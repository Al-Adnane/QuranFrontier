/**
 * Deepfake Detector PWA Service Worker
 * Enables offline functionality and caching
 */

const CACHE_NAME = 'deepfake-detector-v1';
const STATIC_CACHE = 'static-v1';
const DYNAMIC_CACHE = 'dynamic-v1';

// Static assets to cache
const STATIC_ASSETS = [
  '/',
  '/manifest.json',
  '/logo.svg'
];

// Install event - cache static assets
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(STATIC_CACHE).then((cache) => {
      return cache.addAll(STATIC_ASSETS);
    })
  );
  self.skipWaiting();
});

// Activate event - clean up old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys
          .filter((key) => key !== STATIC_CACHE && key !== DYNAMIC_CACHE)
          .map((key) => caches.delete(key))
      );
    })
  );
  self.clients.claim();
});

// Fetch event - serve from cache, fallback to network
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Skip non-GET requests (API calls)
  if (request.method !== 'GET') {
    return;
  }

  // Skip API requests - always fetch fresh
  if (url.pathname.startsWith('/api/')) {
    return;
  }

  // Cache-first for static assets
  event.respondWith(
    caches.match(request).then((cachedResponse) => {
      if (cachedResponse) {
        return cachedResponse;
      }

      return fetch(request).then((networkResponse) => {
        // Cache successful responses
        if (networkResponse.ok) {
          const responseClone = networkResponse.clone();
          caches.open(DYNAMIC_CACHE).then((cache) => {
            cache.put(request, responseClone);
          });
        }
        return networkResponse;
      }).catch(() => {
        // Return offline page for navigation requests
        if (request.mode === 'navigate') {
          return caches.match('/');
        }
        return new Response('Offline', { status: 503 });
      });
    })
  );
});

// Background sync for failed scans
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-scan') {
    event.waitUntil(syncPendingScans());
  }
});

async function syncPendingScans() {
  // Retry any pending scans when back online
  const pendingScans = await getPendingScans();
  
  for (const scan of pendingScans) {
    try {
      await fetch('/api/detect', {
        method: 'POST',
        body: scan.formData
      });
      await removePendingScan(scan.id);
    } catch (error) {
      console.error('Sync failed for scan:', scan.id);
    }
  }
}

async function getPendingScans() {
  // This would use IndexedDB in production
  return [];
}

async function removePendingScan(id) {
  // This would use IndexedDB in production
}

// Push notifications for scan results
self.addEventListener('push', (event) => {
  const data = event.data?.json() ?? {};
  
  const options = {
    icon: '/icons/icon-192.png',
    badge: '/icons/badge.png',
    vibrate: [100, 50, 100],
    data: {
      url: data.url || '/'
    }
  };

  if (data.type === 'scan_complete') {
    const resultConfig = {
      authentic: {
        title: '✅ Media is Authentic',
        body: `Confidence: ${(data.confidence * 100).toFixed(0)}%`,
        icon: '/icons/icon-success.png'
      },
      deepfake: {
        title: '⚠️ Deepfake Detected!',
        body: `Confidence: ${(data.confidence * 100).toFixed(0)}% - Tap for details`,
        icon: '/icons/icon-warning.png'
      },
      uncertain: {
        title: '❓ Result Uncertain',
        body: 'Manual review recommended',
        icon: '/icons/icon-uncertain.png'
      }
    };

    const config = resultConfig[data.result] || resultConfig.uncertain;
    
    event.waitUntil(
      self.registration.showNotification(config.title, {
        ...options,
        body: config.body,
        icon: config.icon
      })
    );
  }
});

// Notification click handler
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  
  event.waitUntil(
    clients.matchAll({ type: 'window' }).then((clientList) => {
      // Focus existing window or open new one
      for (const client of clientList) {
        if (client.url === event.notification.data.url && 'focus' in client) {
          return client.focus();
        }
      }
      return clients.openWindow(event.notification.data.url);
    })
  );
});

console.log('Service Worker registered');
