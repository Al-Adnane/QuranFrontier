/**
 * Kasbah Popup Script
 */

document.addEventListener('DOMContentLoaded', async () => {
  // Load stats from background
  try {
    const stats = await chrome.runtime.sendMessage({ type: 'GET_STATS' })
    
    if (stats) {
      document.getElementById('blockedCount').textContent = stats.requestsBlocked || 0
      document.getElementById('scannedCount').textContent = stats.secretsDetected || 0
      document.getElementById('wsCount').textContent = stats.websocketsProtected || 0
    }
  } catch (e) {
    console.log('Could not load stats')
  }
  
  // Load settings
  const settings = await chrome.storage.local.get(['secretsEnabled', 'mediaEnabled', 'wsEnabled'])
  
  // Toggle handlers
  const toggles = {
    toggleSecrets: 'secretsEnabled',
    toggleMedia: 'mediaEnabled',
    toggleWs: 'wsEnabled'
  }
  
  for (const [id, key] of Object.entries(toggles)) {
    const toggle = document.getElementById(id)
    const isEnabled = settings[key] !== false // Default true
    
    if (isEnabled) toggle.classList.add('active')
    else toggle.classList.remove('active')
    
    toggle.addEventListener('click', async () => {
      const isActive = toggle.classList.toggle('active')
      await chrome.storage.local.set({ [key]: isActive })
    })
  }
  
  // Update status
  const status = document.getElementById('status')
  const allActive = ['toggleSecrets', 'toggleMedia', 'toggleWs']
    .every(id => document.getElementById(id).classList.contains('active'))
  
  status.textContent = allActive ? 'Protected' : 'Partial'
  status.style.color = allActive ? '#22c55e' : '#eab308'
})

// Listen for updates from background
chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'STATS_UPDATE') {
    document.getElementById('blockedCount').textContent = message.stats.requestsBlocked || 0
    document.getElementById('scannedCount').textContent = message.stats.secretsDetected || 0
    document.getElementById('wsCount').textContent = message.stats.websocketsProtected || 0
  }
  
  if (message.type === 'SECURITY_ALERT') {
    const alert = document.getElementById('alert')
    alert.textContent = `⚠️ ${message.reason}`
    alert.classList.add('show')
    setTimeout(() => alert.classList.remove('show'), 5000)
  }
})
