/**
 * Kasbah Media Quality Helper - Service Worker
 * Background script for network-level secret blocking
 * 
 * @version 2.0.0
 */

// ==========================================
// SECRET DETECTION PATTERNS (Inline for service worker)
// ==========================================

const CRITICAL_PATTERNS = [
  { name: 'openai-api-key', pattern: /sk-[a-zA-Z0-9]{20}T3BlbkFJ[a-zA-Z0-9]{20}/g },
  { name: 'openai-project-key', pattern: /sk-proj-[a-zA-Z0-9]{32,}/g },
  { name: 'openai-service-key', pattern: /sk-svcacct-[a-zA-Z0-9]{32,}/g },
  { name: 'anthropic-api-key', pattern: /sk-ant-api03-[a-zA-Z0-9\-]{80,}/g },
  { name: 'stripe-live-key', pattern: /sk_live_[a-zA-Z0-9]{24,}/g },
  { name: 'stripe-test-key', pattern: /sk_test_[a-zA-Z0-9]{24,}/g },
  { name: 'stripe-restricted-key', pattern: /rk_live_[a-zA-Z0-9]{24,}/g },
  { name: 'aws-access-key', pattern: /AKIA[0-9A-Z]{16}/g },
  { name: 'github-token', pattern: /ghp_[a-zA-Z0-9]{36}/g },
  { name: 'github-oauth', pattern: /gho_[a-zA-Z0-9]{36}/g },
  { name: 'github-app-token', pattern: /ghu_[a-zA-Z0-9]{36}/g },
  { name: 'github-app-installation', pattern: /ghs_[a-zA-Z0-9]{36}/g },
  { name: 'google-api-key', pattern: /AIza[a-zA-Z0-9\-_]{35}/g },
  { name: 'slack-bot-token', pattern: /xoxb-[0-9]{10,13}-[0-9]{10,13}-[a-zA-Z0-9]{24}/g },
  { name: 'slack-user-token', pattern: /xoxp-[0-9]{10,13}-[0-9]{10,13}-[0-9]{10,13}-[a-f0-9]{32}/g },
  { name: 'rsa-private-key', pattern: /-----BEGIN (RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----/g },
  { name: 'postgres-connection', pattern: /postgres(ql)?:\/\/[^:]+:[^@]+@[a-zA-Z0-9.\-]+/gi },
  { name: 'mongodb-connection', pattern: /mongodb(\+srv)?:\/\/[^:]+:[^@]+@[a-zA-Z0-9.\-]+/gi },
  { name: 'mysql-connection', pattern: /mysql:\/\/[^:]+:[^@]+@[a-zA-Z0-9.\-]+/gi },
  { name: 'redis-connection', pattern: /redis:\/\/[^:]*:[^@]+@[a-zA-Z0-9.\-]+/gi }
]

const HIGH_PATTERNS = [
  { name: 'firebase-api-key', pattern: /AIzaSy[a-zA-Z0-9\-_]{33}/g },
  { name: 'sendgrid-api-key', pattern: /SG\.[a-zA-Z0-9\-_]{20,}\.[a-zA-Z0-9\-_]{20,}/g },
  { name: 'twilio-account-sid', pattern: /AC[a-f0-9]{32}/g },
  { name: 'generic-api-key', pattern: /api[_\-]?key['\":\s]*['\"]([a-zA-Z0-9_\-]{20,})['\"]/gi }
]

const ALL_PATTERNS = [...CRITICAL_PATTERNS, ...HIGH_PATTERNS]

// ==========================================
// OBFUSCATION DETECTION
// ==========================================

function decodeBase64(str) {
  try {
    const normalized = str.replace(/-/g, '+').replace(/_/g, '/')
    const padded = normalized.padEnd(normalized.length + (4 - normalized.length % 4) % 4, '=')
    return atob(padded)
  } catch { return null }
}

function decodeUrl(str) {
  try { return decodeURIComponent(str) } catch { return null }
}

function decodeUnicodeEscapes(str) {
  return str.replace(/\\u([0-9a-fA-F]{4})/g, (_, code) => 
    String.fromCharCode(parseInt(code, 16)))
}

function removeZeroWidth(str) {
  return str.replace(/[\u200B-\u200D\uFEFF\u00AD]/g, '')
}

function normalizeHomoglyphs(str) {
  const homoglyphs = {
    'а': 'a', 'е': 'e', 'о': 'o', 'р': 'p', 'с': 'c', 'у': 'y', 'х': 'x',
    'А': 'A', 'В': 'B', 'Е': 'E', 'К': 'K', 'М': 'M', 'Н': 'H', 'О': 'O',
    'Р': 'P', 'С': 'C', 'Т': 'T', 'Х': 'X'
  }
  return str.replace(/[а-яёА-ЯЁ]/g, c => homoglyphs[c] || c)
}

// ==========================================
// SECRET SCANNING
// ==========================================

function scanForSecrets(text, checkObfuscated = true) {
  if (!text || typeof text !== 'string') return []
  
  const findings = []
  
  // Preprocess text
  const cleaned = removeZeroWidth(normalizeHomoglyphs(text))
  
  // Scan original and cleaned
  const textsToScan = [text, cleaned]
  
  // Add decoded variants if obfuscation detection enabled
  if (checkObfuscated) {
    const decoded = decodeUrl(cleaned)
    if (decoded) textsToScan.push(decoded)
    
    const unicodeDecoded = decodeUnicodeEscapes(cleaned)
    if (unicodeDecoded !== cleaned) textsToScan.push(unicodeDecoded)
    
    // Check for base64-like strings
    const b64Matches = cleaned.match(/[A-Za-z0-9+\/_=]{40,}/g) || []
    for (const match of b64Matches.slice(0, 5)) { // Limit to prevent DoS
      const decoded = decodeBase64(match)
      if (decoded) textsToScan.push(decoded)
    }
  }
  
  // Scan all variants
  for (const scanText of textsToScan) {
    for (const patternDef of ALL_PATTERNS) {
      patternDef.pattern.lastIndex = 0
      const matches = scanText.matchAll(patternDef.pattern)
      for (const match of matches) {
        findings.push({
          type: patternDef.name,
          match: match[0].slice(0, 100)
        })
      }
    }
  }
  
  // Deduplicate
  const seen = new Set()
  return findings.filter(f => {
    const key = `${f.type}:${f.match}`
    if (seen.has(key)) return false
    seen.add(key)
    return true
  })
}

function hasSecret(text) {
  const cleaned = removeZeroWidth(normalizeHomoglyphs(text))
  
  for (const patternDef of CRITICAL_PATTERNS) {
    patternDef.pattern.lastIndex = 0
    if (patternDef.pattern.test(cleaned)) return true
  }
  
  // Check base64 encoded
  const b64Matches = cleaned.match(/[A-Za-z0-9+\/_=]{40,}/g) || []
  for (const match of b64Matches.slice(0, 3)) {
    const decoded = decodeBase64(match)
    if (decoded) {
      for (const patternDef of CRITICAL_PATTERNS) {
        patternDef.pattern.lastIndex = 0
        if (patternDef.pattern.test(decoded)) return true
      }
    }
  }
  
  return false
}

// ==========================================
// STATISTICS
// ==========================================

let stats = {
  requestsBlocked: 0,
  secretsDetected: 0,
  websocketsProtected: 0
}

// ==========================================
// WEBREQUEST BLOCKING
// ==========================================

// Block requests containing secrets in URL
chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    // Check URL for secrets
    if (hasSecret(details.url)) {
      stats.requestsBlocked++
      stats.secretsDetected++
      console.warn(`[Kasbah] Blocked secret in URL: ${details.url.slice(0, 100)}`)
      return { cancel: true }
    }
    
    // Check POST body for secrets
    if (details.method === 'POST' && details.requestBody) {
      let bodyText = ''
      
      if (details.requestBody.raw) {
        try {
          const decoder = new TextDecoder('utf-8')
          bodyText = decoder.decode(details.requestBody.raw[0]?.bytes)
        } catch {}
      }
      
      if (details.requestBody.formData) {
        for (const [key, values] of Object.entries(details.requestBody.formData)) {
          bodyText += `${key}=${values.join(',')} `
        }
      }
      
      if (bodyText && hasSecret(bodyText)) {
        stats.requestsBlocked++
        stats.secretsDetected++
        console.warn(`[Kasbah] Blocked secret in POST body to: ${details.url.slice(0, 100)}`)
        return { cancel: true }
      }
    }
    
    return {}
  },
  { urls: ['<all_urls>'] },
  ['blocking', 'requestBody']
)

// ==========================================
// MESSAGE HANDLING
// ==========================================

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.type) {
    case 'SCAN_TEXT':
      const findings = scanForSecrets(message.text, true)
      sendResponse({ findings, hasSecrets: findings.length > 0 })
      break
      
    case 'SCAN_REQUEST':
      const urlFindings = scanForSecrets(message.url + ' ' + (message.body || ''), true)
      sendResponse({ 
        findings: urlFindings, 
        blocked: urlFindings.some(f => CRITICAL_PATTERNS.some(p => p.name === f.type))
      })
      break
      
    case 'WEBSOCKET_MESSAGE':
      const wsFindings = scanForSecrets(message.data, true)
      if (wsFindings.some(f => CRITICAL_PATTERNS.some(p => p.name === f.type))) {
        stats.websocketsProtected++
        stats.secretsDetected++
        sendResponse({ blocked: true, reason: 'Secret detected in WebSocket message' })
      } else {
        sendResponse({ blocked: false })
      }
      break
      
    case 'GET_STATS':
      sendResponse(stats)
      break
      
    case 'REPORT_BLOCKED':
      stats.requestsBlocked++
      stats.secretsDetected++
      sendResponse({ acknowledged: true })
      break
      
    default:
      sendResponse({ error: 'Unknown message type' })
  }
  
  return true // Keep channel open for async response
})

// ==========================================
// CONTENT SCRIPT INJECTION
// ==========================================

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'loading' && tab.url) {
    // Inject WebSocket protection script
    chrome.scripting.executeScript({
      target: { tabId },
      files: ['content/websocket-guard.js'],
      injectImmediately: true
    }).catch(() => {}) // Ignore errors for restricted pages
  }
})

// ==========================================
// INITIALIZATION
// ==========================================

console.log('[Kasbah] Media Quality Helper v2.0.0 initialized')
console.log('[Kasbah] Secret protection active')

// Load stats from storage
chrome.storage.local.get(['stats'], (result) => {
  if (result.stats) {
    stats = { ...stats, ...result.stats }
  }
})

// Save stats periodically
setInterval(() => {
  chrome.storage.local.set({ stats })
}, 60000)
