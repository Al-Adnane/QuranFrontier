/**
 * Kasbah Content Loader
 * Main content script for social media deepfake detection
 * 
 * @version 2.0.0
 */

(function() {
  'use strict'
  
  // Prevent multiple injections
  if (window.__KASBAH_CONTENT_ACTIVE) return
  window.__KASBAH_CONTENT_ACTIVE = true

  // ==========================================
  // CONFIGURATION
  // ==========================================

  const CONFIG = {
    // Stealth mode - disguise as quality helper
    badgePrefix: 'mq-',
    qualityLabels: ['Checked', 'Issues', 'Clean'],
    
    // Scan settings
    scanDelay: { min: 800, max: 3000 },
    maxScansPerMinute: 20,
    
    // Platform detection
    platforms: {
      tiktok: { host: 'tiktok.com', selector: '[data-e2e="recommend-list-item-container"] video' },
      instagram: { host: 'instagram.com', selector: 'article video' },
      youtube: { host: 'youtube.com', selector: 'ytd-player video, #shorts-container video' },
      twitter: { host: ['twitter.com', 'x.com'], selector: '[data-testid="videoPlayer"] video' },
      facebook: { host: 'facebook.com', selector: '[data-pagelet="FeedUnit"] video' }
    }
  }

  // Random session class for stealth
  const SESSION_CLASS = CONFIG.badgePrefix + Math.random().toString(36).slice(2, 7)

  // ==========================================
  // STATE
  // ==========================================

  let scanCount = 0
  let lastScanTime = 0
  const scannedMedia = new WeakSet()
  const pendingScans = new Map()

  // ==========================================
  // PLATFORM DETECTION
  // ==========================================

  function getCurrentPlatform() {
    const host = window.location.hostname.replace('www.', '')
    
    for (const [name, config] of Object.entries(CONFIG.platforms)) {
      const hosts = Array.isArray(config.host) ? config.host : [config.host]
      if (hosts.some(h => host === h || host.endsWith('.' + h))) {
        return { name, ...config }
      }
    }
    
    return null
  }

  const platform = getCurrentPlatform()

  // ==========================================
  // UI HELPERS
  // ==========================================

  function createBadge(element, status) {
    // Remove existing badge
    const existing = element.parentElement?.querySelector(`.${SESSION_CLASS}`)
    if (existing) existing.remove()
    
    const badge = document.createElement('div')
    badge.className = SESSION_CLASS
    
    // Stealth styling - looks like quality indicator
    const colors = {
      authentic: { bg: 'rgba(34, 197, 94, 0.9)', text: 'white' },
      deepfake: { bg: 'rgba(239, 68, 68, 0.9)', text: 'white' },
      uncertain: { bg: 'rgba(234, 179, 8, 0.9)', text: 'black' },
      loading: { bg: 'rgba(107, 114, 128, 0.9)', text: 'white' }
    }
    
    const color = colors[status.type] || colors.loading
    
    // Randomized position to avoid detection
    const positions = ['top-right', 'top-left', 'bottom-right']
    const pos = positions[Math.floor(Math.random() * positions.length)]
    
    const posStyles = {
      'top-right': 'top: 8px; right: 8px;',
      'top-left': 'top: 8px; left: 8px;',
      'bottom-right': 'bottom: 8px; right: 8px;'
    }
    
    badge.style.cssText = `
      position: absolute;
      ${posStyles[pos]}
      padding: 4px 8px;
      border-radius: 4px;
      font-size: 11px;
      font-family: -apple-system, BlinkMacSystemFont, sans-serif;
      font-weight: 500;
      background: ${color.bg};
      color: ${color.text};
      z-index: 9999;
      pointer-events: none;
      opacity: 0.95;
      transition: opacity 0.3s;
    `
    
    // Stealth text - doesn't reveal "deepfake" detection
    let displayText = ''
    switch (status.type) {
      case 'authentic':
        displayText = `${Math.round(status.confidence * 100)}%` // Shows like quality score
        break
      case 'deepfake':
        displayText = `!${Math.round(status.confidence * 100)}%` // Subtle warning
        break
      case 'uncertain':
        displayText = '?'
        break
      case 'loading':
        displayText = '...'
        break
      default:
        displayText = CONFIG.qualityLabels[0]
    }
    
    badge.textContent = displayText
    
    // Position relative to video
    if (element.parentElement) {
      const parent = element.parentElement
      if (getComputedStyle(parent).position === 'static') {
        parent.style.position = 'relative'
      }
      parent.appendChild(badge)
    }
    
    return badge
  }

  // ==========================================
  // MEDIA SCANNING
  // ==========================================

  async function scanMedia(element) {
    // Rate limiting
    const now = Date.now()
    if (now - lastScanTime < 60000 / CONFIG.maxScansPerMinute) {
      return
    }
    lastScanTime = now
    scanCount++
    
    // Prevent duplicate scans
    if (scannedMedia.has(element)) return
    scannedMedia.add(element)
    
    // Show loading badge
    const badge = createBadge(element, { type: 'loading' })
    
    try {
      // Get media URL
      const mediaUrl = element.src || element.currentSrc || element.poster
      if (!mediaUrl) {
        badge.remove()
        return
      }
      
      // Add random delay to mimic human behavior
      const delay = CONFIG.scanDelay.min + 
        Math.random() * (CONFIG.scanDelay.max - CONFIG.scanDelay.min)
      await new Promise(r => setTimeout(r, delay))
      
      // Send to detection API
      const response = await fetch('/api/q', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          url: mediaUrl,
          platform: platform?.name 
        })
      })
      
      if (!response.ok) {
        // Fallback to uncertain
        createBadge(element, { type: 'uncertain' })
        return
      }
      
      const data = await response.json()
      
      if (data.detection) {
        createBadge(element, {
          type: data.detection.result,
          confidence: data.detection.confidence
        })
      } else {
        createBadge(element, { type: 'uncertain' })
      }
      
    } catch (error) {
      console.warn('[Kasbah] Scan error:', error.message)
      badge.remove()
    }
  }

  // ==========================================
  // MUTATION OBSERVER
  // ==========================================

  function setupObserver() {
    if (!platform) return
    
    const observer = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        if (mutation.type !== 'childList') continue
        
        for (const node of mutation.addedNodes) {
          if (!(node instanceof HTMLElement)) continue
          
          // Find videos in added content
          const videos = node.matches(platform.selector) 
            ? [node] 
            : Array.from(node.querySelectorAll(platform.selector))
          
          for (const video of videos) {
            if (video.tagName === 'VIDEO' && video.readyState >= 2) {
              scanMedia(video)
            }
          }
        }
      }
    })
    
    observer.observe(document.body, {
      childList: true,
      subtree: true
    })
  }

  // ==========================================
  // VISIBILITY TRIGGER
  // ==========================================

  function setupVisibilityTrigger() {
    if (!platform) return
    
    const observer = new IntersectionObserver((entries) => {
      for (const entry of entries) {
        if (entry.isIntersecting && entry.intersectionRatio > 0.5) {
          const video = entry.target
          if (video.tagName === 'VIDEO') {
            scanMedia(video)
          }
        }
      }
    }, {
      threshold: [0.5],
      rootMargin: '100px'
    })
    
    // Observe existing videos
    const observeVideos = () => {
      document.querySelectorAll(platform.selector).forEach(video => {
        observer.observe(video)
      })
    }
    
    // Initial scan
    observeVideos()
    
    // Re-scan periodically for lazy-loaded content
    setInterval(observeVideos, 5000)
  }

  // ==========================================
  // INITIALIZATION
  // ==========================================

  function init() {
    console.log(`[Kasbah] Content loader active on ${platform?.name || 'unknown platform'}`)
    
    // Setup observers
    setupObserver()
    setupVisibilityTrigger()
    
    // Scan initial content after page load
    if (document.readyState === 'complete') {
      setTimeout(() => {
        document.querySelectorAll(platform?.selector || 'video').forEach(scanMedia)
      }, 1000)
    } else {
      window.addEventListener('load', () => {
        setTimeout(() => {
          document.querySelectorAll(platform?.selector || 'video').forEach(scanMedia)
        }, 1000)
      })
    }
  }

  // Start
  init()
})()
