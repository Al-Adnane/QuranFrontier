/**
 * Kasbah WebSocket Guard
 * Intercepts WebSocket messages to block secret exfiltration
 * 
 * @version 2.0.0
 */

(function() {
  'use strict'
  
  // Prevent multiple injections
  if (window.__KASBAH_WS_GUARD_ACTIVE) return
  window.__KASBAH_WS_GUARD_ACTIVE = true

  // ==========================================
  // SECRET PATTERNS (Simplified for injection)
  // ==========================================

  const SECRET_PATTERNS = [
    /sk-proj-[a-zA-Z0-9]{32,}/g,
    /sk-[a-zA-Z0-9]{20}T3BlbkFJ[a-zA-Z0-9]{20}/g,
    /sk-ant-api03-[a-zA-Z0-9\-]{80,}/g,
    /sk_live_[a-zA-Z0-9]{24,}/g,
    /sk_test_[a-zA-Z0-9]{24,}/g,
    /AKIA[0-9A-Z]{16}/g,
    /ghp_[a-zA-Z0-9]{36}/g,
    /gho_[a-zA-Z0-9]{36}/g,
    /ghu_[a-zA-Z0-9]{36}/g,
    /ghs_[a-zA-Z0-9]{36}/g,
    /AIza[a-zA-Z0-9\-_]{35}/g,
    /xoxb-[0-9]{10,13}-[0-9]{10,13}-[a-zA-Z0-9]{24}/g,
    /xoxp-[0-9]{10,13}-[0-9]{10,13}-[0-9]{10,13}-[a-f0-9]{32}/g,
    /-----BEGIN (RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----/g,
    /postgres(ql)?:\/\/[^:]+:[^@]+@[a-zA-Z0-9.\-]+/gi,
    /mongodb(\+srv)?:\/\/[^:]+:[^@]+@[a-zA-Z0-9.\-]+/gi,
    /mysql:\/\/[^:]+:[^@]+@[a-zA-Z0-9.\-]+/gi
  ]

  // ==========================================
  // OBFUSCATION DETECTION
  // ==========================================

  function decodeBase64(str) {
    try {
      const normalized = str.replace(/-/g, '+').replace(/_/g, '/')
      const padded = normalized.padEnd(normalized.length + (4 - normalized.length % 4) % 4, '=')
      return atob(padded)
    } catch { return null }
  }

  function decodeUrl(str) {
    try { return decodeURIComponent(str) } catch { return null }
  }

  function removeZeroWidth(str) {
    return str.replace(/[\u200B-\u200D\uFEFF\u00AD]/g, '')
  }

  function normalizeHomoglyphs(str) {
    const homoglyphs = {
      'а': 'a', 'е': 'e', 'о': 'o', 'р': 'p', 'с': 'c', 'у': 'y', 'х': 'x',
      'А': 'A', 'В': 'B', 'Е': 'E', 'К': 'K', 'М': 'M', 'Н': 'H', 'О': 'O',
      'Р': 'P', 'С': 'C', 'Т': 'T', 'Х': 'X'
    }
    return str.replace(/[а-яёА-ЯЁ]/g, c => homoglyphs[c] || c)
  }

  // ==========================================
  // SECRET SCANNING
  // ==========================================

  function hasSecret(text) {
    if (!text || typeof text !== 'string') return false
    
    // Clean and normalize
    const cleaned = removeZeroWidth(normalizeHomoglyphs(text))
    
    // Check direct patterns
    for (const pattern of SECRET_PATTERNS) {
      pattern.lastIndex = 0
      if (pattern.test(cleaned)) return true
    }
    
    // Check URL decoded
    const urlDecoded = decodeUrl(cleaned)
    if (urlDecoded && urlDecoded !== cleaned) {
      for (const pattern of SECRET_PATTERNS) {
        pattern.lastIndex = 0
        if (pattern.test(urlDecoded)) return true
      }
    }
    
    // Check base64 encoded strings
    const b64Matches = cleaned.match(/[A-Za-z0-9+\/_=]{40,}/g) || []
    for (const match of b64Matches.slice(0, 3)) {
      const decoded = decodeBase64(match)
      if (decoded) {
        for (const pattern of SECRET_PATTERNS) {
          pattern.lastIndex = 0
          if (pattern.test(decoded)) return true
        }
      }
    }
    
    return false
  }

  // ==========================================
  // WEBSOCKET INTERCEPTION
  // ==========================================

  const OriginalWebSocket = window.WebSocket
  const wsRegistry = new Map()
  let wsIdCounter = 0

  class ProtectedWebSocket extends OriginalWebSocket {
    constructor(url, protocols) {
      super(url, protocols)
      
      this._kasbahId = ++wsIdCounter
      this._kasbahUrl = url
      wsRegistry.set(this._kasbahId, this)
      
      // Intercept incoming messages
      super.addEventListener('message', (event) => {
        // Scan incoming data for secrets (could be malicious injection)
        if (typeof event.data === 'string' && hasSecret(event.data)) {
          console.warn('[Kasbah] Secret detected in incoming WebSocket message')
          event.stopImmediatePropagation()
          return
        }
      })
    }

    send(data) {
      // Scan outgoing data for secrets
      if (typeof data === 'string' && hasSecret(data)) {
        console.warn('[Kasbah] Blocked secret in WebSocket.send()')
        
        // Notify background script
        if (chrome?.runtime?.sendMessage) {
          chrome.runtime.sendMessage({
            type: 'WEBSOCKET_MESSAGE',
            data: data.slice(0, 500)
          })
        }
        
        return // Drop the message silently
      }
      
      super.send(data)
    }
  }

  // Copy static properties
  Object.defineProperty(ProtectedWebSocket, 'CONNECTING', { value: OriginalWebSocket.CONNECTING })
  Object.defineProperty(ProtectedWebSocket, 'OPEN', { value: OriginalWebSocket.OPEN })
  Object.defineProperty(ProtectedWebSocket, 'CLOSING', { value: OriginalWebSocket.CLOSING })
  Object.defineProperty(ProtectedWebSocket, 'CLOSED', { value: OriginalWebSocket.CLOSED })

  // Replace global WebSocket
  window.WebSocket = ProtectedWebSocket

  // ==========================================
  // FETCH INTERCEPTION
  // ==========================================

  const originalFetch = window.fetch
  
  window.fetch = function(input, init = {}) {
    let url = typeof input === 'string' ? input : input.url || ''
    let body = init.body || ''
    
    // Check URL for secrets
    if (hasSecret(url)) {
      console.warn('[Kasbah] Blocked secret in fetch URL')
      return Promise.reject(new Error('Request blocked by Kasbah'))
    }
    
    // Check body for secrets
    if (typeof body === 'string' && hasSecret(body)) {
      console.warn('[Kasbah] Blocked secret in fetch body')
      return Promise.reject(new Error('Request blocked by Kasbah'))
    }
    
    return originalFetch.call(this, input, init)
  }

  // ==========================================
  // XMLHTTPREQUEST INTERCEPTION
  // ==========================================

  const OriginalXHR = window.XMLHttpRequest
  const originalOpen = OriginalXHR.prototype.open
  const originalSend = OriginalXHR.prototype.send
  const originalSetRequestHeader = OriginalXHR.prototype.setRequestHeader

  class ProtectedXHR extends OriginalXHR {
    constructor() {
      super()
      this._kasbahHeaders = {}
    }

    open(method, url, ...args) {
      this._kasbahUrl = url
      this._kasbahMethod = method
      
      // Check URL for secrets
      if (hasSecret(url)) {
        console.warn('[Kasbah] Blocked secret in XHR URL')
        throw new Error('Request blocked by Kasbah')
      }
      
      return originalOpen.call(this, method, url, ...args)
    }

    send(body) {
      // Check body for secrets
      if (typeof body === 'string' && hasSecret(body)) {
        console.warn('[Kasbah] Blocked secret in XHR body')
        throw new Error('Request blocked by Kasbah')
      }
      
      return originalSend.call(this, body)
    }

    setRequestHeader(name, value) {
      // Check header value for secrets
      if (hasSecret(value)) {
        console.warn('[Kasbah] Blocked secret in XHR header')
        return
      }
      
      return originalSetRequestHeader.call(this, name, value)
    }
  }

  window.XMLHttpRequest = ProtectedXHR

  // ==========================================
  // FORM SUBMISSION INTERCEPTION
  // ==========================================

  document.addEventListener('submit', (event) => {
    const form = event.target
    if (!form || form.tagName !== 'FORM') return
    
    const formData = new FormData(form)
    const entries = Array.from(formData.entries()).map(([k, v]) => `${k}=${v}`).join('&')
    
    if (hasSecret(entries)) {
      console.warn('[Kasbah] Blocked secret in form submission')
      event.preventDefault()
      event.stopImmediatePropagation()
    }
  }, true) // Use capture phase

  // ==========================================
  // CLIPBOARD INTERCEPTION
  // ==========================================

  const originalWriteText = navigator.clipboard?.writeText?.bind(navigator.clipboard)
  
  if (originalWriteText) {
    navigator.clipboard.writeText = function(text) {
      if (hasSecret(text)) {
        console.warn('[Kasbah] Allowed clipboard write but logged')
        // Don't block - user may be intentionally copying their own secret
      }
      return originalWriteText(text)
    }
  }

  console.log('[Kasbah] WebSocket Guard active')
})()
