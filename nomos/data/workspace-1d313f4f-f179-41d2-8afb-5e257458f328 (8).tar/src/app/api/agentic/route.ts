import { NextRequest, NextResponse } from 'next/server'
import {
  getAgenticSystemStatus,
  initializeAgenticModules,
  // Behavior Monitoring
  registerAgent,
  getAgentProfile,
  analyzeBehavior,
  detectAnomalies,
  // Policy Guardrails
  createPolicy,
  evaluatePolicy,
  listPolicies,
  // Multi-Agent Coordination
  registerAgentNode,
  createGroup,
  proposeConsensus,
  vote,
  sendMessage,
  detectRogueAgents,
  // Identity & Attestation
  createAgentIdentity,
  verifyCertificate,
  generateAttestation,
  verifySupplyChain,
  // Decision Auditing
  explainDecision,
  rollbackDecision,
  performForensicAnalysis,
  // Sandbox
  createSandboxConfig,
  startSandboxSession,
  checkCircuitBreaker
} from '@/lib/agentic'

// Initialize modules on first request
let initialized = false

export async function GET(request: NextRequest) {
  if (!initialized) {
    initializeAgenticModules()
    initialized = true
  }

  const { searchParams } = new URL(request.url)
  const action = searchParams.get('action') || 'status'

  try {
    switch (action) {
      case 'status':
        return NextResponse.json({
          success: true,
          status: getAgenticSystemStatus()
        })

      case 'agents':
        const agentsModule = await import('@/lib/agentic/agent-behavior-monitor')
        return NextResponse.json({
          success: true,
          agents: agentsModule.getAllAgents()
        })

      case 'policies':
        return NextResponse.json({
          success: true,
          policies: listPolicies()
        })

      case 'anomalies':
        return NextResponse.json({
          success: true,
          anomalies: detectAnomalies()
        })

      case 'rogue-agents':
        return NextResponse.json({
          success: true,
          rogueAgents: detectRogueAgents()
        })

      case 'stats':
        return NextResponse.json({
          success: true,
          behavior: (await import('@/lib/agentic/agent-behavior-monitor')).getBehaviorMonitorStats(),
          policy: (await import('@/lib/agentic/policy-guardrails')).getPolicyStats(),
          coordination: (await import('@/lib/agentic/multi-agent-coordination')).getCoordinationStats(),
          identity: (await import('@/lib/agentic/agent-identity')).getAgentIdentityStats(),
          audit: (await import('@/lib/agentic/decision-auditing')).getAuditStatistics(),
          sandbox: (await import('@/lib/agentic/agent-sandbox')).getSandboxStats()
        })

      default:
        return NextResponse.json({
          success: false,
          error: 'Unknown action',
          availableActions: ['status', 'agents', 'policies', 'anomalies', 'rogue-agents', 'stats']
        }, { status: 400 })
    }
  } catch (error) {
    console.error('[API] Agentic error:', error)
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  if (!initialized) {
    initializeAgenticModules()
    initialized = true
  }

  try {
    const body = await request.json()
    const { action, ...params } = body

    switch (action) {
      // Agent Management
      case 'register-agent':
        const agent = registerAgent({
          name: params.name,
          type: params.type,
          capabilities: params.capabilities || [],
          restrictions: params.restrictions || []
        })
        return NextResponse.json({ success: true, agent })

      case 'record-decision':
        const { recordDecision } = await import('@/lib/agentic/agent-behavior-monitor')
        const decision = recordDecision(params.agentId, {
          action: params.decisionAction,
          input: params.input,
          output: params.output,
          reasoning: params.reasoning,
          confidence: params.confidence || 0.5,
          riskLevel: params.riskLevel || 'medium'
        })
        return NextResponse.json({ success: true, decision })

      case 'analyze-behavior':
        const analysis = analyzeBehavior(params.agentId)
        return NextResponse.json({ success: true, analysis })

      // Policy Management
      case 'create-policy':
        const policy = createPolicy({
          name: params.name,
          description: params.description || '',
          effect: params.effect,
          priority: params.priority || 50,
          conditions: params.conditions || [],
          actions: params.actions || ['*'],
          resources: params.resources || ['*'],
          enabled: params.enabled ?? true
        })
        return NextResponse.json({ success: true, policy })

      case 'evaluate-policy':
        const result = evaluatePolicy({
          agentId: params.agentId,
          action: params.policyAction,
          resource: params.resource,
          context: params.context || {}
        })
        return NextResponse.json({ success: true, result })

      // Multi-Agent Coordination
      case 'register-node':
        const node = registerAgentNode({
          name: params.name,
          publicKey: params.publicKey,
          capabilities: params.capabilities || []
        })
        return NextResponse.json({ success: true, node })

      case 'create-group':
        const group = createGroup(
          params.name,
          params.purpose,
          params.members,
          params.consensusThreshold || 51
        )
        return NextResponse.json({ success: true, group })

      case 'propose-consensus':
        const proposal = proposeConsensus(
          params.groupId,
          params.proposerId,
          params.consensusAction,
          params.payload
        )
        return NextResponse.json({ success: true, proposal })

      case 'vote':
        const updatedProposal = vote(params.proposalId, params.voterId, params.vote)
        return NextResponse.json({ success: true, proposal: updatedProposal })

      case 'send-message':
        const message = sendMessage({
          fromAgentId: params.fromAgentId,
          toAgentId: params.toAgentId,
          type: params.messageType,
          payload: params.payload
        })
        return NextResponse.json({ success: true, message })

      // Identity & Attestation
      case 'create-identity':
        const identity = createAgentIdentity(
          params.capabilities || [],
          params.restrictions || [],
          params.validityDays || 365
        )
        return NextResponse.json({ success: true, identity })

      case 'generate-attestation':
        const attestation = generateAttestation(
          params.agentId,
          params.attestationType,
          params.measurements
        )
        return NextResponse.json({ success: true, attestation })

      case 'verify-supply-chain':
        const chainResult = verifySupplyChain(params.agentId)
        return NextResponse.json({ success: true, result: chainResult })

      // Decision Auditing
      case 'explain-decision':
        const explanation = explainDecision(params.decisionId, params.question)
        return NextResponse.json({ success: true, explanation })

      case 'rollback-decision':
        const rollback = rollbackDecision(
          params.decisionId,
          params.reason,
          params.rolledBackBy
        )
        return NextResponse.json({ success: true, rollback })

      case 'forensic-analysis':
        const forensics = performForensicAnalysis(params.targetId, params.options)
        return NextResponse.json({ success: true, forensics })

      // Sandbox Management
      case 'create-sandbox':
        const sandbox = createSandboxConfig(params.agentId, {
          isolationLevel: params.isolationLevel || 'moderate',
          resourceLimits: params.resourceLimits,
          allowedOperations: params.allowedOperations || [],
          deniedOperations: params.deniedOperations || [],
          networkAllowList: params.networkAllowList || [],
          fileAllowList: params.fileAllowList || [],
          environmentVariables: params.environmentVariables || {}
        })
        return NextResponse.json({ success: true, sandbox })

      case 'start-sandbox-session':
        const session = startSandboxSession(params.configId)
        return NextResponse.json({ success: true, session })

      case 'check-circuit-breaker':
        const breakerStatus = checkCircuitBreaker(params.breakerId)
        return NextResponse.json({ success: true, status: breakerStatus })

      default:
        return NextResponse.json({
          success: false,
          error: 'Unknown action',
          availableActions: [
            'register-agent', 'record-decision', 'analyze-behavior',
            'create-policy', 'evaluate-policy',
            'register-node', 'create-group', 'propose-consensus', 'vote', 'send-message',
            'create-identity', 'generate-attestation', 'verify-supply-chain',
            'explain-decision', 'rollback-decision', 'forensic-analysis',
            'create-sandbox', 'start-sandbox-session', 'check-circuit-breaker'
          ]
        }, { status: 400 })
    }
  } catch (error) {
    console.error('[API] Agentic POST error:', error)
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 })
  }
}
