/**
 * Unified Kasbah API Route
 * 
 * Single endpoint for all Kasbah capabilities
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  getUnifiedStatus,
  getMoatSummary,
  MOATS,
  PATENT_FAMILIES,
  TIER1_PATENTS,
  PRODUCT_IDEAS_BY_MOAT,
  TECHNOLOGY_WAVES
} from '@/lib/unified';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const action = searchParams.get('action') || 'status';

  try {
    switch (action) {
      case 'status':
        return NextResponse.json({
          success: true,
          data: getUnifiedStatus()
        });

      case 'moats':
        return NextResponse.json({
          success: true,
          data: {
            moats: MOATS,
            summary: getMoatSummary()
          }
        });

      case 'patents':
        return NextResponse.json({
          success: true,
          data: {
            families: PATENT_FAMILIES,
            tier1Patents: TIER1_PATENTS,
            totalInventions: 38,
            totalFamilies: 7
          }
        });

      case 'products':
        return NextResponse.json({
          success: true,
          data: {
            ideasByMoat: PRODUCT_IDEAS_BY_MOAT,
            totalIdeas: 130,
            categories: 13
          }
        });

      case 'waves':
        return NextResponse.json({
          success: true,
          data: {
            waves: TECHNOLOGY_WAVES,
            totalTAM: '$260-430M+ ARR'
          }
        });

      case 'summary':
        const status = getUnifiedStatus();
        return NextResponse.json({
          success: true,
          data: {
            version: status.version,
            disruptionScore: status.disruptionScore,
            valuation: status.valuation,
            moats: `${status.moats.production}/${status.moats.total} production`,
            patents: `${status.patents.totalInventions} inventions, ${status.patents.families} families`,
            products: `${status.products.totalIdeas} ideas`,
            waves: `${status.waves.active}/${status.waves.total} active`,
            totalTAM: status.waves.totalTAM,
            estimatedARR: status.products.estimatedARR
          }
        });

      default:
        return NextResponse.json({
          success: false,
          error: 'Invalid action. Use: status, moats, patents, products, waves, summary'
        }, { status: 400 });
    }
  } catch (error) {
    console.error('[Unified API] Error:', error);
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}
