import { NextRequest, NextResponse } from 'next/server'
import { analyzeSocialMediaURL } from '@/lib/social-media-analyzer'
import {
  detectionLimiter,
  getClientIdentifier,
  createRateLimitHeaders,
} from '@/lib/rate-limiter'
import { generateRequestId, createLogger } from '@/lib/logger'
import { handleError, createErrorResponse, RateLimitError } from '@/lib/errors'

const logger = createLogger('url')

export async function POST(request: NextRequest) {
  const requestId = generateRequestId()

  try {
    const clientId = getClientIdentifier(request)
    const rateLimitResult = detectionLimiter.check(clientId)
    
    if (!rateLimitResult.allowed) {
      throw new RateLimitError(rateLimitResult.retryAfter || 60)
    }

    const body = await request.json()
    const { url } = body

    if (!url || typeof url !== 'string') {
      return NextResponse.json(
        { success: false, error: 'Please provide a valid URL' },
        { status: 400 }
      )
    }

    // Validate URL format
    let parsedUrl: URL
    try {
      parsedUrl = new URL(url.startsWith('http') ? url : `https://${url}`)
    } catch {
      return NextResponse.json({
        success: false,
        error: 'Invalid URL format. Please paste a valid TikTok, Instagram, or YouTube link.',
        hint: 'Example: https://www.tiktok.com/@user/video/123456789'
      })
    }

    logger.info('Analyzing URL', { url: parsedUrl.href })

    const result = await analyzeSocialMediaURL(parsedUrl.href)

    const headers = createRateLimitHeaders(rateLimitResult)
    headers.set('X-Request-ID', requestId)

    return NextResponse.json({
      success: result.success,
      platform: result.platform,
      mediaType: result.mediaType,
      thumbnail: result.thumbnailBase64 ? `data:image/jpeg;base64,${result.thumbnailBase64}` : null,
      result: result.analysisResult,
      error: result.error,
      shareableCard: result.shareableCard ? `data:image/svg+xml;base64,${result.shareableCard}` : null
    }, { headers })

  } catch (error) {
    logger.error('URL analysis failed', error instanceof Error ? error : undefined)
    
    const errorResponse = createErrorResponse(error)
    
    return NextResponse.json(errorResponse, {
      status: errorResponse.code === 'RATE_LIMIT_EXCEEDED' ? 429 : 500
    })
  }
}
