/**
 * Real-time Analysis Progress API
 * Provides progress updates for long-running analysis jobs
 */

import { NextRequest, NextResponse } from 'next/server'

// In-memory progress store (use Redis in production)
const progressStore = new Map<string, {
  status: 'pending' | 'processing' | 'completed' | 'failed'
  progress: number
  message: string
  startTime: number
  result?: unknown
  error?: string
}>()

export function setProgress(requestId: string, progress: number, message: string) {
  const existing = progressStore.get(requestId)
  progressStore.set(requestId, {
    status: progress < 100 ? 'processing' : 'completed',
    progress,
    message,
    startTime: existing?.startTime || Date.now()
  })
}

export function setResult(requestId: string, result: unknown) {
  const existing = progressStore.get(requestId)
  if (existing) {
    progressStore.set(requestId, {
      ...existing,
      status: 'completed',
      progress: 100,
      result
    })
  }
}

export function setError(requestId: string, error: string) {
  const existing = progressStore.get(requestId)
  if (existing) {
    progressStore.set(requestId, {
      ...existing,
      status: 'failed',
      error
    })
  }
}

export function getProgress(requestId: string) {
  return progressStore.get(requestId) || {
    status: 'pending' as const,
    progress: 0,
    message: 'Waiting to start...',
    startTime: Date.now()
  }
}

export function cleanupProgress(requestId: string) {
  // Clean up after 5 minutes
  setTimeout(() => {
    progressStore.delete(requestId)
  }, 5 * 60 * 1000)
}

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const requestId = searchParams.get('requestId')

  if (!requestId) {
    return NextResponse.json(
      { success: false, error: 'Missing requestId parameter' },
      { status: 400 }
    )
  }

  const progress = getProgress(requestId)

  // Calculate elapsed time
  const elapsed = Date.now() - progress.startTime
  const elapsedSeconds = Math.floor(elapsed / 1000)

  // Estimate remaining time (simple linear estimation)
  let estimatedRemaining: number | null = null
  if (progress.progress > 0 && progress.progress < 100) {
    const rate = progress.progress / elapsedSeconds
    if (rate > 0) {
      estimatedRemaining = Math.round((100 - progress.progress) / rate)
    }
  }

  return NextResponse.json({
    success: true,
    progress: {
      ...progress,
      elapsed: elapsedSeconds,
      estimatedRemaining
    }
  })
}
