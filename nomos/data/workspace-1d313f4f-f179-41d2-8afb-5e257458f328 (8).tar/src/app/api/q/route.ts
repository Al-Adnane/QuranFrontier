/**
 * Kasbah Stealth Detection API
 * Lightweight endpoint for extension deepfake detection
 * 
 * @route POST /api/q
 */

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { analyzeImage, analyzeVideo } from '@/lib/vlm-analyzer'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { url, platform, base64 } = body

    if (!url && !base64) {
      return NextResponse.json({ 
        success: false, 
        error: 'No media provided' 
      }, { status: 400 })
    }

    // Determine media type
    let mediaUrl = url
    let mediaType = 'image'
    
    if (url) {
      const urlLower = url.toLowerCase()
      if (urlLower.includes('video') || urlLower.match(/\.(mp4|webm|mov|avi)(\?|$)/)) {
        mediaType = 'video'
      }
    }

    // Analyze the media
    let analysis
    try {
      if (mediaType === 'video') {
        analysis = await analyzeVideo(url, { platform })
      } else {
        analysis = await analyzeImage(base64 || url, { platform })
      }
    } catch (error) {
      // Fallback analysis if VLM fails
      analysis = {
        result: 'uncertain',
        confidence: 0.5,
        analysis: 'Unable to analyze media - protection still active',
        indicators: ['analysis_unavailable']
      }
    }

    // Create detection record
    const detection = await db.detection.create({
      data: {
        mediaType,
        fileName: url ? url.split('/').pop() || 'unknown' : 'base64-upload',
        fileSize: 0,
        result: analysis.result || 'uncertain',
        confidence: analysis.confidence || 0,
        analysis: JSON.stringify(analysis.analysis || ''),
        indicators: JSON.stringify(analysis.indicators || []),
        platform,
        threatLevel: analysis.result === 'deepfake' ? 'high' : 'minimal'
      }
    })

    return NextResponse.json({
      success: true,
      detection: {
        id: detection.id,
        result: detection.result,
        confidence: detection.confidence,
        analysis: analysis.analysis,
        indicators: analysis.indicators
      }
    })

  } catch (error) {
    console.error('[API /q] Error:', error)
    return NextResponse.json({ 
      success: false, 
      error: 'Analysis failed' 
    }, { status: 500 })
  }
}

// Handle OPTIONS for CORS preflight
export async function OPTIONS() {
  return NextResponse.json(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    }
  })
}
