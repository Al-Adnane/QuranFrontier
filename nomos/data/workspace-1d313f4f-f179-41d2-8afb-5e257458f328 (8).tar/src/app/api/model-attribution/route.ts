import { NextRequest, NextResponse } from 'next/server'
import { apiLogger as logger } from '@/lib/logger'

/**
 * GET /api/model-attribution
 * Get supported AI generators
 */
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const action = searchParams.get('action')
  
  try {
    // Import dynamically to avoid build issues
    const { getAllGenerators, getVideoGenerators, getImageGenerators, getGeneratorById } = 
      await import('@/lib/detection/model-attribution')
    
    switch (action) {
      case 'list':
        return NextResponse.json({
          success: true,
          generators: getAllGenerators()
        })
        
      case 'video':
        return NextResponse.json({
          success: true,
          generators: getVideoGenerators(),
          count: Object.keys(getVideoGenerators()).length
        })
        
      case 'image':
        return NextResponse.json({
          success: true,
          generators: getImageGenerators(),
          count: Object.keys(getImageGenerators()).length
        })
        
      case 'generator':
        const id = searchParams.get('id')
        if (!id) {
          return NextResponse.json(
            { success: false, error: 'Generator ID required' },
            { status: 400 }
          )
        }
        const generator = getGeneratorById(id)
        if (!generator) {
          return NextResponse.json(
            { success: false, error: 'Generator not found' },
            { status: 404 }
          )
        }
        return NextResponse.json({
          success: true,
          generator
        })
        
      default:
        return NextResponse.json({
          success: true,
          message: 'AI Model Attribution API',
          endpoints: {
            'GET ?action=list': 'List all supported generators',
            'GET ?action=video': 'List video generators',
            'GET ?action=image': 'List image generators',
            'GET ?action=generator&id=XXX': 'Get specific generator info',
            'POST': 'Analyze media for AI attribution'
          },
          supportedGenerators: {
            video: Object.keys(getVideoGenerators()).length,
            image: Object.keys(getImageGenerators()).length,
            total: Object.keys(getAllGenerators()).length
          },
          features: [
            'Google Veo detection',
            'OpenAI Sora detection',
            'Runway Gen-3 detection',
            'Kling AI detection',
            'Hailuo/MiniMax detection',
            'Luma Dream Machine detection',
            'Seedance detection (dance motion)',
            'Nano manipulation detection',
            'Temporal coherence analysis',
            'Cross-modal consistency check'
          ]
        })
    }
  } catch (error) {
    logger.error('Model attribution GET error', { error })
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

/**
 * POST /api/model-attribution
 * Analyze media for AI model attribution
 */
export async function POST(request: NextRequest) {
  const startTime = Date.now()
  
  try {
    const formData = await request.formData()
    const file = formData.get('file') as File | null
    const analysisType = formData.get('type') as string || 'full'
    
    if (!file) {
      return NextResponse.json(
        { success: false, error: 'No file provided' },
        { status: 400 }
      )
    }
    
    // Read file buffer
    const buffer = Buffer.from(await file.arrayBuffer())
    const mediaType = file.type.startsWith('video') ? 'video' : 'image'
    
    logger.info('Model attribution analysis started', {
      fileName: file.name,
      fileSize: file.size,
      mediaType,
      analysisType
    })
    
    // Import detection modules
    const { analyzeModelAttribution } = await import('@/lib/detection/model-attribution')
    const { 
      detectMotionPatterns,
      detectNanoManipulation,
      analyzeTemporalCoherence,
      comprehensiveAnalysis,
      generateDetectionFingerprint
    } = await import('@/lib/detection/specialized-detection')
    
    // Run analysis based on type
    let result: Record<string, unknown> = {}
    
    switch (analysisType) {
      case 'attribution':
        result = await analyzeModelAttribution(buffer, mediaType)
        break
        
      case 'motion':
        if (mediaType !== 'video') {
          return NextResponse.json(
            { success: false, error: 'Motion analysis only for video' },
            { status: 400 }
          )
        }
        result = await detectMotionPatterns(buffer)
        break
        
      case 'nano':
        result = await detectNanoManipulation(buffer, mediaType)
        break
        
      case 'temporal':
        if (mediaType !== 'video') {
          return NextResponse.json(
            { success: false, error: 'Temporal analysis only for video' },
            { status: 400 }
          )
        }
        const fakeFrames = Array(10).fill(buffer)
        result = await analyzeTemporalCoherence(fakeFrames)
        break
        
      case 'full':
      default:
        const frames = mediaType === 'video' ? Array(10).fill(buffer) : undefined
        result = await comprehensiveAnalysis(buffer, frames)
        break
    }
    
    const duration = Date.now() - startTime
    
    logger.info('Model attribution analysis completed', {
      duration,
      analysisType,
      mediaType
    })
    
    return NextResponse.json({
      success: true,
      analysisType,
      mediaType,
      fileName: file.name,
      fileSize: file.size,
      duration,
      result,
      fingerprint: analysisType === 'full' ? generateDetectionFingerprint(result as Awaited<ReturnType<typeof comprehensiveAnalysis>>) : undefined
    })
    
  } catch (error) {
    logger.error('Model attribution analysis failed', { error })
    return NextResponse.json(
      { 
        success: false, 
        error: error instanceof Error ? error.message : 'Analysis failed' 
      },
      { status: 500 }
    )
  }
}
