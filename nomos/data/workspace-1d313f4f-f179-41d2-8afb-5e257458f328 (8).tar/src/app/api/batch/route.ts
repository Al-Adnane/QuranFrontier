import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import {
  sanitizeFilename,
  MAX_FILE_SIZE,
} from '@/lib/validation'
import {
  detectionLimiter,
  getClientIdentifier,
  createRateLimitHeaders,
} from '@/lib/rate-limiter'
import {
  createLogger,
  generateRequestId,
  logRequest,
  logResponse,
} from '@/lib/logger'
import {
  ValidationError,
  RateLimitError,
  handleError,
  createErrorResponse,
} from '@/lib/errors'
import { addAuditEntry } from '@/lib/moats/audit-ledger'
import { recordThreatEvent } from '@/lib/moats/dynamic-thresholds'

const MAX_BATCH_SIZE = 10
const MAX_BATCH_TOTAL_SIZE = 100 * 1024 * 1024 // 100MB total

const logger = createLogger('batch')

export async function POST(request: NextRequest) {
  const requestId = generateRequestId()
  const startTime = Date.now()

  try {
    logRequest('POST', '/api/batch', requestId)

    const clientId = getClientIdentifier(request)
    const rateLimitResult = detectionLimiter.check(clientId)
    
    if (!rateLimitResult.allowed) {
      throw new RateLimitError(rateLimitResult.retryAfter || 60)
    }

    const formData = await request.formData()
    const files = formData.getAll('files') as File[]

    if (!files || files.length === 0) {
      throw new ValidationError('No files provided for batch processing')
    }

    if (files.length > MAX_BATCH_SIZE) {
      throw new ValidationError(`Maximum ${MAX_BATCH_SIZE} files per batch`)
    }

    // Calculate total size
    const totalSize = files.reduce((sum, f) => sum + f.size, 0)
    if (totalSize > MAX_BATCH_TOTAL_SIZE) {
      throw new ValidationError(`Total batch size (${(totalSize / 1024 / 1024).toFixed(1)}MB) exceeds limit of ${MAX_BATCH_TOTAL_SIZE / 1024 / 1024}MB`)
    }

    // Process each file
    const results = []
    const errors = []

    for (let i = 0; i < files.length; i++) {
      const file = files[i]
      
      try {
        // Validate individual file
        if (file.size > MAX_FILE_SIZE) {
          errors.push({
            filename: file.name,
            error: 'File too large'
          })
          continue
        }

        const sanitizedFilename = sanitizeFilename(file.name)
        
        // Add audit entry
        addAuditEntry('DETECT', sanitizedFilename, 'SUCCESS', {
          batchIndex: i,
          batchSize: files.length
        })

        // For batch, we store metadata only and return queue position
        const savedDetection = await db.detection.create({
          data: {
            mediaType: file.type.startsWith('image/') ? 'image' 
              : file.type.startsWith('video/') ? 'video' 
              : 'audio',
            fileName: sanitizedFilename,
            fileSize: file.size,
            result: 'uncertain',
            confidence: 0.5,
            analysis: 'Queued for batch processing',
            indicators: '[]'
          }
        })

        results.push({
          id: savedDetection.id,
          filename: sanitizedFilename,
          status: 'queued',
          queuePosition: i + 1
        })

      } catch (error) {
        errors.push({
          filename: file.name,
          error: error instanceof Error ? error.message : 'Unknown error'
        })
      }
    }

    const duration = Date.now() - startTime
    logResponse('POST', '/api/batch', 200, duration, requestId)

    logger.info('Batch processing completed', {
      total: files.length,
      successful: results.length,
      failed: errors.length,
      duration
    })

    // Record batch processing for threat tracking
    if (errors.length > files.length * 0.5) {
      recordThreatEvent('mass_requests')
    }

    const headers = createRateLimitHeaders(rateLimitResult)
    headers.set('X-Request-ID', requestId)

    return NextResponse.json({
      success: true,
      batch: {
        total: files.length,
        processed: results.length,
        failed: errors.length,
        results,
        errors: errors.length > 0 ? errors : undefined,
        processingTime: duration
      }
    }, { headers })

  } catch (error) {
    const appError = handleError(error)
    logResponse('POST', '/api/batch', appError.statusCode, Date.now() - startTime, requestId)
    
    const errorResponse = createErrorResponse(error)
    
    return NextResponse.json(errorResponse, {
      status: appError.statusCode,
      headers: { 'X-Request-ID': requestId }
    })
  }
}

export async function GET() {
  return NextResponse.json(
    { 
      success: false, 
      error: 'Method not allowed. Use POST to submit batch files.',
      info: {
        maxBatchSize: MAX_BATCH_SIZE,
        maxTotalSize: `${MAX_BATCH_TOTAL_SIZE / 1024 / 1024}MB`,
        allowedTypes: ['image/*', 'video/*', 'audio/*']
      }
    },
    { status: 405 }
  )
}
