/**
 * Thaura.ai Compatible API Route
 * Provides OpenAI/Thaura-compatible endpoints for deepfake detection
 * 
 * @route POST /api/thaura/v1/chat/completions
 */

import { NextRequest, NextResponse } from 'next/server';
import {
  getExternalAIProviderManager,
  type AIProvider,
  type ChatMessage,
  type FileAttachment,
} from '@/lib/security/external-ai-provider';
import {
  getMultiModalProcessor,
  type MediaType,
} from '@/lib/security/multimodal-processor';
import {
  getFunctionCallingExecutor,
  executeDetectionFunction,
} from '@/lib/security/function-calling-framework';
import {
  getEthicalAIVerifier,
} from '@/lib/security/ethical-ai-verification';
import {
  getAPIGateway,
} from '@/lib/security/api-gateway';

// ============================================================================
// TYPES
// ============================================================================

interface ChatCompletionRequest {
  messages: ChatMessage[];
  model?: string;
  temperature?: number;
  max_tokens?: number;
  stream?: boolean;
  stream_options?: {
    include_usage?: boolean;
  };
  tools?: Array<{
    type: 'function';
    function: {
      name: string;
      description: string;
      parameters: Record<string, unknown>;
    };
  }>;
  tool_choice?: 'auto' | 'required' | 'none' | string;
  parallel_tool_calls?: boolean;
  attachment?: string | string[]; // Thaura-style simplified attachments
  attachments?: string | string[]; // Alternative name
  response_format?: {
    type: 'text' | 'json_object';
  };
}

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

function getProviderFromModel(model: string): AIProvider {
  if (model.includes('thaura')) return 'thaura';
  if (model.includes('gpt') || model.includes('o1') || model.includes('o3')) return 'openai';
  if (model.includes('claude')) return 'anthropic';
  if (model.includes('llama') || model.includes('local')) return 'local';
  return 'thaura'; // Default to Thaura
}

function determineAttachmentType(mimeType: string): MediaType {
  if (mimeType.startsWith('image/')) return 'image';
  if (mimeType.startsWith('video/')) return 'video';
  if (mimeType.startsWith('audio/')) return 'audio';
  if (mimeType === 'application/pdf') return 'pdf';
  return 'document';
}

async function processAttachments(
  attachments: string | string[] | undefined
): Promise<FileAttachment[]> {
  if (!attachments) return [];

  const attachmentArray = Array.isArray(attachments) ? attachments : [attachments];
  const processed: FileAttachment[] = [];

  for (const data of attachmentArray) {
    // Simple base64 detection
    if (data.startsWith('data:')) {
      const [header, base64] = data.split(',');
      const mimeType = header.match(/data:([^;]+)/)?.[1] || 'application/octet-stream';
      processed.push({
        type: determineAttachmentType(mimeType),
        mimeType,
        data: base64,
      });
    } else {
      // Assume raw base64 with unknown type
      processed.push({
        type: 'document',
        mimeType: 'application/octet-stream',
        data,
      });
    }
  }

  return processed;
}

// ============================================================================
// MAIN HANDLER
// ============================================================================

export async function POST(request: NextRequest) {
  const startTime = Date.now();
  const requestId = `req-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

  try {
    // Parse request body
    const body: ChatCompletionRequest = await request.json();

    // Validate required fields
    if (!body.messages || !Array.isArray(body.messages)) {
      return NextResponse.json(
        { error: 'messages field is required and must be an array' },
        { status: 400 }
      );
    }

    // Get provider
    const model = body.model || 'thaura';
    const provider = getProviderFromModel(model);

    // Process attachments if present
    const attachments = await processAttachments(
      body.attachment || body.attachments
    );

    // Get AI provider manager
    const aiManager = getExternalAIProviderManager();

    // Check for function calls
    if (body.tools && body.tools.length > 0) {
      // Handle function calling
      const lastMessage = body.messages[body.messages.length - 1];
      const functionExecutor = getFunctionCallingExecutor();

      // Find relevant detection functions
      const relevantTools = body.tools.filter((tool) =>
        tool.function.name.includes('analyze') ||
        tool.function.name.includes('detect') ||
        tool.function.name.includes('verify')
      );

      if (relevantTools.length > 0) {
        // Execute detection functions
        const functionResults = [];

        for (const tool of relevantTools) {
          try {
            const result = await executeDetectionFunction(
              tool.function.name,
              lastMessage.content ? { text: lastMessage.content } : {}
            );

            if (result.success) {
              functionResults.push({
                name: tool.function.name,
                result: result.result,
              });
            }
          } catch (error) {
            console.error(`Function ${tool.function.name} failed:`, error);
          }
        }

        // Generate response based on function results
        const responseContent = generateFunctionResponse(functionResults);

        return NextResponse.json({
          id: `chatcmpl-${Date.now()}`,
          object: 'chat.completion',
          created: Math.floor(Date.now() / 1000),
          model,
          choices: [
            {
              index: 0,
              message: {
                role: 'assistant',
                content: responseContent,
                tool_calls: functionResults.map((r, i) => ({
                  id: `call-${i}`,
                  type: 'function',
                  function: {
                    name: r.name,
                    arguments: JSON.stringify(r.result),
                  },
                })),
              },
              finish_reason: 'tool_calls',
            },
          ],
          usage: {
            prompt_tokens: 100,
            completion_tokens: 200,
            total_tokens: 300,
          },
        });
      }
    }

    // Standard chat completion
    const completionRequest = {
      messages: body.messages,
      model,
      temperature: body.temperature ?? 0.7,
      maxTokens: body.max_tokens ?? 4096,
      stream: body.stream ?? false,
      streamOptions: body.stream_options,
      attachments,
      responseFormat: body.response_format,
    };

    // Handle streaming
    if (body.stream) {
      // Return SSE stream
      const encoder = new TextEncoder();
      const stream = new ReadableStream({
        async start(controller) {
          try {
            for await (const chunk of aiManager.createStreamingCompletion(
              provider,
              completionRequest
            )) {
              const data = `data: ${JSON.stringify(chunk)}\n\n`;
              controller.enqueue(encoder.encode(data));
            }
            controller.enqueue(encoder.encode('data: [DONE]\n\n'));
            controller.close();
          } catch (error) {
            controller.error(error);
          }
        },
      });

      return new Response(stream, {
        headers: {
          'Content-Type': 'text/event-stream',
          'Cache-Control': 'no-cache',
          'Connection': 'keep-alive',
        },
      });
    }

    // Non-streaming response
    const completion = await aiManager.createCompletion(provider, completionRequest);

    // Add ethical score if available
    const ethicsVerifier = getEthicalAIVerifier();
    const ethicalVerification = await ethicsVerifier.verifyProvider(
      provider,
      provider.toUpperCase(),
      {}
    );

    const response = {
      id: completion.id,
      object: completion.object,
      created: completion.created,
      model: completion.model,
      choices: completion.choices.map((choice) => ({
        index: choice.index,
        message: choice.message,
        finish_reason: choice.finishReason,
      })),
      usage: {
        prompt_tokens: completion.usage.promptTokens,
        completion_tokens: completion.usage.completionTokens,
        total_tokens: completion.usage.totalTokens,
      },
      ethical_score: ethicalVerification.overallScore,
      privacy_first: provider === 'thaura' || provider === 'local',
      processing_time_ms: Date.now() - startTime,
    };

    return NextResponse.json(response);
  } catch (error) {
    console.error('Chat completion error:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Internal server error' },
      { status: 500 }
    );
  }
}

// ============================================================================
// ADDITIONAL ENDPOINTS
// ============================================================================

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const action = searchParams.get('action');

  const gateway = getAPIGateway();
  const aiManager = getExternalAIProviderManager();

  switch (action) {
    case 'models':
      // List available models
      return NextResponse.json({
        object: 'list',
        data: [
          {
            id: 'thaura',
            object: 'model',
            created: 1700000000,
            owned_by: 'thaura',
            permission: [],
            root: 'thaura',
            parent: null,
            ethical: true,
            privacy_first: true,
            no_training: true,
          },
          {
            id: 'thaura-vision',
            object: 'model',
            created: 1700000000,
            owned_by: 'thaura',
            permission: [],
            root: 'thaura',
            parent: 'thaura',
            ethical: true,
            privacy_first: true,
            capabilities: ['chat', 'vision'],
          },
          {
            id: 'thaura-deepfake',
            object: 'model',
            created: 1700000000,
            owned_by: 'kasbah',
            permission: [],
            root: 'kasbah',
            parent: null,
            ethical: true,
            privacy_first: true,
            capabilities: ['deepfake_detection', 'forensics', 'analysis'],
          },
        ],
      });

    case 'health':
      // Health check
      const providerHealth = await Promise.all([
        aiManager.checkProviderHealth('thaura'),
        aiManager.checkProviderHealth('openai'),
        aiManager.checkProviderHealth('anthropic'),
        aiManager.checkProviderHealth('local'),
      ]);

      return NextResponse.json({
        status: 'healthy',
        timestamp: new Date().toISOString(),
        providers: providerHealth.reduce((acc, h) => {
          acc[h.provider] = {
            status: h.status,
            latency: h.latency,
            success_rate: h.successRate,
          };
          return acc;
        }, {} as Record<string, unknown>),
        gateway: gateway.getMetrics(),
      });

    case 'metrics':
      // Gateway metrics
      return NextResponse.json(gateway.getMetrics());

    case 'functions':
      // List available detection functions
      const functionExecutor = getFunctionCallingExecutor();
      return NextResponse.json({
        object: 'list',
        data: functionExecutor.getAllFunctionDefinitions().map((fn) => ({
          name: fn.name,
          description: fn.description,
          category: fn.category,
          priority: fn.priority,
          parameters: fn.parameters,
        })),
      });

    case 'ethics':
      // Ethical verification
      const ethicsVerifier = getEthicalAIVerifier();
      const provider = (searchParams.get('provider') || 'thaura') as AIProvider;

      const ethicalReport = await ethicsVerifier.verifyProvider(
        provider,
        provider.toUpperCase(),
        {}
      );

      return NextResponse.json({
        provider,
        overall_score: ethicalReport.overallScore,
        compliance_level: ethicalReport.complianceLevel,
        is_compliant: ethicalReport.isCompliant,
        category_scores: ethicalReport.categoryScores,
        critical_issues: ethicalReport.criticalIssues.length,
      });

    default:
      return NextResponse.json({
        name: 'Kasbah Deepfake Detection API',
        version: '1.0.0',
        description: 'Ethical AI-powered deepfake detection with Thaura.ai compatibility',
        endpoints: {
          'POST /api/thaura/v1': 'Chat completions with optional function calling',
          'GET /api/thaura/v1?action=models': 'List available models',
          'GET /api/thaura/v1?action=health': 'Health check',
          'GET /api/thaura/v1?action=metrics': 'Gateway metrics',
          'GET /api/thaura/v1?action=functions': 'List detection functions',
          'GET /api/thaura/v1?action=ethics': 'Ethical verification',
        },
        features: [
          'Multi-provider support (Thaura, OpenAI, Anthropic, Local)',
          'Multi-modal attachment processing',
          'Function calling for deepfake detection',
          'Ethical AI verification',
          'Privacy-first design',
          'No training on user data',
        ],
      });
  }
}

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

function generateFunctionResponse(
  results: Array<{ name: string; result: unknown }>
): string {
  if (results.length === 0) {
    return 'No detection functions were executed.';
  }

  const summaries = results.map((r) => {
    const result = r.result as Record<string, unknown>;
    const score = result?.confidence || result?.score || 0;
    const isDeepfake = result?.isDeepfake || result?.isManipulated || result?.isSynthetic;

    return `- ${r.name}: ${isDeepfake ? 'Potential deepfake detected' : 'No deepfake detected'} (confidence: ${(score * 100).toFixed(1)}%)`;
  });

  return `Deepfake Analysis Results:\n\n${summaries.join('\n')}\n\nRecommendation: ${results.some((r) => (r.result as Record<string, unknown>)?.isDeepfake) ? 'Further investigation recommended' : 'Content appears authentic'}`;
}
