import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import ZAI from 'z-ai-web-dev-sdk'
import {
  validateFile,
  sanitizeFilename,
  MAX_FILE_SIZE,
} from '@/lib/validation'
import {
  detectionLimiter,
  getClientIdentifier,
  createRateLimitHeaders,
} from '@/lib/rate-limiter'
import {
  createLogger,
  generateRequestId,
  logRequest,
  logResponse,
} from '@/lib/logger'
import {
  vlmCircuitBreaker,
  withTimeout,
} from '@/lib/retry'
import {
  ValidationError,
  FileValidationError,
  RateLimitError,
  AIServiceError,
} from '@/lib/errors'

const IMAGE_DETECTION_PROMPT = `You are an expert deepfake detection AI specializing in identifying AI-generated or manipulated images. Analyze this image for signs of deepfake manipulation.

Examine these specific aspects thoroughly:
1. FACIAL FEATURES: Check for unnatural skin textures, inconsistent lighting on face, blurred edges around face, asymmetrical features
2. EYE DETAILS: Look for asymmetric blinking patterns, unusual eye reflections, mismatched eye directions, artificial-looking pupils
3. ARTIFACTS: Identify compression artifacts, unusual blur patterns, edge inconsistencies, color banding
4. LIGHTING & SHADOWS: Verify consistent lighting sources and natural shadow directions
5. BACKGROUND CONSISTENCY: Check for unusual background blurring or inconsistencies near the subject
6. HAIR & EDGE DETAILS: Look for unnatural hair strands, edge artifacts around the head, floating hair elements
7. SKIN TEXTURE: Check for overly smooth skin, unusual pore patterns, or artificial texture

Respond ONLY with valid JSON in this exact format:
{
  "result": "authentic" | "deepfake" | "uncertain",
  "confidence": 0.0-1.0,
  "analysis": "Detailed explanation of findings (2-4 sentences)",
  "indicators": ["specific indicator 1", "specific indicator 2", ...]
}`

const VLM_TIMEOUT_MS = 60000
const DB_TIMEOUT_MS = 5000

function getMediaType(mimeType: string): 'image' | 'video' | 'audio' {
  if (mimeType.startsWith('image/')) return 'image'
  if (mimeType.startsWith('video/')) return 'video'
  if (mimeType.startsWith('audio/')) return 'audio'
  return 'image'
}

function parseDetectionResult(content: string) {
  try {
    const jsonMatch = content.match(/\{[\s\S]*?\}/)
    if (!jsonMatch) {
      throw new Error('No valid JSON found in response')
    }
    const parsed = JSON.parse(jsonMatch[0])
    const validResults = ['authentic', 'deepfake', 'uncertain'] as const
    const result = validResults.includes(parsed.result) ? parsed.result : 'uncertain'
    let confidence = parseFloat(parsed.confidence)
    if (isNaN(confidence)) confidence = 0.5
    confidence = Math.max(0, Math.min(1, confidence))
    let analysis = String(parsed.analysis || 'Analysis not available')
    if (analysis.length > 2000) analysis = analysis.slice(0, 2000) + '...'
    let indicators: string[] = []
    if (Array.isArray(parsed.indicators)) {
      indicators = parsed.indicators
        .filter((i: unknown): i is string => typeof i === 'string')
        .map((i: string) => i.slice(0, 100))
        .slice(0, 15)
    }
    return { result, confidence, analysis, indicators }
  } catch {
    return {
      result: 'uncertain' as const,
      confidence: 0.5,
      analysis: 'Unable to complete full analysis. The detection system encountered an unexpected response format.',
      indicators: ['Analysis incomplete - manual review recommended']
    }
  }
}

// Handle POST for share target
export async function POST(request: NextRequest) {
  const requestId = generateRequestId()
  const logger = createLogger('share', requestId)
  const startTime = Date.now()

  try {
    logRequest('POST', '/api/share', requestId)

    const clientId = getClientIdentifier(request)
    const rateLimitResult = detectionLimiter.check(clientId)
    
    if (!rateLimitResult.allowed) {
      throw new RateLimitError(rateLimitResult.retryAfter || 60)
    }

    let formData: FormData
    try {
      formData = await request.formData()
    } catch {
      throw new ValidationError('Failed to parse request body. Ensure Content-Type is multipart/form-data.')
    }

    const file = formData.get('file') as File | null
    if (!file) {
      throw new ValidationError('No file provided.')
    }

    const sanitizedFilename = sanitizeFilename(file.name)

    if (file.size > MAX_FILE_SIZE) {
      throw new FileValidationError(
        `File size (${(file.size / (1024 * 1024)).toFixed(2)}MB) exceeds maximum allowed size`,
        'FILE_TOO_LARGE'
      )
    }

    if (file.size < 100) {
      throw new FileValidationError('File is too small or may be corrupted', 'FILE_TOO_SMALL')
    }

    const arrayBuffer = await file.arrayBuffer()
    const buffer = Buffer.from(arrayBuffer)

    const validationResult = validateFile(file, buffer)
    if (!validationResult.valid) {
      throw new FileValidationError(
        validationResult.error || 'File validation failed',
        validationResult.code || 'VALIDATION_ERROR'
      )
    }

    const mediaType = getMediaType(file.type)
    const base64Data = buffer.toString('base64')
    const dataUrl = `data:${file.type};base64,${base64Data}`

    logger.info('Starting shared file analysis', { 
      mediaType, 
      filename: sanitizedFilename,
      fileSize: file.size 
    })

    let vlmResponse: string
    
    try {
      vlmResponse = await vlmCircuitBreaker.execute(async () => {
        const zai = await ZAI.create()
        const content = [
          { type: 'text', text: IMAGE_DETECTION_PROMPT },
          { type: 'image_url', image_url: { url: dataUrl } }
        ]
        const response = await withTimeout(
          async () => zai.chat.completions.createVision({
            messages: [{ role: 'user', content }],
            thinking: { type: 'disabled' }
          }),
          VLM_TIMEOUT_MS,
          'Analysis timed out'
        )
        return response.choices[0]?.message?.content || ''
      })
    } catch (error) {
      throw new AIServiceError(
        'Failed to analyze file. The AI service is temporarily unavailable.',
        { error: error instanceof Error ? error.message : 'Unknown error' }
      )
    }

    const detection = parseDetectionResult(vlmResponse)

    let savedDetection
    try {
      savedDetection = await withTimeout(
        async () => db.detection.create({
          data: {
            mediaType,
            fileName: sanitizedFilename,
            fileSize: file.size,
            result: detection.result,
            confidence: detection.confidence,
            analysis: detection.analysis,
            indicators: JSON.stringify(detection.indicators)
          }
        }),
        DB_TIMEOUT_MS,
        'Database operation timed out'
      )
    } catch (error) {
      logger.error('Failed to save detection to database', error instanceof Error ? error : undefined)
    }

    const duration = Date.now() - startTime
    logResponse('POST', '/api/share', 200, duration, requestId)

    logger.info('Shared file analysis completed', {
      result: detection.result,
      confidence: detection.confidence,
      duration
    })

    const headers = createRateLimitHeaders(rateLimitResult)
    headers.set('X-Request-ID', requestId)
    headers.set('X-Response-Time', `${duration}ms`)

    // Redirect back to home with result
    const redirectUrl = new URL('/', request.url)
    return NextResponse.redirect(redirectUrl.toString(), 302)
  } catch (error) {
    const duration = Date.now() - startTime
    logResponse('POST', '/api/share', 500, duration, requestId)
    
    logger.error('Share analysis failed', error instanceof Error ? error : undefined)
    
    // Redirect back to home with error
    const redirectUrl = new URL('/?error=analysis_failed', request.url)
    return NextResponse.redirect(redirectUrl.toString(), 302)
  }
}
