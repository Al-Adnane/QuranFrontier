import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

import {
  readLimiter,
  getClientIdentifier,
  createRateLimitHeaders,
} from '@/lib/rate-limiter'

import {
  createLogger,
  generateRequestId,
  logRequest,
  logResponse,
} from '@/lib/logger'

import {
  AppError,
  RateLimitError,
  DatabaseError,
  handleError,
  createErrorResponse,
} from '@/lib/errors'

import {
  withTimeout,
} from '@/lib/retry'

const DB_TIMEOUT_MS = 5000
const MAX_RESULTS = 50

const logger = createLogger('api')

export async function GET(request: NextRequest) {
  const requestId = generateRequestId()
  const startTime = Date.now()

  try {
    logRequest('GET', '/api/detections', requestId)

    // Rate limiting
    const clientId = getClientIdentifier(request)
    const rateLimitResult = readLimiter.check(clientId)

    if (!rateLimitResult.allowed) {
      throw new RateLimitError(rateLimitResult.retryAfter || 60)
    }

    // Parse query parameters with validation
    const { searchParams } = new URL(request.url)
    const limitParam = searchParams.get('limit')
    const offsetParam = searchParams.get('offset')

    // Validate and sanitize parameters
    let limit = 20
    let offset = 0

    if (limitParam) {
      const parsedLimit = parseInt(limitParam, 10)
      if (!isNaN(parsedLimit) && parsedLimit > 0 && parsedLimit <= MAX_RESULTS) {
        limit = parsedLimit
      }
    }

    if (offsetParam) {
      const parsedOffset = parseInt(offsetParam, 10)
      if (!isNaN(parsedOffset) && parsedOffset >= 0) {
        offset = parsedOffset
      }
    }

    // Fetch detections with timeout
    let detections
    try {
      detections = await withTimeout(
        async () => db.detection.findMany({
          orderBy: { createdAt: 'desc' },
          take: limit,
          skip: offset,
          select: {
            id: true,
            mediaType: true,
            fileName: true,
            fileSize: true,
            result: true,
            confidence: true,
            analysis: true,
            indicators: true,
            createdAt: true
          }
        }),
        DB_TIMEOUT_MS,
        'Database query timed out'
      )
    } catch (error) {
      throw new DatabaseError('Failed to fetch detection history', {
        error: error instanceof Error ? error.message : 'Unknown error'
      })
    }

    // Sanitize response data
    const sanitizedDetections = detections.map(d => ({
      id: d.id,
      mediaType: d.mediaType,
      fileName: d.fileName.slice(0, 255), // Limit filename length
      fileSize: d.fileSize,
      result: d.result,
      confidence: Math.round(d.confidence * 1000) / 1000, // 3 decimal places
      analysis: d.analysis.slice(0, 2000), // Limit analysis length
      indicators: d.indicators,
      createdAt: d.createdAt.toISOString()
    }))

    const duration = Date.now() - startTime
    logResponse('GET', '/api/detections', 200, duration, requestId)

    logger.debug('Fetched detections', {
      count: sanitizedDetections.length,
      limit,
      offset,
      duration
    })

    // Build response headers
    const headers = createRateLimitHeaders(rateLimitResult)
    headers.set('X-Request-ID', requestId)
    headers.set('X-Response-Time', `${duration}ms`)

    return NextResponse.json({
      success: true,
      detections: sanitizedDetections,
      pagination: {
        limit,
        offset,
        count: sanitizedDetections.length
      }
    }, { headers })

  } catch (error) {
    const duration = Date.now() - startTime
    const appError = handleError(error)

    logResponse('GET', '/api/detections', appError.statusCode, duration, requestId)

    logger.error(
      'Failed to fetch detections',
      appError instanceof AppError ? appError : undefined,
      { duration }
    )

    const errorResponse = createErrorResponse(error)
    const headers = new Headers()
    headers.set('X-Request-ID', requestId)
    headers.set('X-Response-Time', `${duration}ms`)

    if (appError instanceof RateLimitError) {
      headers.set('Retry-After', appError.retryAfter.toString())
    }

    return NextResponse.json(errorResponse, {
      status: appError.statusCode,
      headers
    })
  }
}

// Handle unsupported methods
export async function POST() {
  return NextResponse.json(
    { success: false, error: 'Method not allowed. Use GET to fetch detection history.' },
    { status: 405 }
  )
}
