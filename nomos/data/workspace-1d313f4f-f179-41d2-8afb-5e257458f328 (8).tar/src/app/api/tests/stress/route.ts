import { NextRequest, NextResponse } from 'next/server'
import { runAllStressTests, printTestReport } from '@/lib/security/stress-tests'

/**
 * GET /api/tests/stress
 * Run comprehensive stress tests and return results
 */
export async function GET(request: NextRequest) {
  try {
    // In development mode, allow running tests
    const isDev = process.env.NODE_ENV === 'development'
    
    if (!isDev) {
      // In production, require auth token
      const authHeader = request.headers.get('authorization')
      const expectedToken = process.env.ADMIN_TOKEN
      
      if (!expectedToken || authHeader !== `Bearer ${expectedToken}`) {
        return NextResponse.json(
          { success: false, error: 'Unauthorized' },
          { status: 401 }
        )
      }
    }
    
    // Run all stress tests
    const report = runAllStressTests()
    
    const format = request.nextUrl.searchParams.get('format')
    
    if (format === 'text') {
      return new NextResponse(printTestReport(report), {
        headers: {
          'Content-Type': 'text/plain; charset=utf-8'
        }
      })
    }
    
    return NextResponse.json({
      success: true,
      report
    })
  } catch (error) {
    console.error('Stress test error:', error)
    return NextResponse.json(
      { 
        success: false, 
        error: error instanceof Error ? error.message : 'Stress test failed' 
      },
      { status: 500 }
    )
  }
}
