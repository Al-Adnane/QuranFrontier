import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import ZAI from 'z-ai-web-dev-sdk'

import {
  validateFile,
  sanitizeFilename,
  validateAnalysisResult,
  MAX_FILE_SIZE,
} from '@/lib/validation'

import {
  detectionLimiter,
  getClientIdentifier,
  createRateLimitHeaders,
} from '@/lib/rate-limiter'

import {
  createLogger,
  generateRequestId,
  logRequest,
  logResponse,
} from '@/lib/logger'

import {
  withRetry,
  withTimeout,
  vlmCircuitBreaker,
} from '@/lib/retry'

import {
  AppError,
  ValidationError,
  FileValidationError,
  RateLimitError,
  AIServiceError,
  DatabaseError,
  TimeoutError,
  CircuitBreakerError,
  handleError,
  createErrorResponse,
} from '@/lib/errors'

// Moats - Security Enhancement Layers
import { 
  detectAdversarialPatterns,
  type EvasionDetectionResult 
} from '@/lib/security/adversarial-detection'
import { 
  addAuditEntry, 
  verifyLedgerIntegrity 
} from '@/lib/moats/audit-ledger'
import { 
  recordIndicatorUsage, 
  isDetectionReliable,
  calculateSystemBrittleness 
} from '@/lib/moats/brittleness'
import { 
  recordThreatEvent, 
  getCurrentThresholdConfig,
  shouldBlockAction 
} from '@/lib/moats/dynamic-thresholds'

// Detection prompts (enterprise-grade)
const IMAGE_DETECTION_PROMPT = `You are an expert deepfake detection AI specializing in identifying AI-generated or manipulated images. Analyze this image for signs of deepfake manipulation.

Examine these specific aspects thoroughly:
1. FACIAL FEATURES: Check for unnatural skin textures, inconsistent lighting on face, blurred edges around face, asymmetrical features
2. EYE DETAILS: Look for asymmetric blinking patterns, unusual eye reflections, mismatched eye directions, artificial-looking pupils
3. ARTIFACTS: Identify compression artifacts, unusual blur patterns, edge inconsistencies, color banding
4. LIGHTING & SHADOWS: Verify consistent lighting sources and natural shadow directions
5. BACKGROUND CONSISTENCY: Check for unusual background blurring or inconsistencies near the subject
6. HAIR & EDGE DETAILS: Look for unnatural hair strands, edge artifacts around the head, floating hair elements
7. SKIN TEXTURE: Check for overly smooth skin, unusual pore patterns, or artificial texture

Respond ONLY with valid JSON in this exact format:
{
  "result": "authentic" | "deepfake" | "uncertain",
  "confidence": 0.0-1.0,
  "analysis": "Detailed explanation of findings (2-4 sentences)",
  "indicators": ["specific indicator 1", "specific indicator 2", ...]
}`

const VIDEO_DETECTION_PROMPT = `You are an expert deepfake detection AI specializing in identifying AI-generated or manipulated videos. Analyze this video for signs of deepfake manipulation.

Examine these specific aspects thoroughly:
1. FACIAL MOTION: Look for unnatural facial movements, lip-sync inconsistencies, rigid expressions, delayed reactions
2. EYE MOVEMENTS: Check for unusual blinking patterns, inconsistent gaze directions, unnatural eye motion
3. FRAME CONSISTENCY: Look for flickering artifacts between frames, morphing issues, temporal coherence problems
4. HEAD POSE: Verify natural head movements and consistent head proportions throughout
5. AUDIO-VISUAL SYNC: If audio is present, check lip movement synchronization
6. TEMPORAL ARTIFACTS: Look for jitter, unnatural transitions, frame blending issues
7. EDGE CONSISTENCY: Check for artifacts around the face that appear/disappear across frames

Respond ONLY with valid JSON in this exact format:
{
  "result": "authentic" | "deepfake" | "uncertain",
  "confidence": 0.0-1.0,
  "analysis": "Detailed explanation of findings (2-4 sentences)",
  "indicators": ["specific indicator 1", "specific indicator 2", ...]
}`

const AUDIO_DETECTION_PROMPT = `You are an expert deepfake detection AI specializing in identifying AI-generated or synthetic audio. 

Analyze this audio file metadata for potential deepfake indicators:
- File name: {filename}
- File type: {filetype}
- File size: {filesize} bytes

Consider these indicators of synthetic audio:
1. UNNATURAL PAUSES: AI-generated speech often has unnatural pauses or rhythm
2. VOICE CONSISTENCY: Check for sudden changes in voice characteristics
3. BACKGROUND PATTERNS: Identify unusual background noise patterns typical of synthetic audio
4. BREATHING SOUNDS: Natural speech includes breathing - absence is suspicious
5. EMOTIONAL CONSISTENCY: Voice should match expected emotional context
6. DIGITAL ARTIFACTS: Listen for metallic sounds, glitches, or audio discontinuities

Respond ONLY with valid JSON in this exact format:
{
  "result": "authentic" | "deepfake" | "uncertain",
  "confidence": 0.0-1.0,
  "analysis": "Detailed explanation of findings based on available metadata (2-4 sentences)",
  "indicators": ["specific indicator 1", "specific indicator 2", ...]
}

Note: For definitive audio analysis, specialized audio forensics tools are recommended.`

// Timeouts
const VLM_TIMEOUT_MS = 60000 // 60 seconds for images
const VLM_VIDEO_TIMEOUT_MS = 120000 // 120 seconds for videos
const DB_TIMEOUT_MS = 5000   // 5 seconds

// Video file size limit (larger videos may timeout)
const MAX_VIDEO_SIZE = 50 * 1024 * 1024 // 50MB for videos

// Confidence thresholds
const MIN_CONFIDENCE = 0.0
const MAX_CONFIDENCE = 1.0

function getMediaType(mimeType: string): 'image' | 'video' | 'audio' {
  if (mimeType.startsWith('image/')) return 'image'
  if (mimeType.startsWith('video/')) return 'video'
  if (mimeType.startsWith('audio/')) return 'audio'
  return 'image'
}

function parseDetectionResult(content: string): {
  result: 'authentic' | 'deepfake' | 'uncertain'
  confidence: number
  analysis: string
  indicators: string[]
} {
  try {
    // Extract JSON from response
    const jsonMatch = content.match(/\{[\s\S]*?\}/)
    if (!jsonMatch) {
      throw new Error('No valid JSON found in response')
    }

    let parsed
    try {
      parsed = JSON.parse(jsonMatch[0])
    } catch {
      throw new Error('Failed to parse JSON response')
    }

    // Validate result field
    const validResults = ['authentic', 'deepfake', 'uncertain'] as const
    const result = validResults.includes(parsed.result) 
      ? parsed.result 
      : 'uncertain'

    // Validate and clamp confidence
    let confidence = parseFloat(parsed.confidence)
    if (isNaN(confidence)) confidence = 0.5
    confidence = Math.max(MIN_CONFIDENCE, Math.min(MAX_CONFIDENCE, confidence))

    // Validate analysis
    let analysis = String(parsed.analysis || 'Analysis not available')
    if (analysis.length > 2000) {
      analysis = analysis.slice(0, 2000) + '...'
    }

    // Validate indicators
    let indicators: string[] = []
    if (Array.isArray(parsed.indicators)) {
      indicators = parsed.indicators
        .filter((i: unknown): i is string => typeof i === 'string')
        .map((i: string) => i.slice(0, 100))
        .slice(0, 15)
    }

    return { result, confidence, analysis, indicators }
  } catch (error) {
    // Default fallback for parsing errors
    return {
      result: 'uncertain',
      confidence: 0.5,
      analysis: 'Unable to complete full analysis. The detection system encountered an unexpected response format.',
      indicators: ['Analysis incomplete - manual review recommended']
    }
  }
}

export async function POST(request: NextRequest) {
  const requestId = generateRequestId()
  const logger = createLogger('detection', requestId)
  const startTime = Date.now()
  
  let method = 'POST'
  let path = '/api/detect'

  try {
    // Log incoming request
    logRequest('POST', '/api/detect', requestId)

    // Rate limiting
    const clientId = getClientIdentifier(request)
    const rateLimitResult = detectionLimiter.check(clientId)
    
    if (!rateLimitResult.allowed) {
      logger.warn('Rate limit exceeded', { clientId, remaining: rateLimitResult.remaining })
      throw new RateLimitError(rateLimitResult.retryAfter || 60)
    }

    // Parse form data with size limit
    let formData: FormData
    try {
      formData = await request.formData()
    } catch (error) {
      throw new ValidationError('Failed to parse request body. Ensure Content-Type is multipart/form-data.')
    }

    const file = formData.get('file') as File | null

    // File presence validation
    if (!file) {
      throw new ValidationError('No file provided. Please upload a file for analysis.')
    }

    // Sanitize filename
    const sanitizedFilename = sanitizeFilename(file.name)
    if (sanitizedFilename !== file.name) {
      logger.warn('Filename was sanitized', { 
        original: file.name.slice(0, 100), 
        sanitized: sanitizedFilename.slice(0, 100) 
      })
    }

    // Validate file size (pre-buffer check)
    if (file.size > MAX_FILE_SIZE) {
      throw new FileValidationError(
        `File size (${(file.size / (1024 * 1024)).toFixed(2)}MB) exceeds maximum allowed size (${MAX_FILE_SIZE / (1024 * 1024)}MB)`,
        'FILE_TOO_LARGE'
      )
    }

    if (file.size < 100) {
      throw new FileValidationError(
        'File is too small or may be corrupted',
        'FILE_TOO_SMALL'
      )
    }

    // Read file buffer
    let buffer: Buffer
    try {
      const arrayBuffer = await file.arrayBuffer()
      buffer = Buffer.from(arrayBuffer)
    } catch (error) {
      throw new FileValidationError(
        'Failed to read file. The file may be corrupted.',
        'FILE_READ_ERROR'
      )
    }

    // Comprehensive file validation
    const validationResult = validateFile(file, buffer)
    if (!validationResult.valid) {
      logger.warn('File validation failed', { 
        filename: sanitizedFilename,
        error: validationResult.error,
        code: validationResult.code 
      })
      throw new FileValidationError(
        validationResult.error || 'File validation failed',
        validationResult.code || 'VALIDATION_ERROR'
      )
    }

    // Log warnings if any
    if (validationResult.warnings && validationResult.warnings.length > 0) {
      logger.warn('File validation warnings', { warnings: validationResult.warnings })
      // Record suspicious pattern for dynamic threshold
      recordThreatEvent('suspicious_pattern')
    }

    const mediaType = getMediaType(file.type)
    const base64Data = buffer.toString('base64')
    const dataUrl = `data:${file.type};base64,${base64Data}`

    // === MOAT 5: Dynamic Threshold Check ===
    // Check if action should be blocked based on current threat level
    const thresholdConfig = getCurrentThresholdConfig()
    const blockCheck = shouldBlockAction('upload', {
      fileSize: file.size,
      suspiciousPatterns: validationResult.warnings
    })
    
    if (blockCheck.blocked) {
      logger.warn('Action blocked by dynamic threshold', { 
        reason: blockCheck.reason,
        threatLevel: thresholdConfig.baseConfidenceThreshold
      })
      addAuditEntry('BLOCK', sanitizedFilename, 'BLOCKED', { 
        reason: blockCheck.reason,
        threshold: thresholdConfig.baseConfidenceThreshold 
      })
      throw new FileValidationError(
        blockCheck.reason || 'Request blocked due to elevated threat level',
        'THRESHOLD_BLOCK'
      )
    }

    // Check video size and warn if too large
    if (mediaType === 'video' && file.size > MAX_VIDEO_SIZE) {
      logger.warn('Video file is large, analysis may take longer', {
        fileSize: file.size,
        maxSize: MAX_VIDEO_SIZE
      })
    }

    // === MOAT 7: Audit Ledger Entry ===
    addAuditEntry('DETECT', sanitizedFilename, 'SUCCESS', {
      mediaType,
      fileSize: file.size,
      threshold: thresholdConfig.baseConfidenceThreshold
    })

    logger.info('Starting analysis', { 
      mediaType, 
      filename: sanitizedFilename,
      fileSize: file.size,
      threatThreshold: thresholdConfig.baseConfidenceThreshold
    })

    // Initialize VLM with circuit breaker and timeout
    let vlmResponse: string
    
    // Use longer timeout for videos
    const timeoutMs = mediaType === 'video' ? VLM_VIDEO_TIMEOUT_MS : VLM_TIMEOUT_MS
    
    try {
      vlmResponse = await vlmCircuitBreaker.execute(async () => {
        const zai = await ZAI.create()

        // Build content based on media type
        let content: Array<{ type: string; text?: string; image_url?: { url: string }; video_url?: { url: string } }>
        
        if (mediaType === 'image') {
          content = [
            { type: 'text', text: IMAGE_DETECTION_PROMPT },
            { type: 'image_url', image_url: { url: dataUrl } }
          ]
        } else if (mediaType === 'video') {
          content = [
            { type: 'text', text: VIDEO_DETECTION_PROMPT },
            { type: 'video_url', video_url: { url: dataUrl } }
          ]
        } else {
          // Audio - use metadata-based analysis
          const audioPrompt = AUDIO_DETECTION_PROMPT
            .replace('{filename}', sanitizedFilename)
            .replace('{filetype}', file.type)
            .replace('{filesize}', file.size.toString())
          
          content = [
            { type: 'text', text: audioPrompt }
          ]
        }

        // Call VLM with appropriate timeout
        const response = await withTimeout(
          async () => zai.chat.completions.createVision({
            messages: [{ role: 'user', content }],
            thinking: { type: 'disabled' }
          }),
          timeoutMs,
          'Analysis timed out'
        )

        return response.choices[0]?.message?.content || ''
      })
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error'
      logger.error('VLM analysis failed', error instanceof Error ? error : undefined, {
        mediaType,
        timeoutMs,
        fileSize: file.size
      })
      
      if (errorMessage.includes('Circuit breaker')) {
        throw new CircuitBreakerError('VLM Service', 60000)
      }
      
      // Provide more specific error messages
      if (errorMessage.includes('timeout') || errorMessage.includes('ETIMEDOUT')) {
        throw new AIServiceError(
          mediaType === 'video' 
            ? 'Video analysis timed out. Please try with a shorter video (under 30 seconds) or smaller file size.'
            : 'Analysis timed out. Please try with a smaller file.',
          { error: errorMessage, mediaType }
        )
      }
      
      throw new AIServiceError(
        'Failed to analyze file. The AI service is temporarily unavailable.',
        { error: errorMessage }
      )
    }

    // Parse detection result
    const detection = parseDetectionResult(vlmResponse)

    // Validate parsed result
    const resultValidation = validateAnalysisResult(detection)
    if (!resultValidation.valid) {
      logger.warn('Detection result validation failed', { 
        error: resultValidation.error 
      })
      // Use parsed result anyway but log the issue
    }

    // === MOAT 8: Adversarial Pattern Detection ===
    // Check for evasion attempts in the analysis
    const adversarialCheck = detectAdversarialPatterns(
      sanitizedFilename,
      detection.analysis,
      { indicators: detection.indicators, confidence: detection.confidence }
    )
    
    if (adversarialCheck.isEvasive) {
      logger.warn('Adversarial patterns detected in detection', {
        riskScore: adversarialCheck.riskScore,
        patterns: adversarialCheck.detectedPatterns,
        methods: adversarialCheck.obfuscationMethods
      })
      
      // Add to indicators
      if (adversarialCheck.recommendations.length > 0) {
        detection.indicators.push(...adversarialCheck.recommendations.slice(0, 3))
      }
      
      // Record evasion attempt for threshold modulation
      recordThreatEvent('evasion_attempt')
    }

    // === MOAT 3: Brittleness Tracking ===
    // Record each indicator usage for brittleness calculation
    for (const indicator of detection.indicators) {
      recordIndicatorUsage(indicator)
    }
    
    // Check if detection is reliable based on brittleness
    const reliabilityCheck = isDetectionReliable(detection.indicators)
    if (!reliabilityCheck.reliable) {
      logger.warn('Detection reliability check failed', {
        confidence: reliabilityCheck.confidence,
        reasons: reliabilityCheck.reasons
      })
      
      // Adjust confidence based on reliability
      detection.confidence *= reliabilityCheck.confidence
      
      // Add warning to analysis
      detection.analysis += ` Note: ${reliabilityCheck.reasons.join('; ')}`
    }

    // === MOAT 7: Update Audit Ledger ===
    addAuditEntry('ALLOW', sanitizedFilename, 'SUCCESS', {
      result: detection.result,
      confidence: detection.confidence,
      adversarialRisk: adversarialCheck.riskScore,
      reliability: reliabilityCheck.confidence
    })

    // Save to database with retry and timeout
    let savedDetection
    try {
      savedDetection = await withTimeout(
        async () => db.detection.create({
          data: {
            mediaType,
            fileName: sanitizedFilename,
            fileSize: file.size,
            result: detection.result,
            confidence: detection.confidence,
            analysis: detection.analysis,
            indicators: JSON.stringify(detection.indicators)
          }
        }),
        DB_TIMEOUT_MS,
        'Database operation timed out'
      )
    } catch (error) {
      logger.error('Failed to save detection to database', error instanceof Error ? error : undefined)
      // Continue without saving - return result anyway
      // In production, you might want to queue this for retry
    }

    const duration = Date.now() - startTime
    logResponse('POST', '/api/detect', 200, duration, requestId)

    logger.info('Analysis completed', {
      result: detection.result,
      confidence: detection.confidence,
      duration
    })

    // Build response headers
    const headers = createRateLimitHeaders(rateLimitResult)
    headers.set('X-Request-ID', requestId)
    headers.set('X-Response-Time', `${duration}ms`)

    return NextResponse.json({
      success: true,
      detection: {
        id: savedDetection?.id || `temp_${requestId}`,
        mediaType,
        fileName: sanitizedFilename,
        fileSize: file.size,
        result: detection.result,
        confidence: detection.confidence,
        analysis: detection.analysis,
        indicators: JSON.stringify(detection.indicators),
        createdAt: savedDetection?.createdAt?.toISOString() || new Date().toISOString()
      }
    }, { headers })

  } catch (error) {
    const duration = Date.now() - startTime
    const appError = handleError(error)
    
    logResponse('POST', '/api/detect', appError.statusCode, duration, requestId)
    
    logger.error(
      'Detection failed',
      appError instanceof AppError ? appError : undefined,
      { 
        code: appError.code,
        duration 
      }
    )

    const errorResponse = createErrorResponse(error)
    const headers = new Headers()
    headers.set('X-Request-ID', requestId)
    headers.set('X-Response-Time', `${duration}ms`)

    // Add rate limit headers even on error
    const clientId = getClientIdentifier(request)
    const rateLimitStatus = detectionLimiter.peek(clientId)
    headers.set('X-RateLimit-Remaining', rateLimitStatus.remaining.toString())

    if (appError instanceof RateLimitError) {
      headers.set('Retry-After', appError.retryAfter.toString())
    }

    return NextResponse.json(errorResponse, {
      status: appError.statusCode,
      headers
    })
  }
}

// Handle unsupported methods
export async function GET() {
  return NextResponse.json(
    { success: false, error: 'Method not allowed. Use POST to upload files.' },
    { status: 405 }
  )
}
