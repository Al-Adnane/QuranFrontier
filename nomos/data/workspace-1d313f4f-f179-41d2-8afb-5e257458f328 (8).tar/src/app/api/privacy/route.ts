/**
 * Privacy API Route
 *
 * Exposes all privacy modules through a unified API endpoint.
 * Stanford HAI + IBM AI Privacy inspired implementation.
 */

import { NextRequest, NextResponse } from 'next/server';
import { unifiedPrivacy } from '@/lib/security/privacy-integration';
import { privacyFramework } from '@/lib/security/privacy-first-framework';
import { dataSupplyChain } from '@/lib/security/data-supply-chain';
import { collectivePrivacyManager } from '@/lib/security/collective-privacy-rights';
import { voiceCloneDetector, voiceAnonymizer } from '@/lib/security/voice-privacy-protection';
import { dpEngine } from '@/lib/security/privacy-preserving-analytics';

export async function GET(request: NextRequest) {
  const action = request.nextUrl.searchParams.get('action');
  const userId = request.nextUrl.searchParams.get('userId') || 'anonymous';

  try {
    switch (action) {
      case 'status':
        return NextResponse.json({
          success: true,
          status: await getPrivacyStatus(userId),
        });

      case 'settings':
        return NextResponse.json({
          success: true,
          settings: privacyFramework.consent.getPrivacySettings(userId),
        });

      case 'report':
        return NextResponse.json({
          success: true,
          report: await unifiedPrivacy.generatePrivacyReport(userId),
        });

      case 'intermediaries':
        return NextResponse.json({
          success: true,
          intermediaries: collectivePrivacyManager.getAllIntermediaries(),
        });

      case 'data-sources':
        return NextResponse.json({
          success: true,
          sources: dataSupplyChain.getAllDataSources(),
        });

      case 'voice-profile':
        return NextResponse.json({
          success: true,
          profile: voiceCloneDetector.getVoiceProfile(userId),
        });

      case 'clone-detections':
        return NextResponse.json({
          success: true,
          detections: voiceCloneDetector.getDetectionHistory(),
        });

      case 'budgets':
        return NextResponse.json({
          success: true,
          budgets: Array.from(dpEngine['budgets'].values()),
        });

      case 'audit-logs':
        return NextResponse.json({
          success: true,
          logs: privacyFramework.consent.getAuditLogs(userId),
        });

      default:
        return NextResponse.json({
          success: true,
          message: 'Privacy API - Use action parameter',
          availableActions: [
            'status - Get comprehensive privacy status',
            'settings - Get privacy settings',
            'report - Generate comprehensive privacy report',
            'intermediaries - List available data intermediaries',
            'data-sources - List tracked data sources',
            'voice-profile - Get voice protection profile',
            'clone-detections - Get voice clone detection history',
            'budgets - Get privacy budgets',
            'audit-logs - Get audit logs',
          ],
        });
    }
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  const action = request.nextUrl.searchParams.get('action');

  try {
    const body = await request.json();

    switch (action) {
      case 'update-settings': {
        const { userId, settings } = body;
        const updated = await privacyFramework.consent.updatePrivacySettings(
          userId,
          settings
        );
        return NextResponse.json({ success: true, settings: updated });
      }

      case 'request-consent': {
        const { userId, purposes, dataTypes, retentionPeriod } = body;
        const consent = await privacyFramework.consent.requestConsent(
          userId,
          purposes,
          dataTypes,
          { retentionPeriod }
        );
        return NextResponse.json({ success: true, consent });
      }

      case 'withdraw-consent': {
        const { consentId, userId, reason } = body;
        await privacyFramework.consent.withdrawConsent(consentId, userId, reason);
        return NextResponse.json({ success: true, message: 'Consent withdrawn' });
      }

      case 'join-collective': {
        const { userId, intermediaryId, preferences } = body;
        const membership = await collectivePrivacyManager.joinCollective(
          userId,
          intermediaryId,
          preferences || {
            autoNegotiate: true,
            notifyOnAccess: true,
            notifyOnDeletion: true,
            notifyOnSharing: true,
            preferredCommunication: 'email',
            language: 'en',
          }
        );
        return NextResponse.json({ success: true, membership });
      }

      case 'initiate-action': {
        const { initiatorId, intermediaryId, type, target, participants } = body;
        const action_result = await collectivePrivacyManager.initiateCollectiveAction(
          initiatorId,
          intermediaryId,
          type,
          target,
          participants
        );
        return NextResponse.json({ success: true, action: action_result });
      }

      case 'register-voice': {
        const { userId, audioSampleUrl, settings } = body;
        const profile = await voiceCloneDetector.registerVoiceProfile(
          userId,
          audioSampleUrl,
          settings
        );
        return NextResponse.json({ success: true, profile });
      }

      case 'detect-clone': {
        const { audioUrl, userId } = body;
        const result = await voiceCloneDetector.detectClone(audioUrl, userId);
        return NextResponse.json({ success: true, result });
      }

      case 'anonymize-voice': {
        const { audioUrl, level } = body;
        const result = await voiceAnonymizer.anonymize(
          audioUrl,
          level || 'advanced'
        );
        return NextResponse.json({ success: true, result });
      }

      case 'create-budget': {
        const { totalEpsilon, totalDelta } = body;
        const budget = dpEngine.createBudget(
          totalEpsilon || 1.0,
          totalDelta || 1e-6
        );
        return NextResponse.json({ success: true, budget });
      }

      case 'private-query': {
        const { budgetId, query, data } = body;
        const result = await dpEngine.executePrivateQuery(budgetId, query, data);
        return NextResponse.json({ success: true, result });
      }

      case 'register-data-source': {
        const { name, type, url, license, recordCount, consentObtained } = body;
        const source = await dataSupplyChain.registerDataSource({
          name,
          type,
          url,
          license,
          recordCount,
          consentObtained: consentObtained || false,
          provenance: {
            origin: 'user_upload',
            owner: 'user',
            collector: 'kasbah',
            collectionMethod: 'direct',
            collectionPurpose: 'deepfake_detection',
            retentionPeriod: 30,
            transferHistory: [],
          },
        });
        return NextResponse.json({ success: true, source });
      }

      case 'transparency-report': {
        const { modelId } = body;
        const report = await unifiedPrivacy.generateTransparencyReport(modelId);
        return NextResponse.json({ success: true, report });
      }

      case 'create-trust': {
        const { name, trustees, beneficiaries, assets } = body;
        const trust = await unifiedPrivacy.createDataTrust(
          name,
          trustees,
          beneficiaries,
          assets
        );
        return NextResponse.json({ success: true, trust });
      }

      case 'process-media': {
        const { userId, mediaUrl, mediaType, purpose } = body;
        const result = await unifiedPrivacy.processMediaWithPrivacy(
          userId,
          mediaUrl,
          mediaType,
          purpose
        );
        return NextResponse.json({ success: true, result });
      }

      default:
        return NextResponse.json(
          {
            success: false,
            error: 'Invalid action',
            availableActions: [
              'update-settings - Update privacy settings',
              'request-consent - Request new consent',
              'withdraw-consent - Withdraw existing consent',
              'join-collective - Join a data collective',
              'initiate-action - Start collective action',
              'register-voice - Register voice profile',
              'detect-clone - Detect voice clone',
              'anonymize-voice - Anonymize voice audio',
              'create-budget - Create privacy budget',
              'private-query - Execute private analytics query',
              'register-data-source - Register training data source',
              'transparency-report - Generate transparency report',
              'create-trust - Create data trust',
              'process-media - Process media with privacy checks',
            ],
          },
          { status: 400 }
        );
    }
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      },
      { status: 500 }
    );
  }
}

// Helper function
async function getPrivacyStatus(userId: string) {
  const settings = privacyFramework.consent.getPrivacySettings(userId);
  const memberships = collectivePrivacyManager.getUserMemberships(userId);
  const voiceProfile = voiceCloneDetector.getVoiceProfile(userId);

  // Calculate remaining privacy budget
  const budgets = Array.from(dpEngine['budgets'].values());
  const totalBudget = budgets.reduce(
    (sum, b) => sum + (b.remainingEpsilon || 0),
    0
  );

  return {
    userId,
    settings,
    membershipsCount: memberships.length,
    voiceProfileRegistered: !!voiceProfile,
    privacyBudgetRemaining: totalBudget,
    lastUpdated: new Date().toISOString(),
  };
}
