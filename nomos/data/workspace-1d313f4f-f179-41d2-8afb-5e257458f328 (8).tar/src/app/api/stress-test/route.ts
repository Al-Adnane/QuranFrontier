import { NextRequest, NextResponse } from 'next/server'
import { runComprehensiveStressTest, THRESHOLDS } from '@/lib/stress-test-comprehensive'

export const maxDuration = 60 // Allow up to 60 seconds for stress test

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const format = searchParams.get('format') || 'json'

  try {
    console.log('[API] Running comprehensive stress test...')
    const report = await runComprehensiveStressTest()

    // Calculate instant response rate
    const instantCount = report.results.filter(r => r.duration <= THRESHOLDS.INSTANT).length
    const fastCount = report.results.filter(r => r.duration <= THRESHOLDS.FAST).length
    const instantResponseRate = (fastCount / report.totalTests) * 100

    if (format === 'summary') {
      return NextResponse.json({
        success: true,
        summary: {
          totalTests: report.totalTests,
          passed: report.passed,
          failed: report.failed,
          overallScore: `${report.overallScore.toFixed(1)}%`,
          efficiency: `${report.efficiency.toFixed(1)}%`,
          avgDuration: `${report.avgDuration.toFixed(2)}ms`,
          instantResponseRate: `${instantResponseRate.toFixed(1)}%`,
          status: report.overallScore >= 95 ? 'EXCELLENT' : report.overallScore >= 80 ? 'GOOD' : 'NEEDS_IMPROVEMENT'
        },
        categories: report.categories,
        recommendations: report.recommendations
      })
    }

    // Full report
    return NextResponse.json({
      success: true,
      ...report,
      thresholds: THRESHOLDS,
      performanceGrade: getPerformanceGrade(report.avgDuration),
      instantResponseRate: `${instantResponseRate.toFixed(1)}%`
    })

  } catch (error) {
    console.error('[API] Stress test failed:', error)
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Stress test failed'
    }, { status: 500 })
  }
}

function getPerformanceGrade(avgDuration: number): string {
  if (avgDuration <= 10) return 'A+ (Instant)'
  if (avgDuration <= 30) return 'A (Excellent)'
  if (avgDuration <= 50) return 'B (Good)'
  if (avgDuration <= 100) return 'C (Acceptable)'
  return 'D (Needs Optimization)'
}

export async function POST(request: NextRequest) {
  const body = await request.json()
  const { targetCategory } = body

  // Run targeted stress test
  console.log(`[API] Running targeted stress test for: ${targetCategory || 'all'}`)

  const report = await runComprehensiveStressTest()

  if (targetCategory) {
    const categoryResults = report.results.filter(r => r.category === targetCategory)
    return NextResponse.json({
      success: true,
      category: targetCategory,
      results: categoryResults,
      passed: categoryResults.filter(r => r.passed).length,
      total: categoryResults.length
    })
  }

  return NextResponse.json({
    success: true,
    report
  })
}
