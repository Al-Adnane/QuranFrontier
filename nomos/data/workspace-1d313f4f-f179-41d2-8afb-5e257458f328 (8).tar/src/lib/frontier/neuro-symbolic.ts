/**
 * NEURO-SYMBOLIC AI FRONTIER
 * ===========================
 * 
 * Combines the learning power of neural networks with the reasoning capabilities
 * of symbolic AI for interpretable deepfake detection with provable guarantees.
 * 
 * Capabilities:
 * - Neural network feature extraction + symbolic reasoning
 * - Differentiable logic programming
 * - Constraint-guided detection
 * - Explainable inference chains
 * - Knowledge graph integration
 * - Rule learning from data
 * - Hybrid inference engine
 * - Compositional reasoning
 * 
 * @module frontier/neuro-symbolic
 * @version 1.0.0
 */

// ============================================================================
// TYPES
// ============================================================================

export interface SymbolicConcept {
  /** Concept ID */
  id: string;
  /** Concept name */
  name: string;
  /** Concept type */
  type: 'entity' | 'relation' | 'attribute' | 'rule' | 'constraint';
  /** Natural language description */
  description: string;
  /** Embedding representation */
  embedding: number[];
  /** Confidence in concept */
  confidence: number;
  /** Source (learned or expert-defined) */
  source: 'learned' | 'expert' | 'hybrid';
}

export interface LogicalRule {
  /** Rule ID */
  id: string;
  /** Rule name */
  name: string;
  /** Antecedents (IF part) */
  antecedents: LogicalExpression[];
  /** Consequents (THEN part) */
  consequents: LogicalExpression[];
  /** Rule weight (fuzzy logic) */
  weight: number;
  /** Rule confidence */
  confidence: number;
  /** Support count */
  support: number;
  /** Source */
  source: 'learned' | 'expert' | 'hybrid';
}

export interface LogicalExpression {
  /** Expression type */
  type: 'atom' | 'conjunction' | 'disjunction' | 'negation' | 'implication' | 'quantifier';
  /** Predicate name */
  predicate?: string;
  /** Arguments */
  arguments?: string[];
  /** Sub-expressions */
  subExpressions?: LogicalExpression[];
  /** Negated */
  negated?: boolean;
  /** Fuzzy membership value */
  fuzzyValue?: number;
}

export interface Constraint {
  /** Constraint ID */
  id: string;
  /** Constraint name */
  name: string;
  /** Constraint expression */
  expression: LogicalExpression;
  /** Constraint type */
  type: 'hard' | 'soft';
  /** Penalty for violation */
  penalty: number;
  /** Priority */
  priority: number;
}

export interface KnowledgeGraph {
  /** Nodes (entities) */
  nodes: Map<string, GraphNode>;
  /** Edges (relations) */
  edges: GraphEdge[];
  /** Concept embeddings */
  embeddings: Map<string, number[]>;
  /** Schema */
  schema: GraphSchema;
}

export interface GraphNode {
  /** Node ID */
  id: string;
  /** Node type */
  type: string;
  /** Node properties */
  properties: Record<string, unknown>;
  /** Confidence */
  confidence: number;
}

export interface GraphEdge {
  /** Source node */
  source: string;
  /** Target node */
  target: string;
  /** Relation type */
  relation: string;
  /** Edge weight */
  weight: number;
  /** Confidence */
  confidence: number;
}

export interface GraphSchema {
  /** Entity types */
  entityTypes: string[];
  /** Relation types with domains/ranges */
  relationTypes: Array<{
    name: string;
    domain: string;
    range: string;
  }>;
  /** Attribute types */
  attributeTypes: string[];
}

export interface NeuralSymbolicBridge {
  /** Neural feature extractor */
  featureExtractor: NeuralFeatureExtractor;
  /** Concept groundings */
  conceptGroundings: Map<string, number[]>;
  /** Differentiable rules */
  differentiableRules: DifferentiableRule[];
  /** Reasoning module */
  reasoningModule: ReasoningModule;
}

export interface NeuralFeatureExtractor {
  /** Layer configurations */
  layers: number[];
  /** Feature dimension */
  featureDim: number;
  /** Output concepts */
  outputConcepts: string[];
}

export interface DifferentiableRule {
  /** Rule ID */
  id: string;
  /** Rule body as neural operations */
  neuralOperations: NeuralOperation[];
  /** Soft logic temperature */
  temperature: number;
  /** Rule weight */
  weight: number;
}

export interface NeuralOperation {
  /** Operation type */
  type: 'and' | 'or' | 'not' | 'implies' | 'exists' | 'forall' | 'softmax';
  /** Input tensors */
  inputs: string[];
  /** Output tensor */
  output: string;
  /** Parameters */
  params: Record<string, number>;
}

export interface ReasoningModule {
  /** Forward chaining rules */
  forwardRules: LogicalRule[];
  /** Backward chaining rules */
  backwardRules: LogicalRule[];
  /** Inference depth */
  maxDepth: number;
  /** Proof traces */
  proofTraces: ProofTrace[];
}

export interface ProofTrace {
  /** Trace ID */
  id: string;
  /** Goal */
  goal: string;
  /** Steps */
  steps: ProofStep[];
  /** Final confidence */
  confidence: number;
  /** Success */
  success: boolean;
}

export interface ProofStep {
  /** Step number */
  step: number;
  /** Rule applied */
  rule: string;
  /** Substitutions */
  substitutions: Record<string, string>;
  /** Derived fact */
  derivedFact: string;
  /** Confidence at this step */
  confidence: number;
}

export interface NeuroSymbolicResult {
  /** Detection result */
  prediction: 'real' | 'deepfake' | 'inconclusive';
  /** Confidence */
  confidence: number;
  /** Neural features used */
  neuralFeatures: number[];
  /** Symbolic concepts activated */
  activatedConcepts: string[];
  /** Rules fired */
  firedRules: string[];
  /** Proof trace */
  proofTrace: ProofTrace | null;
  /** Explanation */
  explanation: string;
  /** Knowledge graph subgraph */
  relevantSubgraph: GraphEdge[];
  /** Constraint violations */
  constraintViolations: string[];
}

// ============================================================================
// SYMBOLIC REASONING ENGINE
// ============================================================================

/**
 * Initialize knowledge graph
 */
export function initializeKnowledgeGraph(): KnowledgeGraph {
  const schema: GraphSchema = {
    entityTypes: [
      'Media',
      'Person',
      'Face',
      'Voice',
      'DeepfakeType',
      'Artifact',
      'DetectionMethod',
      'Constraint'
    ],
    relationTypes: [
      { name: 'contains', domain: 'Media', range: 'Face' },
      { name: 'depicts', domain: 'Face', range: 'Person' },
      { name: 'hasVoice', domain: 'Person', range: 'Voice' },
      { name: 'detectedAs', domain: 'Media', range: 'DeepfakeType' },
      { name: 'hasArtifact', domain: 'Face', range: 'Artifact' },
      { name: 'detectedBy', domain: 'Artifact', range: 'DetectionMethod' },
      { name: 'violates', domain: 'Media', range: 'Constraint' }
    ],
    attributeTypes: [
      'confidence',
      'timestamp',
      'duration',
      'quality',
      'authenticityScore'
    ]
  };

  return {
    nodes: new Map(),
    edges: [],
    embeddings: new Map(),
    schema
  };
}

/**
 * Add entity to knowledge graph
 */
export function addEntity(
  kg: KnowledgeGraph,
  id: string,
  type: string,
  properties: Record<string, unknown> = {},
  confidence: number = 1.0
): KnowledgeGraph {
  const node: GraphNode = {
    id,
    type,
    properties,
    confidence
  };

  kg.nodes.set(id, node);
  
  // Generate embedding for entity
  const embedding = generateEntityEmbedding(type, properties);
  kg.embeddings.set(id, embedding);

  return kg;
}

/**
 * Generate entity embedding
 */
function generateEntityEmbedding(type: string, properties: Record<string, unknown>): number[] {
  const embedding: number[] = [];
  const baseVector = getBaseVector(type);
  
  // Combine base vector with property values
  for (let i = 0; i < 64; i++) {
    let val = baseVector[i % baseVector.length];
    
    // Add property contributions
    for (const [key, value] of Object.entries(properties)) {
      if (typeof value === 'number') {
        val += hashString(key) * value * 0.01;
      }
    }
    
    embedding.push(val);
  }
  
  // Normalize
  const norm = Math.sqrt(embedding.reduce((sum, v) => sum + v * v, 0));
  return embedding.map(v => v / norm);
}

/**
 * Get base vector for entity type
 */
function getBaseVector(type: string): number[] {
  const hash = hashString(type);
  const vector: number[] = [];
  
  for (let i = 0; i < 32; i++) {
    vector.push(Math.sin(hash * (i + 1) * 0.1));
  }
  
  return vector;
}

/**
 * Hash string to number
 */
function hashString(s: string): number {
  let hash = 0;
  for (let i = 0; i < s.length; i++) {
    hash = ((hash << 5) - hash) + s.charCodeAt(i);
    hash = hash & hash;
  }
  return hash;
}

/**
 * Add relation to knowledge graph
 */
export function addRelation(
  kg: KnowledgeGraph,
  source: string,
  target: string,
  relation: string,
  weight: number = 1.0,
  confidence: number = 1.0
): KnowledgeGraph {
  const edge: GraphEdge = {
    source,
    target,
    relation,
    weight,
    confidence
  };

  kg.edges.push(edge);

  return kg;
}

/**
 * Query knowledge graph
 */
export function queryGraph(
  kg: KnowledgeGraph,
  query: {
    entityType?: string;
    relation?: string;
    sourceId?: string;
    targetId?: string;
    minConfidence?: number;
  }
): GraphEdge[] {
  return kg.edges.filter(edge => {
    if (query.relation && edge.relation !== query.relation) return false;
    if (query.sourceId && edge.source !== query.sourceId) return false;
    if (query.targetId && edge.target !== query.targetId) return false;
    if (query.minConfidence && edge.confidence < query.minConfidence) return false;
    
    if (query.entityType) {
      const sourceNode = kg.nodes.get(edge.source);
      const targetNode = kg.nodes.get(edge.target);
      if (sourceNode?.type !== query.entityType && targetNode?.type !== query.entityType) {
        return false;
      }
    }
    
    return true;
  });
}

// ============================================================================
// LOGICAL RULE ENGINE
// ============================================================================

/**
 * Create logical rule
 */
export function createRule(
  name: string,
  antecedents: LogicalExpression[],
  consequents: LogicalExpression[],
  weight: number = 1.0,
  source: 'learned' | 'expert' | 'hybrid' = 'expert'
): LogicalRule {
  return {
    id: `rule_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    name,
    antecedents,
    consequents,
    weight,
    confidence: 1.0,
    support: 0,
    source
  };
}

/**
 * Evaluate logical expression
 */
export function evaluateExpression(
  expr: LogicalExpression,
  facts: Map<string, number>
): number {
  switch (expr.type) {
    case 'atom': {
      const key = expr.predicate + (expr.arguments?.join(',') || '');
      const value = facts.get(key) || 0;
      return expr.negated ? 1 - value : value;
    }
    
    case 'conjunction': {
      if (!expr.subExpressions || expr.subExpressions.length === 0) return 0;
      let result = 1;
      for (const sub of expr.subExpressions) {
        result *= evaluateExpression(sub, facts);
      }
      return result;
    }
    
    case 'disjunction': {
      if (!expr.subExpressions || expr.subExpressions.length === 0) return 0;
      let result = 0;
      for (const sub of expr.subExpressions) {
        result = Math.max(result, evaluateExpression(sub, facts));
      }
      return result;
    }
    
    case 'negation': {
      if (!expr.subExpressions || expr.subExpressions.length === 0) return 1;
      return 1 - evaluateExpression(expr.subExpressions[0], facts);
    }
    
    case 'implication': {
      if (!expr.subExpressions || expr.subExpressions.length < 2) return 0;
      const antecedent = evaluateExpression(expr.subExpressions[0], facts);
      const consequent = evaluateExpression(expr.subExpressions[1], facts);
      // Material implication: A → B ≡ ¬A ∨ B
      return Math.max(1 - antecedent, consequent);
    }
    
    default:
      return expr.fuzzyValue || 0;
  }
}

/**
 * Forward chaining inference
 */
export function forwardChain(
  rules: LogicalRule[],
  initialFacts: Map<string, number>,
  maxIterations: number = 100
): {
  facts: Map<string, number>;
  iterations: number;
  derivedFacts: string[];
} {
  const facts = new Map(initialFacts);
  const derivedFacts: string[] = [];
  let iterations = 0;
  let changed = true;

  while (changed && iterations < maxIterations) {
    changed = false;
    iterations++;

    for (const rule of rules) {
      // Evaluate antecedents
      let antecedentValue = 1;
      for (const ant of rule.antecedents) {
        antecedentValue *= evaluateExpression(ant, facts);
      }

      if (antecedentValue > 0.5) {
        // Fire rule
        for (const cons of rule.consequents) {
          const key = cons.predicate + (cons.arguments?.join(',') || '');
          const currentValue = facts.get(key) || 0;
          const newValue = Math.max(currentValue, antecedentValue * rule.weight);
          
          if (newValue > currentValue) {
            facts.set(key, newValue);
            derivedFacts.push(key);
            changed = true;
          }
        }
      }
    }
  }

  return { facts, iterations, derivedFacts };
}

/**
 * Backward chaining inference
 */
export function backwardChain(
  goal: string,
  rules: LogicalRule[],
  facts: Map<string, number>,
  maxDepth: number = 10
): {
  proven: boolean;
  confidence: number;
  trace: string[];
} {
  const trace: string[] = [];
  
  function prove(g: string, depth: number): number {
    if (depth > maxDepth) {
      trace.push(`Max depth reached for goal: ${g}`);
      return 0;
    }

    // Check if already known
    const factValue = facts.get(g);
    if (factValue !== undefined && factValue > 0.5) {
      trace.push(`Fact proven: ${g} = ${factValue.toFixed(2)}`);
      return factValue;
    }

    // Find rules that conclude g
    let bestProof = 0;
    
    for (const rule of rules) {
      for (const cons of rule.consequents) {
        const key = cons.predicate + (cons.arguments?.join(',') || '');
        
        if (key === g) {
          trace.push(`Trying rule: ${rule.name}`);
          
          // Prove all antecedents
          let antValue = 1;
          for (const ant of rule.antecedents) {
            const antKey = ant.predicate + (ant.arguments?.join(',') || '');
            const proved = prove(antKey, depth + 1);
            antValue *= proved;
            
            if (antValue < 0.1) break;
          }
          
          bestProof = Math.max(bestProof, antValue * rule.weight);
        }
      }
    }

    return bestProof;
  }

  const confidence = prove(goal, 0);
  
  return {
    proven: confidence > 0.5,
    confidence,
    trace
  };
}

// ============================================================================
// CONSTRAINT SATISFACTION
// ============================================================================

/**
 * Create constraint
 */
export function createConstraint(
  name: string,
  expression: LogicalExpression,
  type: 'hard' | 'soft' = 'hard',
  penalty: number = 1.0,
  priority: number = 1
): Constraint {
  return {
    id: `constraint_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    name,
    expression,
    type,
    penalty,
    priority
  };
}

/**
 * Check constraint satisfaction
 */
export function checkConstraints(
  constraints: Constraint[],
  facts: Map<string, number>
): {
  satisfied: boolean;
  violations: Array<{ constraint: Constraint; violation: number }>;
  totalPenalty: number;
} {
  const violations: Array<{ constraint: Constraint; violation: number }> = [];
  let totalPenalty = 0;
  let hasHardViolation = false;

  for (const constraint of constraints) {
    const value = evaluateExpression(constraint.expression, facts);
    const violation = 1 - value;

    if (violation > 0.1) {
      violations.push({ constraint, violation });
      totalPenalty += violation * constraint.penalty;

      if (constraint.type === 'hard') {
        hasHardViolation = true;
      }
    }
  }

  return {
    satisfied: !hasHardViolation,
    violations,
    totalPenalty
  };
}

/**
 * Constraint-guided inference
 */
export function constraintGuidedInference(
  rules: LogicalRule[],
  constraints: Constraint[],
  initialFacts: Map<string, number>
): {
  facts: Map<string, number>;
  constraintSatisfaction: number;
  iterations: number;
} {
  let facts = new Map(initialFacts);
  let bestSatisfaction = 0;
  let iterations = 0;

  for (let iter = 0; iter < 50; iter++) {
    iterations++;
    
    // Apply forward chaining
    const result = forwardChain(rules, facts, 10);
    facts = result.facts;

    // Check constraints
    const check = checkConstraints(constraints, facts);
    
    if (check.satisfied) {
      return {
        facts,
        constraintSatisfaction: 1 - check.totalPenalty / constraints.length,
        iterations
      };
    }

    // Adjust facts to better satisfy constraints
    for (const { constraint, violation } of check.violations) {
      if (constraint.type === 'soft') {
        // Relax soft constraints slightly
        for (const [key, value] of facts) {
          facts.set(key, value * (1 - violation * 0.01));
        }
      }
    }

    bestSatisfaction = Math.max(bestSatisfaction, 1 - check.totalPenalty / constraints.length);
  }

  return {
    facts,
    constraintSatisfaction: bestSatisfaction,
    iterations
  };
}

// ============================================================================
// NEURAL-SYMBOLIC BRIDGE
// ============================================================================

/**
 * Initialize neural-symbolic bridge
 */
export function initializeBridge(
  featureDim: number,
  concepts: SymbolicConcept[]
): NeuralSymbolicBridge {
  // Map concepts to neural space
  const conceptGroundings = new Map<string, number[]>();
  
  for (const concept of concepts) {
    // Create grounding vector
    const grounding: number[] = [];
    for (let i = 0; i < featureDim; i++) {
      grounding.push((Math.random() - 0.5) * 0.1);
    }
    conceptGroundings.set(concept.id, grounding);
  }

  return {
    featureExtractor: {
      layers: [featureDim, 256, 128, concepts.length],
      featureDim,
      outputConcepts: concepts.map(c => c.id)
    },
    conceptGroundings,
    differentiableRules: [],
    reasoningModule: {
      forwardRules: [],
      backwardRules: [],
      maxDepth: 10,
      proofTraces: []
    }
  };
}

/**
 * Ground neural features to symbolic concepts
 */
export function groundToConcepts(
  features: number[],
  bridge: NeuralSymbolicBridge
): Array<{ concept: string; activation: number }> {
  const activations: Array<{ concept: string; activation: number }> = [];
  
  for (const [conceptId, grounding] of bridge.conceptGroundings) {
    // Compute similarity between features and grounding
    let similarity = 0;
    let norm1 = 0;
    let norm2 = 0;
    
    for (let i = 0; i < Math.min(features.length, grounding.length); i++) {
      similarity += features[i] * grounding[i];
      norm1 += features[i] * features[i];
      norm2 += grounding[i] * grounding[i];
    }
    
    if (norm1 > 0 && norm2 > 0) {
      similarity /= Math.sqrt(norm1 * norm2);
    }
    
    activations.push({
      concept: conceptId,
      activation: (similarity + 1) / 2 // Map to [0, 1]
    });
  }
  
  // Sort by activation
  return activations.sort((a, b) => b.activation - a.activation);
}

/**
 * Create differentiable rule
 */
export function createDifferentiableRule(
  id: string,
  operations: NeuralOperation[],
  temperature: number = 1.0
): DifferentiableRule {
  return {
    id,
    neuralOperations: operations,
    temperature,
    weight: 1.0
  };
}

/**
 * Soft logical operations (differentiable)
 */
export const SoftLogic = {
  and: (values: number[], temperature: number = 1.0): number => {
    // Product t-norm
    return values.reduce((a, b) => a * b, 1);
  },

  or: (values: number[], temperature: number = 1.0): number => {
    // Probabilistic sum
    return 1 - values.reduce((a, b) => a * (1 - b), 1);
  },

  not: (value: number): number => 1 - value,

  implies: (antecedent: number, consequent: number): number => {
    // Godel implication
    return antecedent <= consequent ? 1 : consequent;
  },

  exists: (values: number[], temperature: number = 1.0): number => {
    // Soft max (softmax-based approximation)
    const expValues = values.map(v => Math.exp(v * temperature));
    const sum = expValues.reduce((a, b) => a + b, 0);
    const softMax = expValues.map(v => v / sum);
    
    // Weighted sum as "soft exists"
    return values.reduce((sum, v, i) => sum + v * softMax[i], 0);
  },

  forall: (values: number[], temperature: number = 1.0): number => {
    // Soft min
    const expValues = values.map(v => Math.exp(-v * temperature));
    const sum = expValues.reduce((a, b) => a + b, 0);
    const softMin = expValues.map(v => v / sum);
    
    // Weighted sum as "soft forall"
    return values.reduce((sum, v, i) => sum + v * softMin[i], 0);
  }
};

/**
 * Execute differentiable rule
 */
export function executeDifferentiableRule(
  rule: DifferentiableRule,
  inputTensors: Map<string, number[]>
): Map<string, number[]> {
  const tensors = new Map(inputTensors);

  for (const op of rule.neuralOperations) {
    const inputs = op.inputs.map(i => tensors.get(i) || []);
    let output: number[] = [];

    switch (op.type) {
      case 'and': {
        // Element-wise minimum (soft)
        const [a, b] = inputs;
        for (let i = 0; i < Math.min(a.length, b.length); i++) {
          output.push(Math.min(a[i], b[i]));
        }
        break;
      }
      
      case 'or': {
        // Element-wise maximum (soft)
        const [a, b] = inputs;
        for (let i = 0; i < Math.min(a.length, b.length); i++) {
          output.push(Math.max(a[i], b[i]));
        }
        break;
      }
      
      case 'not': {
        const a = inputs[0];
        output = a.map(v => 1 - v);
        break;
      }
      
      case 'softmax': {
        const a = inputs[0];
        const max = Math.max(...a);
        const exp = a.map(v => Math.exp(v - max));
        const sum = exp.reduce((s, v) => s + v, 0);
        output = exp.map(v => v / sum);
        break;
      }
      
      default:
        output = inputs[0] || [];
    }

    tensors.set(op.output, output);
  }

  return tensors;
}

// ============================================================================
// NEURO-SYMBOLIC DETECTION
// ============================================================================

/**
 * Perform neuro-symbolic deepfake detection
 */
export async function neuroSymbolicDetection(
  mediaFeatures: number[],
  bridge: NeuralSymbolicBridge,
  rules: LogicalRule[],
  constraints: Constraint[],
  kg: KnowledgeGraph
): Promise<NeuroSymbolicResult> {
  // 1. Ground features to concepts
  const conceptActivations = groundToConcepts(mediaFeatures, bridge);
  const activatedConcepts = conceptActivations
    .filter(c => c.activation > 0.5)
    .map(c => c.concept);

  // 2. Create initial facts from neural activations
  const facts = new Map<string, number>();
  for (const { concept, activation } of conceptActivations) {
    facts.set(concept, activation);
  }

  // 3. Query knowledge graph for relevant context
  const relevantSubgraph = queryGraph(kg, {
    minConfidence: 0.5
  }).slice(0, 20);

  // 4. Add knowledge graph facts
  for (const edge of relevantSubgraph) {
    facts.set(`${edge.relation}(${edge.source},${edge.target})`, edge.confidence);
  }

  // 5. Apply rules with constraint guidance
  const inferenceResult = constraintGuidedInference(rules, constraints, facts);

  // 6. Check for deepfake conclusion
  const deepfakeGoal = 'isDeepfake';
  const backwardResult = backwardChain(deepfakeGoal, rules, inferenceResult.facts);

  // 7. Generate proof trace
  const proofTrace: ProofTrace = {
    id: `proof_${Date.now()}`,
    goal: deepfakeGoal,
    steps: backwardResult.trace.map((t, i) => ({
      step: i,
      rule: t.includes('rule:') ? t.split(':')[1]?.trim() || t : '',
      substitutions: {},
      derivedFact: t,
      confidence: backwardResult.confidence
    })),
    confidence: backwardResult.confidence,
    success: backwardResult.proven
  };

  // 8. Generate explanation
  const explanation = generateExplanation(
    conceptActivations.slice(0, 5),
    proofTrace,
    constraints
  );

  // 9. Check constraint violations
  const constraintCheck = checkConstraints(constraints, inferenceResult.facts);
  const constraintViolations = constraintCheck.violations.map(
    v => v.constraint.name
  );

  // 10. Determine prediction
  let prediction: 'real' | 'deepfake' | 'inconclusive';
  let confidence: number;

  if (backwardResult.confidence > 0.7) {
    prediction = 'deepfake';
    confidence = backwardResult.confidence;
  } else if (backwardResult.confidence < 0.3) {
    prediction = 'real';
    confidence = 1 - backwardResult.confidence;
  } else {
    prediction = 'inconclusive';
    confidence = 0.5;
  }

  // Find fired rules
  const firedRules: string[] = [];
  for (const rule of rules) {
    let antecedentValue = 1;
    for (const ant of rule.antecedents) {
      antecedentValue *= evaluateExpression(ant, inferenceResult.facts);
    }
    if (antecedentValue > 0.5) {
      firedRules.push(rule.name);
    }
  }

  return {
    prediction,
    confidence,
    neuralFeatures: mediaFeatures.slice(0, 10),
    activatedConcepts,
    firedRules,
    proofTrace,
    explanation,
    relevantSubgraph,
    constraintViolations
  };
}

/**
 * Generate natural language explanation
 */
function generateExplanation(
  topConcepts: Array<{ concept: string; activation: number }>,
  proofTrace: ProofTrace,
  constraints: Constraint[]
): string {
  const conceptStr = topConcepts
    .map(c => `${c.concept} (${(c.activation * 100).toFixed(0)}%)`)
    .join(', ');

  const proofStr = proofTrace.success
    ? `The detection was proven through ${proofTrace.steps.length} reasoning steps.`
    : `The detection could not be conclusively proven.`;

  const constraintStr = constraints.length > 0
    ? `${constraints.length} constraints were considered.`
    : '';

  return `Analysis focused on: ${conceptStr}. ${proofStr} ${constraintStr}`;
}

// ============================================================================
// RULE LEARNING
// ============================================================================

/**
 * Learn rules from data
 */
export function learnRules(
  positiveExamples: Map<string, number>[],
  negativeExamples: Map<string, number>[],
  maxRules: number = 10
): LogicalRule[] {
  const rules: LogicalRule[] = [];
  
  // Find patterns that distinguish positive from negative
  const candidatePatterns = findDistinguishingPatterns(
    positiveExamples,
    negativeExamples
  );

  for (let i = 0; i < Math.min(candidatePatterns.length, maxRules); i++) {
    const pattern = candidatePatterns[i];
    
    const rule = createRule(
      `learned_rule_${i}`,
      pattern.antecedents,
      [pattern.consequent],
      pattern.weight,
      'learned'
    );
    
    rule.support = pattern.support;
    rule.confidence = pattern.confidence;
    
    rules.push(rule);
  }

  return rules;
}

/**
 * Pattern found in data
 */
interface Pattern {
  antecedents: LogicalExpression[];
  consequent: LogicalExpression;
  weight: number;
  support: number;
  confidence: number;
}

/**
 * Find distinguishing patterns
 */
function findDistinguishingPatterns(
  positive: Map<string, number>[],
  negative: Map<string, number>[]
): Pattern[] {
  const patterns: Pattern[] = [];
  
  // Get all keys
  const allKeys = new Set<string>();
  for (const ex of [...positive, ...negative]) {
    for (const key of ex.keys()) {
      allKeys.add(key);
    }
  }

  // Find single-feature patterns
  for (const key of allKeys) {
    // Check if this feature distinguishes
    let posSum = 0;
    let negSum = 0;
    
    for (const ex of positive) {
      posSum += ex.get(key) || 0;
    }
    for (const ex of negative) {
      negSum += ex.get(key) || 0;
    }

    const posAvg = posSum / positive.length;
    const negAvg = negSum / negative.length;
    
    // If significant difference
    if (Math.abs(posAvg - negAvg) > 0.3) {
      const antecedent: LogicalExpression = {
        type: 'atom',
        predicate: key.split('(')[0],
        arguments: key.includes('(') ? key.match(/\(([^)]*)\)/)?.[1]?.split(',') || [] : [],
        negated: posAvg < negAvg
      };

      const consequent: LogicalExpression = {
        type: 'atom',
        predicate: 'isDeepfake',
        arguments: []
      };

      patterns.push({
        antecedents: [antecedent],
        consequent,
        weight: Math.abs(posAvg - negAvg),
        support: Math.min(posSum, positive.length - negSum),
        confidence: Math.abs(posAvg - negAvg)
      });
    }
  }

  // Sort by confidence
  return patterns.sort((a, b) => b.confidence - a.confidence);
}

// ============================================================================
// TESTS
// ============================================================================

export function runNeuroSymbolicTests(): {
  passed: boolean;
  tests: { total: number; passed: number; failed: number };
  results: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const results: Array<{ name: string; passed: boolean; error?: string }> = [];

  // Test 1: Knowledge Graph
  try {
    let kg = initializeKnowledgeGraph();
    kg = addEntity(kg, 'media1', 'Media', { duration: 30 });
    kg = addRelation(kg, 'media1', 'face1', 'contains');
    
    results.push({
      name: 'Knowledge Graph',
      passed: kg.nodes.size === 1 && kg.edges.length === 1
    });
  } catch (e) {
    results.push({ name: 'Knowledge Graph', passed: false, error: String(e) });
  }

  // Test 2: Logical Expression Evaluation
  try {
    const facts = new Map([['isDeepfake', 0.8]]);
    const expr: LogicalExpression = {
      type: 'atom',
      predicate: 'isDeepfake',
      arguments: []
    };
    const value = evaluateExpression(expr, facts);
    
    results.push({
      name: 'Expression Evaluation',
      passed: Math.abs(value - 0.8) < 0.01
    });
  } catch (e) {
    results.push({ name: 'Expression Evaluation', passed: false, error: String(e) });
  }

  // Test 3: Forward Chaining
  try {
    const rule = createRule(
      'face_swap_rule',
      [{ type: 'atom', predicate: 'hasInconsistentBlinking', arguments: [] }],
      [{ type: 'atom', predicate: 'isDeepfake', arguments: [] }]
    );
    
    const facts = new Map([['hasInconsistentBlinking', 0.9]]);
    const result = forwardChain([rule], facts);
    
    results.push({
      name: 'Forward Chaining',
      passed: (result.facts.get('isDeepfake') || 0) > 0.5
    });
  } catch (e) {
    results.push({ name: 'Forward Chaining', passed: false, error: String(e) });
  }

  // Test 4: Backward Chaining
  try {
    const rule = createRule(
      'lip_sync_rule',
      [{ type: 'atom', predicate: 'lipSyncMismatch', arguments: [] }],
      [{ type: 'atom', predicate: 'isDeepfake', arguments: [] }]
    );
    
    const facts = new Map([['lipSyncMismatch', 0.85]]);
    const result = backwardChain('isDeepfake', [rule], facts);
    
    results.push({
      name: 'Backward Chaining',
      passed: result.proven && result.confidence > 0.5
    });
  } catch (e) {
    results.push({ name: 'Backward Chaining', passed: false, error: String(e) });
  }

  // Test 5: Soft Logic
  try {
    const andResult = SoftLogic.and([0.8, 0.7], 1.0);
    const orResult = SoftLogic.or([0.3, 0.4], 1.0);
    const notResult = SoftLogic.not(0.6);
    
    results.push({
      name: 'Soft Logic',
      passed: Math.abs(andResult - 0.56) < 0.01 &&
              Math.abs(orResult - 0.58) < 0.01 &&
              Math.abs(notResult - 0.4) < 0.01
    });
  } catch (e) {
    results.push({ name: 'Soft Logic', passed: false, error: String(e) });
  }

  // Test 6: Constraint Satisfaction
  try {
    const constraint = createConstraint(
      'authenticity_constraint',
      { type: 'atom', predicate: 'authenticityScore', arguments: [], fuzzyValue: 0.8 },
      'hard'
    );
    
    const facts = new Map([['authenticityScore', 0.9]]);
    const check = checkConstraints([constraint], facts);
    
    results.push({
      name: 'Constraint Satisfaction',
      passed: check.satisfied
    });
  } catch (e) {
    results.push({ name: 'Constraint Satisfaction', passed: false, error: String(e) });
  }

  // Test 7: Neural-Symbolic Bridge
  try {
    const concepts: SymbolicConcept[] = [
      { id: 'face', name: 'Face', type: 'entity', description: 'Detected face', embedding: [], confidence: 1, source: 'expert' },
      { id: 'voice', name: 'Voice', type: 'entity', description: 'Detected voice', embedding: [], confidence: 1, source: 'expert' }
    ];
    
    const bridge = initializeBridge(128, concepts);
    const features = new Array(128).fill(0).map(() => Math.random());
    const grounded = groundToConcepts(features, bridge);
    
    results.push({
      name: 'Neural-Symbolic Bridge',
      passed: grounded.length === 2 && grounded.every(g => g.activation >= 0 && g.activation <= 1)
    });
  } catch (e) {
    results.push({ name: 'Neural-Symbolic Bridge', passed: false, error: String(e) });
  }

  // Test 8: Rule Learning
  try {
    const positive = [
      new Map([['feature1', 0.9], ['feature2', 0.8]]),
      new Map([['feature1', 0.85], ['feature2', 0.75]])
    ];
    const negative = [
      new Map([['feature1', 0.2], ['feature2', 0.3]]),
      new Map([['feature1', 0.3], ['feature2', 0.2]])
    ];
    
    const rules = learnRules(positive, negative, 5);
    
    results.push({
      name: 'Rule Learning',
      passed: rules.length > 0 && rules.every(r => r.source === 'learned')
    });
  } catch (e) {
    results.push({ name: 'Rule Learning', passed: false, error: String(e) });
  }

  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;

  return {
    passed: failed === 0,
    tests: { total: results.length, passed, failed },
    results
  };
}

// Default export
export default {
  initializeKnowledgeGraph,
  addEntity,
  addRelation,
  queryGraph,
  createRule,
  evaluateExpression,
  forwardChain,
  backwardChain,
  createConstraint,
  checkConstraints,
  constraintGuidedInference,
  initializeBridge,
  groundToConcepts,
  createDifferentiableRule,
  SoftLogic,
  executeDifferentiableRule,
  neuroSymbolicDetection,
  learnRules,
  runNeuroSymbolicTests
};
