/**
 * Neural Architecture Fingerprinting Module
 *
 * Identifies the AI model architecture used to generate content:
 * - Model architecture fingerprinting
 * - Generator attribution
 * - Hyperparameter estimation
 * - Training data signature detection
 * - Model family classification
 *
 * @module frontier/neural-fingerprint
 * @version 4.1.0
 */

// ============================================================================
// TYPES AND INTERFACES
// ============================================================================

export interface NeuralFingerprintResult {
  /** Analysis ID */
  id: string;
  /** Timestamp */
  timestamp: number;
  /** Detection confidence */
  confidence: number;
  /** Suspected model architecture */
  architecture: ModelArchitecture | null;
  /** Generator attribution */
  generator: GeneratorInfo | null;
  /** Detected fingerprints */
  fingerprints: NeuralFingerprint[];
  /** Feature analysis */
  features: FeatureAnalysis;
  /** Architecture signatures */
  signatures: ArchitectureSignature[];
  /** Recommendations */
  recommendations: string[];
}

export interface ModelArchitecture {
  /** Architecture name */
  name: string;
  /** Model family */
  family: ModelFamily;
  /** Version */
  version: string;
  /** Confidence */
  confidence: number;
  /** Estimated parameters */
  estimatedParams: string;
  /** Key characteristics */
  characteristics: string[];
}

export type ModelFamily =
  | 'gan'
  | 'diffusion'
  | 'vae'
  | 'autoregressive'
  | 'transformer'
  | 'cnn'
  | 'hybrid'
  | 'unknown';

export interface GeneratorInfo {
  /** Generator name */
  name: string;
  /** Developer */
  developer: string;
  /** Release date (approximate) */
  releaseDate?: string;
  /** Model versions that match */
  matchingVersions: string[];
  /** Match confidence */
  confidence: number;
  /** Supporting evidence */
  evidence: string[];
}

export interface NeuralFingerprint {
  /** Fingerprint type */
  type: FingerprintType;
  /** Description */
  description: string;
  /** Confidence */
  confidence: number;
  /** Detected values */
  values: Record<string, number>;
}

export type FingerprintType =
  | 'upsampling_artifact'
  | 'convolution_pattern'
  | 'normalization_trace'
  | 'attention_pattern'
  | 'activation_signature'
  | 'loss_function_trace'
  | 'noise_injection'
  | 'quantization_artifact';

export interface FeatureAnalysis {
  /** Spatial frequency analysis */
  spatialFrequency: SpatialFrequencyAnalysis;
  /** Color distribution analysis */
  colorDistribution: ColorDistributionAnalysis;
  /** Texture analysis */
  texture: TextureAnalysis;
  /** Edge analysis */
  edges: EdgeAnalysis;
  /** Artifact detection */
  artifacts: ArtifactAnalysis;
}

export interface SpatialFrequencyAnalysis {
  /** Frequency spectrum */
  spectrum: number[];
  /** Dominant frequencies */
  dominantFrequencies: number[];
  /** Frequency decay rate */
  decayRate: number;
  /** Spectral flatness */
  spectralFlatness: number;
  /** High frequency ratio */
  highFrequencyRatio: number;
}

export interface ColorDistributionAnalysis {
  /** Color histogram statistics */
  histogramStats: {
    mean: number[];
    std: number[];
    skewness: number[];
    kurtosis: number[];
  };
  /** Color gamut coverage */
  gamutCoverage: number;
  /** Saturation distribution */
  saturationStats: { mean: number; std: number };
  /** Luminance distribution */
  luminanceStats: { mean: number; std: number };
}

export interface TextureAnalysis {
  /** GLCM features */
  glcmFeatures: {
    contrast: number;
    dissimilarity: number;
    homogeneity: number;
    energy: number;
    correlation: number;
  };
  /** Local binary pattern histogram */
  lbpHistogram: number[];
  /** Texture regularity */
  regularity: number;
}

export interface EdgeAnalysis {
  /** Edge density */
  density: number;
  /** Edge continuity */
  continuity: number;
  /** Edge sharpness */
  sharpness: number;
  /** Edge orientation distribution */
  orientationDistribution: number[];
}

export interface ArtifactAnalysis {
  /** Checkerboard artifacts */
  checkerboard: number;
  /** Ringing artifacts */
  ringing: number;
  /** Compression artifacts */
  compression: number;
  /** Upsampling artifacts */
  upsampling: number;
  /** Color banding */
  colorBanding: number;
}

export interface ArchitectureSignature {
  /** Signature name */
  name: string;
  /** Match score */
  matchScore: number;
  /** Evidence */
  evidence: string[];
  /** Model architecture */
  architecture: string;
}

export interface ImageData {
  /** Width */
  width: number;
  /** Height */
  height: number;
  /** RGB pixel data (row-major) */
  data: number[][];
}

// ============================================================================
// KNOWN ARCHITECTURE SIGNATURES
// ============================================================================

/**
 * Known AI model architecture signatures
 */
const ARCHITECTURE_SIGNATURES: Array<{
  name: string;
  family: ModelFamily;
  versions: string[];
  detect: (features: FeatureAnalysis) => { match: number; evidence: string[] };
  characteristics: string[];
}> = [
  {
    name: 'StyleGAN',
    family: 'gan',
    versions: ['stylegan1', 'stylegan2', 'stylegan2-ada', 'stylegan3'],
    detect: (features) => {
      const evidence: string[] = [];
      let match = 0;

      // StyleGAN specific: smooth frequency decay
      if (features.spatialFrequency.decayRate > 0.8) {
        match += 0.3;
        evidence.push('Smooth frequency decay pattern');
      }

      // High texture regularity
      if (features.texture.regularity > 0.7) {
        match += 0.2;
        evidence.push('High texture regularity');
      }

      // Specific color distribution
      if (features.colorDistribution.saturationStats.std < 0.15) {
        match += 0.2;
        evidence.push('Uniform saturation distribution');
      }

      // Low checkerboard artifacts
      if (features.artifacts.checkerboard < 0.1) {
        match += 0.2;
        evidence.push('Minimal checkerboard artifacts');
      }

      // Strong edge continuity
      if (features.edges.continuity > 0.8) {
        match += 0.1;
        evidence.push('Strong edge continuity');
      }

      return { match: Math.min(1, match), evidence };
    },
    characteristics: ['Adaptive instance normalization', 'Progressive growing', 'Style mixing']
  },
  {
    name: 'Stable Diffusion',
    family: 'diffusion',
    versions: ['sd-1.4', 'sd-1.5', 'sd-2.0', 'sd-2.1', 'sdxl', 'sd3'],
    detect: (features) => {
      const evidence: string[] = [];
      let match = 0;

      // Diffusion specific: gradual noise pattern
      if (features.spatialFrequency.highFrequencyRatio > 0.3) {
        match += 0.25;
        evidence.push('High frequency noise pattern');
      }

      // Texture characteristics
      if (features.texture.glcmFeatures.homogeneity > 0.6) {
        match += 0.2;
        evidence.push('Diffusion texture homogeneity');
      }

      // Color distribution
      if (features.colorDistribution.gamutCoverage > 0.7) {
        match += 0.2;
        evidence.push('Wide color gamut');
      }

      // Edge characteristics
      if (features.edges.sharpness < 0.6 && features.edges.sharpness > 0.3) {
        match += 0.15;
        evidence.push('Moderate edge sharpness');
      }

      // Upsampling artifacts from VAE
      if (features.artifacts.upsampling > 0.1) {
        match += 0.2;
        evidence.push('VAE upsampling artifacts');
      }

      return { match: Math.min(1, match), evidence };
    },
    characteristics: ['Latent diffusion', 'U-Net backbone', 'Cross-attention', 'VAE encoder/decoder']
  },
  {
    name: 'DALL-E',
    family: 'autoregressive',
    versions: ['dall-e-1', 'dall-e-2', 'dall-e-3'],
    detect: (features) => {
      const evidence: string[] = [];
      let match = 0;

      // DALL-E specific: pixel-level artifacts from VQ-VAE
      if (features.texture.regularity > 0.5 && features.texture.regularity < 0.8) {
        match += 0.25;
        evidence.push('VQ-VAE texture pattern');
      }

      // Color distribution
      if (features.colorDistribution.histogramStats.kurtosis[0] > 3) {
        match += 0.2;
        evidence.push('Peaked color distribution');
      }

      // Edge characteristics
      if (features.edges.density > 0.3) {
        match += 0.2;
        evidence.push('High edge density');
      }

      // Spectral characteristics
      if (features.spatialFrequency.spectralFlatness < 0.3) {
        match += 0.2;
        evidence.push('Non-flat spectrum (autoregressive)');
      }

      return { match: Math.min(1, match), evidence };
    },
    characteristics: ['VQ-VAE tokenizer', 'Transformer decoder', 'Autoregressive generation']
  },
  {
    name: 'Midjourney',
    family: 'diffusion',
    versions: ['v4', 'v5', 'v5.1', 'v5.2', 'v6'],
    detect: (features) => {
      const evidence: string[] = [];
      let match = 0;

      // Midjourney specific: artistic style signatures
      if (features.colorDistribution.saturationStats.mean > 0.4) {
        match += 0.25;
        evidence.push('High average saturation (artistic)');
      }

      // Texture smoothness
      if (features.texture.glcmFeatures.contrast < 0.3) {
        match += 0.25;
        evidence.push('Smooth texture rendering');
      }

      // Edge softness
      if (features.edges.sharpness < 0.5) {
        match += 0.2;
        evidence.push('Soft edge rendering');
      }

      // High frequency content
      if (features.spatialFrequency.highFrequencyRatio < 0.4) {
        match += 0.15;
        evidence.push('Reduced high frequency content');
      }

      return { match: Math.min(1, match), evidence };
    },
    characteristics: ['Proprietary diffusion model', 'Artistic style tuning', 'High aesthetic quality']
  },
  {
    name: 'ProGAN',
    family: 'gan',
    versions: ['progan-celeba', 'progan-lsun'],
    detect: (features) => {
      const evidence: string[] = [];
      let match = 0;

      // Progressive growing artifacts
      if (features.artifacts.checkerboard > 0.15) {
        match += 0.3;
        evidence.push('Checkerboard artifacts from progressive growing');
      }

      // Scale-specific texture
      if (features.texture.regularity < 0.5) {
        match += 0.2;
        evidence.push('Scale-varying texture');
      }

      // Edge characteristics
      if (features.edges.continuity < 0.7) {
        match += 0.2;
        evidence.push('Edge discontinuities');
      }

      return { match: Math.min(1, match), evidence };
    },
    characteristics: ['Progressive growing', 'ToRGB layers', 'Minibatch discrimination']
  },
  {
    name: 'BigGAN',
    family: 'gan',
    versions: ['biggan-deep', 'biggan-512'],
    detect: (features) => {
      const evidence: string[] = [];
      let match = 0;

      // BigGAN specific: class-conditional artifacts
      if (features.colorDistribution.gamutCoverage > 0.8) {
        match += 0.25;
        evidence.push('Wide color gamut');
      }

      // High texture quality
      if (features.texture.glcmFeatures.correlation > 0.7) {
        match += 0.25;
        evidence.push('High texture correlation');
      }

      // Spectral characteristics
      if (features.spatialFrequency.decayRate < 0.7) {
        match += 0.2;
        evidence.push('Moderate frequency decay');
      }

      return { match: Math.min(1, match), evidence };
    },
    characteristics: ['Class-conditional', 'Self-attention', 'Large batch training']
  },
  {
    name: 'VQ-VAE',
    family: 'vae',
    versions: ['vq-vae-1', 'vq-vae-2'],
    detect: (features) => {
      const evidence: string[] = [];
      let match = 0;

      // VQ-VAE specific: quantization artifacts
      if (features.artifacts.colorBanding > 0.2) {
        match += 0.35;
        evidence.push('Color banding from quantization');
      }

      // Texture blocks
      if (features.texture.regularity > 0.6) {
        match += 0.25;
        evidence.push('Blocky texture pattern');
      }

      // Compression artifacts
      if (features.artifacts.compression > 0.3) {
        match += 0.2;
        evidence.push('Latent compression artifacts');
      }

      return { match: Math.min(1, match), evidence };
    },
    characteristics: ['Vector quantization', 'Discrete latent space', 'Codebook learning']
  }
];

// ============================================================================
// NEURAL FINGERPRINT ANALYZER
// ============================================================================

/**
 * Neural Architecture Fingerprint Analyzer
 * Identifies AI model architectures from generated images
 */
export class NeuralFingerprintAnalyzer {
  private config: FingerprintConfig;

  constructor(config: Partial<FingerprintConfig> = {}) {
    this.config = {
      frequencyBins: config.frequencyBins || 256,
      glcmDistance: config.glcmDistance || 1,
      lbpRadius: config.lbpRadius || 1,
      edgeThreshold: config.edgeThreshold || 30,
      ...config
    };
  }

  /**
   * Analyze image for neural architecture fingerprints
   */
  analyze(imageData: ImageData): NeuralFingerprintResult {
    const id = `neural_fp_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const startTime = Date.now();

    // Phase 1: Extract all features
    const features = this.extractAllFeatures(imageData);

    // Phase 2: Detect fingerprints
    const fingerprints = this.detectFingerprints(features);

    // Phase 3: Match architecture signatures
    const signatures = this.matchArchitectureSignatures(features);

    // Phase 4: Identify best architecture match
    const architecture = this.identifyArchitecture(signatures, features);

    // Phase 5: Attribute generator
    const generator = this.attributeGenerator(signatures, architecture);

    // Calculate overall confidence
    const confidence = this.calculateConfidence(signatures, fingerprints);

    return {
      id,
      timestamp: startTime,
      confidence,
      architecture,
      generator,
      fingerprints,
      features,
      signatures,
      recommendations: this.generateRecommendations(architecture, generator, confidence)
    };
  }

  /**
   * Extract all features from image
   */
  private extractAllFeatures(imageData: ImageData): FeatureAnalysis {
    const grayscale = this.toGrayscale(imageData);

    return {
      spatialFrequency: this.analyzeSpatialFrequency(grayscale, imageData.width),
      colorDistribution: this.analyzeColorDistribution(imageData),
      texture: this.analyzeTexture(grayscale, imageData.width),
      edges: this.analyzeEdges(grayscale, imageData.width),
      artifacts: this.analyzeArtifacts(grayscale, imageData.width, imageData.height)
    };
  }

  /**
   * Analyze spatial frequency characteristics
   */
  private analyzeSpatialFrequency(grayscale: number[], width: number): SpatialFrequencyAnalysis {
    // Perform 2D FFT
    const spectrum = this.performFFT2D(grayscale, width);

    // Calculate frequency statistics
    const decayRate = this.calculateFrequencyDecay(spectrum);
    const spectralFlatness = this.calculateSpectralFlatness(spectrum);
    const highFrequencyRatio = this.calculateHighFrequencyRatio(spectrum);

    // Find dominant frequencies
    const dominantFrequencies = this.findDominantFrequencies(spectrum, 5);

    return {
      spectrum,
      dominantFrequencies,
      decayRate,
      spectralFlatness,
      highFrequencyRatio
    };
  }

  /**
   * Perform 2D FFT (simplified)
   */
  private performFFT2D(data: number[], width: number): number[] {
    const height = data.length / width;
    const spectrum: number[] = [];

    // Simplified 2D DFT for frequency analysis
    const size = Math.min(width, Math.floor(Math.sqrt(data.length)));

    for (let kx = 0; kx < size; kx++) {
      for (let ky = 0; ky < size; ky++) {
        let real = 0;
        let imag = 0;

        for (let x = 0; x < size; x++) {
          for (let y = 0; y < size; y++) {
            const idx = y * width + x;
            const angle = 2 * Math.PI * (kx * x / size + ky * y / size);
            real += (data[idx] || 0) * Math.cos(angle);
            imag -= (data[idx] || 0) * Math.sin(angle);
          }
        }

        spectrum.push(Math.sqrt(real * real + imag * imag));
      }
    }

    return spectrum;
  }

  /**
   * Calculate frequency decay rate
   */
  private calculateFrequencyDecay(spectrum: number[]): number {
    if (spectrum.length < 2) return 0;

    const sortedSpectrum = [...spectrum].sort((a, b) => b - a);
    let decaySum = 0;

    for (let i = 1; i < Math.min(sortedSpectrum.length, 100); i++) {
      if (sortedSpectrum[i - 1] > 0) {
        decaySum += sortedSpectrum[i] / sortedSpectrum[i - 1];
      }
    }

    return decaySum / Math.min(sortedSpectrum.length - 1, 99);
  }

  /**
   * Calculate spectral flatness
   */
  private calculateSpectralFlatness(spectrum: number[]): number {
    const positiveSpectrum = spectrum.filter(s => s > 0);
    if (positiveSpectrum.length === 0) return 0;

    const geometricMean = Math.exp(
      positiveSpectrum.reduce((a, b) => a + Math.log(b), 0) / positiveSpectrum.length
    );
    const arithmeticMean = positiveSpectrum.reduce((a, b) => a + b, 0) / positiveSpectrum.length;

    return arithmeticMean > 0 ? geometricMean / arithmeticMean : 0;
  }

  /**
   * Calculate high frequency ratio
   */
  private calculateHighFrequencyRatio(spectrum: number[]): number {
    if (spectrum.length < 10) return 0;

    const totalEnergy = spectrum.reduce((a, b) => a + b, 0);
    const highFreqEnergy = spectrum.slice(Math.floor(spectrum.length * 0.7)).reduce((a, b) => a + b, 0);

    return totalEnergy > 0 ? highFreqEnergy / totalEnergy : 0;
  }

  /**
   * Find dominant frequencies
   */
  private findDominantFrequencies(spectrum: number[], count: number): number[] {
    const indexed = spectrum.map((v, i) => ({ value: v, index: i }));
    indexed.sort((a, b) => b.value - a.value);

    return indexed.slice(0, count).map(item => item.index);
  }

  /**
   * Analyze color distribution
   */
  private analyzeColorDistribution(imageData: ImageData): ColorDistributionAnalysis {
    const rValues: number[] = [];
    const gValues: number[] = [];
    const bValues: number[] = [];

    for (const row of imageData.data) {
      if (!row) continue;
      for (let i = 0; i < row.length; i += 3) {
        rValues.push((row[i] || 0) / 255);
        gValues.push((row[i + 1] || 0) / 255);
        bValues.push((row[i + 2] || 0) / 255);
      }
    }

    // Calculate histogram statistics
    const histogramStats = {
      mean: [
        rValues.reduce((a, b) => a + b, 0) / rValues.length,
        gValues.reduce((a, b) => a + b, 0) / gValues.length,
        bValues.reduce((a, b) => a + b, 0) / bValues.length
      ],
      std: [
        Math.sqrt(this.calculateVariance(rValues)),
        Math.sqrt(this.calculateVariance(gValues)),
        Math.sqrt(this.calculateVariance(bValues))
      ],
      skewness: [
        this.calculateSkewness(rValues),
        this.calculateSkewness(gValues),
        this.calculateSkewness(bValues)
      ],
      kurtosis: [
        this.calculateKurtosis(rValues),
        this.calculateKurtosis(gValues),
        this.calculateKurtosis(bValues)
      ]
    };

    // Calculate gamut coverage
    const uniqueColors = new Set<string>();
    for (const row of imageData.data) {
      if (!row) continue;
      for (let i = 0; i < row.length; i += 3) {
        const r = Math.floor((row[i] || 0) / 16);
        const g = Math.floor((row[i + 1] || 0) / 16);
        const b = Math.floor((row[i + 2] || 0) / 16);
        uniqueColors.add(`${r},${g},${b}`);
      }
    }
    const gamutCoverage = uniqueColors.size / (16 * 16 * 16);

    // Calculate saturation
    const saturations: number[] = [];
    const luminances: number[] = [];

    for (let i = 0; i < rValues.length; i++) {
      const r = rValues[i];
      const g = gValues[i];
      const b = bValues[i];

      const max = Math.max(r, g, b);
      const min = Math.min(r, g, b);
      const l = (max + min) / 2;

      const s = l > 0 && l < 1 ? (max - min) / (1 - Math.abs(2 * l - 1)) : 0;
      saturations.push(s);
      luminances.push(l);
    }

    return {
      histogramStats,
      gamutCoverage,
      saturationStats: {
        mean: saturations.reduce((a, b) => a + b, 0) / saturations.length,
        std: Math.sqrt(this.calculateVariance(saturations))
      },
      luminanceStats: {
        mean: luminances.reduce((a, b) => a + b, 0) / luminances.length,
        std: Math.sqrt(this.calculateVariance(luminances))
      }
    };
  }

  /**
   * Analyze texture characteristics
   */
  private analyzeTexture(grayscale: number[], width: number): TextureAnalysis {
    const glcmFeatures = this.calculateGLCMFeatures(grayscale, width);
    const lbpHistogram = this.calculateLBPHistogram(grayscale, width);
    const regularity = this.calculateTextureRegularity(grayscale, width);

    return {
      glcmFeatures,
      lbpHistogram,
      regularity
    };
  }

  /**
   * Calculate GLCM features
   */
  private calculateGLCMFeatures(grayscale: number[], width: number): {
    contrast: number;
    dissimilarity: number;
    homogeneity: number;
    energy: number;
    correlation: number;
  } {
    const height = Math.floor(grayscale.length / width);
    const glcm: number[][] = Array(16).fill(null).map(() => Array(16).fill(0));
    let total = 0;

    // Build co-occurrence matrix
    for (let y = 0; y < height - 1; y++) {
      for (let x = 0; x < width - 1; x++) {
        const idx = y * width + x;
        const i = Math.floor((grayscale[idx] || 0) / 16);
        const j = Math.floor((grayscale[idx + 1] || 0) / 16);
        glcm[i][j]++;
        total++;
      }
    }

    // Normalize
    for (let i = 0; i < 16; i++) {
      for (let j = 0; j < 16; j++) {
        glcm[i][j] /= total;
      }
    }

    // Calculate features
    let contrast = 0;
    let dissimilarity = 0;
    let homogeneity = 0;
    let energy = 0;
    let correlation = 0;

    const meanI = this.matrixMean(glcm, 'row');
    const meanJ = this.matrixMean(glcm, 'col');
    const stdI = Math.sqrt(this.matrixVariance(glcm, 'row', meanI));
    const stdJ = Math.sqrt(this.matrixVariance(glcm, 'col', meanJ));

    for (let i = 0; i < 16; i++) {
      for (let j = 0; j < 16; j++) {
        const p = glcm[i][j];
        contrast += p * (i - j) ** 2;
        dissimilarity += p * Math.abs(i - j);
        homogeneity += p / (1 + Math.abs(i - j));
        energy += p * p;
        correlation += (i - meanI) * (j - meanJ) * p / (stdI * stdJ + 0.001);
      }
    }

    return { contrast, dissimilarity, homogeneity, energy, correlation };
  }

  /**
   * Calculate matrix mean
   */
  private matrixMean(matrix: number[][], dim: 'row' | 'col'): number {
    let sum = 0;
    let count = 0;

    for (let i = 0; i < matrix.length; i++) {
      for (let j = 0; j < matrix[i].length; j++) {
        sum += dim === 'row' ? i * matrix[i][j] : j * matrix[i][j];
        count++;
      }
    }

    return sum / count;
  }

  /**
   * Calculate matrix variance
   */
  private matrixVariance(matrix: number[][], dim: 'row' | 'col', mean: number): number {
    let sum = 0;
    let count = 0;

    for (let i = 0; i < matrix.length; i++) {
      for (let j = 0; j < matrix[i].length; j++) {
        const val = dim === 'row' ? i : j;
        sum += (val - mean) ** 2 * matrix[i][j];
        count++;
      }
    }

    return sum / count;
  }

  /**
   * Calculate LBP histogram
   */
  private calculateLBPHistogram(grayscale: number[], width: number): number[] {
    const height = Math.floor(grayscale.length / width);
    const histogram: number[] = new Array(256).fill(0);

    for (let y = 1; y < height - 1; y++) {
      for (let x = 1; x < width - 1; x++) {
        const center = grayscale[y * width + x] || 0;
        let lbp = 0;

        const neighbors = [
          grayscale[(y - 1) * width + (x - 1)] || 0,
          grayscale[(y - 1) * width + x] || 0,
          grayscale[(y - 1) * width + (x + 1)] || 0,
          grayscale[y * width + (x + 1)] || 0,
          grayscale[(y + 1) * width + (x + 1)] || 0,
          grayscale[(y + 1) * width + x] || 0,
          grayscale[(y + 1) * width + (x - 1)] || 0,
          grayscale[y * width + (x - 1)] || 0
        ];

        for (let i = 0; i < 8; i++) {
          if (neighbors[i] >= center) {
            lbp |= 1 << i;
          }
        }

        histogram[lbp]++;
      }
    }

    // Normalize
    const total = histogram.reduce((a, b) => a + b, 0);
    return histogram.map(v => v / total);
  }

  /**
   * Calculate texture regularity
   */
  private calculateTextureRegularity(grayscale: number[], width: number): number {
    const height = Math.floor(grayscale.length / width);
    const blockSize = 16;
    const blockStats: number[] = [];

    for (let by = 0; by < height - blockSize; by += blockSize) {
      for (let bx = 0; bx < width - blockSize; bx += blockSize) {
        let mean = 0;
        let variance = 0;
        let count = 0;

        // Calculate block mean
        for (let y = by; y < by + blockSize; y++) {
          for (let x = bx; x < bx + blockSize; x++) {
            mean += grayscale[y * width + x] || 0;
            count++;
          }
        }
        mean /= count;

        // Calculate block variance
        for (let y = by; y < by + blockSize; y++) {
          for (let x = bx; x < bx + blockSize; x++) {
            variance += ((grayscale[y * width + x] || 0) - mean) ** 2;
          }
        }
        variance /= count;

        blockStats.push(variance);
      }
    }

    // Regularity is inverse of variance of block stats
    const statsVariance = this.calculateVariance(blockStats);
    return 1 / (1 + statsVariance / 1000);
  }

  /**
   * Analyze edge characteristics
   */
  private analyzeEdges(grayscale: number[], width: number): EdgeAnalysis {
    const height = Math.floor(grayscale.length / width);
    const edges: number[] = [];

    // Sobel edge detection
    const sobelX = [-1, 0, 1, -2, 0, 2, -1, 0, 1];
    const sobelY = [-1, -2, -1, 0, 0, 0, 1, 2, 1];

    for (let y = 1; y < height - 1; y++) {
      for (let x = 1; x < width - 1; x++) {
        let gx = 0;
        let gy = 0;

        for (let ky = -1; ky <= 1; ky++) {
          for (let kx = -1; kx <= 1; kx++) {
            const idx = (y + ky) * width + (x + kx);
            const ki = (ky + 1) * 3 + (kx + 1);
            const pixel = grayscale[idx] || 0;
            gx += pixel * sobelX[ki];
            gy += pixel * sobelY[ki];
          }
        }

        const magnitude = Math.sqrt(gx * gx + gy * gy);
        edges.push(magnitude);
      }
    }

    // Calculate edge density
    const threshold = this.config.edgeThreshold;
    const edgePixels = edges.filter(e => e > threshold).length;
    const density = edgePixels / edges.length;

    // Calculate edge continuity
    const continuity = this.calculateEdgeContinuity(edges, width - 2, threshold);

    // Calculate edge sharpness
    const sharpness = this.calculateEdgeSharpness(edges);

    // Calculate orientation distribution
    const orientationDistribution = this.calculateOrientationDistribution(grayscale, width);

    return {
      density,
      continuity,
      sharpness,
      orientationDistribution
    };
  }

  /**
   * Calculate edge continuity
   */
  private calculateEdgeContinuity(edges: number[], width: number, threshold: number): number {
    let continuous = 0;
    let total = 0;

    for (let y = 0; y < edges.length / width - 1; y++) {
      for (let x = 0; x < width - 1; x++) {
        const idx = y * width + x;
        const current = edges[idx] > threshold;
        const right = edges[idx + 1] > threshold;
        const below = edges[idx + width] > threshold;

        if (current) {
          total++;
          if (right || below) {
            continuous++;
          }
        }
      }
    }

    return total > 0 ? continuous / total : 0;
  }

  /**
   * Calculate edge sharpness
   */
  private calculateEdgeSharpness(edges: number[]): number {
    const sorted = [...edges].sort((a, b) => b - a);
    const top10Percent = sorted.slice(0, Math.floor(sorted.length * 0.1));
    const avgTop = top10Percent.reduce((a, b) => a + b, 0) / top10Percent.length;
    const avgAll = edges.reduce((a, b) => a + b, 0) / edges.length;

    return avgAll > 0 ? avgTop / avgAll : 0;
  }

  /**
   * Calculate orientation distribution
   */
  private calculateOrientationDistribution(grayscale: number[], width: number): number[] {
    const histogram = new Array(8).fill(0);
    const height = Math.floor(grayscale.length / width);

    for (let y = 1; y < height - 1; y++) {
      for (let x = 1; x < width - 1; x++) {
        const gx = (grayscale[y * width + x + 1] || 0) - (grayscale[y * width + x - 1] || 0);
        const gy = (grayscale[(y + 1) * width + x] || 0) - (grayscale[(y - 1) * width + x] || 0);

        let angle = Math.atan2(gy, gx);
        if (angle < 0) angle += Math.PI;

        const bin = Math.floor(angle / (Math.PI / 8));
        histogram[Math.min(bin, 7)]++;
      }
    }

    const total = histogram.reduce((a, b) => a + b, 0);
    return histogram.map(v => v / total);
  }

  /**
   * Analyze artifacts
   */
  private analyzeArtifacts(grayscale: number[], width: number, height: number): ArtifactAnalysis {
    const checkerboard = this.detectCheckerboard(grayscale, width);
    const ringing = this.detectRinging(grayscale, width);
    const compression = this.detectCompression(grayscale, width);
    const upsampling = this.detectUpsampling(grayscale, width);
    const colorBanding = this.detectColorBanding(grayscale);

    return {
      checkerboard,
      ringing,
      compression,
      upsampling,
      colorBanding
    };
  }

  /**
   * Detect checkerboard artifacts
   */
  private detectCheckerboard(grayscale: number[], width: number): number {
    const height = Math.floor(grayscale.length / width);
    let score = 0;
    let count = 0;

    for (let y = 1; y < height - 1; y += 2) {
      for (let x = 1; x < width - 1; x += 2) {
        const center = grayscale[y * width + x] || 0;
        const neighbors = [
          grayscale[(y - 1) * width + x] || 0,
          grayscale[(y + 1) * width + x] || 0,
          grayscale[y * width + x - 1] || 0,
          grayscale[y * width + x + 1] || 0
        ];

        const avgNeighbor = neighbors.reduce((a, b) => a + b, 0) / 4;
        score += Math.abs(center - avgNeighbor);
        count++;
      }
    }

    // Normalize
    return count > 0 ? (score / count) / 255 : 0;
  }

  /**
   * Detect ringing artifacts
   */
  private detectRinging(grayscale: number[], width: number): number {
    const height = Math.floor(grayscale.length / width);
    let score = 0;
    let count = 0;

    for (let y = 2; y < height - 2; y++) {
      for (let x = 2; x < width - 2; x++) {
        const center = grayscale[y * width + x] || 0;
        const left = grayscale[y * width + x - 2] || 0;
        const right = grayscale[y * width + x + 2] || 0;

        // Ringing creates oscillation pattern
        if ((center > left && center > right) || (center < left && center < right)) {
          score += Math.abs(center - (left + right) / 2);
        }
        count++;
      }
    }

    return count > 0 ? (score / count) / 255 : 0;
  }

  /**
   * Detect compression artifacts
   */
  private detectCompression(grayscale: number[], width: number): number {
    // Detect 8x8 blocking
    const height = Math.floor(grayscale.length / width);
    let score = 0;
    let count = 0;

    for (let by = 8; by < height; by += 8) {
      for (let x = 0; x < width; x++) {
        const above = grayscale[(by - 1) * width + x] || 0;
        const below = grayscale[by * width + x] || 0;
        score += Math.abs(above - below);
        count++;
      }
    }

    return count > 0 ? (score / count) / 255 : 0;
  }

  /**
   * Detect upsampling artifacts
   */
  private detectUpsampling(grayscale: number[], width: number): number {
    // Detect blurring patterns from upsampling
    const height = Math.floor(grayscale.length / width);
    let score = 0;
    let count = 0;

    for (let y = 1; y < height - 1; y++) {
      for (let x = 1; x < width - 1; x++) {
        const center = grayscale[y * width + x] || 0;
        const neighbors = [
          grayscale[(y - 1) * width + x] || 0,
          grayscale[(y + 1) * width + x] || 0,
          grayscale[y * width + x - 1] || 0,
          grayscale[y * width + x + 1] || 0
        ];

        const avgNeighbor = neighbors.reduce((a, b) => a + b, 0) / 4;

        // Upsampled images have very similar neighbors
        if (Math.abs(center - avgNeighbor) < 2) {
          score++;
        }
        count++;
      }
    }

    return count > 0 ? score / count : 0;
  }

  /**
   * Detect color banding
   */
  private detectColorBanding(grayscale: number[]): number {
    // Count distinct gray levels
    const histogram = new Map<number, number>();

    for (const pixel of grayscale) {
      const level = Math.round(pixel);
      histogram.set(level, (histogram.get(level) || 0) + 1);
    }

    // Banding indicated by few distinct levels with high counts
    const levels = histogram.size;
    const expectedLevels = 256;

    return 1 - (levels / expectedLevels);
  }

  /**
   * Detect neural fingerprints
   */
  private detectFingerprints(features: FeatureAnalysis): NeuralFingerprint[] {
    const fingerprints: NeuralFingerprint[] = [];

    // Upsampling artifacts
    if (features.artifacts.upsampling > 0.3) {
      fingerprints.push({
        type: 'upsampling_artifact',
        description: 'Strong upsampling artifacts detected',
        confidence: features.artifacts.upsampling,
        values: { upsamplingScore: features.artifacts.upsampling }
      });
    }

    // Convolution patterns
    if (features.texture.glcmFeatures.correlation > 0.8) {
      fingerprints.push({
        type: 'convolution_pattern',
        description: 'Strong convolution patterns detected',
        confidence: features.texture.glcmFeatures.correlation,
        values: { correlation: features.texture.glcmFeatures.correlation }
      });
    }

    // Normalization traces
    if (features.colorDistribution.saturationStats.std < 0.1) {
      fingerprints.push({
        type: 'normalization_trace',
        description: 'Normalization artifacts in saturation',
        confidence: 1 - features.colorDistribution.saturationStats.std,
        values: { saturationStd: features.colorDistribution.saturationStats.std }
      });
    }

    // Attention patterns (for transformers)
    if (features.spatialFrequency.spectralFlatness < 0.2) {
      fingerprints.push({
        type: 'attention_pattern',
        description: 'Attention-based spectral pattern detected',
        confidence: 1 - features.spatialFrequency.spectralFlatness,
        values: { spectralFlatness: features.spatialFrequency.spectralFlatness }
      });
    }

    // Quantization artifacts
    if (features.artifacts.colorBanding > 0.3) {
      fingerprints.push({
        type: 'quantization_artifact',
        description: 'Color quantization artifacts detected',
        confidence: features.artifacts.colorBanding,
        values: { colorBanding: features.artifacts.colorBanding }
      });
    }

    return fingerprints;
  }

  /**
   * Match architecture signatures
   */
  private matchArchitectureSignatures(features: FeatureAnalysis): ArchitectureSignature[] {
    const signatures: ArchitectureSignature[] = [];

    for (const signature of ARCHITECTURE_SIGNATURES) {
      const result = signature.detect(features);

      if (result.match > 0.3) {
        signatures.push({
          name: signature.name,
          matchScore: result.match,
          evidence: result.evidence,
          architecture: signature.family
        });
      }
    }

    // Sort by match score
    signatures.sort((a, b) => b.matchScore - a.matchScore);

    return signatures;
  }

  /**
   * Identify architecture
   */
  private identifyArchitecture(
    signatures: ArchitectureSignature[],
    features: FeatureAnalysis
  ): ModelArchitecture | null {
    if (signatures.length === 0) return null;

    const best = signatures[0];
    if (best.matchScore < 0.4) return null;

    const signature = ARCHITECTURE_SIGNATURES.find(s => s.name === best.name);
    if (!signature) return null;

    return {
      name: best.name,
      family: signature.family,
      version: signature.versions[0],
      confidence: best.matchScore,
      estimatedParams: this.estimateParameters(signature.family, features),
      characteristics: signature.characteristics
    };
  }

  /**
   * Estimate model parameters
   */
  private estimateParameters(family: ModelFamily, features: FeatureAnalysis): string {
    const paramEstimates: Record<ModelFamily, string> = {
      'gan': '10M - 100M parameters',
      'diffusion': '500M - 3B parameters',
      'vae': '10M - 100M parameters',
      'autoregressive': '1B - 20B parameters',
      'transformer': '1B - 10B parameters',
      'cnn': '10M - 200M parameters',
      'hybrid': '500M - 5B parameters',
      'unknown': 'Unknown'
    };

    return paramEstimates[family] || 'Unknown';
  }

  /**
   * Attribute generator
   */
  private attributeGenerator(
    signatures: ArchitectureSignature[],
    architecture: ModelArchitecture | null
  ): GeneratorInfo | null {
    if (signatures.length === 0) return null;

    const best = signatures[0];
    const signature = ARCHITECTURE_SIGNATURES.find(s => s.name === best.name);
    if (!signature) return null;

    const generatorNames: Record<string, { developer: string; releaseDate: string }> = {
      'StyleGAN': { developer: 'NVIDIA', releaseDate: '2018-2021' },
      'Stable Diffusion': { developer: 'Stability AI', releaseDate: '2022-2023' },
      'DALL-E': { developer: 'OpenAI', releaseDate: '2021-2023' },
      'Midjourney': { developer: 'Midjourney', releaseDate: '2022-2024' },
      'ProGAN': { developer: 'NVIDIA', releaseDate: '2017' },
      'BigGAN': { developer: 'DeepMind', releaseDate: '2018' },
      'VQ-VAE': { developer: 'DeepMind', releaseDate: '2017-2019' }
    };

    const info = generatorNames[best.name] || { developer: 'Unknown', releaseDate: 'Unknown' };

    return {
      name: best.name,
      developer: info.developer,
      releaseDate: info.releaseDate,
      matchingVersions: signature.versions,
      confidence: best.matchScore,
      evidence: best.evidence
    };
  }

  /**
   * Calculate overall confidence
   */
  private calculateConfidence(
    signatures: ArchitectureSignature[],
    fingerprints: NeuralFingerprint[]
  ): number {
    if (signatures.length === 0) return 0;

    const bestSignature = signatures[0].matchScore;
    const fingerprintSupport = fingerprints.length > 0 ? 0.2 : 0;

    return Math.min(1, bestSignature + fingerprintSupport);
  }

  /**
   * Generate recommendations
   */
  private generateRecommendations(
    architecture: ModelArchitecture | null,
    generator: GeneratorInfo | null,
    confidence: number
  ): string[] {
    const recommendations: string[] = [];

    if (architecture) {
      recommendations.push(`Suspected architecture: ${architecture.name} (${architecture.family})`);
      recommendations.push(`Confidence: ${(confidence * 100).toFixed(1)}%`);

      if (generator) {
        recommendations.push(`Developer: ${generator.developer}`);
        if (generator.releaseDate) {
          recommendations.push(`Release period: ${generator.releaseDate}`);
        }
      }

      if (architecture.characteristics.length > 0) {
        recommendations.push(`Key characteristics: ${architecture.characteristics.join(', ')}`);
      }
    } else {
      recommendations.push('No clear architecture signature detected');
      recommendations.push('Image may be from an unknown or novel architecture');
    }

    return recommendations;
  }

  /**
   * Convert to grayscale
   */
  private toGrayscale(imageData: ImageData): number[] {
    const grayscale: number[] = [];

    for (const row of imageData.data) {
      if (!row) continue;
      for (let i = 0; i < row.length; i += 3) {
        const r = row[i] || 0;
        const g = row[i + 1] || 0;
        const b = row[i + 2] || 0;
        grayscale.push(0.299 * r + 0.587 * g + 0.114 * b);
      }
    }

    return grayscale;
  }

  /**
   * Calculate variance
   */
  private calculateVariance(values: number[]): number {
    if (values.length === 0) return 0;
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    return values.reduce((a, b) => a + (b - mean) ** 2, 0) / values.length;
  }

  /**
   * Calculate skewness
   */
  private calculateSkewness(values: number[]): number {
    if (values.length === 0) return 0;
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    const std = Math.sqrt(this.calculateVariance(values));

    if (std === 0) return 0;

    const m3 = values.reduce((a, b) => a + ((b - mean) ** 3), 0) / values.length;
    return m3 / (std ** 3);
  }

  /**
   * Calculate kurtosis
   */
  private calculateKurtosis(values: number[]): number {
    if (values.length === 0) return 0;
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    const variance = this.calculateVariance(values);

    if (variance === 0) return 0;

    const m4 = values.reduce((a, b) => a + ((b - mean) ** 4), 0) / values.length;
    return m4 / (variance ** 2);
  }
}

// ============================================================================
// CONFIGURATION
// ============================================================================

export interface FingerprintConfig {
  /** Number of frequency bins */
  frequencyBins: number;
  /** GLCM distance */
  glcmDistance: number;
  /** LBP radius */
  lbpRadius: number;
  /** Edge detection threshold */
  edgeThreshold: number;
}

// ============================================================================
// CONVENIENCE FUNCTIONS
// ============================================================================

/**
 * Analyze neural architecture fingerprint
 */
export function analyzeNeuralFingerprint(
  imageData: ImageData,
  config?: Partial<FingerprintConfig>
): NeuralFingerprintResult {
  const analyzer = new NeuralFingerprintAnalyzer(config);
  return analyzer.analyze(imageData);
}

/**
 * Identify model architecture
 */
export function identifyModelArchitecture(imageData: ImageData): ModelArchitecture | null {
  const analyzer = new NeuralFingerprintAnalyzer();
  const result = analyzer.analyze(imageData);
  return result.architecture;
}

/**
 * Attribute image to generator
 */
export function attributeImageToGenerator(imageData: ImageData): GeneratorInfo | null {
  const analyzer = new NeuralFingerprintAnalyzer();
  const result = analyzer.analyze(imageData);
  return result.generator;
}

// ============================================================================
// TESTS
// ============================================================================

/**
 * Run neural fingerprint tests
 */
export function runNeuralFingerprintTests(): {
  passed: boolean;
  summary: { total: number; passed: number; failed: number };
  details: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const tests: Array<{ name: string; passed: boolean; error?: string }> = [];

  // Test 1: Analyzer instantiation
  try {
    const analyzer = new NeuralFingerprintAnalyzer();
    tests.push({ name: 'Analyzer instantiation', passed: true });
  } catch (error) {
    tests.push({ name: 'Analyzer instantiation', passed: false, error: String(error) });
  }

  // Test 2: Empty image handling
  try {
    const analyzer = new NeuralFingerprintAnalyzer();
    const result = analyzer.analyze({ width: 0, height: 0, data: [] });
    tests.push({
      name: 'Empty image handling',
      passed: result !== undefined
    });
  } catch (error) {
    tests.push({ name: 'Empty image handling', passed: false, error: String(error) });
  }

  // Test 3: Feature extraction
  try {
    const analyzer = new NeuralFingerprintAnalyzer();
    const imageData = generateTestImage(64, 64);
    const result = analyzer.analyze(imageData);
    tests.push({
      name: 'Feature extraction',
      passed: result.features !== undefined &&
        result.features.spatialFrequency !== undefined
    });
  } catch (error) {
    tests.push({ name: 'Feature extraction', passed: false, error: String(error) });
  }

  // Test 4: Spatial frequency analysis
  try {
    const analyzer = new NeuralFingerprintAnalyzer();
    const imageData = generateTestImage(64, 64);
    const result = analyzer.analyze(imageData);
    tests.push({
      name: 'Spatial frequency analysis',
      passed: typeof result.features.spatialFrequency.decayRate === 'number'
    });
  } catch (error) {
    tests.push({ name: 'Spatial frequency analysis', passed: false, error: String(error) });
  }

  // Test 5: Color distribution analysis
  try {
    const analyzer = new NeuralFingerprintAnalyzer();
    const imageData = generateTestImage(64, 64);
    const result = analyzer.analyze(imageData);
    tests.push({
      name: 'Color distribution analysis',
      passed: result.features.colorDistribution.gamutCoverage !== undefined
    });
  } catch (error) {
    tests.push({ name: 'Color distribution analysis', passed: false, error: String(error) });
  }

  // Test 6: Texture analysis
  try {
    const analyzer = new NeuralFingerprintAnalyzer();
    const imageData = generateTestImage(64, 64);
    const result = analyzer.analyze(imageData);
    tests.push({
      name: 'Texture analysis',
      passed: result.features.texture.glcmFeatures !== undefined
    });
  } catch (error) {
    tests.push({ name: 'Texture analysis', passed: false, error: String(error) });
  }

  // Test 7: Edge analysis
  try {
    const analyzer = new NeuralFingerprintAnalyzer();
    const imageData = generateTestImage(64, 64);
    const result = analyzer.analyze(imageData);
    tests.push({
      name: 'Edge analysis',
      passed: typeof result.features.edges.density === 'number'
    });
  } catch (error) {
    tests.push({ name: 'Edge analysis', passed: false, error: String(error) });
  }

  // Test 8: Artifact detection
  try {
    const analyzer = new NeuralFingerprintAnalyzer();
    const imageData = generateTestImage(64, 64);
    const result = analyzer.analyze(imageData);
    tests.push({
      name: 'Artifact detection',
      passed: result.features.artifacts !== undefined
    });
  } catch (error) {
    tests.push({ name: 'Artifact detection', passed: false, error: String(error) });
  }

  // Test 9: Architecture matching
  try {
    const analyzer = new NeuralFingerprintAnalyzer();
    const imageData = generateTestImage(64, 64);
    const result = analyzer.analyze(imageData);
    tests.push({
      name: 'Architecture matching',
      passed: Array.isArray(result.signatures)
    });
  } catch (error) {
    tests.push({ name: 'Architecture matching', passed: false, error: String(error) });
  }

  // Test 10: Convenience functions
  try {
    const imageData = generateTestImage(64, 64);
    const result = analyzeNeuralFingerprint(imageData);
    const arch = identifyModelArchitecture(imageData);
    const gen = attributeImageToGenerator(imageData);

    tests.push({
      name: 'Convenience functions',
      passed: result !== undefined &&
        (arch !== null || result.confidence < 0.5)
    });
  } catch (error) {
    tests.push({ name: 'Convenience functions', passed: false, error: String(error) });
  }

  const passed = tests.filter(t => t.passed).length;
  const failed = tests.filter(t => !t.passed).length;

  return {
    passed: failed === 0,
    summary: { total: tests.length, passed, failed },
    details: tests
  };
}

/**
 * Generate test image
 */
function generateTestImage(width: number, height: number): ImageData {
  const data: number[][] = [];

  for (let y = 0; y < height; y++) {
    const row: number[] = [];
    for (let x = 0; x < width; x++) {
      // Create a pattern that mimics some AI generation characteristics
      const noise = Math.random() * 30;
      const r = 100 + Math.sin(x * 0.1) * 50 + noise;
      const g = 120 + Math.cos(y * 0.1) * 40 + noise;
      const b = 140 + Math.sin((x + y) * 0.05) * 30 + noise;
      row.push(r, g, b);
    }
    data.push(row);
  }

  return { width, height, data };
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

const neuralFingerprintModule = {
  NeuralFingerprintAnalyzer,
  analyzeNeuralFingerprint,
  identifyModelArchitecture,
  attributeImageToGenerator,
  runNeuralFingerprintTests,
  ARCHITECTURE_SIGNATURES
};

export default neuralFingerprintModule;
