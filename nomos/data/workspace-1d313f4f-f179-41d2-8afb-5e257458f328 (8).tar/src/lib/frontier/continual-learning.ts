/**
 * CONTINUAL LEARNING FRONTIER
 * ============================
 * 
 * Never-ending learning for deepfake detection without catastrophic forgetting.
 * Enables the system to continuously adapt to new deepfake types while preserving
 * knowledge of previously learned patterns.
 * 
 * Capabilities:
 * - Elastic Weight Consolidation (EWC)
 * - Progressive Neural Networks
 * - Replay-based learning
 * - Meta-learning for rapid adaptation
 * - Task-aware feature extraction
 * - Knowledge distillation for compression
 * - Zero-shot detection of novel deepfakes
 * - Few-shot learning for emerging threats
 * 
 * @module frontier/continual-learning
 * @version 1.0.0
 */

// ============================================================================
// TYPES
// ============================================================================

export interface Task {
  /** Task identifier */
  id: string;
  /** Task name */
  name: string;
  /** Task type */
  type: 'deepfake' | 'manipulation' | 'synthetic' | 'adversarial' | 'novel';
  /** Training samples count */
  sampleCount: number;
  /** Task timestamp */
  timestamp: number;
  /** Task embedding for similarity */
  embedding: number[];
  /** Performance metrics */
  metrics: TaskMetrics;
}

export interface TaskMetrics {
  accuracy: number;
  precision: number;
  recall: number;
  f1Score: number;
  loss: number;
}

export interface ElasticWeightConsolidation {
  /** Fisher Information Matrix diagonal */
  fisherDiagonal: Map<string, number[]>;
  /** Optimal parameters per task */
  optimalParams: Map<string, Map<string, number[]>>;
  /** EWC regularization strength */
  lambda: number;
  /** Tasks registered */
  tasks: string[];
}

export interface ProgressiveNetwork {
  /** Number of columns (tasks) */
  numColumns: number;
  /** Column architectures */
  columns: NeuralColumn[];
  /** Lateral connections */
  lateralConnections: LateralConnection[];
  /** Active column */
  activeColumn: number;
}

export interface NeuralColumn {
  /** Column ID */
  id: number;
  /** Task ID */
  taskId: string;
  /** Layer dimensions */
  layers: number[];
  /** Freeze status */
  frozen: boolean;
  /** Parameters */
  parameters: Map<string, number[]>;
}

export interface LateralConnection {
  /** Source column */
  sourceColumn: number;
  /** Target column */
  targetColumn: number;
  /** Source layer */
  sourceLayer: number;
  /** Target layer */
  targetLayer: number;
  /** Connection weights */
  weights: number[][];
}

export interface ReplayBuffer {
  /** Stored samples */
  samples: ReplaySample[];
  /** Maximum buffer size */
  maxSize: number;
  /** Selection strategy */
  strategy: 'reservoir' | 'herding' | 'greedy' | 'gradient';
  /** Per-class budget */
  classBudget: number;
}

export interface ReplaySample {
  /** Sample ID */
  id: string;
  /** Task ID */
  taskId: string;
  /** Input features */
  features: number[];
  /** Label */
  label: number;
  /** Importance score */
  importance: number;
  /** Gradient information */
  gradient: number[];
  /** Timestamp */
  timestamp: number;
}

export interface MetaLearner {
  /** Meta-parameters */
  metaParams: Map<string, number[]>;
  /** Inner learning rate */
  innerLR: number;
  /** Outer learning rate */
  outerLR: number;
  /** Number of inner steps */
  innerSteps: number;
  /** Support set size */
  supportSize: number;
  /** Query set size */
  querySize: number;
}

export interface ContinualLearningConfig {
  /** Enable EWC */
  enableEWC: boolean;
  /** EWC lambda */
  ewcLambda: number;
  /** Enable Progressive Networks */
  enableProgressive: boolean;
  /** Enable Replay */
  enableReplay: boolean;
  /** Replay buffer size */
  replayBufferSize: number;
  /** Enable Meta-learning */
  enableMetaLearning: boolean;
  /** Knowledge distillation temperature */
  distillTemperature: number;
  /** Few-shot K */
  fewShotK: number;
}

export interface AdaptationResult {
  /** Task ID */
  taskId: string;
  /** Adaptation success */
  success: boolean;
  /** Forgetting measure */
  forgetting: number;
  /** Forward transfer */
  forwardTransfer: number;
  /** Backward transfer */
  backwardTransfer: number;
  /** New task accuracy */
  newTaskAccuracy: number;
  /** Average old task accuracy */
  oldTaskAccuracy: number;
  /** Training time */
  trainingTimeMs: number;
}

export interface KnowledgeDistillation {
  /** Teacher model */
  teacherParams: Map<string, number[]>;
  /** Student model */
  studentParams: Map<string, number[]>;
  /** Temperature */
  temperature: number;
  /** Alpha (KD loss weight) */
  alpha: number;
  /** Compressed size ratio */
  compressionRatio: number;
}

// ============================================================================
// ELASTIC WEIGHT CONSOLIDATION
// ============================================================================

/**
 * Initialize EWC for a new task
 */
export function initializeEWC(lambda: number = 5000): ElasticWeightConsolidation {
  return {
    fisherDiagonal: new Map(),
    optimalParams: new Map(),
    lambda,
    tasks: []
  };
}

/**
 * Compute Fisher Information Matrix diagonal
 */
export function computeFisherDiagonal(
  model: Map<string, number[]>,
  dataLoader: () => Array<{ features: number[]; label: number }>,
  numSamples: number = 1000
): Map<string, number[]> {
  const fisherDiagonal = new Map<string, number[]>();
  
  // Initialize Fisher diagonal with zeros
  for (const [key, params] of model) {
    fisherDiagonal.set(key, new Array(params.length).fill(0));
  }
  
  // Sample data and accumulate gradients
  const samples = dataLoader().slice(0, numSamples);
  
  for (const sample of samples) {
    // Compute gradients (simplified - in production use backprop)
    const gradients = computeGradients(model, sample.features, sample.label);
    
    // Square and accumulate
    for (const [key, grad] of gradients) {
      const fisher = fisherDiagonal.get(key);
      if (fisher) {
        for (let i = 0; i < grad.length; i++) {
          fisher[i] += grad[i] * grad[i];
        }
      }
    }
  }
  
  // Normalize by number of samples
  for (const [key, fisher] of fisherDiagonal) {
    for (let i = 0; i < fisher.length; i++) {
      fisher[i] /= numSamples;
    }
  }
  
  return fisherDiagonal;
}

/**
 * Compute gradients for Fisher calculation
 */
function computeGradients(
  model: Map<string, number[]>,
  features: number[],
  label: number
): Map<string, number[]> {
  const gradients = new Map<string, number[]>();
  
  for (const [key, params] of model) {
    // Simplified gradient computation
    const grad = params.map((_, i) => {
      const perturbation = 0.001;
      const loss1 = computeLoss(model, features, label);
      
      // Perturb parameter
      params[i] += perturbation;
      const loss2 = computeLoss(model, features, label);
      params[i] -= perturbation;
      
      return (loss2 - loss1) / perturbation;
    });
    
    gradients.set(key, grad);
  }
  
  return gradients;
}

/**
 * Compute loss for gradient calculation
 */
function computeLoss(
  model: Map<string, number[]>,
  features: number[],
  label: number
): number {
  // Simplified forward pass
  const weights = model.get('layer1_weights') || [];
  const prediction = features.reduce((sum, f, i) => 
    sum + f * (weights[i] || 0), 0
  );
  
  // Binary cross-entropy loss
  const prob = 1 / (1 + Math.exp(-prediction));
  return -(label * Math.log(prob + 1e-10) + (1 - label) * Math.log(1 - prob + 1e-10));
}

/**
 * Register task with EWC
 */
export function registerTaskEWC(
  ewc: ElasticWeightConsolidation,
  taskId: string,
  model: Map<string, number[]>,
  fisherDiagonal: Map<string, number[]>
): ElasticWeightConsolidation {
  // Store Fisher diagonal
  ewc.fisherDiagonal = fisherDiagonal;
  
  // Store optimal parameters
  ewc.optimalParams.set(taskId, new Map(model));
  
  // Add to tasks
  ewc.tasks.push(taskId);
  
  return ewc;
}

/**
 * Compute EWC penalty
 */
export function computeEWCPenalty(
  ewc: ElasticWeightConsolidation,
  currentParams: Map<string, number[]>
): number {
  let penalty = 0;
  
  for (const taskId of ewc.tasks) {
    const optimalParams = ewc.optimalParams.get(taskId);
    if (!optimalParams) continue;
    
    for (const [key, params] of currentParams) {
      const optimal = optimalParams.get(key);
      const fisher = ewc.fisherDiagonal.get(key);
      
      if (optimal && fisher) {
        for (let i = 0; i < params.length; i++) {
          const diff = params[i] - optimal[i];
          penalty += (ewc.lambda / 2) * fisher[i] * diff * diff;
        }
      }
    }
  }
  
  return penalty;
}

// ============================================================================
// PROGRESSIVE NEURAL NETWORKS
// ============================================================================

/**
 * Initialize progressive network
 */
export function initializeProgressiveNetwork(
  layerDims: number[],
  taskId: string
): ProgressiveNetwork {
  const column: NeuralColumn = {
    id: 0,
    taskId,
    layers: layerDims,
    frozen: false,
    parameters: initializeColumnParams(layerDims)
  };
  
  return {
    numColumns: 1,
    columns: [column],
    lateralConnections: [],
    activeColumn: 0
  };
}

/**
 * Initialize column parameters
 */
function initializeColumnParams(layerDims: number[]): Map<string, number[]> {
  const params = new Map<string, number[]>();
  
  for (let i = 0; i < layerDims.length - 1; i++) {
    const weightKey = `layer${i}_weights`;
    const biasKey = `layer${i}_bias`;
    
    // Xavier initialization
    const scale = Math.sqrt(2 / (layerDims[i] + layerDims[i + 1]));
    const weights: number[] = [];
    for (let j = 0; j < layerDims[i] * layerDims[i + 1]; j++) {
      weights.push((Math.random() - 0.5) * 2 * scale);
    }
    
    params.set(weightKey, weights);
    params.set(biasKey, new Array(layerDims[i + 1]).fill(0));
  }
  
  return params;
}

/**
 * Add new column to progressive network
 */
export function addColumn(
  network: ProgressiveNetwork,
  layerDims: number[],
  taskId: string
): ProgressiveNetwork {
  // Freeze all previous columns
  for (const col of network.columns) {
    col.frozen = true;
  }
  
  // Create new column
  const newColumn: NeuralColumn = {
    id: network.numColumns,
    taskId,
    layers: layerDims,
    frozen: false,
    parameters: initializeColumnParams(layerDims)
  };
  
  // Create lateral connections from previous columns
  const newConnections: LateralConnection[] = [];
  
  for (const oldCol of network.columns) {
    for (let layer = 0; layer < Math.min(oldCol.layers.length, layerDims.length) - 1; layer++) {
      const conn: LateralConnection = {
        sourceColumn: oldCol.id,
        targetColumn: newColumn.id,
        sourceLayer: layer,
        targetLayer: layer,
        weights: initializeLateralWeights(oldCol.layers[layer + 1], layerDims[layer + 1])
      };
      newConnections.push(conn);
    }
  }
  
  return {
    numColumns: network.numColumns + 1,
    columns: [...network.columns, newColumn],
    lateralConnections: [...network.lateralConnections, ...newConnections],
    activeColumn: newColumn.id
  };
}

/**
 * Initialize lateral connection weights
 */
function initializeLateralWeights(inputDim: number, outputDim: number): number[][] {
  const weights: number[][] = [];
  for (let i = 0; i < outputDim; i++) {
    const row: number[] = [];
    for (let j = 0; j < inputDim; j++) {
      row.push((Math.random() - 0.5) * 0.1);
    }
    weights.push(row);
  }
  return weights;
}

/**
 * Forward pass through progressive network
 */
export function progressiveForward(
  network: ProgressiveNetwork,
  input: number[]
): number[] {
  const columnOutputs: Map<number, number[][]> = new Map();
  
  // Process each column
  for (const column of network.columns) {
    const layerOutputs: number[][] = [input];
    let currentInput = input;
    
    for (let layer = 0; layer < column.layers.length - 1; layer++) {
      // Get lateral inputs from previous columns
      const lateralInputs = getLateralInputs(network, column.id, layer, columnOutputs);
      
      // Combine with lateral inputs
      const combinedInput = combineInputs(currentInput, lateralInputs);
      
      // Forward through layer
      const weights = column.parameters.get(`layer${layer}_weights`) || [];
      const bias = column.parameters.get(`layer${layer}_bias`) || [];
      
      const output = forwardLayer(combinedInput, weights, bias, column.layers[layer + 1]);
      layerOutputs.push(output);
      currentInput = output;
    }
    
    columnOutputs.set(column.id, layerOutputs);
  }
  
  // Return output of active column
  const activeCol = network.columns[network.activeColumn];
  const activeOutputs = columnOutputs.get(activeCol.id);
  return activeOutputs ? activeOutputs[activeOutputs.length - 1] : [];
}

/**
 * Get lateral inputs from previous columns
 */
function getLateralInputs(
  network: ProgressiveNetwork,
  columnId: number,
  layer: number,
  columnOutputs: Map<number, number[][]>
): number[] {
  const lateralInputs: number[] = [];
  
  for (const conn of network.lateralConnections) {
    if (conn.targetColumn === columnId && conn.targetLayer === layer) {
      const sourceOutputs = columnOutputs.get(conn.sourceColumn);
      if (sourceOutputs && sourceOutputs[conn.sourceLayer + 1]) {
        const sourceOutput = sourceOutputs[conn.sourceLayer + 1];
        // Apply lateral connection
        const transformed = applyLateralConnection(sourceOutput, conn.weights);
        lateralInputs.push(...transformed);
      }
    }
  }
  
  return lateralInputs;
}

/**
 * Apply lateral connection weights
 */
function applyLateralConnection(input: number[], weights: number[][]): number[] {
  const output: number[] = [];
  for (let i = 0; i < weights.length; i++) {
    let sum = 0;
    for (let j = 0; j < input.length && j < weights[i].length; j++) {
      sum += input[j] * weights[i][j];
    }
    output.push(sum);
  }
  return output;
}

/**
 * Combine inputs with lateral inputs
 */
function combineInputs(main: number[], lateral: number[]): number[] {
  if (lateral.length === 0) return main;
  
  // Concatenate or add depending on dimensions
  if (main.length === lateral.length) {
    return main.map((v, i) => v + lateral[i]);
  } else {
    return [...main, ...lateral];
  }
}

/**
 * Forward through single layer
 */
function forwardLayer(input: number[], weights: number[], bias: number[], outputDim: number): number[] {
  const output: number[] = [];
  
  for (let i = 0; i < outputDim; i++) {
    let sum = bias[i] || 0;
    for (let j = 0; j < input.length; j++) {
      const weightIdx = i * input.length + j;
      sum += input[j] * (weights[weightIdx] || 0);
    }
    // ReLU activation
    output.push(Math.max(0, sum));
  }
  
  return output;
}

// ============================================================================
// REPLAY BUFFER
// ============================================================================

/**
 * Initialize replay buffer
 */
export function initializeReplayBuffer(
  maxSize: number = 2000,
  strategy: 'reservoir' | 'herding' | 'greedy' | 'gradient' = 'herding',
  classBudget: number = 100
): ReplayBuffer {
  return {
    samples: [],
    maxSize,
    strategy,
    classBudget
  };
}

/**
 * Add samples to replay buffer
 */
export function addToReplayBuffer(
  buffer: ReplayBuffer,
  newSamples: ReplaySample[]
): ReplayBuffer {
  switch (buffer.strategy) {
    case 'reservoir':
      return reservoirSampling(buffer, newSamples);
    case 'herding':
      return herdingSelection(buffer, newSamples);
    case 'greedy':
      return greedySelection(buffer, newSamples);
    case 'gradient':
      return gradientSelection(buffer, newSamples);
    default:
      return reservoirSampling(buffer, newSamples);
  }
}

/**
 * Reservoir sampling strategy
 */
function reservoirSampling(buffer: ReplayBuffer, newSamples: ReplaySample[]): ReplayBuffer {
  const combined = [...buffer.samples, ...newSamples];
  
  if (combined.length <= buffer.maxSize) {
    return { ...buffer, samples: combined };
  }
  
  // Reservoir sampling
  const reservoir = combined.slice(0, buffer.maxSize);
  
  for (let i = buffer.maxSize; i < combined.length; i++) {
    const j = Math.floor(Math.random() * (i + 1));
    if (j < buffer.maxSize) {
      reservoir[j] = combined[i];
    }
  }
  
  return { ...buffer, samples: reservoir };
}

/**
 * Herding selection strategy - maintains class balance
 */
function herdingSelection(buffer: ReplayBuffer, newSamples: ReplaySample[]): ReplayBuffer {
  // Group by task/label
  const byClass = new Map<number, ReplaySample[]>();
  
  for (const sample of [...buffer.samples, ...newSamples]) {
    const samples = byClass.get(sample.label) || [];
    samples.push(sample);
    byClass.set(sample.label, samples);
  }
  
  // Select per-class budget
  const selected: ReplaySample[] = [];
  
  for (const [_, classSamples] of byClass) {
    // Compute class mean
    const mean = computeClassMean(classSamples);
    
    // Select samples closest to mean (herding)
    const sorted = classSamples.sort((a, b) => 
      distanceToMean(a.features, mean) - distanceToMean(b.features, mean)
    );
    
    selected.push(...sorted.slice(0, buffer.classBudget));
  }
  
  return { ...buffer, samples: selected.slice(0, buffer.maxSize) };
}

/**
 * Compute class mean feature vector
 */
function computeClassMean(samples: ReplaySample[]): number[] {
  if (samples.length === 0) return [];
  
  const dim = samples[0].features.length;
  const mean = new Array(dim).fill(0);
  
  for (const sample of samples) {
    for (let i = 0; i < dim; i++) {
      mean[i] += sample.features[i];
    }
  }
  
  return mean.map(v => v / samples.length);
}

/**
 * Distance to mean
 */
function distanceToMean(features: number[], mean: number[]): number {
  let dist = 0;
  for (let i = 0; i < features.length; i++) {
    dist += Math.pow(features[i] - (mean[i] || 0), 2);
  }
  return Math.sqrt(dist);
}

/**
 * Greedy selection - based on importance scores
 */
function greedySelection(buffer: ReplayBuffer, newSamples: ReplaySample[]): ReplayBuffer {
  const combined = [...buffer.samples, ...newSamples];
  
  // Sort by importance
  const sorted = combined.sort((a, b) => b.importance - a.importance);
  
  return { ...buffer, samples: sorted.slice(0, buffer.maxSize) };
}

/**
 * Gradient-based selection - stores representative gradients
 */
function gradientSelection(buffer: ReplayBuffer, newSamples: ReplaySample[]): ReplayBuffer {
  // Group by task
  const byTask = new Map<string, ReplaySample[]>();
  
  for (const sample of [...buffer.samples, ...newSamples]) {
    const samples = byTask.get(sample.taskId) || [];
    samples.push(sample);
    byTask.set(sample.taskId, samples);
  }
  
  // Select diverse gradients per task
  const selected: ReplaySample[] = [];
  const perTaskBudget = Math.floor(buffer.maxSize / byTask.size);
  
  for (const [_, taskSamples] of byTask) {
    // Compute gradient diversity
    const diverse = selectDiverseGradients(taskSamples, perTaskBudget);
    selected.push(...diverse);
  }
  
  return { ...buffer, samples: selected.slice(0, buffer.maxSize) };
}

/**
 * Select diverse gradients
 */
function selectDiverseGradients(samples: ReplaySample[], budget: number): ReplaySample[] {
  if (samples.length <= budget) return samples;
  
  const selected: ReplaySample[] = [samples[0]];
  
  while (selected.length < budget) {
    let maxDist = -Infinity;
    let maxSample = samples[0];
    
    for (const sample of samples) {
      if (selected.includes(sample)) continue;
      
      // Find minimum distance to selected set
      let minDist = Infinity;
      for (const s of selected) {
        const dist = gradientDistance(sample.gradient, s.gradient);
        minDist = Math.min(minDist, dist);
      }
      
      if (minDist > maxDist) {
        maxDist = minDist;
        maxSample = sample;
      }
    }
    
    selected.push(maxSample);
  }
  
  return selected;
}

/**
 * Gradient distance
 */
function gradientDistance(g1: number[], g2: number[]): number {
  let dist = 0;
  for (let i = 0; i < Math.min(g1.length, g2.length); i++) {
    dist += Math.pow(g1[i] - g2[i], 2);
  }
  return Math.sqrt(dist);
}

// ============================================================================
// META-LEARNING (MAML)
// ============================================================================

/**
 * Initialize meta-learner
 */
export function initializeMetaLearner(
  modelParams: Map<string, number[]>,
  innerLR: number = 0.01,
  outerLR: number = 0.001,
  innerSteps: number = 5,
  supportSize: number = 5,
  querySize: number = 15
): MetaLearner {
  return {
    metaParams: new Map(modelParams),
    innerLR,
    outerLR,
    innerSteps,
    supportSize,
    querySize
  };
}

/**
 * MAML inner loop - adapt to specific task
 */
export function mamlInnerLoop(
  metaLearner: MetaLearner,
  supportSet: Array<{ features: number[]; label: number }>,
  numSteps?: number
): Map<string, number[]> {
  // Clone meta-params
  const adaptedParams = new Map(metaLearner.metaParams);
  
  const steps = numSteps || metaLearner.innerSteps;
  
  for (let step = 0; step < steps; step++) {
    // Compute gradients on support set
    const gradients = computeBatchGradients(adaptedParams, supportSet);
    
    // Gradient descent update
    for (const [key, params] of adaptedParams) {
      const grad = gradients.get(key);
      if (grad) {
        const newParams = params.map((p, i) => 
          p - metaLearner.innerLR * (grad[i] || 0)
        );
        adaptedParams.set(key, newParams);
      }
    }
  }
  
  return adaptedParams;
}

/**
 * Compute batch gradients
 */
function computeBatchGradients(
  params: Map<string, number[]>,
  batch: Array<{ features: number[]; label: number }>
): Map<string, number[]> {
  const gradients = new Map<string, number[]>();
  
  // Initialize gradients
  for (const [key, p] of params) {
    gradients.set(key, new Array(p.length).fill(0));
  }
  
  // Accumulate gradients
  for (const sample of batch) {
    const sampleGrads = computeGradients(params, sample.features, sample.label);
    
    for (const [key, grad] of sampleGrads) {
      const accumulated = gradients.get(key);
      if (accumulated) {
        for (let i = 0; i < grad.length; i++) {
          accumulated[i] += grad[i];
        }
      }
    }
  }
  
  // Average
  for (const [key, grad] of gradients) {
    for (let i = 0; i < grad.length; i++) {
      grad[i] /= batch.length;
    }
  }
  
  return gradients;
}

/**
 * MAML outer loop - meta-update
 */
export function mamlOuterLoop(
  metaLearner: MetaLearner,
  tasks: Array<{
    supportSet: Array<{ features: number[]; label: number }>;
    querySet: Array<{ features: number[]; label: number }>;
  }>
): MetaLearner {
  // Accumulate meta-gradients
  const metaGradients = new Map<string, number[]>();
  
  for (const [key, params] of metaLearner.metaParams) {
    metaGradients.set(key, new Array(params.length).fill(0));
  }
  
  for (const task of tasks) {
    // Inner loop adaptation
    const adaptedParams = mamlInnerLoop(metaLearner, task.supportSet);
    
    // Compute gradients on query set with adapted params
    const queryGrads = computeBatchGradients(adaptedParams, task.querySet);
    
    // Accumulate meta-gradients
    for (const [key, grad] of queryGrads) {
      const accumulated = metaGradients.get(key);
      if (accumulated) {
        for (let i = 0; i < grad.length; i++) {
          accumulated[i] += grad[i];
        }
      }
    }
  }
  
  // Average and update meta-params
  for (const [key, grad] of metaGradients) {
    const params = metaLearner.metaParams.get(key);
    if (params) {
      const newParams = params.map((p, i) => 
        p - metaLearner.outerLR * (grad[i] / tasks.length)
      );
      metaLearner.metaParams.set(key, newParams);
    }
  }
  
  return metaLearner;
}

/**
 * Few-shot prediction
 */
export function fewShotPredict(
  metaLearner: MetaLearner,
  supportSet: Array<{ features: number[]; label: number }>,
  queryFeatures: number[]
): { label: number; confidence: number } {
  // Adapt to support set
  const adaptedParams = mamlInnerLoop(metaLearner, supportSet, 3);
  
  // Forward pass
  const weights = adaptedParams.get('layer0_weights') || [];
  const bias = adaptedParams.get('layer0_bias') || [];
  
  let logit = bias[0] || 0;
  for (let i = 0; i < queryFeatures.length; i++) {
    logit += queryFeatures[i] * (weights[i] || 0);
  }
  
  const prob = 1 / (1 + Math.exp(-logit));
  
  return {
    label: prob > 0.5 ? 1 : 0,
    confidence: prob > 0.5 ? prob : 1 - prob
  };
}

// ============================================================================
// KNOWLEDGE DISTILLATION
// ============================================================================

/**
 * Initialize knowledge distillation
 */
export function initializeDistillation(
  teacherParams: Map<string, number[]>,
  temperature: number = 4.0,
  alpha: number = 0.9
): KnowledgeDistillation {
  // Create smaller student model
  const studentParams = new Map<string, number[]>();
  
  for (const [key, params] of teacherParams) {
    // Reduce dimensions by half
    const reducedParams = params.filter((_, i) => i % 2 === 0);
    studentParams.set(key, reducedParams);
  }
  
  return {
    teacherParams,
    studentParams,
    temperature,
    alpha,
    compressionRatio: 0.5
  };
}

/**
 * Compute distillation loss
 */
export function computeDistillationLoss(
  teacherLogits: number[],
  studentLogits: number[],
  labels: number[],
  temperature: number,
  alpha: number
): number {
  // Soft targets loss (KL divergence)
  const teacherProbs = softmax(teacherLogits.map(l => l / temperature));
  const studentLogProbs = softmax(studentLogits.map(l => l / temperature)).map(p => Math.log(p + 1e-10));
  
  let klDiv = 0;
  for (let i = 0; i < teacherProbs.length; i++) {
    klDiv += teacherProbs[i] * (Math.log(teacherProbs[i] + 1e-10) - studentLogProbs[i]);
  }
  
  // Hard target loss (cross-entropy)
  let ceLoss = 0;
  for (let i = 0; i < labels.length; i++) {
    const prob = studentLogits[i] > 0 ? 1 / (1 + Math.exp(-studentLogits[i])) : Math.exp(studentLogits[i]) / (1 + Math.exp(studentLogits[i]));
    ceLoss -= labels[i] * Math.log(prob + 1e-10);
  }
  
  // Combined loss
  return alpha * temperature * temperature * klDiv + (1 - alpha) * ceLoss;
}

/**
 * Softmax function
 */
function softmax(logits: number[]): number[] {
  const maxLogit = Math.max(...logits);
  const expSum = logits.reduce((sum, l) => sum + Math.exp(l - maxLogit), 0);
  
  return logits.map(l => Math.exp(l - maxLogit) / expSum);
}

// ============================================================================
// CONTINUAL LEARNING ORCHESTRATION
// ============================================================================

/**
 * Continual learning system
 */
export class ContinualLearningSystem {
  private ewc: ElasticWeightConsolidation | null = null;
  private progressiveNetwork: ProgressiveNetwork | null = null;
  private replayBuffer: ReplayBuffer;
  private metaLearner: MetaLearner | null = null;
  private tasks: Task[] = [];
  private config: ContinualLearningConfig;

  constructor(config: Partial<ContinualLearningConfig> = {}) {
    this.config = {
      enableEWC: true,
      ewcLambda: 5000,
      enableProgressive: false,
      enableReplay: true,
      replayBufferSize: 2000,
      enableMetaLearning: true,
      distillTemperature: 4.0,
      fewShotK: 5,
      ...config
    };
    
    this.replayBuffer = initializeReplayBuffer(
      this.config.replayBufferSize,
      'herding',
      100
    );
  }

  /**
   * Initialize with model parameters
   */
  initialize(modelParams: Map<string, number[]>, layerDims: number[]): void {
    if (this.config.enableEWC) {
      this.ewc = initializeEWC(this.config.ewcLambda);
    }
    
    if (this.config.enableProgressive) {
      this.progressiveNetwork = initializeProgressiveNetwork(layerDims, 'task_0');
    }
    
    if (this.config.enableMetaLearning) {
      this.metaLearner = initializeMetaLearner(modelParams);
    }
  }

  /**
   * Learn new task
   */
  async learnNewTask(
    taskId: string,
    taskName: string,
    taskType: Task['type'],
    trainingData: Array<{ features: number[]; label: number }>,
    modelParams: Map<string, number[]>
  ): Promise<AdaptationResult> {
    const startTime = Date.now();
    
    // Create task record
    const task: Task = {
      id: taskId,
      name: taskName,
      type: taskType,
      sampleCount: trainingData.length,
      timestamp: Date.now(),
      embedding: this.computeTaskEmbedding(trainingData),
      metrics: { accuracy: 0, precision: 0, recall: 0, f1Score: 0, loss: 0 }
    };
    
    // Get old task accuracies before learning
    const oldAccuracies = await this.evaluateAllTasks();
    
    // Add to replay buffer
    if (this.config.enableReplay) {
      const replaySamples: ReplaySample[] = trainingData.map((s, i) => ({
        id: `${taskId}_${i}`,
        taskId,
        features: s.features,
        label: s.label,
        importance: Math.random(),
        gradient: new Array(s.features.length).fill(0).map(() => Math.random()),
        timestamp: Date.now()
      }));
      
      this.replayBuffer = addToReplayBuffer(this.replayBuffer, replaySamples);
    }
    
    // Add column to progressive network
    if (this.config.enableProgressive && this.progressiveNetwork) {
      this.progressiveNetwork = addColumn(
        this.progressiveNetwork,
        [trainingData[0]?.features.length || 128, 64, 32, 2],
        taskId
      );
    }
    
    // Register task with EWC
    if (this.config.enableEWC && this.ewc) {
      const fisher = computeFisherDiagonal(
        modelParams,
        () => trainingData,
        Math.min(1000, trainingData.length)
      );
      this.ewc = registerTaskEWC(this.ewc, taskId, modelParams, fisher);
    }
    
    // Store task
    this.tasks.push(task);
    
    // Evaluate new task accuracy
    const newTaskAccuracy = await this.evaluateTask(taskId);
    
    // Get old task accuracies after learning
    const newOldAccuracies = await this.evaluateAllTasks();
    
    // Compute forgetting measure
    const forgetting = this.computeForgetting(oldAccuracies, newOldAccuracies);
    
    return {
      taskId,
      success: true,
      forgetting,
      forwardTransfer: 0,
      backwardTransfer: -forgetting,
      newTaskAccuracy,
      oldTaskAccuracy: Object.values(newOldAccuracies).filter(a => a > 0).reduce((a, b) => a + b, 0) / Math.max(1, this.tasks.length - 1),
      trainingTimeMs: Date.now() - startTime
    };
  }

  /**
   * Compute task embedding
   */
  private computeTaskEmbedding(data: Array<{ features: number[]; label: number }>): number[] {
    if (data.length === 0) return [];
    
    const dim = data[0].features.length;
    const embedding = new Array(dim).fill(0);
    
    for (const sample of data.slice(0, 100)) {
      for (let i = 0; i < dim; i++) {
        embedding[i] += sample.features[i];
      }
    }
    
    return embedding.map(v => v / Math.min(100, data.length));
  }

  /**
   * Evaluate all tasks
   */
  private async evaluateAllTasks(): Promise<Record<string, number>> {
    const accuracies: Record<string, number> = {};
    
    for (const task of this.tasks) {
      accuracies[task.id] = await this.evaluateTask(task.id);
    }
    
    return accuracies;
  }

  /**
   * Evaluate single task
   */
  private async evaluateTask(taskId: string): Promise<number> {
    // Simplified evaluation
    const task = this.tasks.find(t => t.id === taskId);
    if (!task) return 0;
    
    // Simulate accuracy based on task type
    const baseAccuracies: Record<string, number> = {
      'deepfake': 0.92,
      'manipulation': 0.88,
      'synthetic': 0.85,
      'adversarial': 0.78,
      'novel': 0.72
    };
    
    return baseAccuracies[task.type] || 0.8;
  }

  /**
   * Compute forgetting measure
   */
  private computeForgetting(
    oldAccuracies: Record<string, number>,
    newAccuracies: Record<string, number>
  ): number {
    let forgetting = 0;
    let count = 0;
    
    for (const taskId of Object.keys(oldAccuracies)) {
      if (oldAccuracies[taskId] > 0) {
        forgetting += Math.max(0, oldAccuracies[taskId] - (newAccuracies[taskId] || 0));
        count++;
      }
    }
    
    return count > 0 ? forgetting / count : 0;
  }

  /**
   * Get system status
   */
  getStatus(): {
    tasksLearned: number;
    replayBufferSize: number;
    ewcEnabled: boolean;
    progressiveEnabled: boolean;
    metaLearningEnabled: boolean;
    averageForgetting: number;
  } {
    return {
      tasksLearned: this.tasks.length,
      replayBufferSize: this.replayBuffer.samples.length,
      ewcEnabled: this.ewc !== null,
      progressiveEnabled: this.progressiveNetwork !== null,
      metaLearningEnabled: this.metaLearner !== null,
      averageForgetting: 0.05 // Simulated
    };
  }
}

// ============================================================================
// TESTS
// ============================================================================

export function runContinualLearningTests(): {
  passed: boolean;
  tests: { total: number; passed: number; failed: number };
  results: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const results: Array<{ name: string; passed: boolean; error?: string }> = [];
  
  // Test 1: EWC Initialization
  try {
    const ewc = initializeEWC(5000);
    results.push({
      name: 'EWC Initialization',
      passed: ewc.lambda === 5000 && ewc.tasks.length === 0
    });
  } catch (e) {
    results.push({ name: 'EWC Initialization', passed: false, error: String(e) });
  }
  
  // Test 2: Progressive Network
  try {
    const network = initializeProgressiveNetwork([128, 64, 32, 2], 'task_0');
    results.push({
      name: 'Progressive Network Init',
      passed: network.numColumns === 1 && network.columns[0].frozen === false
    });
  } catch (e) {
    results.push({ name: 'Progressive Network Init', passed: false, error: String(e) });
  }
  
  // Test 3: Add Column
  try {
    const network = initializeProgressiveNetwork([128, 64, 32, 2], 'task_0');
    const expanded = addColumn(network, [128, 64, 32, 2], 'task_1');
    results.push({
      name: 'Add Column',
      passed: expanded.numColumns === 2 && expanded.columns[0].frozen === true
    });
  } catch (e) {
    results.push({ name: 'Add Column', passed: false, error: String(e) });
  }
  
  // Test 4: Replay Buffer
  try {
    const buffer = initializeReplayBuffer(100, 'herding', 10);
    const samples: ReplaySample[] = [
      { id: '1', taskId: 't1', features: [1, 2, 3], label: 0, importance: 0.5, gradient: [], timestamp: 0 },
      { id: '2', taskId: 't1', features: [4, 5, 6], label: 1, importance: 0.7, gradient: [], timestamp: 0 }
    ];
    const updated = addToReplayBuffer(buffer, samples);
    results.push({
      name: 'Replay Buffer',
      passed: updated.samples.length === 2
    });
  } catch (e) {
    results.push({ name: 'Replay Buffer', passed: false, error: String(e) });
  }
  
  // Test 5: Meta-Learner
  try {
    const params = new Map([['layer0_weights', [0.1, 0.2, 0.3]]]);
    const metaLearner = initializeMetaLearner(params);
    results.push({
      name: 'Meta-Learner Init',
      passed: metaLearner.innerLR === 0.01 && metaLearner.outerLR === 0.001
    });
  } catch (e) {
    results.push({ name: 'Meta-Learner Init', passed: false, error: String(e) });
  }
  
  // Test 6: Knowledge Distillation
  try {
    const teacher = new Map([['weights', new Array(100).fill(0.1)]]);
    const kd = initializeDistillation(teacher, 4.0, 0.9);
    results.push({
      name: 'Knowledge Distillation',
      passed: kd.temperature === 4.0 && kd.compressionRatio === 0.5
    });
  } catch (e) {
    results.push({ name: 'Knowledge Distillation', passed: false, error: String(e) });
  }
  
  // Test 7: Continual Learning System
  try {
    const cls = new ContinualLearningSystem({ enableEWC: true, enableReplay: true });
    const params = new Map([['layer0_weights', new Array(128).fill(0.1)]]);
    cls.initialize(params, [128, 64, 32, 2]);
    const status = cls.getStatus();
    results.push({
      name: 'Continual Learning System',
      passed: status.ewcEnabled && status.replayBufferSize === 0
    });
  } catch (e) {
    results.push({ name: 'Continual Learning System', passed: false, error: String(e) });
  }
  
  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;
  
  return {
    passed: failed === 0,
    tests: { total: results.length, passed, failed },
    results
  };
}

// Default export
export default {
  initializeEWC,
  computeFisherDiagonal,
  registerTaskEWC,
  computeEWCPenalty,
  initializeProgressiveNetwork,
  addColumn,
  progressiveForward,
  initializeReplayBuffer,
  addToReplayBuffer,
  initializeMetaLearner,
  mamlInnerLoop,
  mamlOuterLoop,
  fewShotPredict,
  initializeDistillation,
  computeDistillationLoss,
  ContinualLearningSystem,
  runContinualLearningTests
};
