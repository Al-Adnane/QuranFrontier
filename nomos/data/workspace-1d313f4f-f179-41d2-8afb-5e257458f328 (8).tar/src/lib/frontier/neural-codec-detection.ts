/**
 * Kasbah Neural Codec Detection Engine
 * Detect AI-compressed audio/video (EnCodec, SoundStream, Lyra, DAC)
 * Real spectral analysis, quantization artifact detection
 * 
 * @module neural-codec-detection
 * @version 1.0.0
 * @disruption-score +4.0/10
 * 
 * Capabilities:
 * - Meta EnCodec Detection
 * - Google SoundStream Detection
 * - Lyra Codec Detection
 * - Descript Audio Codec (DAC) Detection
 * - Quantization Artifact Analysis
 * - Residual Vector Quantization Detection
 * - Neural Compression Fingerprinting
 */

// ============================================
// TYPE DEFINITIONS
// ============================================

export interface NeuralCodecResult {
  id: string;
  timestamp: Date;
  isNeuralCodec: boolean;
  detectedCodec: NeuralCodecType | null;
  confidence: number;
  artifacts: CodecArtifact[];
  analysis: {
    spectral: SpectralAnalysis;
    quantization: QuantizationAnalysis;
    temporal: TemporalAnalysis;
    residual: ResidualAnalysis;
  };
  codecSignature: CodecSignature | null;
}

export type NeuralCodecType = 
  | 'EnCodec'
  | 'SoundStream'
  | 'Lyra'
  | 'DAC'
  | 'AudioDec'
  | 'FunCodec'
  | 'DACodec'
  | 'Unknown';

export interface CodecArtifact {
  type: string;
  severity: 'low' | 'medium' | 'high';
  evidence: string;
  confidence: number;
}

export interface SpectralAnalysis {
  highFreqEnergy: number;
  spectralFlatness: number;
  bandwidthLimitation: number;
  harmonicDistortion: number;
  phaseCoherence: number;
}

export interface QuantizationAnalysis {
  quantizationNoise: number;
  codebookPatterns: number;
  rvqArtifacts: number;
  bitDepthAnomaly: number;
}

export interface TemporalAnalysis {
  frameConsistency: number;
  temporalArtifacts: number;
  envelopeDistortion: number;
  transientSmearing: number;
}

export interface ResidualAnalysis {
  residualEnergy: number;
  noiseFloorPattern: number;
  reconstructionError: number;
  aliasingArtifacts: number;
}

export interface CodecSignature {
  codec: NeuralCodecType;
  signatureStrength: number;
  matchedFeatures: string[];
  versionGuess: string;
}

// ============================================
// SPECTRAL ANALYZER
// ============================================

class SpectralCodecAnalyzer {
  /**
   * Analyze spectral characteristics of neural codecs
   * Neural codecs typically have limited bandwidth and specific spectral patterns
   */
  analyze(
    audioSamples: number[],
    sampleRate: number
  ): SpectralAnalysis {
    // Compute FFT
    const spectrum = this.computeSpectrum(audioSamples);
    
    // High frequency energy (neural codecs often cut high frequencies)
    const highFreqEnergy = this.computeHighFreqEnergy(spectrum, sampleRate);
    
    // Spectral flatness (neural codecs may have unusual flatness)
    const spectralFlatness = this.computeSpectralFlatness(spectrum);
    
    // Bandwidth limitation detection
    const bandwidthLimitation = this.detectBandwidthLimitation(spectrum, sampleRate);
    
    // Harmonic distortion
    const harmonicDistortion = this.computeHarmonicDistortion(spectrum);
    
    // Phase coherence
    const phaseCoherence = this.computePhaseCoherence(audioSamples);
    
    return {
      highFreqEnergy,
      spectralFlatness,
      bandwidthLimitation,
      harmonicDistortion,
      phaseCoherence
    };
  }

  private computeSpectrum(samples: number[]): number[] {
    const n = samples.length;
    const paddedLength = Math.pow(2, Math.ceil(Math.log2(n)));
    
    // Apply Hanning window
    const windowed = samples.map((s, i) => 
      s * 0.5 * (1 - Math.cos(2 * Math.PI * i / (n - 1)))
    );
    
    // Pad to power of 2
    const padded = new Float32Array(paddedLength);
    for (let i = 0; i < n; i++) {
      padded[i] = windowed[i];
    }
    
    // Simple DFT for magnitude
    const spectrum: number[] = [];
    const numBins = Math.floor(paddedLength / 2);
    
    for (let k = 0; k < numBins; k++) {
      let real = 0;
      let imag = 0;
      
      for (let n = 0; n < paddedLength; n++) {
        const angle = -2 * Math.PI * k * n / paddedLength;
        real += padded[n] * Math.cos(angle);
        imag += padded[n] * Math.sin(angle);
      }
      
      spectrum.push(Math.sqrt(real * real + imag * imag));
    }
    
    return spectrum;
  }

  private computeHighFreqEnergy(spectrum: number[], sampleRate: number): number {
    // Neural codecs typically cut frequencies above 8-16kHz
    const nyquist = sampleRate / 2;
    const cutoff8k = Math.floor(spectrum.length * 8000 / nyquist);
    const cutoff16k = Math.floor(spectrum.length * 16000 / nyquist);
    
    let highFreqEnergy = 0;
    let totalEnergy = 0;
    
    for (let i = 0; i < spectrum.length; i++) {
      totalEnergy += spectrum[i] * spectrum[i];
      if (i >= cutoff8k) {
        highFreqEnergy += spectrum[i] * spectrum[i];
      }
    }
    
    // Low ratio = likely neural codec
    return totalEnergy > 0 ? highFreqEnergy / totalEnergy : 0;
  }

  private computeSpectralFlatness(spectrum: number[]): number {
    if (spectrum.length === 0) return 0;
    
    // Geometric mean / arithmetic mean
    const epsilon = 1e-10;
    const logSum = spectrum.reduce((sum, m) => sum + Math.log(m + epsilon), 0);
    const geometricMean = Math.exp(logSum / spectrum.length);
    const arithmeticMean = spectrum.reduce((a, b) => a + b, 0) / spectrum.length;
    
    return arithmeticMean > 0 ? geometricMean / arithmeticMean : 0;
  }

  private detectBandwidthLimitation(spectrum: number[], sampleRate: number): number {
    const nyquist = sampleRate / 2;
    
    // Find where energy drops significantly
    let cutoffBin = spectrum.length;
    const threshold = 0.01; // -40dB
    
    for (let i = spectrum.length - 1; i >= 0; i--) {
      if (spectrum[i] > threshold * spectrum[0]) {
        cutoffBin = i;
        break;
      }
    }
    
    const cutoffFreq = (cutoffBin / spectrum.length) * nyquist;
    
    // Score based on how low the cutoff is
    // Neural codecs typically cutoff around 8-16kHz
    if (cutoffFreq < 8000) return 0.9;
    if (cutoffFreq < 12000) return 0.7;
    if (cutoffFreq < 16000) return 0.5;
    return 0.1;
  }

  private computeHarmonicDistortion(spectrum: number[]): number {
    // Neural codecs may introduce harmonic distortion
    // Look for harmonic patterns
    
    let distortionScore = 0;
    
    // Find peaks
    const peaks: number[] = [];
    for (let i = 1; i < spectrum.length - 1; i++) {
      if (spectrum[i] > spectrum[i - 1] && spectrum[i] > spectrum[i + 1]) {
        peaks.push(i);
      }
    }
    
    // Check for harmonic relationships
    for (let i = 0; i < peaks.length - 2; i++) {
      const ratio = peaks[i + 1] / peaks[i];
      if (ratio > 1.9 && ratio < 2.1) {
        // Possible harmonic
        distortionScore += 0.1;
      }
    }
    
    return Math.min(1, distortionScore);
  }

  private computePhaseCoherence(samples: number[]): number {
    // Neural codecs may have unusual phase characteristics
    // Simplified phase coherence using zero-crossing consistency
    
    let crossings = 0;
    for (let i = 1; i < samples.length; i++) {
      if ((samples[i] >= 0 && samples[i - 1] < 0) ||
          (samples[i] < 0 && samples[i - 1] >= 0)) {
        crossings++;
      }
    }
    
    // Expected crossings based on typical audio
    const expectedCrossings = samples.length / 20;
    const deviation = Math.abs(crossings - expectedCrossings) / expectedCrossings;
    
    return Math.max(0, 1 - deviation);
  }
}

// ============================================
// QUANTIZATION ANALYZER
// ============================================

class QuantizationAnalyzer {
  /**
   * Detect quantization artifacts from neural audio codecs
   * Neural codecs use Residual Vector Quantization (RVQ)
   */
  analyze(
    audioSamples: number[],
    sampleRate: number
  ): QuantizationAnalysis {
    // Quantization noise analysis
    const quantizationNoise = this.detectQuantizationNoise(audioSamples);
    
    // Codebook patterns (RVQ leaves specific patterns)
    const codebookPatterns = this.detectCodebookPatterns(audioSamples);
    
    // RVQ artifacts
    const rvqArtifacts = this.detectRVQArtifacts(audioSamples);
    
    // Bit depth anomaly
    const bitDepthAnomaly = this.detectBitDepthAnomaly(audioSamples);
    
    return {
      quantizationNoise,
      codebookPatterns,
      rvqArtifacts,
      bitDepthAnomaly
    };
  }

  private detectQuantizationNoise(samples: number[]): number {
    // Quantization noise has specific characteristics
    // Look for step-like patterns in the signal
    
    let stepCount = 0;
    const stepThreshold = 0.001; // Minimum step size
    
    for (let i = 1; i < samples.length; i++) {
      const diff = Math.abs(samples[i] - samples[i - 1]);
      if (diff > 0 && diff < stepThreshold) {
        stepCount++;
      }
    }
    
    // High ratio of small steps indicates quantization
    const ratio = stepCount / samples.length;
    return Math.min(1, ratio * 100);
  }

  private detectCodebookPatterns(samples: number[]): number {
    // Neural codecs use learned codebooks
    // Look for repeated quantization patterns
    
    const windowSize = 512;
    const patterns: Map<string, number> = new Map();
    
    for (let i = 0; i < samples.length - windowSize; i += windowSize) {
      const window = samples.slice(i, i + windowSize);
      
      // Quantize to detect patterns
      const quantized = window.map(s => Math.round(s * 100) / 100);
      const key = quantized.slice(0, 10).join(',');
      
      patterns.set(key, (patterns.get(key) || 0) + 1);
    }
    
    // High pattern repetition = likely neural codec
    const maxRepetition = Math.max(...patterns.values());
    const expectedRepetition = samples.length / windowSize / 10;
    
    return Math.min(1, maxRepetition / expectedRepetition / 3);
  }

  private detectRVQArtifacts(samples: number[]): number {
    // Residual Vector Quantization leaves layered artifacts
    // Analyze residual signal
    
    // Compute residual by subtracting smoothed signal
    const smoothed = this.smoothSignal(samples, 5);
    const residual = samples.map((s, i) => s - smoothed[i]);
    
    // Analyze residual energy distribution
    let energy = 0;
    let zeroCrossings = 0;
    
    for (let i = 0; i < residual.length; i++) {
      energy += residual[i] * residual[i];
      if (i > 0 && Math.sign(residual[i]) !== Math.sign(residual[i - 1])) {
        zeroCrossings++;
      }
    }
    
    // RVQ residuals have specific energy/zc ratio
    const ratio = energy > 0 ? zeroCrossings / Math.sqrt(energy) : 0;
    
    return Math.min(1, ratio / 10);
  }

  private smoothSignal(samples: number[], windowSize: number): number[] {
    const smoothed: number[] = [];
    const halfWindow = Math.floor(windowSize / 2);
    
    for (let i = 0; i < samples.length; i++) {
      let sum = 0;
      let count = 0;
      
      for (let j = Math.max(0, i - halfWindow); j < Math.min(samples.length, i + halfWindow); j++) {
        sum += samples[j];
        count++;
      }
      
      smoothed.push(sum / count);
    }
    
    return smoothed;
  }

  private detectBitDepthAnomaly(samples: number[]): number {
    // Neural codecs often have unusual bit depth characteristics
    // Check for non-uniform value distribution
    
    const histogram: Map<number, number> = new Map();
    const bins = 256;
    
    for (const s of samples) {
      const bin = Math.floor((s + 1) * bins / 2);
      histogram.set(bin, (histogram.get(bin) || 0) + 1);
    }
    
    // Calculate entropy
    const total = samples.length;
    let entropy = 0;
    
    for (const count of histogram.values()) {
      if (count > 0) {
        const p = count / total;
        entropy -= p * Math.log2(p);
      }
    }
    
    // Low entropy = possible neural codec quantization
    const maxEntropy = Math.log2(bins);
    return Math.max(0, 1 - entropy / maxEntropy);
  }
}

// ============================================
// TEMPORAL ANALYZER
// ============================================

class TemporalCodecAnalyzer {
  /**
   * Analyze temporal characteristics of neural codecs
   */
  analyze(
    audioSamples: number[],
    sampleRate: number
  ): TemporalAnalysis {
    // Frame consistency (neural codecs process in frames)
    const frameConsistency = this.analyzeFrameConsistency(audioSamples, sampleRate);
    
    // Temporal artifacts
    const temporalArtifacts = this.detectTemporalArtifacts(audioSamples, sampleRate);
    
    // Envelope distortion
    const envelopeDistortion = this.analyzeEnvelopeDistortion(audioSamples);
    
    // Transient smearing
    const transientSmearing = this.detectTransientSmearing(audioSamples, sampleRate);
    
    return {
      frameConsistency,
      temporalArtifacts,
      envelopeDistortion,
      transientSmearing
    };
  }

  private analyzeFrameConsistency(samples: number[], sampleRate: number): number {
    // Neural codecs operate on fixed-size frames
    // Check for artifacts at frame boundaries
    
    const frameSizes = [320, 480, 640, 960, 1280, 1920]; // Common frame sizes
    let maxConsistency = 0;
    
    for (const frameSize of frameSizes) {
      let consistency = 0;
      let frameCount = 0;
      
      for (let i = frameSize; i < samples.length - frameSize; i += frameSize) {
        // Check for discontinuities at frame boundaries
        const preBoundary = samples.slice(i - 10, i);
        const postBoundary = samples.slice(i, i + 10);
        
        const preMean = preBoundary.reduce((a, b) => a + b, 0) / preBoundary.length;
        const postMean = postBoundary.reduce((a, b) => a + b, 0) / postBoundary.length;
        
        if (Math.abs(preMean - postMean) < 0.01) {
          consistency++;
        }
        frameCount++;
      }
      
      const score = frameCount > 0 ? consistency / frameCount : 0;
      maxConsistency = Math.max(maxConsistency, score);
    }
    
    return maxConsistency;
  }

  private detectTemporalArtifacts(samples: number[], sampleRate: number): number {
    // Look for periodic temporal artifacts
    // Neural codecs may introduce frame-rate artifacts
    
    const windowSize = Math.floor(sampleRate * 0.02); // 20ms windows
    const energies: number[] = [];
    
    for (let i = 0; i < samples.length - windowSize; i += windowSize) {
      let energy = 0;
      for (let j = 0; j < windowSize; j++) {
        energy += samples[i + j] * samples[i + j];
      }
      energies.push(energy);
    }
    
    // Check for periodic patterns in energy
    let periodicity = 0;
    const period = 50; // Check for ~1 second periodicity
    
    if (energies.length > period * 2) {
      let correlation = 0;
      let count = 0;
      
      for (let i = 0; i < energies.length - period; i++) {
        correlation += Math.abs(energies[i] - energies[i + period]);
        count++;
      }
      
      periodicity = count > 0 ? 1 - correlation / count / energies[0] : 0;
    }
    
    return Math.min(1, Math.max(0, periodicity));
  }

  private analyzeEnvelopeDistortion(samples: number[]): number {
    // Neural codecs may distort amplitude envelope
    
    // Compute envelope using absolute value + smoothing
    const envelope = this.computeEnvelope(samples);
    
    // Check for unnatural flat regions
    let flatRegions = 0;
    const threshold = 0.001;
    
    for (let i = 10; i < envelope.length; i++) {
      const localVariance = this.localVariance(envelope, i, 10);
      if (localVariance < threshold) {
        flatRegions++;
      }
    }
    
    return Math.min(1, flatRegions / samples.length * 100);
  }

  private detectTransientSmearing(samples: number[], sampleRate: number): number {
    // Neural codecs often smear transients
    // Look for smoothed attack/decay
    
    // Find transients (sudden changes)
    const transients: number[] = [];
    const diff: number[] = [];
    
    for (let i = 1; i < samples.length; i++) {
      diff.push(Math.abs(samples[i] - samples[i - 1]));
    }
    
    const threshold = this.percentile(diff, 95);
    
    for (let i = 0; i < diff.length; i++) {
      if (diff[i] > threshold) {
        transients.push(i);
      }
    }
    
    // Analyze transient sharpness
    let smearingScore = 0;
    
    for (const t of transients) {
      if (t < 10 || t >= samples.length - 10) continue;
      
      // Check rise time
      let riseTime = 0;
      for (let i = t; i < Math.min(t + 50, samples.length); i++) {
        if (Math.abs(samples[i] - samples[t]) < threshold * 0.1) {
          riseTime = i - t;
          break;
        }
      }
      
      // Fast transients should have short rise time
      if (riseTime > 20) {
        smearingScore++;
      }
    }
    
    return Math.min(1, smearingScore / Math.max(1, transients.length));
  }

  private computeEnvelope(samples: number[]): number[] {
    const envelope: number[] = [];
    const windowSize = 100;
    
    for (let i = 0; i < samples.length; i++) {
      const start = Math.max(0, i - windowSize);
      const end = Math.min(samples.length, i + windowSize);
      
      let max = 0;
      for (let j = start; j < end; j++) {
        max = Math.max(max, Math.abs(samples[j]));
      }
      envelope.push(max);
    }
    
    return envelope;
  }

  private localVariance(arr: number[], idx: number, window: number): number {
    const start = Math.max(0, idx - window);
    const end = Math.min(arr.length, idx + window);
    
    let sum = 0;
    let sumSq = 0;
    let count = 0;
    
    for (let i = start; i < end; i++) {
      sum += arr[i];
      sumSq += arr[i] * arr[i];
      count++;
    }
    
    const mean = sum / count;
    return sumSq / count - mean * mean;
  }

  private percentile(arr: number[], p: number): number {
    const sorted = [...arr].sort((a, b) => a - b);
    const idx = Math.floor(p * sorted.length / 100);
    return sorted[idx];
  }
}

// ============================================
// RESIDUAL ANALYZER
// ============================================

class ResidualAnalyzer {
  /**
   * Analyze residual signal characteristics
   */
  analyze(
    audioSamples: number[],
    sampleRate: number
  ): ResidualAnalysis {
    // Compute residual (high-pass)
    const residual = this.computeResidual(audioSamples);
    
    // Residual energy
    const residualEnergy = this.computeResidualEnergy(residual);
    
    // Noise floor pattern
    const noiseFloorPattern = this.analyzeNoiseFloorPattern(residual);
    
    // Reconstruction error
    const reconstructionError = this.estimateReconstructionError(audioSamples, residual);
    
    // Aliasing artifacts
    const aliasingArtifacts = this.detectAliasingArtifacts(residual, sampleRate);
    
    return {
      residualEnergy,
      noiseFloorPattern,
      reconstructionError,
      aliasingArtifacts
    };
  }

  private computeResidual(samples: number[]): number[] {
    // High-pass filter to get residual
    const cutoff = 4000; // 4kHz cutoff
    const rc = 1 / (2 * Math.PI * cutoff);
    const dt = 1 / 44100; // Assume 44.1kHz
    const alpha = rc / (rc + dt);
    
    const residual: number[] = [samples[0]];
    
    for (let i = 1; i < samples.length; i++) {
      residual.push(samples[i] - alpha * samples[i - 1]);
    }
    
    return residual;
  }

  private computeResidualEnergy(residual: number[]): number {
    let energy = 0;
    for (const r of residual) {
      energy += r * r;
    }
    return Math.sqrt(energy / residual.length);
  }

  private analyzeNoiseFloorPattern(residual: number[]): number {
    // Neural codecs have specific noise floor patterns
    // Look for quantization noise characteristics
    
    // Compute histogram of residual values
    const histogram: Map<number, number> = new Map();
    const bins = 100;
    
    for (const r of residual) {
      const bin = Math.floor(r * bins);
      histogram.set(bin, (histogram.get(bin) || 0) + 1);
    }
    
    // Check for uniform distribution (quantization noise)
    const values = Array.from(histogram.values());
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    
    let variance = 0;
    for (const v of values) {
      variance += (v - mean) * (v - mean);
    }
    variance /= values.length;
    
    // Low variance = uniform = quantization
    return Math.min(1, variance / (mean * mean));
  }

  private estimateReconstructionError(samples: number[], residual: number[]): number {
    // Estimate reconstruction error by comparing original to smoothed version
    const smoothed = this.lowPassFilter(samples, 2000);
    
    let error = 0;
    for (let i = 0; i < samples.length; i++) {
      error += Math.abs(samples[i] - smoothed[i]);
    }
    
    return error / samples.length;
  }

  private lowPassFilter(samples: number[], cutoff: number): number[] {
    const rc = 1 / (2 * Math.PI * cutoff);
    const dt = 1 / 44100;
    const alpha = dt / (rc + dt);
    
    const filtered: number[] = [samples[0]];
    
    for (let i = 1; i < samples.length; i++) {
      filtered.push(filtered[i - 1] + alpha * (samples[i] - filtered[i - 1]));
    }
    
    return filtered;
  }

  private detectAliasingArtifacts(residual: number[], sampleRate: number): number {
    // Neural codecs may introduce aliasing
    // Look for spectral folding artifacts
    
    // Simplified: check for high-frequency energy that shouldn't exist
    const spectrum = this.computeSpectrum(residual);
    const nyquist = sampleRate / 2;
    
    // Check energy around Nyquist frequency
    const nyquistBin = Math.floor(spectrum.length * 0.9);
    const lowBin = Math.floor(spectrum.length * 0.1);
    
    let highEnergy = 0;
    let lowEnergy = 0;
    
    for (let i = nyquistBin; i < spectrum.length; i++) {
      highEnergy += spectrum[i] * spectrum[i];
    }
    
    for (let i = 0; i < lowBin; i++) {
      lowEnergy += spectrum[i] * spectrum[i];
    }
    
    // Unusually high HF energy suggests aliasing
    return lowEnergy > 0 ? Math.min(1, highEnergy / lowEnergy * 10) : 0;
  }

  private computeSpectrum(samples: number[]): number[] {
    const n = samples.length;
    const spectrum: number[] = [];
    
    for (let k = 0; k < n / 2; k++) {
      let real = 0;
      let imag = 0;
      
      for (let i = 0; i < n; i++) {
        const angle = -2 * Math.PI * k * i / n;
        real += samples[i] * Math.cos(angle);
        imag += samples[i] * Math.sin(angle);
      }
      
      spectrum.push(Math.sqrt(real * real + imag * imag));
    }
    
    return spectrum;
  }
}

// ============================================
// CODEC SIGNATURE DETECTOR
// ============================================

class CodecSignatureDetector {
  /**
   * Detect specific neural codec signatures
   */
  detect(
    spectral: SpectralAnalysis,
    quantization: QuantizationAnalysis,
    temporal: TemporalAnalysis,
    residual: ResidualAnalysis
  ): CodecSignature | null {
    const signatures: Array<{
      codec: NeuralCodecType;
      strength: number;
      features: string[];
    }> = [];
    
    // EnCodec signature
    signatures.push(this.detectEnCodec(spectral, quantization, temporal));
    
    // SoundStream signature
    signatures.push(this.detectSoundStream(spectral, quantization));
    
    // Lyra signature
    signatures.push(this.detectLyra(spectral, temporal));
    
    // DAC signature
    signatures.push(this.detectDAC(quantization, residual));
    
    // Find best match
    signatures.sort((a, b) => b.strength - a.strength);
    
    if (signatures[0].strength < 0.3) {
      return null;
    }
    
    return {
      codec: signatures[0].codec,
      signatureStrength: signatures[0].strength,
      matchedFeatures: signatures[0].features,
      versionGuess: this.guessVersion(signatures[0].codec, spectral)
    };
  }

  private detectEnCodec(
    spectral: SpectralAnalysis,
    quantization: QuantizationAnalysis,
    temporal: TemporalAnalysis
  ): { codec: NeuralCodecType; strength: number; features: string[] } {
    let strength = 0;
    const features: string[] = [];
    
    // EnCodec characteristics
    if (spectral.bandwidthLimitation > 0.6) {
      strength += 0.3;
      features.push('bandwidth_limitation');
    }
    
    if (quantization.rvqArtifacts > 0.5) {
      strength += 0.3;
      features.push('rvq_artifacts');
    }
    
    if (temporal.frameConsistency > 0.8) {
      strength += 0.2;
      features.push('frame_consistency');
    }
    
    if (spectral.spectralFlatness > 0.6) {
      strength += 0.2;
      features.push('spectral_flatness');
    }
    
    return { codec: 'EnCodec', strength, features };
  }

  private detectSoundStream(
    spectral: SpectralAnalysis,
    quantization: QuantizationAnalysis
  ): { codec: NeuralCodecType; strength: number; features: string[] } {
    let strength = 0;
    const features: string[] = [];
    
    // SoundStream characteristics
    if (quantization.codebookPatterns > 0.5) {
      strength += 0.4;
      features.push('codebook_patterns');
    }
    
    if (spectral.highFreqEnergy < 0.1) {
      strength += 0.3;
      features.push('low_hf_energy');
    }
    
    if (quantization.quantizationNoise > 0.4) {
      strength += 0.3;
      features.push('quantization_noise');
    }
    
    return { codec: 'SoundStream', strength, features };
  }

  private detectLyra(
    spectral: SpectralAnalysis,
    temporal: TemporalAnalysis
  ): { codec: NeuralCodecType; strength: number; features: string[] } {
    let strength = 0;
    const features: string[] = [];
    
    // Lyra characteristics (optimized for speech)
    if (spectral.bandwidthLimitation > 0.7) {
      strength += 0.4;
      features.push('heavy_bandwidth_limit');
    }
    
    if (temporal.transientSmearing > 0.5) {
      strength += 0.3;
      features.push('transient_smearing');
    }
    
    if (temporal.envelopeDistortion < 0.3) {
      strength += 0.3;
      features.push('preserved_envelope');
    }
    
    return { codec: 'Lyra', strength, features };
  }

  private detectDAC(
    quantization: QuantizationAnalysis,
    residual: ResidualAnalysis
  ): { codec: NeuralCodecType; strength: number; features: string[] } {
    let strength = 0;
    const features: string[] = [];
    
    // DAC (Descript Audio Codec) characteristics
    if (quantization.bitDepthAnomaly > 0.5) {
      strength += 0.4;
      features.push('bit_depth_anomaly');
    }
    
    if (residual.reconstructionError > 0.3) {
      strength += 0.3;
      features.push('reconstruction_error');
    }
    
    if (quantization.rvqArtifacts > 0.6) {
      strength += 0.3;
      features.push('high_rvq');
    }
    
    return { codec: 'DAC', strength, features };
  }

  private guessVersion(codec: NeuralCodecType, spectral: SpectralAnalysis): string {
    if (codec === 'EnCodec') {
      if (spectral.bandwidthLimitation > 0.8) return 'encodec_24khz';
      return 'encodec_48khz';
    }
    
    if (codec === 'SoundStream') {
      if (spectral.highFreqEnergy < 0.05) return 'soundstream_low_bitrate';
      return 'soundstream_high_quality';
    }
    
    return 'unknown_version';
  }
}

// ============================================
// NEURAL CODEC DETECTOR
// ============================================

export class NeuralCodecDetector {
  private spectralAnalyzer: SpectralCodecAnalyzer;
  private quantizationAnalyzer: QuantizationAnalyzer;
  private temporalAnalyzer: TemporalCodecAnalyzer;
  private residualAnalyzer: ResidualAnalyzer;
  private signatureDetector: CodecSignatureDetector;

  constructor() {
    this.spectralAnalyzer = new SpectralCodecAnalyzer();
    this.quantizationAnalyzer = new QuantizationAnalyzer();
    this.temporalAnalyzer = new TemporalCodecAnalyzer();
    this.residualAnalyzer = new ResidualAnalyzer();
    this.signatureDetector = new CodecSignatureDetector();
  }

  /**
   * Detect neural codec compression in audio
   */
  async detect(
    audioSamples: number[],
    sampleRate: number = 44100
  ): Promise<NeuralCodecResult> {
    const artifacts: CodecArtifact[] = [];
    
    // Run all analyses
    const spectral = this.spectralAnalyzer.analyze(audioSamples, sampleRate);
    const quantization = this.quantizationAnalyzer.analyze(audioSamples, sampleRate);
    const temporal = this.temporalAnalyzer.analyze(audioSamples, sampleRate);
    const residual = this.residualAnalyzer.analyze(audioSamples, sampleRate);
    
    // Detect artifacts
    if (spectral.bandwidthLimitation > 0.6) {
      artifacts.push({
        type: 'bandwidth_limitation',
        severity: 'high',
        evidence: `Bandwidth limited: ${(spectral.bandwidthLimitation * 100).toFixed(0)}%`,
        confidence: spectral.bandwidthLimitation
      });
    }
    
    if (quantization.rvqArtifacts > 0.5) {
      artifacts.push({
        type: 'rvq_quantization',
        severity: 'high',
        evidence: 'Residual Vector Quantization artifacts detected',
        confidence: quantization.rvqArtifacts
      });
    }
    
    if (temporal.transientSmearing > 0.5) {
      artifacts.push({
        type: 'transient_smearing',
        severity: 'medium',
        evidence: 'Transient smearing detected',
        confidence: temporal.transientSmearing
      });
    }
    
    if (residual.aliasingArtifacts > 0.3) {
      artifacts.push({
        type: 'aliasing',
        severity: 'medium',
        evidence: 'Aliasing artifacts detected',
        confidence: residual.aliasingArtifacts
      });
    }
    
    // Detect codec signature
    const codecSignature = this.signatureDetector.detect(
      spectral, quantization, temporal, residual
    );
    
    // Determine if neural codec
    const isNeuralCodec = this.determineIsNeuralCodec(
      spectral, quantization, temporal, residual, codecSignature
    );
    
    // Calculate confidence
    const confidence = this.calculateConfidence(
      spectral, quantization, temporal, residual, codecSignature
    );
    
    return {
      id: `neural-codec-${Date.now()}`,
      timestamp: new Date(),
      isNeuralCodec,
      detectedCodec: codecSignature?.codec || null,
      confidence,
      artifacts,
      analysis: {
        spectral,
        quantization,
        temporal,
        residual
      },
      codecSignature
    };
  }

  private determineIsNeuralCodec(
    spectral: SpectralAnalysis,
    quantization: QuantizationAnalysis,
    temporal: TemporalAnalysis,
    residual: ResidualAnalysis,
    signature: CodecSignature | null
  ): boolean {
    let score = 0;
    
    if (spectral.bandwidthLimitation > 0.5) score += 0.3;
    if (quantization.rvqArtifacts > 0.4) score += 0.3;
    if (quantization.codebookPatterns > 0.4) score += 0.2;
    if (signature && signature.signatureStrength > 0.4) score += 0.2;
    
    return score > 0.5;
  }

  private calculateConfidence(
    spectral: SpectralAnalysis,
    quantization: QuantizationAnalysis,
    temporal: TemporalAnalysis,
    residual: ResidualAnalysis,
    signature: CodecSignature | null
  ): number {
    const weights = {
      spectral: 0.3,
      quantization: 0.3,
      temporal: 0.2,
      signature: 0.2
    };
    
    const spectralScore = spectral.bandwidthLimitation * 0.5 + 
                          (1 - spectral.highFreqEnergy) * 0.5;
    
    const quantScore = quantization.rvqArtifacts * 0.5 + 
                       quantization.codebookPatterns * 0.5;
    
    const temporalScore = temporal.frameConsistency * 0.5 + 
                          temporal.transientSmearing * 0.5;
    
    const signatureScore = signature ? signature.signatureStrength : 0;
    
    return (
      weights.spectral * spectralScore +
      weights.quantization * quantScore +
      weights.temporal * temporalScore +
      weights.signature * signatureScore
    );
  }
}

// ============================================
// EXPORTS
// ============================================

export const neuralCodecDetection = {
  NeuralCodecDetector,
  SpectralCodecAnalyzer,
  QuantizationAnalyzer,
  TemporalCodecAnalyzer,
  ResidualAnalyzer,
  CodecSignatureDetector
};

export default neuralCodecDetection;
