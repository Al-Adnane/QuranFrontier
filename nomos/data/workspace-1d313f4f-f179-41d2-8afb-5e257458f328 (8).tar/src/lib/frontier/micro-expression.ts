/**
 * Micro-Expression Analysis Module
 *
 * Analyzes facial micro-expressions to detect deepfakes by:
 * - Facial Action Unit (AU) detection and analysis
 * - Micro-expression timing analysis
 * - Expression coherence with context
 * - Symmetry analysis
 * - Temporal dynamics of expressions
 *
 * Based on Paul Ekman's Facial Action Coding System (FACS)
 *
 * @module frontier/micro-expression
 * @version 4.1.0
 */

// ============================================================================
// TYPES AND INTERFACES
// ============================================================================

export interface FacialActionUnit {
  /** AU number (1-46 for standard FACS) */
  number: number;
  /** AU name */
  name: string;
  /** Intensity (0-5, FACS scale: trace, slight, marked, severe, extreme) */
  intensity: number;
  /** Laterality (left, right, or bilateral) */
  laterality: 'left' | 'right' | 'bilateral';
  /** Confidence of detection */
  confidence: number;
  /** Related muscles */
  muscles: string[];
}

export interface MicroExpression {
  /** Expression type */
  type: MicroExpressionType;
  /** Start time in ms */
  startTime: number;
  /** Duration in ms */
  duration: number;
  /** Intensity */
  intensity: number;
  /** Involved Action Units */
  actionUnits: FacialActionUnit[];
  /** Symmetry score */
  symmetry: number;
  /** Naturalness score */
  naturalness: number;
  /** Detection confidence */
  confidence: number;
}

export type MicroExpressionType =
  | 'happiness'
  | 'sadness'
  | 'anger'
  | 'fear'
  | 'disgust'
  | 'contempt'
  | 'surprise'
  | 'neutral'
  | 'mixed';

export interface ExpressionAnalysisResult {
  /** Analysis ID */
  id: string;
  /** Timestamp */
  timestamp: number;
  /** Deepfake probability based on expressions */
  deepfakeProbability: number;
  /** Detected Action Units */
  actionUnits: FacialActionUnit[];
  /** Detected micro-expressions */
  microExpressions: MicroExpression[];
  /** Expression timeline */
  timeline: ExpressionTimelineEntry[];
  /** Anomalies detected */
  anomalies: ExpressionAnomaly[];
  /** Symmetry analysis */
  symmetryAnalysis: SymmetryAnalysisResult;
  /** Temporal dynamics */
  temporalDynamics: TemporalDynamicsResult;
  /** Overall naturalness score */
  naturalnessScore: number;
  /** Recommendations */
  recommendations: string[];
}

export interface ExpressionTimelineEntry {
  /** Timestamp in ms */
  timestamp: number;
  /** Expression type */
  expression: MicroExpressionType;
  /** Intensity */
  intensity: number;
  /** Action Units active */
  actionUnits: number[];
}

export interface ExpressionAnomaly {
  /** Anomaly type */
  type: 'timing' | 'symmetry' | 'intensity' | 'coherence' | 'sequence' | 'muscle_conflict';
  /** Description */
  description: string;
  /** Severity (0-1) */
  severity: number;
  /** Confidence */
  confidence: number;
  /** Location in timeline */
  timestamp?: number;
  /** Related Action Units */
  relatedAUs: number[];
}

export interface SymmetryAnalysisResult {
  /** Overall symmetry score */
  overallScore: number;
  /** Left-right intensity differences */
  asymmetries: Array<{
    au: number;
    leftIntensity: number;
    rightIntensity: number;
    difference: number;
  }>;
  /** Natural asymmetry accounted for */
  naturalAsymmetryDetected: boolean;
}

export interface TemporalDynamicsResult {
  /** Average expression onset duration */
  avgOnsetDuration: number;
  /** Average expression apex duration */
  avgApexDuration: number;
  /** Average expression offset duration */
  avgOffsetDuration: number;
  /** Transition smoothness */
  transitionSmoothness: number;
  /** Onset-offset ratio (real expressions have specific ratios) */
  onsetOffsetRatio: number;
}

export interface FaceRegion {
  /** Region name */
  name: string;
  /** Landmark indices */
  landmarks: number[];
  /** Region center */
  center: { x: number; y: number };
  /** Region bounds */
  bounds: { x: number; y: number; width: number; height: number };
}

// ============================================================================
// ACTION UNIT DEFINITIONS (FACS)
// ============================================================================

const ACTION_UNIT_DEFINITIONS: Record<number, {
  name: string;
  muscles: string[];
  region: 'brow' | 'eye' | 'nose' | 'mouth' | 'cheek' | 'jaw' | 'lip';
  description: string;
}> = {
  1: { name: 'Inner Brow Raiser', muscles: ['frontalis, medial'], region: 'brow', description: 'Raises inner corners of eyebrows' },
  2: { name: 'Outer Brow Raiser', muscles: ['frontalis, lateral'], region: 'brow', description: 'Raises outer corners of eyebrows' },
  4: { name: 'Brow Lowerer', muscles: ['corrugator', 'depressor supercilii'], region: 'brow', description: 'Lowers and draws eyebrows together' },
  5: { name: 'Upper Lid Raiser', muscles: ['levator palpebrae superioris'], region: 'eye', description: 'Widens eyes' },
  6: { name: 'Cheek Raiser', muscles: ['orbicularis oculi'], region: 'cheek', description: 'Raises cheeks (Duchenne marker)' },
  7: { name: 'Lid Tightener', muscles: ['orbicularis oculi'], region: 'eye', description: 'Tightens eyelids' },
  9: { name: 'Nose Wrinkler', muscles: ['levator labii superioris alaeque nasi'], region: 'nose', description: 'Wrinkles nose' },
  10: { name: 'Upper Lip Raiser', muscles: ['levator labii superioris'], region: 'lip', description: 'Raises upper lip' },
  11: { name: 'Nasolabial Deepener', muscles: ['zygomaticus minor'], region: 'cheek', description: 'Deepens nasolabial furrow' },
  12: { name: 'Lip Corner Puller', muscles: ['zygomaticus major'], region: 'mouth', description: 'Pulls lip corners up (smile)' },
  13: { name: 'Cheek Puffer', muscles: ['levator anguli oris'], region: 'cheek', description: 'Puffs cheeks' },
  14: { name: 'Dimpler', muscles: ['buccinator'], region: 'mouth', description: 'Creates dimples' },
  15: { name: 'Lip Corner Depressor', muscles: ['depressor anguli oris'], region: 'mouth', description: 'Pulls lip corners down' },
  16: { name: 'Lower Lip Depressor', muscles: ['depressor labii inferioris'], region: 'lip', description: 'Lowers lower lip' },
  17: { name: 'Chin Raiser', muscles: ['mentalis'], region: 'jaw', description: 'Raises chin' },
  18: { name: 'Lip Puckerer', muscles: ['incisivii labii'], region: 'lip', description: 'Puckers lips' },
  20: { name: 'Lip Stretcher', muscles: ['risorius'], region: 'mouth', description: 'Stretches lips horizontally' },
  22: { name: 'Lip Funneler', muscles: ['orbicularis oris'], region: 'lip', description: 'Funnels lips' },
  23: { name: 'Lip Tightener', muscles: ['orbicularis oris'], region: 'lip', description: 'Tightens lips' },
  24: { name: 'Lip Pressor', muscles: ['orbicularis oris'], region: 'lip', description: 'Presses lips together' },
  25: { name: 'Lips Part', muscles: ['depressor labii', 'mentalis'], region: 'lip', description: 'Parts lips' },
  26: { name: 'Jaw Drop', muscles: ['masseter', 'temporalis'], region: 'jaw', description: 'Opens jaw' },
  27: { name: 'Mouth Stretch', muscles: ['pterygoids', 'digastric'], region: 'jaw', description: 'Stretches mouth open' },
  28: { name: 'Lip Suck', muscles: ['orbicularis oris'], region: 'lip', description: 'Sucks lips in' },
  38: { name: 'Nostril Dilator', muscles: ['nasalis'], region: 'nose', description: 'Dilates nostrils' },
  39: { name: 'Nostril Compressor', muscles: ['nasalis', 'compressor naris'], region: 'nose', description: 'Compresses nostrils' },
  43: { name: 'Eye Closure', muscles: ['orbicularis oculi'], region: 'eye', description: 'Closes eyes' },
  45: { name: 'Blink', muscles: ['orbicularis oculi'], region: 'eye', description: 'Blinks' },
  46: { name: 'Wink', muscles: ['orbicularis oculi'], region: 'eye', description: 'Winks one eye' }
};

// Expression patterns based on AU combinations
const EXPRESSION_PATTERNS: Record<MicroExpressionType, {
  requiredAUs: number[];
  optionalAUs: number[];
  forbiddenAUs: number[];
  minIntensity: number;
}> = {
  happiness: {
    requiredAUs: [12], // Lip Corner Puller
    optionalAUs: [6],  // Cheek Raiser (Duchenne smile)
    forbiddenAUs: [15, 17], // Lip Corner Depressor, Chin Raiser
    minIntensity: 2
  },
  sadness: {
    requiredAUs: [1, 15], // Inner Brow Raiser, Lip Corner Depressor
    optionalAUs: [4, 17], // Brow Lowerer, Chin Raiser
    forbiddenAUs: [12], // Lip Corner Puller
    minIntensity: 1
  },
  anger: {
    requiredAUs: [4, 5], // Brow Lowerer, Upper Lid Raiser
    optionalAUs: [7, 23, 24], // Lid Tightener, Lip Tightener, Lip Pressor
    forbiddenAUs: [12], // Lip Corner Puller
    minIntensity: 2
  },
  fear: {
    requiredAUs: [1, 2, 5], // Inner/Outer Brow Raiser, Upper Lid Raiser
    optionalAUs: [4, 20, 25], // Brow Lowerer, Lip Stretcher, Lips Part
    forbiddenAUs: [12], // Lip Corner Puller
    minIntensity: 2
  },
  disgust: {
    requiredAUs: [9], // Nose Wrinkler
    optionalAUs: [10, 17], // Upper Lip Raiser, Chin Raiser
    forbiddenAUs: [12], // Lip Corner Puller
    minIntensity: 2
  },
  contempt: {
    requiredAUs: [14], // Dimpler (unilateral)
    optionalAUs: [12], // Lip Corner Puller
    forbiddenAUs: [],
    minIntensity: 1
  },
  surprise: {
    requiredAUs: [1, 2, 5, 25, 26], // Brow Raisers, Lid Raiser, Lips Part, Jaw Drop
    optionalAUs: [27], // Mouth Stretch
    forbiddenAUs: [4], // Brow Lowerer
    minIntensity: 2
  },
  neutral: {
    requiredAUs: [],
    optionalAUs: [],
    forbiddenAUs: [1, 2, 4, 5, 6, 9, 10, 12, 15, 16, 17, 20, 23, 24, 25, 26, 27],
    minIntensity: 0
  },
  mixed: {
    requiredAUs: [],
    optionalAUs: [],
    forbiddenAUs: [],
    minIntensity: 0
  }
};

// ============================================================================
// MICRO-EXPRESSION ANALYZER
// ============================================================================

/**
 * Micro-Expression Analyzer
 * Detects and analyzes facial micro-expressions for deepfake detection
 */
export class MicroExpressionAnalyzer {
  private config: MicroExpressionConfig;
  private auHistory: Map<number, { intensities: number[]; timestamps: number[] }> = new Map();

  constructor(config: Partial<MicroExpressionConfig> = {}) {
    this.config = {
      intensityThreshold: config.intensityThreshold || 0.5,
      symmetryThreshold: config.symmetryThreshold || 0.15,
      minMicroExpressionDuration: config.minMicroExpressionDuration || 40, // ms
      maxMicroExpressionDuration: config.maxMicroExpressionDuration || 200, // ms
      naturalOnsetOffsetRatio: config.naturalOnsetOffsetRatio || { min: 0.5, max: 2.0 },
      ...config
    };
  }

  /**
   * Analyze facial landmarks for micro-expressions
   */
  analyze(
    landmarks: Array<{ x: number; y: number }>,
    timestamp: number,
    previousLandmarks?: Array<{ x: number; y: number }>,
    previousTimestamp?: number
  ): ExpressionAnalysisResult {
    const id = `expr_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const analysisStart = Date.now();

    // Detect Action Units from landmarks
    const actionUnits = this.detectActionUnits(landmarks, previousLandmarks);

    // Update AU history
    this.updateAUHistory(actionUnits, timestamp);

    // Detect micro-expressions
    const microExpressions = this.detectMicroExpressions(actionUnits, timestamp);

    // Analyze symmetry
    const symmetryAnalysis = this.analyzeSymmetry(landmarks, actionUnits);

    // Analyze temporal dynamics
    const temporalDynamics = this.analyzeTemporalDynamics();

    // Detect anomalies
    const anomalies = this.detectAnomalies(
      actionUnits,
      microExpressions,
      symmetryAnalysis,
      temporalDynamics
    );

    // Calculate deepfake probability
    const deepfakeProbability = this.calculateDeepfakeProbability(
      anomalies,
      symmetryAnalysis,
      temporalDynamics
    );

    // Calculate naturalness score
    const naturalnessScore = 1 - deepfakeProbability;

    // Build timeline entry
    const timeline: ExpressionTimelineEntry[] = [{
      timestamp,
      expression: this.classifyExpression(actionUnits),
      intensity: this.calculateOverallIntensity(actionUnits),
      actionUnits: actionUnits.filter(au => au.intensity >= this.config.intensityThreshold).map(au => au.number)
    }];

    return {
      id,
      timestamp: analysisStart,
      deepfakeProbability,
      actionUnits,
      microExpressions,
      timeline,
      anomalies,
      symmetryAnalysis,
      temporalDynamics,
      naturalnessScore,
      recommendations: this.generateRecommendations(anomalies, naturalnessScore)
    };
  }

  /**
   * Analyze sequence of frames
   */
  analyzeSequence(
    frames: Array<{
      landmarks: Array<{ x: number; y: number }>;
      timestamp: number;
    }>
  ): ExpressionAnalysisResult {
    if (frames.length === 0) {
      return this.getEmptyResult();
    }

    // Reset history
    this.auHistory.clear();

    let lastResult: ExpressionAnalysisResult | null = null;
    const allAnomalies: ExpressionAnomaly[] = [];
    const allMicroExpressions: MicroExpression[] = [];
    const timeline: ExpressionTimelineEntry[] = [];

    for (let i = 0; i < frames.length; i++) {
      const prevFrame = i > 0 ? frames[i - 1] : undefined;

      const result = this.analyze(
        frames[i].landmarks,
        frames[i].timestamp,
        prevFrame?.landmarks,
        prevFrame?.timestamp
      );

      lastResult = result;
      allAnomalies.push(...result.anomalies);
      allMicroExpressions.push(...result.microExpressions);
      timeline.push(...result.timeline);
    }

    // Aggregate results
    const symmetryAnalysis = lastResult?.symmetryAnalysis || this.getDefaultSymmetryAnalysis();
    const temporalDynamics = this.analyzeTemporalDynamics();
    const actionUnits = lastResult?.actionUnits || [];

    const deepfakeProbability = this.calculateDeepfakeProbability(
      allAnomalies,
      symmetryAnalysis,
      temporalDynamics
    );

    return {
      id: `expr_seq_${Date.now()}`,
      timestamp: Date.now(),
      deepfakeProbability,
      actionUnits,
      microExpressions: allMicroExpressions,
      timeline,
      anomalies: allAnomalies,
      symmetryAnalysis,
      temporalDynamics,
      naturalnessScore: 1 - deepfakeProbability,
      recommendations: this.generateRecommendations(allAnomalies, 1 - deepfakeProbability)
    };
  }

  /**
   * Detect Action Units from facial landmarks
   */
  private detectActionUnits(
    landmarks: Array<{ x: number; y: number }>,
    previousLandmarks?: Array<{ x: number; y: number }>
  ): FacialActionUnit[] {
    if (landmarks.length < 68) {
      return [];
    }

    const actionUnits: FacialActionUnit[] = [];

    // AU 1: Inner Brow Raiser
    const au1Intensity = this.detectAU1(landmarks);
    if (au1Intensity > 0) {
      actionUnits.push(this.createAU(1, au1Intensity, 'bilateral', 0.85));
    }

    // AU 2: Outer Brow Raiser
    const au2Intensity = this.detectAU2(landmarks);
    if (au2Intensity > 0) {
      actionUnits.push(this.createAU(2, au2Intensity, 'bilateral', 0.85));
    }

    // AU 4: Brow Lowerer
    const au4Intensity = this.detectAU4(landmarks);
    if (au4Intensity > 0) {
      actionUnits.push(this.createAU(4, au4Intensity, 'bilateral', 0.8));
    }

    // AU 5: Upper Lid Raiser
    const au5Intensity = this.detectAU5(landmarks);
    if (au5Intensity > 0) {
      actionUnits.push(this.createAU(5, au5Intensity, 'bilateral', 0.75));
    }

    // AU 6: Cheek Raiser (Duchenne marker)
    const au6Intensity = this.detectAU6(landmarks);
    if (au6Intensity > 0) {
      actionUnits.push(this.createAU(6, au6Intensity, 'bilateral', 0.7));
    }

    // AU 9: Nose Wrinkler
    const au9Intensity = this.detectAU9(landmarks);
    if (au9Intensity > 0) {
      actionUnits.push(this.createAU(9, au9Intensity, 'bilateral', 0.8));
    }

    // AU 10: Upper Lip Raiser
    const au10Intensity = this.detectAU10(landmarks);
    if (au10Intensity > 0) {
      actionUnits.push(this.createAU(10, au10Intensity, 'bilateral', 0.75));
    }

    // AU 12: Lip Corner Puller (smile)
    const { left: au12Left, right: au12Right } = this.detectAU12(landmarks);
    if (au12Left > 0) {
      actionUnits.push(this.createAU(12, au12Left, 'left', 0.9));
    }
    if (au12Right > 0) {
      actionUnits.push(this.createAU(12, au12Right, 'right', 0.9));
    }

    // AU 15: Lip Corner Depressor
    const au15Intensity = this.detectAU15(landmarks);
    if (au15Intensity > 0) {
      actionUnits.push(this.createAU(15, au15Intensity, 'bilateral', 0.85));
    }

    // AU 17: Chin Raiser
    const au17Intensity = this.detectAU17(landmarks);
    if (au17Intensity > 0) {
      actionUnits.push(this.createAU(17, au17Intensity, 'bilateral', 0.8));
    }

    // AU 20: Lip Stretcher
    const au20Intensity = this.detectAU20(landmarks);
    if (au20Intensity > 0) {
      actionUnits.push(this.createAU(20, au20Intensity, 'bilateral', 0.75));
    }

    // AU 25: Lips Part
    const au25Intensity = this.detectAU25(landmarks);
    if (au25Intensity > 0) {
      actionUnits.push(this.createAU(25, au25Intensity, 'bilateral', 0.9));
    }

    // AU 26: Jaw Drop
    const au26Intensity = this.detectAU26(landmarks);
    if (au26Intensity > 0) {
      actionUnits.push(this.createAU(26, au26Intensity, 'bilateral', 0.85));
    }

    // AU 45: Blink
    if (previousLandmarks) {
      const au45Intensity = this.detectAU45(landmarks, previousLandmarks);
      if (au45Intensity > 0) {
        actionUnits.push(this.createAU(45, au45Intensity, 'bilateral', 0.95));
      }
    }

    return actionUnits;
  }

  /**
   * Create Action Unit object
   */
  private createAU(
    number: number,
    intensity: number,
    laterality: 'left' | 'right' | 'bilateral',
    confidence: number
  ): FacialActionUnit {
    const definition = ACTION_UNIT_DEFINITIONS[number];
    return {
      number,
      name: definition?.name || `AU ${number}`,
      intensity: Math.min(5, intensity * 5), // Scale to 0-5
      laterality,
      confidence,
      muscles: definition?.muscles || []
    };
  }

  /**
   * AU 1: Inner Brow Raiser
   * Detection: Inner eyebrow corners raised relative to neutral
   */
  private detectAU1(landmarks: Array<{ x: number; y: number }>): number {
    // Inner brow points (17-21 left, 22-26 right)
    const leftInnerBrow = landmarks[21]; // Left inner brow
    const rightInnerBrow = landmarks[22]; // Right inner brow

    // Reference points
    const leftBrowCenter = landmarks[19]; // Left brow center
    const rightBrowCenter = landmarks[24]; // Right brow center

    // Calculate vertical distance (y increases downward)
    const leftDiff = leftBrowCenter.y - leftInnerBrow.y;
    const rightDiff = rightBrowCenter.y - rightInnerBrow.y;

    // Normalize by face size
    const faceHeight = Math.abs(landmarks[8].y - landmarks[27].y);
    const normalizedLeft = leftDiff / (faceHeight * 0.1);
    const normalizedRight = rightDiff / (faceHeight * 0.1);

    // Threshold for detection
    const threshold = 0.5;
    return Math.max(0, Math.min(1, (normalizedLeft + normalizedRight) / 2 - threshold));
  }

  /**
   * AU 2: Outer Brow Raiser
   */
  private detectAU2(landmarks: Array<{ x: number; y: number }>): number {
    const leftOuterBrow = landmarks[17];
    const rightOuterBrow = landmarks[26];
    const leftBrowCenter = landmarks[19];
    const rightBrowCenter = landmarks[24];

    const leftDiff = leftBrowCenter.y - leftOuterBrow.y;
    const rightDiff = rightBrowCenter.y - rightOuterBrow.y;

    const faceHeight = Math.abs(landmarks[8].y - landmarks[27].y);
    const normalizedLeft = leftDiff / (faceHeight * 0.08);
    const normalizedRight = rightDiff / (faceHeight * 0.08);

    const threshold = 0.3;
    return Math.max(0, Math.min(1, (normalizedLeft + normalizedRight) / 2 - threshold));
  }

  /**
   * AU 4: Brow Lowerer
   */
  private detectAU4(landmarks: Array<{ x: number; y: number }>): number {
    // Measure distance between eyebrows (closer together = more intense)
    const leftInnerBrow = landmarks[21];
    const rightInnerBrow = landmarks[22];
    const leftOuterBrow = landmarks[17];
    const rightOuterBrow = landmarks[26];

    const innerDistance = Math.abs(rightInnerBrow.x - leftInnerBrow.x);
    const outerDistance = Math.abs(rightOuterBrow.x - leftOuterBrow.x);

    const ratio = innerDistance / outerDistance;
    const threshold = 0.35;

    return Math.max(0, Math.min(1, (threshold - ratio) / threshold));
  }

  /**
   * AU 5: Upper Lid Raiser
   */
  private detectAU5(landmarks: Array<{ x: number; y: number }>): number {
    // Eye landmarks: 36-41 left, 42-47 right
    const leftUpperLid = landmarks[37];
    const leftLowerLid = landmarks[41];
    const rightUpperLid = landmarks[43];
    const rightLowerLid = landmarks[47];

    const leftEyeOpen = leftLowerLid.y - leftUpperLid.y;
    const rightEyeOpen = rightLowerLid.y - rightUpperLid.y;

    const faceHeight = Math.abs(landmarks[8].y - landmarks[27].y);
    const normalizedLeft = leftEyeOpen / (faceHeight * 0.08);
    const normalizedRight = rightEyeOpen / (faceHeight * 0.08);

    const threshold = 0.6;
    return Math.max(0, Math.min(1, (normalizedLeft + normalizedRight) / 2 - threshold));
  }

  /**
   * AU 6: Cheek Raiser
   */
  private detectAU6(landmarks: Array<{ x: number; y: number }>): number {
    // Cheek raise causes narrowing of eye opening at the sides
    const leftOuterEye = landmarks[36];
    const leftInnerEye = landmarks[39];
    const rightInnerEye = landmarks[42];
    const rightOuterEye = landmarks[45];

    // Cheek points
    const leftCheek = landmarks[1];
    const rightCheek = landmarks[15];

    // Measure cheek elevation
    const leftCheekElevation = leftOuterEye.y - leftCheek.y;
    const rightCheekElevation = rightOuterEye.y - rightCheek.y;

    const faceHeight = Math.abs(landmarks[8].y - landmarks[27].y);
    const normalized = (leftCheekElevation + rightCheekElevation) / (faceHeight * 0.3);

    const threshold = 0.4;
    return Math.max(0, Math.min(1, normalized - threshold));
  }

  /**
   * AU 9: Nose Wrinkler
   */
  private detectAU9(landmarks: Array<{ x: number; y: number }>): number {
    const noseBridge = landmarks[27];
    const noseTip = landmarks[30];
    const leftNoseSide = landmarks[31];
    const rightNoseSide = landmarks[35];

    // Measure nose compression (wrinkling causes nose to appear shorter)
    const noseLength = noseTip.y - noseBridge.y;
    const noseWidth = Math.abs(rightNoseSide.x - leftNoseSide.x);

    const faceHeight = Math.abs(landmarks[8].y - landmarks[27].y);
    const aspectRatio = noseWidth / noseLength;

    // Higher aspect ratio = more wrinkling
    const threshold = 0.5;
    return Math.max(0, Math.min(1, aspectRatio / threshold - 1));
  }

  /**
   * AU 10: Upper Lip Raiser
   */
  private detectAU10(landmarks: Array<{ x: number; y: number }>): number {
    const noseBase = landmarks[33];
    const upperLip = landmarks[51];
    const mouthCenter = landmarks[62];

    const lipRaise = noseBase.y - upperLip.y;
    const mouthOpen = mouthCenter.y - upperLip.y;

    const faceHeight = Math.abs(landmarks[8].y - landmarks[27].y);
    const normalized = lipRaise / (faceHeight * 0.1);

    const threshold = 0.3;
    return Math.max(0, Math.min(1, normalized - threshold));
  }

  /**
   * AU 12: Lip Corner Puller (asymmetric detection)
   */
  private detectAU12(landmarks: Array<{ x: number; y: number }>): { left: number; right: number } {
    const leftCorner = landmarks[48];
    const rightCorner = landmarks[54];
    const mouthCenter = landmarks[51];

    // Measure corner elevation relative to mouth center
    const leftElevation = mouthCenter.y - leftCorner.y;
    const rightElevation = mouthCenter.y - rightCorner.y;

    const faceHeight = Math.abs(landmarks[8].y - landmarks[27].y);

    return {
      left: Math.max(0, Math.min(1, leftElevation / (faceHeight * 0.05))),
      right: Math.max(0, Math.min(1, rightElevation / (faceHeight * 0.05)))
    };
  }

  /**
   * AU 15: Lip Corner Depressor
   */
  private detectAU15(landmarks: Array<{ x: number; y: number }>): number {
    const leftCorner = landmarks[48];
    const rightCorner = landmarks[54];
    const mouthCenter = landmarks[51];

    // Measure corner depression (negative elevation)
    const leftDepression = leftCorner.y - mouthCenter.y;
    const rightDepression = rightCorner.y - mouthCenter.y;

    const faceHeight = Math.abs(landmarks[8].y - landmarks[27].y);
    const normalized = (leftDepression + rightDepression) / (faceHeight * 0.06);

    return Math.max(0, Math.min(1, normalized));
  }

  /**
   * AU 17: Chin Raiser
   */
  private detectAU17(landmarks: Array<{ x: number; y: number }>): number {
    const lowerLip = landmarks[57];
    const chin = landmarks[8];

    const chinRaise = chin.y - lowerLip.y;
    const faceHeight = Math.abs(landmarks[8].y - landmarks[27].y);
    const normalized = chinRaise / (faceHeight * 0.12);

    const threshold = 0.3;
    return Math.max(0, Math.min(1, normalized - threshold));
  }

  /**
   * AU 20: Lip Stretcher
   */
  private detectAU20(landmarks: Array<{ x: number; y: number }>): number {
    const leftCorner = landmarks[48];
    const rightCorner = landmarks[54];
    const noseBase = landmarks[33];

    const mouthWidth = Math.abs(rightCorner.x - leftCorner.x);
    const faceWidth = Math.abs(landmarks[16].x - landmarks[0].x);

    const ratio = mouthWidth / faceWidth;
    const threshold = 0.35;

    return Math.max(0, Math.min(1, (ratio - threshold) / 0.15));
  }

  /**
   * AU 25: Lips Part
   */
  private detectAU25(landmarks: Array<{ x: number; y: number }>): number {
    const upperLip = landmarks[51];
    const lowerLip = landmarks[57];

    const lipSeparation = lowerLip.y - upperLip.y;
    const faceHeight = Math.abs(landmarks[8].y - landmarks[27].y);
    const normalized = lipSeparation / (faceHeight * 0.05);

    const threshold = 0.15;
    return Math.max(0, Math.min(1, normalized - threshold));
  }

  /**
   * AU 26: Jaw Drop
   */
  private detectAU26(landmarks: Array<{ x: number; y: number }>): number {
    const upperLip = landmarks[51];
    const chin = landmarks[8];

    const jawOpening = chin.y - upperLip.y;
    const faceHeight = Math.abs(landmarks[8].y - landmarks[27].y);
    const normalized = jawOpening / (faceHeight * 0.2);

    const threshold = 0.4;
    return Math.max(0, Math.min(1, (normalized - threshold) / 0.3));
  }

  /**
   * AU 45: Blink detection
   */
  private detectAU45(
    landmarks: Array<{ x: number; y: number }>,
    previousLandmarks: Array<{ x: number; y: number }>
  ): number {
    // Calculate eye opening in both frames
    const leftEyeOpen = landmarks[41].y - landmarks[37].y;
    const prevLeftEyeOpen = previousLandmarks[41].y - previousLandmarks[37].y;

    const rightEyeOpen = landmarks[47].y - landmarks[43].y;
    const prevRightEyeOpen = previousLandmarks[47].y - previousLandmarks[43].y;

    // Detect significant closing
    const leftClosing = prevLeftEyeOpen - leftEyeOpen;
    const rightClosing = prevRightEyeOpen - rightEyeOpen;

    if (leftClosing > prevLeftEyeOpen * 0.5 && rightClosing > prevRightEyeOpen * 0.5) {
      return 1;
    }

    return 0;
  }

  /**
   * Update Action Unit history
   */
  private updateAUHistory(actionUnits: FacialActionUnit[], timestamp: number): void {
    for (const au of actionUnits) {
      if (!this.auHistory.has(au.number)) {
        this.auHistory.set(au.number, { intensities: [], timestamps: [] });
      }

      const history = this.auHistory.get(au.number)!;
      history.intensities.push(au.intensity);
      history.timestamps.push(timestamp);

      // Keep last 100 entries
      if (history.intensities.length > 100) {
        history.intensities.shift();
        history.timestamps.shift();
      }
    }
  }

  /**
   * Detect micro-expressions from action unit patterns
   */
  private detectMicroExpressions(
    actionUnits: FacialActionUnit[],
    timestamp: number
  ): MicroExpression[] {
    const expressions: MicroExpression[] = [];

    // Classify current expression
    const expressionType = this.classifyExpression(actionUnits);
    const intensity = this.calculateOverallIntensity(actionUnits);

    if (expressionType !== 'neutral' && intensity >= this.config.intensityThreshold) {
      // Check for micro-expression timing
      const duration = this.estimateExpressionDuration(expressionType, timestamp);

      if (duration >= this.config.minMicroExpressionDuration &&
          duration <= this.config.maxMicroExpressionDuration) {
        expressions.push({
          type: expressionType,
          startTime: timestamp - duration,
          duration,
          intensity,
          actionUnits: actionUnits.filter(au => au.intensity >= this.config.intensityThreshold),
          symmetry: this.calculateAUSymmetry(actionUnits),
          naturalness: this.calculateNaturalness(actionUnits, duration),
          confidence: this.calculateExpressionConfidence(actionUnits, expressionType)
        });
      }
    }

    return expressions;
  }

  /**
   * Classify expression from Action Units
   */
  private classifyExpression(actionUnits: FacialActionUnit[]): MicroExpressionType {
    const activeAUs = new Set(actionUnits.filter(au => au.intensity >= this.config.intensityThreshold).map(au => au.number));

    let bestMatch: MicroExpressionType = 'neutral';
    let bestScore = 0;

    for (const [type, pattern] of Object.entries(EXPRESSION_PATTERNS)) {
      if (type === 'mixed') continue;

      let score = 0;

      // Check required AUs
      const requiredPresent = pattern.requiredAUs.filter(au => activeAUs.has(au)).length;
      score += requiredPresent / Math.max(pattern.requiredAUs.length, 1) * 0.5;

      // Check optional AUs
      const optionalPresent = pattern.optionalAUs.filter(au => activeAUs.has(au)).length;
      score += optionalPresent / Math.max(pattern.optionalAUs.length, 1) * 0.3;

      // Check forbidden AUs (penalize if present)
      const forbiddenPresent = pattern.forbiddenAUs.filter(au => activeAUs.has(au)).length;
      score -= forbiddenPresent * 0.2;

      if (score > bestScore) {
        bestScore = score;
        bestMatch = type as MicroExpressionType;
      }
    }

    // If no clear match, check for mixed
    if (bestScore < 0.3 && activeAUs.size > 0) {
      return 'mixed';
    }

    return bestMatch;
  }

  /**
   * Calculate overall expression intensity
   */
  private calculateOverallIntensity(actionUnits: FacialActionUnit[]): number {
    if (actionUnits.length === 0) return 0;

    const intensities = actionUnits.map(au => au.intensity / 5); // Normalize to 0-1
    return Math.max(...intensities);
  }

  /**
   * Estimate expression duration from history
   */
  private estimateExpressionDuration(type: MicroExpressionType, currentTimestamp: number): number {
    // Find onset time from AU history
    let earliestTimestamp = currentTimestamp;

    for (const [_, history] of this.auHistory) {
      for (let i = history.intensities.length - 1; i >= 0; i--) {
        if (history.intensities[i] >= this.config.intensityThreshold * 5) {
          earliestTimestamp = Math.min(earliestTimestamp, history.timestamps[i]);
        } else {
          break;
        }
      }
    }

    return currentTimestamp - earliestTimestamp;
  }

  /**
   * Calculate AU symmetry
   */
  private calculateAUSymmetry(actionUnits: FacialActionUnit[]): number {
    const bilateralAUs = actionUnits.filter(au => au.laterality === 'bilateral');
    if (bilateralAUs.length === 0) return 1;

    // For bilateral AUs, we've already averaged left/right
    // Symmetry is based on consistency of detection
    let symmetrySum = 0;

    for (const au of bilateralAUs) {
      // Higher confidence = better symmetry detection
      symmetrySum += au.confidence;
    }

    return symmetrySum / bilateralAUs.length;
  }

  /**
   * Calculate naturalness of expression
   */
  private calculateNaturalness(actionUnits: FacialActionUnit[], duration: number): number {
    // Natural expressions have:
    // 1. Appropriate duration
    // 2. Smooth intensity transitions
    // 3. Co-occurring muscle groups

    let naturalness = 1;

    // Duration check
    if (duration < 40) naturalness *= 0.7; // Too fast
    if (duration > 5000) naturalness *= 0.8; // Held too long

    // Check for co-occurring muscle groups
    const auNumbers = actionUnits.map(au => au.number);
    const coOccurrenceScore = this.checkCoOccurrence(auNumbers);
    naturalness *= coOccurrenceScore;

    return naturalness;
  }

  /**
   * Check if AU combination typically co-occurs
   */
  private checkCoOccurrence(auNumbers: number[]): number {
    // Define typical AU co-occurrence groups
    const coOccurrenceGroups = [
      [1, 2], // Inner and outer brow raisers often together
      [6, 12], // Cheek raiser and lip corner puller (Duchenne smile)
      [4, 5, 7], // Anger pattern
      [1, 2, 5, 25, 26], // Surprise pattern
      [9, 10], // Disgust pattern
      [1, 4, 15], // Sadness pattern
    ];

    let matchCount = 0;
    let totalChecks = 0;

    for (const group of coOccurrenceGroups) {
      const present = group.filter(au => auNumbers.includes(au)).length;
      if (present > 0) {
        totalChecks++;
        if (present >= group.length * 0.5) {
          matchCount++;
        }
      }
    }

    return totalChecks > 0 ? matchCount / totalChecks : 0.5;
  }

  /**
   * Calculate confidence of expression classification
   */
  private calculateExpressionConfidence(
    actionUnits: FacialActionUnit[],
    type: MicroExpressionType
  ): number {
    const pattern = EXPRESSION_PATTERNS[type];
    if (!pattern) return 0.5;

    const auNumbers = actionUnits.map(au => au.number);
    const requiredMatch = pattern.requiredAUs.filter(au => auNumbers.includes(au)).length;
    const requiredTotal = Math.max(pattern.requiredAUs.length, 1);

    return requiredMatch / requiredTotal;
  }

  /**
   * Analyze facial symmetry
   */
  private analyzeSymmetry(
    landmarks: Array<{ x: number; y: number }>,
    actionUnits: FacialActionUnit[]
  ): SymmetryAnalysisResult {
    // Guard clause for insufficient landmarks
    if (landmarks.length < 68) {
      return {
        overallScore: 1,
        asymmetries: [],
        naturalAsymmetryDetected: true
      };
    }

    const asymmetries: Array<{
      au: number;
      leftIntensity: number;
      rightIntensity: number;
      difference: number;
    }> = [];

    // Check AU 12 symmetry (smile)
    const au12Left = actionUnits.find(au => au.number === 12 && au.laterality === 'left');
    const au12Right = actionUnits.find(au => au.number === 12 && au.laterality === 'right');

    if (au12Left && au12Right) {
      asymmetries.push({
        au: 12,
        leftIntensity: au12Left.intensity,
        rightIntensity: au12Right.intensity,
        difference: Math.abs(au12Left.intensity - au12Right.intensity)
      });
    }

    // Check landmark symmetry
    const leftEyeCenter = {
      x: (landmarks[36].x + landmarks[39].x) / 2,
      y: (landmarks[36].y + landmarks[39].y) / 2
    };
    const rightEyeCenter = {
      x: (landmarks[42].x + landmarks[45].x) / 2,
      y: (landmarks[42].y + landmarks[45].y) / 2
    };

    const noseBridge = landmarks[27];

    // Distance from nose bridge to each eye
    const leftDist = Math.sqrt(
      Math.pow(leftEyeCenter.x - noseBridge.x, 2) +
      Math.pow(leftEyeCenter.y - noseBridge.y, 2)
    );
    const rightDist = Math.sqrt(
      Math.pow(rightEyeCenter.x - noseBridge.x, 2) +
      Math.pow(rightEyeCenter.y - noseBridge.y, 2)
    );

    const eyeAsymmetry = Math.abs(leftDist - rightDist) / Math.max(leftDist, rightDist);

    // Calculate overall symmetry score
    let overallScore = 1 - eyeAsymmetry;

    for (const asym of asymmetries) {
      overallScore -= asym.difference / 10; // Normalize intensity difference
    }

    overallScore = Math.max(0, Math.min(1, overallScore));

    return {
      overallScore,
      asymmetries,
      naturalAsymmetryDetected: eyeAsymmetry < 0.1 && asymmetries.length === 0
    };
  }

  /**
   * Analyze temporal dynamics of expressions
   */
  private analyzeTemporalDynamics(): TemporalDynamicsResult {
    // Estimate dynamics from AU history
    const onsetDurations: number[] = [];
    const apexDurations: number[] = [];
    const offsetDurations: number[] = [];

    for (const [_, history] of this.auHistory) {
      if (history.intensities.length < 5) continue;

      // Find onset, apex, offset
      let onsetEnd = 0;
      let apexEnd = 0;
      let maxValue = 0;

      for (let i = 0; i < history.intensities.length; i++) {
        if (history.intensities[i] > maxValue) {
          maxValue = history.intensities[i];
          onsetEnd = i;
        }
      }

      // Find offset
      for (let i = onsetEnd; i < history.intensities.length; i++) {
        if (history.intensities[i] < maxValue * 0.3) {
          apexEnd = i;
          break;
        }
      }

      if (onsetEnd > 0 && apexEnd > onsetEnd) {
        const onsetDuration = history.timestamps[onsetEnd] - history.timestamps[0];
        const apexDuration = history.timestamps[apexEnd] - history.timestamps[onsetEnd];
        const offsetDuration = history.timestamps[history.intensities.length - 1] - history.timestamps[apexEnd];

        onsetDurations.push(onsetDuration);
        apexDurations.push(apexDuration);
        offsetDurations.push(offsetDuration);
      }
    }

    const avgOnsetDuration = onsetDurations.length > 0
      ? onsetDurations.reduce((a, b) => a + b, 0) / onsetDurations.length
      : 200;
    const avgApexDuration = apexDurations.length > 0
      ? apexDurations.reduce((a, b) => a + b, 0) / apexDurations.length
      : 100;
    const avgOffsetDuration = offsetDurations.length > 0
      ? offsetDurations.reduce((a, b) => a + b, 0) / offsetDurations.length
      : 300;

    const onsetOffsetRatio = avgOffsetDuration > 0 ? avgOnsetDuration / avgOffsetDuration : 1;

    // Transition smoothness (inverse of variance)
    const transitionSmoothness = 1 / (1 + Math.abs(onsetOffsetRatio - 1));

    return {
      avgOnsetDuration,
      avgApexDuration,
      avgOffsetDuration,
      transitionSmoothness,
      onsetOffsetRatio
    };
  }

  /**
   * Detect anomalies in expressions
   */
  private detectAnomalies(
    actionUnits: FacialActionUnit[],
    microExpressions: MicroExpression[],
    symmetryAnalysis: SymmetryAnalysisResult,
    temporalDynamics: TemporalDynamicsResult
  ): ExpressionAnomaly[] {
    const anomalies: ExpressionAnomaly[] = [];

    // Symmetry anomalies
    if (symmetryAnalysis.overallScore < 1 - this.config.symmetryThreshold) {
      anomalies.push({
        type: 'symmetry',
        description: `Facial asymmetry detected (score: ${symmetryAnalysis.overallScore.toFixed(2)})`,
        severity: 1 - symmetryAnalysis.overallScore,
        confidence: 0.8,
        relatedAUs: symmetryAnalysis.asymmetries.map(a => a.au)
      });
    }

    // Timing anomalies
    const { min, max } = this.config.naturalOnsetOffsetRatio;
    if (temporalDynamics.onsetOffsetRatio < min || temporalDynamics.onsetOffsetRatio > max) {
      anomalies.push({
        type: 'timing',
        description: `Unnatural onset-offset ratio: ${temporalDynamics.onsetOffsetRatio.toFixed(2)}`,
        severity: Math.min(1, Math.abs(temporalDynamics.onsetOffsetRatio - 1) / 2),
        confidence: 0.75,
        relatedAUs: []
      });
    }

    // Muscle conflict anomalies (AUs that shouldn't co-occur)
    const auNumbers = actionUnits.map(au => au.number);
    const conflicts = this.detectMuscleConflicts(auNumbers);
    for (const conflict of conflicts) {
      anomalies.push({
        type: 'muscle_conflict',
        description: `Muscle conflict: ${conflict.description}`,
        severity: 0.7,
        confidence: 0.85,
        relatedAUs: conflict.aus
      });
    }

    // Duration anomalies in micro-expressions
    for (const expr of microExpressions) {
      if (expr.duration < this.config.minMicroExpressionDuration) {
        anomalies.push({
          type: 'timing',
          description: `Expression too fast: ${expr.duration}ms`,
          severity: 0.6,
          confidence: 0.7,
          timestamp: expr.startTime,
          relatedAUs: expr.actionUnits.map(au => au.number)
        });
      }
    }

    return anomalies;
  }

  /**
   * Detect muscle conflicts (AUs that shouldn't co-occur)
   */
  private detectMuscleConflicts(auNumbers: number[]): Array<{ aus: number[]; description: string }> {
    const conflicts: Array<{ aus: number[]; description: string }> = [];

    // AU 12 (smile) conflicts with AU 15 (frown)
    if (auNumbers.includes(12) && auNumbers.includes(15)) {
      conflicts.push({
        aus: [12, 15],
        description: 'Smile (AU12) and frown (AU15) simultaneously'
      });
    }

    // AU 1+2 (brow raise) conflicts with AU 4 (brow lower)
    if ((auNumbers.includes(1) || auNumbers.includes(2)) && auNumbers.includes(4)) {
      conflicts.push({
        aus: [1, 2, 4],
        description: 'Brow raise (AU1/2) and brow lower (AU4) simultaneously'
      });
    }

    return conflicts;
  }

  /**
   * Calculate deepfake probability from anomalies
   */
  private calculateDeepfakeProbability(
    anomalies: ExpressionAnomaly[],
    symmetryAnalysis: SymmetryAnalysisResult,
    temporalDynamics: TemporalDynamicsResult
  ): number {
    if (anomalies.length === 0) return 0;

    let probability = 0;

    // Weight anomalies by type
    const typeWeights: Record<string, number> = {
      'symmetry': 0.3,
      'timing': 0.25,
      'intensity': 0.2,
      'coherence': 0.3,
      'sequence': 0.25,
      'muscle_conflict': 0.4
    };

    for (const anomaly of anomalies) {
      const weight = typeWeights[anomaly.type] || 0.2;
      probability += anomaly.severity * anomaly.confidence * weight;
    }

    // Add penalty for symmetry issues
    if (symmetryAnalysis.overallScore < 0.8) {
      probability += (1 - symmetryAnalysis.overallScore) * 0.2;
    }

    // Add penalty for timing issues
    if (temporalDynamics.transitionSmoothness < 0.7) {
      probability += (1 - temporalDynamics.transitionSmoothness) * 0.15;
    }

    return Math.min(probability, 1);
  }

  /**
   * Generate recommendations
   */
  private generateRecommendations(anomalies: ExpressionAnomaly[], naturalnessScore: number): string[] {
    const recommendations: string[] = [];

    if (naturalnessScore < 0.5) {
      recommendations.push('Low expression naturalness - possible deepfake detected');
    }

    const anomalyTypes = new Set(anomalies.map(a => a.type));

    if (anomalyTypes.has('symmetry')) {
      recommendations.push('Facial asymmetry detected - deepfakes often show expression asymmetry');
    }

    if (anomalyTypes.has('timing')) {
      recommendations.push('Unnatural expression timing detected - real expressions have specific dynamics');
    }

    if (anomalyTypes.has('muscle_conflict')) {
      recommendations.push('Conflicting facial muscle activations detected - physically impossible expressions');
    }

    if (anomalyTypes.has('sequence')) {
      recommendations.push('Unnatural expression sequence detected');
    }

    if (recommendations.length === 0) {
      recommendations.push('Expressions appear natural');
    }

    return recommendations;
  }

  /**
   * Get empty result
   */
  private getEmptyResult(): ExpressionAnalysisResult {
    return {
      id: `expr_empty_${Date.now()}`,
      timestamp: Date.now(),
      deepfakeProbability: 0,
      actionUnits: [],
      microExpressions: [],
      timeline: [],
      anomalies: [],
      symmetryAnalysis: this.getDefaultSymmetryAnalysis(),
      temporalDynamics: {
        avgOnsetDuration: 200,
        avgApexDuration: 100,
        avgOffsetDuration: 300,
        transitionSmoothness: 1,
        onsetOffsetRatio: 1
      },
      naturalnessScore: 1,
      recommendations: ['No facial landmarks provided for analysis']
    };
  }

  /**
   * Get default symmetry analysis
   */
  private getDefaultSymmetryAnalysis(): SymmetryAnalysisResult {
    return {
      overallScore: 1,
      asymmetries: [],
      naturalAsymmetryDetected: true
    };
  }
}

// ============================================================================
// CONFIGURATION
// ============================================================================

export interface MicroExpressionConfig {
  /** Minimum intensity threshold for AU detection */
  intensityThreshold: number;
  /** Symmetry difference threshold */
  symmetryThreshold: number;
  /** Minimum micro-expression duration (ms) */
  minMicroExpressionDuration: number;
  /** Maximum micro-expression duration (ms) */
  maxMicroExpressionDuration: number;
  /** Natural onset-offset ratio range */
  naturalOnsetOffsetRatio: { min: number; max: number };
}

// ============================================================================
// CONVENIENCE FUNCTIONS
// ============================================================================

/**
 * Analyze micro-expressions from landmarks
 */
export function analyzeMicroExpressions(
  landmarks: Array<{ x: number; y: number }>,
  timestamp: number,
  config?: Partial<MicroExpressionConfig>
): ExpressionAnalysisResult {
  const analyzer = new MicroExpressionAnalyzer(config);
  return analyzer.analyze(landmarks, timestamp);
}

/**
 * Detect Action Units from landmarks
 */
export function detectActionUnits(
  landmarks: Array<{ x: number; y: number }>
): FacialActionUnit[] {
  const analyzer = new MicroExpressionAnalyzer();
  const result = analyzer.analyze(landmarks, Date.now());
  return result.actionUnits;
}

/**
 * Classify expression from landmarks
 */
export function classifyExpression(
  landmarks: Array<{ x: number; y: number }>
): MicroExpressionType {
  const analyzer = new MicroExpressionAnalyzer();
  const result = analyzer.analyze(landmarks, Date.now());
  return result.timeline[0]?.expression || 'neutral';
}

/**
 * Analyze expression sequence
 */
export function analyzeExpressionSequence(
  frames: Array<{
    landmarks: Array<{ x: number; y: number }>;
    timestamp: number;
  }>
): ExpressionAnalysisResult {
  const analyzer = new MicroExpressionAnalyzer();
  return analyzer.analyzeSequence(frames);
}

// ============================================================================
// TESTS
// ============================================================================

/**
 * Run micro-expression tests
 */
export function runMicroExpressionTests(): {
  passed: boolean;
  summary: { total: number; passed: number; failed: number };
  details: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const tests: Array<{ name: string; passed: boolean; error?: string }> = [];

  // Test 1: Analyzer instantiation
  try {
    const analyzer = new MicroExpressionAnalyzer();
    tests.push({ name: 'Analyzer instantiation', passed: true });
  } catch (error) {
    tests.push({ name: 'Analyzer instantiation', passed: false, error: String(error) });
  }

  // Test 2: Empty landmarks handling
  try {
    const analyzer = new MicroExpressionAnalyzer();
    const result = analyzer.analyze([], Date.now());
    tests.push({
      name: 'Empty landmarks handling',
      passed: result.actionUnits.length === 0
    });
  } catch (error) {
    tests.push({ name: 'Empty landmarks handling', passed: false, error: String(error) });
  }

  // Test 3: Action Unit detection
  try {
    const analyzer = new MicroExpressionAnalyzer();
    // Generate synthetic 68-point landmarks (neutral face)
    const landmarks = generateSyntheticLandmarks();
    const result = analyzer.analyze(landmarks, Date.now());
    tests.push({
      name: 'Action Unit detection',
      passed: Array.isArray(result.actionUnits)
    });
  } catch (error) {
    tests.push({ name: 'Action Unit detection', passed: false, error: String(error) });
  }

  // Test 4: Expression classification
  try {
    const analyzer = new MicroExpressionAnalyzer();
    const landmarks = generateSyntheticLandmarks();
    const result = analyzer.analyze(landmarks, Date.now());
    tests.push({
      name: 'Expression classification',
      passed: ['neutral', 'happiness', 'sadness', 'anger', 'fear', 'disgust', 'contempt', 'surprise', 'mixed'].includes(result.timeline[0]?.expression || 'neutral')
    });
  } catch (error) {
    tests.push({ name: 'Expression classification', passed: false, error: String(error) });
  }

  // Test 5: Symmetry analysis
  try {
    const analyzer = new MicroExpressionAnalyzer();
    const landmarks = generateSyntheticLandmarks();
    const result = analyzer.analyze(landmarks, Date.now());
    tests.push({
      name: 'Symmetry analysis',
      passed: typeof result.symmetryAnalysis.overallScore === 'number'
    });
  } catch (error) {
    tests.push({ name: 'Symmetry analysis', passed: false, error: String(error) });
  }

  // Test 6: Temporal dynamics
  try {
    const analyzer = new MicroExpressionAnalyzer();
    const landmarks = generateSyntheticLandmarks();
    const result = analyzer.analyze(landmarks, Date.now());
    tests.push({
      name: 'Temporal dynamics',
      passed: typeof result.temporalDynamics.transitionSmoothness === 'number'
    });
  } catch (error) {
    tests.push({ name: 'Temporal dynamics', passed: false, error: String(error) });
  }

  // Test 7: Sequence analysis
  try {
    const analyzer = new MicroExpressionAnalyzer();
    const frames = [];

    for (let i = 0; i < 10; i++) {
      frames.push({
        landmarks: generateSyntheticLandmarks(),
        timestamp: i * 33
      });
    }

    const result = analyzer.analyzeSequence(frames);
    tests.push({
      name: 'Sequence analysis',
      passed: result.timeline.length === 10
    });
  } catch (error) {
    tests.push({ name: 'Sequence analysis', passed: false, error: String(error) });
  }

  // Test 8: Anomaly detection
  try {
    const analyzer = new MicroExpressionAnalyzer();
    const landmarks = generateSyntheticLandmarks();
    const result = analyzer.analyze(landmarks, Date.now());
    tests.push({
      name: 'Anomaly detection',
      passed: Array.isArray(result.anomalies)
    });
  } catch (error) {
    tests.push({ name: 'Anomaly detection', passed: false, error: String(error) });
  }

  // Test 9: Convenience functions
  try {
    const landmarks = generateSyntheticLandmarks();
    const result = analyzeMicroExpressions(landmarks, Date.now());
    const aus = detectActionUnits(landmarks);
    const expr = classifyExpression(landmarks);

    tests.push({
      name: 'Convenience functions',
      passed: result !== undefined && Array.isArray(aus) && typeof expr === 'string'
    });
  } catch (error) {
    tests.push({ name: 'Convenience functions', passed: false, error: String(error) });
  }

  // Test 10: Deepfake probability calculation
  try {
    const analyzer = new MicroExpressionAnalyzer();
    const landmarks = generateSyntheticLandmarks();
    const result = analyzer.analyze(landmarks, Date.now());
    tests.push({
      name: 'Deepfake probability calculation',
      passed: typeof result.deepfakeProbability === 'number' &&
        result.deepfakeProbability >= 0 &&
        result.deepfakeProbability <= 1
    });
  } catch (error) {
    tests.push({ name: 'Deepfake probability calculation', passed: false, error: String(error) });
  }

  const passed = tests.filter(t => t.passed).length;
  const failed = tests.filter(t => !t.passed).length;

  return {
    passed: failed === 0,
    summary: { total: tests.length, passed, failed },
    details: tests
  };
}

/**
 * Generate synthetic 68-point landmarks for testing
 */
function generateSyntheticLandmarks(): Array<{ x: number; y: number }> {
  const landmarks: Array<{ x: number; y: number }> = [];

  // Face outline (0-16)
  for (let i = 0; i < 17; i++) {
    const angle = Math.PI + (i / 16) * Math.PI;
    landmarks.push({
      x: 100 + Math.cos(angle) * 40,
      y: 100 + Math.sin(angle) * 50
    });
  }

  // Left eyebrow (17-21)
  for (let i = 0; i < 5; i++) {
    landmarks.push({
      x: 70 + i * 8,
      y: 60 + Math.sin(i * 0.5) * 3
    });
  }

  // Right eyebrow (22-26)
  for (let i = 0; i < 5; i++) {
    landmarks.push({
      x: 110 + i * 8,
      y: 60 + Math.sin(i * 0.5) * 3
    });
  }

  // Nose bridge (27-30)
  for (let i = 0; i < 4; i++) {
    landmarks.push({
      x: 100,
      y: 70 + i * 10
    });
  }

  // Nose bottom (31-35)
  for (let i = 0; i < 5; i++) {
    landmarks.push({
      x: 90 + i * 5,
      y: 105
    });
  }

  // Left eye (36-41)
  for (let i = 0; i < 6; i++) {
    const angle = (i / 6) * Math.PI * 2;
    landmarks.push({
      x: 80 + Math.cos(angle) * 10,
      y: 75 + Math.sin(angle) * 5
    });
  }

  // Right eye (42-47)
  for (let i = 0; i < 6; i++) {
    const angle = (i / 6) * Math.PI * 2;
    landmarks.push({
      x: 120 + Math.cos(angle) * 10,
      y: 75 + Math.sin(angle) * 5
    });
  }

  // Mouth outline (48-59)
  for (let i = 0; i < 12; i++) {
    const angle = (i / 12) * Math.PI * 2;
    landmarks.push({
      x: 100 + Math.cos(angle) * 20,
      y: 125 + Math.sin(angle) * 8
    });
  }

  // Mouth inner (60-67)
  for (let i = 0; i < 8; i++) {
    const angle = (i / 8) * Math.PI * 2;
    landmarks.push({
      x: 100 + Math.cos(angle) * 15,
      y: 125 + Math.sin(angle) * 5
    });
  }

  return landmarks;
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

const microExpressionModule = {
  MicroExpressionAnalyzer,
  analyzeMicroExpressions,
  detectActionUnits,
  classifyExpression,
  analyzeExpressionSequence,
  runMicroExpressionTests,
  ACTION_UNIT_DEFINITIONS,
  EXPRESSION_PATTERNS
};

export default microExpressionModule;
