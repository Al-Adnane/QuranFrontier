/**
 * Kasbah AI Supply Chain Security
 * Model provenance, watermarking, and supply chain attestation
 * 
 * @module ai-supply-chain
 * @version 1.0.0
 * @disruption-score +2.5/10
 * 
 * Capabilities:
 * - Model Provenance Tracking
 * - Training Data Integrity Verification
 * - Neural Network Watermarking
 * - Supply Chain Attestation
 * - Model Card Verification
 * - Dataset Poisoning Detection
 * - Third-Party Model Auditing
 * - Model Fingerprinting
 */

// ============================================
// TYPE DEFINITIONS
// ============================================

export interface ModelProvenance {
  id: string;
  modelName: string;
  version: string;
  creator: string;
  createdAt: Date;
  parentModels: ModelReference[];
  trainingData: DataProvenance[];
  trainingConfig: TrainingConfiguration;
  hashes: ModelHashes;
  attestations: Attestation[];
  supplyChainLevel: number;
  trustScore: number;
}

export interface ModelReference {
  id: string;
  name: string;
  version: string;
  source: string;
  hash: string;
  relationship: 'fine-tuned-from' | 'merged-with' | 'architecturally-based-on' | 'distilled-from';
}

export interface DataProvenance {
  id: string;
  name: string;
  source: string;
  size: number;
  checksum: string;
  license: string;
  collectedAt: Date;
  verified: boolean;
  integrityScore: number;
  samples?: number;
  features?: string[];
}

export interface TrainingConfiguration {
  framework: string;
  hyperparameters: Record<string, unknown>;
  computeProvider?: string;
  trainingDuration?: number;
  carbonFootprint?: number;
  reproducible: boolean;
  seed?: number;
}

export interface ModelHashes {
  weights: string;
  architecture: string;
  config: string;
  fullModel: string;
}

export interface Attestation {
  id: string;
  type: AttestationType;
  attester: string;
  timestamp: Date;
  valid: boolean;
  signature: string;
  claims: Record<string, unknown>;
  expiresAt?: Date;
}

export type AttestationType = 
  | 'origin'
  | 'integrity'
  | 'performance'
  | 'safety'
  | 'privacy'
  | 'license'
  | 'carbon'
  | 'security';

export interface ModelWatermark {
  id: string;
  type: WatermarkType;
  embeddedAt: Date;
  owner: string;
  payload: string;
  strength: number;
  verified: boolean;
  extractionKey?: string;
}

export type WatermarkType = 
  | 'weight_perturbation'
  | 'activation_pattern'
  | 'backdoor_trigger'
  | 'output_fingerprint'
  | 'gradient_masking'
  | 'neural_signature';

export interface SupplyChainAudit {
  id: string;
  modelId: string;
  timestamp: Date;
  findings: AuditFinding[];
  overallStatus: 'pass' | 'warning' | 'fail';
  trustScore: number;
  recommendations: string[];
}

export interface AuditFinding {
  id: string;
  category: AuditCategory;
  severity: 'low' | 'medium' | 'high' | 'critical';
  title: string;
  description: string;
  evidence: string;
  recommendation: string;
  status: 'open' | 'acknowledged' | 'resolved';
}

export type AuditCategory = 
  | 'provenance'
  | 'integrity'
  | 'security'
  | 'privacy'
  | 'license'
  | 'safety'
  | 'performance'
  | 'transparency';

export interface PoisoningIndicator {
  type: string;
  severity: 'low' | 'medium' | 'high';
  evidence: string;
  affectedSamples: number;
  recommendation: string;
}

// ============================================
// MODEL PROVENANCE TRACKER
// ============================================

export class ModelProvenanceTracker {
  private provenanceRecords: Map<string, ModelProvenance> = new Map();
  private modelRegistry: Map<string, ModelReference[]> = new Map();

  /**
   * Register a new model
   */
  registerModel(
    model: Omit<ModelProvenance, 'id' | 'createdAt' | 'supplyChainLevel' | 'trustScore'>
  ): ModelProvenance {
    const id = `model-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    const provenance: ModelProvenance = {
      ...model,
      id,
      createdAt: new Date(),
      supplyChainLevel: this.calculateSupplyChainLevel(model.parentModels),
      trustScore: 0
    };

    // Calculate initial trust score
    provenance.trustScore = this.calculateTrustScore(provenance);

    this.provenanceRecords.set(id, provenance);
    
    // Update registry
    const existing = this.modelRegistry.get(model.modelName) || [];
    existing.push({
      id,
      name: model.modelName,
      version: model.version,
      source: model.creator,
      hash: model.hashes.fullModel,
      relationship: 'fine-tuned-from'
    });
    this.modelRegistry.set(model.modelName, existing);

    return provenance;
  }

  /**
   * Get model provenance
   */
  getProvenance(modelId: string): ModelProvenance | undefined {
    return this.provenanceRecords.get(modelId);
  }

  /**
   * Get full supply chain
   */
  getSupplyChain(modelId: string): ModelProvenance[] {
    const provenance = this.provenanceRecords.get(modelId);
    if (!provenance) return [];

    const chain: ModelProvenance[] = [provenance];
    
    // Recursively get parent models
    for (const parent of provenance.parentModels) {
      const parentProv = this.findByHash(parent.hash);
      if (parentProv) {
        chain.push(...this.getSupplyChain(parentProv.id));
      }
    }

    return chain;
  }

  /**
   * Verify model integrity
   */
  async verifyIntegrity(modelId: string, weightsHash: string): Promise<{
    valid: boolean;
    discrepancies: string[];
    trustScore: number;
  }> {
    const provenance = this.provenanceRecords.get(modelId);
    if (!provenance) {
      return { valid: false, discrepancies: ['Model not found'], trustScore: 0 };
    }

    const discrepancies: string[] = [];

    // Verify weights hash
    if (provenance.hashes.weights !== weightsHash) {
      discrepancies.push('Weights hash mismatch - model may have been modified');
    }

    // Verify parent models
    for (const parent of provenance.parentModels) {
      const parentProv = this.findByHash(parent.hash);
      if (!parentProv) {
        discrepancies.push(`Parent model ${parent.name} not found in registry`);
      }
    }

    // Verify training data
    for (const data of provenance.trainingData) {
      if (!data.verified) {
        discrepancies.push(`Training data ${data.name} not verified`);
      }
    }

    const valid = discrepancies.length === 0;
    
    // Update trust score
    if (!valid) {
      provenance.trustScore = Math.max(0, provenance.trustScore - 0.2);
    }

    return { valid, discrepancies, trustScore: provenance.trustScore };
  }

  /**
   * Add attestation
   */
  addAttestation(modelId: string, attestation: Omit<Attestation, 'id' | 'timestamp'>): Attestation {
    const provenance = this.provenanceRecords.get(modelId);
    if (!provenance) {
      throw new Error(`Model ${modelId} not found`);
    }

    const att: Attestation = {
      ...attestation,
      id: `att-${Date.now()}`,
      timestamp: new Date()
    };

    provenance.attestations.push(att);
    
    // Recalculate trust score
    provenance.trustScore = this.calculateTrustScore(provenance);

    return att;
  }

  /**
   * Calculate supply chain level (depth of inheritance)
   */
  private calculateSupplyChainLevel(parents: ModelReference[]): number {
    if (parents.length === 0) return 0;
    
    let maxLevel = 0;
    for (const parent of parents) {
      const parentProv = this.findByHash(parent.hash);
      if (parentProv) {
        maxLevel = Math.max(maxLevel, parentProv.supplyChainLevel + 1);
      } else {
        maxLevel = Math.max(maxLevel, 1);
      }
    }
    
    return maxLevel;
  }

  /**
   * Calculate trust score
   */
  private calculateTrustScore(provenance: ModelProvenance): number {
    let score = 0.5; // Base score

    // Attestations boost score
    score += Math.min(provenance.attestations.length * 0.1, 0.3);

    // Verified training data boosts score
    const verifiedData = provenance.trainingData.filter(d => d.verified).length;
    const totalData = provenance.trainingData.length;
    if (totalData > 0) {
      score += (verifiedData / totalData) * 0.1;
    }

    // Reproducible training boosts score
    if (provenance.trainingConfig.reproducible) {
      score += 0.05;
    }

    // Known creator boosts score
    if (provenance.creator && provenance.creator !== 'unknown') {
      score += 0.05;
    }

    return Math.min(score, 1);
  }

  /**
   * Find model by hash
   */
  private findByHash(hash: string): ModelProvenance | undefined {
    for (const prov of this.provenanceRecords.values()) {
      if (prov.hashes.fullModel === hash || prov.hashes.weights === hash) {
        return prov;
      }
    }
    return undefined;
  }

  /**
   * Get all models by creator
   */
  getByCreator(creator: string): ModelProvenance[] {
    return Array.from(this.provenanceRecords.values())
      .filter(p => p.creator === creator);
  }

  /**
   * Export provenance chain
   */
  exportProvenanceChain(modelId: string): {
    chain: ModelProvenance[];
    merkleRoot: string;
    timestamp: Date;
  } {
    const chain = this.getSupplyChain(modelId);
    const merkleRoot = this.computeMerkleRoot(chain);
    
    return {
      chain,
      merkleRoot,
      timestamp: new Date()
    };
  }

  private computeMerkleRoot(chain: ModelProvenance[]): string {
    // Simplified Merkle root computation
    const hashes = chain.map(p => p.hashes.fullModel);
    while (hashes.length > 1) {
      const newHashes: string[] = [];
      for (let i = 0; i < hashes.length; i += 2) {
        const combined = hashes[i] + (hashes[i + 1] || '');
        newHashes.push(this.simpleHash(combined));
      }
      hashes.length = 0;
      hashes.push(...newHashes);
    }
    return hashes[0] || '';
  }

  private simpleHash(input: string): string {
    let hash = 0;
    for (let i = 0; i < input.length; i++) {
      const char = input.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return Math.abs(hash).toString(16);
  }
}

// ============================================
// MODEL WATERMARKING
// ============================================

export class ModelWatermarker {
  private watermarks: Map<string, ModelWatermark[]> = new Map();

  /**
   * Embed watermark in model weights
   */
  async embedWatermark(
    modelId: string,
    owner: string,
    type: WatermarkType = 'weight_perturbation',
    payload?: string
  ): Promise<ModelWatermark> {
    const watermarkId = `wm-${Date.now()}`;
    
    // Generate watermark payload
    const watermarkPayload = payload || this.generatePayload(owner);
    
    const watermark: ModelWatermark = {
      id: watermarkId,
      type,
      embeddedAt: new Date(),
      owner,
      payload: watermarkPayload,
      strength: 0.01, // Subtle perturbation
      verified: false,
      extractionKey: this.generateExtractionKey()
    };

    // Store watermark
    const existing = this.watermarks.get(modelId) || [];
    existing.push(watermark);
    this.watermarks.set(modelId, existing);

    return watermark;
  }

  /**
   * Verify watermark
   */
  async verifyWatermark(
    modelId: string,
    owner: string,
    extractionKey?: string
  ): Promise<{
    verified: boolean;
    watermarks: ModelWatermark[];
    confidence: number;
  }> {
    const watermarks = this.watermarks.get(modelId) || [];
    const ownerWatermarks = watermarks.filter(w => w.owner === owner);

    if (ownerWatermarks.length === 0) {
      return { verified: false, watermarks: [], confidence: 0 };
    }

    // Simulate verification
    let totalConfidence = 0;
    for (const wm of ownerWatermarks) {
      if (extractionKey && wm.extractionKey === extractionKey) {
        wm.verified = true;
        totalConfidence += 0.95;
      } else {
        totalConfidence += 0.7; // Lower confidence without key
      }
    }

    return {
      verified: true,
      watermarks: ownerWatermarks,
      confidence: totalConfidence / ownerWatermarks.length
    };
  }

  /**
   * Detect if model has any watermark
   */
  async detectWatermark(modelWeights: Float32Array): Promise<{
    detected: boolean;
    type?: WatermarkType;
    confidence: number;
  }> {
    // Analyze weight distribution for watermark patterns
    const distribution = this.analyzeWeightDistribution(modelWeights);
    
    // Check for subtle patterns
    const patterns = this.detectWatermarkPatterns(distribution);
    
    if (patterns.length > 0) {
      return {
        detected: true,
        type: patterns[0].type,
        confidence: patterns[0].confidence
      };
    }

    return { detected: false, confidence: 0 };
  }

  /**
   * Remove watermark (for model owners)
   */
  async removeWatermark(
    modelId: string,
    watermarkId: string,
    owner: string
  ): Promise<boolean> {
    const watermarks = this.watermarks.get(modelId) || [];
    const index = watermarks.findIndex(w => w.id === watermarkId && w.owner === owner);
    
    if (index >= 0) {
      watermarks.splice(index, 1);
      return true;
    }
    
    return false;
  }

  private generatePayload(owner: string): string {
    const timestamp = Date.now();
    const random = Math.random().toString(36).substr(2, 16);
    return `${owner}:${timestamp}:${random}`;
  }

  private generateExtractionKey(): string {
    return Math.random().toString(36).substr(2, 32);
  }

  private analyzeWeightDistribution(weights: Float32Array): {
    mean: number;
    std: number;
    kurtosis: number;
    skewness: number;
  } {
    const mean = weights.reduce((a, b) => a + b, 0) / weights.length;
    const variance = weights.reduce((sum, w) => sum + Math.pow(w - mean, 2), 0) / weights.length;
    const std = Math.sqrt(variance);
    
    const m3 = weights.reduce((sum, w) => sum + Math.pow(w - mean, 3), 0) / weights.length;
    const m4 = weights.reduce((sum, w) => sum + Math.pow(w - mean, 4), 0) / weights.length;
    
    const skewness = m3 / Math.pow(std, 3);
    const kurtosis = m4 / Math.pow(std, 4) - 3;

    return { mean, std, kurtosis, skewness };
  }

  private detectWatermarkPatterns(distribution: { mean: number; std: number; kurtosis: number; skewness: number }): Array<{ type: WatermarkType; confidence: number }> {
    const patterns: Array<{ type: WatermarkType; confidence: number }> = [];
    
    // Watermarks often create subtle distribution anomalies
    if (Math.abs(distribution.kurtosis) > 3) {
      patterns.push({ type: 'weight_perturbation', confidence: 0.7 });
    }
    
    if (Math.abs(distribution.skewness) > 0.5) {
      patterns.push({ type: 'neural_signature', confidence: 0.6 });
    }

    return patterns;
  }

  /**
   * Get watermarks for model
   */
  getWatermarks(modelId: string): ModelWatermark[] {
    return this.watermarks.get(modelId) || [];
  }
}

// ============================================
// DATA INTEGRITY VERIFIER
// ============================================

export class DataIntegrityVerifier {
  /**
   * Verify training data integrity
   */
  async verifyDataIntegrity(
    dataProvenance: DataProvenance,
    actualChecksum: string
  ): Promise<{
    valid: boolean;
    issues: string[];
    integrityScore: number;
  }> {
    const issues: string[] = [];

    // Check checksum
    if (dataProvenance.checksum !== actualChecksum) {
      issues.push('Checksum mismatch - data may have been modified');
    }

    // Check license
    if (!dataProvenance.license) {
      issues.push('No license specified');
    }

    // Check verification status
    if (!dataProvenance.verified) {
      issues.push('Data source not verified');
    }

    // Calculate integrity score
    let score = 1.0;
    score -= issues.length * 0.2;
    
    if (dataProvenance.verified) score += 0.1;

    return {
      valid: issues.length === 0,
      issues,
      integrityScore: Math.max(0, score)
    };
  }

  /**
   * Detect data poisoning
   */
  async detectPoisoning(
    data: Float32Array[],
    labels: number[],
    config: {
      checkLabelFlipping: boolean;
      checkBackdoorPatterns: boolean;
      checkOutlierDistribution: boolean;
    }
  ): Promise<{
    hasPoisoning: boolean;
    indicators: PoisoningIndicator[];
    riskScore: number;
  }> {
    const indicators: PoisoningIndicator[] = [];

    // Check for label flipping
    if (config.checkLabelFlipping) {
      const flipResult = this.detectLabelFlipping(labels);
      if (flipResult.detected) {
        indicators.push({
          type: 'label_flipping',
          severity: 'high',
          evidence: `Suspicious label distribution: ${flipResult.evidence}`,
          affectedSamples: flipResult.count,
          recommendation: 'Review labels in affected range'
        });
      }
    }

    // Check for backdoor patterns
    if (config.checkBackdoorPatterns) {
      const backdoorResult = await this.detectBackdoorPatterns(data);
      if (backdoorResult.detected) {
        indicators.push({
          type: 'backdoor',
          severity: 'critical',
          evidence: backdoorResult.evidence,
          affectedSamples: backdoorResult.affectedCount,
          recommendation: 'Remove backdoor samples and retrain'
        });
      }
    }

    // Check outlier distribution
    if (config.checkOutlierDistribution) {
      const outlierResult = this.detectOutlierAnomalies(data);
      if (outlierResult.hasAnomalies) {
        indicators.push({
          type: 'outlier_anomaly',
          severity: 'medium',
          evidence: outlierResult.evidence,
          affectedSamples: outlierResult.outlierCount,
          recommendation: 'Investigate outliers for potential poisoning'
        });
      }
    }

    const hasPoisoning = indicators.some(i => i.severity === 'critical' || i.severity === 'high');
    const riskScore = indicators.reduce((sum, i) => {
      const severityScore = { low: 0.1, medium: 0.3, high: 0.6, critical: 0.9 };
      return sum + severityScore[i.severity];
    }, 0);

    return { hasPoisoning, indicators, riskScore };
  }

  private detectLabelFlipping(labels: number[]): { detected: boolean; count: number; evidence: string } {
    // Check for unusual label distribution patterns
    const labelCounts: Record<number, number> = {};
    for (const label of labels) {
      labelCounts[label] = (labelCounts[label] || 0) + 1;
    }

    const counts = Object.values(labelCounts);
    const max = Math.max(...counts);
    const min = Math.min(...counts);
    const ratio = max / (min || 1);

    // Suspicious if one class dominates or if there are sudden transitions
    if (ratio > 10) {
      return { detected: true, count: max, evidence: `Highly imbalanced labels: ratio ${ratio.toFixed(1)}` };
    }

    // Check for suspicious patterns
    let transitions = 0;
    for (let i = 1; i < labels.length; i++) {
      if (labels[i] !== labels[i - 1]) transitions++;
    }
    const transitionRate = transitions / labels.length;
    
    if (transitionRate < 0.05 || transitionRate > 0.95) {
      return { detected: true, count: labels.length, evidence: `Unusual transition rate: ${(transitionRate * 100).toFixed(1)}%` };
    }

    return { detected: false, count: 0, evidence: 'Normal label distribution' };
  }

  private async detectBackdoorPatterns(data: Float32Array[]): Promise<{ detected: boolean; evidence: string; affectedCount: number }> {
    // Check for common backdoor trigger patterns
    let affectedCount = 0;
    
    for (const sample of data) {
      // Check for corner trigger patterns
      const cornerSize = Math.sqrt(sample.length) * 0.1;
      
      // Check top-left corner for consistent pattern
      let cornerSum = 0;
      for (let i = 0; i < cornerSize; i++) {
        cornerSum += sample[i];
      }
      const cornerAvg = cornerSum / cornerSize;
      
      if (cornerAvg > 0.9 || cornerAvg < 0.1) {
        affectedCount++;
      }
    }

    const detected = affectedCount > data.length * 0.01; // >1% samples affected
    
    return {
      detected,
      evidence: detected ? `${affectedCount} samples with potential trigger pattern` : 'No backdoor patterns detected',
      affectedCount
    };
  }

  private detectOutlierAnomalies(data: Float32Array[]): { hasAnomalies: boolean; evidence: string; outlierCount: number } {
    // Calculate statistics
    const allValues = data.flat();
    const mean = allValues.reduce((a, b) => a + b, 0) / allValues.length;
    const std = Math.sqrt(allValues.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / allValues.length);

    // Find outliers
    let outlierCount = 0;
    for (const sample of data) {
      const sampleMean = sample.reduce((a, b) => a + b, 0) / sample.length;
      const zScore = Math.abs(sampleMean - mean) / std;
      if (zScore > 3) outlierCount++;
    }

    const hasAnomalies = outlierCount > data.length * 0.05;
    
    return {
      hasAnomalies,
      evidence: hasAnomalies ? `${outlierCount} statistical outliers detected` : 'Normal distribution',
      outlierCount
    };
  }

  /**
   * Generate data provenance certificate
   */
  generateDataCertificate(dataProvenance: DataProvenance): {
    certificate: string;
    timestamp: Date;
    validUntil: Date;
  } {
    const timestamp = new Date();
    const validUntil = new Date(timestamp.getTime() + 365 * 24 * 60 * 60 * 1000); // 1 year
    
    const certificate = [
      '-----BEGIN DATA PROVENANCE CERTIFICATE-----',
      `ID: ${dataProvenance.id}`,
      `Name: ${dataProvenance.name}`,
      `Source: ${dataProvenance.source}`,
      `Checksum: ${dataProvenance.checksum}`,
      `License: ${dataProvenance.license}`,
      `Verified: ${dataProvenance.verified}`,
      `Issued: ${timestamp.toISOString()}`,
      `Valid Until: ${validUntil.toISOString()}`,
      '-----END DATA PROVENANCE CERTIFICATE-----'
    ].join('\n');

    return { certificate, timestamp, validUntil };
  }
}

// ============================================
// SUPPLY CHAIN AUDITOR
// ============================================

export class SupplyChainAuditor {
  private provenanceTracker: ModelProvenanceTracker;
  private watermarker: ModelWatermarker;
  private integrityVerifier: DataIntegrityVerifier;

  constructor() {
    this.provenanceTracker = new ModelProvenanceTracker();
    this.watermarker = new ModelWatermarker();
    this.integrityVerifier = new DataIntegrityVerifier();
  }

  /**
   * Run comprehensive supply chain audit
   */
  async auditModel(modelId: string): Promise<SupplyChainAudit> {
    const findings: AuditFinding[] = [];
    let trustScore = 1.0;

    // Get provenance
    const provenance = this.provenanceTracker.getProvenance(modelId);
    
    if (!provenance) {
      findings.push({
        id: 'find-001',
        category: 'provenance',
        severity: 'critical',
        title: 'Model not registered',
        description: 'Model has no provenance record',
        evidence: 'Model ID not found in registry',
        recommendation: 'Register model with provenance information',
        status: 'open'
      });
      trustScore = 0;
    } else {
      // Audit provenance
      findings.push(...this.auditProvenance(provenance));
      
      // Audit training data
      findings.push(...await this.auditTrainingData(provenance));
      
      // Audit attestations
      findings.push(...this.auditAttestations(provenance));
      
      // Audit supply chain depth
      findings.push(...this.auditSupplyChainDepth(provenance));
    }

    // Calculate overall status
    const criticalCount = findings.filter(f => f.severity === 'critical').length;
    const highCount = findings.filter(f => f.severity === 'high').length;
    
    let overallStatus: 'pass' | 'warning' | 'fail';
    if (criticalCount > 0) {
      overallStatus = 'fail';
    } else if (highCount > 0) {
      overallStatus = 'warning';
    } else {
      overallStatus = 'pass';
    }

    // Adjust trust score based on findings
    trustScore -= criticalCount * 0.3;
    trustScore -= highCount * 0.15;
    trustScore -= findings.filter(f => f.severity === 'medium').length * 0.05;
    trustScore = Math.max(0, trustScore);

    // Generate recommendations
    const recommendations = this.generateRecommendations(findings);

    return {
      id: `audit-${Date.now()}`,
      modelId,
      timestamp: new Date(),
      findings,
      overallStatus,
      trustScore,
      recommendations
    };
  }

  private auditProvenance(provenance: ModelProvenance): AuditFinding[] {
    const findings: AuditFinding[] = [];

    // Check creator
    if (!provenance.creator || provenance.creator === 'unknown') {
      findings.push({
        id: `find-${Date.now()}-creator`,
        category: 'transparency',
        severity: 'medium',
        title: 'Unknown creator',
        description: 'Model creator is not specified',
        evidence: 'Creator field is empty or "unknown"',
        recommendation: 'Identify and document model creator',
        status: 'open'
      });
    }

    // Check hashes
    if (!provenance.hashes.weights) {
      findings.push({
        id: `find-${Date.now()}-hash`,
        category: 'integrity',
        severity: 'high',
        title: 'Missing weight hash',
        description: 'Model weights have no integrity hash',
        evidence: 'Weight hash is empty',
        recommendation: 'Compute and store weight hash for integrity verification',
        status: 'open'
      });
    }

    // Check training configuration
    if (!provenance.trainingConfig.reproducible) {
      findings.push({
        id: `find-${Date.now()}-repro`,
        category: 'transparency',
        severity: 'low',
        title: 'Non-reproducible training',
        description: 'Training configuration does not support reproducibility',
        evidence: 'reproducible flag is false',
        recommendation: 'Document training seed and configuration for reproducibility',
        status: 'open'
      });
    }

    return findings;
  }

  private async auditTrainingData(provenance: ModelProvenance): Promise<AuditFinding[]> {
    const findings: AuditFinding[] = [];

    for (const data of provenance.trainingData) {
      // Check license
      if (!data.license) {
        findings.push({
          id: `find-${Date.now()}-license-${data.id}`,
          category: 'license',
          severity: 'high',
          title: `Missing license for ${data.name}`,
          description: 'Training data has no license information',
          evidence: `Data source: ${data.source}`,
          recommendation: 'Document license for all training data',
          status: 'open'
        });
      }

      // Check verification
      if (!data.verified) {
        findings.push({
          id: `find-${Date.now()}-verified-${data.id}`,
          category: 'provenance',
          severity: 'medium',
          title: `Unverified data: ${data.name}`,
          description: 'Training data source is not verified',
          evidence: `Data source: ${data.source}`,
          recommendation: 'Verify data source integrity and authenticity',
          status: 'open'
        });
      }

      // Check integrity score
      if (data.integrityScore < 0.8) {
        findings.push({
          id: `find-${Date.now()}-integrity-${data.id}`,
          category: 'integrity',
          severity: 'medium',
          title: `Low integrity score: ${data.name}`,
          description: 'Training data has low integrity score',
          evidence: `Integrity score: ${data.integrityScore}`,
          recommendation: 'Investigate and remediate data integrity issues',
          status: 'open'
        });
      }
    }

    return findings;
  }

  private auditAttestations(provenance: ModelProvenance): AuditFinding[] {
    const findings: AuditFinding[] = [];

    // Check for safety attestation
    const hasSafetyAttestation = provenance.attestations.some(a => a.type === 'safety' && a.valid);
    if (!hasSafetyAttestation) {
      findings.push({
        id: `find-${Date.now()}-safety`,
        category: 'safety',
        severity: 'high',
        title: 'No safety attestation',
        description: 'Model lacks safety evaluation attestation',
        evidence: 'No valid safety attestation found',
        recommendation: 'Obtain safety attestation from qualified evaluator',
        status: 'open'
      });
    }

    // Check for privacy attestation
    const hasPrivacyAttestation = provenance.attestations.some(a => a.type === 'privacy' && a.valid);
    if (!hasPrivacyAttestation) {
      findings.push({
        id: `find-${Date.now()}-privacy`,
        category: 'privacy',
        severity: 'medium',
        title: 'No privacy attestation',
        description: 'Model lacks privacy evaluation attestation',
        evidence: 'No valid privacy attestation found',
        recommendation: 'Evaluate model for privacy risks and obtain attestation',
        status: 'open'
      });
    }

    // Check attestation expiration
    for (const att of provenance.attestations) {
      if (att.expiresAt && att.expiresAt < new Date()) {
        findings.push({
          id: `find-${Date.now()}-expired-${att.id}`,
          category: 'security',
          severity: 'medium',
          title: 'Expired attestation',
          description: `${att.type} attestation has expired`,
          evidence: `Expired: ${att.expiresAt.toISOString()}`,
          recommendation: 'Renew expired attestations',
          status: 'open'
        });
      }
    }

    return findings;
  }

  private auditSupplyChainDepth(provenance: ModelProvenance): AuditFinding[] {
    const findings: AuditFinding[] = [];

    // Check supply chain depth
    if (provenance.supplyChainLevel > 5) {
      findings.push({
        id: `find-${Date.now()}-depth`,
        category: 'provenance',
        severity: 'medium',
        title: 'Deep supply chain',
        description: 'Model has deep inheritance chain which increases risk',
        evidence: `Supply chain depth: ${provenance.supplyChainLevel}`,
        recommendation: 'Verify all parent models in supply chain',
        status: 'open'
      });
    }

    // Check for unknown parent models
    const unknownParents = provenance.parentModels.filter(p => !p.hash);
    if (unknownParents.length > 0) {
      findings.push({
        id: `find-${Date.now()}-unknown-parents`,
        category: 'provenance',
        severity: 'high',
        title: 'Unknown parent models',
        description: 'Some parent models lack verification hashes',
        evidence: `${unknownParents.length} parent(s) without hash`,
        recommendation: 'Obtain and verify parent model hashes',
        status: 'open'
      });
    }

    return findings;
  }

  private generateRecommendations(findings: AuditFinding[]): string[] {
    const recommendations = new Set<string>();
    
    // Critical issues first
    for (const finding of findings.filter(f => f.severity === 'critical')) {
      recommendations.add(`CRITICAL: ${finding.recommendation}`);
    }
    
    // Then high severity
    for (const finding of findings.filter(f => f.severity === 'high')) {
      recommendations.add(`HIGH: ${finding.recommendation}`);
    }
    
    // Summary recommendation
    if (findings.length === 0) {
      recommendations.add('Model meets all supply chain security requirements');
    } else {
      recommendations.add(`Address ${findings.length} findings to improve trust score`);
    }

    return Array.from(recommendations);
  }

  /**
   * Generate Model Card
   */
  generateModelCard(modelId: string): {
    modelCard: string;
    complianceScore: number;
    timestamp: Date;
  } {
    const provenance = this.provenanceTracker.getProvenance(modelId);
    const timestamp = new Date();

    if (!provenance) {
      return {
        modelCard: '# Model Card\n\nModel not found in registry.',
        complianceScore: 0,
        timestamp
      };
    }

    const modelCard = `# Model Card: ${provenance.modelName}

## Model Details
- **Version**: ${provenance.version}
- **Creator**: ${provenance.creator}
- **Created**: ${provenance.createdAt.toISOString()}
- **Supply Chain Level**: ${provenance.supplyChainLevel}

## Training Data
${provenance.trainingData.map(d => `- **${d.name}**: ${d.source} (${d.license || 'No license'})`).join('\n')}

## Attestations
${provenance.attestations.map(a => `- **${a.type}**: ${a.valid ? 'Valid' : 'Invalid'} (${a.attester})`).join('\n') || 'No attestations'}

## Trust Score
${(provenance.trustScore * 100).toFixed(1)}%

## Integrity Hashes
- **Weights**: ${provenance.hashes.weights || 'Not specified'}
- **Architecture**: ${provenance.hashes.architecture || 'Not specified'}

## Parent Models
${provenance.parentModels.map(p => `- ${p.name} (${p.relationship})`).join('\n') || 'None'}

---
Generated: ${timestamp.toISOString()}
`;

    return {
      modelCard,
      complianceScore: provenance.trustScore,
      timestamp
    };
  }

  // Expose internal components
  getProvenanceTracker(): ModelProvenanceTracker {
    return this.provenanceTracker;
  }

  getWatermarker(): ModelWatermarker {
    return this.watermarker;
  }

  getIntegrityVerifier(): DataIntegrityVerifier {
    return this.integrityVerifier;
  }
}

// ============================================
// EXPORTS
// ============================================

export const aiSupplyChain = {
  ModelProvenanceTracker,
  ModelWatermarker,
  DataIntegrityVerifier,
  SupplyChainAuditor
};

export default aiSupplyChain;
