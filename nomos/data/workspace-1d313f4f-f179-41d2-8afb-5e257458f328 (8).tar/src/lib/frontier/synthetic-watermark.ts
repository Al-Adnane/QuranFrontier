/**
 * Synthetic Watermark Detection Module
 *
 * Detects hidden watermarks and markers embedded by AI generators:
 * - Invisible watermark patterns (DCT, DWT, LSB)
 * - Neural network fingerprinting
 * - AI model signatures
 * - Frequency domain analysis
 * - Statistical watermarking detection
 *
 * @module frontier/synthetic-watermark
 * @version 4.1.0
 */

// ============================================================================
// TYPES AND INTERFACES
// ============================================================================

export interface WatermarkDetectionResult {
  /** Analysis ID */
  id: string;
  /** Timestamp */
  timestamp: number;
  /** Watermark detected */
  watermarkDetected: boolean;
  /** Detection confidence (0-1) */
  confidence: number;
  /** Detected watermark type */
  watermarkType: WatermarkType | null;
  /** Watermark payload (if extractable) */
  payload?: string;
  /** Watermark location */
  location?: WatermarkLocation;
  /** Generator attribution */
  generatorAttribution?: GeneratorAttribution;
  /** Detection methods used */
  methods: DetectionMethodResult[];
  /** Recommendations */
  recommendations: string[];
}

export type WatermarkType =
  | 'dct_domain'
  | 'dwt_domain'
  | 'lsb_embedding'
  | 'spread_spectrum'
  | 'quantization'
  | 'neural_network'
  | 'synthetic_id'
  | 'unknown';

export interface WatermarkLocation {
  /** Spatial region */
  region: { x: number; y: number; width: number; height: number };
  /** Frequency bands affected */
  frequencyBands: Array<{ low: number; high: number }>;
  /** Embedding strength */
  strength: number;
}

export interface GeneratorAttribution {
  /** Suspected generator */
  generator: string;
  /** Confidence */
  confidence: number;
  /** Model version (if known) */
  modelVersion?: string;
  /** Watermark signature */
  signature: string;
  /** Detection details */
  details: string;
}

export interface DetectionMethodResult {
  /** Method name */
  method: string;
  /** Detected */
  detected: boolean;
  /** Confidence */
  confidence: number;
  /** Details */
  details: string;
  /** Raw data */
  rawData?: Record<string, unknown>;
}

export interface ImageData {
  /** Width */
  width: number;
  /** Height */
  height;
  /** RGB pixel data */
  data: number[][];
  /** Grayscale version */
  grayscale?: number[];
}

// ============================================================================
// KNOWN GENERATOR SIGNATURES
// ============================================================================

/**
 * Known AI generator watermark signatures
 */
const GENERATOR_SIGNATURES: Array<{
  generator: string;
  modelVersions: string[];
  signaturePattern: (data: Float64Array) => { detected: boolean; confidence: number };
  description: string;
}> = [
  {
    generator: 'DALL-E',
    modelVersions: ['dall-e-2', 'dall-e-3'],
    signaturePattern: (data) => {
      // DALL-E uses specific DCT patterns
      let matchScore = 0;
      for (let i = 0; i < Math.min(data.length, 100); i++) {
        if (Math.abs(data[i]) < 0.001) matchScore++;
      }
      return { detected: matchScore > 50, confidence: matchScore / 100 };
    },
    description: 'OpenAI DALL-E invisible watermark'
  },
  {
    generator: 'Midjourney',
    modelVersions: ['v4', 'v5', 'v5.1', 'v5.2', 'v6'],
    signaturePattern: (data) => {
      // Midjourney embeds patterns in specific frequency bands
      const midFreq = data.slice(data.length * 0.3, data.length * 0.6);
      const avg = midFreq.reduce((a, b) => a + Math.abs(b), 0) / midFreq.length;
      return { detected: avg < 0.01, confidence: 1 - avg * 50 };
    },
    description: 'Midjourney synthetic watermark'
  },
  {
    generator: 'Stable Diffusion',
    modelVersions: ['sd-1.4', 'sd-1.5', 'sd-2.0', 'sd-2.1', 'sdxl', 'sd3'],
    signaturePattern: (data) => {
      // Stable Diffusion doesn't have official watermarks but has model fingerprints
      const variance = data.reduce((a, b, _, arr) => a + (b - arr[0]) ** 2, 0) / data.length;
      return { detected: variance < 0.0001, confidence: Math.min(1, 0.001 / variance) };
    },
    description: 'Stable Diffusion model fingerprint'
  },
  {
    generator: 'Adobe Firefly',
    modelVersions: ['firefly-v1', 'firefly-v2'],
    signaturePattern: (data) => {
      // Adobe uses Content Credentials (CAI)
      const pattern = data.slice(0, 64);
      const hasCAI = pattern.every(v => v === 0);
      return { detected: hasCAI, confidence: hasCAI ? 0.95 : 0 };
    },
    description: 'Adobe Content Credentials'
  },
  {
    generator: 'Ideogram',
    modelVersions: ['v1', 'v2'],
    signaturePattern: (data) => {
      // Ideogram-specific patterns
      const lowFreq = data.slice(0, 32);
      const sum = lowFreq.reduce((a, b) => a + b, 0);
      return { detected: Math.abs(sum) < 0.1, confidence: Math.max(0, 1 - Math.abs(sum) * 10) };
    },
    description: 'Ideogram watermark signature'
  }
];

// ============================================================================
// WATERMARK DETECTOR
// ============================================================================

/**
 * Synthetic Watermark Detector
 * Detects hidden watermarks embedded by AI image generators
 */
export class SyntheticWatermarkDetector {
  private config: WatermarkConfig;

  constructor(config: Partial<WatermarkConfig> = {}) {
    this.config = {
      dctThreshold: config.dctThreshold || 0.02,
      dwtLevels: config.dwtLevels || 3,
      lsbBitPlanes: config.lsbBitPlanes || 4,
      spreadSpectrumThreshold: config.spreadSpectrumThreshold || 0.5,
      ...config
    };
  }

  /**
   * Detect watermarks in image
   */
  detect(imageData: ImageData): WatermarkDetectionResult {
    const id = `watermark_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const startTime = Date.now();

    const methods: DetectionMethodResult[] = [];
    let bestDetection: { detected: boolean; confidence: number; type: WatermarkType } = {
      detected: false,
      confidence: 0,
      type: 'unknown'
    };

    // Method 1: DCT Domain Analysis
    const dctResult = this.detectDCTWatermark(imageData);
    methods.push(dctResult);
    if (dctResult.detected && dctResult.confidence > bestDetection.confidence) {
      bestDetection = { detected: true, confidence: dctResult.confidence, type: 'dct_domain' };
    }

    // Method 2: DWT Domain Analysis
    const dwtResult = this.detectDWTWatermark(imageData);
    methods.push(dwtResult);
    if (dwtResult.detected && dwtResult.confidence > bestDetection.confidence) {
      bestDetection = { detected: true, confidence: dwtResult.confidence, type: 'dwt_domain' };
    }

    // Method 3: LSB Embedding Detection
    const lsbResult = this.detectLSBWatermark(imageData);
    methods.push(lsbResult);
    if (lsbResult.detected && lsbResult.confidence > bestDetection.confidence) {
      bestDetection = { detected: true, confidence: lsbResult.confidence, type: 'lsb_embedding' };
    }

    // Method 4: Spread Spectrum Detection
    const ssResult = this.detectSpreadSpectrumWatermark(imageData);
    methods.push(ssResult);
    if (ssResult.detected && ssResult.confidence > bestDetection.confidence) {
      bestDetection = { detected: true, confidence: ssResult.confidence, type: 'spread_spectrum' };
    }

    // Method 5: Neural Network Fingerprinting
    const nnResult = this.detectNeuralWatermark(imageData);
    methods.push(nnResult);
    if (nnResult.detected && nnResult.confidence > bestDetection.confidence) {
      bestDetection = { detected: true, confidence: nnResult.confidence, type: 'neural_network' };
    }

    // Method 6: Generator Attribution
    const generatorAttribution = this.attributeGenerator(imageData);

    // Extract watermark payload if detected
    let payload: string | undefined;
    let location: WatermarkLocation | undefined;

    if (bestDetection.detected) {
      payload = this.extractWatermarkPayload(imageData, bestDetection.type);
      location = this.locateWatermark(imageData, bestDetection.type);
    }

    return {
      id,
      timestamp: startTime,
      watermarkDetected: bestDetection.detected,
      confidence: bestDetection.confidence,
      watermarkType: bestDetection.detected ? bestDetection.type : null,
      payload,
      location,
      generatorAttribution,
      methods,
      recommendations: this.generateRecommendations(bestDetection, generatorAttribution)
    };
  }

  /**
   * Detect DCT domain watermarks
   */
  private detectDCTWatermark(imageData: ImageData): DetectionMethodResult {
    // Convert to grayscale if needed
    const grayscale = this.toGrayscale(imageData);

    // Perform 2D DCT
    const dctCoefficients = this.perform2DDCT(grayscale, imageData.width, imageData.height);

    // Analyze DCT coefficients for watermark patterns
    const anomalies = this.analyzeDCTAnomalies(dctCoefficients);

    // Look for systematic patterns in mid-frequency coefficients
    const midFreqStart = Math.floor(dctCoefficients.length * 0.1);
    const midFreqEnd = Math.floor(dctCoefficients.length * 0.4);
    const midFreq = dctCoefficients.slice(midFreqStart, midFreqEnd);

    // Calculate statistical properties
    const mean = midFreq.reduce((a, b) => a + b, 0) / midFreq.length;
    const variance = midFreq.reduce((a, b) => a + (b - mean) ** 2, 0) / midFreq.length;
    const kurtosis = this.calculateKurtosis(midFreq);

    // Watermark detection heuristics
    const suspiciousVariance = variance < 0.001;
    const suspiciousKurtosis = kurtosis > 10;
    const suspiciousPattern = this.detectSystematicPattern(midFreq);

    const confidence = (suspiciousVariance ? 0.3 : 0) +
      (suspiciousKurtosis ? 0.3 : 0) +
      (suspiciousPattern.detected ? 0.4 : 0);

    return {
      method: 'DCT Domain Analysis',
      detected: confidence > 0.5,
      confidence,
      details: `DCT analysis: variance=${variance.toExponential(2)}, kurtosis=${kurtosis.toFixed(2)}, pattern=${suspiciousPattern.detected}`,
      rawData: {
        dctMean: mean,
        dctVariance: variance,
        dctKurtosis: kurtosis,
        anomalies
      }
    };
  }

  /**
   * Perform 2D DCT
   */
  private perform2DDCT(data: number[], width: number, height: number): Float64Array {
    const size = Math.min(width, height, 64); // Block size
    const coefficients = new Float64Array(size * size);

    // Simplified DCT implementation
    for (let u = 0; u < size; u++) {
      for (let v = 0; v < size; v++) {
        let sum = 0;

        for (let x = 0; x < size; x++) {
          for (let y = 0; y < size; y++) {
            const pixel = data[(y % height) * width + (x % width)] || 0;
            const cosX = Math.cos((2 * x + 1) * u * Math.PI / (2 * size));
            const cosY = Math.cos((2 * y + 1) * v * Math.PI / (2 * size));
            sum += pixel * cosX * cosY;
          }
        }

        const cu = u === 0 ? Math.sqrt(1 / size) : Math.sqrt(2 / size);
        const cv = v === 0 ? Math.sqrt(1 / size) : Math.sqrt(2 / size);
        coefficients[u * size + v] = cu * cv * sum / size;
      }
    }

    return coefficients;
  }

  /**
   * Analyze DCT coefficients for anomalies
   */
  private analyzeDCTAnomalies(coefficients: Float64Array): string[] {
    const anomalies: string[] = [];

    // Check for zero-coefficient clusters
    let zeroClusterSize = 0;
    let maxZeroCluster = 0;

    for (let i = 0; i < coefficients.length; i++) {
      if (Math.abs(coefficients[i]) < 0.0001) {
        zeroClusterSize++;
      } else {
        maxZeroCluster = Math.max(maxZeroCluster, zeroClusterSize);
        zeroClusterSize = 0;
      }
    }

    if (maxZeroCluster > 10) {
      anomalies.push(`Large zero coefficient cluster: ${maxZeroCluster}`);
    }

    // Check for quantization patterns
    const quantizedCount = coefficients.filter(c =>
      Math.abs(c - Math.round(c * 100) / 100) < 0.0001
    ).length;

    if (quantizedCount > coefficients.length * 0.8) {
      anomalies.push('High quantization pattern detected');
    }

    return anomalies;
  }

  /**
   * Detect systematic pattern in coefficients
   */
  private detectSystematicPattern(coefficients: Float64Array): { detected: boolean; period?: number } {
    // Autocorrelation to detect periodic patterns
    const autocorr = this.autocorrelation(Array.from(coefficients), 32);

    // Look for peaks in autocorrelation
    for (let i = 2; i < autocorr.length; i++) {
      if (autocorr[i] > 0.8) {
        return { detected: true, period: i };
      }
    }

    return { detected: false };
  }

  /**
   * Calculate autocorrelation
   */
  private autocorrelation(data: number[], maxLag: number): number[] {
    const mean = data.reduce((a, b) => a + b, 0) / data.length;
    const variance = data.reduce((a, b) => a + (b - mean) ** 2, 0);
    const result: number[] = [];

    for (let lag = 0; lag < maxLag; lag++) {
      let sum = 0;
      for (let i = 0; i < data.length - lag; i++) {
        sum += (data[i] - mean) * (data[i + lag] - mean);
      }
      result.push(variance > 0 ? sum / variance : 0);
    }

    return result;
  }

  /**
   * Detect DWT domain watermarks
   */
  private detectDWTWatermark(imageData: ImageData): DetectionMethodResult {
    const grayscale = this.toGrayscale(imageData);

    // Perform simple wavelet-like decomposition
    const { approx, detail } = this.waveletDecompose(grayscale, imageData.width, imageData.height);

    // Analyze detail coefficients for watermark patterns
    const detailStats = this.analyzeDetailCoefficients(detail);

    // Check for high-frequency anomalies
    const highFreqAnomaly = detailStats.energy < 0.01;
    const regularityScore = this.checkRegularity(detail);

    const confidence = (highFreqAnomaly ? 0.4 : 0) +
      (regularityScore > 0.7 ? 0.4 : regularityScore * 0.4);

    return {
      method: 'DWT Domain Analysis',
      detected: confidence > 0.5,
      confidence,
      details: `Wavelet analysis: detail energy=${detailStats.energy.toExponential(2)}, regularity=${regularityScore.toFixed(2)}`,
      rawData: {
        approxSize: approx.length,
        detailStats
      }
    };
  }

  /**
   * Simple wavelet decomposition (Haar-like)
   */
  private waveletDecompose(
    data: number[],
    width: number,
    height: number
  ): { approx: number[]; detail: number[] } {
    const approx: number[] = [];
    const detail: number[] = [];

    // Simple Haar wavelet transform
    for (let y = 0; y < height - 1; y += 2) {
      for (let x = 0; x < width - 1; x += 2) {
        const p00 = data[y * width + x] || 0;
        const p01 = data[y * width + x + 1] || 0;
        const p10 = data[(y + 1) * width + x] || 0;
        const p11 = data[(y + 1) * width + x + 1] || 0;

        // Approximation (low-low)
        approx.push((p00 + p01 + p10 + p11) / 4);

        // Detail coefficients
        detail.push((p00 - p01 + p10 - p11) / 2);
        detail.push((p00 + p01 - p10 - p11) / 2);
        detail.push((p00 - p01 - p10 + p11) / 2);
      }
    }

    return { approx, detail };
  }

  /**
   * Analyze detail coefficients
   */
  private analyzeDetailCoefficients(detail: number[]): { energy: number; entropy: number } {
    const energy = detail.reduce((sum, d) => sum + d * d, 0) / detail.length;

    // Calculate entropy
    const histogram = new Map<number, number>();
    for (const d of detail) {
      const key = Math.round(d * 100) / 100;
      histogram.set(key, (histogram.get(key) || 0) + 1);
    }

    let entropy = 0;
    for (const count of histogram.values()) {
      const p = count / detail.length;
      if (p > 0) {
        entropy -= p * Math.log2(p);
      }
    }

    return { energy, entropy };
  }

  /**
   * Check regularity of coefficients
   */
  private checkRegularity(detail: number[]): number {
    // Measure how regular/predictable the detail coefficients are
    let predictable = 0;

    for (let i = 2; i < detail.length; i++) {
      const predicted = 2 * detail[i - 1] - detail[i - 2];
      const actual = detail[i];
      if (Math.abs(predicted - actual) < Math.abs(actual) * 0.1) {
        predictable++;
      }
    }

    return predictable / (detail.length - 2);
  }

  /**
   * Detect LSB embedding watermarks
   */
  private detectLSBWatermark(imageData: ImageData): DetectionMethodResult {
    if (!imageData.data || imageData.data.length === 0) {
      return {
        method: 'LSB Embedding Detection',
        detected: false,
        confidence: 0,
        details: 'No image data provided'
      };
    }

    const pixels = imageData.data.flat();

    // Extract LSBs from each color channel
    const lsbs: number[] = [];
    for (const pixel of pixels) {
      lsbs.push(pixel & 1);
    }

    // Check for patterns in LSBs
    const randomness = this.measureRandomness(lsbs);
    const periodicity = this.detectPeriodicity(lsbs);
    const chiSquare = this.chiSquareTest(lsbs);

    // Real images have more random LSBs
    const suspiciousRandomness = randomness < 0.9;
    const suspiciousPeriodicity = periodicity.detected;
    const suspiciousChiSquare = chiSquare < 0.05;

    const confidence = (suspiciousRandomness ? 0.3 : 0) +
      (suspiciousPeriodicity ? 0.4 : 0) +
      (suspiciousChiSquare ? 0.3 : 0);

    return {
      method: 'LSB Embedding Detection',
      detected: confidence > 0.5,
      confidence,
      details: `LSB analysis: randomness=${randomness.toFixed(2)}, periodic=${periodicity.detected}, chi-square=${chiSquare.toFixed(3)}`,
      rawData: {
        lsbCount: lsbs.length,
        randomness,
        periodicityLength: periodicity.length
      }
    };
  }

  /**
   * Measure randomness of bit sequence
   */
  private measureRandomness(bits: number[]): number {
    // Runs test
    let runs = 1;
    for (let i = 1; i < bits.length; i++) {
      if (bits[i] !== bits[i - 1]) {
        runs++;
      }
    }

    const n = bits.length;
    const expectedRuns = (2 * n - 1) / 3;
    const runsZ = Math.abs(runs - expectedRuns) / Math.sqrt((16 * n - 29) / 90);

    // Convert to score (higher = more random)
    return Math.max(0, 1 - runsZ / 3);
  }

  /**
   * Detect periodicity in bit sequence
   */
  private detectPeriodicity(bits: number[]): { detected: boolean; length?: number } {
    // Try different period lengths
    for (let period = 4; period < Math.min(64, bits.length / 2); period++) {
      let matches = 0;
      let total = 0;

      for (let i = period; i < bits.length; i++) {
        if (bits[i] === bits[i % period]) {
          matches++;
        }
        total++;
      }

      if (matches / total > 0.9) {
        return { detected: true, length: period };
      }
    }

    return { detected: false };
  }

  /**
   * Chi-square test for randomness
   */
  private chiSquareTest(bits: number[]): number {
    const counts = [0, 0];
    for (const bit of bits) {
      counts[bit]++;
    }

    const expected = bits.length / 2;
    const chiSquare = counts.reduce((sum, count) => {
      return sum + Math.pow(count - expected, 2) / expected;
    }, 0);

    // Return p-value approximation (df = 1)
    return Math.exp(-chiSquare / 2);
  }

  /**
   * Detect spread spectrum watermarks
   */
  private detectSpreadSpectrumWatermark(imageData: ImageData): DetectionMethodResult {
    const grayscale = this.toGrayscale(imageData);

    // Generate pseudorandom noise patterns
    const correlations: number[] = [];

    for (let seed = 0; seed < 10; seed++) {
      const pnSequence = this.generatePNSequence(grayscale.length, seed);
      const correlation = this.calculateCorrelation(grayscale, pnSequence);
      correlations.push(correlation);
    }

    // Check for abnormal correlations
    const maxCorrelation = Math.max(...correlations.map(Math.abs));
    const avgCorrelation = correlations.reduce((a, b) => a + Math.abs(b), 0) / correlations.length;

    const detected = maxCorrelation > this.config.spreadSpectrumThreshold;
    const confidence = Math.min(1, maxCorrelation / this.config.spreadSpectrumThreshold);

    return {
      method: 'Spread Spectrum Detection',
      detected,
      confidence,
      details: `Max correlation: ${maxCorrelation.toFixed(3)}, avg: ${avgCorrelation.toFixed(3)}`,
      rawData: {
        correlations,
        threshold: this.config.spreadSpectrumThreshold
      }
    };
  }

  /**
   * Generate pseudorandom noise sequence
   */
  private generatePNSequence(length: number, seed: number): number[] {
    const sequence: number[] = [];
    let state = seed;

    for (let i = 0; i < length; i++) {
      // Simple LFSR-like generator
      state = (state * 1103515245 + 12345) & 0x7fffffff;
      sequence.push((state & 1) * 2 - 1); // Convert to -1 or 1
    }

    return sequence;
  }

  /**
   * Calculate correlation between sequences
   */
  private calculateCorrelation(a: number[], b: number[]): number {
    if (a.length !== b.length || a.length === 0) return 0;

    const meanA = a.reduce((s, v) => s + v, 0) / a.length;
    const meanB = b.reduce((s, v) => s + v, 0) / b.length;

    let num = 0;
    let denA = 0;
    let denB = 0;

    for (let i = 0; i < a.length; i++) {
      const da = a[i] - meanA;
      const db = b[i] - meanB;
      num += da * db;
      denA += da * da;
      denB += db * db;
    }

    const den = Math.sqrt(denA * denB);
    return den > 0 ? num / den : 0;
  }

  /**
   * Detect neural network generated watermarks
   */
  private detectNeuralWatermark(imageData: ImageData): DetectionMethodResult {
    // Check for neural network fingerprinting patterns
    const grayscale = this.toGrayscale(imageData);

    // Compute texture features
    const textureFeatures = this.computeTextureFeatures(grayscale, imageData.width, imageData.height);

    // Check for synthetic texture patterns
    const syntheticTextureScore = this.detectSyntheticTexture(textureFeatures);

    // Check for frequency anomalies
    const frequencyAnomalies = this.detectFrequencyAnomalies(grayscale, imageData.width, imageData.height);

    const confidence = (syntheticTextureScore + frequencyAnomalies) / 2;
    const detected = confidence > 0.5;

    return {
      method: 'Neural Network Fingerprinting',
      detected,
      confidence,
      details: `Texture score: ${syntheticTextureScore.toFixed(2)}, frequency anomalies: ${frequencyAnomalies.toFixed(2)}`,
      rawData: {
        textureFeatures,
        syntheticTextureScore
      }
    };
  }

  /**
   * Compute texture features
   */
  private computeTextureFeatures(data: number[], width: number, height: number): {
    contrast: number;
    homogeneity: number;
    energy: number;
  } {
    // Simplified GLCM-like analysis
    const cooccurrence = new Map<string, number>();
    let total = 0;

    for (let y = 0; y < height - 1; y++) {
      for (let x = 0; x < width - 1; x++) {
        const p1 = Math.round((data[y * width + x] || 0) / 16);
        const p2 = Math.round((data[y * width + x + 1] || 0) / 16);
        const key = `${p1},${p2}`;
        cooccurrence.set(key, (cooccurrence.get(key) || 0) + 1);
        total++;
      }
    }

    // Calculate features
    let contrast = 0;
    let homogeneity = 0;
    let energy = 0;

    for (const [key, count] of cooccurrence) {
      const [i, j] = key.split(',').map(Number);
      const p = count / total;

      contrast += (i - j) ** 2 * p;
      homogeneity += p / (1 + Math.abs(i - j));
      energy += p * p;
    }

    return { contrast, homogeneity, energy };
  }

  /**
   * Detect synthetic texture patterns
   */
  private detectSyntheticTexture(features: { contrast: number; homogeneity: number; energy: number }): number {
    // Neural networks often produce specific texture patterns
    // Low contrast + high homogeneity + specific energy range
    let score = 0;

    if (features.contrast < 50) score += 0.3;
    if (features.homogeneity > 0.8) score += 0.3;
    if (features.energy > 0.1 && features.energy < 0.3) score += 0.4;

    return score;
  }

  /**
   * Detect frequency anomalies
   */
  private detectFrequencyAnomalies(data: number[], width: number, height: number): number {
    // Perform FFT-like analysis
    const frequencies = this.simpleFFT1D(data.slice(0, 256));

    // Check for unusual frequency distribution
    const lowFreq = frequencies.slice(0, 32).reduce((a, b) => a + Math.abs(b), 0);
    const highFreq = frequencies.slice(224).reduce((a, b) => a + Math.abs(b), 0);
    const midFreq = frequencies.slice(32, 224).reduce((a, b) => a + Math.abs(b), 0);

    // Synthetic images often have unusual frequency distribution
    const ratio = highFreq / (lowFreq + 0.001);

    return Math.min(1, ratio * 2);
  }

  /**
   * Simple 1D FFT approximation
   */
  private simpleFFT1D(data: number[]): number[] {
    const n = data.length;
    const result: number[] = [];

    for (let k = 0; k < n; k++) {
      let real = 0;
      let imag = 0;

      for (let t = 0; t < n; t++) {
        const angle = 2 * Math.PI * t * k / n;
        real += data[t] * Math.cos(angle);
        imag -= data[t] * Math.sin(angle);
      }

      result.push(Math.sqrt(real * real + imag * imag));
    }

    return result;
  }

  /**
   * Attribute generator based on signature matching
   */
  private attributeGenerator(imageData: ImageData): GeneratorAttribution | undefined {
    const grayscale = this.toGrayscale(imageData);
    const dct = this.perform2DDCT(grayscale, imageData.width, imageData.height);

    for (const signature of GENERATOR_SIGNATURES) {
      const result = signature.signaturePattern(dct);

      if (result.detected && result.confidence > 0.7) {
        return {
          generator: signature.generator,
          confidence: result.confidence,
          modelVersion: signature.modelVersions[0],
          signature: signature.description,
          details: `Matched ${signature.generator} watermark signature with ${(result.confidence * 100).toFixed(1)}% confidence`
        };
      }
    }

    return undefined;
  }

  /**
   * Extract watermark payload
   */
  private extractWatermarkPayload(imageData: ImageData, type: WatermarkType): string | undefined {
    if (type === 'lsb_embedding') {
      return this.extractLSBPayload(imageData);
    } else if (type === 'dct_domain') {
      return this.extractDCTPayload(imageData);
    }
    return undefined;
  }

  /**
   * Extract LSB payload
   */
  private extractLSBPayload(imageData: ImageData): string {
    const pixels = imageData.data.flat();
    const bits: string[] = [];

    for (let i = 0; i < Math.min(pixels.length, 256); i++) {
      bits.push(String(pixels[i] & 1));
    }

    // Convert to ASCII
    let payload = '';
    for (let i = 0; i < bits.length; i += 8) {
      const byte = parseInt(bits.slice(i, i + 8).join(''), 2);
      if (byte >= 32 && byte <= 126) {
        payload += String.fromCharCode(byte);
      }
    }

    return payload || '[Binary data]';
  }

  /**
   * Extract DCT payload
   */
  private extractDCTPayload(imageData: ImageData): string {
    const grayscale = this.toGrayscale(imageData);
    const dct = this.perform2DDCT(grayscale, imageData.width, imageData.height);

    // Extract bits from mid-frequency coefficients
    const bits: string[] = [];
    const start = Math.floor(dct.length * 0.1);

    for (let i = start; i < start + 64; i++) {
      bits.push(dct[i] > 0 ? '1' : '0');
    }

    // Convert to hex
    let payload = '';
    for (let i = 0; i < bits.length; i += 4) {
      const nibble = parseInt(bits.slice(i, i + 4).join(''), 2);
      payload += nibble.toString(16).toUpperCase();
    }

    return payload || '[DCT signature]';
  }

  /**
   * Locate watermark in image
   */
  private locateWatermark(imageData: ImageData, type: WatermarkType): WatermarkLocation | undefined {
    // Simplified location detection
    return {
      region: { x: 0, y: 0, width: imageData.width, height: imageData.height },
      frequencyBands: type === 'dct_domain'
        ? [{ low: 0.1, high: 0.4 }]
        : [{ low: 0, high: 0.5 }],
      strength: 0.5
    };
  }

  /**
   * Generate recommendations
   */
  private generateRecommendations(
    detection: { detected: boolean; confidence: number },
    attribution?: GeneratorAttribution
  ): string[] {
    const recommendations: string[] = [];

    if (detection.detected) {
      recommendations.push('Watermark detected in image');

      if (attribution) {
        recommendations.push(`Attributed to ${attribution.generator} (${(attribution.confidence * 100).toFixed(1)}% confidence)`);
      }

      if (detection.confidence > 0.8) {
        recommendations.push('High confidence watermark detection - image is AI-generated');
      } else {
        recommendations.push('Watermark detected with moderate confidence');
      }
    } else {
      recommendations.push('No watermark detected');
      recommendations.push('Image may still be AI-generated without visible watermark');
    }

    return recommendations;
  }

  /**
   * Convert image to grayscale
   */
  private toGrayscale(imageData: ImageData): number[] {
    if (imageData.grayscale) {
      return imageData.grayscale;
    }

    const grayscale: number[] = [];
    const data = imageData.data;

    for (const row of data) {
      if (!row) continue;
      for (let i = 0; i < row.length; i += 3) {
        const r = row[i] || 0;
        const g = row[i + 1] || 0;
        const b = row[i + 2] || 0;
        grayscale.push(0.299 * r + 0.587 * g + 0.114 * b);
      }
    }

    return grayscale;
  }

  /**
   * Calculate kurtosis
   */
  private calculateKurtosis(data: Float64Array | number[]): number {
    const mean = data.reduce((a, b) => a + b, 0) / data.length;
    const variance = data.reduce((a, b) => a + (b - mean) ** 2, 0) / data.length;
    const m4 = data.reduce((a, b) => a + (b - mean) ** 4, 0) / data.length;

    return variance > 0 ? m4 / (variance ** 2) : 0;
  }
}

// ============================================================================
// CONFIGURATION
// ============================================================================

export interface WatermarkConfig {
  /** DCT detection threshold */
  dctThreshold: number;
  /** DWT decomposition levels */
  dwtLevels: number;
  /** LSB bit planes to analyze */
  lsbBitPlanes: number;
  /** Spread spectrum correlation threshold */
  spreadSpectrumThreshold: number;
}

// ============================================================================
// CONVENIENCE FUNCTIONS
// ============================================================================

/**
 * Detect watermarks in image
 */
export function detectWatermarks(
  imageData: ImageData,
  config?: Partial<WatermarkConfig>
): WatermarkDetectionResult {
  const detector = new SyntheticWatermarkDetector(config);
  return detector.detect(imageData);
}

/**
 * Check if image has AI watermark
 */
export function hasAIWatermark(imageData: ImageData): boolean {
  const detector = new SyntheticWatermarkDetector();
  const result = detector.detect(imageData);
  return result.watermarkDetected && result.confidence > 0.7;
}

/**
 * Attribute image to AI generator
 */
export function attributeToGenerator(imageData: ImageData): GeneratorAttribution | undefined {
  const detector = new SyntheticWatermarkDetector();
  const result = detector.detect(imageData);
  return result.generatorAttribution;
}

// ============================================================================
// TESTS
// ============================================================================

/**
 * Run synthetic watermark tests
 */
export function runSyntheticWatermarkTests(): {
  passed: boolean;
  summary: { total: number; passed: number; failed: number };
  details: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const tests: Array<{ name: string; passed: boolean; error?: string }> = [];

  // Test 1: Detector instantiation
  try {
    const detector = new SyntheticWatermarkDetector();
    tests.push({ name: 'Detector instantiation', passed: true });
  } catch (error) {
    tests.push({ name: 'Detector instantiation', passed: false, error: String(error) });
  }

  // Test 2: Empty image handling
  try {
    const detector = new SyntheticWatermarkDetector();
    const result = detector.detect({ width: 0, height: 0, data: [] });
    tests.push({
      name: 'Empty image handling',
      passed: !result.watermarkDetected
    });
  } catch (error) {
    tests.push({ name: 'Empty image handling', passed: false, error: String(error) });
  }

  // Test 3: DCT watermark detection
  try {
    const detector = new SyntheticWatermarkDetector();
    const imageData = generateSyntheticImage(100, 100);
    const result = detector.detect(imageData);
    const dctMethod = result.methods.find(m => m.method === 'DCT Domain Analysis');
    tests.push({
      name: 'DCT watermark detection',
      passed: dctMethod !== undefined
    });
  } catch (error) {
    tests.push({ name: 'DCT watermark detection', passed: false, error: String(error) });
  }

  // Test 4: DWT watermark detection
  try {
    const detector = new SyntheticWatermarkDetector();
    const imageData = generateSyntheticImage(100, 100);
    const result = detector.detect(imageData);
    const dwtMethod = result.methods.find(m => m.method === 'DWT Domain Analysis');
    tests.push({
      name: 'DWT watermark detection',
      passed: dwtMethod !== undefined
    });
  } catch (error) {
    tests.push({ name: 'DWT watermark detection', passed: false, error: String(error) });
  }

  // Test 5: LSB detection
  try {
    const detector = new SyntheticWatermarkDetector();
    const imageData = generateSyntheticImage(100, 100);
    const result = detector.detect(imageData);
    const lsbMethod = result.methods.find(m => m.method === 'LSB Embedding Detection');
    tests.push({
      name: 'LSB detection',
      passed: lsbMethod !== undefined
    });
  } catch (error) {
    tests.push({ name: 'LSB detection', passed: false, error: String(error) });
  }

  // Test 6: Spread spectrum detection
  try {
    const detector = new SyntheticWatermarkDetector();
    const imageData = generateSyntheticImage(100, 100);
    const result = detector.detect(imageData);
    const ssMethod = result.methods.find(m => m.method === 'Spread Spectrum Detection');
    tests.push({
      name: 'Spread spectrum detection',
      passed: ssMethod !== undefined
    });
  } catch (error) {
    tests.push({ name: 'Spread spectrum detection', passed: false, error: String(error) });
  }

  // Test 7: Neural fingerprint detection
  try {
    const detector = new SyntheticWatermarkDetector();
    const imageData = generateSyntheticImage(100, 100);
    const result = detector.detect(imageData);
    const nnMethod = result.methods.find(m => m.method === 'Neural Network Fingerprinting');
    tests.push({
      name: 'Neural fingerprint detection',
      passed: nnMethod !== undefined
    });
  } catch (error) {
    tests.push({ name: 'Neural fingerprint detection', passed: false, error: String(error) });
  }

  // Test 8: Generator attribution
  try {
    const detector = new SyntheticWatermarkDetector();
    const imageData = generateSyntheticImage(100, 100);
    const result = detector.detect(imageData);
    tests.push({
      name: 'Generator attribution',
      passed: result.generatorAttribution !== undefined || result.confidence < 0.7
    });
  } catch (error) {
    tests.push({ name: 'Generator attribution', passed: false, error: String(error) });
  }

  // Test 9: Convenience functions
  try {
    const imageData = generateSyntheticImage(50, 50);
    const result = detectWatermarks(imageData);
    const hasWatermark = hasAIWatermark(imageData);
    const attribution = attributeToGenerator(imageData);

    tests.push({
      name: 'Convenience functions',
      passed: result !== undefined && typeof hasWatermark === 'boolean'
    });
  } catch (error) {
    tests.push({ name: 'Convenience functions', passed: false, error: String(error) });
  }

  // Test 10: Recommendations generation
  try {
    const detector = new SyntheticWatermarkDetector();
    const imageData = generateSyntheticImage(100, 100);
    const result = detector.detect(imageData);
    tests.push({
      name: 'Recommendations generation',
      passed: result.recommendations.length > 0
    });
  } catch (error) {
    tests.push({ name: 'Recommendations generation', passed: false, error: String(error) });
  }

  const passed = tests.filter(t => t.passed).length;
  const failed = tests.filter(t => !t.passed).length;

  return {
    passed: failed === 0,
    summary: { total: tests.length, passed, failed },
    details: tests
  };
}

/**
 * Generate synthetic image for testing
 */
function generateSyntheticImage(width: number, height: number): ImageData {
  const data: number[][] = [];

  for (let y = 0; y < height; y++) {
    const row: number[] = [];
    for (let x = 0; x < width; x++) {
      // Create a gradient pattern
      const r = Math.floor((x / width) * 255);
      const g = Math.floor((y / height) * 255);
      const b = Math.floor(((x + y) / (width + height)) * 255);
      row.push(r, g, b);
    }
    data.push(row);
  }

  return { width, height, data };
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

const syntheticWatermarkModule = {
  SyntheticWatermarkDetector,
  detectWatermarks,
  hasAIWatermark,
  attributeToGenerator,
  runSyntheticWatermarkTests,
  GENERATOR_SIGNATURES
};

export default syntheticWatermarkModule;
