/**
 * Swarm Intelligence Module
 * 
 * Distributed detection consensus using swarm algorithms.
 * Emergent intelligence from multiple detection agents.
 * 
 * @module frontier/swarm-intelligence
 * @version 1.0.0
 * 
 * Capabilities:
 * - Particle Swarm Optimization (PSO)
 * - Ant Colony Optimization (ACO)
 * - Bee Algorithm Detection
 * - Consensus Formation
 * - Emergent Pattern Detection
 * - Distributed Truth Discovery
 * - Swarm-based Model Selection
 * - Collective Intelligence Scoring
 */

// ============================================================================
// TYPES
// ============================================================================

/**
 * Swarm agent
 */
export interface SwarmAgent {
  id: string;
  type: 'detector' | 'validator' | 'aggregator' | 'oracle';
  status: 'active' | 'idle' | 'failed' | 'quarantined';
  capabilities: string[];
  reputation: number;
  confidence: number;
  lastActive: number;
  contributions: number;
  accuracy: number;
}

/**
 * Particle for PSO
 */
export interface Particle {
  id: string;
  position: number[];  // Feature space position
  velocity: number[];
  bestPosition: number[];
  bestScore: number;
  currentScore: number;
  fitness: number;
}

/**
 * Swarm state
 */
export interface SwarmState {
  id: string;
  particles: Particle[];
  globalBestPosition: number[];
  globalBestScore: number;
  iteration: number;
  convergenceScore: number;
  diversityScore: number;
}

/**
 * Ant for ACO
 */
export interface Ant {
  id: string;
  path: string[];
  pheromoneDeposited: number;
  solutionQuality: number;
  visitedNodes: Set<string>;
}

/**
 * Pheromone trail
 */
export interface PheromoneTrail {
  from: string;
  to: string;
  strength: number;
  evaporationRate: number;
  lastUpdated: number;
}

/**
 * Consensus proposal
 */
export interface ConsensusProposal {
  id: string;
  proposerId: string;
  result: 'authentic' | 'deepfake' | 'uncertain';
  confidence: number;
  evidence: string[];
  timestamp: number;
  votes: Vote[];
  status: 'pending' | 'approved' | 'rejected' | 'contested';
}

/**
 * Vote for consensus
 */
export interface Vote {
  agentId: string;
  support: boolean;
  weight: number;
  reason?: string;
  timestamp: number;
}

/**
 * Consensus result
 */
export interface ConsensusResult {
  id: string;
  proposalId: string;
  result: 'authentic' | 'deepfake' | 'uncertain';
  confidence: number;
  agreement: number;  // 0-1
  participants: number;
  dissenters: number;
  emergentPatterns: string[];
  trustScore: number;
  timestamp: number;
}

/**
 * Detection agent report
 */
export interface AgentReport {
  agentId: string;
  contentHash: string;
  result: 'authentic' | 'deepfake' | 'uncertain';
  confidence: number;
  features: number[];
  model: string;
  timestamp: number;
  signature: string;
}

/**
 * Truth discovery result
 */
export interface TruthDiscoveryResult {
  contentHash: string;
  truthLabel: 'authentic' | 'deepfake' | 'uncertain';
  truthConfidence: number;
  sourceReliability: Map<string, number>;
  consensusReached: boolean;
  iterations: number;
  emergentTruth: boolean;
}

/**
 * Swarm configuration
 */
export interface SwarmConfig {
  particleCount: number;
  maxIterations: number;
  inertiaWeight: number;
  cognitiveWeight: number;
  socialWeight: number;
  convergenceThreshold: number;
  diversityThreshold: number;
}

// ============================================================================
// STORAGE
// ============================================================================

const agents = new Map<string, SwarmAgent>();
const swarms = new Map<string, SwarmState>();
const proposals = new Map<string, ConsensusProposal>();
const consensusResults = new Map<string, ConsensusResult>();
const pheromoneTrails = new Map<string, PheromoneTrail>();
const agentReports = new Map<string, AgentReport[]>();

// Default configuration
const DEFAULT_CONFIG: SwarmConfig = {
  particleCount: 50,
  maxIterations: 100,
  inertiaWeight: 0.7,
  cognitiveWeight: 1.5,
  socialWeight: 1.5,
  convergenceThreshold: 0.001,
  diversityThreshold: 0.1
};

// ============================================================================
// AGENT MANAGEMENT
// ============================================================================

/**
 * Register a swarm agent
 */
export function registerAgent(
  type: SwarmAgent['type'],
  capabilities: string[]
): SwarmAgent {
  const id = `agent_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  
  const agent: SwarmAgent = {
    id,
    type,
    status: 'idle',
    capabilities,
    reputation: 50,  // Start neutral
    confidence: 0,
    lastActive: Date.now(),
    contributions: 0,
    accuracy: 0.5
  };
  
  agents.set(id, agent);
  
  return agent;
}

/**
 * Get agent by ID
 */
export function getAgent(id: string): SwarmAgent | undefined {
  return agents.get(id);
}

/**
 * List all agents
 */
export function listAgents(type?: SwarmAgent['type']): SwarmAgent[] {
  const all = Array.from(agents.values());
  return type ? all.filter(a => a.type === type) : all;
}

/**
 * Update agent status
 */
export function updateAgentStatus(
  id: string,
  status: SwarmAgent['status']
): boolean {
  const agent = agents.get(id);
  if (!agent) return false;
  
  agent.status = status;
  agent.lastActive = Date.now();
  
  return true;
}

/**
 * Update agent reputation
 */
export function updateAgentReputation(
  id: string,
  delta: number,
  wasCorrect: boolean
): void {
  const agent = agents.get(id);
  if (!agent) return;
  
  // Update reputation with bounds
  agent.reputation = Math.max(0, Math.min(100, agent.reputation + delta));
  
  // Update accuracy tracking
  const totalContributions = agent.contributions + 1;
  if (wasCorrect) {
    agent.accuracy = (agent.accuracy * agent.contributions + 1) / totalContributions;
  } else {
    agent.accuracy = (agent.accuracy * agent.contributions) / totalContributions;
  }
  
  agent.contributions = totalContributions;
}

// ============================================================================
// PARTICLE SWARM OPTIMIZATION
// ============================================================================

/**
 * Initialize PSO swarm
 */
export function initializeSwarm(
  dimensions: number,
  config: Partial<SwarmConfig> = {}
): SwarmState {
  const cfg = { ...DEFAULT_CONFIG, ...config };
  const id = `swarm_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  
  const particles: Particle[] = [];
  
  for (let i = 0; i < cfg.particleCount; i++) {
    const position = Array.from({ length: dimensions }, () => Math.random() * 2 - 1);
    const velocity = Array.from({ length: dimensions }, () => (Math.random() - 0.5) * 0.1);
    
    particles.push({
      id: `particle_${i}`,
      position,
      velocity,
      bestPosition: [...position],
      bestScore: -Infinity,
      currentScore: -Infinity,
      fitness: 0
    });
  }
  
  const swarm: SwarmState = {
    id,
    particles,
    globalBestPosition: Array(dimensions).fill(0),
    globalBestScore: -Infinity,
    iteration: 0,
    convergenceScore: 0,
    diversityScore: 1
  };
  
  swarms.set(id, swarm);
  
  return swarm;
}

/**
 * Evaluate particle fitness (detection quality)
 */
export function evaluateFitness(
  particle: Particle,
  targetFeatures: number[]
): number {
  // Euclidean distance as fitness (closer = better)
  let sumSquares = 0;
  for (let i = 0; i < particle.position.length; i++) {
    const diff = particle.position[i] - targetFeatures[i];
    sumSquares += diff * diff;
  }
  
  // Convert to fitness (1 - normalized distance)
  const distance = Math.sqrt(sumSquares);
  const fitness = 1 / (1 + distance);
  
  particle.currentScore = fitness;
  particle.fitness = fitness;
  
  // Update personal best
  if (fitness > particle.bestScore) {
    particle.bestScore = fitness;
    particle.bestPosition = [...particle.position];
  }
  
  return fitness;
}

/**
 * Update particle velocities and positions
 */
export function updateParticles(
  swarmId: string,
  targetFeatures: number[],
  config: Partial<SwarmConfig> = {}
): SwarmState {
  const swarm = swarms.get(swarmId);
  if (!swarm) throw new Error(`Swarm not found: ${swarmId}`);
  
  const cfg = { ...DEFAULT_CONFIG, ...config };
  
  // Evaluate all particles
  for (const particle of swarm.particles) {
    const fitness = evaluateFitness(particle, targetFeatures);
    
    // Update global best
    if (fitness > swarm.globalBestScore) {
      swarm.globalBestScore = fitness;
      swarm.globalBestPosition = [...particle.position];
    }
  }
  
  // Update velocities and positions
  for (const particle of swarm.particles) {
    const r1 = Math.random();
    const r2 = Math.random();
    
    for (let i = 0; i < particle.position.length; i++) {
      // Update velocity
      const cognitive = cfg.cognitiveWeight * r1 * (particle.bestPosition[i] - particle.position[i]);
      const social = cfg.socialWeight * r2 * (swarm.globalBestPosition[i] - particle.position[i]);
      
      particle.velocity[i] = 
        cfg.inertiaWeight * particle.velocity[i] + cognitive + social;
      
      // Clamp velocity
      particle.velocity[i] = Math.max(-2, Math.min(2, particle.velocity[i]));
      
      // Update position
      particle.position[i] += particle.velocity[i];
      
      // Clamp position to [-1, 1]
      particle.position[i] = Math.max(-1, Math.min(1, particle.position[i]));
    }
  }
  
  // Calculate convergence and diversity
  swarm.convergenceScore = calculateConvergence(swarm);
  swarm.diversityScore = calculateDiversity(swarm);
  swarm.iteration++;
  
  return swarm;
}

/**
 * Calculate convergence score
 */
function calculateConvergence(swarm: SwarmState): number {
  // Standard deviation of positions
  const avgPosition = swarm.globalBestPosition.map((_, i) => {
    return swarm.particles.reduce((sum, p) => sum + p.position[i], 0) / swarm.particles.length;
  });
  
  let variance = 0;
  for (const particle of swarm.particles) {
    for (let i = 0; i < particle.position.length; i++) {
      variance += Math.pow(particle.position[i] - avgPosition[i], 2);
    }
  }
  
  return 1 - Math.sqrt(variance / swarm.particles.length);
}

/**
 * Calculate diversity score
 */
function calculateDiversity(swarm: SwarmState): number {
  // Average pairwise distance
  let totalDistance = 0;
  let pairs = 0;
  
  for (let i = 0; i < swarm.particles.length; i++) {
    for (let j = i + 1; j < swarm.particles.length; j++) {
      let dist = 0;
      for (let k = 0; k < swarm.particles[i].position.length; k++) {
        dist += Math.pow(swarm.particles[i].position[k] - swarm.particles[j].position[k], 2);
      }
      totalDistance += Math.sqrt(dist);
      pairs++;
    }
  }
  
  return pairs > 0 ? totalDistance / pairs : 0;
}

/**
 * Run PSO optimization
 */
export function runPSOOptimization(
  targetFeatures: number[],
  config: Partial<SwarmConfig> = {}
): SwarmState {
  const cfg = { ...DEFAULT_CONFIG, ...config };
  const swarm = initializeSwarm(targetFeatures.length, cfg);
  
  for (let i = 0; i < cfg.maxIterations; i++) {
    updateParticles(swarm.id, targetFeatures, cfg);
    
    // Check convergence
    if (swarm.convergenceScore > 0.99) {
      break;
    }
  }
  
  return swarm;
}

// ============================================================================
// ANT COLONY OPTIMIZATION
// ============================================================================

/**
 * Initialize ACO
 */
export function initializeACO(
  nodes: string[]
): Map<string, PheromoneTrail> {
  const trails = new Map<string, PheromoneTrail>();
  
  // Create trails between all node pairs
  for (let i = 0; i < nodes.length; i++) {
    for (let j = 0; j < nodes.length; j++) {
      if (i !== j) {
        const key = `${nodes[i]}_${nodes[j]}`;
        trails.set(key, {
          from: nodes[i],
          to: nodes[j],
          strength: 0.1,  // Initial pheromone
          evaporationRate: 0.1,
          lastUpdated: Date.now()
        });
      }
    }
  }
  
  return trails;
}

/**
 * Create ant
 */
function createAnt(id: string, startNode: string): Ant {
  return {
    id,
    path: [startNode],
    pheromoneDeposited: 0,
    solutionQuality: 0,
    visitedNodes: new Set([startNode])
  };
}

/**
 * Select next node for ant
 */
function selectNextNode(
  ant: Ant,
  trails: Map<string, PheromoneTrail>,
  nodes: string[],
  alpha: number = 1,  // Pheromone influence
  beta: number = 2    // Heuristic influence
): string | null {
  const currentNode = ant.path[ant.path.length - 1];
  const unvisited = nodes.filter(n => !ant.visitedNodes.has(n));
  
  if (unvisited.length === 0) return null;
  
  // Calculate probabilities
  const probabilities: { node: string; prob: number }[] = [];
  let totalProb = 0;
  
  for (const node of unvisited) {
    const key = `${currentNode}_${node}`;
    const trail = trails.get(key);
    const pheromone = trail?.strength || 0.1;
    
    // Heuristic (inverse distance - simplified)
    const heuristic = 1;
    
    const prob = Math.pow(pheromone, alpha) * Math.pow(heuristic, beta);
    probabilities.push({ node, prob });
    totalProb += prob;
  }
  
  // Roulette wheel selection
  const rand = Math.random() * totalProb;
  let cumulative = 0;
  
  for (const { node, prob } of probabilities) {
    cumulative += prob;
    if (rand <= cumulative) {
      return node;
    }
  }
  
  return unvisited[0];
}

/**
 * Evaporate pheromones
 */
function evaporatePheromones(
  trails: Map<string, PheromoneTrail>
): void {
  for (const [, trail] of trails) {
    trail.strength *= (1 - trail.evaporationRate);
    trail.lastUpdated = Date.now();
  }
}

/**
 * Deposit pheromone
 */
function depositPheromone(
  ant: Ant,
  trails: Map<string, PheromoneTrail>
): void {
  const deposit = ant.solutionQuality;
  
  for (let i = 0; i < ant.path.length - 1; i++) {
    const key = `${ant.path[i]}_${ant.path[i + 1]}`;
    const trail = trails.get(key);
    if (trail) {
      trail.strength += deposit;
      trail.lastUpdated = Date.now();
    }
  }
}

/**
 * Run ACO for detection path
 */
export function runACODetection(
  detectionNodes: string[],
  antCount: number = 20,
  iterations: number = 50
): { bestPath: string[]; bestScore: number } {
  const trails = initializeACO(detectionNodes);
  let bestPath: string[] = [];
  let bestScore = 0;
  
  for (let iter = 0; iter < iterations; iter++) {
    const ants: Ant[] = [];
    
    // Create ants
    for (let i = 0; i < antCount; i++) {
      const startNode = detectionNodes[Math.floor(Math.random() * detectionNodes.length)];
      ants.push(createAnt(`ant_${iter}_${i}`, startNode));
    }
    
    // Move ants
    for (const ant of ants) {
      while (true) {
        const nextNode = selectNextNode(ant, trails, detectionNodes);
        if (!nextNode) break;
        
        ant.path.push(nextNode);
        ant.visitedNodes.add(nextNode);
      }
      
      // Evaluate solution
      ant.solutionQuality = Math.random();  // Would be actual detection quality
      ant.pheromoneDeposited = ant.solutionQuality;
      
      // Track best
      if (ant.solutionQuality > bestScore) {
        bestScore = ant.solutionQuality;
        bestPath = [...ant.path];
      }
    }
    
    // Update pheromones
    evaporatePheromones(trails);
    for (const ant of ants) {
      depositPheromone(ant, trails);
    }
  }
  
  return { bestPath, bestScore };
}

// ============================================================================
// CONSENSUS FORMATION
// ============================================================================

/**
 * Submit detection report
 */
export function submitReport(report: AgentReport): void {
  const existing = agentReports.get(report.contentHash) || [];
  existing.push(report);
  agentReports.set(report.contentHash, existing);
}

/**
 * Create consensus proposal
 */
export function createProposal(
  proposerId: string,
  result: 'authentic' | 'deepfake' | 'uncertain',
  confidence: number,
  evidence: string[]
): ConsensusProposal {
  const id = `prop_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  
  const proposal: ConsensusProposal = {
    id,
    proposerId,
    result,
    confidence,
    evidence,
    timestamp: Date.now(),
    votes: [],
    status: 'pending'
  };
  
  proposals.set(id, proposal);
  
  return proposal;
}

/**
 * Vote on proposal
 */
export function voteOnProposal(
  proposalId: string,
  agentId: string,
  support: boolean,
  reason?: string
): boolean {
  const proposal = proposals.get(proposalId);
  if (!proposal) return false;
  
  const agent = agents.get(agentId);
  if (!agent) return false;
  
  const vote: Vote = {
    agentId,
    support,
    weight: agent.reputation / 100,  // Weight by reputation
    reason,
    timestamp: Date.now()
  };
  
  proposal.votes.push(vote);
  
  // Update agent activity
  agent.lastActive = Date.now();
  
  return true;
}

/**
 * Form consensus from votes
 */
export function formConsensus(proposalId: string): ConsensusResult | null {
  const proposal = proposals.get(proposalId);
  if (!proposal) return null;
  
  // Calculate weighted votes
  let supportWeight = 0;
  let opposeWeight = 0;
  let totalWeight = 0;
  
  for (const vote of proposal.votes) {
    totalWeight += vote.weight;
    if (vote.support) {
      supportWeight += vote.weight;
    } else {
      opposeWeight += vote.weight;
    }
  }
  
  // Need minimum participation
  const activeAgents = Array.from(agents.values()).filter(a => a.status === 'active');
  if (proposal.votes.length < activeAgents.length * 0.3) {
    return null;  // Insufficient participation
  }
  
  const agreement = totalWeight > 0 ? supportWeight / totalWeight : 0;
  const participants = proposal.votes.length;
  const dissenters = proposal.votes.filter(v => !v.support).length;
  
  // Determine result
  let finalResult = proposal.result;
  let finalConfidence = proposal.confidence;
  
  if (agreement >= 0.67) {
    proposal.status = 'approved';
    finalConfidence *= (1 + agreement * 0.2);  // Boost confidence with agreement
  } else if (agreement < 0.33) {
    proposal.status = 'rejected';
    finalResult = 'uncertain';
    finalConfidence = 0.5;
  } else {
    proposal.status = 'contested';
    finalConfidence *= 0.8;  // Reduce confidence for contested
  }
  
  // Identify emergent patterns
  const emergentPatterns = identifyEmergentPatterns(proposal);
  
  // Calculate trust score
  const trustScore = calculateTrustScore(proposal, agreement);
  
  const result: ConsensusResult = {
    id: `consensus_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    proposalId,
    result: finalResult,
    confidence: Math.min(1, finalConfidence),
    agreement,
    participants,
    dissenters,
    emergentPatterns,
    trustScore,
    timestamp: Date.now()
  };
  
  consensusResults.set(result.id, result);
  
  // Update agent reputations
  for (const vote of proposal.votes) {
    const wasCorrect = vote.support === (agreement >= 0.5);
    updateAgentReputation(vote.agentId, wasCorrect ? 2 : -1, wasCorrect);
  }
  
  return result;
}

/**
 * Identify emergent patterns from proposal
 */
function identifyEmergentPatterns(proposal: ConsensusProposal): string[] {
  const patterns: string[] = [];
  
  // Check vote clustering
  const supportingAgents = proposal.votes
    .filter(v => v.support)
    .map(v => agents.get(v.agentId))
    .filter((a): a is SwarmAgent => a !== undefined);
  
  // Capability convergence
  const capabilities = new Map<string, number>();
  for (const agent of supportingAgents) {
    for (const cap of agent.capabilities) {
      capabilities.set(cap, (capabilities.get(cap) || 0) + 1);
    }
  }
  
  for (const [cap, count] of capabilities) {
    if (count >= supportingAgents.length * 0.7) {
      patterns.push(`capability_convergence:${cap}`);
    }
  }
  
  // Reputation convergence
  const avgReputation = supportingAgents.reduce((sum, a) => sum + a.reputation, 0) / supportingAgents.length;
  if (avgReputation > 70) {
    patterns.push('high_reputation_consensus');
  }
  
  return patterns;
}

/**
 * Calculate trust score for consensus
 */
function calculateTrustScore(proposal: ConsensusProposal, agreement: number): number {
  let score = 0;
  
  // Agreement factor
  score += agreement * 0.3;
  
  // Participation factor
  const participationRate = proposal.votes.length / agents.size;
  score += participationRate * 0.2;
  
  // Reputation factor
  const avgReputation = proposal.votes.reduce((sum, v) => {
    const agent = agents.get(v.agentId);
    return sum + (agent?.reputation || 50);
  }, 0) / proposal.votes.length;
  score += (avgReputation / 100) * 0.3;
  
  // Evidence factor
  score += Math.min(proposal.evidence.length / 5, 1) * 0.2;
  
  return Math.min(1, score);
}

// ============================================================================
// TRUTH DISCOVERY
// ============================================================================

/**
 * Discover truth from multiple agent reports
 */
export function discoverTruth(
  contentHash: string,
  maxIterations: number = 20
): TruthDiscoveryResult {
  const reports = agentReports.get(contentHash) || [];
  
  if (reports.length === 0) {
    return {
      contentHash,
      truthLabel: 'uncertain',
      truthConfidence: 0,
      sourceReliability: new Map(),
      consensusReached: false,
      iterations: 0,
      emergentTruth: false
    };
  }
  
  // Initialize source reliability
  const sourceReliability = new Map<string, number>();
  for (const report of reports) {
    sourceReliability.set(report.agentId, 0.5);  // Start neutral
  }
  
  // Iterate truth discovery
  for (let iter = 0; iter < maxIterations; iter++) {
    // Calculate claim confidence
    const claimScores = new Map<string, number>();
    
    for (const report of reports) {
      const reliability = sourceReliability.get(report.agentId) || 0.5;
      const key = `${report.result}_${Math.round(report.confidence * 10)}`;
      claimScores.set(key, (claimScores.get(key) || 0) + reliability);
    }
    
    // Find most confident claim
    let maxScore = 0;
    let bestClaim = '';
    for (const [claim, score] of claimScores) {
      if (score > maxScore) {
        maxScore = score;
        bestClaim = claim;
      }
    }
    
    // Update source reliability
    for (const report of reports) {
      const claimKey = `${report.result}_${Math.round(report.confidence * 10)}`;
      const isConsistent = claimKey === bestClaim;
      
      const current = sourceReliability.get(report.agentId) || 0.5;
      const update = isConsistent ? 0.1 : -0.05;
      sourceReliability.set(report.agentId, Math.max(0, Math.min(1, current + update)));
    }
  }
  
  // Determine final truth
  const weightedResults = new Map<string, number>();
  let totalWeight = 0;
  
  for (const report of reports) {
    const reliability = sourceReliability.get(report.agentId) || 0.5;
    const key = report.result;
    weightedResults.set(key, (weightedResults.get(key) || 0) + reliability * report.confidence);
    totalWeight += reliability;
  }
  
  let maxWeight = 0;
  let truthLabel: 'authentic' | 'deepfake' | 'uncertain' = 'uncertain';
  
  for (const [result, weight] of weightedResults) {
    if (weight > maxWeight) {
      maxWeight = weight;
      truthLabel = result as 'authentic' | 'deepfake' | 'uncertain';
    }
  }
  
  const truthConfidence = totalWeight > 0 ? maxWeight / totalWeight : 0;
  
  // Check if emergent (different from simple majority)
  const simpleMajority = getSimpleMajority(reports);
  const emergentTruth = simpleMajority !== truthLabel;
  
  return {
    contentHash,
    truthLabel,
    truthConfidence,
    sourceReliability,
    consensusReached: truthConfidence > 0.7,
    iterations: maxIterations,
    emergentTruth
  };
}

/**
 * Get simple majority vote
 */
function getSimpleMajority(reports: AgentReport[]): string {
  const counts = new Map<string, number>();
  for (const report of reports) {
    counts.set(report.result, (counts.get(report.result) || 0) + 1);
  }
  
  let max = 0;
  let majority = 'uncertain';
  for (const [result, count] of counts) {
    if (count > max) {
      max = count;
      majority = result;
    }
  }
  
  return majority;
}

// ============================================================================
// SWARM DETECTION
// ============================================================================

/**
 * Perform swarm-based detection
 */
export function swarmDetection(
  contentHash: string,
  features: number[]
): {
  psoResult: SwarmState;
  consensusResult: ConsensusResult | null;
  truthResult: TruthDiscoveryResult;
  swarmScore: number;
} {
  // Run PSO for feature optimization
  const psoResult = runPSOOptimization(features);
  
  // Get agent reports
  const reports = agentReports.get(contentHash) || [];
  
  // Create proposal if we have reports
  let consensusResult: ConsensusResult | null = null;
  
  if (reports.length > 0) {
    // Aggregate reports into proposal
    const avgConfidence = reports.reduce((sum, r) => sum + r.confidence, 0) / reports.length;
    const majorityResult = getSimpleMajority(reports) as 'authentic' | 'deepfake' | 'uncertain';
    
    const proposal = createProposal(
      'swarm_aggregator',
      majorityResult,
      avgConfidence,
      features.map((f, i) => `feature_${i}=${f.toFixed(3)}`)
    );
    
    // Have agents vote
    for (const report of reports) {
      const agent = agents.get(report.agentId);
      if (agent) {
        const support = report.result === majorityResult;
        voteOnProposal(proposal.id, agent.id, support, `Agent confidence: ${report.confidence}`);
      }
    }
    
    consensusResult = formConsensus(proposal.id);
  }
  
  // Discover truth
  const truthResult = discoverTruth(contentHash);
  
  // Calculate swarm score
  const swarmScore = calculateSwarmScore(psoResult, consensusResult, truthResult);
  
  return {
    psoResult,
    consensusResult,
    truthResult,
    swarmScore
  };
}

/**
 * Calculate overall swarm score
 */
function calculateSwarmScore(
  psoResult: SwarmState,
  consensusResult: ConsensusResult | null,
  truthResult: TruthDiscoveryResult
): number {
  let score = 0;
  
  // PSO convergence
  score += psoResult.globalBestScore * 0.3;
  
  // Consensus strength
  if (consensusResult) {
    score += consensusResult.agreement * consensusResult.trustScore * 0.3;
  }
  
  // Truth confidence
  score += truthResult.truthConfidence * 0.4;
  
  return Math.min(1, score);
}

// ============================================================================
// STATUS
// ============================================================================

/**
 * Get swarm status
 */
export function getSwarmStatus(): {
  totalAgents: number;
  activeAgents: number;
  swarmsCreated: number;
  proposalsCreated: number;
  consensusReached: number;
  averageReputation: number;
  diversityScore: number;
} {
  const agentList = Array.from(agents.values());
  const activeAgents = agentList.filter(a => a.status === 'active');
  
  return {
    totalAgents: agents.size,
    activeAgents: activeAgents.length,
    swarmsCreated: swarms.size,
    proposalsCreated: proposals.size,
    consensusReached: Array.from(consensusResults.values()).filter(c => c.agreement > 0.67).length,
    averageReputation: agentList.reduce((sum, a) => sum + a.reputation, 0) / agentList.length || 50,
    diversityScore: swarms.size > 0 
      ? Array.from(swarms.values()).reduce((sum, s) => sum + s.diversityScore, 0) / swarms.size 
      : 0
  };
}

// ============================================================================
// TESTS
// ============================================================================

/**
 * Run swarm intelligence tests
 */
export function runSwarmTests(): {
  passed: boolean;
  tests: { total: number; passed: number; failed: number };
  results: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const results: Array<{ name: string; passed: boolean; error?: string }> = [];
  
  // Test 1: Agent registration
  try {
    const agent = registerAgent('detector', ['image', 'video']);
    if (!agent.id || agent.reputation !== 50) {
      throw new Error('Agent registration failed');
    }
    results.push({ name: 'Agent Registration', passed: true });
  } catch (e) {
    results.push({ name: 'Agent Registration', passed: false, error: String(e) });
  }
  
  // Test 2: PSO initialization
  try {
    const swarm = initializeSwarm(10);
    if (swarm.particles.length !== 50) {
      throw new Error('PSO initialization failed');
    }
    results.push({ name: 'PSO Initialization', passed: true });
  } catch (e) {
    results.push({ name: 'PSO Initialization', passed: false, error: String(e) });
  }
  
  // Test 3: PSO optimization
  try {
    const target = [0.5, 0.3, 0.8];
    const swarm = runPSOOptimization(target, { maxIterations: 20 });
    if (swarm.globalBestScore < 0.5) {
      throw new Error('PSO optimization failed');
    }
    results.push({ name: 'PSO Optimization', passed: true });
  } catch (e) {
    results.push({ name: 'PSO Optimization', passed: false, error: String(e) });
  }
  
  // Test 4: ACO detection
  try {
    const nodes = ['detector_1', 'detector_2', 'detector_3'];
    const result = runACODetection(nodes, 5, 10);
    if (result.bestPath.length === 0) {
      throw new Error('ACO failed');
    }
    results.push({ name: 'ACO Detection', passed: true });
  } catch (e) {
    results.push({ name: 'ACO Detection', passed: false, error: String(e) });
  }
  
  // Test 5: Consensus formation
  try {
    const agent1 = registerAgent('validator', ['image']);
    const agent2 = registerAgent('validator', ['video']);
    
    updateAgentStatus(agent1.id, 'active');
    updateAgentStatus(agent2.id, 'active');
    
    const proposal = createProposal(agent1.id, 'deepfake', 0.9, ['evidence1']);
    voteOnProposal(proposal.id, agent1.id, true);
    voteOnProposal(proposal.id, agent2.id, true);
    
    const consensus = formConsensus(proposal.id);
    if (!consensus || consensus.agreement < 0.5) {
      throw new Error('Consensus formation failed');
    }
    results.push({ name: 'Consensus Formation', passed: true });
  } catch (e) {
    results.push({ name: 'Consensus Formation', passed: false, error: String(e) });
  }
  
  // Test 6: Truth discovery
  try {
    const agent1 = registerAgent('detector', ['image']);
    const agent2 = registerAgent('detector', ['image']);
    
    const hash = 'test_content_' + Date.now();
    submitReport({
      agentId: agent1.id,
      contentHash: hash,
      result: 'deepfake',
      confidence: 0.9,
      features: [0.5, 0.5],
      model: 'v1',
      timestamp: Date.now(),
      signature: 'sig'
    });
    submitReport({
      agentId: agent2.id,
      contentHash: hash,
      result: 'deepfake',
      confidence: 0.85,
      features: [0.5, 0.5],
      model: 'v1',
      timestamp: Date.now(),
      signature: 'sig'
    });
    
    const truth = discoverTruth(hash);
    if (truth.truthLabel !== 'deepfake') {
      throw new Error('Truth discovery failed');
    }
    results.push({ name: 'Truth Discovery', passed: true });
  } catch (e) {
    results.push({ name: 'Truth Discovery', passed: false, error: String(e) });
  }
  
  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;
  
  return {
    passed: failed === 0,
    tests: { total: results.length, passed, failed },
    results
  };
}

// Default export
const swarmIntelligenceModule = {
  // Agent management
  registerAgent,
  getAgent,
  listAgents,
  updateAgentStatus,
  updateAgentReputation,
  
  // PSO
  initializeSwarm,
  evaluateFitness,
  updateParticles,
  runPSOOptimization,
  
  // ACO
  initializeACO,
  runACODetection,
  
  // Consensus
  submitReport,
  createProposal,
  voteOnProposal,
  formConsensus,
  
  // Truth discovery
  discoverTruth,
  
  // Swarm detection
  swarmDetection,
  
  // Status
  getSwarmStatus,
  
  // Tests
  runSwarmTests
};

export default swarmIntelligenceModule;
