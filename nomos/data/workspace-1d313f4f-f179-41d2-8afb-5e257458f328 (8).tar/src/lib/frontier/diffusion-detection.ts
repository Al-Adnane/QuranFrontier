/**
 * Kasbah Diffusion Model Detection Engine
 * Detect DALL-E, Midjourney, Stable Diffusion generated images
 * Real artifact detection, frequency analysis, and model fingerprinting
 * 
 * @module diffusion-detection
 * @version 1.0.0
 * @disruption-score +3.5/10
 * 
 * Capabilities:
 * - DALL-E 2/3 Detection
 * - Midjourney Detection
 * - Stable Diffusion Detection
 * - Diffusion Artifact Detection
 * - Latent Space Analysis
 * - Denoising Pattern Detection
 */

// ============================================
// TYPE DEFINITIONS
// ============================================

export interface DiffusionFingerprint {
  id: string;
  isDiffusionGenerated: boolean;
  generator: DiffusionGenerator;
  confidence: number;
  artifacts: DiffusionArtifact[];
  features: DiffusionFeatures;
  modelSignature: ModelSignature;
}

export type DiffusionGenerator = 
  | 'DALL-E-2'
  | 'DALL-E-3'
  | 'Midjourney'
  | 'Stable-Diffusion-1.4'
  | 'Stable-Diffusion-1.5'
  | 'Stable-Diffusion-2.0'
  | 'Stable-Diffusion-XL'
  | 'Imagen'
  | 'Firefly'
  | 'Leonardo'
  | 'Unknown';

export interface DiffusionArtifact {
  type: string;
  severity: 'low' | 'medium' | 'high';
  evidence: string;
  confidence: number;
}

export interface DiffusionFeatures {
  // Denoising artifacts
  denoisingScore: number;
  iterativeRefinementScore: number;
  noisePatternScore: number;
  
  // Frequency domain
  spectralSmoothness: number;
  highFrequencyLoss: number;
  frequencyBanding: number;
  
  // Spatial patterns
  textureCoherence: number;
  edgeConsistency: number;
  colorGradientSmoothness: number;
  
  // Model-specific
  promptAdherenceScore: number;
  compositionBalance: number;
  styleConsistency: number;
  
  // Latent artifacts
  latentSpaceArtifacts: number;
  vaeDecompressionScore: number;
}

export interface ModelSignature {
  generator: DiffusionGenerator;
  signatureStrength: number;
  matchedFeatures: string[];
  versionGuess: string;
}

// ============================================
// DENOISING PATTERN ANALYZER
// ============================================

class DenoisingAnalyzer {
  /**
   * Detect iterative denoising patterns
   * Diffusion models leave traces of the denoising process
   */
  analyze(imageData: number[][], width: number, height: number): {
    denoisingScore: number;
    noisePatternScore: number;
    iterativeScore: number;
  } {
    // Extract noise residual
    const noiseResidual = this.extractNoiseResidual(imageData, width, height);
    
    // Analyze noise patterns
    const noisePatternScore = this.analyzeNoisePattern(noiseResidual);
    
    // Check for iterative refinement traces
    const iterativeScore = this.detectIterativeTraces(imageData, width, height);
    
    // Combined denoising score
    const denoisingScore = (noisePatternScore + iterativeScore) / 2;
    
    return { denoisingScore, noisePatternScore, iterativeScore };
  }

  private extractNoiseResidual(
    image: number[][],
    width: number,
    height: number
  ): number[][] {
    // High-pass filter to extract high-freq noise
    const residual: number[][] = [];
    
    for (let y = 1; y < height - 1; y++) {
      residual[y] = [];
      for (let x = 1; x < width - 1; x++) {
        // Laplacian
        const laplacian = 
          -image[y - 1][x] - image[y + 1][x] -
          image[y][x - 1] - image[y][x + 1] +
          4 * image[y][x];
        
        residual[y][x] = laplacian;
      }
    }
    
    return residual;
  }

  private analyzeNoisePattern(residual: number[][]): number {
    // Flatten residual
    const flat: number[] = [];
    for (const row of residual) {
      if (row) {
        flat.push(...row);
      }
    }
    
    if (flat.length === 0) return 0;
    
    // Compute histogram
    const histogram = new Map<number, number>();
    for (const v of flat) {
      const bin = Math.floor(v / 10);
      histogram.set(bin, (histogram.get(bin) || 0) + 1);
    }
    
    // Diffusion models have characteristic noise distributions
    // More uniform than natural images
    const values = Array.from(histogram.values()).sort((a, b) => b - a);
    const total = values.reduce((a, b) => a + b, 0);
    
    // Check if noise is too uniform
    const topBins = values.slice(0, 5);
    const topRatio = topBins.reduce((a, b) => a + b, 0) / total;
    
    // Very uniform noise = diffusion
    return topRatio < 0.3 ? 0.8 : topRatio < 0.5 ? 0.5 : 0.2;
  }

  private detectIterativeTraces(
    image: number[][],
    width: number,
    height: number
  ): number {
    // Look for consistent patterns at different scales
    // Diffusion models often have consistent micro-patterns
    
    const scales = [4, 8, 16, 32];
    const consistencyScores: number[] = [];
    
    for (const scale of scales) {
      const blocks = this.extractBlocks(image, width, height, scale);
      const variance = this.computeBlockVariance(blocks);
      consistencyScores.push(1 / (1 + variance));
    }
    
    // High consistency across scales = iterative refinement
    const avgConsistency = consistencyScores.reduce((a, b) => a + b, 0) / consistencyScores.length;
    
    return avgConsistency > 0.7 ? 0.8 : avgConsistency;
  }

  private extractBlocks(
    image: number[][],
    width: number,
    height: number,
    blockSize: number
  ): number[][][] {
    const blocks: number[][][] = [];
    
    for (let y = 0; y < height - blockSize; y += blockSize) {
      for (let x = 0; x < width - blockSize; x += blockSize) {
        const block: number[][] = [];
        
        for (let dy = 0; dy < blockSize; dy++) {
          block[dy] = [];
          for (let dx = 0; dx < blockSize; dx++) {
            block[dy][dx] = image[y + dy][x + dx];
          }
        }
        
        blocks.push(block);
      }
    }
    
    return blocks;
  }

  private computeBlockVariance(blocks: number[][][]): number {
    const means: number[] = [];
    
    for (const block of blocks) {
      let sum = 0;
      let count = 0;
      
      for (const row of block) {
        for (const v of row) {
          sum += v;
          count++;
        }
      }
      
      means.push(sum / count);
    }
    
    const overallMean = means.reduce((a, b) => a + b, 0) / means.length;
    return means.reduce((sum, m) => sum + Math.pow(m - overallMean, 2), 0) / means.length;
  }
}

// ============================================
// VAE ARTIFACT DETECTOR
// ============================================

class VAEArtifactDetector {
  /**
   * Detect VAE compression/decompression artifacts
   * Stable Diffusion and similar models use VAE
   */
  detect(
    imageData: number[][],
    width: number,
    height: number
  ): { vaeScore: number; latentArtifacts: number } {
    // Detect 8x8 blocking artifacts (VAE latent space is typically 8x downsampled)
    const blockingScore = this.detectBlockingArtifacts(imageData, width, height, 8);
    
    // Detect color bleeding at boundaries
    const colorBleedingScore = this.detectColorBleeding(imageData, width, height);
    
    // Detect compression artifacts
    const compressionScore = this.detectCompressionArtifacts(imageData, width, height);
    
    // Combined VAE score
    const vaeScore = (blockingScore + colorBleedingScore + compressionScore) / 3;
    
    // Latent space artifacts
    const latentArtifacts = this.detectLatentPatterns(imageData, width, height);
    
    return { vaeScore, latentArtifacts };
  }

  private detectBlockingArtifacts(
    image: number[][],
    width: number,
    height: number,
    blockSize: number
  ): number {
    // Check for regular patterns at block boundaries
    let boundaryScore = 0;
    let count = 0;
    
    for (let y = blockSize; y < height - blockSize; y += blockSize) {
      for (let x = 0; x < width - 1; x++) {
        const diff = Math.abs(image[y - 1][x] - image[y][x]);
        boundaryScore += diff;
        count++;
      }
    }
    
    // Also check vertical boundaries
    for (let x = blockSize; x < width - blockSize; x += blockSize) {
      for (let y = 0; y < height - 1; y++) {
        const diff = Math.abs(image[y][x - 1] - image[y][x]);
        boundaryScore += diff;
        count++;
      }
    }
    
    const avgBoundary = count > 0 ? boundaryScore / count : 0;
    
    // Normalize - higher boundary differences might indicate blocking
    return Math.min(1, avgBoundary / 30);
  }

  private detectColorBleeding(
    image: number[][],
    width: number,
    height: number
  ): number {
    // VAE often causes color bleeding at edges
    // Check for colors "leaking" across edges
    
    let bleedingScore = 0;
    let count = 0;
    
    for (let y = 2; y < height - 2; y++) {
      for (let x = 2; x < width - 2; x++) {
        // Check if this is an edge
        const gx = Math.abs(image[y][x + 1] - image[y][x - 1]);
        const gy = Math.abs(image[y + 1][x] - image[y - 1][x]);
        const edgeStrength = Math.sqrt(gx * gx + gy * gy);
        
        if (edgeStrength > 50) {
          // This is an edge - check for color anomalies
          const localVariance = this.localVariance(image, x, y, 3);
          
          // High variance at edges suggests color bleeding
          if (localVariance > 500) {
            bleedingScore++;
          }
          count++;
        }
      }
    }
    
    return count > 0 ? bleedingScore / count : 0;
  }

  private localVariance(
    image: number[][],
    cx: number,
    cy: number,
    radius: number
  ): number {
    const values: number[] = [];
    
    for (let dy = -radius; dy <= radius; dy++) {
      for (let dx = -radius; dx <= radius; dx++) {
        if (cy + dy >= 0 && cy + dy < image.length && cx + dx >= 0) {
          values.push(image[cy + dy][cx + dx]);
        }
      }
    }
    
    if (values.length === 0) return 0;
    
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    return values.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / values.length;
  }

  private detectCompressionArtifacts(
    image: number[][],
    width: number,
    height: number
  ): number {
    // Look for ringing artifacts around edges
    let ringingScore = 0;
    let edgeCount = 0;
    
    for (let y = 5; y < height - 5; y++) {
      for (let x = 5; x < width - 5; x++) {
        // Detect edge
        const grad = Math.abs(image[y][x + 1] - image[y][x - 1]) +
                    Math.abs(image[y + 1][x] - image[y - 1][x]);
        
        if (grad > 80) {
          // Check for oscillation around edge
          let oscillation = 0;
          for (let i = -4; i <= 4; i++) {
            if (i !== 0) {
              oscillation += Math.abs(image[y + i][x + i] - image[y][x]) * (1 - Math.abs(i) / 5);
            }
          }
          
          if (oscillation > 100) {
            ringingScore++;
          }
          edgeCount++;
        }
      }
    }
    
    return edgeCount > 0 ? Math.min(1, ringingScore / edgeCount * 2) : 0;
  }

  private detectLatentPatterns(
    image: number[][],
    width: number,
    height: number
  ): number {
    // Detect patterns in latent space (upsampled patterns)
    // Look for 64x64 grid patterns (typical latent size upsampled)
    
    const gridSize = 64;
    const gridScore = this.detectGridPattern(image, width, height, gridSize);
    
    return gridScore;
  }

  private detectGridPattern(
    image: number[][],
    width: number,
    height: number,
    gridSize: number
  ): number {
    let patternScore = 0;
    let count = 0;
    
    // Check for repeating patterns at grid intervals
    for (let y = 0; y < height - gridSize * 2; y += gridSize) {
      for (let x = 0; x < width - gridSize * 2; x += gridSize) {
        // Compare block with neighboring blocks
        const block1 = this.getBlockMean(image, x, y, gridSize);
        const block2 = this.getBlockMean(image, x + gridSize, y, gridSize);
        const block3 = this.getBlockMean(image, x, y + gridSize, gridSize);
        
        // High similarity suggests latent pattern
        const similarity = this.blockSimilarity(block1, block2) + 
                         this.blockSimilarity(block1, block3);
        
        if (similarity > 1.5) {
          patternScore++;
        }
        count++;
      }
    }
    
    return count > 0 ? patternScore / count : 0;
  }

  private getBlockMean(
    image: number[][],
    x: number,
    y: number,
    size: number
  ): number {
    let sum = 0;
    let count = 0;
    
    for (let dy = 0; dy < size; dy++) {
      for (let dx = 0; dx < size; dx++) {
        if (y + dy < image.length && x + dx < image[0].length) {
          sum += image[y + dy][x + dx];
          count++;
        }
      }
    }
    
    return count > 0 ? sum / count : 0;
  }

  private blockSimilarity(mean1: number, mean2: number): number {
    return 1 - Math.abs(mean1 - mean2) / 255;
  }
}

// ============================================
// MODEL-SPECIFIC SIGNATURES
// ============================================

class ModelSignatureDetector {
  /**
   * Detect signatures of specific diffusion models
   */
  detect(
    features: DiffusionFeatures,
    imageData: number[][],
    width: number,
    height: number
  ): ModelSignature {
    const signatures: Array<{
      generator: DiffusionGenerator;
      strength: number;
      features: string[];
    }> = [];
    
    // DALL-E 2
    signatures.push(this.detectDALLE2(features, imageData, width, height));
    
    // DALL-E 3
    signatures.push(this.detectDALLE3(features, imageData, width, height));
    
    // Midjourney
    signatures.push(this.detectMidjourney(features, imageData, width, height));
    
    // Stable Diffusion
    signatures.push(this.detectStableDiffusion(features, imageData, width, height));
    
    // Find best match
    signatures.sort((a, b) => b.strength - a.strength);
    const best = signatures[0];
    
    return {
      generator: best.generator,
      signatureStrength: best.strength,
      matchedFeatures: best.features,
      versionGuess: this.guessVersion(best.generator, features)
    };
  }

  private detectDALLE2(
    features: DiffusionFeatures,
    imageData: number[][],
    width: number,
    height: number
  ): { generator: DiffusionGenerator; strength: number; features: string[] } {
    let strength = 0;
    const matchedFeatures: string[] = [];
    
    // DALL-E 2 has specific characteristics
    if (features.iterativeRefinementScore > 0.6) {
      strength += 0.2;
      matchedFeatures.push('iterative_refinement');
    }
    
    if (features.compositionBalance > 0.8) {
      strength += 0.2;
      matchedFeatures.push('balanced_composition');
    }
    
    // DALL-E 2 often has specific color grading
    const colorGradeScore = this.analyzeColorGrading(imageData, width, height);
    if (colorGradeScore > 0.5) {
      strength += 0.15;
      matchedFeatures.push('dalle_color_grade');
    }
    
    return { generator: 'DALL-E-2', strength, features: matchedFeatures };
  }

  private detectDALLE3(
    features: DiffusionFeatures,
    imageData: number[][],
    width: number,
    height: number
  ): { generator: DiffusionGenerator; strength: number; features: string[] } {
    let strength = 0;
    const matchedFeatures: string[] = [];
    
    // DALL-E 3 has better coherence
    if (features.textureCoherence > 0.85) {
      strength += 0.25;
      matchedFeatures.push('high_coherence');
    }
    
    if (features.promptAdherenceScore > 0.8) {
      strength += 0.2;
      matchedFeatures.push('prompt_adherence');
    }
    
    // DALL-E 3 tends to have cleaner edges
    if (features.edgeConsistency > 0.8) {
      strength += 0.15;
      matchedFeatures.push('clean_edges');
    }
    
    return { generator: 'DALL-E-3', strength, features: matchedFeatures };
  }

  private detectMidjourney(
    features: DiffusionFeatures,
    imageData: number[][],
    width: number,
    height: number
  ): { generator: DiffusionGenerator; strength: number; features: string[] } {
    let strength = 0;
    const matchedFeatures: string[] = [];
    
    // Midjourney has distinctive artistic style
    if (features.styleConsistency > 0.75) {
      strength += 0.2;
      matchedFeatures.push('artistic_style');
    }
    
    // Midjourney often has specific saturation levels
    const saturationScore = this.analyzeSaturation(imageData, width, height);
    if (saturationScore > 0.6) {
      strength += 0.2;
      matchedFeatures.push('high_saturation');
    }
    
    // Midjourney compositions are often centered
    if (features.compositionBalance > 0.85) {
      strength += 0.15;
      matchedFeatures.push('centered_composition');
    }
    
    return { generator: 'Midjourney', strength, features: matchedFeatures };
  }

  private detectStableDiffusion(
    features: DiffusionFeatures,
    imageData: number[][],
    width: number,
    height: number
  ): { generator: DiffusionGenerator; strength: number; features: string[] } {
    let strength = 0;
    const matchedFeatures: string[] = [];
    
    // Stable Diffusion has VAE artifacts
    if (features.vaeDecompressionScore > 0.5) {
      strength += 0.25;
      matchedFeatures.push('vae_artifacts');
    }
    
    // SD often has specific noise patterns
    if (features.noisePatternScore > 0.6) {
      strength += 0.15;
      matchedFeatures.push('sd_noise');
    }
    
    // Check for typical SD resolutions
    if (this.isSDResolution(width, height)) {
      strength += 0.1;
      matchedFeatures.push('sd_resolution');
    }
    
    return { generator: 'Stable-Diffusion-1.5', strength, features: matchedFeatures };
  }

  private analyzeColorGrading(
    imageData: number[][],
    width: number,
    height: number
  ): number {
    // Simplified color grading analysis
    let warmCount = 0;
    let total = 0;
    
    const step = Math.max(1, Math.floor(width * height / 1000));
    
    for (let y = 0; y < height; y += step) {
      for (let x = 0; x < width; x += step) {
        const val = imageData[y][x];
        // DALL-E tends toward warmer tones
        if (val > 128) warmCount++;
        total++;
      }
    }
    
    return total > 0 ? warmCount / total : 0.5;
  }

  private analyzeSaturation(
    imageData: number[][],
    width: number,
    height: number
  ): number {
    // Estimate saturation from grayscale
    // High contrast = high saturation proxy
    let variance = 0;
    let mean = 0;
    let count = 0;
    
    const step = Math.max(1, Math.floor(width * height / 500));
    
    for (let y = 0; y < height; y += step) {
      for (let x = 0; x < width; x += step) {
        mean += imageData[y][x];
        count++;
      }
    }
    
    mean /= count;
    
    for (let y = 0; y < height; y += step) {
      for (let x = 0; x < width; x += step) {
        variance += Math.pow(imageData[y][x] - mean, 2);
      }
    }
    
    variance /= count;
    
    return Math.min(1, variance / 5000);
  }

  private isSDResolution(width: number, height: number): boolean {
    // Common SD resolutions
    const sdResolutions = [
      [512, 512], [512, 768], [768, 512],
      [768, 768], [1024, 1024]
    ];
    
    for (const [w, h] of sdResolutions) {
      if (Math.abs(width - w) < 10 && Math.abs(height - h) < 10) {
        return true;
      }
    }
    
    return false;
  }

  private guessVersion(generator: DiffusionGenerator, features: DiffusionFeatures): string {
    if (generator === 'Stable-Diffusion-1.5') {
      // Distinguish between SD versions
      if (features.vaeDecompressionScore > 0.7) {
        return '1.4 or 1.5';
      }
      if (features.textureCoherence > 0.8) {
        return '2.0 or XL';
      }
    }
    
    return 'Unknown version';
  }
}

// ============================================
// DIFFUSION DETECTOR
// ============================================

export class DiffusionDetector {
  private denoisingAnalyzer: DenoisingAnalyzer;
  private vaeDetector: VAEArtifactDetector;
  private signatureDetector: ModelSignatureDetector;

  constructor() {
    this.denoisingAnalyzer = new DenoisingAnalyzer();
    this.vaeDetector = new VAEArtifactDetector();
    this.signatureDetector = new ModelSignatureDetector();
  }

  /**
   * Detect diffusion-generated image
   */
  async detect(
    imageData: number[][],
    width: number,
    height: number
  ): Promise<DiffusionFingerprint> {
    // Analyze denoising patterns
    const denoisingResult = this.denoisingAnalyzer.analyze(imageData, width, height);
    
    // Detect VAE artifacts
    const vaeResult = this.vaeDetector.detect(imageData, width, height);
    
    // Compute frequency features
    const freqFeatures = this.computeFrequencyFeatures(imageData, width, height);
    
    // Compute spatial features
    const spatialFeatures = this.computeSpatialFeatures(imageData, width, height);
    
    // Build feature set
    const features: DiffusionFeatures = {
      denoisingScore: denoisingResult.denoisingScore,
      iterativeRefinementScore: denoisingResult.iterativeScore,
      noisePatternScore: denoisingResult.noisePatternScore,
      
      spectralSmoothness: freqFeatures.spectralSmoothness,
      highFrequencyLoss: freqFeatures.highFrequencyLoss,
      frequencyBanding: freqFeatures.frequencyBanding,
      
      textureCoherence: spatialFeatures.textureCoherence,
      edgeConsistency: spatialFeatures.edgeConsistency,
      colorGradientSmoothness: spatialFeatures.colorGradientSmoothness,
      
      promptAdherenceScore: spatialFeatures.promptAdherenceScore,
      compositionBalance: spatialFeatures.compositionBalance,
      styleConsistency: spatialFeatures.styleConsistency,
      
      latentSpaceArtifacts: vaeResult.latentArtifacts,
      vaeDecompressionScore: vaeResult.vaeScore
    };
    
    // Detect model signature
    const modelSignature = this.signatureDetector.detect(
      features,
      imageData,
      width,
      height
    );
    
    // Detect artifacts
    const artifacts = this.detectArtifacts(features);
    
    // Determine if diffusion-generated
    const isDiffusionGenerated = this.isDiffusionGenerated(features, modelSignature);
    
    // Compute confidence
    const confidence = this.computeConfidence(features, modelSignature);
    
    return {
      id: `diffusion-${Date.now()}`,
      isDiffusionGenerated,
      generator: modelSignature.generator,
      confidence,
      artifacts,
      features,
      modelSignature
    };
  }

  private computeFrequencyFeatures(
    imageData: number[][],
    width: number,
    height: number
  ): { spectralSmoothness: number; highFrequencyLoss: number; frequencyBanding: number } {
    // Compute FFT
    const n = Math.min(width, height);
    const size = Math.pow(2, Math.floor(Math.log2(n)));
    
    // Extract center region
    const region: number[][] = [];
    for (let y = 0; y < size; y++) {
      region[y] = [];
      for (let x = 0; x < size; x++) {
        region[y][x] = imageData[y][x];
      }
    }
    
    // Simple spectral analysis
    let highFreqEnergy = 0;
    let lowFreqEnergy = 0;
    let bandingScore = 0;
    
    // Compute 2D DCT-like transform (simplified)
    for (let ky = 0; ky < size; ky += 8) {
      for (let kx = 0; kx < size; kx += 8) {
        let coeff = 0;
        
        for (let y = 0; y < 8; y++) {
          for (let x = 0; x < 8; x++) {
            const cy = y + ky;
            const cx = x + kx;
            if (cy < size && cx < size) {
              const cosY = Math.cos((2 * y + 1) * ky * Math.PI / (2 * size));
              const cosX = Math.cos((2 * x + 1) * kx * Math.PI / (2 * size));
              coeff += region[cy][cx] * cosY * cosX;
            }
          }
        }
        
        if (ky + kx > size / 2) {
          highFreqEnergy += coeff * coeff;
        } else {
          lowFreqEnergy += coeff * coeff;
        }
      }
    }
    
    // Spectral smoothness
    const spectralSmoothness = 1 - Math.abs(highFreqEnergy - lowFreqEnergy) / 
                                   (highFreqEnergy + lowFreqEnergy + 1);
    
    // High frequency loss (diffusion models lose high-freq detail)
    const highFrequencyLoss = lowFreqEnergy > 0 ? 
                              1 - highFreqEnergy / lowFreqEnergy : 0;
    
    // Frequency banding (check for regular patterns)
    bandingScore = this.detectFrequencyBanding(imageData, width, height);
    
    return { spectralSmoothness, highFrequencyLoss, frequencyBanding: bandingScore };
  }

  private detectFrequencyBanding(
    imageData: number[][],
    width: number,
    height: number
  ): number {
    // Look for regular frequency patterns
    const rowProfiles: number[][] = [];
    
    for (let y = 0; y < height; y += 16) {
      const profile: number[] = [];
      for (let x = 0; x < width - 1; x++) {
        profile.push(imageData[y][x + 1] - imageData[y][x]);
      }
      rowProfiles.push(profile);
    }
    
    // Check for correlation between profiles
    if (rowProfiles.length < 2) return 0;
    
    let totalCorr = 0;
    for (let i = 0; i < rowProfiles.length - 1; i++) {
      const corr = this.correlation(rowProfiles[i], rowProfiles[i + 1]);
      totalCorr += corr;
    }
    
    return totalCorr / (rowProfiles.length - 1);
  }

  private correlation(a: number[], b: number[]): number {
    const n = Math.min(a.length, b.length);
    if (n === 0) return 0;
    
    const meanA = a.reduce((x, y) => x + y, 0) / n;
    const meanB = b.reduce((x, y) => x + y, 0) / n;
    
    let num = 0;
    let denA = 0;
    let denB = 0;
    
    for (let i = 0; i < n; i++) {
      const diffA = a[i] - meanA;
      const diffB = b[i] - meanB;
      num += diffA * diffB;
      denA += diffA * diffA;
      denB += diffB * diffB;
    }
    
    const den = Math.sqrt(denA * denB);
    return den > 0 ? num / den : 0;
  }

  private computeSpatialFeatures(
    imageData: number[][],
    width: number,
    height: number
  ): {
    textureCoherence: number;
    edgeConsistency: number;
    colorGradientSmoothness: number;
    promptAdherenceScore: number;
    compositionBalance: number;
    styleConsistency: number;
  } {
    // Texture coherence
    const textureCoherence = this.computeTextureCoherence(imageData, width, height);
    
    // Edge consistency
    const edgeConsistency = this.computeEdgeConsistency(imageData, width, height);
    
    // Color gradient smoothness
    const colorGradientSmoothness = this.computeGradientSmoothness(imageData, width, height);
    
    // Prompt adherence (composition coherence)
    const promptAdherenceScore = this.computePromptAdherence(imageData, width, height);
    
    // Composition balance
    const compositionBalance = this.computeCompositionBalance(imageData, width, height);
    
    // Style consistency
    const styleConsistency = this.computeStyleConsistency(imageData, width, height);
    
    return {
      textureCoherence,
      edgeConsistency,
      colorGradientSmoothness,
      promptAdherenceScore,
      compositionBalance,
      styleConsistency
    };
  }

  private computeTextureCoherence(image: number[][], width: number, height: number): number {
    // Simplified texture coherence
    const blockSize = 16;
    let coherenceSum = 0;
    let count = 0;
    
    for (let y = 0; y < height - blockSize; y += blockSize) {
      for (let x = 0; x < width - blockSize; x += blockSize) {
        const block1 = this.getBlockStats(image, x, y, blockSize);
        const block2 = this.getBlockStats(image, x + blockSize, y, blockSize);
        
        const similarity = 1 - Math.abs(block1.mean - block2.mean) / 255;
        coherenceSum += similarity;
        count++;
      }
    }
    
    return count > 0 ? coherenceSum / count : 0;
  }

  private getBlockStats(
    image: number[][],
    x: number,
    y: number,
    size: number
  ): { mean: number; variance: number } {
    let sum = 0;
    let count = 0;
    
    for (let dy = 0; dy < size; dy++) {
      for (let dx = 0; dx < size; dx++) {
        if (y + dy < image.length && x + dx < image[0].length) {
          sum += image[y + dy][x + dx];
          count++;
        }
      }
    }
    
    const mean = count > 0 ? sum / count : 0;
    
    let variance = 0;
    for (let dy = 0; dy < size; dy++) {
      for (let dx = 0; dx < size; dx++) {
        if (y + dy < image.length && x + dx < image[0].length) {
          variance += Math.pow(image[y + dy][x + dx] - mean, 2);
        }
      }
    }
    
    return { mean, variance: count > 0 ? variance / count : 0 };
  }

  private computeEdgeConsistency(image: number[][], width: number, height: number): number {
    // Check for consistent edge directions
    let consistentEdges = 0;
    let totalEdges = 0;
    
    for (let y = 1; y < height - 1; y++) {
      for (let x = 1; x < width - 1; x++) {
        const gx = image[y][x + 1] - image[y][x - 1];
        const gy = image[y + 1][x] - image[y - 1][x];
        const magnitude = Math.sqrt(gx * gx + gy * gy);
        
        if (magnitude > 30) {
          // Check 8-neighborhood for similar direction
          let similarCount = 0;
          for (let dy = -1; dy <= 1; dy++) {
            for (let dx = -1; dx <= 1; dx++) {
              if (dy === 0 && dx === 0) continue;
              
              const nx = x + dx;
              const ny = y + dy;
              if (ny > 0 && ny < height - 1 && nx > 0 && nx < width - 1) {
                const ngx = image[ny][nx + 1] - image[ny][nx - 1];
                const ngy = image[ny + 1][nx] - image[ny - 1][nx];
                
                // Check if directions are similar
                const dot = gx * ngx + gy * ngy;
                if (dot > 0) similarCount++;
              }
            }
          }
          
          if (similarCount >= 4) consistentEdges++;
          totalEdges++;
        }
      }
    }
    
    return totalEdges > 0 ? consistentEdges / totalEdges : 0;
  }

  private computeGradientSmoothness(image: number[][], width: number, height: number): number {
    // Check for smooth gradients
    let smoothGradients = 0;
    let total = 0;
    
    for (let y = 1; y < height - 1; y++) {
      for (let x = 1; x < width - 2; x++) {
        const g1 = image[y][x + 1] - image[y][x];
        const g2 = image[y][x + 2] - image[y][x + 1];
        
        // Smooth if gradients are similar
        if (Math.abs(g1 - g2) < 20) {
          smoothGradients++;
        }
        total++;
      }
    }
    
    return total > 0 ? smoothGradients / total : 0;
  }

  private computePromptAdherence(image: number[][], width: number, height: number): number {
    // Simplified prompt adherence - measures composition coherence
    // Diffusion models with good prompt adherence have coherent compositions
    
    const centerRegion = this.getBlockStats(
      image,
      Math.floor(width / 4),
      Math.floor(height / 4),
      Math.floor(width / 2)
    );
    
    const cornerMean = (
      this.getBlockStats(image, 0, 0, Math.floor(width / 8)).mean +
      this.getBlockStats(image, width - Math.floor(width / 8), 0, Math.floor(width / 8)).mean +
      this.getBlockStats(image, 0, height - Math.floor(height / 8), Math.floor(width / 8)).mean +
      this.getBlockStats(image, width - Math.floor(width / 8), height - Math.floor(height / 8), Math.floor(width / 8)).mean
    ) / 4;
    
    // Good prompt adherence = distinct subject vs background
    return 1 - Math.abs(centerRegion.mean - cornerMean) / 255;
  }

  private computeCompositionBalance(image: number[][], width: number, height: number): number {
    // Check for balanced composition
    const leftHalf = this.getBlockStats(image, 0, 0, Math.floor(width / 2), height);
    const rightHalf = this.getBlockStats(image, Math.floor(width / 2), 0, Math.floor(width / 2), height);
    const topHalf = this.getBlockStats(image, 0, 0, width, Math.floor(height / 2));
    const bottomHalf = this.getBlockStats(image, 0, Math.floor(height / 2), width, Math.floor(height / 2));
    
    const horizontalBalance = 1 - Math.abs(leftHalf.mean - rightHalf.mean) / 255;
    const verticalBalance = 1 - Math.abs(topHalf.mean - bottomHalf.mean) / 255;
    
    return (horizontalBalance + verticalBalance) / 2;
  }

  private computeStyleConsistency(image: number[][], width: number, height: number): number {
    // Check for consistent style across image
    const quadrants = [
      this.getBlockStats(image, 0, 0, Math.floor(width / 2), Math.floor(height / 2)),
      this.getBlockStats(image, Math.floor(width / 2), 0, Math.floor(width / 2), Math.floor(height / 2)),
      this.getBlockStats(image, 0, Math.floor(height / 2), Math.floor(width / 2), Math.floor(height / 2)),
      this.getBlockStats(image, Math.floor(width / 2), Math.floor(height / 2), Math.floor(width / 2), Math.floor(height / 2))
    ];
    
    // Compute variance of variances
    const meanVariance = quadrants.reduce((sum, q) => sum + q.variance, 0) / 4;
    const varianceOfVariance = quadrants.reduce((sum, q) => sum + Math.pow(q.variance - meanVariance, 2), 0) / 4;
    
    // Low variance of variances = consistent style
    return 1 / (1 + varianceOfVariance / 1000);
  }

  private detectArtifacts(features: DiffusionFeatures): DiffusionArtifact[] {
    const artifacts: DiffusionArtifact[] = [];
    
    if (features.denoisingScore > 0.6) {
      artifacts.push({
        type: 'denoising_artifact',
        severity: 'high',
        evidence: `Denoising score: ${features.denoisingScore.toFixed(3)}`,
        confidence: features.denoisingScore
      });
    }
    
    if (features.vaeDecompressionScore > 0.5) {
      artifacts.push({
        type: 'vae_compression',
        severity: 'medium',
        evidence: 'VAE compression/decompression artifacts detected',
        confidence: features.vaeDecompressionScore
      });
    }
    
    if (features.highFrequencyLoss > 0.6) {
      artifacts.push({
        type: 'high_frequency_loss',
        severity: 'medium',
        evidence: 'Loss of high-frequency detail typical of diffusion',
        confidence: features.highFrequencyLoss
      });
    }
    
    if (features.frequencyBanding > 0.5) {
      artifacts.push({
        type: 'frequency_banding',
        severity: 'low',
        evidence: 'Regular frequency patterns detected',
        confidence: features.frequencyBanding
      });
    }
    
    return artifacts;
  }

  private isDiffusionGenerated(
    features: DiffusionFeatures,
    signature: ModelSignature
  ): boolean {
    // Combine multiple signals
    let score = 0;
    
    if (features.denoisingScore > 0.5) score += 0.25;
    if (features.vaeDecompressionScore > 0.4) score += 0.2;
    if (features.highFrequencyLoss > 0.5) score += 0.15;
    if (signature.signatureStrength > 0.4) score += 0.2;
    if (features.iterativeRefinementScore > 0.5) score += 0.2;
    
    return score > 0.5;
  }

  private computeConfidence(
    features: DiffusionFeatures,
    signature: ModelSignature
  ): number {
    // Weighted combination of signals
    const weights = {
      denoising: 0.25,
      vae: 0.2,
      signature: 0.25,
      iterative: 0.15,
      highFreq: 0.15
    };
    
    return (
      weights.denoising * features.denoisingScore +
      weights.vae * features.vaeDecompressionScore +
      weights.signature * signature.signatureStrength +
      weights.iterative * features.iterativeRefinementScore +
      weights.highFreq * features.highFrequencyLoss
    );
  }
}

// ============================================
// EXPORTS
// ============================================

export const diffusionDetection = {
  DiffusionDetector,
  DenoisingAnalyzer,
  VAEArtifactDetector,
  ModelSignatureDetector
};

export default diffusionDetection;
