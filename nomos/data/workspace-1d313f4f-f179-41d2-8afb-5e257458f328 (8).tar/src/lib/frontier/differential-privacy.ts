/**
 * Differential Privacy Engine
 *
 * Provides mathematical privacy guarantees using epsilon-delta differential privacy.
 * Ensures that detection results cannot be used to infer information about individuals
 * in the training data or detection requests.
 *
 * Based on:
 * - Dwork et al. (2006) - Calibrating noise to sensitivity
 * - Abadi et al. (2016) - Deep Learning with Differential Privacy
 * - Mironov (2017) - Rényi Differential Privacy
 *
 * @module differential-privacy
 * @version 1.0.0
 */

import { createHash, randomBytes } from 'crypto';

// ============================================================================
// DIFFERENTIAL PRIVACY TYPES
// ============================================================================

/**
 * Privacy budget parameters
 */
export interface PrivacyBudget {
  /** Epsilon - privacy loss parameter (smaller = more privacy) */
  epsilon: number;
  /** Delta - probability of privacy breach (should be < 1/n) */
  delta: number;
  /** Remaining budget */
  remaining: number;
  /** Total budget consumed */
  consumed: number;
}

/**
 * Sensitivity of a query function
 */
export interface SensitivityAnalysis {
  /** L1 sensitivity */
  l1Sensitivity: number;
  /** L2 sensitivity */
  l2Sensitivity: number;
  /** Global sensitivity */
  globalSensitivity: number;
  /** Local sensitivity at current data */
  localSensitivity: number;
  /** Smooth sensitivity */
  smoothSensitivity: number;
}

/**
 * Noisy output with privacy guarantee
 */
export interface PrivateOutput<T> {
  /** The noisy result */
  value: T;
  /** Privacy cost of this query */
  privacyCost: { epsilon: number; delta: number };
  /** Noise parameters used */
  noiseParams: {
    mechanism: string;
    scale: number;
    variance: number;
  };
  /** Confidence interval */
  confidenceInterval?: {
    lower: T;
    upper: T;
    confidence: number;
  };
}

/**
 * Privacy accountant for tracking budget
 */
export interface PrivacyAccountant {
  /** Total budget allocated */
  totalBudget: PrivacyBudget;
  /** Per-query costs */
  queryLog: Array<{
    timestamp: number;
    epsilon: number;
    delta: number;
    mechanism: string;
    description: string;
  }>;
  /** Renyi DP parameters for tighter accounting */
  rdpOrders: number[];
  rdpEpsilon: number;
}

// ============================================================================
// CORE PRIVACY MECHANISMS
// ============================================================================

/**
 * Laplace Mechanism - ε-differential privacy
 *
 * Adds Laplace noise calibrated to function sensitivity:
 * noise ~ Laplace(0, sensitivity/ε)
 */
export function laplaceMechanism<T extends number>(
  trueValue: T,
  sensitivity: number,
  epsilon: number
): PrivateOutput<T> {
  const scale = sensitivity / epsilon;

  // Generate Laplace noise using inverse CDF
  const buffer = randomBytes(8);
  const u = buffer.readBigUInt64LE(0);
  const uFloat = Number(u) / Number(BigInt('0xFFFFFFFFFFFFFFFF')) * 2 - 1; // Uniform in [-1, 1]

  // Laplace noise: -scale * sign(u) * ln(1 - |u|)
  const noise = -scale * Math.sign(uFloat) * Math.log(1 - Math.abs(uFloat));

  const noisyValue = (trueValue + noise) as T;

  return {
    value: noisyValue,
    privacyCost: { epsilon, delta: 0 },
    noiseParams: {
      mechanism: 'laplace',
      scale,
      variance: 2 * scale * scale
    },
    confidenceInterval: {
      lower: (trueValue - 2 * scale) as T,
      upper: (trueValue + 2 * scale) as T,
      confidence: 0.95
    }
  };
}

/**
 * Gaussian Mechanism - (ε, δ)-differential privacy
 *
 * Adds Gaussian noise for tighter composition at cost of δ > 0
 */
export function gaussianMechanism<T extends number>(
  trueValue: T,
  sensitivity: number,
  epsilon: number,
  delta: number
): PrivateOutput<T> {
  // σ = sensitivity * sqrt(2 * ln(1.25/δ)) / ε
  const sigma = sensitivity * Math.sqrt(2 * Math.log(1.25 / delta)) / epsilon;

  // Box-Muller transform for Gaussian noise
  const u1 = Math.random();
  const u2 = Math.random();
  const noise = sigma * Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);

  const noisyValue = (trueValue + noise) as T;

  return {
    value: noisyValue,
    privacyCost: { epsilon, delta },
    noiseParams: {
      mechanism: 'gaussian',
      scale: sigma,
      variance: sigma * sigma
    },
    confidenceInterval: {
      lower: (trueValue - 1.96 * sigma) as T,
      upper: (trueValue + 1.96 * sigma) as T,
      confidence: 0.95
    }
  };
}

/**
 * Exponential Mechanism - ε-differential privacy for non-numeric outputs
 *
 * Selects from a universe of possible outputs based on utility scores
 */
export function exponentialMechanism<T>(
  items: T[],
  utilityFunction: (item: T) => number,
  sensitivity: number,
  epsilon: number
): PrivateOutput<T> {
  const scale = 2 * sensitivity / epsilon;

  // Calculate utility scores
  const utilities = items.map(item => utilityFunction(item));

  // Calculate probabilities: exp(utility / scale)
  const expUtilities = utilities.map(u => Math.exp(u / scale));
  const sumExp = expUtilities.reduce((a, b) => a + b, 0);
  const probabilities = expUtilities.map(eu => eu / sumExp);

  // Sample according to probabilities
  const r = Math.random();
  let cumProb = 0;
  let selectedIndex = 0;

  for (let i = 0; i < probabilities.length; i++) {
    cumProb += probabilities[i];
    if (r <= cumProb) {
      selectedIndex = i;
      break;
    }
  }

  return {
    value: items[selectedIndex],
    privacyCost: { epsilon, delta: 0 },
    noiseParams: {
      mechanism: 'exponential',
      scale,
      variance: scale * scale
    }
  };
}

/**
 * Report Noisy Max - ε-differential privacy for selection
 *
 * Adds noise to each option's score and selects the maximum
 */
export function reportNoisyMax<T>(
  items: T[],
  scoreFunction: (item: T) => number,
  epsilon: number
): PrivateOutput<T> {
  const scale = 1 / epsilon;

  // Add Gumbel noise to each score
  const noisyScores = items.map(item => {
    const score = scoreFunction(item);
    // Gumbel noise: -scale * ln(-ln(U))
    const u = Math.random();
    const gumbelNoise = -scale * Math.log(-Math.log(u));
    return { item, noisyScore: score + gumbelNoise };
  });

  // Select maximum
  noisyScores.sort((a, b) => b.noisyScore - a.noisyScore);
  const selected = noisyScores[0].item;

  return {
    value: selected,
    privacyCost: { epsilon, delta: 0 },
    noiseParams: {
      mechanism: 'report_noisy_max',
      scale,
      variance: (Math.PI * Math.PI * scale * scale) / 6 // Gumbel variance
    }
  };
}

// ============================================================================
// COMPOSITION THEOREMS
// ============================================================================

/**
 * Basic Composition - Direct sum of privacy costs
 */
export function basicComposition(
  privacyCosts: Array<{ epsilon: number; delta: number }>
): PrivacyBudget {
  return {
    epsilon: privacyCosts.reduce((sum, cost) => sum + cost.epsilon, 0),
    delta: privacyCosts.reduce((sum, cost) => sum + cost.delta, 0),
    remaining: 0,
    consumed: 0
  };
}

/**
 * Advanced Composition - Tighter bounds for multiple queries
 *
 * For k (ε, δ)-DP queries, the total is:
 * (ε', kδ + δ') where ε' = ε√(2k ln(1/δ')) + kε(e^ε - 1)
 */
export function advancedComposition(
  privacyCosts: Array<{ epsilon: number; delta: number }>,
  targetDelta: number
): PrivacyBudget {
  const k = privacyCosts.length;
  const epsilon = privacyCosts[0]?.epsilon || 0;
  const totalDelta = privacyCosts.reduce((sum, cost) => sum + cost.delta, 0);

  // Advanced composition bound
  const epsilonPrime = epsilon * Math.sqrt(2 * k * Math.log(1 / targetDelta)) +
                       k * epsilon * (Math.exp(epsilon) - 1);

  return {
    epsilon: epsilonPrime,
    delta: totalDelta + targetDelta,
    remaining: 0,
    consumed: 0
  };
}

/**
 * Rényi Differential Privacy Composition
 *
 * Much tighter composition for many queries
 */
export function rdpComposition(
  orders: number[], // α values
  epsilon: number,
  steps: number
): { optimalEpsilon: number; optimalOrder: number; rdpEpsilon: number } {
  // RDP epsilon for each order
  const rdpEpsilons = orders.map(alpha => {
    // For Gaussian mechanism: ε(α) = α * ε² / 2
    return (alpha * epsilon * epsilon) / 2;
  });

  // Total RDP after steps
  const totalRdp = rdpEpsilons.map(e => e * steps);

  // Convert back to (ε, δ)-DP
  const delta = 1e-5;
  const conversions = orders.map((alpha, i) => {
    return totalRdp[i] + Math.log((alpha - 1) / alpha) - Math.log(delta) / (alpha - 1);
  });

  // Find optimal
  let minEpsilon = Infinity;
  let optimalOrder = orders[0];
  let optimalRdp = 0;

  for (let i = 0; i < orders.length; i++) {
    if (conversions[i] < minEpsilon) {
      minEpsilon = conversions[i];
      optimalOrder = orders[i];
      optimalRdp = totalRdp[i];
    }
  }

  return {
    optimalEpsilon: minEpsilon,
    optimalOrder,
    rdpEpsilon: optimalRdp
  };
}

// ============================================================================
// PRIVACY ACCOUNTANT
// ============================================================================

/**
 * Create a privacy accountant to track budget
 */
export function createPrivacyAccountant(
  totalEpsilon: number,
  totalDelta: number
): PrivacyAccountant {
  return {
    totalBudget: {
      epsilon: totalEpsilon,
      delta: totalDelta,
      remaining: totalEpsilon,
      consumed: 0
    },
    queryLog: [],
    rdpOrders: [2, 3, 4, 8, 16, 32, 64, 256, 512, 1024],
    rdpEpsilon: 0
  };
}

/**
 * Check if query can be afforded
 */
export function canAffordQuery(
  accountant: PrivacyAccountant,
  epsilon: number,
  delta: number
): boolean {
  return (
    accountant.totalBudget.remaining >= epsilon &&
    accountant.totalBudget.delta >= delta
  );
}

/**
 * Spend privacy budget
 */
export function spendBudget(
  accountant: PrivacyAccountant,
  epsilon: number,
  delta: number,
  mechanism: string,
  description: string
): boolean {
  if (!canAffordQuery(accountant, epsilon, delta)) {
    return false;
  }

  accountant.totalBudget.remaining -= epsilon;
  accountant.totalBudget.consumed += epsilon;
  accountant.queryLog.push({
    timestamp: Date.now(),
    epsilon,
    delta,
    mechanism,
    description
  });

  // Update RDP accounting
  const rdpResult = rdpComposition(
    accountant.rdpOrders,
    epsilon,
    accountant.queryLog.length
  );
  accountant.rdpEpsilon = rdpResult.rdpEpsilon;

  return true;
}

/**
 * Get privacy budget status
 */
export function getBudgetStatus(
  accountant: PrivacyAccountant
): {
  remaining: number;
  consumed: number;
  percentageRemaining: number;
  queryCount: number;
  rdpEpsilon: number;
  effectivelyRemaining: number; // Using RDP composition
} {
  return {
    remaining: accountant.totalBudget.remaining,
    consumed: accountant.totalBudget.consumed,
    percentageRemaining: (accountant.totalBudget.remaining / accountant.totalBudget.epsilon) * 100,
    queryCount: accountant.queryLog.length,
    rdpEpsilon: accountant.rdpEpsilon,
    effectivelyRemaining: accountant.totalBudget.epsilon - accountant.rdpEpsilon
  };
}

// ============================================================================
// SENSITIVITY ANALYSIS
// ============================================================================

/**
 * Calculate sensitivity for counting queries
 */
export function countSensitivity(): number {
  return 1; // Adding/removing one record changes count by at most 1
}

/**
 * Calculate sensitivity for sum queries
 */
export function sumSensitivity(maxValue: number): number {
  return maxValue; // One record can contribute at most maxValue
}

/**
 * Calculate sensitivity for mean queries (bounded)
 */
export function meanSensitivity(
  lowerBound: number,
  upperBound: number,
  n: number
): number {
  return (upperBound - lowerBound) / n;
}

/**
 * Full sensitivity analysis for a function
 */
export function analyzeSensitivity(
  fn: (data: unknown[]) => number,
  sampleData: unknown[],
  numSamples: number = 100
): SensitivityAnalysis {
  // Compute function on original data
  const originalResult = fn(sampleData);

  // Compute local sensitivity by perturbing data
  let l1Max = 0;
  let l2Max = 0;

  for (let i = 0; i < Math.min(numSamples, sampleData.length); i++) {
    // Remove one element
    const perturbedData = [...sampleData];
    perturbedData.splice(i, 1);

    const perturbedResult = fn(perturbedData);
    const diff = Math.abs(originalResult - perturbedResult);

    l1Max = Math.max(l1Max, diff);
    l2Max = Math.max(l2Max, diff * diff);
  }

  // Estimate global sensitivity (conservative bound)
  const globalSensitivity = l1Max * 2; // Assume worst case is 2x observed

  return {
    l1Sensitivity: l1Max,
    l2Sensitivity: Math.sqrt(l2Max),
    globalSensitivity,
    localSensitivity: l1Max,
    smoothSensitivity: l1Max * 0.9 // Approximate smooth sensitivity
  };
}

// ============================================================================
// PRIVATE AGGREGATIONS
// ============================================================================

/**
 * Private count with Laplace mechanism
 */
export function privateCount(
  items: unknown[],
  predicate: (item: unknown) => boolean,
  epsilon: number
): PrivateOutput<number> {
  const trueCount = items.filter(predicate).length;
  return laplaceMechanism(trueCount, 1, epsilon);
}

/**
 * Private sum with Laplace mechanism
 */
export function privateSum(
  items: number[],
  maxValue: number,
  epsilon: number
): PrivateOutput<number> {
  // Clamp values to bound sensitivity
  const clampedItems = items.map(v => Math.min(Math.max(v, 0), maxValue));
  const trueSum = clampedItems.reduce((a, b) => a + b, 0);
  return laplaceMechanism(trueSum, maxValue, epsilon);
}

/**
 * Private mean with bounded values
 */
export function privateMean(
  items: number[],
  lowerBound: number,
  upperBound: number,
  epsilon: number
): PrivateOutput<number> {
  // Clamp and normalize
  const clampedItems = items.map(v => Math.min(Math.max(v, lowerBound), upperBound));
  const trueMean = clampedItems.reduce((a, b) => a + b, 0) / items.length;

  const sensitivity = (upperBound - lowerBound) / items.length;
  return laplaceMechanism(trueMean, sensitivity, epsilon);
}

/**
 * Private histogram with parallel composition
 */
export function privateHistogram<T extends string | number>(
  items: T[],
  categories: T[],
  epsilon: number
): Map<T, PrivateOutput<number>> {
  // Parallel composition: split epsilon across categories
  const epsilonPerCategory = epsilon / categories.length;
  const result = new Map<T, PrivateOutput<number>>();

  for (const category of categories) {
    const count = items.filter(i => i === category).length;
    result.set(category, laplaceMechanism(count, 1, epsilonPerCategory));
  }

  return result;
}

// ============================================================================
// PRIVATE MACHINE LEARNING
// ============================================================================

/**
 * DP-SGD: Differentially Private Stochastic Gradient Descent
 *
 * Adds noise to gradients during training
 */
export function dpSgdGradient(
  gradient: number[],
  sensitivity: number,
  epsilon: number,
  delta: number,
  clippingNorm: number
): { gradient: number[]; privacyCost: { epsilon: number; delta: number } } {
  // Clip gradient
  const gradNorm = Math.sqrt(gradient.reduce((sum, g) => sum + g * g, 0));
  const clippedGradient = gradient.map(g => g * Math.min(1, clippingNorm / gradNorm));

  // Add Gaussian noise
  const sigma = sensitivity * Math.sqrt(2 * Math.log(1.25 / delta)) / epsilon;
  const noisyGradient = clippedGradient.map(g => {
    const u1 = Math.random();
    const u2 = Math.random();
    const noise = sigma * Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
    return g + noise;
  });

  return {
    gradient: noisyGradient,
    privacyCost: { epsilon, delta }
  };
}

// ============================================================================
// PRIVACY-PRESERVING DETECTION
// ============================================================================

/**
 * Private deepfake detection result
 */
export interface PrivateDetectionResult {
  /** Noisy confidence score */
  confidence: PrivateOutput<number>;
  /** Private verdict (using exponential mechanism) */
  verdict: PrivateOutput<'authentic' | 'deepfake' | 'uncertain'>;
  /** Privacy budget consumed */
  privacyCost: { epsilon: number; delta: number };
  /** Whether detection was performed */
  performed: boolean;
}

/**
 * Perform differentially private deepfake detection
 */
export function privateDetection(
  trueConfidence: number,
  trueVerdict: 'authentic' | 'deepfake' | 'uncertain',
  accountant: PrivacyAccountant,
  epsilon: number = 0.5,
  delta: number = 1e-6
): PrivateDetectionResult {
  // Check budget
  if (!canAffordQuery(accountant, epsilon, delta)) {
    return {
      confidence: { value: 0.5, privacyCost: { epsilon: 0, delta: 0 }, noiseParams: { mechanism: 'none', scale: 0, variance: 0 } },
      verdict: { value: 'uncertain', privacyCost: { epsilon: 0, delta: 0 }, noiseParams: { mechanism: 'none', scale: 0, variance: 0 } },
      privacyCost: { epsilon: 0, delta: 0 },
      performed: false
    };
  }

  // Private confidence using Gaussian mechanism
  const privateConfidence = gaussianMechanism(trueConfidence, 1, epsilon * 0.7, delta);

  // Private verdict using exponential mechanism
  const verdictUtilities = {
    'authentic': trueVerdict === 'authentic' ? 1.0 : trueConfidence,
    'deepfake': trueVerdict === 'deepfake' ? 1.0 : (1 - trueConfidence),
    'uncertain': trueVerdict === 'uncertain' ? 1.0 : 0.5
  };

  const privateVerdict = exponentialMechanism(
    ['authentic', 'deepfake', 'uncertain'] as const,
    (v) => verdictUtilities[v as keyof typeof verdictUtilities],
    1,
    epsilon * 0.3
  );

  // Spend budget
  spendBudget(accountant, epsilon, delta, 'private_detection', 'DP deepfake detection');

  return {
    confidence: privateConfidence,
    verdict: privateVerdict as PrivateDetectionResult['verdict'],
    privacyCost: { epsilon, delta },
    performed: true
  };
}

// ============================================================================
// TESTING
// ============================================================================

/**
 * Run differential privacy tests
 */
export function runDifferentialPrivacyTests(): {
  passed: boolean;
  tests: Array<{ name: string; passed: boolean; message: string }>;
  summary: { total: number; passed: number; failed: number };
} {
  const tests: Array<{ name: string; passed: boolean; message: string }> = [];

  // Test 1: Laplace mechanism
  const laplaceResult = laplaceMechanism(100, 1, 0.5);
  tests.push({
    name: 'Laplace mechanism',
    passed: Math.abs(laplaceResult.value - 100) < 20, // Within reasonable noise
    message: `Noisy value: ${laplaceResult.value.toFixed(2)}, true: 100`
  });

  // Test 2: Gaussian mechanism
  const gaussianResult = gaussianMechanism(100, 1, 0.5, 1e-6);
  tests.push({
    name: 'Gaussian mechanism',
    passed: Math.abs(gaussianResult.value - 100) < 20,
    message: `Noisy value: ${gaussianResult.value.toFixed(2)}, true: 100`
  });

  // Test 3: Exponential mechanism
  const items = ['a', 'b', 'c', 'd'];
  const expResult = exponentialMechanism(items, (s) => s === 'b' ? 10 : 1, 1, 0.5);
  tests.push({
    name: 'Exponential mechanism',
    passed: items.includes(expResult.value),
    message: `Selected: ${expResult.value}`
  });

  // Test 4: Privacy budget tracking
  const accountant = createPrivacyAccountant(2.0, 1e-5);
  spendBudget(accountant, 0.5, 1e-6, 'laplace', 'test query 1');
  spendBudget(accountant, 0.5, 1e-6, 'gaussian', 'test query 2');
  tests.push({
    name: 'Privacy budget tracking',
    passed: accountant.totalBudget.consumed === 1.0 && accountant.totalBudget.remaining === 1.0,
    message: `Consumed: ${accountant.totalBudget.consumed}, Remaining: ${accountant.totalBudget.remaining}`
  });

  // Test 5: Composition
  const basicComp = basicComposition([
    { epsilon: 0.5, delta: 1e-6 },
    { epsilon: 0.5, delta: 1e-6 },
    { epsilon: 0.5, delta: 1e-6 }
  ]);
  tests.push({
    name: 'Basic composition',
    passed: basicComp.epsilon === 1.5,
    message: `Total epsilon: ${basicComp.epsilon}`
  });

  // Test 6: RDP composition
  const rdpComp = rdpComposition([2, 4, 8, 16, 32], 0.1, 10);
  tests.push({
    name: 'RDP composition',
    passed: rdpComp.optimalEpsilon > 0,
    message: `Optimal epsilon: ${rdpComp.optimalEpsilon.toFixed(3)} at order ${rdpComp.optimalOrder}`
  });

  // Test 7: Private count
  const countData = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  const privateCountResult = privateCount(countData, (x) => (x as number) > 5, 0.5);
  tests.push({
    name: 'Private count',
    passed: privateCountResult.value >= 3 && privateCountResult.value <= 7, // True count is 5
    message: `Private count: ${privateCountResult.value.toFixed(2)}, true: 5`
  });

  // Test 8: Private detection
  const detAccountant = createPrivacyAccountant(1.0, 1e-5);
  const privateDet = privateDetection(0.85, 'deepfake', detAccountant, 0.5, 1e-6);
  tests.push({
    name: 'Private detection',
    passed: privateDet.performed && privateDet.confidence.value > 0,
    message: `Private confidence: ${privateDet.confidence.value.toFixed(2)}, verdict: ${privateDet.verdict.value}`
  });

  // Test 9: Sensitivity analysis
  const sensAnalysis = analyzeSensitivity(
    (data) => (data as number[]).reduce((a: number, b) => a + (b as number), 0),
    [1, 2, 3, 4, 5],
    5
  );
  tests.push({
    name: 'Sensitivity analysis',
    passed: sensAnalysis.l1Sensitivity >= 0 && sensAnalysis.globalSensitivity >= sensAnalysis.l1Sensitivity,
    message: `L1 sensitivity: ${sensAnalysis.l1Sensitivity}, Global: ${sensAnalysis.globalSensitivity}`
  });

  // Test 10: Private histogram
  const histData = ['a', 'b', 'a', 'c', 'b', 'a', 'a'];
  const privateHist = privateHistogram(histData, ['a', 'b', 'c'], 1.0);
  tests.push({
    name: 'Private histogram',
    passed: privateHist.size === 3,
    message: `Histogram categories: ${privateHist.size}`
  });

  const passed = tests.filter(t => t.passed).length;
  const failed = tests.filter(t => !t.passed).length;

  return {
    passed: failed === 0,
    tests,
    summary: { total: tests.length, passed, failed }
  };
}

// Export all
export default {
  laplaceMechanism,
  gaussianMechanism,
  exponentialMechanism,
  reportNoisyMax,
  basicComposition,
  advancedComposition,
  rdpComposition,
  createPrivacyAccountant,
  canAffordQuery,
  spendBudget,
  getBudgetStatus,
  countSensitivity,
  sumSensitivity,
  meanSensitivity,
  analyzeSensitivity,
  privateCount,
  privateSum,
  privateMean,
  privateHistogram,
  dpSgdGradient,
  privateDetection,
  runDifferentialPrivacyTests
};
