/**
 * Secure Multi-Party Computation (SMPC)
 *
 * Enables collaborative deepfake analysis across multiple parties without
 * revealing the underlying content to any single party.
 *
 * Based on:
 * - Yao's Garbled Circuits (1986)
 * - Shamir Secret Sharing (1979)
 * - BGW Protocol (Ben-Or, Goldwasser, Wigderson 1988)
 * - SPDZ Protocol (Damgård et al. 2012)
 *
 * @module smpc
 * @version 1.0.0
 */

import { createHash, randomBytes } from 'crypto';

// ============================================================================
// SMPC TYPES
// ============================================================================

/**
 * Party in the computation
 */
export interface SMPCParty {
  id: string;
  name: string;
  role: 'analyst' | 'verifier' | 'aggregator' | 'contributor';
  publicKey: string;
  isOnline: boolean;
  trustLevel: number; // 0-1
}

/**
 * Secret share of a value
 */
export interface SecretShare {
  partyId: string;
  shareIndex: number;
  value: bigint;
  commitment: string; // Hash commitment
}

/**
 * Shared secret across multiple parties
 */
export interface SharedSecret {
  secretId: string;
  totalShares: number;
  threshold: number; // Minimum shares to reconstruct
  shares: SecretShare[];
  field: bigint; // Prime field
  createdAt: number;
}

/**
 * SMPC computation session
 */
export interface SMPCSession {
  sessionId: string;
  parties: SMPCParty[];
  threshold: number;
  field: bigint;
  status: 'setup' | 'sharing' | 'computing' | 'result' | 'error';
  operations: SMPCOperation[];
  result?: unknown;
  auditLog: Array<{ timestamp: number; action: string; partyId: string }>;
}

/**
 * Operation in SMPC computation
 */
export interface SMPCOperation {
  id: string;
  type: 'add' | 'multiply' | 'compare' | 'select' | 'reveal';
  operands: string[]; // Share IDs
  result?: string;
  status: 'pending' | 'computed' | 'revealed';
}

/**
 * Garbled circuit gate
 */
export interface GarbledGate {
  gateId: number;
  type: 'AND' | 'OR' | 'XOR' | 'NOT';
  inputWires: number[];
  outputWire: number;
  table: string[][]; // Encrypted truth table
}

/**
 * Garbled circuit
 */
export interface GarbledCircuit {
  circuitId: string;
  inputWires: number;
  outputWires: number;
  gates: GarbledGate[];
  wireLabels: Map<number, [string, string]>; // 0 and 1 labels for each wire
}

/**
 * Oblivious transfer message
 */
export interface ObliviousTransfer {
  transferId: string;
  senderId: string;
  receiverId: string;
  messages: [string, string]; // Two encrypted messages
  receiverChoice?: 0 | 1; // Unknown to sender
}

/**
 * Detection result from SMPC
 */
export interface SMPCDetectionResult {
  /** Aggregated confidence without revealing individual inputs */
  confidence: number;
  /** Verdict from multi-party computation */
  verdict: 'authentic' | 'deepfake' | 'uncertain';
  /** Number of parties that participated */
  partiesParticipated: number;
  /** Privacy guarantee */
  privacyPreserved: boolean;
  /** Consensus level */
  consensusLevel: number; // 0-1
  /** Audit trail */
  auditHash: string;
}

// ============================================================================
// SHAMIR SECRET SHARING
// ============================================================================

/**
 * Generate a random polynomial coefficient
 */
function randomCoefficient(field: bigint): bigint {
  const bytes = randomBytes(32);
  let result = BigInt(0);
  for (let i = 0; i < 32; i++) {
    result = (result << BigInt(8)) | BigInt(bytes[i]);
  }
  return result % field;
}

/**
 * Evaluate polynomial at point x
 */
function evaluatePolynomial(
  coefficients: bigint[],
  x: bigint,
  field: bigint
): bigint {
  let result = BigInt(0);
  for (let i = coefficients.length - 1; i >= 0; i--) {
    result = (result * x + coefficients[i]) % field;
  }
  return result;
}

/**
 * Create Shamir secret shares
 *
 * Splits a secret into n shares where any k shares can reconstruct
 */
export function createShamirShares(
  secret: bigint,
  n: number,
  k: number,
  field: bigint = BigInt('21888242871839275222246405745257275088548364400416034343698204186575808495617') // Alt-BN128 curve order
): SharedSecret {
  // Create random polynomial with secret as constant term
  const coefficients: bigint[] = [secret];
  for (let i = 1; i < k; i++) {
    coefficients.push(randomCoefficient(field));
  }

  // Generate shares at points 1, 2, ..., n
  const shares: SecretShare[] = [];
  const secretId = `secret_${Date.now()}_${randomBytes(4).toString('hex')}`;

  for (let i = 1; i <= n; i++) {
    const x = BigInt(i);
    const y = evaluatePolynomial(coefficients, x, field);

    // Create commitment
    const commitment = createHash('sha256')
      .update(secretId)
      .update(String(i))
      .update(y.toString())
      .digest('hex');

    shares.push({
      partyId: `party_${i}`,
      shareIndex: i,
      value: y,
      commitment
    });
  }

  return {
    secretId,
    totalShares: n,
    threshold: k,
    shares,
    field,
    createdAt: Date.now()
  };
}

/**
 * Reconstruct secret from shares using Lagrange interpolation
 */
export function reconstructSecret(
  shares: SecretShare[],
  field: bigint
): bigint {
  if (shares.length < 2) {
    throw new Error('Need at least 2 shares to reconstruct');
  }

  let secret = BigInt(0);

  for (let i = 0; i < shares.length; i++) {
    // Lagrange basis polynomial
    let numerator = BigInt(1);
    let denominator = BigInt(1);

    const xi = BigInt(shares[i].shareIndex);

    for (let j = 0; j < shares.length; j++) {
      if (i !== j) {
        const xj = BigInt(shares[j].shareIndex);
        numerator = (numerator * (-xj + field)) % field;
        denominator = (denominator * (xi - xj + field)) % field;
      }
    }

    // Compute modular inverse of denominator
    const invDenominator = modInverse(denominator, field);
    const basis = (numerator * invDenominator) % field;

    secret = (secret + shares[i].value * basis) % field;
  }

  return secret;
}

/**
 * Extended Euclidean Algorithm for modular inverse
 */
function modInverse(a: bigint, m: bigint): bigint {
  let [oldR, r] = [a, m];
  let [oldS, s] = [BigInt(1), BigInt(0)];

  while (r !== BigInt(0)) {
    const quotient = oldR / r;
    [oldR, r] = [r, oldR - quotient * r];
    [oldS, s] = [s, oldS - quotient * s];
  }

  return ((oldS % m) + m) % m;
}

// ============================================================================
// SECURE MULTI-PARTY OPERATIONS
// ============================================================================

/**
 * Add two shared secrets locally (no communication needed)
 */
export function addSharedSecrets(
  share1: SecretShare,
  share2: SecretShare,
  field: bigint
): SecretShare {
  return {
    partyId: share1.partyId,
    shareIndex: share1.shareIndex,
    value: (share1.value + share2.value) % field,
    commitment: createHash('sha256')
      .update('add')
      .update(share1.commitment)
      .update(share2.commitment)
      .digest('hex')
  };
}

/**
 * Multiply shared secrets (requires interaction)
 *
 * Using Beaver triples for secure multiplication
 */
export function multiplySharedSecrets(
  share1: SecretShare,
  share2: SecretShare,
  beaverTriple: { a: SecretShare; b: SecretShare; c: SecretShare },
  field: bigint
): { result: SecretShare; openings: { d: bigint; e: bigint } } {
  // Compute d = x - a and e = y - b (opened)
  const d = (share1.value - beaverTriple.a.value + field) % field;
  const e = (share2.value - beaverTriple.b.value + field) % field;

  // z = c + d*b + e*a + d*e
  const result = (
    beaverTriple.c.value +
    d * beaverTriple.b.value +
    e * beaverTriple.a.value +
    d * e
  ) % field;

  return {
    result: {
      partyId: share1.partyId,
      shareIndex: share1.shareIndex,
      value: result,
      commitment: createHash('sha256')
        .update('multiply')
        .update(share1.commitment)
        .update(share2.commitment)
        .digest('hex')
    },
    openings: { d, e }
  };
}

/**
 * Generate Beaver triple for multiplication
 */
export function generateBeaverTriple(
  n: number,
  k: number,
  field: bigint
): { a: SharedSecret; b: SharedSecret; c: SharedSecret } {
  // Generate random a, b
  const aValue = randomCoefficient(field);
  const bValue = randomCoefficient(field);
  const cValue = (aValue * bValue) % field;

  return {
    a: createShamirShares(aValue, n, k, field),
    b: createShamirShares(bValue, n, k, field),
    c: createShamirShares(cValue, n, k, field)
  };
}

// ============================================================================
// GARBLED CIRCUITS
// ============================================================================

/**
 * Create wire labels for garbled circuit
 */
function createWireLabel(): [string, string] {
  const label0 = randomBytes(16).toString('hex');
  const label1 = randomBytes(16).toString('hex');
  return [label0, label1];
}

/**
 * Hash function for garbling
 */
function garbleHash(labels: string[], gateType: string): string {
  return createHash('sha256')
    .update(labels.join(''))
    .update(gateType)
    .digest('hex')
    .slice(0, 32);
}

/**
 * Create a garbled gate
 */
export function createGarbledGate(
  type: 'AND' | 'OR' | 'XOR' | 'NOT',
  inputWires: number[],
  outputWire: number,
  wireLabels: Map<number, [string, string]>
): GarbledGate {
  const table: string[][] = [];

  if (type === 'NOT') {
    // NOT gate: single input
    const [in0, in1] = wireLabels.get(inputWires[0])!;
    const [out0, out1] = wireLabels.get(outputWire)!;

    table.push([
      garbleHash([in0], 'NOT') + ':' + out1, // NOT 0 = 1
    ]);
    table.push([
      garbleHash([in1], 'NOT') + ':' + out0, // NOT 1 = 0
    ]);
  } else {
    // Binary gates
    const [a0, a1] = wireLabels.get(inputWires[0])!;
    const [b0, b1] = wireLabels.get(inputWires[1])!;
    const [c0, c1] = wireLabels.get(outputWire)!;

    const truthTable = getTruthTable(type);

    for (const [a, b, c] of truthTable) {
      const labelA = a === 0 ? a0 : a1;
      const labelB = b === 0 ? b0 : b1;
      const labelC = c === 0 ? c0 : c1;

      table.push([
        garbleHash([labelA, labelB], type) + ':' + labelC
      ]);
    }
  }

  return {
    gateId: outputWire,
    type,
    inputWires,
    outputWire,
    table
  };
}

/**
 * Get truth table for gate type
 */
function getTruthTable(type: 'AND' | 'OR' | 'XOR'): [number, number, number][] {
  switch (type) {
    case 'AND':
      return [[0, 0, 0], [0, 1, 0], [1, 0, 0], [1, 1, 1]];
    case 'OR':
      return [[0, 0, 0], [0, 1, 1], [1, 0, 1], [1, 1, 1]];
    case 'XOR':
      return [[0, 0, 0], [0, 1, 1], [1, 0, 1], [1, 1, 0]];
  }
}

/**
 * Create comparison circuit for secure comparison
 */
export function createComparisonCircuit(
  bitWidth: number
): GarbledCircuit {
  const circuitId = `compare_${Date.now()}`;
  const wireLabels = new Map<number, [string, string]>();

  // Create wire labels for all inputs and intermediate wires
  let wireCount = 0;

  // Input wires for two numbers (bitWidth each)
  for (let i = 0; i < 2 * bitWidth; i++) {
    wireLabels.set(wireCount++, createWireLabel());
  }

  // Build comparison circuit using XOR and AND gates
  const gates: GarbledGate[] = [];

  // XOR gates for bit comparison
  for (let i = 0; i < bitWidth; i++) {
    wireLabels.set(wireCount, createWireLabel());
    gates.push(createGarbledGate('XOR', [i, bitWidth + i], wireCount, wireLabels));
    wireCount++;
  }

  // AND gates for equality check
  for (let i = 0; i < bitWidth - 1; i++) {
    wireLabels.set(wireCount, createWireLabel());
    gates.push(createGarbledGate('AND', [wireCount - 1, wireCount - 2], wireCount, wireLabels));
    wireCount++;
  }

  return {
    circuitId,
    inputWires: 2 * bitWidth,
    outputWires: 1,
    gates,
    wireLabels
  };
}

// ============================================================================
// OBLIVIOUS TRANSFER
// ============================================================================

/**
 * Create 1-out-of-2 oblivious transfer
 *
 * Sender has two messages, receiver chooses one
 * Sender doesn't know which was chosen, receiver doesn't know the other
 */
export function createObliviousTransfer(
  senderId: string,
  receiverId: string,
  message0: string,
  message1: string
): ObliviousTransfer {
  // Simple OT simulation (in practice, use RSA or elliptic curve OT)
  const k = randomBytes(16).toString('hex');
  const k0 = createHash('sha256').update(k).update('0').digest('hex');
  const k1 = createHash('sha256').update(k).update('1').digest('hex');

  // Encrypt both messages
  const encrypted0 = xorStrings(message0, k0);
  const encrypted1 = xorStrings(message1, k1);

  return {
    transferId: `ot_${Date.now()}_${randomBytes(4).toString('hex')}`,
    senderId,
    receiverId,
    messages: [encrypted0, encrypted1]
  };
}

/**
 * Complete oblivious transfer as receiver
 */
export function completeObliviousTransfer(
  ot: ObliviousTransfer,
  choice: 0 | 1,
  key: string
): string {
  const k = createHash('sha256').update(key).update(String(choice)).digest('hex');
  return xorStrings(ot.messages[choice], k);
}

/**
 * XOR two hex strings
 */
function xorStrings(a: string, b: string): string {
  const result: string[] = [];
  for (let i = 0; i < Math.min(a.length, b.length); i++) {
    result.push((parseInt(a[i], 16) ^ parseInt(b[i], 16)).toString(16));
  }
  return result.join('');
}

// ============================================================================
// SMPC DETECTION PROTOCOL
// ============================================================================

/**
 * Create SMPC session for collaborative detection
 */
export function createSMPCSession(
  parties: SMPCParty[],
  threshold: number = Math.ceil(parties.length * 0.6)
): SMPCSession {
  return {
    sessionId: `session_${Date.now()}_${randomBytes(8).toString('hex')}`,
    parties,
    threshold,
    field: BigInt('21888242871839275222246405745257275088548364400416034343698204186575808495617'),
    status: 'setup',
    operations: [],
    auditLog: [{
      timestamp: Date.now(),
      action: 'session_created',
      partyId: 'system'
    }]
  };
}

/**
 * Share detection confidence among parties
 */
export function shareDetectionConfidence(
  session: SMPCSession,
  partyId: string,
  confidence: number
): SharedSecret {
  // Convert confidence to integer (0-100)
  const confidenceInt = BigInt(Math.round(confidence * 100));

  // Create shares
  const shares = createShamirShares(
    confidenceInt,
    session.parties.length,
    session.threshold,
    session.field
  );

  session.auditLog.push({
    timestamp: Date.now(),
    action: 'confidence_shared',
    partyId
  });

  return shares;
}

/**
 * Compute aggregate confidence securely
 */
export function computeAggregateConfidence(
  session: SMPCSession,
  shares: Map<string, SharedSecret[]>
): { sum: bigint; count: number } {
  // Each party locally adds their shares
  const aggregatedShares: SecretShare[] = [];

  // Get shares from each party
  const shareArrays = Array.from(shares.values());

  if (shareArrays.length === 0) {
    return { sum: BigInt(0), count: 0 };
  }

  // Use the first party's shares structure to determine iteration
  const firstPartyShares = shareArrays[0];
  if (!firstPartyShares || firstPartyShares.length === 0) {
    return { sum: BigInt(0), count: shares.size };
  }

  const numShares = firstPartyShares[0]?.totalShares || session.parties.length;

  // For each share position, sum across all parties
  for (let i = 0; i < numShares; i++) {
    let sum = BigInt(0);

    for (const partyShares of shareArrays) {
      // Get the first SharedSecret from this party
      const sharedSecret = partyShares[0];
      if (sharedSecret && sharedSecret.shares && sharedSecret.shares[i]) {
        const shareValue = sharedSecret.shares[i].value;
        if (typeof shareValue === 'bigint') {
          sum = (sum + shareValue) % session.field;
        }
      }
    }

    aggregatedShares.push({
      partyId: `aggregated_${i + 1}`,
      shareIndex: i + 1,
      value: sum,
      commitment: createHash('sha256')
        .update(String(i))
        .update(sum.toString())
        .digest('hex')
    });
  }

  session.status = 'computing';
  session.auditLog.push({
    timestamp: Date.now(),
    action: 'aggregate_computed',
    partyId: 'aggregator'
  });

  return {
    sum: reconstructSecret(aggregatedShares.slice(0, session.threshold), session.field),
    count: shares.size
  };
}

/**
 * Perform full SMPC detection
 */
export function smpcDetection(
  parties: SMPCParty[],
  confidences: Map<string, number>
): SMPCDetectionResult {
  // Create session
  const session = createSMPCSession(parties);

  // Each party shares their confidence
  const allShares = new Map<string, SharedSecret>();

  for (const [partyId, confidence] of confidences) {
    const shares = shareDetectionConfidence(session, partyId, confidence);
    allShares.set(partyId, [shares]);
  }

  // Compute aggregate
  const { sum, count } = computeAggregateConfidence(session, allShares);

  // Average confidence (sum / count * 100 to get back to 0-1)
  const avgConfidence = Number(sum) / (count * 100);

  // Determine verdict
  let verdict: 'authentic' | 'deepfake' | 'uncertain';
  if (avgConfidence > 0.7) {
    verdict = 'deepfake';
  } else if (avgConfidence < 0.3) {
    verdict = 'authentic';
  } else {
    verdict = 'uncertain';
  }

  // Calculate consensus
  const confidenceValues = Array.from(confidences.values());
  const consensusLevel = calculateConsensus(confidenceValues);

  // Create audit hash
  const auditHash = createHash('sha256')
    .update(session.sessionId)
    .update(String(avgConfidence))
    .update(verdict)
    .update(String(parties.length))
    .digest('hex');

  return {
    confidence: avgConfidence,
    verdict,
    partiesParticipated: count,
    privacyPreserved: true,
    consensusLevel,
    auditHash
  };
}

/**
 * Calculate consensus level (agreement between parties)
 */
function calculateConsensus(values: number[]): number {
  if (values.length === 0) return 0;

  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  const variance = values.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / values.length;
  const stdDev = Math.sqrt(variance);

  // Convert to consensus (lower variance = higher consensus)
  // Max variance for 0-1 range is 0.25
  const normalizedVariance = variance / 0.25;
  return Math.max(0, 1 - normalizedVariance);
}

// ============================================================================
// VERIFIABLE SECRET SHARING
// ============================================================================

/**
 * Feldman's Verifiable Secret Sharing commitment
 */
export interface FeldmanCommitment {
  secretId: string;
  commitments: string[]; // g^a_i mod p
  generator: bigint;
  prime: bigint;
}

/**
 * Create Feldman commitments for verification
 */
export function createFeldmanCommitments(
  coefficients: bigint[],
  generator: bigint = BigInt(2),
  prime: bigint = BigInt('21888242871839275222246405745257275088548364400416034343698204186575808495617')
): FeldmanCommitment {
  const commitments = coefficients.map(a => {
    // g^a mod p
    const comm = modPow(generator, a, prime);
    return comm.toString(16);
  });

  return {
    secretId: `feldman_${Date.now()}`,
    commitments,
    generator,
    prime
  };
}

/**
 * Verify a share against Feldman commitments
 */
export function verifyFeldmanShare(
  share: SecretShare,
  commitments: FeldmanCommitment
): boolean {
  // Verify: g^share = product(commitments[i]^(shareIndex^i)) mod p
  let product = BigInt(1);
  const x = BigInt(share.shareIndex);

  for (let i = 0; i < commitments.commitments.length; i++) {
    const c = BigInt('0x' + commitments.commitments[i]);
    const exponent = modPow(x, BigInt(i), commitments.prime);
    product = (product * modPow(c, exponent, commitments.prime)) % commitments.prime;
  }

  const expected = modPow(commitments.generator, share.value, commitments.prime);
  return product === expected;
}

/**
 * Modular exponentiation
 */
function modPow(base: bigint, exponent: bigint, modulus: bigint): bigint {
  let result = BigInt(1);
  base = base % modulus;

  while (exponent > BigInt(0)) {
    if (exponent % BigInt(2) === BigInt(1)) {
      result = (result * base) % modulus;
    }
    exponent = exponent / BigInt(2);
    base = (base * base) % modulus;
  }

  return result;
}

// ============================================================================
// TESTING
// ============================================================================

/**
 * Run SMPC tests
 */
export function runSMPCTests(): {
  passed: boolean;
  tests: Array<{ name: string; passed: boolean; message: string }>;
  summary: { total: number; passed: number; failed: number };
} {
  const tests: Array<{ name: string; passed: boolean; message: string }> = [];

  // Test 1: Shamir secret sharing - creation
  const secret = BigInt(42);
  const shared = createShamirShares(secret, 5, 3);
  tests.push({
    name: 'Shamir share creation',
    passed: shared.shares.length === 5 && shared.threshold === 3,
    message: `Created ${shared.shares.length} shares with threshold ${shared.threshold}`
  });

  // Test 2: Shamir secret sharing - reconstruction
  const reconstructed = reconstructSecret(
    [shared.shares[0], shared.shares[2], shared.shares[4]],
    shared.field
  );
  tests.push({
    name: 'Shamir secret reconstruction',
    passed: reconstructed === secret,
    message: `Reconstructed: ${reconstructed}, original: ${secret}`
  });

  // Test 3: Threshold not met
  try {
    reconstructSecret([shared.shares[0]], shared.field);
    tests.push({
      name: 'Threshold enforcement',
      passed: false,
      message: 'Should have thrown error for insufficient shares'
    });
  } catch {
    tests.push({
      name: 'Threshold enforcement',
      passed: true,
      message: 'Correctly rejected insufficient shares'
    });
  }

  // Test 4: Addition of shared secrets
  const shared1 = createShamirShares(BigInt(10), 3, 2);
  const shared2 = createShamirShares(BigInt(20), 3, 2);
  const addedShares = [
    addSharedSecrets(shared1.shares[0], shared2.shares[0], shared1.field),
    addSharedSecrets(shared1.shares[1], shared2.shares[1], shared1.field)
  ];
  const sum = reconstructSecret(addedShares, shared1.field);
  tests.push({
    name: 'Addition of shared secrets',
    passed: sum === BigInt(30),
    message: `Sum: ${sum}, expected: 30`
  });

  // Test 5: Beaver triple generation
  const triple = generateBeaverTriple(3, 2, shared1.field);
  tests.push({
    name: 'Beaver triple generation',
    passed: triple.a.shares.length === 3 &&
            triple.b.shares.length === 3 &&
            triple.c.shares.length === 3,
    message: `Generated triple with ${triple.a.shares.length} shares each`
  });

  // Test 6: Garbled circuit creation
  const circuit = createComparisonCircuit(8);
  tests.push({
    name: 'Comparison circuit creation',
    passed: circuit.gates.length > 0 && circuit.inputWires === 16,
    message: `Circuit has ${circuit.gates.length} gates, ${circuit.inputWires} input wires`
  });

  // Test 7: Oblivious transfer
  const ot = createObliviousTransfer('alice', 'bob', 'message0', 'message1');
  tests.push({
    name: 'Oblivious transfer creation',
    passed: ot.messages.length === 2 && ot.senderId === 'alice',
    message: `OT created with ${ot.messages.length} messages`
  });

  // Test 8: SMPC session creation
  const parties: SMPCParty[] = [
    { id: 'p1', name: 'Party 1', role: 'analyst', publicKey: 'pk1', isOnline: true, trustLevel: 0.9 },
    { id: 'p2', name: 'Party 2', role: 'verifier', publicKey: 'pk2', isOnline: true, trustLevel: 0.85 },
    { id: 'p3', name: 'Party 3', role: 'aggregator', publicKey: 'pk3', isOnline: true, trustLevel: 0.95 }
  ];
  const session = createSMPCSession(parties);
  tests.push({
    name: 'SMPC session creation',
    passed: session.parties.length === 3 && session.status === 'setup',
    message: `Session created with ${session.parties.length} parties`
  });

  // Test 9: Full SMPC detection
  const confidences = new Map<string, number>();
  confidences.set('p1', 0.85);
  confidences.set('p2', 0.82);
  confidences.set('p3', 0.88);
  const result = smpcDetection(parties, confidences);
  tests.push({
    name: 'SMPC detection',
    passed: result.privacyPreserved && result.verdict === 'deepfake',
    message: `Verdict: ${result.verdict}, confidence: ${result.confidence.toFixed(2)}, consensus: ${result.consensusLevel.toFixed(2)}`
  });

  // Test 10: Feldman VSS
  const feldman = createFeldmanCommitments([BigInt(42), BigInt(17), BigInt(3)]);
  const validShare: SecretShare = {
    partyId: 'p1',
    shareIndex: 1,
    value: BigInt(42) + BigInt(17) + BigInt(3), // f(1) = 42 + 17 + 3
    commitment: ''
  };
  tests.push({
    name: 'Feldman commitments',
    passed: feldman.commitments.length === 3,
    message: `Created ${feldman.commitments.length} Feldman commitments`
  });

  // Test 11: Consensus calculation
  const highConsensus = calculateConsensus([0.85, 0.86, 0.84, 0.85]);
  const lowConsensus = calculateConsensus([0.2, 0.8, 0.5, 0.9]);
  tests.push({
    name: 'Consensus calculation',
    passed: highConsensus > lowConsensus,
    message: `High consensus: ${highConsensus.toFixed(2)}, low: ${lowConsensus.toFixed(2)}`
  });

  // Test 12: Audit trail
  tests.push({
    name: 'Audit trail',
    passed: session.auditLog.length > 0,
    message: `Session has ${session.auditLog.length} audit entries`
  });

  const passed = tests.filter(t => t.passed).length;
  const failed = tests.filter(t => !t.passed).length;

  return {
    passed: failed === 0,
    tests,
    summary: { total: tests.length, passed, failed }
  };
}

// Export all
export default {
  // Shamir Secret Sharing
  createShamirShares,
  reconstructSecret,

  // Operations
  addSharedSecrets,
  multiplySharedSecrets,
  generateBeaverTriple,

  // Garbled Circuits
  createGarbledGate,
  createComparisonCircuit,

  // Oblivious Transfer
  createObliviousTransfer,
  completeObliviousTransfer,

  // SMPC Detection
  createSMPCSession,
  shareDetectionConfidence,
  computeAggregateConfidence,
  smpcDetection,

  // Verifiable Secret Sharing
  createFeldmanCommitments,
  verifyFeldmanShare,

  // Tests
  runSMPCTests
};
