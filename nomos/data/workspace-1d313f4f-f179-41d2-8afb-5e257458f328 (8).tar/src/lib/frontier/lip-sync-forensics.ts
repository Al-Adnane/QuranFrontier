/**
 * Lip Sync Forensics Module
 *
 * Detects lip-sync deepfakes by analyzing:
 * - Phoneme-Viseme synchronization
 * - Audio-visual coherence
 * - Articulation dynamics
 * - Mouth shape consistency
 * - Temporal alignment accuracy
 *
 * @module frontier/lip-sync-forensics
 * @version 4.1.0
 */

// ============================================================================
// TYPES AND INTERFACES
// ============================================================================

export interface Phoneme {
  /** Phoneme symbol (IPA or ARPABET) */
  symbol: string;
  /** Start time in ms */
  startTime: number;
  /** End time in ms */
  endTime: number;
  /** Duration in ms */
  duration: number;
  /** Confidence of detection */
  confidence: number;
  /** Audio features */
  audioFeatures: AudioFeatures;
}

export interface Viseme {
  /** Viseme type */
  type: VisemeType;
  /** Start time in ms */
  startTime: number;
  /** End time in ms */
  endTime: number;
  /** Intensity */
  intensity: number;
  /** Mouth shape parameters */
  mouthShape: MouthShape;
  /** Confidence of detection */
  confidence: number;
}

export type VisemeType =
  | 'A'     // Open mouth (ah, aa)
  | 'B'     // Bilabial (b, p, m)
  | 'C'     // Alveolar (ch, sh, jh, zh)
  | 'D'     // Alveolar (d, t, n, l)
  | 'E'     // Front vowel (eh, ae)
  | 'F'     // Labiodental (f, v)
  | 'G'     // Velar (g, k, ng)
  | 'H'     // Glottal (h)
  | 'I'     // Front vowel (ih, iy)
  | 'J'     // Palatal (y)
  | 'K'     // Velar
  | 'L'     // Lateral
  | 'M'     // Bilabial nasal
  | 'N'     // Alveolar nasal
  | 'O'     // Rounded vowel (ow, ao)
  | 'P'     // Bilabial plosive
  | 'Q'     // Glottal stop
  | 'R'     // Rhotic
  | 'S'     // Sibilant
  | 'T'     // Dental
  | 'U'     // Rounded vowel (uw, uh)
  | 'V'     // Labiodental
  | 'W'     // Labiovelar
  | 'X'     // Rest/Neutral
  | 'Y'     // Front rounded
  | 'Z'     // Alveolar fricative
  | 'SILENCE';

export interface MouthShape {
  /** Mouth width (normalized) */
  width: number;
  /** Mouth height (normalized) */
  height: number;
  /** Upper lip protrusion */
  upperLipProtrusion: number;
  /** Lower lip protrusion */
  lowerLipProtrusion: number;
  /** Jaw openness */
  jawOpen: number;
  /** Lip rounding */
  lipRounding: number;
  /** Teeth visible */
  teethVisible: boolean;
  /** Tongue visible */
  tongueVisible: boolean;
}

export interface AudioFeatures {
  /** Fundamental frequency */
  f0: number;
  /** Mel-frequency cepstral coefficients */
  mfcc: number[];
  /** Zero crossing rate */
  zcr: number;
  /** Energy */
  energy: number;
  /** Spectral centroid */
  spectralCentroid: number;
  /** Spectral rolloff */
  spectralRolloff: number;
}

export interface LipSyncAnalysisResult {
  /** Analysis ID */
  id: string;
  /** Timestamp */
  timestamp: number;
  /** Deepfake probability */
  deepfakeProbability: number;
  /** Overall sync score (0-1) */
  syncScore: number;
  /** Detected phonemes from audio */
  phonemes: Phoneme[];
  /** Detected visemes from video */
  visemes: Viseme[];
  /** Synchronization errors */
  syncErrors: SyncError[];
  /** Audio-visual coherence score */
  coherenceScore: number;
  /** Temporal alignment accuracy */
  temporalAccuracy: number;
  /** Anomalies detected */
  anomalies: LipSyncAnomaly[];
  /** Recommendations */
  recommendations: string[];
}

export interface SyncError {
  /** Error type */
  type: 'timing' | 'shape' | 'missing' | 'extra' | 'mismatch';
  /** Timestamp in ms */
  timestamp: number;
  /** Duration in ms */
  duration: number;
  /** Severity (0-1) */
  severity: number;
  /** Description */
  description: string;
  /** Expected viseme */
  expectedViseme?: VisemeType;
  /** Actual viseme */
  actualViseme?: VisemeType;
  /** Timing offset in ms */
  timingOffset?: number;
}

export interface LipSyncAnomaly {
  /** Anomaly type */
  type: 'lip_jitter' | 'unnatural_motion' | 'shape_inconsistency' | 'timing_drift' | 'phoneme_mismatch';
  /** Timestamp range */
  timeRange: { start: number; end: number };
  /** Severity (0-1) */
  severity: number;
  /** Confidence */
  confidence: number;
  /** Description */
  description: string;
}

export interface LipLandmarks {
  /** Upper lip center */
  upperLipCenter: { x: number; y: number };
  /** Lower lip center */
  lowerLipCenter: { x: number; y: number };
  /** Left mouth corner */
  leftCorner: { x: number; y: number };
  /** Right mouth corner */
  rightCorner: { x: number; y: number };
  /** Upper lip points */
  upperLipPoints: Array<{ x: number; y: number }>;
  /** Lower lip points */
  lowerLipPoints: Array<{ x: number; y: number }>;
  /** Timestamp */
  timestamp: number;
}

// ============================================================================
// PHONEME-VISEME MAPPING
// ============================================================================

/**
 * Mapping from ARPABET phonemes to visemes
 * Based on the Preston Blair viseme set
 */
const PHONEME_TO_VISEME: Record<string, VisemeType> = {
  // Vowels
  'AA': 'A',   // father
  'AE': 'E',   // cat
  'AH': 'A',   // but
  'AO': 'O',   // caught
  'AW': 'O',   // how
  'AY': 'A',   // hide
  'EH': 'E',   // bed
  'ER': 'R',   // bird
  'EY': 'E',   // say
  'IH': 'I',   // bit
  'IY': 'I',   // see
  'OW': 'O',   // go
  'OY': 'O',   // boy
  'UH': 'U',   // book
  'UW': 'U',   // boot

  // Consonants
  'B': 'B',
  'CH': 'C',
  'D': 'D',
  'DH': 'T',   // this
  'F': 'F',
  'G': 'G',
  'HH': 'H',
  'JH': 'C',   // judge
  'K': 'G',
  'L': 'L',
  'M': 'M',
  'N': 'N',
  'NG': 'G',   // sing
  'P': 'B',
  'R': 'R',
  'S': 'S',
  'SH': 'C',
  'T': 'D',
  'TH': 'T',   // think
  'V': 'F',
  'W': 'W',
  'Y': 'J',
  'Z': 'S',
  'ZH': 'C',   // measure

  // Silence
  'SIL': 'SILENCE',
  'SP': 'SILENCE',
  'SPN': 'SILENCE'
};

/**
 * Viseme shape parameters
 */
const VISEME_SHAPES: Record<VisemeType, Partial<MouthShape>> = {
  'A': { width: 0.7, height: 0.6, jawOpen: 0.6, lipRounding: 0.2 },
  'B': { width: 0.3, height: 0.0, jawOpen: 0.1, lipRounding: 0.0 },
  'C': { width: 0.5, height: 0.3, jawOpen: 0.3, lipRounding: 0.5 },
  'D': { width: 0.4, height: 0.3, jawOpen: 0.3, lipRounding: 0.1 },
  'E': { width: 0.6, height: 0.3, jawOpen: 0.3, lipRounding: 0.1 },
  'F': { width: 0.4, height: 0.1, jawOpen: 0.2, lipRounding: 0.0 },
  'G': { width: 0.4, height: 0.4, jawOpen: 0.4, lipRounding: 0.1 },
  'H': { width: 0.5, height: 0.4, jawOpen: 0.4, lipRounding: 0.1 },
  'I': { width: 0.5, height: 0.2, jawOpen: 0.2, lipRounding: 0.0 },
  'J': { width: 0.5, height: 0.3, jawOpen: 0.3, lipRounding: 0.2 },
  'K': { width: 0.4, height: 0.4, jawOpen: 0.4, lipRounding: 0.1 },
  'L': { width: 0.4, height: 0.3, jawOpen: 0.3, lipRounding: 0.0, teethVisible: true, tongueVisible: true },
  'M': { width: 0.3, height: 0.0, jawOpen: 0.0, lipRounding: 0.0 },
  'N': { width: 0.4, height: 0.2, jawOpen: 0.2, lipRounding: 0.0 },
  'O': { width: 0.3, height: 0.5, jawOpen: 0.5, lipRounding: 0.8 },
  'P': { width: 0.3, height: 0.0, jawOpen: 0.1, lipRounding: 0.0 },
  'Q': { width: 0.3, height: 0.1, jawOpen: 0.1, lipRounding: 0.0 },
  'R': { width: 0.4, height: 0.3, jawOpen: 0.3, lipRounding: 0.6, upperLipProtrusion: 0.3 },
  'S': { width: 0.5, height: 0.1, jawOpen: 0.2, lipRounding: 0.0, teethVisible: true },
  'T': { width: 0.4, height: 0.15, jawOpen: 0.2, lipRounding: 0.0, teethVisible: true, tongueVisible: true },
  'U': { width: 0.2, height: 0.4, jawOpen: 0.4, lipRounding: 0.9 },
  'V': { width: 0.4, height: 0.1, jawOpen: 0.2, lipRounding: 0.0, teethVisible: true },
  'W': { width: 0.2, height: 0.4, jawOpen: 0.4, lipRounding: 0.9 },
  'X': { width: 0.4, height: 0.1, jawOpen: 0.1, lipRounding: 0.0 },
  'Y': { width: 0.4, height: 0.2, jawOpen: 0.2, lipRounding: 0.3 },
  'Z': { width: 0.5, height: 0.1, jawOpen: 0.2, lipRounding: 0.0, teethVisible: true },
  'SILENCE': { width: 0.3, height: 0.05, jawOpen: 0.05, lipRounding: 0.0 }
};

// ============================================================================
// LIP SYNC ANALYZER
// ============================================================================

/**
 * Lip Sync Forensics Analyzer
 * Detects lip-sync deepfakes through audio-visual synchronization analysis
 */
export class LipSyncAnalyzer {
  private config: LipSyncConfig;
  private frameBuffer: Array<{ landmarks: LipLandmarks; timestamp: number }> = [];
  private audioBuffer: Array<{ features: AudioFeatures; timestamp: number }> = [];

  constructor(config: Partial<LipSyncConfig> = {}) {
    this.config = {
      timingThreshold: config.timingThreshold || 50, // ms
      shapeSimilarityThreshold: config.shapeSimilarityThreshold || 0.7,
      minPhonemeDuration: config.minPhonemeDuration || 30, // ms
      windowSize: config.windowSize || 1000, // ms
      sampleRate: config.sampleRate || 16000, // Hz
      ...config
    };
  }

  /**
   * Analyze lip sync from audio and video frames
   */
  analyze(
    audioFrames: Array<{ features: AudioFeatures; timestamp: number }>,
    videoFrames: Array<{ landmarks: LipLandmarks; timestamp: number }>
  ): LipSyncAnalysisResult {
    const id = `lipsync_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const startTime = Date.now();

    // Store buffers
    this.audioBuffer = audioFrames;
    this.frameBuffer = videoFrames;

    // Phase 1: Extract phonemes from audio
    const phonemes = this.extractPhonemes(audioFrames);

    // Phase 2: Extract visemes from video
    const visemes = this.extractVisemes(videoFrames);

    // Phase 3: Align phonemes and visemes
    const alignedPairs = this.alignPhonemesVisemes(phonemes, visemes);

    // Phase 4: Detect synchronization errors
    const syncErrors = this.detectSyncErrors(alignedPairs, phonemes, visemes);

    // Phase 5: Calculate coherence score
    const coherenceScore = this.calculateCoherenceScore(phonemes, visemes, alignedPairs);

    // Phase 6: Calculate temporal accuracy
    const temporalAccuracy = this.calculateTemporalAccuracy(alignedPairs);

    // Phase 7: Detect anomalies
    const anomalies = this.detectAnomalies(visemes, phonemes, syncErrors);

    // Calculate overall scores
    const syncScore = this.calculateSyncScore(syncErrors);
    const deepfakeProbability = this.calculateDeepfakeProbability(syncErrors, anomalies, coherenceScore);

    return {
      id,
      timestamp: startTime,
      deepfakeProbability,
      syncScore,
      phonemes,
      visemes,
      syncErrors,
      coherenceScore,
      temporalAccuracy,
      anomalies,
      recommendations: this.generateRecommendations(syncErrors, anomalies, deepfakeProbability)
    };
  }

  /**
   * Extract phonemes from audio features
   */
  private extractPhonemes(
    audioFrames: Array<{ features: AudioFeatures; timestamp: number }>
  ): Phoneme[] {
    if (audioFrames.length === 0) return [];

    const phonemes: Phoneme[] = [];

    // Group frames into segments based on acoustic changes
    const segments = this.segmentAudio(audioFrames);

    for (const segment of segments) {
      const symbol = this.classifyPhoneme(segment);
      const avgFeatures = this.averageFeatures(segment.frames);

      phonemes.push({
        symbol,
        startTime: segment.startTime,
        endTime: segment.endTime,
        duration: segment.endTime - segment.startTime,
        confidence: segment.confidence,
        audioFeatures: avgFeatures
      });
    }

    return phonemes;
  }

  /**
   * Segment audio into phoneme-like units
   */
  private segmentAudio(
    audioFrames: Array<{ features: AudioFeatures; timestamp: number }>
  ): Array<{
    frames: Array<{ features: AudioFeatures; timestamp: number }>;
    startTime: number;
    endTime: number;
    confidence: number;
  }> {
    const segments: Array<{
      frames: Array<{ features: AudioFeatures; timestamp: number }>;
      startTime: number;
      endTime: number;
      confidence: number;
    }> = [];

    if (audioFrames.length === 0) return segments;

    let currentSegment: Array<{ features: AudioFeatures; timestamp: number }> = [audioFrames[0]];
    let segmentStart = audioFrames[0].timestamp;

    for (let i = 1; i < audioFrames.length; i++) {
      const prev = audioFrames[i - 1];
      const curr = audioFrames[i];

      // Check for significant acoustic change
      const change = this.calculateFeatureChange(prev.features, curr.features);

      if (change > 0.3 || curr.timestamp - segmentStart > 200) {
        // End current segment
        if (currentSegment.length > 0) {
          segments.push({
            frames: currentSegment,
            startTime: segmentStart,
            endTime: prev.timestamp + (curr.timestamp - prev.timestamp),
            confidence: 1 - change
          });
        }

        // Start new segment
        currentSegment = [curr];
        segmentStart = curr.timestamp;
      } else {
        currentSegment.push(curr);
      }
    }

    // Add final segment
    if (currentSegment.length > 0) {
      segments.push({
        frames: currentSegment,
        startTime: segmentStart,
        endTime: audioFrames[audioFrames.length - 1].timestamp,
        confidence: 0.8
      });
    }

    return segments;
  }

  /**
   * Classify phoneme from audio features
   */
  private classifyPhoneme(segment: {
    frames: Array<{ features: AudioFeatures; timestamp: number }>;
  }): string {
    const avgFeatures = this.averageFeatures(segment.frames);

    // Energy-based classification
    if (avgFeatures.energy < 0.01) {
      return 'SIL';
    }

    // F0-based voicing detection
    const isVoiced = avgFeatures.f0 > 50;

    // MFCC-based vowel/consonant classification
    const mfccSum = avgFeatures.mfcc.slice(0, 5).reduce((a, b) => a + Math.abs(b), 0);

    // Simplified classification based on features
    if (avgFeatures.spectralCentroid > 3000 && avgFeatures.zcr > 0.3) {
      return isVoiced ? 'S' : 'S'; // Fricatives
    } else if (avgFeatures.energy > 0.5 && mfccSum < 2) {
      // Likely vowel - use shape to guess
      if (avgFeatures.spectralRolloff < 2000) {
        return 'UW'; // Back vowel
      } else if (avgFeatures.spectralRolloff > 3000) {
        return 'IY'; // Front vowel
      } else {
        return 'AH'; // Central vowel
      }
    } else if (avgFeatures.zcr < 0.1 && avgFeatures.energy < 0.3) {
      // Likely nasal or stop
      return isVoiced ? 'N' : 'T';
    } else if (avgFeatures.zcr > 0.2) {
      // Fricative
      return isVoiced ? 'Z' : 'S';
    } else {
      // Default to neutral
      return 'AH';
    }
  }

  /**
   * Calculate feature change between frames
   */
  private calculateFeatureChange(f1: AudioFeatures, f2: AudioFeatures): number {
    let change = 0;
    let count = 0;

    // Energy change
    change += Math.abs(f1.energy - f2.energy);
    count++;

    // F0 change
    if (f1.f0 > 0 && f2.f0 > 0) {
      change += Math.abs(f1.f0 - f2.f0) / 300;
      count++;
    }

    // MFCC change
    for (let i = 0; i < Math.min(f1.mfcc.length, f2.mfcc.length); i++) {
      change += Math.abs(f1.mfcc[i] - f2.mfcc[i]) / 10;
      count++;
    }

    // ZCR change
    change += Math.abs(f1.zcr - f2.zcr);
    count++;

    return change / count;
  }

  /**
   * Average audio features
   */
  private averageFeatures(frames: Array<{ features: AudioFeatures; timestamp: number }>): AudioFeatures {
    if (frames.length === 0) {
      return {
        f0: 0,
        mfcc: [],
        zcr: 0,
        energy: 0,
        spectralCentroid: 0,
        spectralRolloff: 0
      };
    }

    const sum = frames.reduce((acc, f) => ({
      f0: acc.f0 + f.features.f0,
      mfcc: acc.mfcc.map((v, i) => v + (f.features.mfcc[i] || 0)),
      zcr: acc.zcr + f.features.zcr,
      energy: acc.energy + f.features.energy,
      spectralCentroid: acc.spectralCentroid + f.features.spectralCentroid,
      spectralRolloff: acc.spectralRolloff + f.features.spectralRolloff
    }), {
      f0: 0,
      mfcc: Array(frames[0].features.mfcc.length).fill(0),
      zcr: 0,
      energy: 0,
      spectralCentroid: 0,
      spectralRolloff: 0
    });

    const n = frames.length;
    return {
      f0: sum.f0 / n,
      mfcc: sum.mfcc.map(v => v / n),
      zcr: sum.zcr / n,
      energy: sum.energy / n,
      spectralCentroid: sum.spectralCentroid / n,
      spectralRolloff: sum.spectralRolloff / n
    };
  }

  /**
   * Extract visemes from video frames
   */
  private extractVisemes(
    videoFrames: Array<{ landmarks: LipLandmarks; timestamp: number }>
  ): Viseme[] {
    if (videoFrames.length === 0) return [];

    const visemes: Viseme[] = [];

    // Group frames into viseme segments
    const segments = this.segmentVisually(videoFrames);

    for (const segment of segments) {
      const mouthShape = this.extractMouthShape(segment.frames);
      const visemeType = this.classifyViseme(mouthShape);

      visemes.push({
        type: visemeType,
        startTime: segment.startTime,
        endTime: segment.endTime,
        intensity: this.calculateVisemeIntensity(mouthShape),
        mouthShape,
        confidence: segment.confidence
      });
    }

    return visemes;
  }

  /**
   * Segment video frames based on mouth shape changes
   */
  private segmentVisually(
    videoFrames: Array<{ landmarks: LipLandmarks; timestamp: number }>
  ): Array<{
    frames: Array<{ landmarks: LipLandmarks; timestamp: number }>;
    startTime: number;
    endTime: number;
    confidence: number;
  }> {
    const segments: Array<{
      frames: Array<{ landmarks: LipLandmarks; timestamp: number }>;
      startTime: number;
      endTime: number;
      confidence: number;
    }> = [];

    if (videoFrames.length === 0) return segments;

    let currentSegment = [videoFrames[0]];
    let segmentStart = videoFrames[0].timestamp;

    for (let i = 1; i < videoFrames.length; i++) {
      const prev = videoFrames[i - 1];
      const curr = videoFrames[i];

      // Check for significant shape change
      const change = this.calculateShapeChange(prev.landmarks, curr.landmarks);

      if (change > 0.2 || curr.timestamp - segmentStart > 200) {
        if (currentSegment.length > 0) {
          segments.push({
            frames: currentSegment,
            startTime: segmentStart,
            endTime: prev.timestamp + (curr.timestamp - prev.timestamp),
            confidence: 1 - change
          });
        }

        currentSegment = [curr];
        segmentStart = curr.timestamp;
      } else {
        currentSegment.push(curr);
      }
    }

    if (currentSegment.length > 0) {
      segments.push({
        frames: currentSegment,
        startTime: segmentStart,
        endTime: videoFrames[videoFrames.length - 1].timestamp,
        confidence: 0.8
      });
    }

    return segments;
  }

  /**
   * Calculate shape change between frames
   */
  private calculateShapeChange(l1: LipLandmarks, l2: LipLandmarks): number {
    // Mouth opening change
    const height1 = Math.abs(l1.lowerLipCenter.y - l1.upperLipCenter.y);
    const height2 = Math.abs(l2.lowerLipCenter.y - l2.upperLipCenter.y);
    const heightChange = Math.abs(height1 - height2) / Math.max(height1, height2, 1);

    // Mouth width change
    const width1 = Math.abs(l1.rightCorner.x - l1.leftCorner.x);
    const width2 = Math.abs(l2.rightCorner.x - l2.leftCorner.x);
    const widthChange = Math.abs(width1 - width2) / Math.max(width1, width2, 1);

    return (heightChange + widthChange) / 2;
  }

  /**
   * Extract mouth shape from landmarks
   */
  private extractMouthShape(
    frames: Array<{ landmarks: LipLandmarks; timestamp: number }>
  ): MouthShape {
    if (frames.length === 0) {
      return {
        width: 0.3,
        height: 0.1,
        upperLipProtrusion: 0,
        lowerLipProtrusion: 0,
        jawOpen: 0.1,
        lipRounding: 0,
        teethVisible: false,
        tongueVisible: false
      };
    }

    // Average across frames
    let totalWidth = 0;
    let totalHeight = 0;

    for (const frame of frames) {
      const landmarks = frame.landmarks;

      const width = Math.abs(landmarks.rightCorner.x - landmarks.leftCorner.x);
      const height = Math.abs(landmarks.lowerLipCenter.y - landmarks.upperLipCenter.y);

      totalWidth += width;
      totalHeight += height;
    }

    // Normalize by face size (assuming face width ~200px)
    const faceWidth = 200;
    const normalizedWidth = (totalWidth / frames.length) / faceWidth;
    const normalizedHeight = (totalHeight / frames.length) / (faceWidth * 0.5);

    // Estimate lip rounding from width-height ratio
    const lipRounding = normalizedHeight > 0
      ? Math.min(1, normalizedHeight / normalizedWidth)
      : 0;

    // Estimate jaw opening from mouth height
    const jawOpen = Math.min(1, normalizedHeight * 2);

    return {
      width: Math.min(1, normalizedWidth * 2),
      height: Math.min(1, normalizedHeight),
      upperLipProtrusion: 0.1,
      lowerLipProtrusion: 0.05,
      jawOpen,
      lipRounding,
      teethVisible: normalizedHeight > 0.15,
      tongueVisible: normalizedHeight > 0.25
    };
  }

  /**
   * Classify viseme from mouth shape
   */
  private classifyViseme(mouthShape: MouthShape): VisemeType {
    // Silence/closed mouth
    if (mouthShape.height < 0.05 && mouthShape.width < 0.4) {
      return 'SILENCE';
    }

    // Bilabial sounds (closed or nearly closed)
    if (mouthShape.height < 0.05 && mouthShape.width > 0.3) {
      return 'B';
    }

    // Rounded vowels (O, U)
    if (mouthShape.lipRounding > 0.6 && mouthShape.height > 0.2) {
      return mouthShape.height > 0.4 ? 'O' : 'U';
    }

    // Open vowels (A)
    if (mouthShape.jawOpen > 0.5 && mouthShape.width > 0.5) {
      return 'A';
    }

    // Front vowels (I, E)
    if (mouthShape.width > 0.4 && mouthShape.height < 0.3) {
      return mouthShape.teethVisible ? 'I' : 'E';
    }

    // Labiodental (F, V)
    if (mouthShape.height < 0.15 && mouthShape.teethVisible) {
      return 'F';
    }

    // Alveolar (T, D, N, L, S, Z)
    if (mouthShape.height < 0.25 && mouthShape.width > 0.35) {
      return mouthShape.teethVisible ? 'S' : 'D';
    }

    // Default to neutral
    return 'X';
  }

  /**
   * Calculate viseme intensity
   */
  private calculateVisemeIntensity(mouthShape: MouthShape): number {
    // Intensity based on mouth opening and articulation
    return Math.min(1, mouthShape.jawOpen * 0.5 + mouthShape.height * 0.5);
  }

  /**
   * Align phonemes and visemes temporally
   */
  private alignPhonemesVisemes(
    phonemes: Phoneme[],
    visemes: Viseme[]
  ): Array<{ phoneme: Phoneme; viseme: Viseme | null; offset: number }> {
    const pairs: Array<{ phoneme: Phoneme; viseme: Viseme | null; offset: number }> = [];

    for (const phoneme of phonemes) {
      // Find overlapping viseme
      const overlappingViseme = visemes.find(v =>
        v.startTime <= phoneme.endTime && v.endTime >= phoneme.startTime
      );

      if (overlappingViseme) {
        const offset = overlappingViseme.startTime - phoneme.startTime;
        pairs.push({
          phoneme,
          viseme: overlappingViseme,
          offset
        });
      } else {
        pairs.push({
          phoneme,
          viseme: null,
          offset: 0
        });
      }
    }

    return pairs;
  }

  /**
   * Detect synchronization errors
   */
  private detectSyncErrors(
    alignedPairs: Array<{ phoneme: Phoneme; viseme: Viseme | null; offset: number }>,
    phonemes: Phoneme[],
    visemes: Viseme[]
  ): SyncError[] {
    const errors: SyncError[] = [];

    for (const pair of alignedPairs) {
      // Missing viseme
      if (!pair.viseme) {
        errors.push({
          type: 'missing',
          timestamp: pair.phoneme.startTime,
          duration: pair.phoneme.duration,
          severity: 0.7,
          description: `No mouth movement detected for phoneme ${pair.phoneme.symbol}`,
          expectedViseme: PHONEME_TO_VISEME[pair.phoneme.symbol] || 'X'
        });
        continue;
      }

      // Timing error
      if (Math.abs(pair.offset) > this.config.timingThreshold) {
        errors.push({
          type: 'timing',
          timestamp: pair.phoneme.startTime,
          duration: pair.phoneme.duration,
          severity: Math.min(1, Math.abs(pair.offset) / 200),
          description: `Timing offset of ${pair.offset}ms detected`,
          timingOffset: pair.offset
        });
      }

      // Phoneme-viseme mismatch
      const expectedViseme = PHONEME_TO_VISEME[pair.phoneme.symbol];
      if (expectedViseme && pair.viseme.type !== expectedViseme) {
        const similarity = this.calculateVisemeSimilarity(expectedViseme, pair.viseme.type);

        if (similarity < this.config.shapeSimilarityThreshold) {
          errors.push({
            type: 'mismatch',
            timestamp: pair.phoneme.startTime,
            duration: pair.phoneme.duration,
            severity: 1 - similarity,
            description: `Phoneme ${pair.phoneme.symbol} expects viseme ${expectedViseme} but got ${pair.viseme.type}`,
            expectedViseme,
            actualViseme: pair.viseme.type
          });
        }
      }
    }

    // Check for extra visemes (mouth movement without sound)
    for (const viseme of visemes) {
      const hasPhoneme = phonemes.some(p =>
        p.startTime <= viseme.endTime && p.endTime >= viseme.startTime
      );

      if (!hasPhoneme && viseme.type !== 'SILENCE') {
        errors.push({
          type: 'extra',
          timestamp: viseme.startTime,
          duration: viseme.endTime - viseme.startTime,
          severity: 0.5,
          description: `Mouth movement detected without corresponding audio`,
          actualViseme: viseme.type
        });
      }
    }

    return errors;
  }

  /**
   * Calculate similarity between two visemes
   */
  private calculateVisemeSimilarity(v1: VisemeType, v2: VisemeType): number {
    if (v1 === v2) return 1;

    // Define viseme similarity groups
    const similarityGroups: VisemeType[][] = [
      ['B', 'M', 'P'], // Bilabial
      ['F', 'V'], // Labiodental
      ['S', 'Z'], // Alveolar fricatives
      ['T', 'D', 'N', 'L'], // Alveolar
      ['C', 'J', 'SH', 'ZH'], // Postalveolar
      ['A', 'AH', 'AA'], // Open vowels
      ['I', 'E', 'IY', 'IH'], // Front vowels
      ['O', 'U', 'OW', 'UW'], // Rounded vowels
      ['G', 'K', 'NG'], // Velar
    ];

    for (const group of similarityGroups) {
      if (group.includes(v1) && group.includes(v2)) {
        return 0.8;
      }
    }

    return 0.3;
  }

  /**
   * Calculate audio-visual coherence score
   */
  private calculateCoherenceScore(
    phonemes: Phoneme[],
    visemes: Viseme[],
    alignedPairs: Array<{ phoneme: Phoneme; viseme: Viseme | null; offset: number }>
  ): number {
    if (alignedPairs.length === 0) return 1;

    let totalCoherence = 0;

    for (const pair of alignedPairs) {
      if (!pair.viseme) {
        totalCoherence += 0.3; // Low coherence for missing viseme
        continue;
      }

      // Calculate shape match
      const expectedViseme = PHONEME_TO_VISEME[pair.phoneme.symbol];
      if (expectedViseme) {
        const shapeSimilarity = this.calculateVisemeSimilarity(expectedViseme, pair.viseme.type);
        totalCoherence += shapeSimilarity;
      } else {
        totalCoherence += 0.5;
      }
    }

    return totalCoherence / alignedPairs.length;
  }

  /**
   * Calculate temporal alignment accuracy
   */
  private calculateTemporalAccuracy(
    alignedPairs: Array<{ phoneme: Phoneme; viseme: Viseme | null; offset: number }>
  ): number {
    const validPairs = alignedPairs.filter(p => p.viseme !== null);
    if (validPairs.length === 0) return 1;

    const offsets = validPairs.map(p => Math.abs(p.offset));
    const avgOffset = offsets.reduce((a, b) => a + b, 0) / offsets.length;

    // Convert to accuracy score (0ms offset = 1, 100ms+ offset = 0)
    return Math.max(0, 1 - avgOffset / 100);
  }

  /**
   * Detect lip sync anomalies
   */
  private detectAnomalies(
    visemes: Viseme[],
    phonemes: Phoneme[],
    syncErrors: SyncError[]
  ): LipSyncAnomaly[] {
    const anomalies: LipSyncAnomaly[] = [];

    // Detect lip jitter
    const jitterAnomaly = this.detectLipJitter(visemes);
    if (jitterAnomaly) {
      anomalies.push(jitterAnomaly);
    }

    // Detect unnatural motion
    const motionAnomaly = this.detectUnnaturalMotion(visemes);
    if (motionAnomaly) {
      anomalies.push(motionAnomaly);
    }

    // Detect timing drift
    const driftAnomaly = this.detectTimingDrift(syncErrors);
    if (driftAnomaly) {
      anomalies.push(driftAnomaly);
    }

    // Detect phoneme mismatch patterns
    const mismatchAnomaly = this.detectMismatchPattern(syncErrors);
    if (mismatchAnomaly) {
      anomalies.push(mismatchAnomaly);
    }

    return anomalies;
  }

  /**
   * Detect lip jitter (rapid small movements)
   */
  private detectLipJitter(visemes: Viseme[]): LipSyncAnomaly | null {
    if (visemes.length < 5) return null;

    // Count rapid transitions
    let rapidTransitions = 0;

    for (let i = 1; i < visemes.length; i++) {
      const duration = visemes[i].startTime - visemes[i - 1].startTime;
      if (duration < 30) {
        rapidTransitions++;
      }
    }

    const jitterRatio = rapidTransitions / visemes.length;

    if (jitterRatio > 0.3) {
      return {
        type: 'lip_jitter',
        timeRange: {
          start: visemes[0].startTime,
          end: visemes[visemes.length - 1].endTime
        },
        severity: jitterRatio,
        confidence: 0.8,
        description: `Rapid lip movement transitions detected (${(jitterRatio * 100).toFixed(1)}%)`
      };
    }

    return null;
  }

  /**
   * Detect unnatural motion patterns
   */
  private detectUnnaturalMotion(visemes: Viseme[]): LipSyncAnomaly | null {
    if (visemes.length < 10) return null;

    // Check for unrealistic mouth shapes
    const unnaturalCount = visemes.filter(v => {
      const shape = v.mouthShape;
      // Check for impossible combinations
      return shape.height > 0.8 && shape.lipRounding > 0.8 && shape.width < 0.2;
    }).length;

    if (unnaturalCount > visemes.length * 0.1) {
      return {
        type: 'unnatural_motion',
        timeRange: {
          start: visemes[0].startTime,
          end: visemes[visemes.length - 1].endTime
        },
        severity: unnaturalCount / visemes.length,
        confidence: 0.75,
        description: 'Unnatural mouth shape combinations detected'
      };
    }

    return null;
  }

  /**
   * Detect timing drift
   */
  private detectTimingDrift(syncErrors: SyncError[]): LipSyncAnomaly | null {
    const timingErrors = syncErrors.filter(e => e.type === 'timing');
    if (timingErrors.length < 3) return null;

    // Check for progressive drift
    const offsets = timingErrors.map(e => e.timingOffset || 0);

    // Calculate trend
    let trendSum = 0;
    for (let i = 1; i < offsets.length; i++) {
      trendSum += offsets[i] - offsets[i - 1];
    }

    const avgTrend = trendSum / (offsets.length - 1);

    if (Math.abs(avgTrend) > 5) {
      return {
        type: 'timing_drift',
        timeRange: {
          start: timingErrors[0].timestamp,
          end: timingErrors[timingErrors.length - 1].timestamp
        },
        severity: Math.min(1, Math.abs(avgTrend) / 20),
        confidence: 0.85,
        description: `Progressive timing drift detected (avg ${avgTrend.toFixed(1)}ms per segment)`
      };
    }

    return null;
  }

  /**
   * Detect phoneme mismatch patterns
   */
  private detectMismatchPattern(syncErrors: SyncError[]): LipSyncAnomaly | null {
    const mismatches = syncErrors.filter(e => e.type === 'mismatch');
    if (mismatches.length < 5) return null;

    const mismatchRatio = mismatches.length / syncErrors.length;

    if (mismatchRatio > 0.3) {
      return {
        type: 'phoneme_mismatch',
        timeRange: {
          start: mismatches[0].timestamp,
          end: mismatches[mismatches.length - 1].timestamp
        },
        severity: mismatchRatio,
        confidence: 0.9,
        description: `High rate of phoneme-viseme mismatches (${(mismatchRatio * 100).toFixed(1)}%)`
      };
    }

    return null;
  }

  /**
   * Calculate overall sync score
   */
  private calculateSyncScore(syncErrors: SyncError[]): number {
    if (syncErrors.length === 0) return 1;

    const totalSeverity = syncErrors.reduce((sum, e) => sum + e.severity, 0);
    const avgSeverity = totalSeverity / syncErrors.length;

    return Math.max(0, 1 - avgSeverity);
  }

  /**
   * Calculate deepfake probability
   */
  private calculateDeepfakeProbability(
    syncErrors: SyncError[],
    anomalies: LipSyncAnomaly[],
    coherenceScore: number
  ): number {
    let probability = 0;

    // Weight by sync errors
    if (syncErrors.length > 0) {
      const avgSeverity = syncErrors.reduce((sum, e) => sum + e.severity, 0) / syncErrors.length;
      probability += avgSeverity * 0.4;
    }

    // Weight by anomalies
    for (const anomaly of anomalies) {
      probability += anomaly.severity * anomaly.confidence * 0.2;
    }

    // Weight by coherence
    probability += (1 - coherenceScore) * 0.3;

    return Math.min(probability, 1);
  }

  /**
   * Generate recommendations
   */
  private generateRecommendations(
    syncErrors: SyncError[],
    anomalies: LipSyncAnomaly[],
    deepfakeProbability: number
  ): string[] {
    const recommendations: string[] = [];

    if (deepfakeProbability > 0.7) {
      recommendations.push('High likelihood of lip-sync deepfake detected');
    } else if (deepfakeProbability > 0.4) {
      recommendations.push('Moderate lip-sync manipulation indicators detected');
    }

    const errorTypes = new Set(syncErrors.map(e => e.type));

    if (errorTypes.has('mismatch')) {
      recommendations.push('Audio-visual phoneme mismatch detected - common in lip-sync deepfakes');
    }

    if (errorTypes.has('timing')) {
      recommendations.push('Timing inconsistencies detected between audio and lip movements');
    }

    if (errorTypes.has('missing')) {
      recommendations.push('Missing mouth movements for detected speech');
    }

    if (errorTypes.has('extra')) {
      recommendations.push('Extra mouth movements without corresponding audio');
    }

    const anomalyTypes = new Set(anomalies.map(a => a.type));

    if (anomalyTypes.has('lip_jitter')) {
      recommendations.push('Unnatural lip jitter detected - may indicate synthetic generation');
    }

    if (anomalyTypes.has('timing_drift')) {
      recommendations.push('Progressive timing drift detected - audio-video desync');
    }

    if (recommendations.length === 0) {
      recommendations.push('Audio-visual synchronization appears natural');
    }

    return recommendations;
  }
}

// ============================================================================
// CONFIGURATION
// ============================================================================

export interface LipSyncConfig {
  /** Timing threshold in ms for sync detection */
  timingThreshold: number;
  /** Minimum similarity for viseme match */
  shapeSimilarityThreshold: number;
  /** Minimum phoneme duration in ms */
  minPhonemeDuration: number;
  /** Analysis window size in ms */
  windowSize: number;
  /** Audio sample rate */
  sampleRate: number;
}

// ============================================================================
// CONVENIENCE FUNCTIONS
// ============================================================================

/**
 * Analyze lip sync from audio and video
 */
export function analyzeLipSync(
  audioFrames: Array<{ features: AudioFeatures; timestamp: number }>,
  videoFrames: Array<{ landmarks: LipLandmarks; timestamp: number }>,
  config?: Partial<LipSyncConfig>
): LipSyncAnalysisResult {
  const analyzer = new LipSyncAnalyzer(config);
  return analyzer.analyze(audioFrames, videoFrames);
}

/**
 * Extract visemes from video frames
 */
export function extractVisemesFromVideo(
  videoFrames: Array<{ landmarks: LipLandmarks; timestamp: number }>
): Viseme[] {
  const analyzer = new LipSyncAnalyzer();
  const result = analyzer.analyze([], videoFrames);
  return result.visemes;
}

/**
 * Calculate sync score between audio and video
 */
export function calculateSyncScore(
  audioFrames: Array<{ features: AudioFeatures; timestamp: number }>,
  videoFrames: Array<{ landmarks: LipLandmarks; timestamp: number }>
): number {
  const analyzer = new LipSyncAnalyzer();
  const result = analyzer.analyze(audioFrames, videoFrames);
  return result.syncScore;
}

// ============================================================================
// TESTS
// ============================================================================

/**
 * Run lip sync forensics tests
 */
export function runLipSyncForensicsTests(): {
  passed: boolean;
  summary: { total: number; passed: number; failed: number };
  details: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const tests: Array<{ name: string; passed: boolean; error?: string }> = [];

  // Test 1: Analyzer instantiation
  try {
    const analyzer = new LipSyncAnalyzer();
    tests.push({ name: 'Analyzer instantiation', passed: true });
  } catch (error) {
    tests.push({ name: 'Analyzer instantiation', passed: false, error: String(error) });
  }

  // Test 2: Empty input handling
  try {
    const analyzer = new LipSyncAnalyzer();
    const result = analyzer.analyze([], []);
    tests.push({
      name: 'Empty input handling',
      passed: result.syncScore === 1 && result.deepfakeProbability === 0
    });
  } catch (error) {
    tests.push({ name: 'Empty input handling', passed: false, error: String(error) });
  }

  // Test 3: Audio-only analysis
  try {
    const analyzer = new LipSyncAnalyzer();
    const audioFrames = generateSyntheticAudio(10);
    const result = analyzer.analyze(audioFrames, []);
    tests.push({
      name: 'Audio-only analysis',
      passed: result.phonemes.length > 0
    });
  } catch (error) {
    tests.push({ name: 'Audio-only analysis', passed: false, error: String(error) });
  }

  // Test 4: Video-only analysis
  try {
    const analyzer = new LipSyncAnalyzer();
    const videoFrames = generateSyntheticVideo(10);
    const result = analyzer.analyze([], videoFrames);
    tests.push({
      name: 'Video-only analysis',
      passed: result.visemes.length > 0
    });
  } catch (error) {
    tests.push({ name: 'Video-only analysis', passed: false, error: String(error) });
  }

  // Test 5: Full sync analysis
  try {
    const analyzer = new LipSyncAnalyzer();
    const audioFrames = generateSyntheticAudio(30);
    const videoFrames = generateSyntheticVideo(30);
    const result = analyzer.analyze(audioFrames, videoFrames);
    tests.push({
      name: 'Full sync analysis',
      passed: typeof result.syncScore === 'number' &&
        typeof result.coherenceScore === 'number'
    });
  } catch (error) {
    tests.push({ name: 'Full sync analysis', passed: false, error: String(error) });
  }

  // Test 6: Phoneme-viseme mapping
  try {
    const mapping = PHONEME_TO_VISEME['AA'];
    tests.push({
      name: 'Phoneme-viseme mapping',
      passed: mapping === 'A'
    });
  } catch (error) {
    tests.push({ name: 'Phoneme-viseme mapping', passed: false, error: String(error) });
  }

  // Test 7: Viseme classification
  try {
    const analyzer = new LipSyncAnalyzer();
    const mouthShape: MouthShape = {
      width: 0.7,
      height: 0.6,
      jawOpen: 0.6,
      lipRounding: 0.2,
      upperLipProtrusion: 0,
      lowerLipProtrusion: 0,
      teethVisible: false,
      tongueVisible: false
    };
    // @ts-expect-error - Testing private method
    const viseme = analyzer['classifyViseme'](mouthShape);
    tests.push({
      name: 'Viseme classification',
      passed: viseme === 'A'
    });
  } catch (error) {
    tests.push({ name: 'Viseme classification', passed: false, error: String(error) });
  }

  // Test 8: Error detection
  try {
    const analyzer = new LipSyncAnalyzer();
    const audioFrames = generateSyntheticAudio(20);
    const videoFrames = generateSyntheticVideo(20);
    const result = analyzer.analyze(audioFrames, videoFrames);
    tests.push({
      name: 'Error detection',
      passed: Array.isArray(result.syncErrors)
    });
  } catch (error) {
    tests.push({ name: 'Error detection', passed: false, error: String(error) });
  }

  // Test 9: Anomaly detection
  try {
    const analyzer = new LipSyncAnalyzer();
    const audioFrames = generateSyntheticAudio(20);
    const videoFrames = generateSyntheticVideo(20);
    const result = analyzer.analyze(audioFrames, videoFrames);
    tests.push({
      name: 'Anomaly detection',
      passed: Array.isArray(result.anomalies)
    });
  } catch (error) {
    tests.push({ name: 'Anomaly detection', passed: false, error: String(error) });
  }

  // Test 10: Convenience functions
  try {
    const audioFrames = generateSyntheticAudio(10);
    const videoFrames = generateSyntheticVideo(10);

    const result = analyzeLipSync(audioFrames, videoFrames);
    const visemes = extractVisemesFromVideo(videoFrames);
    const score = calculateSyncScore(audioFrames, videoFrames);

    tests.push({
      name: 'Convenience functions',
      passed: result !== undefined &&
        Array.isArray(visemes) &&
        typeof score === 'number'
    });
  } catch (error) {
    tests.push({ name: 'Convenience functions', passed: false, error: String(error) });
  }

  const passed = tests.filter(t => t.passed).length;
  const failed = tests.filter(t => !t.passed).length;

  return {
    passed: failed === 0,
    summary: { total: tests.length, passed, failed },
    details: tests
  };
}

/**
 * Generate synthetic audio frames for testing
 */
function generateSyntheticAudio(count: number): Array<{ features: AudioFeatures; timestamp: number }> {
  const frames: Array<{ features: AudioFeatures; timestamp: number }> = [];

  for (let i = 0; i < count; i++) {
    frames.push({
      features: {
        f0: 100 + Math.sin(i * 0.5) * 50,
        mfcc: Array(13).fill(0).map((_, j) => Math.sin(i * 0.3 + j) * 2),
        zcr: 0.1 + Math.random() * 0.2,
        energy: 0.3 + Math.random() * 0.4,
        spectralCentroid: 2000 + Math.random() * 1000,
        spectralRolloff: 3000 + Math.random() * 1000
      },
      timestamp: i * 33
    });
  }

  return frames;
}

/**
 * Generate synthetic video frames for testing
 */
function generateSyntheticVideo(count: number): Array<{ landmarks: LipLandmarks; timestamp: number }> {
  const frames: Array<{ landmarks: LipLandmarks; timestamp: number }> = [];

  for (let i = 0; i < count; i++) {
    const mouthOpen = Math.sin(i * 0.5) * 10 + 5;

    frames.push({
      landmarks: {
        upperLipCenter: { x: 100, y: 100 },
        lowerLipCenter: { x: 100, y: 100 + mouthOpen },
        leftCorner: { x: 80, y: 102 },
        rightCorner: { x: 120, y: 102 },
        upperLipPoints: [
          { x: 85, y: 100 },
          { x: 100, y: 98 },
          { x: 115, y: 100 }
        ],
        lowerLipPoints: [
          { x: 85, y: 100 + mouthOpen },
          { x: 100, y: 102 + mouthOpen },
          { x: 115, y: 100 + mouthOpen }
        ],
        timestamp: i * 33
      },
      timestamp: i * 33
    });
  }

  return frames;
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

const lipSyncForensicsModule = {
  LipSyncAnalyzer,
  analyzeLipSync,
  extractVisemesFromVideo,
  calculateSyncScore,
  runLipSyncForensicsTests,
  PHONEME_TO_VISEME,
  VISEME_SHAPES
};

export default lipSyncForensicsModule;
