/**
 * Kasbah Chaos Engineering Module
 * Fault injection, resilience testing, and system reliability validation
 * 
 * @module chaos-engineering
 * @version 1.0.0
 * @disruption-score +2.0/10
 * 
 * Capabilities:
 * - Network fault injection (latency, packet loss, partition)
 * - Resource exhaustion (CPU, memory, disk, file descriptors)
 * - Service degradation simulation
 * - Cascading failure analysis
 * - Recovery time measurement
 * - Circuit breaker testing
 * - Graceful degradation validation
 * - Blast radius analysis
 */

// ============================================
// TYPE DEFINITIONS
// ============================================

export interface ChaosExperiment {
  id: string;
  name: string;
  description: string;
  hypothesis: string;
  steadyState: SteadyStateCondition[];
  method: FaultInjection[];
  rollback: RollbackAction[];
  duration: number;
  blastRadius: BlastRadius;
  status: ExperimentStatus;
  results?: ExperimentResult;
  createdAt: Date;
  startedAt?: Date;
  completedAt?: Date;
}

export interface SteadyStateCondition {
  metric: string;
  operator: 'eq' | 'neq' | 'gt' | 'gte' | 'lt' | 'lte' | 'within';
  value: number | number[];
  tolerance: number;
  source: 'metrics' | 'logs' | 'traces' | 'custom';
}

export interface FaultInjection {
  type: FaultType;
  target: FaultTarget;
  parameters: Record<string, unknown>;
  schedule: InjectionSchedule;
  duration: number;
}

export type FaultType = 
  | 'network_latency'
  | 'network_packet_loss'
  | 'network_partition'
  | 'network_dns_failure'
  | 'cpu_stress'
  | 'memory_stress'
  | 'disk_stress'
  | 'disk_fill'
  | 'process_kill'
  | 'process_pause'
  | 'process_stop'
  | 'service_degradation'
  | 'service_timeout'
  | 'service_error'
  | 'time_skew'
  | 'file_descriptor_exhaustion'
  | 'connection_pool_exhaustion';

export interface FaultTarget {
  type: 'service' | 'container' | 'node' | 'zone' | 'region' | 'network' | 'database' | 'cache' | 'queue';
  selector: Record<string, string>;
  percentage: number;
}

export interface InjectionSchedule {
  type: 'immediate' | 'delayed' | 'gradual' | 'repeating';
  delay?: number;
  rampUp?: number;
  interval?: number;
  count?: number;
}

export interface RollbackAction {
  type: 'revert' | 'restart' | 'scale' | 'failover' | 'restore';
  target: string;
  timeout: number;
  automatic: boolean;
}

export interface BlastRadius {
  expected: {
    servicesAffected: number;
    usersImpacted: number;
    dataAtRisk: number;
  };
  actual?: {
    servicesAffected: number;
    usersImpacted: number;
    dataAtRisk: number;
  };
  blastRadiusScore: number;
}

export type ExperimentStatus = 'pending' | 'running' | 'completed' | 'failed' | 'aborted';

export interface ExperimentResult {
  hypothesisValidated: boolean;
  steadyStateMaintained: boolean;
  metrics: MetricObservation[];
  timeline: ExperimentTimelineEvent[];
  recoveryTime: number;
  mttr: number;
  errorBudgetRemaining: number;
  lessonsLearned: string[];
  recommendations: string[];
}

export interface MetricObservation {
  name: string;
  baseline: number;
  duringExperiment: number[];
  postExperiment: number;
  deviation: number;
  recovered: boolean;
  recoveryTime?: number;
}

export interface ExperimentTimelineEvent {
  timestamp: Date;
  type: 'start' | 'fault_injected' | 'fault_recovered' | 'alert_triggered' | 'manual_intervention' | 'rollback' | 'end';
  description: string;
  metadata?: Record<string, unknown>;
}

// ============================================
// NETWORK FAULT INJECTOR
// ============================================

export class NetworkFaultInjector {
  private activeFaults: Map<string, { type: FaultType; startTime: Date; config: Record<string, unknown> }> = new Map();

  /**
   * Inject network latency
   */
  async injectLatency(
    target: FaultTarget,
    latencyMs: number,
    jitterMs: number = 0,
    correlation: number = 0.25
  ): Promise<{ faultId: string; status: string }> {
    const faultId = `latency-${Date.now()}`;
    
    // Simulate latency injection (in real implementation, use tc or similar)
    this.activeFaults.set(faultId, {
      type: 'network_latency',
      startTime: new Date(),
      config: { target, latencyMs, jitterMs, correlation }
    });

    // Log the injection
    console.log(`[CHAOS] Injecting latency: ${latencyMs}ms (±${jitterMs}ms jitter) to ${JSON.stringify(target.selector)}`);

    return {
      faultId,
      status: 'injected'
    };
  }

  /**
   * Inject packet loss
   */
  async injectPacketLoss(
    target: FaultTarget,
    lossPercentage: number,
    correlation: number = 0.25
  ): Promise<{ faultId: string; status: string }> {
    const faultId = `packetloss-${Date.now()}`;
    
    this.activeFaults.set(faultId, {
      type: 'network_packet_loss',
      startTime: new Date(),
      config: { target, lossPercentage, correlation }
    });

    console.log(`[CHAOS] Injecting packet loss: ${lossPercentage}% to ${JSON.stringify(target.selector)}`);

    return {
      faultId,
      status: 'injected'
    };
  }

  /**
   * Simulate network partition
   */
  async simulatePartition(
    target: FaultTarget,
    partitionType: 'one-way' | 'two-way' = 'two-way'
  ): Promise<{ faultId: string; status: string }> {
    const faultId = `partition-${Date.now()}`;
    
    this.activeFaults.set(faultId, {
      type: 'network_partition',
      startTime: new Date(),
      config: { target, partitionType }
    });

    console.log(`[CHAOS] Simulating ${partitionType} network partition for ${JSON.stringify(target.selector)}`);

    return {
      faultId,
      status: 'injected'
    };
  }

  /**
   * Simulate DNS failure
   */
  async simulateDNSFailure(
    target: FaultTarget,
    failureType: 'timeout' | 'refused' | 'nxdomain' = 'timeout'
  ): Promise<{ faultId: string; status: string }> {
    const faultId = `dns-${Date.now()}`;
    
    this.activeFaults.set(faultId, {
      type: 'network_dns_failure',
      startTime: new Date(),
      config: { target, failureType }
    });

    console.log(`[CHAOS] Simulating DNS ${failureType} failure for ${JSON.stringify(target.selector)}`);

    return {
      faultId,
      status: 'injected'
    };
  }

  /**
   * Clear all network faults
   */
  async clearAllFaults(): Promise<{ cleared: number }> {
    const count = this.activeFaults.size;
    
    for (const [faultId, fault] of this.activeFaults) {
      console.log(`[CHAOS] Clearing fault: ${faultId} (${fault.type})`);
    }
    
    this.activeFaults.clear();
    
    return { cleared: count };
  }

  /**
   * Get active faults
   */
  getActiveFaults(): Array<{ id: string; type: FaultType; duration: number }> {
    const faults: Array<{ id: string; type: FaultType; duration: number }> = [];
    
    for (const [id, fault] of this.activeFaults) {
      faults.push({
        id,
        type: fault.type,
        duration: Date.now() - fault.startTime.getTime()
      });
    }
    
    return faults;
  }
}

// ============================================
// RESOURCE STRESS INJECTOR
// ============================================

export class ResourceStressInjector {
  private stressProcesses: Map<string, { type: string; startTime: Date; intensity: number }> = new Map();

  /**
   * Inject CPU stress
   */
  async injectCPUStress(
    target: FaultTarget,
    cpuPercentage: number,
    duration: number,
    cores: number[] = [0]
  ): Promise<{ faultId: string; status: string }> {
    const faultId = `cpu-stress-${Date.now()}`;
    
    // Simulate CPU stress
    const stressPromise = new Promise<void>((resolve) => {
      const startTime = Date.now();
      const stressLoop = () => {
        // Simulate CPU load by doing computation
        for (let i = 0; i < 1000000 * cpuPercentage / 100; i++) {
          Math.sqrt(Math.random());
        }
        
        if (Date.now() - startTime < duration) {
          setImmediate(stressLoop);
        } else {
          resolve();
        }
      };
      stressLoop();
    });

    this.stressProcesses.set(faultId, {
      type: 'cpu_stress',
      startTime: new Date(),
      intensity: cpuPercentage
    });

    // Auto-clear after duration
    setTimeout(() => {
      this.stressProcesses.delete(faultId);
    }, duration);

    console.log(`[CHAOS] Injecting CPU stress: ${cpuPercentage}% for ${duration}ms`);

    return {
      faultId,
      status: 'injected'
    };
  }

  /**
   * Inject memory stress
   */
  async injectMemoryStress(
    target: FaultTarget,
    memoryMB: number,
    duration: number
  ): Promise<{ faultId: string; status: string }> {
    const faultId = `mem-stress-${Date.now()}`;
    
    // Allocate memory
    const buffer = Buffer.alloc(memoryMB * 1024 * 1024);
    
    // Fill with random data to ensure allocation
    for (let i = 0; i < buffer.length; i += 4096) {
      buffer[i] = Math.floor(Math.random() * 256);
    }

    this.stressProcesses.set(faultId, {
      type: 'memory_stress',
      startTime: new Date(),
      intensity: memoryMB
    });

    // Auto-clear after duration
    setTimeout(() => {
      // Clear buffer (allow GC)
      buffer.fill(0);
      this.stressProcesses.delete(faultId);
      console.log(`[CHAOS] Memory stress released: ${faultId}`);
    }, duration);

    console.log(`[CHAOS] Injecting memory stress: ${memoryMB}MB for ${duration}ms`);

    return {
      faultId,
      status: 'injected'
    };
  }

  /**
   * Inject disk I/O stress
   */
  async injectDiskStress(
    target: FaultTarget,
    iops: number,
    blockSize: number = 4096,
    duration: number
  ): Promise<{ faultId: string; status: string }> {
    const faultId = `disk-stress-${Date.now()}`;
    
    this.stressProcesses.set(faultId, {
      type: 'disk_stress',
      startTime: new Date(),
      intensity: iops
    });

    // Simulate disk I/O (in real implementation, actually write to disk)
    const stressInterval = setInterval(() => {
      // Simulate I/O operations
      for (let i = 0; i < iops / 100; i++) {
        const buffer = Buffer.alloc(blockSize);
        buffer.fill(Math.floor(Math.random() * 256));
        // In real implementation: fs.writeFileSync(`/tmp/stress-${i}`, buffer);
      }
    }, 100);

    // Auto-clear after duration
    setTimeout(() => {
      clearInterval(stressInterval);
      this.stressProcesses.delete(faultId);
      console.log(`[CHAOS] Disk stress released: ${faultId}`);
    }, duration);

    console.log(`[CHAOS] Injecting disk stress: ${iops} IOPS for ${duration}ms`);

    return {
      faultId,
      status: 'injected'
    };
  }

  /**
   * Fill disk space
   */
  async fillDiskSpace(
    target: FaultTarget,
    sizeGB: number,
    path: string = '/tmp'
  ): Promise<{ faultId: string; status: string }> {
    const faultId = `disk-fill-${Date.now()}`;
    
    // Simulate disk fill
    const totalBytes = sizeGB * 1024 * 1024 * 1024;
    const chunkSize = 100 * 1024 * 1024; // 100MB chunks
    const chunks: Buffer[] = [];

    for (let written = 0; written < totalBytes; written += chunkSize) {
      const chunk = Buffer.alloc(Math.min(chunkSize, totalBytes - written));
      chunk.fill(0);
      chunks.push(chunk);
    }

    this.stressProcesses.set(faultId, {
      type: 'disk_fill',
      startTime: new Date(),
      intensity: sizeGB
    });

    // Store reference for cleanup
    (this.stressProcesses.get(faultId) as { chunks: Buffer[] }).chunks = chunks;

    console.log(`[CHAOS] Filled ${sizeGB}GB of disk space`);

    return {
      faultId,
      status: 'injected'
    };
  }

  /**
   * Exhaust file descriptors
   */
  async exhaustFileDescriptors(
    target: FaultTarget,
    count: number
  ): Promise<{ faultId: string; status: string; opened: number }> {
    const faultId = `fd-exhaust-${Date.now()}`;
    const descriptors: number[] = [];

    try {
      // Simulate opening files (in real implementation, actually open files)
      for (let i = 0; i < count; i++) {
        // Simulated file descriptor
        descriptors.push(i);
      }

      console.log(`[CHAOS] Exhausted file descriptors: ${descriptors.length}`);

      return {
        faultId,
        status: 'injected',
        opened: descriptors.length
      };
    } catch (err) {
      return {
        faultId,
        status: 'partial',
        opened: descriptors.length
      };
    }
  }

  /**
   * Get active stress processes
   */
  getActiveStress(): Array<{ id: string; type: string; intensity: number }> {
    const processes: Array<{ id: string; type: string; intensity: number }> = [];
    
    for (const [id, process] of this.stressProcesses) {
      processes.push({
        id,
        type: process.type,
        intensity: process.intensity
      });
    }
    
    return processes;
  }

  /**
   * Clear all stress
   */
  async clearAllStress(): Promise<{ cleared: number }> {
    const count = this.stressProcesses.size;
    this.stressProcesses.clear();
    
    // Force garbage collection if available
    if (global.gc) {
      global.gc();
    }
    
    console.log(`[CHAOS] Cleared all resource stress: ${count} processes`);
    
    return { cleared: count };
  }
}

// ============================================
// SERVICE DEGRADATION SIMULATOR
// ============================================

export class ServiceDegradationSimulator {
  private degradedServices: Map<string, {
    type: string;
    startTime: Date;
    degradation: number;
    originalBehavior?: () => unknown;
  }> = new Map();

  /**
   * Simulate service timeout
   */
  async simulateTimeout(
    serviceName: string,
    timeoutMs: number,
    probability: number = 1.0
  ): Promise<{ faultId: string }> {
    const faultId = `timeout-${serviceName}-${Date.now()}`;
    
    this.degradedServices.set(faultId, {
      type: 'timeout',
      startTime: new Date(),
      degradation: probability
    });

    console.log(`[CHAOS] Simulating timeout for ${serviceName}: ${timeoutMs}ms (${probability * 100}% of requests)`);

    return { faultId };
  }

  /**
   * Simulate service errors
   */
  async simulateErrors(
    serviceName: string,
    errorRate: number,
    errorType: string = 'INTERNAL_ERROR',
    statusCode: number = 500
  ): Promise<{ faultId: string }> {
    const faultId = `error-${serviceName}-${Date.now()}`;
    
    this.degradedServices.set(faultId, {
      type: 'error',
      startTime: new Date(),
      degradation: errorRate
    });

    console.log(`[CHAOS] Simulating errors for ${serviceName}: ${errorRate * 100}% (${statusCode})`);

    return { faultId };
  }

  /**
   * Simulate slow responses
   */
  async simulateSlowResponses(
    serviceName: string,
    baseLatencyMs: number,
    additionalLatencyMs: number,
    probability: number = 1.0
  ): Promise<{ faultId: string }> {
    const faultId = `slow-${serviceName}-${Date.now()}`;
    
    this.degradedServices.set(faultId, {
      type: 'slow',
      startTime: new Date(),
      degradation: probability
    });

    console.log(`[CHAOS] Simulating slow responses for ${serviceName}: +${additionalLatencyMs}ms`);

    return { faultId };
  }

  /**
   * Simulate cascading failure
   */
  async simulateCascadingFailure(
    services: string[],
    failureDelay: number = 1000
  ): Promise<{ faultId: string; affectedServices: string[] }> {
    const faultId = `cascade-${Date.now()}`;
    
    for (const service of services) {
      await new Promise(resolve => setTimeout(resolve, failureDelay));
      
      this.degradedServices.set(`${faultId}-${service}`, {
        type: 'cascade',
        startTime: new Date(),
        degradation: 1.0
      });

      console.log(`[CHAOS] Cascading failure reached: ${service}`);
    }

    return {
      faultId,
      affectedServices: services
    };
  }

  /**
   * Check if service is degraded
   */
  isServiceDegraded(serviceName: string): { degraded: boolean; type?: string } {
    for (const [id, fault] of this.degradedServices) {
      if (id.includes(serviceName)) {
        return { degraded: true, type: fault.type };
      }
    }
    return { degraded: false };
  }

  /**
   * Apply degradation to request
   */
  async applyDegradation<T>(
    serviceName: string,
    request: () => Promise<T>
  ): Promise<T> {
    const degradation = this.isServiceDegraded(serviceName);
    
    if (!degradation.degraded) {
      return request();
    }

    const fault = Array.from(this.degradedServices.values())
      .find(f => f.type === degradation.type);

    if (!fault) {
      return request();
    }

    switch (fault.type) {
      case 'timeout':
        await new Promise(resolve => setTimeout(resolve, 30000));
        throw new Error('ETIMEDOUT');
      
      case 'error':
        if (Math.random() < fault.degradation) {
          throw new Error('INTERNAL_ERROR');
        }
        return request();
      
      case 'slow':
        await new Promise(resolve => setTimeout(resolve, fault.degradation * 5000));
        return request();
      
      default:
        return request();
    }
  }

  /**
   * Restore all services
   */
  async restoreAll(): Promise<{ restored: number }> {
    const count = this.degradedServices.size;
    this.degradedServices.clear();
    
    console.log(`[CHAOS] Restored all services: ${count} degradations removed`);
    
    return { restored: count };
  }
}

// ============================================
// CIRCUIT BREAKER TESTER
// ============================================

export class CircuitBreakerTester {
  private states: Map<string, {
    state: 'closed' | 'open' | 'half-open';
    failures: number;
    lastFailure?: Date;
    lastStateChange: Date;
    successThreshold: number;
    failureThreshold: number;
    timeout: number;
  }> = new Map();

  /**
   * Initialize circuit breaker for a service
   */
  initializeCircuitBreaker(
    serviceName: string,
    config: {
      failureThreshold?: number;
      successThreshold?: number;
      timeout?: number;
    } = {}
  ): void {
    this.states.set(serviceName, {
      state: 'closed',
      failures: 0,
      lastStateChange: new Date(),
      successThreshold: config.successThreshold ?? 3,
      failureThreshold: config.failureThreshold ?? 5,
      timeout: config.timeout ?? 30000
    });
  }

  /**
   * Record success
   */
  recordSuccess(serviceName: string): { state: string; action: string } {
    const breaker = this.states.get(serviceName);
    if (!breaker) {
      this.initializeCircuitBreaker(serviceName);
      return this.recordSuccess(serviceName);
    }

    if (breaker.state === 'half-open') {
      breaker.failures = 0;
      
      // Check if we should close
      if (breaker.failures === 0) {
        breaker.state = 'closed';
        breaker.lastStateChange = new Date();
        return { state: 'closed', action: 'circuit_closed' };
      }
    }

    breaker.failures = Math.max(0, breaker.failures - 1);
    return { state: breaker.state, action: 'success_recorded' };
  }

  /**
   * Record failure
   */
  recordFailure(serviceName: string): { state: string; action: string } {
    const breaker = this.states.get(serviceName);
    if (!breaker) {
      this.initializeCircuitBreaker(serviceName);
      return this.recordFailure(serviceName);
    }

    breaker.failures++;
    breaker.lastFailure = new Date();

    if (breaker.state === 'closed' && breaker.failures >= breaker.failureThreshold) {
      breaker.state = 'open';
      breaker.lastStateChange = new Date();
      return { state: 'open', action: 'circuit_opened' };
    }

    if (breaker.state === 'half-open') {
      breaker.state = 'open';
      breaker.lastStateChange = new Date();
      return { state: 'open', action: 'circuit_reopened' };
    }

    return { state: breaker.state, action: 'failure_recorded' };
  }

  /**
   * Check if request is allowed
   */
  isRequestAllowed(serviceName: string): { allowed: boolean; state: string } {
    const breaker = this.states.get(serviceName);
    if (!breaker) {
      return { allowed: true, state: 'closed' };
    }

    if (breaker.state === 'closed') {
      return { allowed: true, state: 'closed' };
    }

    if (breaker.state === 'open') {
      // Check if timeout has elapsed
      const elapsed = Date.now() - breaker.lastStateChange.getTime();
      if (elapsed >= breaker.timeout) {
        breaker.state = 'half-open';
        breaker.lastStateChange = new Date();
        return { allowed: true, state: 'half-open' };
      }
      return { allowed: false, state: 'open' };
    }

    // Half-open: allow limited requests
    return { allowed: true, state: 'half-open' };
  }

  /**
   * Test circuit breaker behavior
   */
  async testCircuitBreaker(
    serviceName: string,
    scenarios: Array<{ type: 'success' | 'failure'; count: number }>
  ): Promise<{
    events: Array<{ type: string; state: string; action: string }>;
    finalState: string;
  }> {
    this.initializeCircuitBreaker(serviceName);
    const events: Array<{ type: string; state: string; action: string }> = [];

    for (const scenario of scenarios) {
      for (let i = 0; i < scenario.count; i++) {
        let result;
        if (scenario.type === 'success') {
          result = this.recordSuccess(serviceName);
        } else {
          result = this.recordFailure(serviceName);
        }
        events.push({
          type: scenario.type,
          state: result.state,
          action: result.action
        });
      }
    }

    const breaker = this.states.get(serviceName);
    return {
      events,
      finalState: breaker?.state || 'closed'
    };
  }

  /**
   * Get circuit breaker state
   */
  getState(serviceName: string): {
    state: string;
    failures: number;
    lastFailure?: Date;
    lastStateChange: Date;
  } | null {
    const breaker = this.states.get(serviceName);
    if (!breaker) return null;

    return {
      state: breaker.state,
      failures: breaker.failures,
      lastFailure: breaker.lastFailure,
      lastStateChange: breaker.lastStateChange
    };
  }
}

// ============================================
// RECOVERY TIME MEASURER
// ============================================

export class RecoveryTimeMeasurer {
  private recoveryPoints: Map<string, {
    faultInjectedAt: Date;
    faultClearedAt?: Date;
    serviceRecoveredAt?: Date;
    metricsBaseline: Map<string, number>;
    metricsRecovery: Map<string, number>;
  }> = new Map();

  /**
   * Start measuring recovery time
   */
  startMeasurement(
    serviceId: string,
    baselineMetrics: Record<string, number>
  ): void {
    this.recoveryPoints.set(serviceId, {
      faultInjectedAt: new Date(),
      metricsBaseline: new Map(Object.entries(baselineMetrics)),
      metricsRecovery: new Map()
    });
  }

  /**
   * Mark fault as cleared
   */
  markFaultCleared(serviceId: string): void {
    const point = this.recoveryPoints.get(serviceId);
    if (point) {
      point.faultClearedAt = new Date();
    }
  }

  /**
   * Check if service has recovered
   */
  checkRecovery(
    serviceId: string,
    currentMetrics: Record<string, number>,
    tolerance: number = 0.1
  ): { recovered: boolean; recoveryTime?: number } {
    const point = this.recoveryPoints.get(serviceId);
    if (!point) {
      return { recovered: false };
    }

    let allRecovered = true;
    
    for (const [metric, value] of Object.entries(currentMetrics)) {
      const baseline = point.metricsBaseline.get(metric);
      if (baseline !== undefined) {
        const deviation = Math.abs(value - baseline) / baseline;
        if (deviation > tolerance) {
          allRecovered = false;
        }
        point.metricsRecovery.set(metric, value);
      }
    }

    if (allRecovered && !point.serviceRecoveredAt) {
      point.serviceRecoveredAt = new Date();
      const recoveryTime = point.serviceRecoveredAt.getTime() - 
                          (point.faultClearedAt?.getTime() || point.faultInjectedAt.getTime());
      
      return { recovered: true, recoveryTime };
    }

    return { recovered: allRecovered };
  }

  /**
   * Get recovery metrics
   */
  getRecoveryMetrics(serviceId: string): {
    faultDuration: number;
    recoveryTime: number;
    totalImpactTime: number;
  } | null {
    const point = this.recoveryPoints.get(serviceId);
    if (!point || !point.faultClearedAt || !point.serviceRecoveredAt) {
      return null;
    }

    const faultDuration = point.faultClearedAt.getTime() - point.faultInjectedAt.getTime();
    const recoveryTime = point.serviceRecoveredAt.getTime() - point.faultClearedAt.getTime();
    const totalImpactTime = point.serviceRecoveredAt.getTime() - point.faultInjectedAt.getTime();

    return {
      faultDuration,
      recoveryTime,
      totalImpactTime
    };
  }

  /**
   * Calculate MTTR statistics
   */
  calculateMTTR(): {
    mttr: number;
    p50: number;
    p95: number;
    p99: number;
    samples: number;
  } {
    const recoveryTimes: number[] = [];

    for (const point of this.recoveryPoints.values()) {
      if (point.faultClearedAt && point.serviceRecoveredAt) {
        recoveryTimes.push(
          point.serviceRecoveredAt.getTime() - point.faultClearedAt.getTime()
        );
      }
    }

    if (recoveryTimes.length === 0) {
      return { mttr: 0, p50: 0, p95: 0, p99: 0, samples: 0 };
    }

    const sorted = recoveryTimes.sort((a, b) => a - b);
    const mttr = sorted.reduce((a, b) => a + b, 0) / sorted.length;

    return {
      mttr,
      p50: sorted[Math.floor(sorted.length * 0.5)],
      p95: sorted[Math.floor(sorted.length * 0.95)],
      p99: sorted[Math.floor(sorted.length * 0.99)],
      samples: sorted.length
    };
  }
}

// ============================================
// CHAOS EXPERIMENT RUNNER
// ============================================

export class ChaosExperimentRunner {
  private networkInjector: NetworkFaultInjector;
  private resourceInjector: ResourceStressInjector;
  private serviceSimulator: ServiceDegradationSimulator;
  private circuitBreakerTester: CircuitBreakerTester;
  private recoveryMeasurer: RecoveryTimeMeasurer;
  
  private experiments: Map<string, ChaosExperiment> = new Map();
  private metricsCollector?: () => Record<string, number>;

  constructor() {
    this.networkInjector = new NetworkFaultInjector();
    this.resourceInjector = new ResourceStressInjector();
    this.serviceSimulator = ServiceDegradationSimulator.prototype; // Will be used via instance
    this.circuitBreakerTester = new CircuitBreakerTester();
    this.recoveryMeasurer = new RecoveryTimeMeasurer();
    this.serviceSimulator = new ServiceDegradationSimulator();
  }

  /**
   * Set metrics collector
   */
  setMetricsCollector(collector: () => Record<string, number>): void {
    this.metricsCollector = collector;
  }

  /**
   * Create experiment
   */
  createExperiment(config: Partial<ChaosExperiment>): ChaosExperiment {
    const experiment: ChaosExperiment = {
      id: config.id || `exp-${Date.now()}`,
      name: config.name || 'Unnamed Experiment',
      description: config.description || '',
      hypothesis: config.hypothesis || 'System maintains steady state under fault',
      steadyState: config.steadyState || [],
      method: config.method || [],
      rollback: config.rollback || [],
      duration: config.duration || 60000,
      blastRadius: config.blastRadius || {
        expected: { servicesAffected: 1, usersImpacted: 0, dataAtRisk: 0 },
        blastRadiusScore: 1
      },
      status: 'pending',
      createdAt: new Date()
    };

    this.experiments.set(experiment.id, experiment);
    return experiment;
  }

  /**
   * Run experiment
   */
  async runExperiment(experimentId: string): Promise<ExperimentResult> {
    const experiment = this.experiments.get(experimentId);
    if (!experiment) {
      throw new Error(`Experiment ${experimentId} not found`);
    }

    // Update status
    experiment.status = 'running';
    experiment.startedAt = new Date();

    // Collect baseline metrics
    const baselineMetrics = this.metricsCollector?.() || {};

    // Start recovery measurement
    this.recoveryMeasurer.startMeasurement(experimentId, baselineMetrics);

    const timeline: ExperimentTimelineEvent[] = [
      {
        timestamp: new Date(),
        type: 'start',
        description: `Starting experiment: ${experiment.name}`
      }
    ];

    // Inject faults
    for (const fault of experiment.method) {
      timeline.push({
        timestamp: new Date(),
        type: 'fault_injected',
        description: `Injecting fault: ${fault.type}`,
        metadata: fault.parameters
      });

      await this.injectFault(fault);
    }

    // Monitor during experiment
    const duringMetrics: Map<string, number[]> = new Map();
    const monitorInterval = setInterval(() => {
      const metrics = this.metricsCollector?.() || {};
      for (const [key, value] of Object.entries(metrics)) {
        const values = duringMetrics.get(key) || [];
        values.push(value);
        duringMetrics.set(key, values);
      }
    }, 1000);

    // Wait for experiment duration
    await new Promise(resolve => setTimeout(resolve, experiment.duration));

    // Stop monitoring
    clearInterval(monitorInterval);

    // Rollback faults
    for (const rollback of experiment.rollback) {
      if (rollback.automatic) {
        timeline.push({
          timestamp: new Date(),
          type: 'rollback',
          description: `Executing rollback: ${rollback.type}`
        });
        await this.executeRollback(rollback);
      }
    }

    // Mark fault cleared
    this.recoveryMeasurer.markFaultCleared(experimentId);

    // Wait for recovery
    let recovered = false;
    const recoveryTimeout = experiment.duration;
    const recoveryStart = Date.now();

    while (!recovered && Date.now() - recoveryStart < recoveryTimeout) {
      const currentMetrics = this.metricsCollector?.() || {};
      const recoveryCheck = this.recoveryMeasurer.checkRecovery(experimentId, currentMetrics);
      recovered = recoveryCheck.recovered;
      
      if (!recovered) {
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }

    // Collect post-experiment metrics
    const postMetrics = this.metricsCollector?.() || {};

    // Calculate metric observations
    const metrics: MetricObservation[] = [];
    for (const [key, baseline] of Object.entries(baselineMetrics)) {
      const during = duringMetrics.get(key) || [];
      const post = postMetrics[key] || baseline;
      
      metrics.push({
        name: key,
        baseline,
        duringExperiment: during,
        postExperiment: post,
        deviation: Math.abs(post - baseline) / baseline,
        recovered: Math.abs(post - baseline) / baseline < 0.1
      });
    }

    // Calculate results
    const recoveryMetrics = this.recoveryMeasurer.getRecoveryMetrics(experimentId);
    const steadyStateMaintained = this.checkSteadyState(experiment.steadyState, metrics);

    // Update experiment
    experiment.status = 'completed';
    experiment.completedAt = new Date();

    timeline.push({
      timestamp: new Date(),
      type: 'end',
      description: `Experiment completed`
    });

    const result: ExperimentResult = {
      hypothesisValidated: steadyStateMaintained,
      steadyStateMaintained,
      metrics,
      timeline,
      recoveryTime: recoveryMetrics?.recoveryTime || 0,
      mttr: this.recoveryMeasurer.calculateMTTR().mttr,
      errorBudgetRemaining: this.calculateErrorBudget(metrics),
      lessonsLearned: this.generateLessonsLearned(metrics, timeline),
      recommendations: this.generateRecommendations(metrics, steadyStateMaintained)
    };

    experiment.results = result;

    return result;
  }

  /**
   * Abort experiment
   */
  async abortExperiment(experimentId: string): Promise<void> {
    const experiment = this.experiments.get(experimentId);
    if (!experiment) return;

    // Clear all faults
    await this.networkInjector.clearAllFaults();
    await this.resourceInjector.clearAllStress();
    await this.serviceSimulator.restoreAll();

    experiment.status = 'aborted';
    experiment.completedAt = new Date();
  }

  /**
   * Get experiment
   */
  getExperiment(experimentId: string): ChaosExperiment | undefined {
    return this.experiments.get(experimentId);
  }

  /**
   * List experiments
   */
  listExperiments(): ChaosExperiment[] {
    return Array.from(this.experiments.values());
  }

  private async injectFault(fault: FaultInjection): Promise<void> {
    switch (fault.type) {
      case 'network_latency':
        await this.networkInjector.injectLatency(
          fault.target,
          fault.parameters.latencyMs as number,
          fault.parameters.jitterMs as number
        );
        break;
      case 'network_packet_loss':
        await this.networkInjector.injectPacketLoss(
          fault.target,
          fault.parameters.lossPercentage as number
        );
        break;
      case 'network_partition':
        await this.networkInjector.simulatePartition(
          fault.target,
          fault.parameters.partitionType as 'one-way' | 'two-way'
        );
        break;
      case 'cpu_stress':
        await this.resourceInjector.injectCPUStress(
          fault.target,
          fault.parameters.cpuPercentage as number,
          fault.duration
        );
        break;
      case 'memory_stress':
        await this.resourceInjector.injectMemoryStress(
          fault.target,
          fault.parameters.memoryMB as number,
          fault.duration
        );
        break;
      case 'disk_stress':
        await this.resourceInjector.injectDiskStress(
          fault.target,
          fault.parameters.iops as number,
          4096,
          fault.duration
        );
        break;
      case 'service_timeout':
        await this.serviceSimulator.simulateTimeout(
          fault.target.selector.service as string,
          fault.parameters.timeoutMs as number
        );
        break;
      case 'service_error':
        await this.serviceSimulator.simulateErrors(
          fault.target.selector.service as string,
          fault.parameters.errorRate as number
        );
        break;
      default:
        console.log(`[CHAOS] Unknown fault type: ${fault.type}`);
    }
  }

  private async executeRollback(rollback: RollbackAction): Promise<void> {
    switch (rollback.type) {
      case 'revert':
        await this.networkInjector.clearAllFaults();
        await this.resourceInjector.clearAllStress();
        break;
      case 'restart':
        console.log(`[CHAOS] Restarting: ${rollback.target}`);
        break;
      case 'failover':
        console.log(`[CHAOS] Failing over: ${rollback.target}`);
        break;
      case 'restore':
        await this.serviceSimulator.restoreAll();
        break;
    }
  }

  private checkSteadyState(
    conditions: SteadyStateCondition[],
    metrics: MetricObservation[]
  ): boolean {
    for (const condition of conditions) {
      const metric = metrics.find(m => m.name === condition.metric);
      if (!metric) continue;

      const value = metric.postExperiment;
      const target = condition.value;

      switch (condition.operator) {
        case 'lt':
          if (value >= target as number) return false;
          break;
        case 'lte':
          if (value > target as number) return false;
          break;
        case 'gt':
          if (value <= target as number) return false;
          break;
        case 'gte':
          if (value < target as number) return false;
          break;
        case 'within':
          const [min, max] = target as number[];
          if (value < min || value > max) return false;
          break;
      }
    }

    return true;
  }

  private calculateErrorBudget(metrics: MetricObservation[]): number {
    // Simplified error budget calculation
    const totalBudget = 1.0;
    const consumed = metrics
      .filter(m => m.deviation > 0.1)
      .reduce((sum, m) => sum + m.deviation * 0.1, 0);
    
    return Math.max(0, totalBudget - consumed);
  }

  private generateLessonsLearned(
    metrics: MetricObservation[],
    timeline: ExperimentTimelineEvent[]
  ): string[] {
    const lessons: string[] = [];

    // Check for unexpected behaviors
    const highDeviationMetrics = metrics.filter(m => m.deviation > 0.3);
    if (highDeviationMetrics.length > 0) {
      lessons.push(
        `High deviation detected in: ${highDeviationMetrics.map(m => m.name).join(', ')}`
      );
    }

    // Check for slow recovery
    const slowRecovery = metrics.filter(m => !m.recovered);
    if (slowRecovery.length > 0) {
      lessons.push(
        `Slow recovery observed in: ${slowRecovery.map(m => m.name).join(', ')}`
      );
    }

    // Check timeline for issues
    const alerts = timeline.filter(e => e.type === 'alert_triggered');
    if (alerts.length > 0) {
      lessons.push(`${alerts.length} alerts were triggered during the experiment`);
    }

    return lessons;
  }

  private generateRecommendations(
    metrics: MetricObservation[],
    steadyStateMaintained: boolean
  ): string[] {
    const recommendations: string[] = [];

    if (!steadyStateMaintained) {
      recommendations.push('Review and improve fault tolerance mechanisms');
    }

    const cpuMetrics = metrics.filter(m => m.name.includes('cpu'));
    if (cpuMetrics.some(m => m.deviation > 0.5)) {
      recommendations.push('Implement CPU autoscaling based on load');
    }

    const memoryMetrics = metrics.filter(m => m.name.includes('memory'));
    if (memoryMetrics.some(m => m.deviation > 0.5)) {
      recommendations.push('Review memory allocation and implement proper cleanup');
    }

    const latencyMetrics = metrics.filter(m => m.name.includes('latency'));
    if (latencyMetrics.some(m => m.deviation > 0.3)) {
      recommendations.push('Implement circuit breakers and retry logic');
    }

    if (recommendations.length === 0) {
      recommendations.push('System demonstrated good resilience under fault conditions');
    }

    return recommendations;
  }
}

// ============================================
// EXPORTS
// ============================================

export const chaosEngineering = {
  NetworkFaultInjector,
  ResourceStressInjector,
  ServiceDegradationSimulator,
  CircuitBreakerTester,
  RecoveryTimeMeasurer,
  ChaosExperimentRunner
};

export default chaosEngineering;
