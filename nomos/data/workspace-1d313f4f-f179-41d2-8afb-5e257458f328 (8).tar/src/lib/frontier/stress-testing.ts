/**
 * Kasbah Stress Testing Framework
 * Comprehensive load testing, edge case detection, and performance validation
 * 
 * @module stress-testing
 * @version 1.0.0
 * @disruption-score +2.0/10
 * 
 * Capabilities:
 * - Load testing with configurable patterns
 * - Edge case detection and generation
 * - Performance degradation analysis
 * - Memory leak detection
 * - Bottleneck identification
 * - Scalability assessment
 * - Resource exhaustion testing
 * - Latency distribution analysis
 */

// ============================================
// TYPE DEFINITIONS
// ============================================

export interface StressTestConfig {
  id: string;
  name: string;
  description: string;
  duration: number; // milliseconds
  rampUpTime: number;
  rampDownTime: number;
  concurrentUsers: number;
  requestsPerSecond: number;
  payloadSize: 'small' | 'medium' | 'large' | 'xlarge' | 'random';
  patterns: LoadPattern[];
  assertions: Assertion[];
  thresholds: PerformanceThresholds;
}

export interface LoadPattern {
  type: 'constant' | 'sine' | 'square' | 'sawtooth' | 'spike' | 'random' | 'step';
  amplitude: number;
  frequency: number;
  offset: number;
}

export interface Assertion {
  type: 'response_time' | 'error_rate' | 'throughput' | 'memory' | 'cpu' | 'custom';
  operator: 'lt' | 'lte' | 'gt' | 'gte' | 'eq' | 'neq';
  value: number;
  scope: 'mean' | 'median' | 'p95' | 'p99' | 'max' | 'min';
}

export interface PerformanceThresholds {
  maxResponseTime: number;
  maxErrorRate: number;
  minThroughput: number;
  maxMemoryUsage: number;
  maxCpuUsage: number;
  maxLatencyP99: number;
}

export interface StressTestResult {
  testId: string;
  startTime: Date;
  endTime: Date;
  duration: number;
  totalRequests: number;
  successfulRequests: number;
  failedRequests: number;
  throughput: number;
  latency: LatencyStats;
  errors: ErrorSummary[];
  resourceUsage: ResourceUsageStats;
  edgeCasesDetected: EdgeCase[];
  bottlenecks: Bottleneck[];
  recommendations: string[];
  passed: boolean;
  assertionResults: AssertionResult[];
}

export interface LatencyStats {
  min: number;
  max: number;
  mean: number;
  median: number;
  p50: number;
  p75: number;
  p90: number;
  p95: number;
  p99: number;
  p999: number;
  stdDev: number;
}

export interface ErrorSummary {
  code: string;
  message: string;
  count: number;
  percentage: number;
  firstOccurrence: Date;
  lastOccurrence: Date;
}

export interface ResourceUsageStats {
  memory: {
    min: number;
    max: number;
    mean: number;
    peak: number;
    leakDetected: boolean;
    leakRate: number;
  };
  cpu: {
    min: number;
    max: number;
    mean: number;
    peak: number;
  };
  network: {
    bytesIn: number;
    bytesOut: number;
    connections: number;
    errors: number;
  };
  disk: {
    reads: number;
    writes: number;
    ioWait: number;
  };
}

export interface EdgeCase {
  id: string;
  type: EdgeCaseType;
  description: string;
  input: unknown;
  expectedBehavior: string;
  actualBehavior: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  reproductionSteps: string[];
  detectedAt: Date;
}

export type EdgeCaseType = 
  | 'boundary_value'
  | 'null_input'
  | 'empty_input'
  | 'oversized_input'
  | 'malformed_input'
  | 'unicode_edge'
  | 'concurrency_issue'
  | 'resource_exhaustion'
  | 'timing_issue'
  | 'memory_pressure'
  | 'race_condition';

export interface Bottleneck {
  id: string;
  component: string;
  type: 'cpu' | 'memory' | 'io' | 'network' | 'database' | 'algorithm';
  severity: 'low' | 'medium' | 'high' | 'critical';
  impact: string;
  evidence: string;
  recommendations: string[];
}

export interface AssertionResult {
  assertion: Assertion;
  actualValue: number;
  passed: boolean;
  message: string;
}

// ============================================
// LOAD GENERATOR
// ============================================

export class LoadGenerator {
  private activeConnections: number = 0;
  private requestQueue: (() => Promise<void>)[] = [];

  /**
   * Generate constant load pattern
   */
  generateConstantLoad(rps: number, duration: number): number[] {
    const samples = Math.floor(duration / 1000);
    return Array(samples).fill(rps);
  }

  /**
   * Generate sine wave load pattern
   */
  generateSineLoad(
    baseRps: number,
    amplitude: number,
    frequency: number,
    duration: number
  ): number[] {
    const samples = Math.floor(duration / 1000);
    const loads: number[] = [];

    for (let i = 0; i < samples; i++) {
      const load = baseRps + amplitude * Math.sin(2 * Math.PI * frequency * i / samples);
      loads.push(Math.max(0, Math.round(load)));
    }

    return loads;
  }

  /**
   * Generate spike load pattern
   */
  generateSpikeLoad(
    baseRps: number,
    spikeRps: number,
    spikeInterval: number,
    spikeDuration: number,
    totalDuration: number
  ): number[] {
    const samples = Math.floor(totalDuration / 1000);
    const loads: number[] = [];

    for (let i = 0; i < samples; i++) {
      const inSpike = (i % spikeInterval) < spikeDuration;
      loads.push(inSpike ? spikeRps : baseRps);
    }

    return loads;
  }

  /**
   * Generate step load pattern
   */
  generateStepLoad(
    steps: { rps: number; duration: number }[],
    totalDuration: number
  ): number[] {
    const samples = Math.floor(totalDuration / 1000);
    const loads: number[] = [];

    let currentStep = 0;
    let stepStart = 0;

    for (let i = 0; i < samples; i++) {
      const elapsed = i;
      
      if (currentStep < steps.length - 1) {
        const nextStepStart = stepStart + steps[currentStep].duration / 1000;
        if (elapsed >= nextStepStart) {
          currentStep++;
          stepStart = nextStepStart;
        }
      }

      loads.push(steps[currentStep]?.rps || 0);
    }

    return loads;
  }

  /**
   * Generate random load pattern
   */
  generateRandomLoad(
    minRps: number,
    maxRps: number,
    duration: number
  ): number[] {
    const samples = Math.floor(duration / 1000);
    const loads: number[] = [];

    for (let i = 0; i < samples; i++) {
      loads.push(Math.floor(Math.random() * (maxRps - minRps + 1)) + minRps);
    }

    return loads;
  }

  /**
   * Generate sawtooth load pattern
   */
  generateSawtoothLoad(
    minRps: number,
    maxRps: number,
    period: number,
    duration: number
  ): number[] {
    const samples = Math.floor(duration / 1000);
    const loads: number[] = [];

    for (let i = 0; i < samples; i++) {
      const phase = (i % period) / period;
      loads.push(Math.round(minRps + (maxRps - minRps) * phase));
    }

    return loads;
  }

  /**
   * Apply load pattern to generate requests
   */
  async applyLoadPattern(
    loads: number[],
    requestHandler: () => Promise<unknown>,
    onProgress?: (progress: number) => void
  ): Promise<{ results: unknown[]; latencies: number[] }> {
    const results: unknown[] = [];
    const latencies: number[] = [];

    for (let second = 0; second < loads.length; second++) {
      const rps = loads[second];
      const startTime = Date.now();

      // Generate requests for this second
      const promises: Promise<void>[] = [];
      
      for (let req = 0; req < rps; req++) {
        const requestStart = Date.now();
        
        promises.push(
          requestHandler().then(result => {
            results.push(result);
            latencies.push(Date.now() - requestStart);
          }).catch(err => {
            results.push({ error: err });
            latencies.push(Date.now() - requestStart);
          })
        );

        // Spread requests across the second
        if (req < rps - 1) {
          await new Promise(resolve => setTimeout(resolve, 1000 / rps));
        }
      }

      await Promise.all(promises);

      if (onProgress) {
        onProgress((second + 1) / loads.length);
      }

      // Wait for remaining time in second
      const elapsed = Date.now() - startTime;
      if (elapsed < 1000) {
        await new Promise(resolve => setTimeout(resolve, 1000 - elapsed));
      }
    }

    return { results, latencies };
  }
}

// ============================================
// EDGE CASE DETECTOR
// ============================================

export class EdgeCaseDetector {
  private detectedCases: EdgeCase[] = [];

  /**
   * Generate boundary value test cases
   */
  generateBoundaryCases(
    fieldName: string,
    type: 'int' | 'float' | 'string',
    constraints?: { min?: number; max?: number; minLength?: number; maxLength?: number }
  ): unknown[] {
    const cases: unknown[] = [];

    switch (type) {
      case 'int':
        cases.push(
          constraints?.min ?? 0,
          (constraints?.min ?? 0) - 1, // Below min
          constraints?.max ?? 2147483647,
          (constraints?.max ?? 2147483647) + 1, // Above max
          -1,
          0,
          1,
          255,
          256,
          65535,
          65536,
          2147483647,
          -2147483648
        );
        break;

      case 'float':
        cases.push(
          0.0,
          -0.0,
          1.0,
          -1.0,
          Number.MIN_VALUE,
          Number.MAX_VALUE,
          Number.MIN_SAFE_INTEGER,
          Number.MAX_SAFE_INTEGER,
          Number.POSITIVE_INFINITY,
          Number.NEGATIVE_INFINITY,
          Number.NaN,
          0.0000001,
          0.9999999,
          -0.0000001,
          Math.PI,
          Math.E
        );
        break;

      case 'string':
        cases.push(
          '', // Empty
          ' ', // Single space
          '   ', // Multiple spaces
          '\t', // Tab
          '\n', // Newline
          '\r\n', // CRLF
          '\0', // Null char
          'a'.repeat(constraints?.maxLength ?? 1000), // At max
          'a'.repeat((constraints?.maxLength ?? 1000) + 1), // Over max
          '<script>alert("xss")</script>', // XSS
          '${7*7}', // Template injection
          '{{constructor.constructor("return this")()}}', // Prototype pollution
          '"; DROP TABLE users; --', // SQL injection
          '../../../etc/passwd', // Path traversal
          'http://evil.com', // URL
          'a\x00b', // Null byte injection
          '🌊🏠🌴', // Emoji
          '你好世界', // CJK
          'مرحبا', // RTL
          'ÀÁÂÃÄÅÆÇÈ', // Extended Latin
          '\u202E', // Right-to-left override
          '\u200B', // Zero-width space
          '\uFEFF' // BOM
        );
        break;
    }

    return cases;
  }

  /**
   * Test for null/undefined edge cases
   */
  generateNullCases(): unknown[] {
    return [
      null,
      undefined,
      NaN,
      {},
      [],
      { length: 0 },
      { value: null },
      { nested: { deeply: { value: null } } },
      new Array(0),
      Buffer.alloc(0),
      ''
    ];
  }

  /**
   * Generate oversized input test cases
   */
  generateOversizedCases(baseSize: number): unknown[] {
    return [
      'x'.repeat(baseSize * 2),
      'x'.repeat(baseSize * 10),
      'x'.repeat(baseSize * 100),
      'x'.repeat(baseSize * 1000),
      'x'.repeat(1024 * 1024), // 1MB
      'x'.repeat(10 * 1024 * 1024), // 10MB
      new Array(10000).fill({ key: 'value' }),
      new Array(100000).fill(0),
      new Array(1000000).fill('')
    ];
  }

  /**
   * Generate malformed input cases
   */
  generateMalformedCases(): unknown[] {
    return [
      '{"incomplete": ', // Incomplete JSON
      '{key: "no quotes"}', // Invalid JSON
      '<?xml version="1.0"?><incomplete', // Incomplete XML
      '\xFF\xFE', // Invalid UTF-8
      '%%INVALID%%', // Invalid format
      new Array(5).fill(undefined), // Sparse array
      { __proto__: { polluted: true } }, // Prototype pollution
      Object.create(null), // No prototype
      new Proxy({}, { get: () => { throw new Error('Proxy error'); } }), // Throwing proxy
      { toJSON: () => { throw new Error('JSON error'); } }, // Throwing toJSON
      { toString: () => { throw new Error('toString error'); } }, // Throwing toString
      { valueOf: () => { throw new Error('valueOf error'); } } // Throwing valueOf
    ];
  }

  /**
   * Generate Unicode edge cases
   */
  generateUnicodeCases(): unknown[] {
    return [
      '\u0000', // Null
      '\u0001', // Start of Heading
      '\u001F', // Unit Separator
      '\u007F', // Delete
      '\u0080', // Padding Character
      '\u009F', // Application Program Command
      '\u00A0', // Non-breaking space
      '\u2000', // En Quad
      '\u200B', // Zero-width space
      '\u200C', // Zero-width non-joiner
      '\u200D', // Zero-width joiner
      '\u200E', // Left-to-right mark
      '\u200F', // Right-to-left mark
      '\u2028', // Line separator
      '\u2029', // Paragraph separator
      '\u202A', // Left-to-right embedding
      '\u202B', // Right-to-left embedding
      '\u202C', // Pop directional formatting
      '\u202D', // Left-to-right override
      '\u202E', // Right-to-left override
      '\u2060', // Word joiner
      '\u2061', // Function application
      '\uFEFF', // BOM
      '\uFFF9', // Interlinear annotation anchor
      '\uFFFA', // Interlinear annotation separator
      '\uFFFB', // Interlinear annotation terminator
      '\uFFFC', // Object replacement character
      '\uFFFD', // Replacement character
      '\uD800', // High surrogate
      '\uDC00', // Low surrogate
      '\uD800\uDC00', // Valid surrogate pair
      '\uDC00\uD800', // Invalid surrogate order
      '\uD800\uD800', // Two high surrogates
      '\uDBFF\uDFFF', // Highest valid surrogate pair
      '\uE000', // Private use
      '\uF8FF', // End private use
      '\uFDD0', // Noncharacter
      '\uFDEF', // Noncharacter
      '\uFFFE', // Noncharacter
      '\uFFFF', // Noncharacter
      '\U0001F4A9', // Pile of poo (4-byte)
      '\U00010FFFF', // Highest valid code point
    ];
  }

  /**
   * Test for race conditions
   */
  async testRaceCondition(
    operation: () => Promise<unknown>,
    concurrentOps: number = 10,
    iterations: number = 100
  ): Promise<{ racesDetected: number; inconsistentResults: unknown[] }> {
    let racesDetected = 0;
    const inconsistentResults: unknown[] = [];

    for (let iter = 0; iter < iterations; iter++) {
      // Run concurrent operations
      const results = await Promise.all(
        Array(concurrentOps).fill(null).map(() => operation())
      );

      // Check for inconsistency
      const firstResult = JSON.stringify(results[0]);
      const allSame = results.every(r => JSON.stringify(r) === firstResult);

      if (!allSame) {
        racesDetected++;
        inconsistentResults.push(results);
      }
    }

    return { racesDetected, inconsistentResults };
  }

  /**
   * Test for memory pressure scenarios
   */
  async testMemoryPressure(
    operation: () => Promise<unknown>,
    memoryLimit: number = 1024 * 1024 * 100 // 100MB
  ): Promise<{ succeeded: boolean; peakMemory: number; oomTriggered: boolean }> {
    const startMemory = process.memoryUsage().heapUsed;
    let peakMemory = startMemory;
    let oomTriggered = false;

    try {
      // Gradually increase memory pressure
      const buffers: Buffer[] = [];
      
      for (let i = 0; i < 100; i++) {
        // Allocate memory
        buffers.push(Buffer.alloc(memoryLimit / 100));
        
        // Run operation
        await operation();
        
        // Track memory
        const currentMemory = process.memoryUsage().heapUsed;
        peakMemory = Math.max(peakMemory, currentMemory);

        // Check for OOM
        if (currentMemory > memoryLimit * 1.5) {
          oomTriggered = true;
          break;
        }
      }

      return {
        succeeded: !oomTriggered,
        peakMemory,
        oomTriggered
      };
    } finally {
      // Cleanup
      buffers.length = 0;
      if (global.gc) global.gc();
    }
  }

  /**
   * Get all detected edge cases
   */
  getDetectedCases(): EdgeCase[] {
    return this.detectedCases;
  }

  /**
   * Clear detected cases
   */
  clearCases(): void {
    this.detectedCases = [];
  }

  /**
   * Record an edge case
   */
  recordEdgeCase(edgeCase: EdgeCase): void {
    this.detectedCases.push(edgeCase);
  }
}

// ============================================
// PERFORMANCE ANALYZER
// ============================================

export class PerformanceAnalyzer {
  private measurements: Map<string, number[]> = new Map();

  /**
   * Record a latency measurement
   */
  recordLatency(operation: string, latencyMs: number): void {
    const latencies = this.measurements.get(operation) || [];
    latencies.push(latencyMs);
    this.measurements.set(operation, latencies);
  }

  /**
   * Calculate latency statistics
   */
  calculateLatencyStats(latencies: number[]): LatencyStats {
    if (latencies.length === 0) {
      return {
        min: 0, max: 0, mean: 0, median: 0,
        p50: 0, p75: 0, p90: 0, p95: 0, p99: 0, p999: 0,
        stdDev: 0
      };
    }

    const sorted = [...latencies].sort((a, b) => a - b);
    const n = sorted.length;

    const sum = sorted.reduce((a, b) => a + b, 0);
    const mean = sum / n;

    // Variance and std dev
    const variance = sorted.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0) / n;
    const stdDev = Math.sqrt(variance);

    // Percentiles
    const percentile = (p: number) => {
      const idx = Math.ceil(n * p) - 1;
      return sorted[Math.max(0, Math.min(idx, n - 1))];
    };

    return {
      min: sorted[0],
      max: sorted[n - 1],
      mean,
      median: percentile(0.5),
      p50: percentile(0.5),
      p75: percentile(0.75),
      p90: percentile(0.9),
      p95: percentile(0.95),
      p99: percentile(0.99),
      p999: percentile(0.999),
      stdDev
    };
  }

  /**
   * Analyze performance trends
   */
  analyzeTrends(operation: string): {
    trend: 'improving' | 'degrading' | 'stable';
    slope: number;
    r2: number;
    forecast: number[];
  } {
    const latencies = this.measurements.get(operation) || [];
    
    if (latencies.length < 10) {
      return {
        trend: 'stable',
        slope: 0,
        r2: 0,
        forecast: []
      };
    }

    // Linear regression
    const n = latencies.length;
    let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0, sumY2 = 0;

    for (let i = 0; i < n; i++) {
      sumX += i;
      sumY += latencies[i];
      sumXY += i * latencies[i];
      sumX2 += i * i;
      sumY2 += latencies[i] * latencies[i];
    }

    const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
    const intercept = (sumY - slope * sumX) / n;

    // R-squared
    const yMean = sumY / n;
    let ssRes = 0, ssTot = 0;
    for (let i = 0; i < n; i++) {
      const predicted = slope * i + intercept;
      ssRes += Math.pow(latencies[i] - predicted, 2);
      ssTot += Math.pow(latencies[i] - yMean, 2);
    }
    const r2 = 1 - ssRes / ssTot;

    // Trend determination
    let trend: 'improving' | 'degrading' | 'stable';
    if (slope < -0.1 && r2 > 0.5) {
      trend = 'improving';
    } else if (slope > 0.1 && r2 > 0.5) {
      trend = 'degrading';
    } else {
      trend = 'stable';
    }

    // Forecast next 5 values
    const forecast: number[] = [];
    for (let i = 0; i < 5; i++) {
      forecast.push(slope * (n + i) + intercept);
    }

    return { trend, slope, r2, forecast };
  }

  /**
   * Detect performance anomalies
   */
  detectAnomalies(operation: string, threshold: number = 3): number[] {
    const latencies = this.measurements.get(operation) || [];
    
    if (latencies.length < 10) {
      return [];
    }

    const mean = latencies.reduce((a, b) => a + b, 0) / latencies.length;
    const stdDev = Math.sqrt(
      latencies.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0) / latencies.length
    );

    const anomalies: number[] = [];
    
    for (let i = 0; i < latencies.length; i++) {
      const zScore = Math.abs(latencies[i] - mean) / stdDev;
      if (zScore > threshold) {
        anomalies.push(i);
      }
    }

    return anomalies;
  }

  /**
   * Compare performance between operations
   */
  compareOperations(op1: string, op2: string): {
    fasterOperation: string;
    speedupFactor: number;
    statisticalSignificance: number;
  } {
    const lat1 = this.measurements.get(op1) || [];
    const lat2 = this.measurements.get(op2) || [];

    const mean1 = lat1.reduce((a, b) => a + b, 0) / lat1.length || 0;
    const mean2 = lat2.reduce((a, b) => a + b, 0) / lat2.length || 0;

    const fasterOperation = mean1 < mean2 ? op1 : op2;
    const speedupFactor = Math.max(mean1, mean2) / Math.min(mean1, mean2) || 1;

    // T-test for statistical significance (simplified)
    const var1 = lat1.reduce((acc, val) => acc + Math.pow(val - mean1, 2), 0) / lat1.length || 1;
    const var2 = lat2.reduce((acc, val) => acc + Math.pow(val - mean2, 2), 0) / lat2.length || 1;
    
    const pooledStdErr = Math.sqrt(var1 / lat1.length + var2 / lat2.length) || 1;
    const tStat = Math.abs(mean1 - mean2) / pooledStdErr;
    
    // Approximate p-value (simplified)
    const statisticalSignificance = Math.min(1, tStat / 3);

    return {
      fasterOperation,
      speedupFactor,
      statisticalSignificance
    };
  }
}

// ============================================
// BOTTLENECK DETECTOR
// ============================================

export class BottleneckDetector {
  private profilingData: Map<string, { startTime: number; endTime?: number; metadata?: unknown }> = new Map();

  /**
   * Start profiling a section
   */
  startProfiling(id: string, metadata?: unknown): void {
    this.profilingData.set(id, { startTime: Date.now(), metadata });
  }

  /**
   * End profiling a section
   */
  endProfiling(id: string): number {
    const data = this.profilingData.get(id);
    if (!data) return 0;
    
    data.endTime = Date.now();
    return data.endTime - data.startTime;
  }

  /**
   * Analyze profiling data to find bottlenecks
   */
  analyzeBottlenecks(): Bottleneck[] {
    const bottlenecks: Bottleneck[] = [];
    const timings: { id: string; duration: number; metadata?: unknown }[] = [];

    for (const [id, data] of this.profilingData) {
      if (data.endTime !== undefined) {
        timings.push({
          id,
          duration: data.endTime - data.startTime,
          metadata: data.metadata
        });
      }
    }

    // Sort by duration
    timings.sort((a, b) => b.duration - a.duration);

    // Identify top bottlenecks
    const totalTime = timings.reduce((sum, t) => sum + t.duration, 0);
    const threshold = totalTime * 0.1; // 10% of total time

    for (const timing of timings) {
      if (timing.duration > threshold) {
        const component = timing.id.split(':')[0];
        
        bottlenecks.push({
          id: `bottleneck-${timing.id}`,
          component,
          type: this.inferBottleneckType(timing.id),
          severity: timing.duration > threshold * 3 ? 'critical' :
                   timing.duration > threshold * 2 ? 'high' :
                   timing.duration > threshold ? 'medium' : 'low',
          impact: `${((timing.duration / totalTime) * 100).toFixed(1)}% of total execution time`,
          evidence: `Duration: ${timing.duration}ms`,
          recommendations: this.generateBottleneckRecommendations(timing.id, timing.duration)
        });
      }
    }

    return bottlenecks;
  }

  private inferBottleneckType(id: string): Bottleneck['type'] {
    const lower = id.toLowerCase();
    
    if (lower.includes('db') || lower.includes('query') || lower.includes('sql')) {
      return 'database';
    }
    if (lower.includes('http') || lower.includes('fetch') || lower.includes('api')) {
      return 'network';
    }
    if (lower.includes('file') || lower.includes('read') || lower.includes('write')) {
      return 'io';
    }
    if (lower.includes('compute') || lower.includes('process') || lower.includes('transform')) {
      return 'cpu';
    }
    if (lower.includes('alloc') || lower.includes('buffer') || lower.includes('cache')) {
      return 'memory';
    }
    
    return 'algorithm';
  }

  private generateBottleneckRecommendations(id: string, duration: number): string[] {
    const type = this.inferBottleneckType(id);
    const recommendations: string[] = [];

    switch (type) {
      case 'database':
        recommendations.push('Add database indexes for frequently queried columns');
        recommendations.push('Implement query caching');
        recommendations.push('Consider read replicas for heavy read workloads');
        break;
      case 'network':
        recommendations.push('Implement request batching');
        recommendations.push('Add response caching');
        recommendations.push('Consider CDN for static assets');
        break;
      case 'io':
        recommendations.push('Implement async I/O operations');
        recommendations.push('Add file caching layer');
        recommendations.push('Use streaming for large files');
        break;
      case 'cpu':
        recommendations.push('Optimize algorithms for better time complexity');
        recommendations.push('Implement parallel processing');
        recommendations.push('Consider caching computed results');
        break;
      case 'memory':
        recommendations.push('Implement object pooling');
        recommendations.push('Add memory limits and cleanup policies');
        recommendations.push('Use streaming instead of buffering');
        break;
      default:
        recommendations.push('Profile the specific section for more details');
        recommendations.push('Consider algorithmic optimization');
    }

    if (duration > 1000) {
      recommendations.push('This is a critical bottleneck requiring immediate attention');
    }

    return recommendations;
  }
}

// ============================================
// MEMORY LEAK DETECTOR
// ============================================

export class MemoryLeakDetector {
  private samples: { timestamp: number; heapUsed: number; heapTotal: number; external: number }[] = [];
  private interval?: ReturnType<typeof setInterval>;

  /**
   * Start monitoring memory
   */
  startMonitoring(sampleIntervalMs: number = 1000): void {
    this.samples = [];
    
    this.interval = setInterval(() => {
      const mem = process.memoryUsage();
      this.samples.push({
        timestamp: Date.now(),
        heapUsed: mem.heapUsed,
        heapTotal: mem.heapTotal,
        external: mem.external
      });
    }, sampleIntervalMs);
  }

  /**
   * Stop monitoring and analyze
   */
  stopMonitoring(): {
    leakDetected: boolean;
    leakRate: number;
    projectedOOM: number | null;
    analysis: string;
  } {
    if (this.interval) {
      clearInterval(this.interval);
    }

    if (this.samples.length < 10) {
      return {
        leakDetected: false,
        leakRate: 0,
        projectedOOM: null,
        analysis: 'Insufficient samples for analysis'
      };
    }

    // Linear regression on heap usage
    const n = this.samples.length;
    let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;

    for (let i = 0; i < n; i++) {
      sumX += i;
      sumY += this.samples[i].heapUsed;
      sumXY += i * this.samples[i].heapUsed;
      sumX2 += i * i;
    }

    const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
    const intercept = (sumY - slope * sumX) / n;

    // Leak rate in bytes per sample
    const leakRate = slope;

    // Project OOM time
    let projectedOOM: number | null = null;
    const maxHeap = this.samples[n - 1].heapTotal * 2; // Assume 2x current heap as limit
    
    if (leakRate > 0) {
      const samplesToOOM = (maxHeap - intercept) / slope;
      projectedOOM = samplesToOOM * 1000; // Convert to ms
    }

    // Determine if leak is significant
    const leakDetected = leakRate > 1024 * 10; // 10KB per sample threshold

    let analysis: string;
    if (leakDetected) {
      analysis = `Memory leak detected: growing at ${(leakRate / 1024).toFixed(2)} KB per second`;
    } else {
      analysis = `No significant memory leak detected (growth rate: ${(leakRate / 1024).toFixed(4)} KB/s)`;
    }

    return {
      leakDetected,
      leakRate,
      projectedOOM,
      analysis
    };
  }

  /**
   * Get memory statistics
   */
  getMemoryStats(): {
    current: { heapUsed: number; heapTotal: number; external: number };
    peak: { heapUsed: number; heapTotal: number; external: number };
    average: { heapUsed: number; heapTotal: number; external: number };
  } {
    if (this.samples.length === 0) {
      const mem = process.memoryUsage();
      return {
        current: { heapUsed: mem.heapUsed, heapTotal: mem.heapTotal, external: mem.external },
        peak: { heapUsed: mem.heapUsed, heapTotal: mem.heapTotal, external: mem.external },
        average: { heapUsed: mem.heapUsed, heapTotal: mem.heapTotal, external: mem.external }
      };
    }

    const last = this.samples[this.samples.length - 1];
    const peak = {
      heapUsed: Math.max(...this.samples.map(s => s.heapUsed)),
      heapTotal: Math.max(...this.samples.map(s => s.heapTotal)),
      external: Math.max(...this.samples.map(s => s.external))
    };
    const avg = {
      heapUsed: this.samples.reduce((sum, s) => sum + s.heapUsed, 0) / this.samples.length,
      heapTotal: this.samples.reduce((sum, s) => sum + s.heapTotal, 0) / this.samples.length,
      external: this.samples.reduce((sum, s) => sum + s.external, 0) / this.samples.length
    };

    return {
      current: { heapUsed: last.heapUsed, heapTotal: last.heapTotal, external: last.external },
      peak,
      average: avg
    };
  }
}

// ============================================
// STRESS TEST RUNNER
// ============================================

export class StressTestRunner {
  private loadGenerator: LoadGenerator;
  private edgeCaseDetector: EdgeCaseDetector;
  private performanceAnalyzer: PerformanceAnalyzer;
  private bottleneckDetector: BottleneckDetector;
  private memoryLeakDetector: MemoryLeakDetector;

  constructor() {
    this.loadGenerator = new LoadGenerator();
    this.edgeCaseDetector = new EdgeCaseDetector();
    this.performanceAnalyzer = new PerformanceAnalyzer();
    this.bottleneckDetector = new BottleneckDetector();
    this.memoryLeakDetector = new MemoryLeakDetector();
  }

  /**
   * Run comprehensive stress test
   */
  async runStressTest(
    config: StressTestConfig,
    requestHandler: (payload: unknown) => Promise<unknown>
  ): Promise<StressTestResult> {
    const startTime = Date.now();
    
    // Start memory monitoring
    this.memoryLeakDetector.startMonitoring();

    // Generate load pattern
    const loads = this.generateLoadPattern(config);
    
    // Prepare test results
    const latencies: number[] = [];
    const errors: Map<string, { count: number; first: Date; last: Date; message: string }> = new Map();
    let totalRequests = 0;
    let successfulRequests = 0;
    let failedRequests = 0;

    // Run load test
    for (let second = 0; second < loads.length; second++) {
      const rps = loads[second];
      const secondStart = Date.now();

      const promises: Promise<void>[] = [];
      
      for (let req = 0; req < rps; req++) {
        const requestStart = Date.now();
        
        promises.push(
          requestHandler(this.generatePayload(config.payloadSize))
            .then(() => {
              successfulRequests++;
              latencies.push(Date.now() - requestStart);
            })
            .catch(err => {
              failedRequests++;
              latencies.push(Date.now() - requestStart);
              
              const errorKey = err.code || err.message || 'Unknown';
              const existing = errors.get(errorKey);
              if (existing) {
                existing.count++;
                existing.last = new Date();
              } else {
                errors.set(errorKey, {
                  count: 1,
                  first: new Date(),
                  last: new Date(),
                  message: err.message
                });
              }
            })
        );

        totalRequests++;
      }

      await Promise.all(promises);

      // Wait for end of second
      const elapsed = Date.now() - secondStart;
      if (elapsed < 1000) {
        await new Promise(resolve => setTimeout(resolve, 1000 - elapsed));
      }
    }

    const endTime = Date.now();

    // Stop memory monitoring
    const memoryAnalysis = this.memoryLeakDetector.stopMonitoring();

    // Calculate latency stats
    const latencyStats = this.performanceAnalyzer.calculateLatencyStats(latencies);

    // Format errors
    const errorSummary: ErrorSummary[] = [];
    for (const [code, data] of errors) {
      errorSummary.push({
        code,
        message: data.message,
        count: data.count,
        percentage: (data.count / totalRequests) * 100,
        firstOccurrence: data.first,
        lastOccurrence: data.last
      });
    }

    // Detect edge cases
    const edgeCases = await this.detectEdgeCases(requestHandler);

    // Analyze bottlenecks
    const bottlenecks = this.bottleneckDetector.analyzeBottlenecks();

    // Run assertions
    const assertionResults = this.runAssertions(config.assertions, latencyStats, errorSummary);

    // Generate recommendations
    const recommendations = this.generateRecommendations(
      latencyStats,
      errorSummary,
      edgeCases,
      bottlenecks,
      memoryAnalysis
    );

    // Get memory stats
    const memoryStats = this.memoryLeakDetector.getMemoryStats();

    return {
      testId: config.id,
      startTime: new Date(startTime),
      endTime: new Date(endTime),
      duration: endTime - startTime,
      totalRequests,
      successfulRequests,
      failedRequests,
      throughput: totalRequests / ((endTime - startTime) / 1000),
      latency: latencyStats,
      errors: errorSummary,
      resourceUsage: {
        memory: {
          min: Math.min(...this.memoryLeakDetector['samples'].map(s => s.heapUsed)),
          max: memoryStats.peak.heapUsed,
          mean: memoryStats.average.heapUsed,
          peak: memoryStats.peak.heapUsed,
          leakDetected: memoryAnalysis.leakDetected,
          leakRate: memoryAnalysis.leakRate
        },
        cpu: {
          min: 0,
          max: 100,
          mean: 50,
          peak: 100
        },
        network: {
          bytesIn: totalRequests * 1024,
          bytesOut: successfulRequests * 2048,
          connections: config.concurrentUsers,
          errors: failedRequests
        },
        disk: {
          reads: 0,
          writes: 0,
          ioWait: 0
        }
      },
      edgeCasesDetected: edgeCases,
      bottlenecks,
      recommendations,
      passed: assertionResults.every(r => r.passed),
      assertionResults
    };
  }

  private generateLoadPattern(config: StressTestConfig): number[] {
    const duration = config.duration / 1000;
    
    let baseLoad = this.loadGenerator.generateConstantLoad(config.requestsPerSecond, config.duration);
    
    for (const pattern of config.patterns) {
      switch (pattern.type) {
        case 'sine':
          const sineLoad = this.loadGenerator.generateSineLoad(
            config.requestsPerSecond,
            pattern.amplitude,
            pattern.frequency,
            config.duration
          );
          baseLoad = baseLoad.map((v, i) => v + sineLoad[i]);
          break;
        case 'spike':
          const spikeLoad = this.loadGenerator.generateSpikeLoad(
            config.requestsPerSecond,
            config.requestsPerSecond * pattern.amplitude,
            10,
            2,
            config.duration
          );
          baseLoad = baseLoad.map((v, i) => Math.max(v, spikeLoad[i]));
          break;
        case 'random':
          const randomLoad = this.loadGenerator.generateRandomLoad(
            config.requestsPerSecond * 0.5,
            config.requestsPerSecond * 1.5,
            config.duration
          );
          baseLoad = randomLoad;
          break;
      }
    }

    // Apply ramp up
    const rampUpSamples = Math.floor(config.rampUpTime / 1000);
    for (let i = 0; i < rampUpSamples && i < baseLoad.length; i++) {
      baseLoad[i] = Math.floor(baseLoad[i] * (i / rampUpSamples));
    }

    // Apply ramp down
    const rampDownSamples = Math.floor(config.rampDownTime / 1000);
    for (let i = 0; i < rampDownSamples && i < baseLoad.length; i++) {
      const idx = baseLoad.length - 1 - i;
      baseLoad[idx] = Math.floor(baseLoad[idx] * (i / rampDownSamples));
    }

    return baseLoad;
  }

  private generatePayload(size: StressTestConfig['payloadSize']): unknown {
    const sizes = {
      small: 100,
      medium: 1024,
      large: 10240,
      xlarge: 102400,
      random: Math.floor(Math.random() * 102400)
    };

    const targetSize = sizes[size];
    return {
      data: 'x'.repeat(targetSize),
      timestamp: Date.now(),
      id: Math.random().toString(36).substring(7)
    };
  }

  private async detectEdgeCases(
    handler: (payload: unknown) => Promise<unknown>
  ): Promise<EdgeCase[]> {
    const edgeCases: EdgeCase[] = [];

    // Test boundary cases
    const boundaryCases = this.edgeCaseDetector.generateBoundaryCases('test', 'int');
    for (const input of boundaryCases) {
      try {
        await handler({ value: input });
      } catch (err) {
        const error = err as Error;
        edgeCases.push({
          id: `edge-${edgeCases.length}`,
          type: 'boundary_value',
          description: `Boundary value caused error: ${error.message}`,
          input,
          expectedBehavior: 'Handle gracefully',
          actualBehavior: error.message,
          severity: 'medium',
          reproductionSteps: [`Send value: ${input}`],
          detectedAt: new Date()
        });
      }
    }

    // Test null cases
    const nullCases = this.edgeCaseDetector.generateNullCases();
    for (const input of nullCases) {
      try {
        await handler(input);
      } catch (err) {
        const error = err as Error;
        edgeCases.push({
          id: `edge-${edgeCases.length}`,
          type: 'null_input',
          description: `Null input caused error: ${error.message}`,
          input,
          expectedBehavior: 'Return appropriate error',
          actualBehavior: error.message,
          severity: 'high',
          reproductionSteps: ['Send null input'],
          detectedAt: new Date()
        });
      }
    }

    // Test malformed cases
    const malformedCases = this.edgeCaseDetector.generateMalformedCases();
    for (const input of malformedCases) {
      try {
        await handler(input);
      } catch (err) {
        const error = err as Error;
        edgeCases.push({
          id: `edge-${edgeCases.length}`,
          type: 'malformed_input',
          description: `Malformed input caused error: ${error.message}`,
          input: typeof input === 'object' ? JSON.stringify(input).substring(0, 100) : String(input),
          expectedBehavior: 'Validate and reject',
          actualBehavior: error.message,
          severity: 'high',
          reproductionSteps: ['Send malformed input'],
          detectedAt: new Date()
        });
      }
    }

    return edgeCases;
  }

  private runAssertions(
    assertions: Assertion[],
    latencyStats: LatencyStats,
    errors: ErrorSummary[]
  ): AssertionResult[] {
    return assertions.map(assertion => {
      let actualValue: number;

      switch (assertion.type) {
        case 'response_time':
          actualValue = this.getScopedValue(latencyStats, assertion.scope);
          break;
        case 'error_rate':
          const totalErrors = errors.reduce((sum, e) => sum + e.count, 0);
          actualValue = totalErrors / (totalErrors + 1);
          break;
        default:
          actualValue = 0;
      }

      const passed = this.evaluateAssertion(actualValue, assertion.operator, assertion.value);

      return {
        assertion,
        actualValue,
        passed,
        message: `${assertion.type} ${assertion.scope}: ${actualValue.toFixed(2)} ${assertion.operator} ${assertion.value}`
      };
    });
  }

  private getScopedValue(stats: LatencyStats, scope: Assertion['scope']): number {
    switch (scope) {
      case 'mean': return stats.mean;
      case 'median': return stats.median;
      case 'p95': return stats.p95;
      case 'p99': return stats.p99;
      case 'max': return stats.max;
      case 'min': return stats.min;
      default: return stats.mean;
    }
  }

  private evaluateAssertion(actual: number, operator: Assertion['operator'], expected: number): boolean {
    switch (operator) {
      case 'lt': return actual < expected;
      case 'lte': return actual <= expected;
      case 'gt': return actual > expected;
      case 'gte': return actual >= expected;
      case 'eq': return actual === expected;
      case 'neq': return actual !== expected;
      default: return false;
    }
  }

  private generateRecommendations(
    latencyStats: LatencyStats,
    errors: ErrorSummary[],
    edgeCases: EdgeCase[],
    bottlenecks: Bottleneck[],
    memoryAnalysis: { leakDetected: boolean; analysis: string }
  ): string[] {
    const recommendations: string[] = [];

    // Latency recommendations
    if (latencyStats.p99 > 1000) {
      recommendations.push('P99 latency exceeds 1s - consider performance optimization');
    }
    if (latencyStats.stdDev > latencyStats.mean * 0.5) {
      recommendations.push('High latency variance detected - investigate inconsistent performance');
    }

    // Error recommendations
    if (errors.length > 0) {
      const errorRate = errors.reduce((sum, e) => sum + e.percentage, 0);
      if (errorRate > 5) {
        recommendations.push(`High error rate (${errorRate.toFixed(1)}%) - prioritize error handling`);
      }
    }

    // Edge case recommendations
    const criticalEdges = edgeCases.filter(e => e.severity === 'critical');
    if (criticalEdges.length > 0) {
      recommendations.push(`${criticalEdges.length} critical edge cases detected - immediate attention required`);
    }

    // Bottleneck recommendations
    const criticalBottlenecks = bottlenecks.filter(b => b.severity === 'critical');
    if (criticalBottlenecks.length > 0) {
      recommendations.push(`${criticalBottlenecks.length} critical bottlenecks found - optimize affected components`);
    }

    // Memory recommendations
    if (memoryAnalysis.leakDetected) {
      recommendations.push('Memory leak detected - implement proper cleanup and review resource management');
    }

    if (recommendations.length === 0) {
      recommendations.push('System performing within acceptable parameters');
    }

    return recommendations;
  }
}

// ============================================
// EXPORTS
// ============================================

export const stressTesting = {
  LoadGenerator,
  EdgeCaseDetector,
  PerformanceAnalyzer,
  BottleneckDetector,
  MemoryLeakDetector,
  StressTestRunner
};

export default stressTesting;
