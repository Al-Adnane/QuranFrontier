/**
 * Temporal Consistency Detection Module
 *
 * Detects temporal inconsistencies in video deepfakes by analyzing:
 * - Frame-to-frame coherence
 * - Temporal flickering artifacts
 * - Motion smoothness anomalies
 * - Identity drift across frames
 * - Lighting/shadow inconsistencies
 *
 * @module frontier/temporal-consistency
 * @version 4.1.0
 */

// ============================================================================
// TYPES AND INTERFACES
// ============================================================================

export interface Frame {
  /** Frame index */
  index: number;
  /** Timestamp in milliseconds */
  timestamp: number;
  /** Frame width */
  width: number;
  /** Frame height */
  height: number;
  /** Raw pixel data (RGB) */
  data: number[][];
  /** Detected faces in frame */
  faces?: DetectedFace[];
  /** Motion vectors */
  motionVectors?: MotionVector[];
}

export interface DetectedFace {
  /** Face bounding box */
  bbox: { x: number; y: number; width: number; height: number };
  /** Facial landmarks */
  landmarks: FacialLandmarks;
  /** Face embedding */
  embedding: number[];
  /** Confidence score */
  confidence: number;
}

export interface FacialLandmarks {
  /** 68-point landmarks */
  points: Array<{ x: number; y: number }>;
  /** Left eye center */
  leftEye: { x: number; y: number };
  /** Right eye center */
  rightEye: { x: number; y: number };
  /** Nose tip */
  nose: { x: number; y: number };
  /** Mouth center */
  mouth: { x: number; y: number };
  /** Chin */
  chin: { x: number; y: number };
}

export interface MotionVector {
  /** Start point */
  start: { x: number; y: number };
  /** End point */
  end: { x: number; y: number };
  /** Magnitude */
  magnitude: number;
  /** Angle in radians */
  angle: number;
}

export interface TemporalAnalysisResult {
  /** Analysis ID */
  id: string;
  /** Timestamp */
  timestamp: number;
  /** Overall consistency score (0-1) */
  consistencyScore: number;
  /** Deepfake probability */
  deepfakeProbability: number;
  /** Detected anomalies */
  anomalies: TemporalAnomaly[];
  /** Frame-by-frame analysis */
  frameAnalysis: FrameAnalysisResult[];
  /** Motion analysis */
  motionAnalysis: MotionAnalysisResult;
  /** Identity consistency */
  identityConsistency: IdentityConsistencyResult;
  /** Recommendations */
  recommendations: string[];
}

export interface TemporalAnomaly {
  /** Anomaly type */
  type: 'flicker' | 'jump' | 'morph' | 'identity_drift' | 'lighting' | 'occlusion';
  /** Frame indices where anomaly occurs */
  frames: number[];
  /** Severity (0-1) */
  severity: number;
  /** Confidence (0-1) */
  confidence: number;
  /** Description */
  description: string;
  /** Spatial location */
  location?: { x: number; y: number; width: number; height: number };
}

export interface FrameAnalysisResult {
  /** Frame index */
  frameIndex: number;
  /** Consistency with previous frame */
  prevConsistency: number;
  /** Consistency with next frame */
  nextConsistency: number;
  /** Local anomaly score */
  anomalyScore: number;
  /** Feature changes */
  featureChanges: Array<{
    name: string;
    change: number;
    threshold: number;
  }>;
}

export interface MotionAnalysisResult {
  /** Average motion magnitude */
  averageMotion: number;
  /** Motion variance */
  motionVariance: number;
  /** Motion smoothness score */
  smoothness: number;
  /** Sudden motion events */
  suddenMotionEvents: Array<{
    frameIndex: number;
    magnitude: number;
  }>;
  /** Motion blur consistency */
  blurConsistency: number;
}

export interface IdentityConsistencyResult {
  /** Overall identity consistency */
  overallScore: number;
  /** Identity drift detected */
  driftDetected: boolean;
  /** Per-segment scores */
  segments: Array<{
    startFrame: number;
    endFrame: number;
    score: number;
  }>;
  /** Face count consistency */
  faceCountVariance: number;
}

// ============================================================================
// TEMPORAL CONSISTENCY ANALYZER
// ============================================================================

/**
 * Temporal Consistency Analyzer
 * Analyzes video frames for temporal coherence
 */
export class TemporalConsistencyAnalyzer {
  private config: TemporalConfig;
  private frameBuffer: Frame[] = [];
  private previousFrame: Frame | null = null;
  private identityHistory: number[][] = [];

  constructor(config: Partial<TemporalConfig> = {}) {
    this.config = {
      windowSize: config.windowSize || 30,
      flickerThreshold: config.flickerThreshold || 0.15,
      jumpThreshold: config.jumpThreshold || 0.25,
      identityThreshold: config.identityThreshold || 0.85,
      motionThreshold: config.motionThreshold || 0.3,
      smoothingWindow: config.smoothingWindow || 5,
      ...config
    };
  }

  /**
   * Analyze temporal consistency of video frames
   */
  analyzeFrames(frames: Frame[]): TemporalAnalysisResult {
    const id = `temporal_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const startTime = Date.now();

    // Reset state
    this.frameBuffer = [];
    this.previousFrame = null;
    this.identityHistory = [];

    const anomalies: TemporalAnomaly[] = [];
    const frameAnalysis: FrameAnalysisResult[] = [];

    // Phase 1: Frame-by-frame analysis
    for (let i = 0; i < frames.length; i++) {
      const frame = frames[i];
      const prevFrame = i > 0 ? frames[i - 1] : null;
      const nextFrame = i < frames.length - 1 ? frames[i + 1] : null;

      const analysis = this.analyzeFrame(frame, prevFrame, nextFrame, i);
      frameAnalysis.push(analysis);

      // Track identity
      if (frame.faces && frame.faces.length > 0) {
        this.identityHistory.push(frame.faces[0].embedding);
      }

      this.frameBuffer.push(frame);
      if (this.frameBuffer.length > this.config.windowSize) {
        this.frameBuffer.shift();
      }
    }

    // Phase 2: Detect anomalies
    anomalies.push(...this.detectFlickerAnomalies(frames));
    anomalies.push(...this.detectJumpAnomalies(frames, frameAnalysis));
    anomalies.push(...this.detectMorphAnomalies(frames));
    anomalies.push(...this.detectLightingAnomalies(frames));

    // Phase 3: Motion analysis
    const motionAnalysis = this.analyzeMotion(frames);

    // Phase 4: Identity consistency
    const identityConsistency = this.analyzeIdentityConsistency(frames);

    // Detect identity drift anomalies
    if (identityConsistency.driftDetected) {
      anomalies.push({
        type: 'identity_drift',
        frames: frames.map((_, i) => i),
        severity: 1 - identityConsistency.overallScore,
        confidence: 0.9,
        description: 'Identity drift detected across video sequence'
      });
    }

    // Calculate overall scores
    const consistencyScore = this.calculateConsistencyScore(frameAnalysis, anomalies);
    const deepfakeProbability = this.calculateDeepfakeProbability(consistencyScore, anomalies);

    const result: TemporalAnalysisResult = {
      id,
      timestamp: startTime,
      consistencyScore,
      deepfakeProbability,
      anomalies: anomalies.sort((a, b) => b.severity - a.severity),
      frameAnalysis,
      motionAnalysis,
      identityConsistency,
      recommendations: this.generateRecommendations(anomalies, consistencyScore)
    };

    return result;
  }

  /**
   * Analyze individual frame
   */
  private analyzeFrame(
    frame: Frame,
    prevFrame: Frame | null,
    nextFrame: Frame | null,
    index: number
  ): FrameAnalysisResult {
    const prevConsistency = prevFrame
      ? this.calculateFrameSimilarity(frame, prevFrame)
      : 1.0;
    const nextConsistency = nextFrame
      ? this.calculateFrameSimilarity(frame, nextFrame)
      : 1.0;

    const featureChanges: Array<{ name: string; change: number; threshold: number }> = [];

    // Analyze feature changes
    if (prevFrame) {
      const brightnessChange = Math.abs(
        this.calculateBrightness(frame) - this.calculateBrightness(prevFrame)
      );
      if (brightnessChange > 0.1) {
        featureChanges.push({
          name: 'brightness',
          change: brightnessChange,
          threshold: 0.1
        });
      }

      const contrastChange = Math.abs(
        this.calculateContrast(frame) - this.calculateContrast(prevFrame)
      );
      if (contrastChange > 0.15) {
        featureChanges.push({
          name: 'contrast',
          change: contrastChange,
          threshold: 0.15
        });
      }

      const saturationChange = Math.abs(
        this.calculateSaturation(frame) - this.calculateSaturation(prevFrame)
      );
      if (saturationChange > 0.1) {
        featureChanges.push({
          name: 'saturation',
          change: saturationChange,
          threshold: 0.1
        });
      }
    }

    // Calculate anomaly score
    const anomalyScore = this.calculateFrameAnomalyScore(
      prevConsistency,
      nextConsistency,
      featureChanges
    );

    return {
      frameIndex: index,
      prevConsistency,
      nextConsistency,
      anomalyScore,
      featureChanges
    };
  }

  /**
   * Calculate frame similarity using histogram comparison
   */
  private calculateFrameSimilarity(frame1: Frame, frame2: Frame): number {
    // Calculate color histograms
    const hist1 = this.calculateColorHistogram(frame1);
    const hist2 = this.calculateColorHistogram(frame2);

    // Calculate histogram intersection
    let intersection = 0;
    let total = 0;

    for (let i = 0; i < hist1.length; i++) {
      intersection += Math.min(hist1[i], hist2[i]);
      total += Math.max(hist1[i], hist2[i]);
    }

    const histogramSimilarity = total > 0 ? intersection / total : 0;

    // Calculate structural similarity
    const structuralSimilarity = this.calculateStructuralSimilarity(frame1, frame2);

    // Combine scores
    return 0.6 * histogramSimilarity + 0.4 * structuralSimilarity;
  }

  /**
   * Calculate color histogram
   */
  private calculateColorHistogram(frame: Frame, bins: number = 32): number[] {
    const histogram: number[] = new Array(bins * 3).fill(0);
    const binSize = 256 / bins;

    if (!frame.data || frame.data.length === 0) {
      return histogram;
    }

    for (const row of frame.data) {
      if (!row) continue;
      for (let i = 0; i < row.length - 2; i += 3) {
        const r = Math.floor((row[i] || 0) / binSize);
        const g = Math.floor((row[i + 1] || 0) / binSize);
        const b = Math.floor((row[i + 2] || 0) / binSize);

        histogram[Math.min(r, bins - 1)]++;
        histogram[bins + Math.min(g, bins - 1)]++;
        histogram[2 * bins + Math.min(b, bins - 1)]++;
      }
    }

    // Normalize
    const total = frame.data.length * (frame.data[0]?.length || 0) / 3 || 1;
    return histogram.map(v => v / total);
  }

  /**
   * Calculate structural similarity between frames
   */
  private calculateStructuralSimilarity(frame1: Frame, frame2: Frame): number {
    // Simplified SSIM calculation
    const mean1 = this.calculateMeanIntensity(frame1);
    const mean2 = this.calculateMeanIntensity(frame2);

    const variance1 = this.calculateVariance(frame1, mean1);
    const variance2 = this.calculateVariance(frame2, mean2);

    const covariance = this.calculateCovariance(frame1, frame2, mean1, mean2);

    // SSIM constants
    const C1 = 0.01 * 0.01;
    const C2 = 0.03 * 0.03;

    const luminance = (2 * mean1 * mean2 + C1) / (mean1 * mean1 + mean2 * mean2 + C1);
    const contrast = (2 * Math.sqrt(variance1) * Math.sqrt(variance2) + C2) /
      (variance1 + variance2 + C2);
    const structure = (covariance + C2 / 2) / (Math.sqrt(variance1 * variance2) + C2 / 2);

    return luminance * contrast * structure;
  }

  /**
   * Calculate mean intensity
   */
  private calculateMeanIntensity(frame: Frame): number {
    if (!frame.data || frame.data.length === 0) return 0.5;

    let sum = 0;
    let count = 0;

    for (const row of frame.data) {
      if (!row) continue;
      for (let i = 0; i < row.length; i++) {
        sum += row[i] || 0;
        count++;
      }
    }

    return count > 0 ? sum / (count * 255) : 0.5;
  }

  /**
   * Calculate variance
   */
  private calculateVariance(frame: Frame, mean: number): number {
    if (!frame.data || frame.data.length === 0) return 0;

    let sum = 0;
    let count = 0;

    for (const row of frame.data) {
      if (!row) continue;
      for (let i = 0; i < row.length; i++) {
        const val = (row[i] || 0) / 255;
        sum += (val - mean) * (val - mean);
        count++;
      }
    }

    return count > 0 ? sum / count : 0;
  }

  /**
   * Calculate covariance between frames
   */
  private calculateCovariance(frame1: Frame, frame2: Frame, mean1: number, mean2: number): number {
    if (!frame1.data || !frame2.data) return 0;
    if (frame1.data.length === 0 || frame2.data.length === 0) return 0;

    let sum = 0;
    let count = 0;

    const minRows = Math.min(frame1.data.length, frame2.data.length);

    for (let r = 0; r < minRows; r++) {
      const row1 = frame1.data[r];
      const row2 = frame2.data[r];
      if (!row1 || !row2) continue;

      const minCols = Math.min(row1.length, row2.length);
      for (let c = 0; c < minCols; c++) {
        const val1 = (row1[c] || 0) / 255;
        const val2 = (row2[c] || 0) / 255;
        sum += (val1 - mean1) * (val2 - mean2);
        count++;
      }
    }

    return count > 0 ? sum / count : 0;
  }

  /**
   * Calculate brightness
   */
  private calculateBrightness(frame: Frame): number {
    return this.calculateMeanIntensity(frame);
  }

  /**
   * Calculate contrast
   */
  private calculateContrast(frame: Frame): number {
    return Math.sqrt(this.calculateVariance(frame, this.calculateMeanIntensity(frame)));
  }

  /**
   * Calculate saturation
   */
  private calculateSaturation(frame: Frame): number {
    if (!frame.data || frame.data.length === 0) return 0.5;

    let totalSaturation = 0;
    let count = 0;

    for (const row of frame.data) {
      if (!row) continue;
      for (let i = 0; i < row.length - 2; i += 3) {
        const r = (row[i] || 0) / 255;
        const g = (row[i + 1] || 0) / 255;
        const b = (row[i + 2] || 0) / 255;

        const max = Math.max(r, g, b);
        const min = Math.min(r, g, b);
        const l = (max + min) / 2;

        const saturation = l > 0 && l < 1
          ? (max - min) / (1 - Math.abs(2 * l - 1))
          : 0;

        totalSaturation += saturation;
        count++;
      }
    }

    return count > 0 ? totalSaturation / count : 0;
  }

  /**
   * Calculate frame anomaly score
   */
  private calculateFrameAnomalyScore(
    prevConsistency: number,
    nextConsistency: number,
    featureChanges: Array<{ name: string; change: number; threshold: number }>
  ): number {
    // Base anomaly from consistency
    let score = (1 - prevConsistency) * 0.4 + (1 - nextConsistency) * 0.4;

    // Add feature change penalties
    for (const change of featureChanges) {
      score += Math.min(change.change / change.threshold, 1) * 0.1;
    }

    return Math.min(score, 1);
  }

  /**
   * Detect flicker anomalies
   */
  private detectFlickerAnomalies(frames: Frame[]): TemporalAnomaly[] {
    const anomalies: TemporalAnomaly[] = [];
    const brightnessSequence: number[] = [];

    // Calculate brightness for each frame
    for (const frame of frames) {
      brightnessSequence.push(this.calculateBrightness(frame));
    }

    // Detect rapid brightness changes
    for (let i = 1; i < brightnessSequence.length - 1; i++) {
      const prev = brightnessSequence[i - 1];
      const curr = brightnessSequence[i];
      const next = brightnessSequence[i + 1];

      // Check for flicker pattern (up-down or down-up)
      const flickerMagnitude = Math.abs(curr - prev) + Math.abs(next - curr);

      if (flickerMagnitude > this.config.flickerThreshold * 2) {
        // Check if it's an isolated flicker
        const isIsolated = i < 2 || i >= brightnessSequence.length - 2 ||
          (Math.abs(brightnessSequence[i - 2] - brightnessSequence[i + 2]) < this.config.flickerThreshold);

        if (isIsolated) {
          anomalies.push({
            type: 'flicker',
            frames: [i - 1, i, i + 1],
            severity: Math.min(flickerMagnitude / (this.config.flickerThreshold * 4), 1),
            confidence: 0.8,
            description: `Flicker detected at frame ${i} with magnitude ${flickerMagnitude.toFixed(3)}`
          });
        }
      }
    }

    return this.mergeAdjacentAnomalies(anomalies, 'flicker');
  }

  /**
   * Detect jump anomalies (sudden changes)
   */
  private detectJumpAnomalies(frames: Frame[], frameAnalysis: FrameAnalysisResult[]): TemporalAnomaly[] {
    const anomalies: TemporalAnomaly[] = [];

    for (const analysis of frameAnalysis) {
      if (analysis.prevConsistency < 1 - this.config.jumpThreshold) {
        anomalies.push({
          type: 'jump',
          frames: [analysis.frameIndex - 1, analysis.frameIndex],
          severity: 1 - analysis.prevConsistency,
          confidence: 0.85,
          description: `Temporal jump detected between frames ${analysis.frameIndex - 1} and ${analysis.frameIndex}`
        });
      }
    }

    return anomalies;
  }

  /**
   * Detect morph anomalies (gradual unnatural changes)
   */
  private detectMorphAnomalies(frames: Frame[]): TemporalAnomaly[] {
    const anomalies: TemporalAnomaly[] = [];

    if (frames.length < 10) return anomalies;

    // Analyze face position stability if faces are detected
    const facePositions: Array<{ x: number; y: number } | null> = [];

    for (const frame of frames) {
      if (frame.faces && frame.faces.length > 0) {
        const face = frame.faces[0];
        facePositions.push({
          x: face.bbox.x + face.bbox.width / 2,
          y: face.bbox.y + face.bbox.height / 2
        });
      } else {
        facePositions.push(null);
      }
    }

    // Check for unnatural smooth motion (too smooth = morph)
    const validPositions = facePositions.filter(p => p !== null) as Array<{ x: number; y: number }>;

    if (validPositions.length > 5) {
      const velocityVariance = this.calculateVelocityVariance(validPositions);

      // Real videos have natural jitter; morph videos are often too smooth
      if (velocityVariance < 0.001) {
        anomalies.push({
          type: 'morph',
          frames: frames.map((_, i) => i),
          severity: 0.6,
          confidence: 0.7,
          description: 'Unusually smooth motion detected, possible morph manipulation'
        });
      }
    }

    return anomalies;
  }

  /**
   * Calculate velocity variance
   */
  private calculateVelocityVariance(positions: Array<{ x: number; y: number }>): number {
    if (positions.length < 2) return 0;

    const velocities: number[] = [];

    for (let i = 1; i < positions.length; i++) {
      const dx = positions[i].x - positions[i - 1].x;
      const dy = positions[i].y - positions[i - 1].y;
      velocities.push(Math.sqrt(dx * dx + dy * dy));
    }

    const mean = velocities.reduce((a, b) => a + b, 0) / velocities.length;
    const variance = velocities.reduce((a, v) => a + (v - mean) * (v - mean), 0) / velocities.length;

    return variance;
  }

  /**
   * Detect lighting inconsistencies
   */
  private detectLightingAnomalies(frames: Frame[]): TemporalAnomaly[] {
    const anomalies: TemporalAnomaly[] = [];
    const lightingFeatures: Array<{ brightness: number; contrast: number }> = [];

    for (const frame of frames) {
      lightingFeatures.push({
        brightness: this.calculateBrightness(frame),
        contrast: this.calculateContrast(frame)
      });
    }

    // Look for sudden lighting changes that shouldn't occur naturally
    for (let i = 1; i < lightingFeatures.length; i++) {
      const prev = lightingFeatures[i - 1];
      const curr = lightingFeatures[i];

      const brightnessChange = Math.abs(curr.brightness - prev.brightness);
      const contrastChange = Math.abs(curr.contrast - prev.contrast);

      if (brightnessChange > 0.2 || contrastChange > 0.3) {
        anomalies.push({
          type: 'lighting',
          frames: [i - 1, i],
          severity: Math.max(brightnessChange / 0.2, contrastChange / 0.3),
          confidence: 0.75,
          description: `Lighting inconsistency detected at frame ${i}`
        });
      }
    }

    return this.mergeAdjacentAnomalies(anomalies, 'lighting');
  }

  /**
   * Analyze motion patterns
   */
  private analyzeMotion(frames: Frame[]): MotionAnalysisResult {
    const motionMagnitudes: number[] = [];
    const suddenMotionEvents: Array<{ frameIndex: number; magnitude: number }> = [];

    for (let i = 1; i < frames.length; i++) {
      const motion = this.calculateMotionMagnitude(frames[i - 1], frames[i]);
      motionMagnitudes.push(motion);

      if (motion > this.config.motionThreshold) {
        suddenMotionEvents.push({
          frameIndex: i,
          magnitude: motion
        });
      }
    }

    const averageMotion = motionMagnitudes.length > 0
      ? motionMagnitudes.reduce((a, b) => a + b, 0) / motionMagnitudes.length
      : 0;

    const motionVariance = motionMagnitudes.length > 0
      ? motionMagnitudes.reduce((a, v) => a + (v - averageMotion) * (v - averageMotion), 0) / motionMagnitudes.length
      : 0;

    // Calculate smoothness (lower variance = smoother)
    const smoothness = 1 / (1 + Math.sqrt(motionVariance) * 10);

    // Calculate blur consistency
    const blurConsistency = this.calculateBlurConsistency(frames);

    return {
      averageMotion,
      motionVariance,
      smoothness,
      suddenMotionEvents,
      blurConsistency
    };
  }

  /**
   * Calculate motion magnitude between frames
   */
  private calculateMotionMagnitude(frame1: Frame, frame2: Frame): number {
    if (!frame1.data || !frame2.data) return 0;
    if (frame1.data.length === 0 || frame2.data.length === 0) return 0;

    // Simple block-based motion estimation
    const blockSize = 16;
    let totalMotion = 0;
    let blockCount = 0;

    const rows = Math.min(frame1.data.length, frame2.data.length);
    const cols = frame1.data[0]?.length || 0;

    for (let by = 0; by < rows - blockSize; by += blockSize) {
      for (let bx = 0; bx < cols - blockSize; bx += blockSize) {
        const motion = this.estimateBlockMotion(frame1, frame2, bx, by, blockSize);
        totalMotion += motion;
        blockCount++;
      }
    }

    return blockCount > 0 ? totalMotion / blockCount : 0;
  }

  /**
   * Estimate motion for a block
   */
  private estimateBlockMotion(
    frame1: Frame,
    frame2: Frame,
    bx: number,
    by: number,
    blockSize: number
  ): number {
    // Simple SAD (Sum of Absolute Differences) based motion estimation
    let minSAD = Infinity;

    // Search in a small neighborhood
    const searchRange = 8;

    for (let dy = -searchRange; dy <= searchRange; dy++) {
      for (let dx = -searchRange; dx <= searchRange; dx++) {
        let sad = 0;
        let count = 0;

        for (let y = 0; y < blockSize && by + y < frame1.data.length; y++) {
          const row1 = frame1.data[by + y];
          const row2Idx = by + y + dy;

          if (!row1 || row2Idx < 0 || row2Idx >= frame2.data.length) continue;
          const row2 = frame2.data[row2Idx];
          if (!row2) continue;

          for (let x = 0; x < blockSize && bx + x < row1.length; x++) {
            const col2Idx = bx + x + dx;
            if (col2Idx < 0 || col2Idx >= row2.length) continue;

            sad += Math.abs((row1[bx + x] || 0) - (row2[col2Idx] || 0));
            count++;
          }
        }

        if (count > 0) {
          sad /= count;
          if (sad < minSAD) {
            minSAD = sad;
          }
        }
      }
    }

    return minSAD / 255; // Normalize to 0-1
  }

  /**
   * Calculate blur consistency across frames
   */
  private calculateBlurConsistency(frames: Frame[]): number {
    if (frames.length < 2) return 1;

    const blurScores: number[] = [];

    for (const frame of frames) {
      blurScores.push(this.estimateBlur(frame));
    }

    // Calculate variance of blur scores
    const mean = blurScores.reduce((a, b) => a + b, 0) / blurScores.length;
    const variance = blurScores.reduce((a, v) => a + (v - mean) * (v - mean), 0) / blurScores.length;

    // Lower variance = more consistent
    return 1 / (1 + variance * 100);
  }

  /**
   * Estimate blur in frame using Laplacian variance
   */
  private estimateBlur(frame: Frame): number {
    if (!frame.data || frame.data.length < 3) return 0;

    let laplacianVariance = 0;
    let count = 0;

    for (let y = 1; y < frame.data.length - 1; y++) {
      const prevRow = frame.data[y - 1];
      const currRow = frame.data[y];
      const nextRow = frame.data[y + 1];

      if (!prevRow || !currRow || !nextRow) continue;

      for (let x = 1; x < currRow.length - 1; x++) {
        // Laplacian kernel
        const laplacian =
          -4 * (currRow[x] || 0) +
          (prevRow[x] || 0) +
          (nextRow[x] || 0) +
          (currRow[x - 1] || 0) +
          (currRow[x + 1] || 0);

        laplacianVariance += laplacian * laplacian;
        count++;
      }
    }

    return count > 0 ? laplacianVariance / count : 0;
  }

  /**
   * Analyze identity consistency across frames
   */
  private analyzeIdentityConsistency(frames: Frame[]): IdentityConsistencyResult {
    const embeddings: number[][] = [];

    for (const frame of frames) {
      if (frame.faces && frame.faces.length > 0) {
        embeddings.push(frame.faces[0].embedding);
      }
    }

    if (embeddings.length < 2) {
      return {
        overallScore: 1.0,
        driftDetected: false,
        segments: [{ startFrame: 0, endFrame: frames.length - 1, score: 1.0 }],
        faceCountVariance: 0
      };
    }

    // Calculate pairwise cosine similarities
    const similarities: number[] = [];

    for (let i = 1; i < embeddings.length; i++) {
      const sim = this.cosineSimilarity(embeddings[i - 1], embeddings[i]);
      similarities.push(sim);
    }

    const overallScore = similarities.reduce((a, b) => a + b, 0) / similarities.length;

    // Detect drift by looking at temporal trends
    const driftDetected = this.detectIdentityDrift(similarities);

    // Create segments
    const segments = this.createIdentitySegments(similarities);

    // Calculate face count variance
    const faceCounts = frames.map(f => f.faces?.length || 0);
    const meanFaceCount = faceCounts.reduce((a, b) => a + b, 0) / faceCounts.length;
    const faceCountVariance = faceCounts.reduce(
      (a, v) => a + (v - meanFaceCount) * (v - meanFaceCount),
      0
    ) / faceCounts.length;

    return {
      overallScore,
      driftDetected,
      segments,
      faceCountVariance
    };
  }

  /**
   * Calculate cosine similarity between vectors
   */
  private cosineSimilarity(a: number[], b: number[]): number {
    if (a.length !== b.length) return 0;

    let dotProduct = 0;
    let normA = 0;
    let normB = 0;

    for (let i = 0; i < a.length; i++) {
      dotProduct += a[i] * b[i];
      normA += a[i] * a[i];
      normB += b[i] * b[i];
    }

    if (normA === 0 || normB === 0) return 0;

    return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
  }

  /**
   * Detect identity drift from similarity sequence
   */
  private detectIdentityDrift(similarities: number[]): boolean {
    if (similarities.length < 5) return false;

    // Use sliding window to detect gradual decline
    const windowSize = Math.min(5, Math.floor(similarities.length / 3));

    let declineCount = 0;

    for (let i = windowSize; i < similarities.length; i++) {
      const prevAvg = similarities.slice(i - windowSize, i).reduce((a, b) => a + b, 0) / windowSize;
      const currAvg = similarities.slice(i - windowSize + 1, i + 1).reduce((a, b) => a + b, 0) / windowSize;

      if (currAvg < prevAvg - 0.02) {
        declineCount++;
      }
    }

    return declineCount > similarities.length * 0.3;
  }

  /**
   * Create identity consistency segments
   */
  private createIdentitySegments(similarities: number[]): Array<{
    startFrame: number;
    endFrame: number;
    score: number;
  }> {
    const segments: Array<{ startFrame: number; endFrame: number; score: number }> = [];

    let segmentStart = 0;
    let currentSum = similarities[0] || 1;

    for (let i = 1; i <= similarities.length; i++) {
      const sim = similarities[i] || 1;

      // Check if we should end current segment
      if (sim < this.config.identityThreshold || i === similarities.length) {
        segments.push({
          startFrame: segmentStart,
          endFrame: i,
          score: currentSum / (i - segmentStart)
        });

        segmentStart = i;
        currentSum = sim;
      } else {
        currentSum += sim;
      }
    }

    return segments;
  }

  /**
   * Merge adjacent anomalies of same type
   */
  private mergeAdjacentAnomalies(anomalies: TemporalAnomaly[], type: string): TemporalAnomaly[] {
    const filtered = anomalies.filter(a => a.type === type);
    if (filtered.length === 0) return [];

    filtered.sort((a, b) => a.frames[0] - b.frames[0]);

    const merged: TemporalAnomaly[] = [];
    let current = { ...filtered[0] };

    for (let i = 1; i < filtered.length; i++) {
      const lastFrame = current.frames[current.frames.length - 1];
      const firstFrame = filtered[i].frames[0];

      if (firstFrame - lastFrame <= 2) {
        // Merge
        current.frames = [...current.frames, ...filtered[i].frames];
        current.severity = Math.max(current.severity, filtered[i].severity);
      } else {
        merged.push(current);
        current = { ...filtered[i] };
      }
    }

    merged.push(current);
    return merged;
  }

  /**
   * Calculate overall consistency score
   */
  private calculateConsistencyScore(
    frameAnalysis: FrameAnalysisResult[],
    anomalies: TemporalAnomaly[]
  ): number {
    if (frameAnalysis.length === 0) return 1;

    // Base score from frame analysis
    const avgConsistency = frameAnalysis.reduce((a, f) => {
      return a + (f.prevConsistency + f.nextConsistency) / 2;
    }, 0) / frameAnalysis.length;

    // Penalty from anomalies
    let anomalyPenalty = 0;

    for (const anomaly of anomalies) {
      const weight = anomaly.severity * anomaly.confidence;
      anomalyPenalty += weight * (anomaly.frames.length / frameAnalysis.length);
    }

    return Math.max(0, avgConsistency - anomalyPenalty * 0.5);
  }

  /**
   * Calculate deepfake probability
   */
  private calculateDeepfakeProbability(consistencyScore: number, anomalies: TemporalAnomaly[]): number {
    // Higher anomaly count and lower consistency = higher deepfake probability
    let probability = 1 - consistencyScore;

    // Weight by anomaly types
    const typeWeights: Record<string, number> = {
      'flicker': 0.7,
      'jump': 0.8,
      'morph': 0.85,
      'identity_drift': 0.9,
      'lighting': 0.6,
      'occlusion': 0.3
    };

    for (const anomaly of anomalies) {
      const weight = typeWeights[anomaly.type] || 0.5;
      probability += (anomaly.severity * anomaly.confidence * weight) * 0.1;
    }

    return Math.min(probability, 1);
  }

  /**
   * Generate recommendations based on analysis
   */
  private generateRecommendations(anomalies: TemporalAnomaly[], consistencyScore: number): string[] {
    const recommendations: string[] = [];

    if (consistencyScore < 0.5) {
      recommendations.push('Low temporal consistency detected - high likelihood of manipulation');
    }

    const anomalyTypes = new Set(anomalies.map(a => a.type));

    if (anomalyTypes.has('flicker')) {
      recommendations.push('Frame flickering detected - may indicate face swapping artifacts');
    }

    if (anomalyTypes.has('jump')) {
      recommendations.push('Temporal jumps detected - possible frame insertion or deletion');
    }

    if (anomalyTypes.has('morph')) {
      recommendations.push('Unnatural smooth motion detected - possible morph-based manipulation');
    }

    if (anomalyTypes.has('identity_drift')) {
      recommendations.push('Identity drift detected - face identity changes across video');
    }

    if (anomalyTypes.has('lighting')) {
      recommendations.push('Lighting inconsistencies detected - may indicate compositing');
    }

    if (recommendations.length === 0) {
      recommendations.push('Video exhibits good temporal consistency');
    }

    return recommendations;
  }
}

// ============================================================================
// CONFIGURATION
// ============================================================================

export interface TemporalConfig {
  /** Analysis window size */
  windowSize: number;
  /** Threshold for flicker detection */
  flickerThreshold: number;
  /** Threshold for jump detection */
  jumpThreshold: number;
  /** Threshold for identity consistency */
  identityThreshold: number;
  /** Threshold for motion detection */
  motionThreshold: number;
  /** Smoothing window size */
  smoothingWindow: number;
}

// ============================================================================
// CONVENIENCE FUNCTIONS
// ============================================================================

/**
 * Analyze temporal consistency of video
 */
export function analyzeTemporalConsistency(
  frames: Frame[],
  config?: Partial<TemporalConfig>
): TemporalAnalysisResult {
  const analyzer = new TemporalConsistencyAnalyzer(config);
  return analyzer.analyzeFrames(frames);
}

/**
 * Detect temporal anomalies in video
 */
export function detectTemporalAnomalies(frames: Frame[]): TemporalAnomaly[] {
  const analyzer = new TemporalConsistencyAnalyzer();
  const result = analyzer.analyzeFrames(frames);
  return result.anomalies;
}

/**
 * Calculate motion smoothness score
 */
export function calculateMotionSmoothness(frames: Frame[]): number {
  const analyzer = new TemporalConsistencyAnalyzer();
  const result = analyzer.analyzeFrames(frames);
  return result.motionAnalysis.smoothness;
}

/**
 * Verify identity consistency across video
 */
export function verifyIdentityConsistency(frames: Frame[]): IdentityConsistencyResult {
  const analyzer = new TemporalConsistencyAnalyzer();
  const result = analyzer.analyzeFrames(frames);
  return result.identityConsistency;
}

// ============================================================================
// TESTS
// ============================================================================

/**
 * Run temporal consistency tests
 */
export function runTemporalConsistencyTests(): {
  passed: boolean;
  summary: { total: number; passed: number; failed: number };
  details: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const tests: Array<{ name: string; passed: boolean; error?: string }> = [];

  // Test 1: Analyzer instantiation
  try {
    const analyzer = new TemporalConsistencyAnalyzer();
    tests.push({ name: 'Analyzer instantiation', passed: true });
  } catch (error) {
    tests.push({ name: 'Analyzer instantiation', passed: false, error: String(error) });
  }

  // Test 2: Empty frames handling
  try {
    const analyzer = new TemporalConsistencyAnalyzer();
    const result = analyzer.analyzeFrames([]);
    tests.push({
      name: 'Empty frames handling',
      passed: result.consistencyScore === 1 && result.anomalies.length === 0
    });
  } catch (error) {
    tests.push({ name: 'Empty frames handling', passed: false, error: String(error) });
  }

  // Test 3: Single frame handling
  try {
    const analyzer = new TemporalConsistencyAnalyzer();
    const frame: Frame = {
      index: 0,
      timestamp: 0,
      width: 100,
      height: 100,
      data: [[128, 128, 128]]
    };
    const result = analyzer.analyzeFrames([frame]);
    tests.push({
      name: 'Single frame handling',
      passed: result.consistencyScore === 1
    });
  } catch (error) {
    tests.push({ name: 'Single frame handling', passed: false, error: String(error) });
  }

  // Test 4: Consistent frames
  try {
    const analyzer = new TemporalConsistencyAnalyzer();
    const frames: Frame[] = [];

    for (let i = 0; i < 10; i++) {
      frames.push({
        index: i,
        timestamp: i * 33,
        width: 100,
        height: 100,
        data: Array(100).fill(Array(300).fill(128))
      });
    }

    const result = analyzer.analyzeFrames(frames);
    tests.push({
      name: 'Consistent frames detection',
      passed: result.consistencyScore > 0.8
    });
  } catch (error) {
    tests.push({ name: 'Consistent frames detection', passed: false, error: String(error) });
  }

  // Test 5: Flicker detection
  try {
    const analyzer = new TemporalConsistencyAnalyzer();
    const frames: Frame[] = [];

    for (let i = 0; i < 10; i++) {
      const brightness = i === 5 ? 255 : 128; // Flicker at frame 5
      frames.push({
        index: i,
        timestamp: i * 33,
        width: 100,
        height: 100,
        data: Array(100).fill(Array(300).fill(brightness))
      });
    }

    const result = analyzer.analyzeFrames(frames);
    tests.push({
      name: 'Flicker detection',
      passed: result.anomalies.some(a => a.type === 'flicker' || a.type === 'lighting')
    });
  } catch (error) {
    tests.push({ name: 'Flicker detection', passed: false, error: String(error) });
  }

  // Test 6: Motion analysis
  try {
    const analyzer = new TemporalConsistencyAnalyzer();
    const frames: Frame[] = [];

    for (let i = 0; i < 30; i++) {
      frames.push({
        index: i,
        timestamp: i * 33,
        width: 100,
        height: 100,
        data: Array(100).fill(Array(300).fill(128 + (i % 10)))
      });
    }

    const result = analyzer.analyzeFrames(frames);
    tests.push({
      name: 'Motion analysis',
      passed: result.motionAnalysis !== undefined &&
        typeof result.motionAnalysis.smoothness === 'number'
    });
  } catch (error) {
    tests.push({ name: 'Motion analysis', passed: false, error: String(error) });
  }

  // Test 7: Identity consistency
  try {
    const analyzer = new TemporalConsistencyAnalyzer();
    const frames: Frame[] = [];

    for (let i = 0; i < 10; i++) {
      frames.push({
        index: i,
        timestamp: i * 33,
        width: 100,
        height: 100,
        data: Array(100).fill(Array(300).fill(128)),
        faces: [{
          bbox: { x: 10, y: 10, width: 50, height: 50 },
          landmarks: {
            points: [],
            leftEye: { x: 20, y: 25 },
            rightEye: { x: 40, y: 25 },
            nose: { x: 30, y: 35 },
            mouth: { x: 30, y: 45 },
            chin: { x: 30, y: 55 }
          },
          embedding: Array(128).fill(0.5 + i * 0.001),
          confidence: 0.95
        }]
      });
    }

    const result = analyzer.analyzeFrames(frames);
    tests.push({
      name: 'Identity consistency analysis',
      passed: result.identityConsistency !== undefined &&
        typeof result.identityConsistency.overallScore === 'number'
    });
  } catch (error) {
    tests.push({ name: 'Identity consistency analysis', passed: false, error: String(error) });
  }

  // Test 8: Configuration options
  try {
    const analyzer = new TemporalConsistencyAnalyzer({
      windowSize: 60,
      flickerThreshold: 0.1,
      jumpThreshold: 0.2
    });
    tests.push({ name: 'Configuration options', passed: true });
  } catch (error) {
    tests.push({ name: 'Configuration options', passed: false, error: String(error) });
  }

  // Test 9: Convenience functions
  try {
    const frames: Frame[] = [{
      index: 0,
      timestamp: 0,
      width: 100,
      height: 100,
      data: [[128, 128, 128]]
    }];

    const result = analyzeTemporalConsistency(frames);
    const anomalies = detectTemporalAnomalies(frames);
    const smoothness = calculateMotionSmoothness(frames);
    const identity = verifyIdentityConsistency(frames);

    tests.push({
      name: 'Convenience functions',
      passed: result !== undefined &&
        Array.isArray(anomalies) &&
        typeof smoothness === 'number' &&
        identity !== undefined
    });
  } catch (error) {
    tests.push({ name: 'Convenience functions', passed: false, error: String(error) });
  }

  // Test 10: Recommendations generation
  try {
    const analyzer = new TemporalConsistencyAnalyzer();

    // Create frames with some anomalies
    const frames: Frame[] = [];
    for (let i = 0; i < 20; i++) {
      const brightness = i % 5 === 0 ? 255 : 128;
      frames.push({
        index: i,
        timestamp: i * 33,
        width: 100,
        height: 100,
        data: Array(100).fill(Array(300).fill(brightness))
      });
    }

    const result = analyzer.analyzeFrames(frames);
    tests.push({
      name: 'Recommendations generation',
      passed: result.recommendations.length > 0
    });
  } catch (error) {
    tests.push({ name: 'Recommendations generation', passed: false, error: String(error) });
  }

  const passed = tests.filter(t => t.passed).length;
  const failed = tests.filter(t => !t.passed).length;

  return {
    passed: failed === 0,
    summary: { total: tests.length, passed, failed },
    details: tests
  };
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

const temporalConsistencyModule = {
  TemporalConsistencyAnalyzer,
  analyzeTemporalConsistency,
  detectTemporalAnomalies,
  calculateMotionSmoothness,
  verifyIdentityConsistency,
  runTemporalConsistencyTests
};

export default temporalConsistencyModule;
