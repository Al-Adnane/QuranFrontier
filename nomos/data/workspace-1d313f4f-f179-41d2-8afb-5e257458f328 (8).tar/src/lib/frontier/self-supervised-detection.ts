/**
 * Kasbah Self-Supervised Detection Engine
 * Real training loops, contrastive learning, and feature extraction
 * 
 * @module self-supervised-detection
 * @version 2.0.0
 */

// ============================================
// TENSOR OPERATIONS
// ============================================

export class Tensor {
  constructor(
    public data: Float32Array,
    public shape: number[]
  ) {}

  static zeros(shape: number[]): Tensor {
    const size = shape.reduce((a, b) => a * b, 1);
    return new Tensor(new Float32Array(size), shape);
  }

  static random(shape: number[], scale: number = 0.1): Tensor {
    const size = shape.reduce((a, b) => a * b, 1);
    const data = new Float32Array(size);
    for (let i = 0; i < size; i++) {
      data[i] = (Math.random() - 0.5) * 2 * scale;
    }
    return new Tensor(data, shape);
  }

  static fromArray(arr: number[]): Tensor {
    return new Tensor(new Float32Array(arr), [arr.length]);
  }

  get(indices: number[]): number {
    let idx = 0;
    let stride = 1;
    for (let i = this.shape.length - 1; i >= 0; i--) {
      idx += indices[i] * stride;
      stride *= this.shape[i];
    }
    return this.data[idx];
  }

  set(indices: number[], value: number): void {
    let idx = 0;
    let stride = 1;
    for (let i = this.shape.length - 1; i >= 0; i--) {
      idx += indices[i] * stride;
      stride *= this.shape[i];
    }
    this.data[idx] = value;
  }

  add(other: Tensor): Tensor {
    if (this.shape.length !== other.shape.length) {
      throw new Error('Shape mismatch');
    }
    const result = new Tensor(new Float32Array(this.data.length), [...this.shape]);
    for (let i = 0; i < this.data.length; i++) {
      result.data[i] = this.data[i] + other.data[i];
    }
    return result;
  }

  sub(other: Tensor): Tensor {
    const result = new Tensor(new Float32Array(this.data.length), [...this.shape]);
    for (let i = 0; i < this.data.length; i++) {
      result.data[i] = this.data[i] - other.data[i];
    }
    return result;
  }

  mul(scalar: number): Tensor {
    const result = new Tensor(new Float32Array(this.data.length), [...this.shape]);
    for (let i = 0; i < this.data.length; i++) {
      result.data[i] = this.data[i] * scalar;
    }
    return result;
  }

  dot(other: Tensor): Tensor {
    // Matrix multiplication
    if (this.shape.length !== 2 || other.shape.length !== 2) {
      throw new Error('Only 2D tensors supported for dot');
    }
    
    const [m, k1] = this.shape;
    const [k2, n] = other.shape;
    
    if (k1 !== k2) {
      throw new Error(`Shape mismatch: [${m},${k1}] @ [${k2},${n}]`);
    }
    
    const k = k1;
    const result = new Tensor(new Float32Array(m * n), [m, n]);
    
    for (let i = 0; i < m; i++) {
      for (let j = 0; j < n; j++) {
        let sum = 0;
        for (let l = 0; l < k; l++) {
          sum += this.data[i * k + l] * other.data[l * n + j];
        }
        result.data[i * n + j] = sum;
      }
    }
    
    return result;
  }

  transpose(): Tensor {
    if (this.shape.length !== 2) {
      throw new Error('Only 2D tensors supported for transpose');
    }
    
    const [m, n] = this.shape;
    const result = new Tensor(new Float32Array(m * n), [n, m]);
    
    for (let i = 0; i < m; i++) {
      for (let j = 0; j < n; j++) {
        result.data[j * m + i] = this.data[i * n + j];
      }
    }
    
    return result;
  }

  sum(): number {
    return this.data.reduce((a, b) => a + b, 0);
  }

  mean(): number {
    return this.sum() / this.data.length;
  }

  norm(): number {
    return Math.sqrt(this.data.reduce((sum, x) => sum + x * x, 0));
  }

  normalize(): Tensor {
    const norm = this.norm();
    if (norm === 0) return this;
    return this.mul(1 / norm);
  }

  relu(): Tensor {
    const result = new Tensor(new Float32Array(this.data.length), [...this.shape]);
    for (let i = 0; i < this.data.length; i++) {
      result.data[i] = Math.max(0, this.data[i]);
    }
    return result;
  }

  sigmoid(): Tensor {
    const result = new Tensor(new Float32Array(this.data.length), [...this.shape]);
    for (let i = 0; i < this.data.length; i++) {
      result.data[i] = 1 / (1 + Math.exp(-this.data[i]));
    }
    return result;
  }

  softmax(): Tensor {
    const result = new Tensor(new Float32Array(this.data.length), [...this.shape]);
    
    // Find max for numerical stability
    let max = -Infinity;
    for (let i = 0; i < this.data.length; i++) {
      max = Math.max(max, this.data[i]);
    }
    
    // Compute exp(x - max)
    let sum = 0;
    for (let i = 0; i < this.data.length; i++) {
      result.data[i] = Math.exp(this.data[i] - max);
      sum += result.data[i];
    }
    
    // Normalize
    for (let i = 0; i < this.data.length; i++) {
      result.data[i] /= sum;
    }
    
    return result;
  }

  clone(): Tensor {
    return new Tensor(new Float32Array(this.data), [...this.shape]);
  }
}

// ============================================
// NEURAL NETWORK LAYERS
// ============================================

export interface Layer {
  forward(x: Tensor): Tensor;
  backward(gradOutput: Tensor): Tensor;
  updateParams(learningRate: number): void;
  getParams(): Tensor[];
  getGrads(): Tensor[];
}

export class LinearLayer implements Layer {
  private weights: Tensor;
  private bias: Tensor;
  private input: Tensor | null = null;
  private weightGrad: Tensor;
  private biasGrad: Tensor;

  constructor(inputSize: number, outputSize: number) {
    // Xavier initialization
    const scale = Math.sqrt(2 / (inputSize + outputSize));
    this.weights = Tensor.random([inputSize, outputSize], scale);
    this.bias = Tensor.zeros([outputSize]);
    this.weightGrad = Tensor.zeros([inputSize, outputSize]);
    this.biasGrad = Tensor.zeros([outputSize]);
  }

  forward(x: Tensor): Tensor {
    this.input = x.clone();
    // y = x @ W + b
    const out = x.dot(this.weights);
    return out.add(this.bias);
  }

  backward(gradOutput: Tensor): Tensor {
    if (!this.input) throw new Error('Forward not called');
    
    // dL/dW = x^T @ gradOutput
    this.weightGrad = this.input.transpose().dot(gradOutput);
    
    // dL/db = sum(gradOutput, axis=0)
    this.biasGrad = gradOutput;
    
    // dL/dx = gradOutput @ W^T
    return gradOutput.dot(this.weights.transpose());
  }

  updateParams(learningRate: number): void {
    this.weights = this.weights.sub(this.weightGrad.mul(learningRate));
    this.bias = this.bias.sub(this.biasGrad.mul(learningRate));
  }

  getParams(): Tensor[] {
    return [this.weights, this.bias];
  }

  getGrads(): Tensor[] {
    return [this.weightGrad, this.biasGrad];
  }
}

export class ReLULayer implements Layer {
  private input: Tensor | null = null;

  forward(x: Tensor): Tensor {
    this.input = x.clone();
    return x.relu();
  }

  backward(gradOutput: Tensor): Tensor {
    if (!this.input) throw new Error('Forward not called');
    
    const grad = new Tensor(new Float32Array(this.input.data.length), [...this.input.shape]);
    for (let i = 0; i < this.input.data.length; i++) {
      grad.data[i] = this.input.data[i] > 0 ? gradOutput.data[i] : 0;
    }
    return grad;
  }

  updateParams(_learningRate: number): void {}
  getParams(): Tensor[] { return []; }
  getGrads(): Tensor[] { return []; }
}

export class LayerNorm implements Layer {
  private gamma: Tensor;
  private beta: Tensor;
  private gammaGrad: Tensor;
  private betaGrad: Tensor;
  private normalized: Tensor | null = null;
  private std: number = 1;

  constructor(size: number) {
    this.gamma = Tensor.fromArray(Array(size).fill(1));
    this.beta = Tensor.fromArray(Array(size).fill(0));
    this.gammaGrad = Tensor.zeros([size]);
    this.betaGrad = Tensor.zeros([size]);
  }

  forward(x: Tensor): Tensor {
    const mean = x.mean();
    const variance = x.data.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / x.data.length;
    this.std = Math.sqrt(variance + 1e-8);
    
    // Normalize
    this.normalized = new Tensor(
      new Float32Array(x.data.map(v => (v - mean) / this.std)),
      [...x.shape]
    );
    
    // Scale and shift
    return this.normalized.mul(1).add(this.beta); // gamma * normalized + beta
  }

  backward(gradOutput: Tensor): Tensor {
    // Simplified backward for layer norm
    this.gammaGrad = gradOutput;
    this.betaGrad = gradOutput;
    return gradOutput.mul(1); // gamma
  }

  updateParams(learningRate: number): void {
    this.gamma = this.gamma.sub(this.gammaGrad.mul(learningRate));
    this.beta = this.beta.sub(this.betaGrad.mul(learningRate));
  }

  getParams(): Tensor[] { return [this.gamma, this.beta]; }
  getGrads(): Tensor[] { return [this.gammaGrad, this.betaGrad]; }
}

// ============================================
// CONTRASTIVE LEARNING MODEL
// ============================================

export class ContrastiveModel {
  private encoder: Layer[];
  private projector: Layer[];

  constructor(
    inputSize: number,
    hiddenSize: number = 256,
    projectionSize: number = 128
  ) {
    // Encoder network
    this.encoder = [
      new LinearLayer(inputSize, hiddenSize),
      new ReLULayer(),
      new LinearLayer(hiddenSize, hiddenSize),
      new ReLULayer(),
    ];

    // Projection head
    this.projector = [
      new LinearLayer(hiddenSize, hiddenSize),
      new ReLULayer(),
      new LinearLayer(hiddenSize, projectionSize)
    ];
  }

  forward(x: Tensor): { embedding: Tensor; projection: Tensor } {
    let h = x;
    for (const layer of this.encoder) {
      h = layer.forward(h);
    }
    
    let z = h;
    for (const layer of this.projector) {
      z = layer.forward(z);
    }
    
    return { embedding: h, projection: z.normalize() };
  }

  backward(grad: Tensor): void {
    let g = grad;
    for (let i = this.projector.length - 1; i >= 0; i--) {
      g = this.projector[i].backward(g);
    }
    for (let i = this.encoder.length - 1; i >= 0; i--) {
      g = this.encoder[i].backward(g);
    }
  }

  updateParams(learningRate: number): void {
    for (const layer of [...this.encoder, ...this.projector]) {
      layer.updateParams(learningRate);
    }
  }

  getParams(): Tensor[] {
    const params: Tensor[] = [];
    for (const layer of [...this.encoder, ...this.projector]) {
      params.push(...layer.getParams());
    }
    return params;
  }
}

// ============================================
// NT-XENT LOSS (Normalized Temperature-scaled Cross Entropy)
// ============================================

export class NTXentLoss {
  constructor(private temperature: number = 0.5) {}

  /**
   * Compute contrastive loss for a batch
   */
  compute(
    projections1: Tensor[],
    projections2: Tensor[]
  ): { loss: number; grads: Tensor[] } {
    const batchSize = projections1.length;
    const dim = projections1[0].data.length;
    
    // Stack all projections
    const allProjs = [...projections1, ...projections2];
    const totalSize = allProjs.length;
    
    // Compute similarity matrix
    const simMatrix = this.computeSimilarityMatrix(allProjs);
    
    // Create labels (positive pairs)
    const labels: number[] = [];
    for (let i = 0; i < batchSize; i++) {
      labels.push(i + batchSize); // i's positive is i + batchSize
    }
    for (let i = batchSize; i < totalSize; i++) {
      labels.push(i - batchSize); // i's positive is i - batchSize
    }
    
    // Apply temperature
    const scaledSim = simMatrix.map(row => 
      row.map(s => s / this.temperature)
    );
    
    // Compute softmax and loss
    let totalLoss = 0;
    const grads: Tensor[] = [];
    
    for (let i = 0; i < totalSize; i++) {
      // Softmax
      const maxSim = Math.max(...scaledSim[i]);
      const expSims = scaledSim[i].map(s => Math.exp(s - maxSim));
      const sumExp = expSims.reduce((a, b) => a + b, 0);
      const probs = expSims.map(e => e / sumExp);
      
      // Cross entropy loss
      totalLoss -= Math.log(probs[labels[i]] + 1e-10);
      
      // Gradient
      const grad = new Tensor(new Float32Array(dim), [dim]);
      for (let j = 0; j < totalSize; j++) {
        const g = probs[j] - (j === labels[i] ? 1 : 0);
        // Gradient w.r.t. projection
        const diff = allProjs[i].sub(allProjs[j]);
        const norm = allProjs[i].norm() * allProjs[j].norm();
        const gradScale = g / (this.temperature * norm);
        for (let k = 0; k < dim; k++) {
          grad.data[k] += gradScale * diff.data[k];
        }
      }
      grads.push(grad);
    }
    
    return {
      loss: totalLoss / totalSize,
      grads: grads.slice(0, batchSize) // Only return grads for first half
    };
  }

  private computeSimilarityMatrix(vectors: Tensor[]): number[][] {
    const n = vectors.length;
    const matrix: number[][] = [];
    
    for (let i = 0; i < n; i++) {
      matrix[i] = [];
      for (let j = 0; j < n; j++) {
        if (i === j) {
          matrix[i][j] = -Infinity; // Mask self-similarity
        } else {
          // Cosine similarity
          const vi = vectors[i].normalize();
          const vj = vectors[j].normalize();
          let dot = 0;
          for (let k = 0; k < vi.data.length; k++) {
            dot += vi.data[k] * vj.data[k];
          }
          matrix[i][j] = dot;
        }
      }
    }
    
    return matrix;
  }
}

// ============================================
// DATA AUGMENTATION
// ============================================

export class DataAugmentation {
  /**
   * Apply random augmentations to create positive pair
   */
  augment(input: Float32Array): { view1: Float32Array; view2: Float32Array } {
    return {
      view1: this.applyTransforms(input, this.sampleTransforms()),
      view2: this.applyTransforms(input, this.sampleTransforms())
    };
  }

  private sampleTransforms(): Transform[] {
    const transforms: Transform[] = [];
    
    // Random noise
    if (Math.random() > 0.5) {
      transforms.push({ type: 'noise', params: { std: 0.05 + Math.random() * 0.1 } });
    }
    
    // Random scaling
    if (Math.random() > 0.5) {
      transforms.push({ type: 'scale', params: { factor: 0.8 + Math.random() * 0.4 } });
    }
    
    // Random mask
    if (Math.random() > 0.7) {
      transforms.push({ 
        type: 'mask', 
        params: { 
          start: Math.floor(Math.random() * input.length * 0.5),
          length: Math.floor(Math.random() * input.length * 0.3)
        } 
      });
    }
    
    // Random permutation (shuffle small segments)
    if (Math.random() > 0.8) {
      transforms.push({ type: 'permute', params: { blockSize: 10 } });
    }
    
    return transforms;
  }

  private applyTransforms(input: Float32Array, transforms: Transform[]): Float32Array {
    const output = new Float32Array(input);
    
    for (const transform of transforms) {
      switch (transform.type) {
        case 'noise':
          const std = transform.params.std;
          for (let i = 0; i < output.length; i++) {
            output[i] += (Math.random() - 0.5) * 2 * std;
          }
          break;
          
        case 'scale':
          const factor = transform.params.factor;
          for (let i = 0; i < output.length; i++) {
            output[i] *= factor;
          }
          break;
          
        case 'mask':
          const { start, length } = transform.params;
          for (let i = start; i < Math.min(start + length, output.length); i++) {
            output[i] = 0;
          }
          break;
          
        case 'permute':
          const blockSize = transform.params.blockSize;
          for (let i = 0; i < output.length - blockSize; i += blockSize) {
            if (Math.random() > 0.5) {
              const j = Math.floor(Math.random() * (output.length - blockSize));
              for (let k = 0; k < blockSize; k++) {
                const temp = output[i + k];
                output[i + k] = output[j + k];
                output[j + k] = temp;
              }
            }
          }
          break;
      }
    }
    
    return output;
  }
}

interface Transform {
  type: 'noise' | 'scale' | 'mask' | 'permute';
  params: Record<string, number>;
}

// ============================================
// TRAINING LOOP
// ============================================

export class ContrastiveTrainer {
  private model: ContrastiveModel;
  private loss: NTXentLoss;
  private augmentation: DataAugmentation;
  private optimizer: SGDOptimizer;

  constructor(
    inputSize: number,
    hiddenSize: number = 256,
    projectionSize: number = 128,
    learningRate: number = 0.001
  ) {
    this.model = new ContrastiveModel(inputSize, hiddenSize, projectionSize);
    this.loss = new NTXentLoss(0.5);
    this.augmentation = new DataAugmentation();
    this.optimizer = new SGDOptimizer(learningRate);
  }

  /**
   * Train for one epoch
   */
  async trainEpoch(
    data: Float32Array[],
    batchSize: number = 32,
    onBatch?: (batch: number, loss: number) => void
  ): Promise<{ avgLoss: number; batches: number }> {
    // Shuffle data
    const shuffled = [...data].sort(() => Math.random() - 0.5);
    
    let totalLoss = 0;
    let batchCount = 0;
    
    for (let i = 0; i < shuffled.length; i += batchSize) {
      const batch = shuffled.slice(i, Math.min(i + batchSize, shuffled.length));
      
      // Create augmented views
      const views1: Tensor[] = [];
      const views2: Tensor[] = [];
      
      for (const sample of batch) {
        const { view1, view2 } = this.augmentation.augment(sample);
        views1.push(new Tensor(view1, [view1.length]));
        views2.push(new Tensor(view2, [view2.length]));
      }
      
      // Forward pass
      const projections1 = views1.map(v => this.model.forward(v).projection);
      const projections2 = views2.map(v => this.model.forward(v).projection);
      
      // Compute loss and gradients
      const { loss: batchLoss, grads } = this.loss.compute(projections1, projections2);
      totalLoss += batchLoss;
      
      // Backward pass
      for (const grad of grads) {
        this.model.backward(grad);
      }
      
      // Update parameters
      this.model.updateParams(this.optimizer.learningRate);
      
      batchCount++;
      
      if (onBatch) {
        onBatch(batchCount, batchLoss);
      }
    }
    
    return {
      avgLoss: totalLoss / batchCount,
      batches: batchCount
    };
  }

  /**
   * Extract embeddings
   */
  extractEmbedding(input: Float32Array): Float32Array {
    const tensor = new Tensor(input, [input.length]);
    const { embedding } = this.model.forward(tensor);
    return embedding.data;
  }

  /**
   * Get model
   */
  getModel(): ContrastiveModel {
    return this.model;
  }
}

class SGDOptimizer {
  constructor(public learningRate: number) {}
}

// ============================================
// K-NEAREST NEIGHBORS FOR ANOMALY DETECTION
// ============================================

export class KNNDetector {
  private embeddings: Float32Array[] = [];
  private labels: number[] = [];
  private k: number;

  constructor(k: number = 5) {
    this.k = k;
  }

  /**
   * Add reference embedding
   */
  addReference(embedding: Float32Array, label: number = 0): void {
    this.embeddings.push(embedding);
    this.labels.push(label);
  }

  /**
   * Find k nearest neighbors
   */
  findNeighbors(query: Float32Array): Array<{ distance: number; label: number; index: number }> {
    const distances: Array<{ distance: number; label: number; index: number }> = [];
    
    for (let i = 0; i < this.embeddings.length; i++) {
      const dist = this.euclideanDistance(query, this.embeddings[i]);
      distances.push({ distance: dist, label: this.labels[i], index: i });
    }
    
    return distances
      .sort((a, b) => a.distance - b.distance)
      .slice(0, this.k);
  }

  /**
   * Compute anomaly score
   */
  computeAnomalyScore(query: Float32Array): number {
    const neighbors = this.findNeighbors(query);
    
    // Average distance to k nearest neighbors
    const avgDistance = neighbors.reduce((sum, n) => sum + n.distance, 0) / neighbors.length;
    
    // Normalize by typical distance
    const allDistances: number[] = [];
    for (let i = 0; i < this.embeddings.length; i++) {
      for (let j = i + 1; j < this.embeddings.length; j++) {
        allDistances.push(this.euclideanDistance(this.embeddings[i], this.embeddings[j]));
      }
    }
    
    const meanDist = allDistances.reduce((a, b) => a + b, 0) / allDistances.length;
    const stdDist = Math.sqrt(
      allDistances.reduce((sum, d) => sum + Math.pow(d - meanDist, 2), 0) / allDistances.length
    );
    
    // Z-score as anomaly score
    return stdDist > 0 ? (avgDistance - meanDist) / stdDist : 0;
  }

  /**
   * Classify using k-NN voting
   */
  classify(query: Float32Array): { label: number; confidence: number } {
    const neighbors = this.findNeighbors(query);
    
    // Vote
    const votes: Record<number, number> = {};
    for (const n of neighbors) {
      votes[n.label] = (votes[n.label] || 0) + 1;
    }
    
    // Find majority
    let maxVotes = 0;
    let label = 0;
    for (const [l, v] of Object.entries(votes)) {
      if (v > maxVotes) {
        maxVotes = v;
        label = parseInt(l);
      }
    }
    
    return {
      label,
      confidence: maxVotes / this.k
    };
  }

  private euclideanDistance(a: Float32Array, b: Float32Array): number {
    let sum = 0;
    for (let i = 0; i < Math.min(a.length, b.length); i++) {
      sum += Math.pow(a[i] - b[i], 2);
    }
    return Math.sqrt(sum);
  }
}

// ============================================
// SELF-SUPERVISED DETECTION SUITE
// ============================================

export class SelfSupervisedDetectionSuite {
  private trainer: ContrastiveTrainer | null = null;
  private knnDetector: KNNDetector;
  private inputSize: number;
  private trained: boolean = false;

  constructor(inputSize: number = 256) {
    this.inputSize = inputSize;
    this.knnDetector = new KNNDetector(5);
  }

  /**
   * Train on unlabeled data
   */
  async train(
    data: Float32Array[],
    epochs: number = 10,
    batchSize: number = 32,
    onProgress?: (epoch: number, loss: number) => void
  ): Promise<void> {
    this.trainer = new ContrastiveTrainer(this.inputSize);
    
    for (let epoch = 0; epoch < epochs; epoch++) {
      const result = await this.trainer.trainEpoch(data, batchSize, (_batch, loss) => {
        if (onProgress) {
          onProgress(epoch, loss);
        }
      });
      
      if (onProgress) {
        onProgress(epoch, result.avgLoss);
      }
    }
    
    // Extract embeddings and add to KNN detector
    for (const sample of data) {
      const embedding = this.trainer!.extractEmbedding(sample);
      this.knnDetector.addReference(embedding, 0); // All training data is "normal"
    }
    
    this.trained = true;
  }

  /**
   * Detect anomaly
   */
  async detect(input: Float32Array): Promise<{
    isAnomaly: boolean;
    anomalyScore: number;
    nearestNeighbors: number[];
    confidence: number;
  }> {
    if (!this.trainer || !this.trained) {
      throw new Error('Model not trained');
    }
    
    const embedding = this.trainer.extractEmbedding(input);
    const anomalyScore = this.knnDetector.computeAnomalyScore(embedding);
    const neighbors = this.knnDetector.findNeighbors(embedding);
    
    // Threshold: z-score > 2 is anomalous
    const isAnomaly = anomalyScore > 2;
    
    return {
      isAnomaly,
      anomalyScore,
      nearestNeighbors: neighbors.map(n => n.index),
      confidence: Math.min(1, Math.abs(anomalyScore) / 3)
    };
  }

  /**
   * Get training status
   */
  isTrained(): boolean {
    return this.trained;
  }
}

// ============================================
// EXPORTS
// ============================================

export const selfSupervisedDetection = {
  Tensor,
  LinearLayer,
  ReLULayer,
  LayerNorm,
  ContrastiveModel,
  NTXentLoss,
  DataAugmentation,
  ContrastiveTrainer,
  KNNDetector,
  SelfSupervisedDetectionSuite
};

export default selfSupervisedDetection;
