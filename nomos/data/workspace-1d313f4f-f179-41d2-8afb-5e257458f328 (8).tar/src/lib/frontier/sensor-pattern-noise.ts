/**
 * Kasbah Sensor Pattern Noise (PRNU) Detection Engine
 * Photo Response Non-Uniformity analysis for camera fingerprinting
 * Identify source camera, detect manipulation, verify authenticity
 * 
 * @module sensor-pattern-noise
 * @version 1.0.0
 * @disruption-score +3.5/10
 * 
 * Capabilities:
 * - Camera fingerprint extraction
 * - Source camera identification
 * - Image manipulation detection
 * - Device attribution
 * - Forgery localization
 * - Authenticity verification
 */

// ============================================
// TYPE DEFINITIONS
// ============================================

export interface PRNUResult {
  id: string;
  timestamp: Date;
  hasValidPRNU: boolean;
  cameraFingerprint: number[];
  fingerprintQuality: number;
  sourceAttribution: SourceAttribution | null;
  manipulationDetected: boolean;
  manipulationRegions: ManipulationRegion[];
  analysis: {
    noiseExtraction: NoiseExtractionResult;
    fingerprintMatch: FingerprintMatchResult;
    consistencyCheck: ConsistencyResult;
  };
}

export interface SourceAttribution {
  manufacturer: string;
  model: string | null;
  confidence: number;
  fingerprintId: string;
}

export interface ManipulationRegion {
  x: number;
  y: number;
  width: number;
  height: number;
  type: 'inconsistency' | 'splicing' | 'copy_move' | 'unknown';
  confidence: number;
}

export interface NoiseExtractionResult {
  prnuEstimate: number[];
  quality: number;
  noiseLevel: number;
  convergenceRate: number;
}

export interface FingerprintMatchResult {
  matched: boolean;
  matchScore: number;
  candidateCameras: Array<{
    fingerprintId: string;
    score: number;
  }>;
}

export interface ConsistencyResult {
  globalConsistency: number;
  localConsistencies: number[];
  suspiciousRegions: number;
}

// ============================================
// PRNU EXTRACTOR
// ============================================

class PRNUExtractor {
  /**
   * Extract PRNU fingerprint from image
   * Uses wavelet-based denoising for accurate extraction
   */
  extract(
    imageData: number[][],
    width: number,
    height: number
  ): NoiseExtractionResult {
    // Step 1: Denoise image to get noise residual
    const denoised = this.denoiseImage(imageData, width, height);
    const noiseResidual = this.computeNoiseResidual(imageData, denoised, width, height);
    
    // Step 2: Extract PRNU pattern from noise
    const prnuEstimate = this.extractPRNUPattern(noiseResidual, width, height);
    
    // Step 3: Assess quality
    const quality = this.assessQuality(prnuEstimate, noiseResidual, width, height);
    const noiseLevel = this.computeNoiseLevel(noiseResidual, width, height);
    const convergenceRate = this.computeConvergence(prnuEstimate);
    
    return {
      prnuEstimate,
      quality,
      noiseLevel,
      convergenceRate
    };
  }

  private denoiseImage(
    image: number[][],
    width: number,
    height: number
  ): number[][] {
    // Wavelet-inspired denoising using multi-scale filtering
    
    // Level 1: Large-scale smoothing
    const level1 = this.gaussianBlur(image, width, height, 5);
    
    // Level 2: Medium-scale
    const level2 = this.gaussianBlur(image, width, height, 3);
    
    // Level 3: Edge-preserving
    const level3 = this.bilateralFilter(image, width, height);
    
    // Combine levels
    const denoised: number[][] = [];
    for (let y = 0; y < height; y++) {
      denoised[y] = [];
      for (let x = 0; x < width; x++) {
        denoised[y][x] = (level1[y][x] + level2[y][x] + level3[y][x]) / 3;
      }
    }
    
    return denoised;
  }

  private gaussianBlur(
    image: number[][],
    width: number,
    height: number,
    kernelSize: number
  ): number[][] {
    const result: number[][] = [];
    const halfKernel = Math.floor(kernelSize / 2);
    
    // Create Gaussian kernel
    const kernel: number[][] = [];
    const sigma = kernelSize / 3;
    let sum = 0;
    
    for (let y = 0; y < kernelSize; y++) {
      kernel[y] = [];
      for (let x = 0; x < kernelSize; x++) {
        const dx = x - halfKernel;
        const dy = y - halfKernel;
        kernel[y][x] = Math.exp(-(dx * dx + dy * dy) / (2 * sigma * sigma));
        sum += kernel[y][x];
      }
    }
    
    // Normalize kernel
    for (let y = 0; y < kernelSize; y++) {
      for (let x = 0; x < kernelSize; x++) {
        kernel[y][x] /= sum;
      }
    }
    
    // Apply convolution
    for (let y = 0; y < height; y++) {
      result[y] = [];
      for (let x = 0; x < width; x++) {
        let value = 0;
        for (let ky = 0; ky < kernelSize; ky++) {
          for (let kx = 0; kx < kernelSize; kx++) {
            const py = Math.min(height - 1, Math.max(0, y + ky - halfKernel));
            const px = Math.min(width - 1, Math.max(0, x + kx - halfKernel));
            value += image[py][px] * kernel[ky][kx];
          }
        }
        result[y][x] = value;
      }
    }
    
    return result;
  }

  private bilateralFilter(
    image: number[][],
    width: number,
    height: number
  ): number[][] {
    const result: number[][] = [];
    const radius = 3;
    const spatialSigma = 3;
    const rangeSigma = 30;
    
    for (let y = 0; y < height; y++) {
      result[y] = [];
      for (let x = 0; x < width; x++) {
        let sum = 0;
        let weightSum = 0;
        const centerValue = image[y][x];
        
        for (let dy = -radius; dy <= radius; dy++) {
          for (let dx = -radius; dx <= radius; dx++) {
            const py = Math.min(height - 1, Math.max(0, y + dy));
            const px = Math.min(width - 1, Math.max(0, x + dx));
            const neighborValue = image[py][px];
            
            const spatialWeight = Math.exp(-(dx * dx + dy * dy) / (2 * spatialSigma * spatialSigma));
            const rangeWeight = Math.exp(-Math.pow(neighborValue - centerValue, 2) / (2 * rangeSigma * rangeSigma));
            const weight = spatialWeight * rangeWeight;
            
            sum += neighborValue * weight;
            weightSum += weight;
          }
        }
        
        result[y][x] = sum / weightSum;
      }
    }
    
    return result;
  }

  private computeNoiseResidual(
    original: number[][],
    denoised: number[][],
    width: number,
    height: number
  ): number[][] {
    const residual: number[][] = [];
    
    for (let y = 0; y < height; y++) {
      residual[y] = [];
      for (let x = 0; x < width; x++) {
        residual[y][x] = original[y][x] - denoised[y][x];
      }
    }
    
    return residual;
  }

  private extractPRNUPattern(
    noiseResidual: number[][],
    width: number,
    height: number
  ): number[] {
    // Zero-mean the noise
    const mean = this.computeMean(noiseResidual, width, height);
    const zeroMeaned = this.subtractMean(noiseResidual, mean, width, height);
    
    // Flatten to 1D fingerprint
    const fingerprint: number[] = [];
    
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        fingerprint.push(zeroMeaned[y][x]);
      }
    }
    
    // Normalize fingerprint
    const norm = Math.sqrt(fingerprint.reduce((sum, v) => sum + v * v, 0));
    if (norm > 0) {
      for (let i = 0; i < fingerprint.length; i++) {
        fingerprint[i] /= norm;
      }
    }
    
    return fingerprint;
  }

  private computeMean(image: number[][], width: number, height: number): number {
    let sum = 0;
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        sum += image[y][x];
      }
    }
    return sum / (width * height);
  }

  private subtractMean(
    image: number[][],
    mean: number,
    width: number,
    height: number
  ): number[][] {
    const result: number[][] = [];
    for (let y = 0; y < height; y++) {
      result[y] = [];
      for (let x = 0; x < width; x++) {
        result[y][x] = image[y][x] - mean;
      }
    }
    return result;
  }

  private assessQuality(
    fingerprint: number[],
    noiseResidual: number[][],
    width: number,
    height: number
  ): number {
    // Quality based on fingerprint strength and noise characteristics
    
    // Fingerprint strength (signal level)
    let fingerprintStrength = 0;
    for (const v of fingerprint) {
      fingerprintStrength += v * v;
    }
    
    // Noise level
    let noiseVariance = 0;
    const noiseMean = this.computeMean(noiseResidual, width, height);
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        noiseVariance += Math.pow(noiseResidual[y][x] - noiseMean, 2);
      }
    }
    noiseVariance /= (width * height);
    
    // SNR-based quality
    const snr = fingerprintStrength / (noiseVariance + 1e-10);
    
    return Math.min(1, snr * 10);
  }

  private computeNoiseLevel(noiseResidual: number[][], width: number, height: number): number {
    let sum = 0;
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        sum += noiseResidual[y][x] * noiseResidual[y][x];
      }
    }
    return Math.sqrt(sum / (width * height));
  }

  private computeConvergence(fingerprint: number[]): number {
    // Check if fingerprint has converged (not random noise)
    // Use autocorrelation at lag 0 vs other lags
    
    const n = fingerprint.length;
    if (n < 100) return 0;
    
    // Sample autocorrelation
    const mean = fingerprint.reduce((a, b) => a + b, 0) / n;
    let autoCorr0 = 0;
    let autoCorr1 = 0;
    
    for (let i = 0; i < n; i++) {
      autoCorr0 += Math.pow(fingerprint[i] - mean, 2);
      if (i < n - 1) {
        autoCorr1 += (fingerprint[i] - mean) * (fingerprint[i + 1] - mean);
      }
    }
    
    // Converged fingerprint has high autocorrelation
    return autoCorr0 > 0 ? Math.abs(autoCorr1 / autoCorr0) : 0;
  }
}

// ============================================
// FINGERPRINT MATCHER
// ============================================

class FingerprintMatcher {
  /**
   * Match PRNU fingerprint against database
   */
  match(
    fingerprint: number[],
    knownCameras: Map<string, number[]>
  ): FingerprintMatchResult {
    const candidates: Array<{ fingerprintId: string; score: number }> = [];
    
    for (const [id, knownFingerprint] of knownCameras) {
      const score = this.computeSimilarity(fingerprint, knownFingerprint);
      candidates.push({ fingerprintId: id, score });
    }
    
    // Sort by score
    candidates.sort((a, b) => b.score - a.score);
    
    const bestMatch = candidates[0];
    const matched = bestMatch && bestMatch.score > 0.5;
    
    return {
      matched,
      matchScore: bestMatch?.score || 0,
      candidateCameras: candidates.slice(0, 5)
    };
  }

  private computeSimilarity(fp1: number[], fp2: number[]): number {
    // Normalized cross-correlation
    const n = Math.min(fp1.length, fp2.length);
    if (n === 0) return 0;
    
    let sum1 = 0;
    let sum2 = 0;
    let dot = 0;
    
    for (let i = 0; i < n; i++) {
      sum1 += fp1[i] * fp1[i];
      sum2 += fp2[i] * fp2[i];
      dot += fp1[i] * fp2[i];
    }
    
    const norm1 = Math.sqrt(sum1);
    const norm2 = Math.sqrt(sum2);
    
    if (norm1 === 0 || norm2 === 0) return 0;
    
    return dot / (norm1 * norm2);
  }
}

// ============================================
// CONSISTENCY CHECKER
// ============================================

class ConsistencyChecker {
  /**
   * Check PRNU consistency across image regions
   */
  check(
    imageData: number[][],
    width: number,
    height: number,
    globalFingerprint: number[]
  ): ConsistencyResult {
    // Divide image into blocks
    const blockSize = 128;
    const localConsistencies: number[] = [];
    let suspiciousRegions = 0;
    
    for (let by = 0; by < height - blockSize; by += blockSize) {
      for (let bx = 0; bx < width - blockSize; bx += blockSize) {
        // Extract block
        const block: number[][] = [];
        for (let y = 0; y < blockSize; y++) {
          block[y] = [];
          for (let x = 0; x < blockSize; x++) {
            block[y][x] = imageData[by + y][bx + x];
          }
        }
        
        // Extract local PRNU
        const extractor = new PRNUExtractor();
        const localResult = extractor.extract(block, blockSize, blockSize);
        const localFingerprint = localResult.prnuEstimate;
        
        // Compute consistency with global fingerprint
        const consistency = this.computeLocalConsistency(
          localFingerprint,
          globalFingerprint,
          blockSize
        );
        
        localConsistencies.push(consistency);
        
        if (consistency < 0.3) {
          suspiciousRegions++;
        }
      }
    }
    
    // Global consistency
    const globalConsistency = localConsistencies.length > 0
      ? localConsistencies.reduce((a, b) => a + b, 0) / localConsistencies.length
      : 0;
    
    return {
      globalConsistency,
      localConsistencies,
      suspiciousRegions
    };
  }

  private computeLocalConsistency(
    localFingerprint: number[],
    globalFingerprint: number[],
    blockSize: number
  ): number {
    // Compare local fingerprint with corresponding region of global
    const n = Math.min(localFingerprint.length, blockSize * blockSize);
    if (n === 0) return 0;
    
    let dot = 0;
    let norm1 = 0;
    let norm2 = 0;
    
    for (let i = 0; i < n; i++) {
      dot += localFingerprint[i] * globalFingerprint[i];
      norm1 += localFingerprint[i] * localFingerprint[i];
      norm2 += globalFingerprint[i] * globalFingerprint[i];
    }
    
    if (norm1 === 0 || norm2 === 0) return 0;
    
    return dot / (Math.sqrt(norm1) * Math.sqrt(norm2));
  }
}

// ============================================
// MANIPULATION DETECTOR
// ============================================

class ManipulationDetector {
  /**
   * Detect image manipulation using PRNU analysis
   */
  detect(
    imageData: number[][],
    width: number,
    height: number,
    consistencyResult: ConsistencyResult
  ): ManipulationRegion[] {
    const regions: ManipulationRegion[] = [];
    const blockSize = 128;
    let blockIdx = 0;
    
    for (let by = 0; by < height - blockSize; by += blockSize) {
      for (let bx = 0; bx < width - blockSize; bx += blockSize) {
        const consistency = consistencyResult.localConsistencies[blockIdx];
        blockIdx++;
        
        if (consistency < 0.3) {
          // Determine manipulation type
          const block: number[][] = [];
          for (let y = 0; y < blockSize; y++) {
            block[y] = [];
            for (let x = 0; x < blockSize; x++) {
              block[y][x] = imageData[by + y][bx + x];
            }
          }
          
          const type = this.classifyManipulation(block, blockSize);
          
          regions.push({
            x: bx,
            y: by,
            width: blockSize,
            height: blockSize,
            type,
            confidence: 1 - consistency
          });
        }
      }
    }
    
    return regions;
  }

  private classifyManipulation(block: number[][], blockSize: number): ManipulationRegion['type'] {
    // Analyze block to classify manipulation type
    
    // Check for copy-move (similar patterns in block)
    const hasCopyMove = this.detectCopyMove(block, blockSize);
    if (hasCopyMove) return 'copy_move';
    
    // Check for splicing (edge artifacts)
    const hasSplicing = this.detectSplicing(block, blockSize);
    if (hasSplicing) return 'splicing';
    
    // Check for general inconsistency
    const hasInconsistency = this.detectInconsistency(block, blockSize);
    if (hasInconsistency) return 'inconsistency';
    
    return 'unknown';
  }

  private detectCopyMove(block: number[][], blockSize: number): boolean {
    // Look for repeated patterns within block
    const patchSize = 16;
    const patches: Map<string, number> = new Map();
    
    for (let y = 0; y < blockSize - patchSize; y += patchSize / 2) {
      for (let x = 0; x < blockSize - patchSize; x += patchSize / 2) {
        // Compute patch hash
        let hash = 0;
        for (let py = 0; py < patchSize; py++) {
          for (let px = 0; px < patchSize; px++) {
            hash += block[y + py][x + px];
          }
        }
        
        const key = Math.floor(hash).toString();
        const count = patches.get(key) || 0;
        
        if (count > 0) {
          return true; // Found repeated patch
        }
        
        patches.set(key, count + 1);
      }
    }
    
    return false;
  }

  private detectSplicing(block: number[][], blockSize: number): boolean {
    // Look for edge artifacts suggesting splicing
    const edgeStrength = this.computeEdgeStrength(block, blockSize);
    
    // Splicing often creates unusual edge patterns
    const mean = edgeStrength.reduce((a, b) => a + b, 0) / edgeStrength.length;
    const variance = edgeStrength.reduce((sum, e) => sum + Math.pow(e - mean, 2), 0) / edgeStrength.length;
    
    return variance > mean * mean * 2;
  }

  private detectInconsistency(block: number[][], blockSize: number): boolean {
    // Check for general noise/texture inconsistency
    const quarters = [
      block.slice(0, blockSize / 2).map(row => row.slice(0, blockSize / 2)),
      block.slice(0, blockSize / 2).map(row => row.slice(blockSize / 2)),
      block.slice(blockSize / 2).map(row => row.slice(0, blockSize / 2)),
      block.slice(blockSize / 2).map(row => row.slice(blockSize / 2))
    ];
    
    const means = quarters.map(q => {
      let sum = 0;
      for (const row of q) {
        for (const v of row) {
          sum += v;
        }
      }
      return sum / (q.length * q[0].length);
    });
    
    // Check for significant differences
    const overallMean = means.reduce((a, b) => a + b, 0) / 4;
    for (const m of means) {
      if (Math.abs(m - overallMean) > 20) {
        return true;
      }
    }
    
    return false;
  }

  private computeEdgeStrength(block: number[][], blockSize: number): number[] {
    const strengths: number[] = [];
    
    for (let y = 1; y < blockSize - 1; y++) {
      for (let x = 1; x < blockSize - 1; x++) {
        const gx = Math.abs(block[y][x + 1] - block[y][x - 1]);
        const gy = Math.abs(block[y + 1][x] - block[y - 1][x]);
        strengths.push(Math.sqrt(gx * gx + gy * gy));
      }
    }
    
    return strengths;
  }
}

// ============================================
// PRNU DETECTOR
// ============================================

export class PRNUDetector {
  private extractor: PRNUExtractor;
  private matcher: FingerprintMatcher;
  private consistencyChecker: ConsistencyChecker;
  private manipulationDetector: ManipulationDetector;
  
  // Simulated camera database
  private cameraDatabase: Map<string, number[]>;

  constructor() {
    this.extractor = new PRNUExtractor();
    this.matcher = new FingerprintMatcher();
    this.consistencyChecker = new ConsistencyChecker();
    this.manipulationDetector = new ManipulationDetector();
    this.cameraDatabase = new Map();
  }

  /**
   * Analyze image for PRNU fingerprint
   */
  async detect(
    imageData: number[][],
    width: number,
    height: number
  ): Promise<PRNUResult> {
    // Extract PRNU fingerprint
    const noiseExtraction = this.extractor.extract(imageData, width, height);
    
    // Match against known cameras
    const fingerprintMatch = this.matcher.match(
      noiseExtraction.prnuEstimate,
      this.cameraDatabase
    );
    
    // Check consistency
    const consistencyCheck = this.consistencyChecker.check(
      imageData,
      width,
      height,
      noiseExtraction.prnuEstimate
    );
    
    // Detect manipulation
    const manipulationRegions = this.manipulationDetector.detect(
      imageData,
      width,
      height,
      consistencyCheck
    );
    
    // Determine source attribution
    const sourceAttribution = this.determineSource(
      fingerprintMatch,
      noiseExtraction
    );
    
    // Determine validity
    const hasValidPRNU = noiseExtraction.quality > 0.3;
    
    // Determine manipulation
    const manipulationDetected = consistencyCheck.suspiciousRegions > 2 ||
      manipulationRegions.length > 2;
    
    return {
      id: `prnu-${Date.now()}`,
      timestamp: new Date(),
      hasValidPRNU,
      cameraFingerprint: noiseExtraction.prnuEstimate.slice(0, 1000), // Truncated for output
      fingerprintQuality: noiseExtraction.quality,
      sourceAttribution,
      manipulationDetected,
      manipulationRegions,
      analysis: {
        noiseExtraction,
        fingerprintMatch,
        consistencyCheck
      }
    };
  }

  private determineSource(
    matchResult: FingerprintMatchResult,
    extractionResult: NoiseExtractionResult
  ): SourceAttribution | null {
    if (!matchResult.matched) {
      return null;
    }
    
    // Parse fingerprint ID (format: manufacturer_model_id)
    const parts = matchResult.candidateCameras[0].fingerprintId.split('_');
    
    return {
      manufacturer: parts[0] || 'Unknown',
      model: parts[1] || null,
      confidence: matchResult.matchScore,
      fingerprintId: matchResult.candidateCameras[0].fingerprintId
    };
  }

  /**
   * Register a known camera fingerprint
   */
  registerCamera(
    fingerprintId: string,
    fingerprint: number[]
  ): void {
    this.cameraDatabase.set(fingerprintId, fingerprint);
  }
}

// ============================================
// EXPORTS
// ============================================

export const sensorPatternNoise = {
  PRNUDetector,
  PRNUExtractor,
  FingerprintMatcher,
  ConsistencyChecker,
  ManipulationDetector
};

export default sensorPatternNoise;
