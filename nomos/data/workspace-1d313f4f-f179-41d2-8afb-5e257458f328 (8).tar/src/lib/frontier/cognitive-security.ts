/**
 * Cognitive Security Module
 *
 * Protects against psychological manipulation in deepfakes by detecting
 * emotional exploitation, cognitive biases, and persuasion techniques.
 *
 * Based on:
 * - Cialdini's principles of influence
 * - Kahneman's System 1/System 2 framework
 * - Emotional contagion research
 * - Propaganda analysis techniques
 *
 * @module cognitive-security
 * @version 1.0.0
 */

import { createHash, randomBytes } from 'crypto';

// ============================================================================
// COGNITIVE SECURITY TYPES
// ============================================================================

/**
 * Cognitive threat types
 */
export type CognitiveThreatType =
  | 'emotional_manipulation'
  | 'authority_exploitation'
  | 'urgency_induction'
  | 'social_proof_fabrication'
  | 'scarcity_creation'
  | 'fear_amplification'
  | 'trust_exploitation'
  | 'cognitive_overload'
  | 'confirmation_bait'
  | 'outrage_manufacturing';

/**
 * Emotional state detected
 */
export interface EmotionalState {
  primary: string;
  secondary: string[];
  intensity: number; // 0-1
  valence: 'positive' | 'negative' | 'neutral';
  arousal: number; // 0-1
}

/**
 * Persuasion technique detected
 */
export interface PersuasionTechnique {
  type: CognitiveThreatType;
  name: string;
  description: string;
  indicators: string[];
  confidence: number;
  severity: 'low' | 'medium' | 'high' | 'critical';
  countermeasures: string[];
}

/**
 * Cognitive bias exploited
 */
export interface CognitiveBias {
  name: string;
  description: string;
  exploitationEvidence: string[];
  impact: number; // 0-1
  affected: string[];
}

/**
 * Psychological profile of content
 */
export interface PsychologicalProfile {
  /** Target emotional state */
  targetEmotion: EmotionalState;
  /** Persuasion techniques used */
  persuasionTechniques: PersuasionTechnique[];
  /** Cognitive biases exploited */
  biasesExploited: CognitiveBias[];
  /** Manipulation score */
  manipulationScore: number; // 0-1
  /** Psychological harm potential */
  harmPotential: number; // 0-1
  /** Vulnerable populations */
  vulnerablePopulations: string[];
  /** Risk assessment */
  riskAssessment: {
    level: 'minimal' | 'low' | 'moderate' | 'high' | 'severe';
    score: number;
    factors: string[];
  };
}

/**
 * Cognitive security analysis result
 */
export interface CognitiveSecurityResult {
  /** Overall threat level */
  threatLevel: 'safe' | 'low' | 'moderate' | 'high' | 'critical';
  /** Threat score */
  threatScore: number; // 0-1
  /** Psychological profile */
  profile: PsychologicalProfile;
  /** Detected threats */
  threats: CognitiveThreat[];
  /** Recommendations */
  recommendations: string[];
  /** Confidence in analysis */
  confidence: number;
  /** Analysis metadata */
  metadata: {
    analyzedAt: number;
    method: string;
    version: string;
  };
}

/**
 * Individual cognitive threat
 */
export interface CognitiveThreat {
  id: string;
  type: CognitiveThreatType;
  description: string;
  evidence: string[];
  impact: number;
  likelihood: number;
  affectedSystems: string[];
  mitigationStrategies: string[];
}

/**
 * Emotional indicator
 */
export interface EmotionalIndicator {
  emotion: string;
  triggers: string[];
  signals: string[];
  culturalVariations: Record<string, string[]>;
}

// ============================================================================
// EMOTIONAL ANALYSIS
// ============================================================================

// Primary emotions and their indicators
const EMOTION_INDICATORS: Map<string, EmotionalIndicator> = new Map([
  ['fear', {
    emotion: 'fear',
    triggers: ['threat', 'danger', 'warning', 'alert', 'crisis'],
    signals: ['immediate', 'urgent', 'breaking', 'emergency', 'critical'],
    culturalVariations: {
      western: ['danger', 'threat', 'risk'],
      eastern: ['dishonor', 'shame', 'disgrace']
    }
  }],
  ['anger', {
    emotion: 'anger',
    triggers: ['injustice', 'unfair', 'betrayal', 'violation', 'outrage'],
    signals: ['furious', 'enraged', 'unacceptable', 'scandal', 'exposed'],
    culturalVariations: {
      western: ['rights', 'freedom', 'justice'],
      eastern: ['respect', 'hierarchy', 'tradition']
    }
  }],
  ['disgust', {
    emotion: 'disgust',
    triggers: ['repulsive', 'revolting', 'shocking', 'vile', 'depraved'],
    signals: ['unbelievable', 'sickening', 'horrifying', 'appalling'],
    culturalVariations: {
      western: ['moral', 'ethics', 'values'],
      eastern: ['purity', 'contamination', 'taboo']
    }
  }],
  ['surprise', {
    emotion: 'surprise',
    triggers: ['unexpected', 'shocking', 'revealed', 'exposed', 'secret'],
    signals: ['breaking', 'exclusive', 'leaked', 'never-before-seen'],
    culturalVariations: {
      western: ['exclusive', 'leaked', 'secret'],
      eastern: ['hidden', 'concealed', 'mystery']
    }
  }],
  ['sadness', {
    emotion: 'sadness',
    triggers: ['tragic', 'heartbreaking', 'devastating', 'loss', 'grief'],
    signals: ['mourning', 'suffering', 'victims', 'fallen'],
    culturalVariations: {
      western: ['loss', 'death', 'grief'],
      eastern: ['impermanence', 'suffering', 'departure']
    }
  }],
  ['joy', {
    emotion: 'joy',
    triggers: ['celebration', 'victory', 'triumph', 'success', 'breakthrough'],
    signals: ['exciting', 'amazing', 'incredible', 'wonderful'],
    culturalVariations: {
      western: ['achievement', 'success', 'win'],
      eastern: ['harmony', 'blessing', 'fortune']
    }
  }],
  ['trust', {
    emotion: 'trust',
    triggers: ['reliable', 'verified', 'official', 'confirmed', 'expert'],
    signals: ['trusted', 'authentic', 'genuine', 'legitimate'],
    culturalVariations: {
      western: ['credentials', 'expertise', 'authority'],
      eastern: ['lineage', 'reputation', 'endorsement']
    }
  }],
  ['anticipation', {
    emotion: 'anticipation',
    triggers: ['coming', 'soon', 'expected', 'upcoming', 'announced'],
    signals: ['prepare', 'ready', 'await', 'watch'],
    culturalVariations: {
      western: ['deadline', 'launch', 'release'],
      eastern: ['auspicious', 'timing', 'destiny']
    }
  }]
]);

/**
 * Analyze emotional content
 */
export function analyzeEmotionalContent(
  content: string,
  audioFeatures?: { pitch: number; tempo: number; volume: number },
  visualFeatures?: { faceExpression: string; bodyLanguage: string }
): EmotionalState {
  const contentLower = content.toLowerCase();
  const emotionScores: Map<string, number> = new Map();

  // Analyze text for emotional indicators
  for (const [emotion, indicator] of EMOTION_INDICATORS) {
    let score = 0;

    // Check triggers
    for (const trigger of indicator.triggers) {
      if (contentLower.includes(trigger)) {
        score += 0.15;
      }
    }

    // Check signals
    for (const signal of indicator.signals) {
      if (contentLower.includes(signal)) {
        score += 0.1;
      }
    }

    emotionScores.set(emotion, Math.min(1, score));
  }

  // Incorporate audio features
  if (audioFeatures) {
    if (audioFeatures.pitch > 0.7) {
      emotionScores.set('fear', (emotionScores.get('fear') || 0) + 0.2);
      emotionScores.set('anger', (emotionScores.get('anger') || 0) + 0.1);
    }
    if (audioFeatures.tempo > 0.7) {
      emotionScores.set('anticipation', (emotionScores.get('anticipation') || 0) + 0.2);
    }
  }

  // Incorporate visual features
  if (visualFeatures) {
    const expr = visualFeatures.faceExpression.toLowerCase();
    if (emotionScores.has(expr)) {
      emotionScores.set(expr, (emotionScores.get(expr) || 0) + 0.3);
    }
  }

  // Find primary and secondary emotions
  const sorted = Array.from(emotionScores.entries())
    .sort((a, b) => b[1] - a[1]);

  const primary = sorted[0]?.[0] || 'neutral';
  const secondary = sorted.slice(1, 3)
    .filter(([, score]) => score > 0.1)
    .map(([emotion]) => emotion);

  // Calculate intensity and valence
  const intensity = sorted[0]?.[1] || 0;
  const negativeEmotions = ['fear', 'anger', 'disgust', 'sadness'];
  const positiveEmotions = ['joy', 'trust', 'anticipation'];

  let valence: 'positive' | 'negative' | 'neutral' = 'neutral';
  if (negativeEmotions.includes(primary)) {
    valence = 'negative';
  } else if (positiveEmotions.includes(primary)) {
    valence = 'positive';
  }

  // Calculate arousal based on emotion type
  const highArousalEmotions = ['fear', 'anger', 'surprise', 'joy'];
  const arousal = highArousalEmotions.includes(primary) ? intensity : intensity * 0.5;

  return {
    primary,
    secondary,
    intensity,
    valence,
    arousal
  };
}

// ============================================================================
// PERSUASION TECHNIQUE DETECTION
// ============================================================================

// Persuasion techniques based on Cialdini's principles and propaganda analysis
const PERSUASION_PATTERNS: Map<CognitiveThreatType, {
  name: string;
  description: string;
  patterns: string[];
  countermeasures: string[];
}> = new Map([
  ['authority_exploitation', {
    name: 'Authority Exploitation',
    description: 'Uses fake or exaggerated authority figures to influence',
    patterns: [
      'expert', 'doctor', 'scientist', 'official', 'government',
      'study shows', 'research proves', 'authorities say',
      'leading', 'top', 'renowned', 'world-class'
    ],
    countermeasures: [
      'Verify credentials independently',
      'Check for actual expertise in the field',
      'Look for conflicts of interest',
      'Cross-reference with reputable sources'
    ]
  }],
  ['urgency_induction', {
    name: 'Urgency Induction',
    description: 'Creates artificial time pressure to bypass critical thinking',
    patterns: [
      'act now', 'limited time', 'deadline', 'urgent',
      'immediately', 'last chance', 'final warning', 'before it\'s too late',
      'don\'t wait', 'time is running out', 'expires soon'
    ],
    countermeasures: [
      'Take time to verify claims',
      'Question artificial deadlines',
      'Seek second opinions',
      'Recognize manufactured urgency'
    ]
  }],
  ['social_proof_fabrication', {
    name: 'Social Proof Fabrication',
    description: 'Creates fake consensus or popularity',
    patterns: [
      'everyone knows', 'most people', 'going viral',
      'trending', 'millions agree', 'join the movement',
      'shared thousands of times', 'what people are saying'
    ],
    countermeasures: [
      'Verify engagement metrics',
      'Check for bot activity',
      'Look for authentic individual testimonials',
      'Be skeptical of vague claims of popularity'
    ]
  }],
  ['scarcity_creation', {
    name: 'Scarcity Creation',
    description: 'Creates artificial scarcity to increase perceived value',
    patterns: [
      'rare', 'limited', 'exclusive', 'only',
      'few remaining', 'once in a lifetime', 'special access',
      'members only', 'invitation only', 'secret'
    ],
    countermeasures: [
      'Question actual scarcity',
      'Research true availability',
      'Consider why access is restricted',
      'Be wary of "exclusive" content'
    ]
  }],
  ['fear_amplification', {
    name: 'Fear Amplification',
    description: 'Exaggerates threats to manipulate behavior',
    patterns: [
      'dangerous', 'deadly', 'catastrophic', 'threat',
      'crisis', 'epidemic', 'plague', 'invasion',
      'under attack', 'existential threat', 'apocalypse'
    ],
    countermeasures: [
      'Fact-check threat claims',
      'Seek balanced perspectives',
      'Understand actual probability of harm',
      'Recognize fear-mongering tactics'
    ]
  }],
  ['trust_exploitation', {
    name: 'Trust Exploitation',
    description: 'Exploits existing trust relationships or creates false trust',
    patterns: [
      'as your friend', 'I promise', 'trust me',
      'I\'ve never lied', 'believe me', 'honestly',
      'to tell the truth', 'in confidence', 'between us'
    ],
    countermeasures: [
      'Verify claims regardless of source',
      'Be cautious of excessive trust-building',
      'Check consistency with previous behavior',
      'Look for manipulation patterns'
    ]
  }],
  ['emotional_manipulation', {
    name: 'Emotional Manipulation',
    description: 'Deliberately triggers strong emotions to bypass reason',
    patterns: [
      'heartbreaking', 'outrageous', 'shocking',
      'unbelievable', 'devastating', 'inspiring',
      'tear-jerking', 'enraging', 'terrifying'
    ],
    countermeasures: [
      'Pause before reacting emotionally',
      'Seek factual information',
      'Recognize emotional triggers',
      'Consider who benefits from your emotional response'
    ]
  }],
  ['cognitive_overload', {
    name: 'Cognitive Overload',
    description: 'Overwhelms with information to prevent critical analysis',
    patterns: [
      excessiveLength,
      rapidTransitions,
      multipleClaims,
      complexJargon
    ].map(f => f()),
    countermeasures: [
      'Break down information into smaller parts',
      'Focus on key claims',
      'Take notes and organize thoughts',
      'Seek simplified explanations'
    ]
  }],
  ['confirmation_bait', {
    name: 'Confirmation Bait',
    description: 'Appeals to pre-existing beliefs to bypass scrutiny',
    patterns: [
      'just as we suspected', 'as you know',
      'proves what we\'ve been saying', 'confirms our fears',
      'you were right', 'they don\'t want you to know'
    ],
    countermeasures: [
      'Actively seek opposing viewpoints',
      'Question comfortable conclusions',
      'Verify even when it confirms beliefs',
      'Be especially critical of confirming evidence'
    ]
  }],
  ['outrage_manufacturing', {
    name: 'Outrage Manufacturing',
    description: 'Deliberately creates anger and division',
    patterns: [
      'scandal', 'exposed', 'caught', 'outrage',
      'unacceptable', 'must be stopped', 'how dare',
      'beyond the pale', 'crossed the line', 'disgraceful'
    ],
    countermeasures: [
      'Pause before sharing outrage-inducing content',
      'Verify the source and context',
      'Consider who benefits from outrage',
      'Seek balanced reporting'
    ]
  }]
]);

function excessiveLength(): string {
  return 'excessive_length';
}

function rapidTransitions(): string {
  return 'rapid_transitions';
}

function multipleClaims(): string {
  return 'multiple_unsubstantiated_claims';
}

function complexJargon(): string {
  return 'unnecessary_complexity';
}

/**
 * Detect persuasion techniques in content
 */
export function detectPersuasionTechniques(
  content: string,
  emotionalState: EmotionalState
): PersuasionTechnique[] {
  const techniques: PersuasionTechnique[] = [];
  const contentLower = content.toLowerCase();

  for (const [type, pattern] of PERSUASION_PATTERNS) {
    let indicatorCount = 0;
    const matchedIndicators: string[] = [];

    // Check for pattern matches
    for (const p of pattern.patterns) {
      if (typeof p === 'string' && contentLower.includes(p.toLowerCase())) {
        indicatorCount++;
        matchedIndicators.push(p);
      }
    }

    // Calculate confidence based on matches
    const confidence = Math.min(1, indicatorCount / 3);

    if (confidence > 0.2) {
      // Determine severity
      let severity: PersuasionTechnique['severity'] = 'low';
      if (confidence > 0.7) severity = 'critical';
      else if (confidence > 0.5) severity = 'high';
      else if (confidence > 0.3) severity = 'medium';

      techniques.push({
        type,
        name: pattern.name,
        description: pattern.description,
        indicators: matchedIndicators,
        confidence,
        severity,
        countermeasures: pattern.countermeasures
      });
    }
  }

  // Sort by confidence
  return techniques.sort((a, b) => b.confidence - a.confidence);
}

// ============================================================================
// COGNITIVE BIAS DETECTION
// ============================================================================

const COGNITIVE_BIASES: Map<string, {
  name: string;
  description: string;
  exploitationPatterns: string[];
  affectedPopulations: string[];
}> = new Map([
  ['anchoring', {
    name: 'Anchoring Bias',
    description: 'Over-reliance on first piece of information',
    exploitationPatterns: ['shocking opening', 'extreme initial claim'],
    affectedPopulations: ['general']
  }],
  ['availability', {
    name: 'Availability Heuristic',
    description: 'Over-weighting easily recalled information',
    exploitationPatterns: ['repetition', 'vivid examples', 'recent events'],
    affectedPopulations: ['general', 'anxious']
  }],
  ['confirmation', {
    name: 'Confirmation Bias',
    description: 'Seeking information that confirms existing beliefs',
    exploitationPatterns: ['echo chamber content', 'cherry-picked data'],
    affectedPopulations: ['partisan', 'ideological']
  }],
  ['authority', {
    name: 'Authority Bias',
    description: 'Excessive deference to authority figures',
    exploitationPatterns: ['fake experts', 'inflated credentials'],
    affectedPopulations: ['uncertain', 'low self-esteem']
  }],
  ['bandwagon', {
    name: 'Bandwagon Effect',
    description: 'Adopting beliefs because others have',
    exploitationPatterns: ['fake popularity', 'trending manipulation'],
    affectedPopulations: ['social', 'young']
  }],
  ['loss_aversion', {
    name: 'Loss Aversion',
    description: 'Over-weighting potential losses vs gains',
    exploitationPatterns: ['fear of missing out', 'threat narratives'],
    affectedPopulations: ['anxious', 'risk-averse']
  }],
  ['in_group', {
    name: 'In-Group Bias',
    description: 'Favoring one\'s own group',
    exploitationPatterns: ['us vs them', 'tribal narratives'],
    affectedPopulations: ['partisan', 'nationalistic']
  }],
  ['negativity', {
    name: 'Negativity Bias',
    description: 'Greater impact of negative information',
    exploitationPatterns: ['fear appeals', 'outrage content'],
    affectedPopulations: ['anxious', 'depressed']
  }]
]);

/**
 * Detect exploited cognitive biases
 */
export function detectCognitiveBiases(
  content: string,
  persuasionTechniques: PersuasionTechnique[]
): CognitiveBias[] {
  const biases: CognitiveBias[] = [];
  const contentLower = content.toLowerCase();

  for (const [id, bias] of COGNITIVE_BIASES) {
    const evidence: string[] = [];

    // Check for exploitation patterns
    for (const pattern of bias.exploitationPatterns) {
      if (contentLower.includes(pattern.toLowerCase())) {
        evidence.push(`Pattern detected: "${pattern}"`);
      }
    }

    // Check persuasion techniques that relate to this bias
    const relatedTechniques = persuasionTechniques.filter(t =>
      t.type.includes(id) || bias.exploitationPatterns.some(p => t.indicators.includes(p))
    );

    if (relatedTechniques.length > 0) {
      evidence.push(`Related technique: ${relatedTechniques.map(t => t.name).join(', ')}`);
    }

    if (evidence.length > 0) {
      biases.push({
        name: bias.name,
        description: bias.description,
        exploitationEvidence: evidence,
        impact: Math.min(1, evidence.length * 0.3),
        affected: bias.affectedPopulations
      });
    }
  }

  return biases.sort((a, b) => b.impact - a.impact);
}

// ============================================================================
// VULNERABLE POPULATION DETECTION
// ============================================================================

const VULNERABLE_POPULATIONS: Map<string, {
  name: string;
  characteristics: string[];
  specificRisks: string[];
}> = new Map([
  ['elderly', {
    name: 'Elderly',
    characteristics: ['less tech-savvy', 'trust by default', 'isolation'],
    specificRisks: ['financial scams', 'health misinformation', 'isolation exploitation']
  }],
  ['children', {
    name: 'Children/Adolescents',
    characteristics: ['impressionable', 'seeking belonging', 'developing critical thinking'],
    specificRisks: ['grooming', 'radicalization', 'body image issues']
  }],
  ['mental_health', {
    name: 'Mental Health Challenges',
    characteristics: ['emotional vulnerability', 'seeking solutions', 'cognitive differences'],
    specificRisks: ['self-harm content', 'exploitation of conditions', 'misinformation about treatments']
  }],
  ['political_partisan', {
    name: 'Strong Political Partisans',
    characteristics: ['tribal identity', 'confirmation seeking', 'mistrust of opposition'],
    specificRisks: ['polarization', 'radicalization', 'election manipulation']
  }],
  ['isolated', {
    name: 'Socially Isolated',
    characteristics: ['seeking connection', 'reduced reality testing', 'loneliness'],
    specificRisks: ['romance scams', 'cult recruitment', 'echo chambers']
  }]
]);

/**
 * Identify vulnerable populations for content
 */
export function identifyVulnerablePopulations(
  content: string,
  emotionalState: EmotionalState,
  persuasionTechniques: PersuasionTechnique[]
): string[] {
  const contentLower = content.toLowerCase();
  const vulnerable: string[] = [];

  // Check for elderly-targeted content
  if (contentLower.includes('senior') ||
      contentLower.includes('retirement') ||
      contentLower.includes('pension') ||
      contentLower.includes('medicare')) {
    vulnerable.push('elderly');
  }

  // Check for child-targeted content
  if (contentLower.includes('kid') ||
      contentLower.includes('teen') ||
      contentLower.includes('student') ||
      contentLower.includes('young')) {
    vulnerable.push('children');
  }

  // Check for mental health targeting
  if (emotionalState.primary === 'sadness' ||
      contentLower.includes('depression') ||
      contentLower.includes('anxiety') ||
      contentLower.includes('lonely')) {
    vulnerable.push('mental_health');
  }

  // Check for political content
  if (persuasionTechniques.some(t => t.type === 'confirmation_bait' || t.type === 'outrage_manufacturing') ||
      contentLower.includes('liberal') ||
      contentLower.includes('conservative') ||
      contentLower.includes('democrat') ||
      contentLower.includes('republican')) {
    vulnerable.push('political_partisan');
  }

  // Check for isolation exploitation
  if (contentLower.includes('alone') ||
      contentLower.includes('nobody understands') ||
      contentLower.includes('only you')) {
    vulnerable.push('isolated');
  }

  return [...new Set(vulnerable)];
}

// ============================================================================
// COMPREHENSIVE COGNITIVE SECURITY ANALYSIS
// ============================================================================

/**
 * Perform comprehensive cognitive security analysis
 */
export function analyzeCognitiveSecurity(
  content: string,
  audioFeatures?: { pitch: number; tempo: number; volume: number },
  visualFeatures?: { faceExpression: string; bodyLanguage: string }
): CognitiveSecurityResult {
  // Analyze emotional content
  const emotionalState = analyzeEmotionalContent(content, audioFeatures, visualFeatures);

  // Detect persuasion techniques
  const persuasionTechniques = detectPersuasionTechniques(content, emotionalState);

  // Detect cognitive biases exploited
  const biasesExploited = detectCognitiveBiases(content, persuasionTechniques);

  // Identify vulnerable populations
  const vulnerablePopulations = identifyVulnerablePopulations(content, emotionalState, persuasionTechniques);

  // Calculate manipulation score
  const manipulationScore = calculateManipulationScore(
    emotionalState,
    persuasionTechniques,
    biasesExploited
  );

  // Calculate harm potential
  const harmPotential = calculateHarmPotential(
    manipulationScore,
    vulnerablePopulations,
    persuasionTechniques
  );

  // Build psychological profile
  const profile: PsychologicalProfile = {
    targetEmotion: emotionalState,
    persuasionTechniques,
    biasesExploited,
    manipulationScore,
    harmPotential,
    vulnerablePopulations,
    riskAssessment: {
      level: getRiskLevel(manipulationScore),
      score: manipulationScore,
      factors: persuasionTechniques.slice(0, 3).map(t => t.name)
    }
  };

  // Generate threats
  const threats = generateCognitiveThreats(profile);

  // Calculate overall threat level
  const threatScore = calculateOverallThreatScore(manipulationScore, harmPotential, threats);
  const threatLevel = getThreatLevel(threatScore);

  // Generate recommendations
  const recommendations = generateRecommendations(profile);

  return {
    threatLevel,
    threatScore,
    profile,
    threats,
    recommendations,
    confidence: 0.85,
    metadata: {
      analyzedAt: Date.now(),
      method: 'multi_modal_cognitive_analysis',
      version: '1.0.0'
    }
  };
}

/**
 * Calculate manipulation score
 */
function calculateManipulationScore(
  emotionalState: EmotionalState,
  techniques: PersuasionTechnique[],
  biases: CognitiveBias[]
): number {
  // Base score from emotional intensity
  let score = emotionalState.intensity * 0.3;

  // Add technique scores
  for (const technique of techniques) {
    score += technique.confidence * 0.15;
  }

  // Add bias scores
  for (const bias of biases) {
    score += bias.impact * 0.1;
  }

  // Adjust for high-arousal negative emotions
  if (emotionalState.valence === 'negative' && emotionalState.arousal > 0.7) {
    score *= 1.2;
  }

  return Math.min(1, score);
}

/**
 * Calculate harm potential
 */
function calculateHarmPotential(
  manipulationScore: number,
  vulnerablePopulations: string[],
  techniques: PersuasionTechnique[]
): number {
  let potential = manipulationScore;

  // Increase for vulnerable populations
  potential += vulnerablePopulations.length * 0.1;

  // Increase for severe techniques
  const criticalTechniques = techniques.filter(t => t.severity === 'critical');
  potential += criticalTechniques.length * 0.15;

  return Math.min(1, potential);
}

/**
 * Get risk level from score
 */
function getRiskLevel(score: number): PsychologicalProfile['riskAssessment']['level'] {
  if (score < 0.2) return 'minimal';
  if (score < 0.4) return 'low';
  if (score < 0.6) return 'moderate';
  if (score < 0.8) return 'high';
  return 'severe';
}

/**
 * Get threat level from score
 */
function getThreatLevel(score: number): CognitiveSecurityResult['threatLevel'] {
  if (score < 0.15) return 'safe';
  if (score < 0.35) return 'low';
  if (score < 0.55) return 'moderate';
  if (score < 0.75) return 'high';
  return 'critical';
}

/**
 * Generate cognitive threats from profile
 */
function generateCognitiveThreats(profile: PsychologicalProfile): CognitiveThreat[] {
  const threats: CognitiveThreat[] = [];

  for (const technique of profile.persuasionTechniques.slice(0, 5)) {
    threats.push({
      id: `threat_${Date.now()}_${randomBytes(4).toString('hex')}`,
      type: technique.type,
      description: technique.description,
      evidence: technique.indicators,
      impact: technique.confidence,
      likelihood: technique.confidence,
      affectedSystems: ['cognitive_processing', 'decision_making'],
      mitigationStrategies: technique.countermeasures
    });
  }

  return threats;
}

/**
 * Calculate overall threat score
 */
function calculateOverallThreatScore(
  manipulationScore: number,
  harmPotential: number,
  threats: CognitiveThreat[]
): number {
  const avgThreatImpact = threats.length > 0
    ? threats.reduce((sum, t) => sum + t.impact, 0) / threats.length
    : 0;

  return (manipulationScore * 0.4 + harmPotential * 0.4 + avgThreatImpact * 0.2);
}

/**
 * Generate recommendations
 */
function generateRecommendations(profile: PsychologicalProfile): string[] {
  const recommendations: string[] = [];

  // Add general recommendation
  recommendations.push('Exercise critical thinking before accepting claims');

  // Add emotion-specific recommendations
  if (profile.targetEmotion.intensity > 0.7) {
    recommendations.push('Be aware of strong emotional triggers that may bypass reason');
  }

  // Add technique-specific recommendations
  for (const technique of profile.persuasionTechniques.slice(0, 3)) {
    recommendations.push(...technique.countermeasures.slice(0, 2));
  }

  // Add vulnerability-specific recommendations
  if (profile.vulnerablePopulations.length > 0) {
    recommendations.push(`Extra caution recommended for: ${profile.vulnerablePopulations.join(', ')}`);
  }

  // Remove duplicates
  return [...new Set(recommendations)].slice(0, 5);
}

// ============================================================================
// TESTING
// ============================================================================

/**
 * Run cognitive security tests
 */
export function runCognitiveSecurityTests(): {
  passed: boolean;
  tests: Array<{ name: string; passed: boolean; message: string }>;
  summary: { total: number; passed: number; failed: number };
} {
  const tests: Array<{ name: string; passed: boolean; message: string }> = [];

  // Test 1: Emotional analysis
  const emotionalResult = analyzeEmotionalContent(
    'BREAKING: Urgent warning about a dangerous new threat that requires immediate action!'
  );
  tests.push({
    name: 'Emotional analysis',
    passed: emotionalResult.primary !== 'neutral' && emotionalResult.intensity > 0,
    message: `Primary emotion: ${emotionalResult.primary}, intensity: ${emotionalResult.intensity.toFixed(2)}`
  });

  // Test 2: Persuasion technique detection
  const techniques = detectPersuasionTechniques(
    'URGENT: Government experts warn that this shocking revelation proves what we suspected all along!',
    emotionalResult
  );
  tests.push({
    name: 'Persuasion detection',
    passed: techniques.length > 0,
    message: `Detected ${techniques.length} techniques: ${techniques.map(t => t.name).join(', ')}`
  });

  // Test 3: Cognitive bias detection
  const biases = detectCognitiveBiases(
    'As everyone knows, this confirms what we\'ve been saying - trust the experts!',
    techniques
  );
  tests.push({
    name: 'Bias detection',
    passed: biases.length >= 0,
    message: `Detected ${biases.length} exploited biases`
  });

  // Test 4: Vulnerable population identification
  const vulnerable = identifyVulnerablePopulations(
    'Seniors are particularly at risk from this new Medicare scam targeting pension funds',
    emotionalResult,
    techniques
  );
  tests.push({
    name: 'Vulnerable populations',
    passed: vulnerable.length > 0,
    message: `Identified: ${vulnerable.join(', ')}`
  });

  // Test 5: Full cognitive security analysis
  const fullAnalysis = analyzeCognitiveSecurity(
    'SHOCKING: Exclusive revelation from top experts proves the crisis is worse than we thought! ' +
    'Act now before it\'s too late - millions agree this is unacceptable!'
  );
  tests.push({
    name: 'Full analysis',
    passed: fullAnalysis.threatScore > 0 && fullAnalysis.recommendations.length > 0,
    message: `Threat level: ${fullAnalysis.threatLevel}, score: ${fullAnalysis.threatScore.toFixed(2)}`
  });

  // Test 6: Manipulation score calculation
  tests.push({
    name: 'Manipulation score',
    passed: fullAnalysis.profile.manipulationScore >= 0 && fullAnalysis.profile.manipulationScore <= 1,
    message: `Score: ${fullAnalysis.profile.manipulationScore.toFixed(2)}`
  });

  // Test 7: Harm potential calculation
  tests.push({
    name: 'Harm potential',
    passed: fullAnalysis.profile.harmPotential >= 0 && fullAnalysis.profile.harmPotential <= 1,
    message: `Potential: ${fullAnalysis.profile.harmPotential.toFixed(2)}`
  });

  // Test 8: Threat generation
  tests.push({
    name: 'Threat generation',
    passed: fullAnalysis.threats.length > 0,
    message: `Generated ${fullAnalysis.threats.length} cognitive threats`
  });

  // Test 9: Recommendation generation
  tests.push({
    name: 'Recommendations',
    passed: fullAnalysis.recommendations.length > 0,
    message: `Generated ${fullAnalysis.recommendations.length} recommendations`
  });

  // Test 10: Risk level determination
  tests.push({
    name: 'Risk level',
    passed: ['minimal', 'low', 'moderate', 'high', 'severe'].includes(fullAnalysis.profile.riskAssessment.level),
    message: `Risk level: ${fullAnalysis.profile.riskAssessment.level}`
  });

  const passed = tests.filter(t => t.passed).length;
  const failed = tests.filter(t => !t.passed).length;

  return {
    passed: failed === 0,
    tests,
    summary: { total: tests.length, passed, failed }
  };
}

// Export all
export default {
  analyzeEmotionalContent,
  detectPersuasionTechniques,
  detectCognitiveBiases,
  identifyVulnerablePopulations,
  analyzeCognitiveSecurity,
  runCognitiveSecurityTests
};
