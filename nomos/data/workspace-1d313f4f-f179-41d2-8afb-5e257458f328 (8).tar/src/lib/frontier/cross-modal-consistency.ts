/**
 * Cross-Modal Consistency Module
 * 
 * Verifies consistency across different modalities (audio, video, text, metadata)
 * to detect sophisticated deepfakes that might fool single-modality detectors.
 * 
 * @module frontier/cross-modal-consistency
 * @version 1.0.0
 * 
 * Capabilities:
 * - Audio-Video Synchronization Check
 * - Lip Reading Verification
 * - Emotion Consistency Analysis
 * - Speaker Identity Matching
 * - Background Consistency Check
 * - Temporal Coherence Verification
 * - Semantic Alignment Analysis
 * - Physiological Signal Detection
 */

// ============================================================================
// TYPES
// ============================================================================

/**
 * Modality type
 */
export type ModalityType = 'audio' | 'video' | 'text' | 'metadata' | 'physiological';

/**
 * Cross-modal analysis result
 */
export interface CrossModalResult {
  id: string;
  overallConsistency: number;
  authenticProbability: number;
  modalityScores: Map<ModalityType, number>;
  pairwiseScores: Map<string, number>;
  inconsistencies: Inconsistency[];
  recommendations: string[];
  timestamp: number;
  processingTime: number;
}

/**
 * Detected inconsistency
 */
export interface Inconsistency {
  id: string;
  type: InconsistencyType;
  severity: 'low' | 'medium' | 'high' | 'critical';
  modalities: ModalityType[];
  description: string;
  evidence: string[];
  confidence: number;
  frameRange?: [number, number];
  timestampRange?: [number, number];
}

/**
 * Inconsistency types
 */
export type InconsistencyType = 
  | 'lip_sync_mismatch'
  | 'emotion_mismatch'
  | 'speaker_identity_mismatch'
  | 'audio_video_timing'
  | 'background_inconsistency'
  | 'lighting_inconsistency'
  | 'semantic_contradiction'
  | 'physiological_anomaly'
  | 'temporal_artifact'
  | 'identity_swap';

/**
 * Audio features
 */
export interface AudioFeatures {
  duration: number;
  sampleRate: number;
  channels: number;
  energy: number[];
  pitch: number[];
  mfcc: number[][];
  zeroCrossingRate: number[];
  spectralCentroid: number[];
  spectralRolloff: number[];
  speakingRate: number;
  pauses: number[];
  voiceActivity: boolean[];
  speakerEmbedding: number[];
}

/**
 * Video features
 */
export interface VideoFeatures {
  duration: number;
  frameCount: number;
  fps: number;
  resolution: [number, number];
  faceDetected: boolean[];
  faceBoundingBoxes: Array<[number, number, number, number]>;
  faceLandmarks: Array<Array<[number, number]>>;
  faceEmbeddings: number[][];
  lipLandmarks: Array<Array<[number, number]>>;
  eyeBlinks: number[];
  headPose: Array<{ yaw: number; pitch: number; roll: number }>;
  emotions: Array<{ [emotion: string]: number }>;
  background: Array<{ mean: number[]; std: number[] }>;
  lighting: Array<{ direction: number[]; intensity: number }>;
}

/**
 * Text features
 */
export interface TextFeatures {
  transcript: string;
  words: string[];
  wordTimestamps: Array<{ word: string; start: number; end: number }>;
  sentiment: number;
  entities: Array<{ text: string; type: string }>;
  language: string;
  confidence: number;
}

/**
 * Synchronization analysis
 */
export interface SyncAnalysis {
  audioLeadMs: number;
  videoLeadMs: number;
  lipSyncScore: number;
  speechToLipCorrelation: number;
  frameDrops: number[];
  audioGaps: number[];
  overallSync: number;
}

/**
 * Emotion consistency analysis
 */
export interface EmotionConsistency {
  audioEmotions: Array<{ [emotion: string]: number }>;
  videoEmotions: Array<{ [emotion: string]: number }>;
  textEmotions: Array<{ [emotion: string]: number }>;
  correlations: { [key: string]: number };
  inconsistencies: number[];
  overallConsistency: number;
}

/**
 * Speaker identity analysis
 */
export interface SpeakerIdentityAnalysis {
  audioSpeakerId: string;
  videoFaceId: string;
  matchScore: number;
  voiceFaceCorrelation: number;
  identityConsistent: boolean;
  confidence: number;
}

// ============================================================================
// STORAGE
// ============================================================================

const analysisHistory: CrossModalResult[] = [];
const knownIdentities = new Map<string, { voiceEmbedding: number[]; faceEmbedding: number[] }>();

// ============================================================================
// CROSS-MODAL ANALYSIS
// ============================================================================

/**
 * Perform comprehensive cross-modal analysis
 */
export function analyzeCrossModal(
  audioFeatures: AudioFeatures,
  videoFeatures: VideoFeatures,
  textFeatures: TextFeatures,
  metadata?: Record<string, unknown>
): CrossModalResult {
  const startTime = Date.now();
  const id = `cross_modal_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  
  const modalityScores = new Map<ModalityType, number>();
  const pairwiseScores = new Map<string, number>();
  const inconsistencies: Inconsistency[] = [];
  
  // 1. Audio-Video Synchronization
  const syncAnalysis = analyzeAudioVideoSync(audioFeatures, videoFeatures);
  pairwiseScores.set('audio-video-sync', syncAnalysis.overallSync);
  
  if (syncAnalysis.lipSyncScore < 0.7) {
    inconsistencies.push({
      id: `inc_${Date.now()}_0`,
      type: 'lip_sync_mismatch',
      severity: syncAnalysis.lipSyncScore < 0.4 ? 'critical' : 'high',
      modalities: ['audio', 'video'],
      description: `Lip sync mismatch detected with score ${syncAnalysis.lipSyncScore.toFixed(2)}`,
      evidence: [`Audio leads video by ${syncAnalysis.audioLeadMs}ms`],
      confidence: 1 - syncAnalysis.lipSyncScore
    });
  }
  
  // 2. Emotion Consistency
  const emotionAnalysis = analyzeEmotionConsistency(audioFeatures, videoFeatures, textFeatures);
  pairwiseScores.set('emotion-consistency', emotionAnalysis.overallConsistency);
  
  if (emotionAnalysis.overallConsistency < 0.6) {
    inconsistencies.push({
      id: `inc_${Date.now()}_1`,
      type: 'emotion_mismatch',
      severity: emotionAnalysis.overallConsistency < 0.4 ? 'critical' : 'medium',
      modalities: ['audio', 'video', 'text'],
      description: 'Emotion inconsistency across modalities detected',
      evidence: Object.entries(emotionAnalysis.correlations)
        .map(([k, v]) => `${k}: ${v.toFixed(2)}`),
      confidence: 1 - emotionAnalysis.overallConsistency
    });
  }
  
  // 3. Speaker Identity
  const identityAnalysis = analyzeSpeakerIdentity(audioFeatures, videoFeatures);
  pairwiseScores.set('speaker-identity', identityAnalysis.matchScore);
  
  if (!identityAnalysis.identityConsistent) {
    inconsistencies.push({
      id: `inc_${Date.now()}_2`,
      type: 'speaker_identity_mismatch',
      severity: 'high',
      modalities: ['audio', 'video'],
      description: 'Speaker voice does not match visual identity',
      evidence: [`Match score: ${identityAnalysis.matchScore.toFixed(2)}`],
      confidence: 1 - identityAnalysis.matchScore
    });
  }
  
  // 4. Background Consistency
  const bgConsistency = analyzeBackgroundConsistency(videoFeatures);
  pairwiseScores.set('background-consistency', bgConsistency);
  modalityScores.set('video', bgConsistency);
  
  if (bgConsistency < 0.7) {
    inconsistencies.push({
      id: `inc_${Date.now()}_3`,
      type: 'background_inconsistency',
      severity: 'medium',
      modalities: ['video'],
      description: 'Background inconsistency detected across frames',
      evidence: ['Background statistics vary significantly between frames'],
      confidence: 1 - bgConsistency
    });
  }
  
  // 5. Physiological Signals
  const physiologicalScore = analyzePhysiologicalSignals(videoFeatures);
  pairwiseScores.set('physiological', physiologicalScore);
  
  if (physiologicalScore < 0.6) {
    inconsistencies.push({
      id: `inc_${Date.now()}_4`,
      type: 'physiological_anomaly',
      severity: 'high',
      modalities: ['video'],
      description: 'Physiological signals appear unnatural',
      evidence: ['Blink patterns inconsistent with natural behavior'],
      confidence: 1 - physiologicalScore
    });
  }
  
  // 6. Semantic Alignment
  const semanticScore = analyzeSemanticAlignment(audioFeatures, textFeatures, videoFeatures);
  pairwiseScores.set('semantic-alignment', semanticScore);
  modalityScores.set('text', semanticScore);
  
  if (semanticScore < 0.7) {
    inconsistencies.push({
      id: `inc_${Date.now()}_5`,
      type: 'semantic_contradiction',
      severity: 'medium',
      modalities: ['audio', 'video', 'text'],
      description: 'Semantic mismatch between spoken words and visual content',
      evidence: ['Transcript does not align with visual lip movements'],
      confidence: 1 - semanticScore
    });
  }
  
  // Calculate modality scores
  modalityScores.set('audio', calculateAudioScore(audioFeatures, syncAnalysis, emotionAnalysis));
  modalityScores.set('metadata', metadata ? 0.8 : 0.5);
  modalityScores.set('physiological', physiologicalScore);
  
  // Calculate overall consistency
  const overallConsistency = calculateOverallConsistency(modalityScores, pairwiseScores, inconsistencies);
  
  // Calculate authentic probability
  const authenticProbability = calculateAuthenticProbability(overallConsistency, inconsistencies);
  
  const result: CrossModalResult = {
    id,
    overallConsistency,
    authenticProbability,
    modalityScores,
    pairwiseScores,
    inconsistencies,
    recommendations: generateRecommendations(inconsistencies),
    timestamp: Date.now(),
    processingTime: Date.now() - startTime
  };
  
  analysisHistory.push(result);
  
  return result;
}

// ============================================================================
// SYNCHRONIZATION ANALYSIS
// ============================================================================

/**
 * Analyze audio-video synchronization
 */
export function analyzeAudioVideoSync(
  audio: AudioFeatures,
  video: VideoFeatures
): SyncAnalysis {
  // Calculate audio energy peaks (simulate speech onset)
  const audioEnergyPeaks = findPeaks(audio.energy, 0.5);
  
  // Calculate lip movement onset
  const lipMovementOnsets = detectLipMovements(video.lipLandmarks);
  
  // Calculate timing difference
  const audioLeadMs = calculateTimingDifference(audioEnergyPeaks, lipMovementOnsets, 
    1000 / video.fps);
  
  // Calculate correlation between audio and lip movement
  const speechToLipCorrelation = calculateSpeechLipCorrelation(
    audio.voiceActivity,
    video.lipLandmarks
  );
  
  // Lip sync score based on timing and correlation
  const lipSyncScore = calculateLipSyncScore(audioLeadMs, speechToLipCorrelation);
  
  return {
    audioLeadMs,
    videoLeadMs: -audioLeadMs,
    lipSyncScore,
    speechToLipCorrelation,
    frameDrops: detectFrameDrops(video.frameCount, video.fps, audio.duration),
    audioGaps: detectAudioGaps(audio.voiceActivity),
    overallSync: lipSyncScore * 0.6 + speechToLipCorrelation * 0.4
  };
}

/**
 * Find peaks in signal
 */
function findPeaks(signal: number[], threshold: number): number[] {
  const peaks: number[] = [];
  
  for (let i = 1; i < signal.length - 1; i++) {
    if (signal[i] > signal[i - 1] && signal[i] > signal[i + 1] && signal[i] > threshold) {
      peaks.push(i);
    }
  }
  
  return peaks;
}

/**
 * Detect lip movements from landmarks
 */
function detectLipMovements(landmarks: Array<Array<[number, number]>>): number[] {
  const movements: number[] = [];
  
  let prevOpenness = 0;
  for (const frame of landmarks) {
    // Calculate mouth openness from landmarks
    const upperLip = frame.slice(12, 18);
    const lowerLip = frame.slice(18, 24);
    
    if (upperLip.length > 0 && lowerLip.length > 0) {
      const upperY = upperLip.reduce((sum, p) => sum + p[1], 0) / upperLip.length;
      const lowerY = lowerLip.reduce((sum, p) => sum + p[1], 0) / lowerLip.length;
      const openness = Math.abs(upperY - lowerY);
      
      if (openness > prevOpenness * 1.5) {
        movements.push(1);
      } else {
        movements.push(0);
      }
      prevOpenness = openness;
    }
  }
  
  return movements;
}

/**
 * Calculate timing difference
 */
function calculateTimingDifference(
  audioPeaks: number[],
  videoOnsets: number[],
  frameDuration: number
): number {
  if (audioPeaks.length === 0 || videoOnsets.length === 0) return 0;
  
  // Average difference
  let totalDiff = 0;
  const pairs = Math.min(audioPeaks.length, videoOnsets.length);
  
  for (let i = 0; i < pairs; i++) {
    const audioTime = audioPeaks[i] * 10; // Assuming 10ms frames
    const videoTime = videoOnsets[i] * frameDuration;
    totalDiff += audioTime - videoTime;
  }
  
  return totalDiff / pairs;
}

/**
 * Calculate speech-lip correlation
 */
function calculateSpeechLipCorrelation(
  voiceActivity: boolean[],
  lipLandmarks: Array<Array<[number, number]>>
): number {
  const lipMovements = detectLipMovements(lipLandmarks);
  
  // Calculate correlation
  let correlation = 0;
  const minLen = Math.min(voiceActivity.length, lipMovements.length);
  
  if (minLen === 0) return 0;
  
  let matchingFrames = 0;
  for (let i = 0; i < minLen; i++) {
    if (voiceActivity[i] === (lipMovements[i] === 1)) {
      matchingFrames++;
    }
  }
  
  return matchingFrames / minLen;
}

/**
 * Calculate lip sync score
 */
function calculateLipSyncScore(audioLeadMs: number, correlation: number): number {
  // Timing penalty (more than 100ms is bad)
  const timingPenalty = Math.max(0, 1 - Math.abs(audioLeadMs) / 100);
  
  // Combine timing and correlation
  return timingPenalty * 0.4 + correlation * 0.6;
}

/**
 * Detect frame drops
 */
function detectFrameDrops(frameCount: number, fps: number, duration: number): number[] {
  const expectedFrames = Math.floor(duration * fps);
  const droppedFrames: number[] = [];
  
  if (frameCount < expectedFrames * 0.95) {
    // Some frames dropped
    for (let i = frameCount; i < expectedFrames; i++) {
      droppedFrames.push(i);
    }
  }
  
  return droppedFrames;
}

/**
 * Detect audio gaps
 */
function detectAudioGaps(voiceActivity: boolean[]): number[] {
  const gaps: number[] = [];
  let gapStart = -1;
  
  for (let i = 0; i < voiceActivity.length; i++) {
    if (!voiceActivity[i] && gapStart === -1) {
      gapStart = i;
    } else if (voiceActivity[i] && gapStart !== -1) {
      gaps.push(i - gapStart);
      gapStart = -1;
    }
  }
  
  return gaps;
}

// ============================================================================
// EMOTION ANALYSIS
// ============================================================================

/**
 * Analyze emotion consistency across modalities
 */
export function analyzeEmotionConsistency(
  audio: AudioFeatures,
  video: VideoFeatures,
  text: TextFeatures
): EmotionConsistency {
  // Get emotions from each modality
  const audioEmotions = extractAudioEmotions(audio);
  const videoEmotions = video.emotions;
  const textEmotions = extractTextEmotions(text);
  
  // Calculate correlations
  const correlations: { [key: string]: number } = {};
  
  // Audio-Video correlation
  correlations['audio-video'] = calculateEmotionCorrelation(audioEmotions, videoEmotions);
  
  // Audio-Text correlation
  correlations['audio-text'] = calculateEmotionCorrelation(audioEmotions, textEmotions);
  
  // Video-Text correlation
  correlations['video-text'] = calculateEmotionCorrelation(videoEmotions, textEmotions);
  
  // Find inconsistency frames
  const inconsistencies = findEmotionInconsistencies(audioEmotions, videoEmotions, textEmotions);
  
  // Overall consistency
  const avgCorrelation = Object.values(correlations).reduce((sum, c) => sum + c, 0) / 3;
  const consistencyFromInconsistencies = 1 - inconsistencies.length / Math.max(1, video.frameCount) * 0.1;
  
  return {
    audioEmotions,
    videoEmotions,
    textEmotions,
    correlations,
    inconsistencies,
    overallConsistency: (avgCorrelation + consistencyFromInconsistencies) / 2
  };
}

/**
 * Extract emotions from audio features
 */
function extractAudioEmotions(audio: AudioFeatures): Array<{ [emotion: string]: number }> {
  // Simplified emotion extraction from audio
  const emotions: Array<{ [emotion: string]: number }> = [];
  
  for (let i = 0; i < audio.pitch.length; i++) {
    const pitch = audio.pitch[i];
    const energy = audio.energy[i];
    
    emotions.push({
      happy: pitch > 200 && energy > 0.5 ? 0.7 : 0.1,
      sad: pitch < 150 && energy < 0.3 ? 0.7 : 0.1,
      angry: pitch > 250 && energy > 0.7 ? 0.7 : 0.1,
      neutral: 0.3
    });
  }
  
  return emotions;
}

/**
 * Extract emotions from text
 */
function extractTextEmotions(text: TextFeatures): Array<{ [emotion: string]: number }> {
  // Simplified - return same emotion for all frames based on sentiment
  const emotion = text.sentiment > 0.2 ? 'happy' : text.sentiment < -0.2 ? 'sad' : 'neutral';
  
  return [{
    happy: emotion === 'happy' ? 0.7 : 0.1,
    sad: emotion === 'sad' ? 0.7 : 0.1,
    angry: 0.1,
    neutral: emotion === 'neutral' ? 0.5 : 0.2
  }];
}

/**
 * Calculate emotion correlation between modalities
 */
function calculateEmotionCorrelation(
  emotions1: Array<{ [emotion: string]: number }>,
  emotions2: Array<{ [emotion: string]: number }>
): number {
  if (emotions1.length === 0 || emotions2.length === 0) return 0.5;
  
  // Get dominant emotions
  const getDominant = (emotions: { [emotion: string]: number }): string => {
    let max = 0;
    let dominant = 'neutral';
    for (const [emotion, score] of Object.entries(emotions)) {
      if (score > max) {
        max = score;
        dominant = emotion;
      }
    }
    return dominant;
  };
  
  let matches = 0;
  const minLen = Math.min(emotions1.length, emotions2.length);
  
  for (let i = 0; i < minLen; i++) {
    if (getDominant(emotions1[i]) === getDominant(emotions2[Math.min(i, emotions2.length - 1)])) {
      matches++;
    }
  }
  
  return matches / minLen;
}

/**
 * Find frames with emotion inconsistencies
 */
function findEmotionInconsistencies(
  audioEmotions: Array<{ [emotion: string]: number }>,
  videoEmotions: Array<{ [emotion: string]: number }>,
  textEmotions: Array<{ [emotion: string]: number }>
): number[] {
  const inconsistencies: number[] = [];
  const minLen = Math.min(audioEmotions.length, videoEmotions.length);
  
  for (let i = 0; i < minLen; i++) {
    const audioDom = getDominantEmotion(audioEmotions[i]);
    const videoDom = getDominantEmotion(videoEmotions[i]);
    const textDom = getDominantEmotion(textEmotions[0] || {});
    
    if (audioDom !== videoDom || (audioDom !== textDom && textDom !== 'neutral')) {
      inconsistencies.push(i);
    }
  }
  
  return inconsistencies;
}

/**
 * Get dominant emotion
 */
function getDominantEmotion(emotions: { [emotion: string]: number }): string {
  let max = 0;
  let dominant = 'neutral';
  for (const [emotion, score] of Object.entries(emotions)) {
    if (score > max) {
      max = score;
      dominant = emotion;
    }
  }
  return dominant;
}

// ============================================================================
// SPEAKER IDENTITY
// ============================================================================

/**
 * Analyze speaker identity consistency
 */
export function analyzeSpeakerIdentity(
  audio: AudioFeatures,
  video: VideoFeatures
): SpeakerIdentityAnalysis {
  // Get voice embedding
  const voiceEmbedding = audio.speakerEmbedding;
  
  // Get face embedding (average across frames)
  const faceEmbedding = video.faceEmbeddings.length > 0
    ? averageEmbeddings(video.faceEmbeddings)
    : [];
  
  // Calculate match score
  const matchScore = calculateIdentityMatch(voiceEmbedding, faceEmbedding);
  
  // Calculate correlation
  const voiceFaceCorrelation = calculateEmbeddingCorrelation(voiceEmbedding, faceEmbedding);
  
  return {
    audioSpeakerId: `voice_${hashEmbedding(voiceEmbedding)}`,
    videoFaceId: `face_${hashEmbedding(faceEmbedding)}`,
    matchScore,
    voiceFaceCorrelation,
    identityConsistent: matchScore > 0.6,
    confidence: Math.min(1, matchScore + 0.1)
  };
}

/**
 * Average embeddings
 */
function averageEmbeddings(embeddings: number[][]): number[] {
  if (embeddings.length === 0) return [];
  
  const dims = embeddings[0].length;
  const avg: number[] = new Array(dims).fill(0);
  
  for (const emb of embeddings) {
    for (let i = 0; i < dims; i++) {
      avg[i] += emb[i];
    }
  }
  
  return avg.map(v => v / embeddings.length);
}

/**
 * Calculate identity match
 */
function calculateIdentityMatch(voice: number[], face: number[]): number {
  if (voice.length === 0 || face.length === 0) return 0.5;
  
  // Cross-modal matching (would use trained model in production)
  // Simplified: check if embeddings have similar structure
  const correlation = calculateEmbeddingCorrelation(voice, face);
  
  // Apply threshold
  return Math.max(0, Math.min(1, correlation * 1.5));
}

/**
 * Calculate embedding correlation
 */
function calculateEmbeddingCorrelation(emb1: number[], emb2: number[]): number {
  if (emb1.length === 0 || emb2.length === 0) return 0;
  
  const minLen = Math.min(emb1.length, emb2.length);
  
  let sum1 = 0, sum2 = 0, sumProd = 0;
  for (let i = 0; i < minLen; i++) {
    sum1 += emb1[i];
    sum2 += emb2[i];
    sumProd += emb1[i] * emb2[i];
  }
  
  const mean1 = sum1 / minLen;
  const mean2 = sum2 / minLen;
  
  let var1 = 0, var2 = 0, cov = 0;
  for (let i = 0; i < minLen; i++) {
    var1 += Math.pow(emb1[i] - mean1, 2);
    var2 += Math.pow(emb2[i] - mean2, 2);
    cov += (emb1[i] - mean1) * (emb2[i] - mean2);
  }
  
  const denom = Math.sqrt(var1 * var2);
  return denom > 0 ? cov / denom : 0;
}

/**
 * Hash embedding for ID
 */
function hashEmbedding(embedding: number[]): string {
  if (embedding.length === 0) return 'unknown';
  const sum = embedding.reduce((s, v) => s + v, 0);
  return Math.abs(Math.floor(sum * 1000)).toString(16);
}

// ============================================================================
// BACKGROUND & PHYSIOLOGICAL
// ============================================================================

/**
 * Analyze background consistency
 */
export function analyzeBackgroundConsistency(video: VideoFeatures): number {
  if (video.background.length < 2) return 1;
  
  // Check variance in background statistics
  const meanVariance = calculateFeatureVariance(video.background.map(b => b.mean));
  const stdVariance = calculateFeatureVariance(video.background.map(b => b.std));
  
  // Lower variance = more consistent
  const meanConsistency = 1 - Math.min(1, meanVariance / 100);
  const stdConsistency = 1 - Math.min(1, stdVariance / 50);
  
  return (meanConsistency + stdConsistency) / 2;
}

/**
 * Calculate feature variance
 */
function calculateFeatureVariance(features: number[][]): number {
  if (features.length === 0) return 0;
  
  const avg = features[0].map((_, i) => {
    return features.reduce((sum, f) => sum + f[i], 0) / features.length;
  });
  
  let variance = 0;
  for (const f of features) {
    for (let i = 0; i < f.length; i++) {
      variance += Math.pow(f[i] - avg[i], 2);
    }
  }
  
  return Math.sqrt(variance / features.length);
}

/**
 * Analyze physiological signals
 */
export function analyzePhysiologicalSignals(video: VideoFeatures): number {
  // Check blink patterns
  const blinkScore = analyzeBlinkPattern(video.eyeBlinks);
  
  // Check head pose naturalness
  const poseScore = analyzeHeadPose(video.headPose);
  
  // Check facial micro-expressions
  const microExpScore = analyzeMicroExpressions(video.emotions);
  
  return (blinkScore + poseScore + microExpScore) / 3;
}

/**
 * Analyze blink pattern
 */
function analyzeBlinkPattern(blinks: number[]): number {
  if (blinks.length === 0) return 0.5;
  
  // Natural blink rate: 15-20 per minute
  const blinkCount = blinks.filter(b => b === 1).length;
  const duration = blinks.length / 30; // Assuming 30 fps
  const blinkRate = blinkCount / duration * 60;
  
  // Score based on natural range
  if (blinkRate >= 12 && blinkRate <= 25) return 1;
  if (blinkRate >= 8 && blinkRate <= 30) return 0.8;
  if (blinkRate >= 5 && blinkRate <= 40) return 0.5;
  return 0.2;
}

/**
 * Analyze head pose
 */
function analyzeHeadPose(poses: Array<{ yaw: number; pitch: number; roll: number }>): number {
  if (poses.length < 2) return 0.5;
  
  // Check for unnatural movement patterns
  let jerkyMovements = 0;
  
  for (let i = 2; i < poses.length; i++) {
    const accel = {
      yaw: Math.abs(poses[i].yaw - 2 * poses[i-1].yaw + poses[i-2].yaw),
      pitch: Math.abs(poses[i].pitch - 2 * poses[i-1].pitch + poses[i-2].pitch),
      roll: Math.abs(poses[i].roll - 2 * poses[i-1].roll + poses[i-2].roll)
    };
    
    if (accel.yaw > 10 || accel.pitch > 10 || accel.roll > 5) {
      jerkyMovements++;
    }
  }
  
  return 1 - Math.min(1, jerkyMovements / poses.length * 5);
}

/**
 * Analyze micro-expressions
 */
function analyzeMicroExpressions(emotions: Array<{ [emotion: string]: number }>): number {
  if (emotions.length < 10) return 0.5;
  
  // Check for rapid emotion changes (micro-expressions)
  let rapidChanges = 0;
  
  for (let i = 1; i < emotions.length; i++) {
    const prevDom = getDominantEmotion(emotions[i-1]);
    const currDom = getDominantEmotion(emotions[i]);
    
    if (prevDom !== currDom) {
      rapidChanges++;
    }
  }
  
  // Some change is natural, too much is suspicious
  const changeRate = rapidChanges / emotions.length;
  
  if (changeRate < 0.05) return 0.6; // Too static
  if (changeRate > 0.3) return 0.4; // Too chaotic
  return 0.9; // Natural
}

// ============================================================================
// SEMANTIC ALIGNMENT
// ============================================================================

/**
 * Analyze semantic alignment
 */
export function analyzeSemanticAlignment(
  audio: AudioFeatures,
  text: TextFeatures,
  video: VideoFeatures
): number {
  // Check if transcript matches speaking rate
  const speakingRateMatch = Math.abs(audio.speakingRate - text.words.length / (audio.duration || 1)) < 2 ? 1 : 0.5;
  
  // Check if lip movements match word count
  const lipMovements = detectLipMovements(video.lipLandmarks);
  const movementCount = lipMovements.filter(m => m === 1).length;
  const wordMovementMatch = Math.abs(movementCount - text.words.length * 2) < text.words.length ? 1 : 0.5;
  
  return (speakingRateMatch + wordMovementMatch) / 2;
}

// ============================================================================
// OVERALL CALCULATIONS
// ============================================================================

/**
 * Calculate overall consistency
 */
function calculateOverallConsistency(
  modalityScores: Map<ModalityType, number>,
  pairwiseScores: Map<string, number>,
  inconsistencies: Inconsistency[]
): number {
  // Average modality scores
  const modalityAvg = Array.from(modalityScores.values()).reduce((sum, s) => sum + s, 0) / modalityScores.size;
  
  // Average pairwise scores
  const pairwiseAvg = Array.from(pairwiseScores.values()).reduce((sum, s) => sum + s, 0) / pairwiseScores.size;
  
  // Penalty for inconsistencies
  const severityWeights = { low: 0.05, medium: 0.1, high: 0.2, critical: 0.4 };
  const inconsistencyPenalty = inconsistencies.reduce((sum, inc) => {
    return sum + severityWeights[inc.severity] * inc.confidence;
  }, 0);
  
  return Math.max(0, Math.min(1, (modalityAvg + pairwiseAvg) / 2 - inconsistencyPenalty));
}

/**
 * Calculate authentic probability
 */
function calculateAuthenticProbability(
  consistency: number,
  inconsistencies: Inconsistency[]
): number {
  // Base probability from consistency
  let probability = consistency;
  
  // Critical inconsistencies strongly indicate deepfake
  const criticalCount = inconsistencies.filter(i => i.severity === 'critical').length;
  probability *= Math.pow(0.5, criticalCount);
  
  // High severity inconsistencies
  const highCount = inconsistencies.filter(i => i.severity === 'high').length;
  probability *= Math.pow(0.8, highCount);
  
  return probability;
}

/**
 * Generate recommendations
 */
function generateRecommendations(inconsistencies: Inconsistency[]): string[] {
  const recommendations: string[] = [];
  
  if (inconsistencies.length === 0) {
    recommendations.push('Content appears consistent across all modalities');
    return recommendations;
  }
  
  for (const inc of inconsistencies) {
    switch (inc.type) {
      case 'lip_sync_mismatch':
        recommendations.push('Review lip synchronization - possible audio-video manipulation');
        break;
      case 'emotion_mismatch':
        recommendations.push('Emotion inconsistency detected - possible AI-generated content');
        break;
      case 'speaker_identity_mismatch':
        recommendations.push('Speaker identity mismatch - possible voice cloning or face swap');
        break;
      case 'physiological_anomaly':
        recommendations.push('Unnatural physiological signals - possible synthetic media');
        break;
      case 'background_inconsistency':
        recommendations.push('Background inconsistencies detected - possible compositing');
        break;
    }
  }
  
  return [...new Set(recommendations)];
}

// ============================================================================
// STATUS & TESTS
// ============================================================================

/**
 * Get cross-modal status
 */
export function getCrossModalStatus(): {
  analysesPerformed: number;
  averageConsistency: number;
  deepfakesDetected: number;
  mostCommonInconsistency: string;
} {
  const history = analysisHistory;
  
  const avgConsistency = history.length > 0
    ? history.reduce((sum, r) => sum + r.overallConsistency, 0) / history.length
    : 0;
  
  const deepfakes = history.filter(r => r.authenticProbability < 0.5).length;
  
  // Find most common inconsistency
  const typeCounts = new Map<string, number>();
  for (const result of history) {
    for (const inc of result.inconsistencies) {
      typeCounts.set(inc.type, (typeCounts.get(inc.type) || 0) + 1);
    }
  }
  
  let mostCommon = 'none';
  let maxCount = 0;
  for (const [type, count] of typeCounts) {
    if (count > maxCount) {
      maxCount = count;
      mostCommon = type;
    }
  }
  
  return {
    analysesPerformed: history.length,
    averageConsistency: avgConsistency,
    deepfakesDetected: deepfakes,
    mostCommonInconsistency: mostCommon
  };
}

/**
 * Run cross-modal tests
 */
export function runCrossModalTests(): {
  passed: boolean;
  tests: { total: number; passed: number; failed: number };
  results: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const results: Array<{ name: string; passed: boolean; error?: string }> = [];
  
  // Test 1: Sync analysis
  try {
    const audio: AudioFeatures = {
      duration: 10, sampleRate: 16000, channels: 1, energy: Array(100).fill(0.5),
      pitch: Array(100).fill(200), mfcc: [], zeroCrossingRate: [], spectralCentroid: [],
      spectralRolloff: [], speakingRate: 3, pauses: [], voiceActivity: Array(100).fill(true),
      speakerEmbedding: Array(128).fill(0.5)
    };
    const video: VideoFeatures = {
      duration: 10, frameCount: 300, fps: 30, resolution: [640, 480],
      faceDetected: Array(300).fill(true), faceBoundingBoxes: [], faceLandmarks: [],
      faceEmbeddings: [Array(512).fill(0.5)], lipLandmarks: [Array(24).fill([0, 0] as [number, number])],
      eyeBlinks: Array(300).fill(0), headPose: Array(300).fill({ yaw: 0, pitch: 0, roll: 0 }),
      emotions: Array(300).fill({ happy: 0.3, sad: 0.1, neutral: 0.5 }),
      background: Array(300).fill({ mean: [100, 100, 100], std: [20, 20, 20] }),
      lighting: Array(300).fill({ direction: [0, 1, 0], intensity: 0.8 })
    };
    
    const sync = analyzeAudioVideoSync(audio, video);
    if (sync.overallSync < 0 || sync.overallSync > 1) {
      throw new Error('Invalid sync score');
    }
    results.push({ name: 'Sync Analysis', passed: true });
  } catch (e) {
    results.push({ name: 'Sync Analysis', passed: false, error: String(e) });
  }
  
  // Test 2: Emotion consistency
  try {
    const audio: AudioFeatures = {
      duration: 10, sampleRate: 16000, channels: 1, energy: Array(100).fill(0.5),
      pitch: Array(100).fill(200), mfcc: [], zeroCrossingRate: [], spectralCentroid: [],
      spectralRolloff: [], speakingRate: 3, pauses: [], voiceActivity: Array(100).fill(true),
      speakerEmbedding: Array(128).fill(0.5)
    };
    const video: VideoFeatures = {
      duration: 10, frameCount: 300, fps: 30, resolution: [640, 480],
      faceDetected: Array(300).fill(true), faceBoundingBoxes: [], faceLandmarks: [],
      faceEmbeddings: [Array(512).fill(0.5)], lipLandmarks: [Array(24).fill([0, 0] as [number, number])],
      eyeBlinks: Array(300).fill(0), headPose: Array(300).fill({ yaw: 0, pitch: 0, roll: 0 }),
      emotions: Array(300).fill({ happy: 0.7, sad: 0.1, neutral: 0.1 }),
      background: Array(300).fill({ mean: [100, 100, 100], std: [20, 20, 20] }),
      lighting: Array(300).fill({ direction: [0, 1, 0], intensity: 0.8 })
    };
    const text: TextFeatures = {
      transcript: 'Hello world',
      words: ['Hello', 'world'],
      wordTimestamps: [{ word: 'Hello', start: 0, end: 0.5 }, { word: 'world', start: 0.6, end: 1 }],
      sentiment: 0.5, entities: [], language: 'en', confidence: 0.9
    };
    
    const emotion = analyzeEmotionConsistency(audio, video, text);
    if (emotion.overallConsistency < 0 || emotion.overallConsistency > 1) {
      throw new Error('Invalid emotion consistency');
    }
    results.push({ name: 'Emotion Consistency', passed: true });
  } catch (e) {
    results.push({ name: 'Emotion Consistency', passed: false, error: String(e) });
  }
  
  // Test 3: Full analysis
  try {
    const audio: AudioFeatures = {
      duration: 10, sampleRate: 16000, channels: 1, energy: Array(100).fill(0.5),
      pitch: Array(100).fill(200), mfcc: [], zeroCrossingRate: [], spectralCentroid: [],
      spectralRolloff: [], speakingRate: 3, pauses: [], voiceActivity: Array(100).fill(true),
      speakerEmbedding: Array(128).fill(0.5)
    };
    const video: VideoFeatures = {
      duration: 10, frameCount: 300, fps: 30, resolution: [640, 480],
      faceDetected: Array(300).fill(true), faceBoundingBoxes: [], faceLandmarks: [],
      faceEmbeddings: [Array(512).fill(0.5)], lipLandmarks: [Array(24).fill([0, 0] as [number, number])],
      eyeBlinks: Array(300).fill(0), headPose: Array(300).fill({ yaw: 0, pitch: 0, roll: 0 }),
      emotions: Array(300).fill({ happy: 0.3, sad: 0.1, neutral: 0.5 }),
      background: Array(300).fill({ mean: [100, 100, 100], std: [20, 20, 20] }),
      lighting: Array(300).fill({ direction: [0, 1, 0], intensity: 0.8 })
    };
    const text: TextFeatures = {
      transcript: 'Test transcript',
      words: ['Test', 'transcript'],
      wordTimestamps: [],
      sentiment: 0.5, entities: [], language: 'en', confidence: 0.9
    };
    
    const result = analyzeCrossModal(audio, video, text);
    if (!result.id || result.overallConsistency < 0) {
      throw new Error('Full analysis failed');
    }
    results.push({ name: 'Full Cross-Modal Analysis', passed: true });
  } catch (e) {
    results.push({ name: 'Full Cross-Modal Analysis', passed: false, error: String(e) });
  }
  
  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;
  
  return {
    passed: failed === 0,
    tests: { total: results.length, passed, failed },
    results
  };
}

// Default export
const crossModalModule = {
  // Main analysis
  analyzeCrossModal,
  
  // Component analysis
  analyzeAudioVideoSync,
  analyzeEmotionConsistency,
  analyzeSpeakerIdentity,
  analyzeBackgroundConsistency,
  analyzePhysiologicalSignals,
  analyzeSemanticAlignment,
  
  // Status
  getCrossModalStatus,
  
  // Tests
  runCrossModalTests
};

export default crossModalModule;
