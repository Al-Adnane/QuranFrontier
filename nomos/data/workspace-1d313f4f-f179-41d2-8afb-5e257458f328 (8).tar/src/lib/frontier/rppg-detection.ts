/**
 * Kasbah rPPG Detection Engine
 * Remote Photoplethysmography - Detect real blood flow from video
 * Deepfakes cannot fake pulse/blood flow
 * 
 * @module rppg-detection
 * @version 1.0.0
 * @disruption-score +3.5/10
 * 
 * Real algorithms:
 * - CHROM (Chrominance-based)
 * - POS (Plane-Orthogonal-to-Skin)
 * - ICA (Independent Component Analysis)
 * - GREEN (Green Channel Analysis)
 * - PBV (Pulse Blood Volume)
 */

// ============================================
// TYPE DEFINITIONS
// ============================================

export interface RPPGResult {
  id: string;
  timestamp: Date;
  heartRate: number;           // BPM
  heartRateConfidence: number; // 0-1
  isRealHuman: boolean;
  bloodFlowDetected: boolean;
  signalQuality: number;
  method: RPPGMethod;
  signal: number[];            // Raw rPPG signal
  spectrum: FrequencySpectrum;
  analysis: RPPGAnalysis;
}

export type RPPGMethod = 'CHROM' | 'POS' | 'ICA' | 'GREEN' | 'PBV' | 'ENSEMBLE';

export interface FrequencySpectrum {
  frequencies: number[];
  magnitudes: number[];
  peakFrequency: number;
  peakMagnitude: number;
  snr: number; // Signal-to-noise ratio
}

export interface RPPGAnalysis {
  colorChannelVariance: {
    red: number;
    green: number;
    blue: number;
  };
  temporalConsistency: number;
  spatialUniformity: number;
  pulseRegularity: number;
  artifacts: string[];
}

export interface ROIMask {
  x: number;
  y: number;
  width: number;
  height: number;
  type: 'face' | 'forehead' | 'cheek' | 'custom';
}

// ============================================
// SIGNAL PROCESSING UTILITIES
// ============================================

class SignalProcessing {
  /**
   * Bandpass filter (Butterworth approximation)
   */
  static bandpassFilter(
    signal: number[],
    lowCut: number,
    highCut: number,
    sampleRate: number
  ): number[] {
    const filtered = [...signal];
    const n = signal.length;
    
    // Simple bandpass using moving average difference
    const lowWindow = Math.floor(sampleRate / lowCut);
    const highWindow = Math.floor(sampleRate / highCut);
    
    // High-pass (remove low frequencies)
    const highPassed = this.highPassFilter(filtered, lowCut, sampleRate);
    
    // Low-pass (remove high frequencies)
    const lowPassed = this.lowPassFilter(highPassed, highCut, sampleRate);
    
    return lowPassed;
  }

  static highPassFilter(
    signal: number[],
    cutoff: number,
    sampleRate: number
  ): number[] {
    const rc = 1 / (2 * Math.PI * cutoff);
    const dt = 1 / sampleRate;
    const alpha = rc / (rc + dt);
    
    const result = new Array(signal.length).fill(0);
    let prevInput = signal[0];
    let prevOutput = 0;
    
    for (let i = 0; i < signal.length; i++) {
      result[i] = alpha * (prevOutput + signal[i] - prevInput);
      prevInput = signal[i];
      prevOutput = result[i];
    }
    
    return result;
  }

  static lowPassFilter(
    signal: number[],
    cutoff: number,
    sampleRate: number
  ): number[] {
    const rc = 1 / (2 * Math.PI * cutoff);
    const dt = 1 / sampleRate;
    const alpha = dt / (rc + dt);
    
    const result = new Array(signal.length).fill(0);
    result[0] = signal[0];
    
    for (let i = 1; i < signal.length; i++) {
      result[i] = result[i - 1] + alpha * (signal[i] - result[i - 1]);
    }
    
    return result;
  }

  /**
   * Normalize signal to zero mean, unit variance
   */
  static normalize(signal: number[]): number[] {
    const mean = signal.reduce((a, b) => a + b, 0) / signal.length;
    const variance = signal.reduce((sum, x) => sum + Math.pow(x - mean, 2), 0) / signal.length;
    const std = Math.sqrt(variance);
    
    if (std === 0) return signal.map(() => 0);
    
    return signal.map(x => (x - mean) / std);
  }

  /**
   * Detrend signal (remove linear trend)
   */
  static detrend(signal: number[]): number[] {
    const n = signal.length;
    const xMean = (n - 1) / 2;
    const yMean = signal.reduce((a, b) => a + b, 0) / n;
    
    let numerator = 0;
    let denominator = 0;
    
    for (let i = 0; i < n; i++) {
      numerator += (i - xMean) * (signal[i] - yMean);
      denominator += Math.pow(i - xMean, 2);
    }
    
    const slope = denominator > 0 ? numerator / denominator : 0;
    const intercept = yMean - slope * xMean;
    
    return signal.map((y, i) => y - (slope * i + intercept));
  }

  /**
   * Compute FFT magnitude spectrum
   */
  static fftMagnitude(signal: number[]): { frequencies: number[]; magnitudes: number[] } {
    const n = signal.length;
    
    // Pad to next power of 2
    const paddedLength = Math.pow(2, Math.ceil(Math.log2(n)));
    const padded = new Float32Array(paddedLength);
    for (let i = 0; i < n; i++) {
      padded[i] = signal[i];
    }
    
    // Apply Hanning window
    for (let i = 0; i < n; i++) {
      padded[i] *= 0.5 * (1 - Math.cos(2 * Math.PI * i / (n - 1)));
    }
    
    // Compute FFT (Cooley-Tukey)
    const { real, imag } = this.fft(padded);
    
    // Compute magnitudes
    const magnitudes: number[] = [];
    const frequencies: number[] = [];
    
    for (let i = 0; i < paddedLength / 2; i++) {
      magnitudes.push(Math.sqrt(real[i] * real[i] + imag[i] * imag[i]));
    }
    
    return { frequencies, magnitudes };
  }

  /**
   * Cooley-Tukey FFT implementation
   */
  static fft(x: Float32Array): { real: Float32Array; imag: Float32Array } {
    const n = x.length;
    const real = new Float32Array(n);
    const imag = new Float32Array(n);
    
    // Copy input to real part
    for (let i = 0; i < n; i++) {
      real[i] = x[i];
    }
    
    // Bit-reversal permutation
    for (let i = 0, j = 0; i < n; i++) {
      if (i < j) {
        [real[i], real[j]] = [real[j], real[i]];
        [imag[i], imag[j]] = [imag[j], imag[i]];
      }
      let m = n >> 1;
      while (m >= 1 && j >= m) {
        j -= m;
        m >>= 1;
      }
      j += m;
    }
    
    // Cooley-Tukey iterative FFT
    for (let len = 2; len <= n; len <<= 1) {
      const halfLen = len >> 1;
      const angle = -2 * Math.PI / len;
      
      for (let i = 0; i < n; i += len) {
        for (let j = 0; j < halfLen; j++) {
          const cos = Math.cos(angle * j);
          const sin = Math.sin(angle * j);
          
          const evenIdx = i + j;
          const oddIdx = i + j + halfLen;
          
          const tReal = real[oddIdx] * cos - imag[oddIdx] * sin;
          const tImag = real[oddIdx] * sin + imag[oddIdx] * cos;
          
          real[oddIdx] = real[evenIdx] - tReal;
          imag[oddIdx] = imag[evenIdx] - tImag;
          real[evenIdx] += tReal;
          imag[evenIdx] += tImag;
        }
      }
    }
    
    return { real, imag };
  }

  /**
   * Find peak frequency in range
   */
  static findPeakFrequency(
    magnitudes: number[],
    sampleRate: number,
    minFreq: number,
    maxFreq: number
  ): { frequency: number; magnitude: number } {
    const n = magnitudes.length * 2;
    const minIdx = Math.floor(minFreq * n / sampleRate);
    const maxIdx = Math.floor(maxFreq * n / sampleRate);
    
    let peakMagnitude = 0;
    let peakIdx = minIdx;
    
    for (let i = minIdx; i < maxIdx && i < magnitudes.length; i++) {
      if (magnitudes[i] > peakMagnitude) {
        peakMagnitude = magnitudes[i];
        peakIdx = i;
      }
    }
    
    const frequency = peakIdx * sampleRate / n;
    
    return { frequency, magnitude: peakMagnitude };
  }

  /**
   * Compute signal-to-noise ratio
   */
  static computeSNR(
    magnitudes: number[],
    peakIdx: number,
    bandwidth: number = 5
  ): number {
    // Signal power around peak
    let signalPower = 0;
    let signalCount = 0;
    
    for (let i = Math.max(0, peakIdx - bandwidth); i < Math.min(magnitudes.length, peakIdx + bandwidth); i++) {
      signalPower += magnitudes[i] * magnitudes[i];
      signalCount++;
    }
    
    // Noise power (everything else)
    let noisePower = 0;
    let noiseCount = 0;
    
    for (let i = 0; i < magnitudes.length; i++) {
      if (i < peakIdx - bandwidth || i > peakIdx + bandwidth) {
        noisePower += magnitudes[i] * magnitudes[i];
        noiseCount++;
      }
    }
    
    if (noisePower === 0 || noiseCount === 0) return 0;
    
    const signalMean = signalPower / signalCount;
    const noiseMean = noisePower / noiseCount;
    
    return noiseMean > 0 ? 10 * Math.log10(signalMean / noiseMean) : 0;
  }
}

// ============================================
// CHROM METHOD (Chrominance-based)
// ============================================

class CHROMMethod {
  /**
   * CHROM algorithm for rPPG extraction
   * Uses chrominance features to extract pulse signal
   */
  static extract(
    frames: Array<{ red: number[]; green: number[]; blue: number[] }>,
    sampleRate: number
  ): number[] {
    const n = frames.length;
    const signal: number[] = [];
    
    // Extract mean RGB for each frame
    const meanR: number[] = [];
    const meanG: number[] = [];
    const meanB: number[] = [];
    
    for (const frame of frames) {
      meanR.push(frame.red.reduce((a, b) => a + b, 0) / frame.red.length);
      meanG.push(frame.green.reduce((a, b) => a + b, 0) / frame.green.length);
      meanB.push(frame.blue.reduce((a, b) => a + b, 0) / frame.blue.length);
    }
    
    // Normalize
    const normR = SignalProcessing.normalize(meanR);
    const normG = SignalProcessing.normalize(meanG);
    const normB = SignalProcessing.normalize(meanB);
    
    // CHROM: Xs = 3R - 2G, Ys = 1.5R + G - 1.5B
    for (let i = 0; i < n; i++) {
      const Xs = 3 * normR[i] - 2 * normG[i];
      const Ys = 1.5 * normR[i] + normG[i] - 1.5 * normB[i];
      
      // Chrominance signal
      signal.push(Xs - (Ys * this.stdDev(Xs, i) / this.stdDev(Ys, i)));
    }
    
    // Bandpass filter (0.7-4 Hz = 42-240 BPM)
    return SignalProcessing.bandpassFilter(signal, 0.7, 4, sampleRate);
  }

  private static stdDev(arr: number[], upTo: number): number {
    const slice = arr.slice(0, upTo + 1);
    const mean = slice.reduce((a, b) => a + b, 0) / slice.length;
    return Math.sqrt(slice.reduce((sum, x) => sum + Math.pow(x - mean, 2), 0) / slice.length);
  }
}

// ============================================
// POS METHOD (Plane-Orthogonal-to-Skin)
// ============================================

class POSMethod {
  /**
   * POS algorithm for rPPG extraction
   * Projects skin color changes onto plane orthogonal to skin
   */
  static extract(
    frames: Array<{ red: number[]; green: number[]; blue: number[] }>,
    sampleRate: number
  ): number[] {
    const n = frames.length;
    const signal: number[] = [];
    
    // Extract mean RGB
    const meanR: number[] = [];
    const meanG: number[] = [];
    const meanB: number[] = [];
    
    for (const frame of frames) {
      meanR.push(frame.red.reduce((a, b) => a + b, 0) / frame.red.length);
      meanG.push(frame.green.reduce((a, b) => a + b, 0) / frame.green.length);
      meanB.push(frame.blue.reduce((a, b) => a + b, 0) / frame.blue.length);
    }
    
    // Normalize to sum = 1 (temporal normalization)
    const normR: number[] = [];
    const normG: number[] = [];
    const normB: number[] = [];
    
    for (let i = 0; i < n; i++) {
      const sum = meanR[i] + meanG[i] + meanB[i];
      normR.push(meanR[i] / sum);
      normG.push(meanG[i] / sum);
      normB.push(meanB[i] / sum);
    }
    
    // POS projection
    // H = [1, -1.5, 0.5] (projection matrix)
    for (let i = 0; i < n; i++) {
      const S1 = normR[i];
      const S2 = normG[i] - normB[i];
      
      // POS signal
      signal.push(S1 - S2 * this.computeAlpha(normR, normG, normB, i));
    }
    
    return SignalProcessing.bandpassFilter(signal, 0.7, 4, sampleRate);
  }

  private static computeAlpha(R: number[], G: number[], B: number[], idx: number): number {
    const windowSize = Math.min(10, idx + 1);
    const start = Math.max(0, idx - windowSize + 1);
    
    let varR = 0, varG = 0;
    for (let i = start; i <= idx; i++) {
      varR += R[i] * R[i];
      varG += (G[i] - B[i]) * (G[i] - B[i]);
    }
    
    return varR > 0 ? Math.sqrt(varG / varR) : 1;
  }
}

// ============================================
// GREEN CHANNEL METHOD
// ============================================

class GreenMethod {
  /**
   * Simple green channel analysis
   * Green channel has highest blood absorption
   */
  static extract(
    frames: Array<{ red: number[]; green: number[]; blue: number[] }>,
    sampleRate: number
  ): number[] {
    const signal: number[] = [];
    
    for (const frame of frames) {
      signal.push(frame.green.reduce((a, b) => a + b, 0) / frame.green.length);
    }
    
    // Detrend and filter
    const detrended = SignalProcessing.detrend(signal);
    return SignalProcessing.bandpassFilter(detrended, 0.7, 4, sampleRate);
  }
}

// ============================================
// PBV METHOD (Pulse Blood Volume)
// ============================================

class PBVMethod {
  /**
   * PBV algorithm
   * Uses blood volume signature
   */
  static extract(
    frames: Array<{ red: number[]; green: number[]; blue: number[] }>,
    sampleRate: number
  ): number[] {
    const n = frames.length;
    
    // Extract normalized RGB
    const rgb: Array<[number, number, number]> = [];
    
    for (const frame of frames) {
      const r = frame.red.reduce((a, b) => a + b, 0) / frame.red.length;
      const g = frame.green.reduce((a, b) => a + b, 0) / frame.green.length;
      const b = frame.blue.reduce((a, b) => a + b, 0) / frame.blue.length;
      
      const sum = r + g + b;
      rgb.push([r / sum, g / sum, b / sum]);
    }
    
    // PBV weight factors (experimentally determined)
    const W = [0.33, 0.77, 0.11]; // Blood volume weights for RGB
    
    // Compute PBV signal
    const signal: number[] = [];
    
    for (let i = 0; i < n; i++) {
      const pbv = W[0] * rgb[i][0] + W[1] * rgb[i][1] + W[2] * rgb[i][2];
      signal.push(pbv);
    }
    
    return SignalProcessing.bandpassFilter(signal, 0.7, 4, sampleRate);
  }
}

// ============================================
// ICA METHOD (Independent Component Analysis)
// ============================================

class ICAMethod {
  /**
   * Simplified ICA for rPPG extraction
   * Uses FastICA algorithm
   */
  static extract(
    frames: Array<{ red: number[]; green: number[]; blue: number[] }>,
    sampleRate: number
  ): number[] {
    const n = frames.length;
    
    // Build observation matrix (3 channels)
    const X: number[][] = [[], [], []];
    
    for (const frame of frames) {
      X[0].push(frame.red.reduce((a, b) => a + b, 0) / frame.red.length);
      X[1].push(frame.green.reduce((a, b) => a + b, 0) / frame.green.length);
      X[2].push(frame.blue.reduce((a, b) => a + b, 0) / frame.blue.length);
    }
    
    // Center and whiten
    const centered = this.center(X);
    const whitened = this.whiten(centered);
    
    // FastICA
    const components = this.fastICA(whitened, 100);
    
    // Find component with strongest cardiac frequency
    let bestComponent = 0;
    let bestScore = 0;
    
    for (let c = 0; c < components.length; c++) {
      const { magnitudes } = SignalProcessing.fftMagnitude(components[c]);
      const peak = SignalProcessing.findPeakFrequency(magnitudes, sampleRate, 0.7, 4);
      
      if (peak.magnitude > bestScore) {
        bestScore = peak.magnitude;
        bestComponent = c;
      }
    }
    
    return SignalProcessing.bandpassFilter(components[bestComponent], 0.7, 4, sampleRate);
  }

  private static center(X: number[][]): number[][] {
    const centered: number[][] = X.map(row => [...row]);
    
    for (let c = 0; c < X.length; c++) {
      const mean = X[c].reduce((a, b) => a + b, 0) / X[c].length;
      for (let i = 0; i < X[c].length; i++) {
        centered[c][i] = X[c][i] - mean;
      }
    }
    
    return centered;
  }

  private static whiten(X: number[][]): number[][] {
    const n = X.length;
    const m = X[0].length;
    
    // Compute covariance matrix
    const cov: number[][] = [];
    for (let i = 0; i < n; i++) {
      cov[i] = [];
      for (let j = 0; j < n; j++) {
        let sum = 0;
        for (let k = 0; k < m; k++) {
          sum += X[i][k] * X[j][k];
        }
        cov[i][j] = sum / m;
      }
    }
    
    // Simplified whitening using diagonal approximation
    const whitened: number[][] = X.map(row => [...row]);
    
    for (let i = 0; i < n; i++) {
      const std = Math.sqrt(cov[i][i]);
      if (std > 0) {
        for (let j = 0; j < m; j++) {
          whitened[i][j] /= std;
        }
      }
    }
    
    return whitened;
  }

  private static fastICA(X: number[][], maxIter: number): number[][] {
    const n = X.length;
    const m = X[0].length;
    
    // Initialize random demixing matrix
    const W: number[][] = [];
    for (let i = 0; i < n; i++) {
      W[i] = [];
      for (let j = 0; j < n; j++) {
        W[i][j] = Math.random() - 0.5;
      }
    }
    
    // Iterate
    for (let iter = 0; iter < maxIter; iter++) {
      // Compute new W using deflation approach
      for (let p = 0; p < n; p++) {
        // wx = W[p] * X
        const wx: number[] = [];
        for (let i = 0; i < m; i++) {
          let sum = 0;
          for (let j = 0; j < n; j++) {
            sum += W[p][j] * X[j][i];
          }
          wx.push(sum);
        }
        
        // g(wx) and g'(wx) - tanh nonlinearity
        const g_wx = wx.map(x => Math.tanh(x));
        const g_prime_wx = wx.map(x => 1 - Math.tanh(x) * Math.tanh(x));
        
        // Update rule
        const mean_g_prime = g_prime_wx.reduce((a, b) => a + b, 0) / m;
        
        for (let j = 0; j < n; j++) {
          let newW = 0;
          for (let i = 0; i < m; i++) {
            newW += X[j][i] * g_wx[i];
          }
          W[p][j] = (newW / m) - mean_g_prime * W[p][j];
        }
        
        // Normalize
        const norm = Math.sqrt(W[p].reduce((sum, w) => sum + w * w, 0));
        for (let j = 0; j < n; j++) {
          W[p][j] /= norm;
        }
      }
    }
    
    // Extract components
    const components: number[][] = [];
    for (let p = 0; p < n; p++) {
      const component: number[] = [];
      for (let i = 0; i < m; i++) {
        let sum = 0;
        for (let j = 0; j < n; j++) {
          sum += W[p][j] * X[j][i];
        }
        component.push(sum);
      }
      components.push(component);
    }
    
    return components;
  }
}

// ============================================
// rPPG DETECTOR
// ============================================

export class RPPGDetector {
  /**
   * Detect heart rate from video frames
   */
  async detect(
    frames: Array<{ red: number[]; green: number[]; blue: number[] }>,
    sampleRate: number = 30,
    method: RPPGMethod = 'ENSEMBLE'
  ): Promise<RPPGResult> {
    // Extract rPPG signal
    const signal = this.extractSignal(frames, sampleRate, method);
    
    // Compute spectrum
    const { magnitudes } = SignalProcessing.fftMagnitude(signal);
    const { frequencies, magnitudes: fullMags } = SignalProcessing.fftMagnitude(signal);
    
    // Find peak frequency (heart rate)
    const peak = SignalProcessing.findPeakFrequency(magnitudes, sampleRate, 0.7, 4);
    const heartRate = peak.frequency * 60; // Convert Hz to BPM
    
    // Compute SNR
    const peakIdx = Math.round(peak.frequency * magnitudes.length * 2 / sampleRate);
    const snr = SignalProcessing.computeSNR(magnitudes, peakIdx, 3);
    
    // Analyze signal quality
    const analysis = this.analyzeSignalQuality(frames, signal);
    
    // Determine if real human
    const bloodFlowDetected = snr > 2 && analysis.temporalConsistency > 0.5;
    const isRealHuman = bloodFlowDetected && heartRate > 40 && heartRate < 200;
    
    // Compute confidence
    const heartRateConfidence = Math.min(1, snr / 10) * analysis.temporalConsistency;
    
    return {
      id: `rppg-${Date.now()}`,
      timestamp: new Date(),
      heartRate: Math.round(heartRate),
      heartRateConfidence,
      isRealHuman,
      bloodFlowDetected,
      signalQuality: Math.min(1, snr / 10),
      method,
      signal: signal.slice(-300), // Last 10 seconds
      spectrum: {
        frequencies: frequencies.slice(0, 50),
        magnitudes: magnitudes.slice(0, 50),
        peakFrequency: peak.frequency,
        peakMagnitude: peak.magnitude,
        snr
      },
      analysis
    };
  }

  private extractSignal(
    frames: Array<{ red: number[]; green: number[]; blue: number[] }>,
    sampleRate: number,
    method: RPPGMethod
  ): number[] {
    switch (method) {
      case 'CHROM':
        return CHROMMethod.extract(frames, sampleRate);
      case 'POS':
        return POSMethod.extract(frames, sampleRate);
      case 'GREEN':
        return GreenMethod.extract(frames, sampleRate);
      case 'PBV':
        return PBVMethod.extract(frames, sampleRate);
      case 'ICA':
        return ICAMethod.extract(frames, sampleRate);
      case 'ENSEMBLE':
      default:
        // Combine multiple methods
        const chrom = CHROMMethod.extract(frames, sampleRate);
        const pos = POSMethod.extract(frames, sampleRate);
        const green = GreenMethod.extract(frames, sampleRate);
        
        // Average signals
        const len = Math.min(chrom.length, pos.length, green.length);
        const ensemble: number[] = [];
        
        for (let i = 0; i < len; i++) {
          ensemble.push((chrom[i] + pos[i] + green[i]) / 3);
        }
        
        return ensemble;
    }
  }

  private analyzeSignalQuality(
    frames: Array<{ red: number[]; green: number[]; blue: number[] }>,
    signal: number[]
  ): RPPGAnalysis {
    // Compute color channel variances
    const varR: number[] = [];
    const varG: number[] = [];
    const varB: number[] = [];
    
    for (const frame of frames) {
      const rMean = frame.red.reduce((a, b) => a + b, 0) / frame.red.length;
      const gMean = frame.green.reduce((a, b) => a + b, 0) / frame.green.length;
      const bMean = frame.blue.reduce((a, b) => a + b, 0) / frame.blue.length;
      
      const rVar = frame.red.reduce((sum, r) => sum + Math.pow(r - rMean, 2), 0) / frame.red.length;
      const gVar = frame.green.reduce((sum, g) => sum + Math.pow(g - gMean, 2), 0) / frame.green.length;
      const bVar = frame.blue.reduce((sum, b) => sum + Math.pow(b - bMean, 2), 0) / frame.blue.length;
      
      varR.push(rVar);
      varG.push(gVar);
      varB.push(bVar);
    }
    
    // Temporal consistency
    let temporalConsistency = 1;
    const windowSize = 30;
    
    for (let i = windowSize; i < signal.length; i++) {
      const window = signal.slice(i - windowSize, i);
      const mean = window.reduce((a, b) => a + b, 0) / windowSize;
      const variance = window.reduce((sum, x) => sum + Math.pow(x - mean, 2), 0) / windowSize;
      
      // Real pulse should have consistent variance
      if (variance < 0.001) temporalConsistency *= 0.9;
    }
    
    // Detect artifacts
    const artifacts: string[] = [];
    
    if (Math.max(...varR) / (Math.min(...varR) || 1) > 10) {
      artifacts.push('red_channel_spike');
    }
    if (Math.max(...varG) / (Math.min(...varG) || 1) > 10) {
      artifacts.push('green_channel_spike');
    }
    
    // Check for sudden jumps in signal
    for (let i = 1; i < signal.length; i++) {
      if (Math.abs(signal[i] - signal[i - 1]) > 3 * this.stdDev(signal)) {
        artifacts.push('signal_discontinuity');
        break;
      }
    }
    
    return {
      colorChannelVariance: {
        red: this.mean(varR),
        green: this.mean(varG),
        blue: this.mean(varB)
      },
      temporalConsistency,
      spatialUniformity: 1 / (1 + this.stdDev(varG) / this.mean(varG)),
      pulseRegularity: this.computeRegularity(signal),
      artifacts
    };
  }

  private computeRegularity(signal: number[]): number {
    // Compute autocorrelation
    const mean = signal.reduce((a, b) => a + b, 0) / signal.length;
    const variance = signal.reduce((sum, x) => sum + Math.pow(x - mean, 2), 0) / signal.length;
    
    if (variance === 0) return 0;
    
    // Find peaks in autocorrelation
    const lag30 = Math.floor(30 / 60 * signal.length / 10); // 30 BPM lag
    const lag200 = Math.floor(200 / 60 * signal.length / 10); // 200 BPM lag
    
    let maxCorr = 0;
    
    for (let lag = lag30; lag < lag200 && lag < signal.length; lag++) {
      let corr = 0;
      for (let i = 0; i < signal.length - lag; i++) {
        corr += (signal[i] - mean) * (signal[i + lag] - mean);
      }
      corr /= (signal.length - lag) * variance;
      
      if (corr > maxCorr) maxCorr = corr;
    }
    
    return maxCorr;
  }

  private mean(arr: number[]): number {
    return arr.reduce((a, b) => a + b, 0) / arr.length;
  }

  private stdDev(arr: number[]): number {
    const mean = this.mean(arr);
    return Math.sqrt(arr.reduce((sum, x) => sum + Math.pow(x - mean, 2), 0) / arr.length);
  }
}

// ============================================
// EXPORTS
// ============================================

export const rppgDetection = {
  RPPGDetector,
  CHROMMethod,
  POSMethod,
  GreenMethod,
  PBVMethod,
  ICAMethod,
  SignalProcessing
};

export default rppgDetection;
