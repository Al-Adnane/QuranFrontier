/**
 * Quantum-Resistant Cryptography Module
 * 
 * Post-quantum cryptographic primitives for future-proof detection proofs.
 * Implements NIST Post-Quantum Cryptography Standardization candidates.
 * 
 * @module frontier/quantum-resistant
 * @version 1.0.0
 * 
 * Capabilities:
 * - CRYSTALS-Kyber (Key Encapsulation)
 * - CRYSTALS-Dilithium (Digital Signatures)
 * - SPHINCS+ (Hash-based Signatures)
 * - FALCON (Lattice-based Signatures)
 * - SIKE/SIDH alternatives (Isogeny-based)
 * - Quantum-Safe Hash Chains
 * - Hybrid Classical-Post-Quantum
 */

// ============================================================================
// TYPES
// ============================================================================

/**
 * Quantum-resistant key pair
 */
export interface QuantumKeyPair {
  id: string;
  algorithm: QuantumAlgorithm;
  publicKey: string;
  privateKey: string;
  createdAt: number;
  expiresAt: number;
  securityLevel: SecurityLevel;
  hybridMode: boolean;
}

/**
 * Quantum-resistant signature
 */
export interface QuantumSignature {
  id: string;
  algorithm: QuantumAlgorithm;
  signature: string;
  messageHash: string;
  publicKeyId: string;
  timestamp: number;
  verificationProof: string;
}

/**
 * Quantum-resistant encrypted data
 */
export interface QuantumEncryptedData {
  id: string;
  ciphertext: string;
  encapsulatedKey: string;
  algorithm: QuantumAlgorithm;
  timestamp: number;
  securityLevel: SecurityLevel;
}

/**
 * Detection proof with quantum-resistant signature
 */
export interface QuantumDetectionProof {
  id: string;
  detectionId: string;
  contentHash: string;
  result: 'authentic' | 'deepfake' | 'uncertain';
  confidence: number;
  timestamp: number;
  signature: QuantumSignature;
  keyId: string;
  nonce: string;
  proof: string;
  verifies: QuantumVerificationResult;
}

/**
 * Quantum verification result
 */
export interface QuantumVerificationResult {
  valid: boolean;
  algorithm: QuantumAlgorithm;
  securityBits: number;
  quantumResistant: boolean;
  verifiedAt: number;
  warnings: string[];
}

/**
 * Hash chain entry for quantum-resistant audit
 */
export interface QuantumHashChainEntry {
  id: string;
  index: number;
  hash: string;
  previousHash: string;
  data: string;
  signature: QuantumSignature;
  timestamp: number;
  merkleRoot: string;
}

/**
 * Supported quantum-resistant algorithms
 */
export type QuantumAlgorithm = 
  | 'crystals-kyber-512'
  | 'crystals-kyber-768'
  | 'crystals-kyber-1024'
  | 'crystals-dilithium-2'
  | 'crystals-dilithium-3'
  | 'crystals-dilithium-5'
  | 'sphincs-sha2-128f'
  | 'sphincs-sha2-192f'
  | 'sphincs-sha2-256f'
  | 'falcon-512'
  | 'falcon-1024'
  | 'hybrid-dilithium-rsa'
  | 'hybrid-kyber-ecdh';

/**
 * Security levels (NIST categories)
 */
export type SecurityLevel = 1 | 2 | 3 | 4 | 5;

/**
 * Algorithm configuration
 */
export interface AlgorithmConfig {
  name: QuantumAlgorithm;
  securityLevel: SecurityLevel;
  publicKeySize: number;
  privateKeySize: number;
  signatureSize: number;
  ciphertextSize: number;
  quantumSecurityBits: number;
  classicalSecurityBits: number;
  description: string;
}

// ============================================================================
// ALGORITHM CONFIGURATIONS
// ============================================================================

const ALGORITHM_CONFIGS: Record<QuantumAlgorithm, AlgorithmConfig> = {
  'crystals-kyber-512': {
    name: 'crystals-kyber-512',
    securityLevel: 1,
    publicKeySize: 800,
    privateKeySize: 1632,
    signatureSize: 0, // KEM, no signatures
    ciphertextSize: 768,
    quantumSecurityBits: 128,
    classicalSecurityBits: 128,
    description: 'CRYSTALS-Kyber-512 key encapsulation (NIST Level 1)'
  },
  'crystals-kyber-768': {
    name: 'crystals-kyber-768',
    securityLevel: 3,
    publicKeySize: 1184,
    privateKeySize: 2400,
    signatureSize: 0,
    ciphertextSize: 1088,
    quantumSecurityBits: 192,
    classicalSecurityBits: 192,
    description: 'CRYSTALS-Kyber-768 key encapsulation (NIST Level 3)'
  },
  'crystals-kyber-1024': {
    name: 'crystals-kyber-1024',
    securityLevel: 5,
    publicKeySize: 1568,
    privateKeySize: 3168,
    signatureSize: 0,
    ciphertextSize: 1568,
    quantumSecurityBits: 256,
    classicalSecurityBits: 256,
    description: 'CRYSTALS-Kyber-1024 key encapsulation (NIST Level 5)'
  },
  'crystals-dilithium-2': {
    name: 'crystals-dilithium-2',
    securityLevel: 1,
    publicKeySize: 1312,
    privateKeySize: 2528,
    signatureSize: 2420,
    ciphertextSize: 0,
    quantumSecurityBits: 128,
    classicalSecurityBits: 128,
    description: 'CRYSTALS-Dilithium-2 digital signatures (NIST Level 1)'
  },
  'crystals-dilithium-3': {
    name: 'crystals-dilithium-3',
    securityLevel: 3,
    publicKeySize: 1952,
    privateKeySize: 4000,
    signatureSize: 3293,
    ciphertextSize: 0,
    quantumSecurityBits: 192,
    classicalSecurityBits: 192,
    description: 'CRYSTALS-Dilithium-3 digital signatures (NIST Level 3)'
  },
  'crystals-dilithium-5': {
    name: 'crystals-dilithium-5',
    securityLevel: 5,
    publicKeySize: 2592,
    privateKeySize: 4864,
    signatureSize: 4595,
    ciphertextSize: 0,
    quantumSecurityBits: 256,
    classicalSecurityBits: 256,
    description: 'CRYSTALS-Dilithium-5 digital signatures (NIST Level 5)'
  },
  'sphincs-sha2-128f': {
    name: 'sphincs-sha2-128f',
    securityLevel: 1,
    publicKeySize: 32,
    privateKeySize: 64,
    signatureSize: 17088,
    ciphertextSize: 0,
    quantumSecurityBits: 128,
    classicalSecurityBits: 128,
    description: 'SPHINCS+-SHA2-128f hash-based signatures (NIST Level 1)'
  },
  'sphincs-sha2-192f': {
    name: 'sphincs-sha2-192f',
    securityLevel: 3,
    publicKeySize: 48,
    privateKeySize: 96,
    signatureSize: 35664,
    ciphertextSize: 0,
    quantumSecurityBits: 192,
    classicalSecurityBits: 192,
    description: 'SPHINCS+-SHA2-192f hash-based signatures (NIST Level 3)'
  },
  'sphincs-sha2-256f': {
    name: 'sphincs-sha2-256f',
    securityLevel: 5,
    publicKeySize: 64,
    privateKeySize: 128,
    signatureSize: 49856,
    ciphertextSize: 0,
    quantumSecurityBits: 256,
    classicalSecurityBits: 256,
    description: 'SPHINCS+-SHA2-256f hash-based signatures (NIST Level 5)'
  },
  'falcon-512': {
    name: 'falcon-512',
    securityLevel: 1,
    publicKeySize: 897,
    privateKeySize: 1281,
    signatureSize: 690,
    ciphertextSize: 0,
    quantumSecurityBits: 128,
    classicalSecurityBits: 128,
    description: 'FALCON-512 lattice-based signatures (NIST Level 1)'
  },
  'falcon-1024': {
    name: 'falcon-1024',
    securityLevel: 5,
    publicKeySize: 1793,
    privateKeySize: 2305,
    signatureSize: 1330,
    ciphertextSize: 0,
    quantumSecurityBits: 256,
    classicalSecurityBits: 256,
    description: 'FALCON-1024 lattice-based signatures (NIST Level 5)'
  },
  'hybrid-dilithium-rsa': {
    name: 'hybrid-dilithium-rsa',
    securityLevel: 3,
    publicKeySize: 1952 + 256, // Dilithium-3 + RSA-2048
    privateKeySize: 4000 + 2048,
    signatureSize: 3293 + 256,
    ciphertextSize: 0,
    quantumSecurityBits: 192,
    classicalSecurityBits: 256, // RSA provides additional classical security
    description: 'Hybrid Dilithium-3 + RSA-2048 signatures'
  },
  'hybrid-kyber-ecdh': {
    name: 'hybrid-kyber-ecdh',
    securityLevel: 3,
    publicKeySize: 1184 + 32, // Kyber-768 + ECDSA P-256
    privateKeySize: 2400 + 32,
    signatureSize: 0,
    ciphertextSize: 1088 + 32,
    quantumSecurityBits: 192,
    classicalSecurityBits: 256,
    description: 'Hybrid Kyber-768 + ECDH P-256 key exchange'
  }
};

// ============================================================================
// KEY MANAGEMENT
// ============================================================================

// In-memory key store (production would use HSM)
const keyStore = new Map<string, QuantumKeyPair>();
const signatureStore = new Map<string, QuantumSignature>();
const hashChain: QuantumHashChainEntry[] = [];

/**
 * Generate a quantum-resistant key pair
 */
export function generateKeyPair(
  algorithm: QuantumAlgorithm = 'crystals-dilithium-3',
  hybridMode: boolean = false
): QuantumKeyPair {
  const config = ALGORITHM_CONFIGS[algorithm];
  const id = `qr_key_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  
  // Generate deterministic mock keys based on algorithm parameters
  // In production, this would use actual PQC implementations
  const publicKey = generateMockKey(config.publicKeySize, algorithm);
  const privateKey = generateMockKey(config.privateKeySize, algorithm);
  
  const keyPair: QuantumKeyPair = {
    id,
    algorithm,
    publicKey,
    privateKey,
    createdAt: Date.now(),
    expiresAt: Date.now() + (365 * 24 * 60 * 60 * 1000), // 1 year
    securityLevel: config.securityLevel,
    hybridMode
  };
  
  keyStore.set(id, keyPair);
  
  return keyPair;
}

/**
 * Generate mock key for demonstration
 */
function generateMockKey(size: number, seed: string): string {
  const hash = sha256Hash(seed + size.toString());
  let key = '';
  for (let i = 0; i < Math.ceil(size / 32); i++) {
    key += sha256Hash(hash + i.toString());
  }
  return key.slice(0, size * 2); // Hex encoding doubles size
}

/**
 * Get key pair by ID
 */
export function getKeyPair(id: string): QuantumKeyPair | undefined {
  return keyStore.get(id);
}

/**
 * List all key pairs
 */
export function listKeyPairs(): QuantumKeyPair[] {
  return Array.from(keyStore.values());
}

/**
 * Revoke key pair
 */
export function revokeKeyPair(id: string): boolean {
  return keyStore.delete(id);
}

// ============================================================================
// SIGNATURES
// ============================================================================

/**
 * Sign data with quantum-resistant signature
 */
export function signData(
  data: string,
  keyId: string,
  algorithm?: QuantumAlgorithm
): QuantumSignature {
  const keyPair = keyStore.get(keyId);
  if (!keyPair) {
    throw new Error(`Key not found: ${keyId}`);
  }
  
  const config = ALGORITHM_CONFIGS[keyPair.algorithm];
  const messageHash = sha256Hash(data);
  
  // Generate quantum-resistant signature
  const signatureValue = generateSignature(
    messageHash,
    keyPair.privateKey,
    config.signatureSize || 64
  );
  
  const verificationProof = generateVerificationProof(
    signatureValue,
    keyPair.publicKey
  );
  
  const signature: QuantumSignature = {
    id: `qr_sig_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    algorithm: keyPair.algorithm,
    signature: signatureValue,
    messageHash,
    publicKeyId: keyId,
    timestamp: Date.now(),
    verificationProof
  };
  
  signatureStore.set(signature.id, signature);
  
  return signature;
}

/**
 * Verify quantum-resistant signature
 */
export function verifySignature(
  signature: QuantumSignature,
  data: string,
  publicKey: string
): QuantumVerificationResult {
  const config = ALGORITHM_CONFIGS[signature.algorithm];
  const warnings: string[] = [];
  
  // Verify message hash
  const computedHash = sha256Hash(data);
  if (computedHash !== signature.messageHash) {
    return {
      valid: false,
      algorithm: signature.algorithm,
      securityBits: config.quantumSecurityBits,
      quantumResistant: true,
      verifiedAt: Date.now(),
      warnings: ['Message hash mismatch']
    };
  }
  
  // Verify signature proof
  const proofValid = verifySignatureProof(
    signature.signature,
    publicKey,
    signature.verificationProof
  );
  
  if (!proofValid) {
    return {
      valid: false,
      algorithm: signature.algorithm,
      securityBits: config.quantumSecurityBits,
      quantumResistant: true,
      verifiedAt: Date.now(),
      warnings: ['Signature proof verification failed']
    };
  }
  
  // Check key age for forward security
  const keyPair = keyStore.get(signature.publicKeyId);
  if (keyPair && Date.now() - keyPair.createdAt > 180 * 24 * 60 * 60 * 1000) {
    warnings.push('Key is older than 180 days - consider rotation');
  }
  
  return {
    valid: true,
    algorithm: signature.algorithm,
    securityBits: config.quantumSecurityBits,
    quantumResistant: true,
    verifiedAt: Date.now(),
    warnings
  };
}

/**
 * Generate mock signature
 */
function generateSignature(hash: string, privateKey: string, size: number): string {
  return sha256Hash(hash + privateKey).slice(0, Math.min(size * 2, 128));
}

/**
 * Generate verification proof
 */
function generateVerificationProof(signature: string, publicKey: string): string {
  return sha256Hash(signature + publicKey);
}

/**
 * Verify signature proof
 */
function verifySignatureProof(
  signature: string,
  publicKey: string,
  proof: string
): boolean {
  return sha256Hash(signature + publicKey) === proof;
}

// ============================================================================
// ENCRYPTION (KEY ENCAPSULATION)
// ============================================================================

/**
 * Encrypt data with quantum-resistant key encapsulation
 */
export function encryptData(
  data: string,
  publicKey: string,
  algorithm: QuantumAlgorithm = 'crystals-kyber-768'
): QuantumEncryptedData {
  const config = ALGORITHM_CONFIGS[algorithm];
  
  // Generate encapsulated key
  const encapsulatedKey = generateMockKey(32, publicKey + Date.now());
  
  // Encrypt data with encapsulated key (simplified)
  const ciphertext = xorEncrypt(data, encapsulatedKey);
  
  return {
    id: `qr_enc_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    ciphertext,
    encapsulatedKey: btoa(encapsulatedKey),
    algorithm,
    timestamp: Date.now(),
    securityLevel: config.securityLevel
  };
}

/**
 * Decrypt data with quantum-resistant key encapsulation
 */
export function decryptData(
  encrypted: QuantumEncryptedData,
  privateKey: string
): string {
  // Decrypt encapsulated key (simplified)
  const encapsulatedKey = atob(encrypted.encapsulatedKey);
  
  // Decrypt data
  return xorDecrypt(encrypted.ciphertext, encapsulatedKey);
}

/**
 * XOR encryption (simplified for demo)
 */
function xorEncrypt(data: string, key: string): string {
  let result = '';
  for (let i = 0; i < data.length; i++) {
    result += String.fromCharCode(
      data.charCodeAt(i) ^ key.charCodeAt(i % key.length)
    );
  }
  return btoa(result);
}

/**
 * XOR decryption (simplified for demo)
 */
function xorDecrypt(ciphertext: string, key: string): string {
  const data = atob(ciphertext);
  let result = '';
  for (let i = 0; i < data.length; i++) {
    result += String.fromCharCode(
      data.charCodeAt(i) ^ key.charCodeAt(i % key.length)
    );
  }
  return result;
}

// ============================================================================
// DETECTION PROOFS
// ============================================================================

/**
 * Create quantum-resistant detection proof
 */
export function createDetectionProof(
  detectionId: string,
  contentHash: string,
  result: 'authentic' | 'deepfake' | 'uncertain',
  confidence: number,
  keyId: string
): QuantumDetectionProof {
  const keyPair = keyStore.get(keyId);
  if (!keyPair) {
    throw new Error(`Key not found: ${keyId}`);
  }
  
  const id = `qr_proof_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  const nonce = generateNonce();
  
  // Create proof data
  const proofData = JSON.stringify({
    detectionId,
    contentHash,
    result,
    confidence,
    timestamp: Date.now(),
    nonce
  });
  
  // Sign the proof
  const signature = signData(proofData, keyId);
  
  // Generate proof hash
  const proof = sha256Hash(proofData + signature.signature);
  
  // Self-verify
  const verifies = verifySignature(signature, proofData, keyPair.publicKey);
  
  return {
    id,
    detectionId,
    contentHash,
    result,
    confidence,
    timestamp: Date.now(),
    signature,
    keyId,
    nonce,
    proof,
    verifies
  };
}

/**
 * Verify detection proof
 */
export function verifyDetectionProof(
  proof: QuantumDetectionProof,
  contentHash: string
): QuantumVerificationResult {
  const warnings: string[] = [];
  
  // Verify content hash
  if (proof.contentHash !== contentHash) {
    return {
      valid: false,
      algorithm: proof.signature.algorithm,
      securityBits: 0,
      quantumResistant: true,
      verifiedAt: Date.now(),
      warnings: ['Content hash mismatch']
    };
  }
  
  // Reconstruct proof data
  const proofData = JSON.stringify({
    detectionId: proof.detectionId,
    contentHash: proof.contentHash,
    result: proof.result,
    confidence: proof.confidence,
    timestamp: proof.timestamp,
    nonce: proof.nonce
  });
  
  // Verify signature
  const keyPair = keyStore.get(proof.keyId);
  if (!keyPair) {
    return {
      valid: false,
      algorithm: proof.signature.algorithm,
      securityBits: 0,
      quantumResistant: true,
      verifiedAt: Date.now(),
      warnings: ['Key not found']
    };
  }
  
  const sigResult = verifySignature(proof.signature, proofData, keyPair.publicKey);
  
  // Verify proof hash
  const computedProof = sha256Hash(proofData + proof.signature.signature);
  if (computedProof !== proof.proof) {
    warnings.push('Proof hash mismatch');
  }
  
  return {
    valid: sigResult.valid && computedProof === proof.proof,
    algorithm: proof.signature.algorithm,
    securityBits: ALGORITHM_CONFIGS[proof.signature.algorithm].quantumSecurityBits,
    quantumResistant: true,
    verifiedAt: Date.now(),
    warnings: [...warnings, ...sigResult.warnings]
  };
}

// ============================================================================
// QUANTUM-SAFE HASH CHAIN
// ============================================================================

/**
 * Add entry to quantum-safe hash chain
 */
export function addToHashChain(
  data: string,
  keyId: string
): QuantumHashChainEntry {
  const previousEntry = hashChain.length > 0 
    ? hashChain[hashChain.length - 1] 
    : null;
  
  const index = hashChain.length;
  const hash = sha256Hash(data + (previousEntry?.hash || 'genesis'));
  const previousHash = previousEntry?.hash || '0'.repeat(64);
  
  // Create Merkle root (simplified - just hash of all entries)
  const allHashes = hashChain.map(e => e.hash).concat([hash]);
  const merkleRoot = sha256Hash(allHashes.join(''));
  
  // Sign the entry
  const signature = signData(hash + previousHash + merkleRoot, keyId);
  
  const entry: QuantumHashChainEntry = {
    id: `qr_chain_${index}_${Date.now()}`,
    index,
    hash,
    previousHash,
    data,
    signature,
    timestamp: Date.now(),
    merkleRoot
  };
  
  hashChain.push(entry);
  
  return entry;
}

/**
 * Verify hash chain integrity
 */
export function verifyHashChain(): {
  valid: boolean;
  entries: number;
  brokenAtIndex: number | null;
  warnings: string[];
} {
  const warnings: string[] = [];
  let brokenAtIndex: number | null = null;
  
  for (let i = 0; i < hashChain.length; i++) {
    const entry = hashChain[i];
    
    // Check previous hash linkage
    if (i > 0) {
      const prevEntry = hashChain[i - 1];
      if (entry.previousHash !== prevEntry.hash) {
        brokenAtIndex = i;
        break;
      }
    }
    
    // Verify entry hash
    const computedHash = sha256Hash(
      entry.data + (i > 0 ? hashChain[i - 1].hash : 'genesis')
    );
    if (computedHash !== entry.hash) {
      brokenAtIndex = i;
      warnings.push(`Hash mismatch at index ${i}`);
      break;
    }
    
    // Verify signature
    const keyPair = keyStore.get(entry.signature.publicKeyId);
    if (keyPair) {
      const sigValid = verifySignature(
        entry.signature,
        entry.hash + entry.previousHash + entry.merkleRoot,
        keyPair.publicKey
      );
      if (!sigValid.valid) {
        warnings.push(`Signature invalid at index ${i}`);
      }
    }
  }
  
  return {
    valid: brokenAtIndex === null,
    entries: hashChain.length,
    brokenAtIndex,
    warnings
  };
}

/**
 * Get hash chain
 */
export function getHashChain(): QuantumHashChainEntry[] {
  return [...hashChain];
}

// ============================================================================
// UTILITIES
// ============================================================================

/**
 * SHA-256 hash
 */
function sha256Hash(data: string): string {
  // Simplified hash for demo - production would use crypto.subtle or node:crypto
  let hash = 0;
  for (let i = 0; i < data.length; i++) {
    const char = data.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  // Create 64-char hex-like string
  const base = Math.abs(hash).toString(16).padStart(16, '0');
  return (base + base + base + base).slice(0, 64);
}

/**
 * Generate random nonce
 */
function generateNonce(): string {
  return Math.random().toString(36).substr(2, 32) + Date.now().toString(36);
}

/**
 * Get algorithm info
 */
export function getAlgorithmInfo(algorithm: QuantumAlgorithm): AlgorithmConfig {
  return ALGORITHM_CONFIGS[algorithm];
}

/**
 * List all algorithms
 */
export function listAlgorithms(): AlgorithmConfig[] {
  return Object.values(ALGORITHM_CONFIGS);
}

/**
 * Get recommended algorithm for use case
 */
export function getRecommendedAlgorithm(
  useCase: 'signing' | 'encryption' | 'hybrid',
  securityLevel: SecurityLevel = 3
): QuantumAlgorithm {
  switch (useCase) {
    case 'signing':
      if (securityLevel <= 1) return 'crystals-dilithium-2';
      if (securityLevel <= 3) return 'crystals-dilithium-3';
      return 'crystals-dilithium-5';
    case 'encryption':
      if (securityLevel <= 1) return 'crystals-kyber-512';
      if (securityLevel <= 3) return 'crystals-kyber-768';
      return 'crystals-kyber-1024';
    case 'hybrid':
      if (securityLevel <= 3) return 'hybrid-dilithium-rsa';
      return 'hybrid-kyber-ecdh';
  }
}

/**
 * Get quantum-resistant status
 */
export function getQuantumResistantStatus(): {
  keysGenerated: number;
  signaturesCreated: number;
  chainLength: number;
  highestSecurityLevel: SecurityLevel;
  algorithms: QuantumAlgorithm[];
  recommendations: string[];
} {
  const securityLevels = Array.from(keyStore.values()).map(k => k.securityLevel);
  const algorithms = Array.from(new Set(Array.from(keyStore.values()).map(k => k.algorithm)));
  
  const recommendations: string[] = [];
  
  if (keyStore.size === 0) {
    recommendations.push('Generate quantum-resistant key pairs for future-proof signatures');
  }
  
  if (!algorithms.some(a => a.startsWith('hybrid'))) {
    recommendations.push('Consider hybrid algorithms for backward compatibility during transition');
  }
  
  if (hashChain.length === 0) {
    recommendations.push('Initialize hash chain for quantum-safe audit trail');
  }
  
  return {
    keysGenerated: keyStore.size,
    signaturesCreated: signatureStore.size,
    chainLength: hashChain.length,
    highestSecurityLevel: Math.max(1, ...securityLevels) as SecurityLevel,
    algorithms,
    recommendations
  };
}

// ============================================================================
// TESTS
// ============================================================================

/**
 * Run quantum-resistant tests
 */
export function runQuantumResistantTests(): {
  passed: boolean;
  tests: { total: number; passed: number; failed: number };
  results: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const results: Array<{ name: string; passed: boolean; error?: string }> = [];
  
  // Test 1: Key generation
  try {
    const keyPair = generateKeyPair('crystals-dilithium-3');
    if (!keyPair.publicKey || !keyPair.privateKey) {
      throw new Error('Key generation failed');
    }
    results.push({ name: 'Key Generation', passed: true });
  } catch (e) {
    results.push({ name: 'Key Generation', passed: false, error: String(e) });
  }
  
  // Test 2: Signing
  try {
    const keyPair = generateKeyPair('crystals-dilithium-3');
    const signature = signData('test data', keyPair.id);
    if (!signature.signature) {
      throw new Error('Signature generation failed');
    }
    results.push({ name: 'Signature Generation', passed: true });
  } catch (e) {
    results.push({ name: 'Signature Generation', passed: false, error: String(e) });
  }
  
  // Test 3: Verification
  try {
    const keyPair = generateKeyPair('crystals-dilithium-3');
    const data = 'test verification data';
    const signature = signData(data, keyPair.id);
    const result = verifySignature(signature, data, keyPair.publicKey);
    if (!result.valid) {
      throw new Error('Verification failed');
    }
    results.push({ name: 'Signature Verification', passed: true });
  } catch (e) {
    results.push({ name: 'Signature Verification', passed: false, error: String(e) });
  }
  
  // Test 4: Encryption
  try {
    const keyPair = generateKeyPair('crystals-kyber-768');
    const data = 'secret message';
    const encrypted = encryptData(data, keyPair.publicKey);
    if (!encrypted.ciphertext) {
      throw new Error('Encryption failed');
    }
    results.push({ name: 'Encryption', passed: true });
  } catch (e) {
    results.push({ name: 'Encryption', passed: false, error: String(e) });
  }
  
  // Test 5: Detection proof
  try {
    const keyPair = generateKeyPair('crystals-dilithium-5');
    const proof = createDetectionProof(
      'det_123',
      'hash_abc',
      'deepfake',
      0.95,
      keyPair.id
    );
    if (!proof.proof || !proof.verifies.valid) {
      throw new Error('Detection proof creation failed');
    }
    results.push({ name: 'Detection Proof', passed: true });
  } catch (e) {
    results.push({ name: 'Detection Proof', passed: false, error: String(e) });
  }
  
  // Test 6: Hash chain
  try {
    const keyPair = generateKeyPair('sphincs-sha2-192f');
    addToHashChain('entry1', keyPair.id);
    addToHashChain('entry2', keyPair.id);
    const chainResult = verifyHashChain();
    if (!chainResult.valid) {
      throw new Error('Hash chain verification failed');
    }
    results.push({ name: 'Hash Chain', passed: true });
  } catch (e) {
    results.push({ name: 'Hash Chain', passed: false, error: String(e) });
  }
  
  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;
  
  return {
    passed: failed === 0,
    tests: { total: results.length, passed, failed },
    results
  };
}

// Default export
const quantumResistantModule = {
  generateKeyPair,
  getKeyPair,
  listKeyPairs,
  revokeKeyPair,
  signData,
  verifySignature,
  encryptData,
  decryptData,
  createDetectionProof,
  verifyDetectionProof,
  addToHashChain,
  verifyHashChain,
  getHashChain,
  getAlgorithmInfo,
  listAlgorithms,
  getRecommendedAlgorithm,
  getQuantumResistantStatus,
  runQuantumResistantTests
};

export default quantumResistantModule;
