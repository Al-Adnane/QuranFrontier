/**
 * Kasbah Predictive Threat Intelligence
 * Real forecasting algorithms, pattern detection, and threat modeling
 * 
 * @module predictive-intelligence
 * @version 2.0.0
 */

// ============================================
// TIME SERIES ANALYSIS
// ============================================

export interface TimeSeriesPoint {
  timestamp: Date;
  value: number;
  features?: Record<string, number>;
}

export interface ForecastResult {
  predictions: Array<{ timestamp: Date; value: number; confidence: number }>;
  trend: 'increasing' | 'decreasing' | 'stable';
  seasonality: { period: number; strength: number } | null;
  accuracy: number;
}

export class TimeSeriesAnalyzer {
  /**
   * Decompose time series into trend, seasonal, and residual
   */
  decompose(
    data: TimeSeriesPoint[],
    period: number = 7
  ): {
    trend: number[];
    seasonal: number[];
    residual: number[];
  } {
    if (data.length < period * 2) {
      return {
        trend: data.map(d => d.value),
        seasonal: Array(data.length).fill(0),
        residual: Array(data.length).fill(0)
      };
    }

    // Compute trend using moving average
    const trend: number[] = [];
    const halfPeriod = Math.floor(period / 2);
    
    for (let i = 0; i < data.length; i++) {
      let sum = 0;
      let count = 0;
      
      for (let j = Math.max(0, i - halfPeriod); j <= Math.min(data.length - 1, i + halfPeriod); j++) {
        sum += data[j].value;
        count++;
      }
      
      trend.push(sum / count);
    }

    // Compute seasonal component
    const seasonal: number[] = Array(data.length).fill(0);
    const seasonalGroups: number[][] = Array(period).fill(null).map(() => []);
    
    // Detrend first
    for (let i = 0; i < data.length; i++) {
      const detrended = data[i].value - trend[i];
      seasonalGroups[i % period].push(detrended);
    }
    
    // Average seasonal values
    const seasonalAvg = seasonalGroups.map(g => 
      g.length > 0 ? g.reduce((a, b) => a + b, 0) / g.length : 0
    );
    
    // Normalize seasonal
    const seasonalMean = seasonalAvg.reduce((a, b) => a + b, 0) / seasonalAvg.length;
    const normalizedSeasonal = seasonalAvg.map(s => s - seasonalMean);
    
    // Apply seasonal
    for (let i = 0; i < data.length; i++) {
      seasonal[i] = normalizedSeasonal[i % period];
    }

    // Compute residual
    const residual = data.map((d, i) => d.value - trend[i] - seasonal[i]);

    return { trend, seasonal, residual };
  }

  /**
   * Detect seasonality using autocorrelation
   */
  detectSeasonality(data: TimeSeriesPoint[]): { period: number; strength: number } | null {
    if (data.length < 14) return null;

    const values = data.map(d => d.value);
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    
    // Compute autocorrelation
    const maxLag = Math.min(data.length / 2, 365);
    let maxCorr = 0;
    let bestPeriod = 0;
    
    for (let lag = 1; lag < maxLag; lag++) {
      let correlation = 0;
      let n = 0;
      
      for (let i = 0; i < values.length - lag; i++) {
        correlation += (values[i] - mean) * (values[i + lag] - mean);
        n++;
      }
      
      if (n > 0) {
        correlation /= n;
        
        // Normalize
        let variance = 0;
        for (let i = 0; i < values.length; i++) {
          variance += Math.pow(values[i] - mean, 2);
        }
        correlation /= variance / values.length;
        
        if (correlation > maxCorr && correlation > 0.3) {
          maxCorr = correlation;
          bestPeriod = lag;
        }
      }
    }

    return bestPeriod > 0 ? { period: bestPeriod, strength: maxCorr } : null;
  }

  /**
   * ARIMA-style forecasting
   */
  forecast(
    data: TimeSeriesPoint[],
    horizon: number = 7,
    order: { p: number; d: number; q: number } = { p: 2, d: 1, q: 1 }
  ): ForecastResult {
    if (data.length < 10) {
      // Not enough data, return simple forecast
      const lastValue = data[data.length - 1].value;
      return {
        predictions: Array(horizon).fill(null).map((_, i) => ({
          timestamp: new Date(Date.now() + i * 24 * 60 * 60 * 1000),
          value: lastValue,
          confidence: 0.5
        })),
        trend: 'stable',
        seasonality: null,
        accuracy: 0.5
      };
    }

    // Differencing (d parameter)
    let diffed = data.map(d => d.value);
    for (let i = 0; i < order.d; i++) {
      const newDiffed: number[] = [];
      for (let j = 1; j < diffed.length; j++) {
        newDiffed.push(diffed[j] - diffed[j - 1]);
      }
      diffed = newDiffed;
    }

    // Fit AR model (p parameter)
    const coefficients = this.fitAR(diffed, order.p);
    
    // Generate predictions
    const predictions: Array<{ timestamp: Date; value: number; confidence: number }> = [];
    let lastValues = diffed.slice(-order.p);
    
    const lastTimestamp = data[data.length - 1].timestamp;
    
    for (let i = 0; i < horizon; i++) {
      // AR prediction
      let prediction = 0;
      for (let j = 0; j < Math.min(order.p, lastValues.length); j++) {
        prediction += coefficients[j] * lastValues[lastValues.length - 1 - j];
      }
      
      // Add back trend (inverse differencing)
      if (order.d > 0) {
        prediction += data[data.length - 1].value;
      }
      
      const timestamp = new Date(lastTimestamp.getTime() + (i + 1) * 24 * 60 * 60 * 1000);
      
      predictions.push({
        timestamp,
        value: prediction,
        confidence: Math.max(0.3, 0.9 - i * 0.05) // Decreasing confidence over time
      });
      
      lastValues.push(prediction);
    }

    // Determine trend
    const trendValues = predictions.map(p => p.value);
    const firstAvg = trendValues.slice(0, Math.floor(horizon / 3)).reduce((a, b) => a + b, 0) / (horizon / 3);
    const lastAvg = trendValues.slice(-Math.floor(horizon / 3)).reduce((a, b) => a + b, 0) / (horizon / 3);
    
    let trend: 'increasing' | 'decreasing' | 'stable';
    if (lastAvg > firstAvg * 1.1) {
      trend = 'increasing';
    } else if (lastAvg < firstAvg * 0.9) {
      trend = 'decreasing';
    } else {
      trend = 'stable';
    }

    // Detect seasonality
    const seasonality = this.detectSeasonality(data);

    // Estimate accuracy (using backtesting)
    const accuracy = this.backtestAccuracy(data, horizon);

    return {
      predictions,
      trend,
      seasonality,
      accuracy
    };
  }

  /**
   * Fit AR model coefficients using Yule-Walker equations
   */
  private fitAR(data: number[], p: number): number[] {
    if (data.length < p + 1) {
      return Array(p).fill(0).map(() => Math.random() * 0.1);
    }

    // Compute autocorrelation
    const mean = data.reduce((a, b) => a + b, 0) / data.length;
    const variance = data.reduce((sum, x) => sum + Math.pow(x - mean, 2), 0) / data.length;
    
    const autocorr: number[] = [];
    for (let lag = 0; lag <= p; lag++) {
      let corr = 0;
      for (let i = 0; i < data.length - lag; i++) {
        corr += (data[i] - mean) * (data[i + lag] - mean);
      }
      autocorr.push(corr / (data.length * variance));
    }

    // Solve Yule-Walker equations (simplified using Levinson-Durbin)
    const coefficients = this.levinsonDurbin(autocorr, p);
    
    return coefficients;
  }

  /**
   * Levinson-Durbin recursion
   */
  private levinsonDurbin(autocorr: number[], p: number): number[] {
    const a: number[][] = Array(p + 1).fill(null).map(() => Array(p + 1).fill(0));
    const e: number[] = Array(p + 1).fill(0);
    
    a[0][0] = 1;
    e[0] = autocorr[0];
    
    for (let k = 1; k <= p; k++) {
      let lambda = 0;
      for (let j = 0; j < k; j++) {
        lambda += a[k - 1][j] * autocorr[k - j];
      }
      lambda = -lambda / e[k - 1];
      
      for (let n = 0; n <= k; n++) {
        a[k][n] = a[k - 1][n] + lambda * a[k - 1][k - n];
      }
      
      e[k] = (1 - lambda * lambda) * e[k - 1];
    }
    
    // Return AR coefficients
    const coeffs: number[] = [];
    for (let i = 1; i <= p; i++) {
      coeffs.push(a[p][i]);
    }
    
    return coeffs;
  }

  /**
   * Backtest accuracy
   */
  private backtestAccuracy(data: TimeSeriesPoint[], horizon: number): number {
    if (data.length < horizon * 2) return 0.7;

    // Use last portion for testing
    const trainSize = data.length - horizon;
    const trainData = data.slice(0, trainSize);
    const testData = data.slice(trainSize);
    
    // Forecast and compare
    const forecast = this.forecast(trainData, horizon, { p: 2, d: 1, q: 1 });
    
    let totalError = 0;
    for (let i = 0; i < Math.min(horizon, testData.length); i++) {
      const error = Math.abs(forecast.predictions[i].value - testData[i].value);
      const scale = Math.abs(testData[i].value) || 1;
      totalError += error / scale;
    }
    
    const avgError = totalError / Math.min(horizon, testData.length);
    
    return Math.max(0, 1 - avgError);
  }
}

// ============================================
// ANOMALY DETECTOR
// ============================================

export interface AnomalyDetector {
  detect(data: TimeSeriesPoint[]): AnomalyResult[];
}

export interface AnomalyResult {
  index: number;
  timestamp: Date;
  value: number;
  score: number;
  isAnomaly: boolean;
  type: 'point' | 'contextual' | 'collective';
}

export class StatisticalAnomalyDetector implements AnomalyDetector {
  private threshold: number;

  constructor(threshold: number = 3) {
    this.threshold = threshold;
  }

  detect(data: TimeSeriesPoint[]): AnomalyResult[] {
    const values = data.map(d => d.value);
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    const std = Math.sqrt(
      values.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / values.length
    );

    const results: AnomalyResult[] = [];

    for (let i = 0; i < data.length; i++) {
      const zScore = std > 0 ? Math.abs(values[i] - mean) / std : 0;
      
      results.push({
        index: i,
        timestamp: data[i].timestamp,
        value: values[i],
        score: zScore,
        isAnomaly: zScore > this.threshold,
        type: 'point'
      });
    }

    return results;
  }
}

export class IsolationForest implements AnomalyDetector {
  private numTrees: number;
  private subSamplingSize: number;

  constructor(numTrees: number = 100, subSamplingSize: number = 256) {
    this.numTrees = numTrees;
    this.subSamplingSize = subSamplingSize;
  }

  detect(data: TimeSeriesPoint[]): AnomalyResult[] {
    const values = data.map(d => d.value);
    const scores = this.computeAnomalyScores(values);
    
    return data.map((d, i) => ({
      index: i,
      timestamp: d.timestamp,
      value: d.value,
      score: scores[i],
      isAnomaly: scores[i] > 0.5,
      type: 'point' as const
    }));
  }

  private computeAnomalyScores(values: number[]): number[] {
    // Simplified isolation forest scoring
    const n = values.length;
    const scores: number[] = [];
    
    // Compute path lengths (simplified)
    for (let i = 0; i < n; i++) {
      let pathSum = 0;
      
      for (let t = 0; t < this.numTrees; t++) {
        pathSum += this.computePathLength(values, i);
      }
      
      const avgPath = pathSum / this.numTrees;
      
      // Normalize to anomaly score
      // s(x, n) = 2^(-E(h(x))/c(n))
      const c = this.averagePathLength(this.subSamplingSize);
      scores.push(1 - Math.pow(2, -avgPath / c));
    }
    
    return scores;
  }

  private computePathLength(values: number[], idx: number): number {
    // Simulated path length computation
    const value = values[idx];
    let pathLength = 0;
    let min = Math.min(...values);
    let max = Math.max(...values);
    
    const currentValues = [...values];
    
    while (currentValues.length > 1 && pathLength < 50) {
      // Random split
      const splitValue = min + Math.random() * (max - min);
      
      pathLength++;
      
      if (value < splitValue) {
        max = splitValue;
      } else {
        min = splitValue;
      }
      
      // Limit iterations
      if (Math.random() < 0.1) break;
    }
    
    return pathLength + this.averagePathLength(currentValues.length);
  }

  private averagePathLength(n: number): number {
    if (n <= 1) return 0;
    // H(i) = ln(i) + Euler's constant
    const H = (n: number) => Math.log(n) + 0.5772156649;
    return 2 * H(n - 1) - (2 * (n - 1)) / n;
  }
}

// ============================================
// THREAT PREDICTION
// ============================================

export interface ThreatFactor {
  name: string;
  weight: number;
  value: number;
  trend: number;
  forecast: number;
}

export class ThreatPredictor {
  private timeSeriesAnalyzer: TimeSeriesAnalyzer;
  private anomalyDetectors: AnomalyDetector[];

  constructor() {
    this.timeSeriesAnalyzer = new TimeSeriesAnalyzer();
    this.anomalyDetectors = [
      new StatisticalAnomalyDetector(2.5),
      new IsolationForest(50, 128)
    ];
  }

  /**
   * Predict threat probability
   */
  async predict(
    historicalData: TimeSeriesPoint[],
    factors: ThreatFactor[]
  ): Promise<{
    probability: number;
    confidence: number;
    timeline: Array<{ date: Date; probability: number }>;
    riskFactors: Array<{ factor: string; contribution: number }>;
  }> {
    // Time series forecast
    const forecast = this.timeSeriesAnalyzer.forecast(historicalData, 30);
    
    // Anomaly detection
    const anomalies = this.anomalyDetectors[0].detect(historicalData);
    const recentAnomalies = anomalies.filter(a => a.isAnomaly).slice(-10);
    
    // Factor analysis
    const factorScores = factors.map(f => {
      // Weighted factor score
      const baseScore = f.value * f.weight;
      const trendBonus = f.trend > 0 ? 0.1 : -0.05;
      const forecastBonus = f.forecast > f.value ? 0.1 : 0;
      return {
        factor: f.name,
        score: baseScore + trendBonus + forecastBonus
      };
    });
    
    // Combine signals
    const forecastTrend = forecast.trend === 'increasing' ? 0.2 : 
                         forecast.trend === 'decreasing' ? -0.1 : 0;
    
    const anomalyScore = recentAnomalies.length / 10;
    
    const factorScore = factorScores.reduce((sum, f) => sum + f.score, 0) / factors.length;
    
    // Final probability
    let probability = 0.3; // Base rate
    probability += forecastTrend;
    probability += anomalyScore * 0.3;
    probability += factorScore * 0.3;
    probability = Math.max(0, Math.min(1, probability));
    
    // Timeline
    const timeline = forecast.predictions.map(p => ({
      date: p.timestamp,
      probability: Math.min(1, probability + (p.value > 0.5 ? 0.1 : -0.1))
    }));
    
    // Risk factors
    const riskFactors = factorScores
      .sort((a, b) => b.score - a.score)
      .slice(0, 5)
      .map(f => ({
        factor: f.factor,
        contribution: f.score
      }));

    // Confidence based on data quality
    const confidence = Math.min(0.95, 0.5 + historicalData.length / 200);

    return {
      probability,
      confidence,
      timeline,
      riskFactors
    };
  }

  /**
   * Detect attack patterns
   */
  detectPatterns(
    data: TimeSeriesPoint[]
  ): Array<{ type: string; startIndex: number; endIndex: number; confidence: number }> {
    const patterns: Array<{ type: string; startIndex: number; endIndex: number; confidence: number }> = [];
    
    // Detect spikes
    const anomalies = this.anomalyDetectors[0].detect(data);
    
    for (const anomaly of anomalies.filter(a => a.isAnomaly)) {
      patterns.push({
        type: 'spike',
        startIndex: anomaly.index,
        endIndex: anomaly.index,
        confidence: anomaly.score / 10
      });
    }
    
    // Detect sustained increases
    let increasing = false;
    let startIdx = -1;
    
    for (let i = 1; i < data.length; i++) {
      if (data[i].value > data[i - 1].value * 1.1) {
        if (!increasing) {
          increasing = true;
          startIdx = i - 1;
        }
      } else if (increasing) {
        if (i - startIdx >= 3) {
          patterns.push({
            type: 'sustained_increase',
            startIndex: startIdx,
            endIndex: i - 1,
            confidence: 0.7 + (i - startIdx) * 0.03
          });
        }
        increasing = false;
      }
    }
    
    return patterns;
  }
}

// ============================================
// ACTOR BEHAVIOR MODEL
// ============================================

export interface ActorBehavior {
  id: string;
  techniques: string[];
  frequency: Map<string, number>;
  lastSeen: Date;
  predictNext(): { technique: string; probability: number }[];
}

export class ActorBehaviorModel implements ActorBehavior {
  id: string;
  techniques: string[];
  frequency: Map<string, number>;
  lastSeen: Date;
  
  private sequenceData: string[][] = [];

  constructor(id: string) {
    this.id = id;
    this.techniques = [];
    this.frequency = new Map();
    this.lastSeen = new Date();
  }

  /**
   * Add observed behavior sequence
   */
  addObservation(techniques: string[]): void {
    this.sequenceData.push(techniques);
    
    for (const technique of techniques) {
      this.frequency.set(technique, (this.frequency.get(technique) || 0) + 1);
      if (!this.techniques.includes(technique)) {
        this.techniques.push(technique);
      }
    }
    
    this.lastSeen = new Date();
  }

  /**
   * Predict next techniques using Markov chain
   */
  predictNext(): Array<{ technique: string; probability: number }> {
    // Build transition matrix
    const transitions: Map<string, Map<string, number>> = new Map();
    
    for (const seq of this.sequenceData) {
      for (let i = 0; i < seq.length - 1; i++) {
        const current = seq[i];
        const next = seq[i + 1];
        
        if (!transitions.has(current)) {
          transitions.set(current, new Map());
        }
        
        transitions.get(current)!.set(
          next,
          (transitions.get(current)!.get(next) || 0) + 1
        );
      }
    }
    
    // Get last technique
    const lastSeq = this.sequenceData[this.sequenceData.length - 1];
    const lastTechnique = lastSeq[lastSeq.length - 1];
    
    // Get transitions from last technique
    const transitionsFromLast = transitions.get(lastTechnique);
    
    if (!transitionsFromLast) {
      // No data, return most common techniques
      return Array.from(this.frequency.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5)
        .map(([technique, count]) => ({
          technique,
          probability: count / this.sequenceData.length
        }));
    }
    
    // Normalize to probabilities
    const total = Array.from(transitionsFromLast.values()).reduce((a, b) => a + b, 0);
    
    return Array.from(transitionsFromLast.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([technique, count]) => ({
        technique,
        probability: count / total
      }));
  }
}

// ============================================
// RISK AGGREGATOR
// ============================================

export class RiskAggregator {
  /**
   * Aggregate multiple risk scores
   */
  aggregate(
    scores: Array<{ source: string; score: number; weight: number }>
  ): {
    total: number;
    breakdown: Map<string, number>;
    confidence: number;
  } {
    const breakdown = new Map<string, number>();
    let weightedSum = 0;
    let totalWeight = 0;
    
    for (const { source, score, weight } of scores) {
      weightedSum += score * weight;
      totalWeight += weight;
      breakdown.set(source, score);
    }
    
    const total = totalWeight > 0 ? weightedSum / totalWeight : 0;
    
    // Confidence based on number of sources
    const confidence = Math.min(0.95, 0.5 + scores.length * 0.1);
    
    return { total, breakdown, confidence };
  }

  /**
   * Calculate risk trend
   */
  calculateTrend(
    historical: Array<{ timestamp: Date; risk: number }>
  ): {
    direction: 'increasing' | 'decreasing' | 'stable';
    velocity: number;
    acceleration: number;
  } {
    if (historical.length < 3) {
      return { direction: 'stable', velocity: 0, acceleration: 0 };
    }

    // Calculate first derivative (velocity)
    const velocities: number[] = [];
    for (let i = 1; i < historical.length; i++) {
      const dt = (historical[i].timestamp.getTime() - historical[i - 1].timestamp.getTime()) / (1000 * 60 * 60 * 24); // days
      if (dt > 0) {
        velocities.push((historical[i].risk - historical[i - 1].risk) / dt);
      }
    }
    
    const avgVelocity = velocities.reduce((a, b) => a + b, 0) / velocities.length;
    
    // Calculate second derivative (acceleration)
    const accelerations: number[] = [];
    for (let i = 1; i < velocities.length; i++) {
      accelerations.push(velocities[i] - velocities[i - 1]);
    }
    
    const avgAcceleration = accelerations.length > 0
      ? accelerations.reduce((a, b) => a + b, 0) / accelerations.length
      : 0;

    let direction: 'increasing' | 'decreasing' | 'stable';
    if (avgVelocity > 0.01) {
      direction = 'increasing';
    } else if (avgVelocity < -0.01) {
      direction = 'decreasing';
    } else {
      direction = 'stable';
    }

    return { direction, velocity: avgVelocity, acceleration: avgAcceleration };
  }
}

// ============================================
// EXPORTS
// ============================================

export const predictiveIntelligence = {
  TimeSeriesAnalyzer,
  StatisticalAnomalyDetector,
  IsolationForest,
  ThreatPredictor,
  ActorBehaviorModel,
  RiskAggregator
};

export default predictiveIntelligence;
