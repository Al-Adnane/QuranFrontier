/**
 * Memetic Warfare Defense Module
 *
 * Detects and analyzes coordinated disinformation campaigns, viral manipulation,
 * and organized influence operations. Uses network analysis, temporal patterns,
 * and content fingerprinting to identify memetic attacks.
 *
 * @module memetic-warfare
 * @version 1.0.0
 */

import { createHash, randomBytes } from 'crypto';

// ============================================================================
// MEMETIC WARFARE TYPES
// ============================================================================

/**
 * Campaign type
 */
export type CampaignType =
  | 'disinformation'
  | 'propaganda'
  | 'astroturfing'
  | 'hijacking'
  | 'amplification'
  | 'suppression'
  | 'polarization'
  | 'destabilization';

/**
 * Coordinated campaign
 */
export interface CoordinatedCampaign {
  id: string;
  type: CampaignType;
  name: string;
  status: 'active' | 'dormant' | 'detected' | 'neutralized';
  participants: Participant[];
  content: ContentItem[];
  timeline: CampaignEvent[];
  reach: {
    estimated: number;
    platforms: string[];
    geographic: string[];
  };
  threatLevel: 'low' | 'medium' | 'high' | 'critical';
  detectedAt: number;
  lastActivity: number;
}

/**
 * Campaign participant
 */
export interface Participant {
  id: string;
  type: 'human' | 'bot' | 'troll' | 'amplifier' | 'proxy';
  platform: string;
  accountAge: number;
  activityPattern: 'burst' | 'sustained' | 'intermittent';
  coordinationScore: number; // 0-1
  influence: number; // 0-1
}

/**
 * Content item in campaign
 */
export interface ContentItem {
  id: string;
  hash: string;
  type: 'text' | 'image' | 'video' | 'link' | 'hashtag';
  platform: string;
  firstSeen: number;
  lastSeen: number;
  occurrences: number;
  variants: string[];
  engagement: {
    shares: number;
    likes: number;
    comments: number;
    reach: number;
  };
  deepfakeScore: number;
}

/**
 * Campaign event
 */
export interface CampaignEvent {
  timestamp: number;
  type: 'launch' | 'amplify' | 'pivot' | 'respond' | 'dormant' | 'detected';
  description: string;
  contentIds: string[];
  participantIds: string[];
}

/**
 * Network graph for campaign analysis
 */
export interface NetworkGraph {
  nodes: Array<{
    id: string;
    type: string;
    weight: number;
    cluster: number;
  }>;
  edges: Array<{
    source: string;
    target: string;
    weight: number;
    type: string;
  }>;
  clusters: number;
  modularity: number;
}

/**
 * Temporal pattern
 */
export interface TemporalPattern {
  type: 'burst' | 'wave' | 'cascade' | 'sustained' | 'pulsed';
  periodicity: number; // Hours between peaks
  peakIntensity: number;
  growthRate: number;
  decayRate: number;
  predictability: number;
}

/**
 * Memetic fingerprint
 */
export interface MemeticFingerprint {
  id: string;
  contentHash: string;
  semanticSignature: string;
  styleSignature: string;
  emotionalSignature: string;
  structuralSignature: string;
  propagationPattern: string;
  similarity: number;
}

/**
 * Campaign detection result
 */
export interface CampaignDetectionResult {
  detected: boolean;
  campaign?: CoordinatedCampaign;
  confidence: number;
  indicators: string[];
  relatedCampaigns: string[];
  recommendedActions: string[];
}

// ============================================================================
// CONTENT ANALYSIS
// ============================================================================

/**
 * Generate memetic fingerprint for content
 */
export function generateMemeticFingerprint(content: string): MemeticFingerprint {
  const id = `meme_${Date.now()}_${randomBytes(4).toString('hex')}`;

  // Semantic signature (simplified - in production use embeddings)
  const semanticSignature = createHash('sha256')
    .update(content.toLowerCase().replace(/[^a-z0-9]/g, ''))
    .digest('hex');

  // Style signature (linguistic features)
  const styleFeatures = extractStyleFeatures(content);
  const styleSignature = createHash('sha256')
    .update(JSON.stringify(styleFeatures))
    .digest('hex');

  // Emotional signature
  const emotionalSignature = createHash('sha256')
    .update(extractEmotionalMarkers(content).join(''))
    .digest('hex');

  // Structural signature (formatting, length, etc.)
  const structuralSignature = createHash('sha256')
    .update(JSON.stringify(extractStructuralFeatures(content)))
    .digest('hex');

  // Content hash
  const contentHash = createHash('sha256').update(content).digest('hex');

  return {
    id,
    contentHash,
    semanticSignature,
    styleSignature,
    emotionalSignature,
    structuralSignature,
    propagationPattern: 'unknown',
    similarity: 1.0
  };
}

/**
 * Extract style features from content
 */
function extractStyleFeatures(content: string): Record<string, number> {
  const words = content.split(/\s+/);
  const sentences = content.split(/[.!?]+/).filter(s => s.trim());

  return {
    avgWordLength: words.reduce((sum, w) => sum + w.length, 0) / Math.max(1, words.length),
    avgSentenceLength: sentences.reduce((sum, s) => sum + s.split(/\s+/).length, 0) / Math.max(1, sentences.length),
    exclamationRatio: (content.match(/!/g) || []).length / Math.max(1, content.length),
    questionRatio: (content.match(/\?/g) || []).length / Math.max(1, content.length),
    capitalRatio: (content.match(/[A-Z]/g) || []).length / Math.max(1, content.length),
    punctuationDensity: (content.match(/[^\w\s]/g) || []).length / Math.max(1, content.length),
    hashtagCount: (content.match(/#\w+/g) || []).length,
    mentionCount: (content.match(/@\w+/g) || []).length,
    urlCount: (content.match(/https?:\/\/\S+/g) || []).length
  };
}

/**
 * Extract emotional markers
 */
function extractEmotionalMarkers(content: string): string[] {
  const markers: string[] = [];

  const emotionalWords = [
    'shocking', 'outrageous', 'unbelievable', 'devastating', 'incredible',
    'terrifying', 'amazing', 'disgusting', 'heartbreaking', 'furious',
    'urgent', 'breaking', 'exclusive', 'exposed', 'revealed'
  ];

  const contentLower = content.toLowerCase();
  for (const word of emotionalWords) {
    if (contentLower.includes(word)) {
      markers.push(word);
    }
  }

  return markers;
}

/**
 * Extract structural features
 */
function extractStructuralFeatures(content: string): Record<string, unknown> {
  return {
    length: content.length,
    hasEmojis: /[\u{1F300}-\u{1F9FF}]/u.test(content),
    hasAllCaps: /[A-Z]{3,}/.test(content),
    hasMultiplePunctuation: /[!?]{2,}/.test(content),
    paragraphCount: content.split(/\n\s*\n/).length,
    listItems: (content.match(/^[-*•]\s/gm) || []).length
  };
}

/**
 * Compare two memetic fingerprints
 */
export function compareFingerprints(fp1: MemeticFingerprint, fp2: MemeticFingerprint): number {
  // Calculate similarity across signatures
  const semanticSimilarity = calculateSignatureSimilarity(fp1.semanticSignature, fp2.semanticSignature);
  const styleSimilarity = calculateSignatureSimilarity(fp1.styleSignature, fp2.styleSignature);
  const emotionalSimilarity = calculateSignatureSimilarity(fp1.emotionalSignature, fp2.emotionalSignature);
  const structuralSimilarity = calculateSignatureSimilarity(fp1.structuralSignature, fp2.structuralSignature);

  // Weighted average
  return (
    semanticSimilarity * 0.4 +
    styleSimilarity * 0.2 +
    emotionalSimilarity * 0.25 +
    structuralSimilarity * 0.15
  );
}

/**
 * Calculate signature similarity (simplified)
 */
function calculateSignatureSimilarity(sig1: string, sig2: string): number {
  if (sig1 === sig2) return 1;

  // Hamming distance approximation
  let matches = 0;
  const minLen = Math.min(sig1.length, sig2.length);

  for (let i = 0; i < minLen; i++) {
    if (sig1[i] === sig2[i]) matches++;
  }

  return matches / Math.max(sig1.length, sig2.length);
}

// ============================================================================
// NETWORK ANALYSIS
// ============================================================================

/**
 * Build coordination network
 */
export function buildCoordinationNetwork(
  interactions: Array<{ source: string; target: string; timestamp: number; type: string }>
): NetworkGraph {
  const nodeMap = new Map<string, { id: string; type: string; weight: number; cluster: number }>();
  const edges: NetworkGraph['edges'] = [];

  // Build nodes
  for (const interaction of interactions) {
    if (!nodeMap.has(interaction.source)) {
      nodeMap.set(interaction.source, {
        id: interaction.source,
        type: 'unknown',
        weight: 1,
        cluster: 0
      });
    } else {
      const node = nodeMap.get(interaction.source)!;
      node.weight++;
    }

    if (!nodeMap.has(interaction.target)) {
      nodeMap.set(interaction.target, {
        id: interaction.target,
        type: 'unknown',
        weight: 1,
        cluster: 0
      });
    } else {
      const node = nodeMap.get(interaction.target)!;
      node.weight++;
    }
  }

  // Build edges with weights
  const edgeWeights = new Map<string, number>();
  for (const interaction of interactions) {
    const key = `${interaction.source}->${interaction.target}`;
    edgeWeights.set(key, (edgeWeights.get(key) || 0) + 1);
  }

  for (const [key, weight] of edgeWeights) {
    const [source, target] = key.split('->');
    edges.push({
      source,
      target,
      weight,
      type: 'interaction'
    });
  }

  // Simple clustering (Louvain-like approximation)
  const nodes = Array.from(nodeMap.values());
  let cluster = 0;
  const visited = new Set<string>();

  for (const node of nodes) {
    if (!visited.has(node.id)) {
      // BFS to assign cluster
      const queue = [node.id];
      while (queue.length > 0) {
        const current = queue.shift()!;
        if (visited.has(current)) continue;
        visited.add(current);

        const currentNode = nodeMap.get(current);
        if (currentNode) {
          currentNode.cluster = cluster;
        }

        // Find neighbors
        for (const edge of edges) {
          if (edge.source === current && !visited.has(edge.target)) {
            queue.push(edge.target);
          }
          if (edge.target === current && !visited.has(edge.source)) {
            queue.push(edge.source);
          }
        }
      }
      cluster++;
    }
  }

  return {
    nodes,
    edges,
    clusters: cluster,
    modularity: calculateModularity(nodes, edges)
  };
}

/**
 * Calculate network modularity
 */
function calculateModularity(nodes: NetworkGraph['nodes'], edges: NetworkGraph['edges']): number {
  if (edges.length === 0) return 0;

  const totalWeight = edges.reduce((sum, e) => sum + e.weight, 0);
  let modularity = 0;

  for (const edge of edges) {
    const sourceNode = nodes.find(n => n.id === edge.source);
    const targetNode = nodes.find(n => n.id === edge.target);

    if (sourceNode && targetNode && sourceNode.cluster === targetNode.cluster) {
      modularity += edge.weight / totalWeight;
    }
  }

  return modularity;
}

// ============================================================================
// TEMPORAL ANALYSIS
// ============================================================================

/**
 * Analyze temporal pattern
 */
export function analyzeTemporalPattern(
  events: Array<{ timestamp: number; intensity: number }>
): TemporalPattern {
  if (events.length < 2) {
    return {
      type: 'burst',
      periodicity: 0,
      peakIntensity: 0,
      growthRate: 0,
      decayRate: 0,
      predictability: 0
    };
  }

  // Sort by timestamp
  const sorted = [...events].sort((a, b) => a.timestamp - b.timestamp);

  // Calculate peak intensity
  const peakIntensity = Math.max(...sorted.map(e => e.intensity));

  // Calculate growth rate (from first event to peak)
  const peakIndex = sorted.findIndex(e => e.intensity === peakIntensity);
  const growthRate = peakIndex > 0
    ? (peakIntensity - sorted[0].intensity) / (peakIndex)
    : 0;

  // Calculate decay rate (from peak to last)
  const decayRate = peakIndex < sorted.length - 1
    ? (peakIntensity - sorted[sorted.length - 1].intensity) / (sorted.length - 1 - peakIndex)
    : 0;

  // Detect periodicity
  const periodicity = detectPeriodicity(sorted);

  // Determine pattern type
  const type = determinePatternType(growthRate, decayRate, periodicity);

  // Calculate predictability
  const predictability = calculatePredictability(sorted);

  return {
    type,
    periodicity,
    peakIntensity,
    growthRate,
    decayRate,
    predictability
  };
}

/**
 * Detect periodicity in events
 */
function detectPeriodicity(events: Array<{ timestamp: number; intensity: number }>): number {
  if (events.length < 4) return 0;

  // Calculate intervals between peaks
  const peaks: number[] = [];
  const threshold = Math.max(...events.map(e => e.intensity)) * 0.7;

  for (let i = 1; i < events.length - 1; i++) {
    if (events[i].intensity > threshold &&
        events[i].intensity > events[i - 1].intensity &&
        events[i].intensity > events[i + 1].intensity) {
      peaks.push(events[i].timestamp);
    }
  }

  if (peaks.length < 2) return 0;

  // Calculate average interval
  const intervals: number[] = [];
  for (let i = 1; i < peaks.length; i++) {
    intervals.push(peaks[i] - peaks[i - 1]);
  }

  return intervals.reduce((a, b) => a + b, 0) / intervals.length;
}

/**
 * Determine pattern type
 */
function determinePatternType(
  growthRate: number,
  decayRate: number,
  periodicity: number
): TemporalPattern['type'] {
  if (periodicity > 0) {
    return 'pulsed';
  }

  if (growthRate > 0.5 && decayRate > 0.5) {
    return 'burst';
  }

  if (growthRate > 0.3 && decayRate < 0.1) {
    return 'sustained';
  }

  if (growthRate > 0.3 && decayRate > 0.3) {
    return 'cascade';
  }

  return 'wave';
}

/**
 * Calculate predictability of pattern
 */
function calculatePredictability(events: Array<{ timestamp: number; intensity: number }>): number {
  if (events.length < 3) return 0;

  // Calculate variance in intensity
  const mean = events.reduce((sum, e) => sum + e.intensity, 0) / events.length;
  const variance = events.reduce((sum, e) => sum + Math.pow(e.intensity - mean, 2), 0) / events.length;

  // Normalize variance to predictability (lower variance = higher predictability)
  const maxVariance = Math.pow(Math.max(...events.map(e => e.intensity)), 2);
  return Math.max(0, 1 - (variance / maxVariance));
}

// ============================================================================
// CAMPAIGN DETECTION
// ============================================================================

// In-memory storage
const knownCampaigns = new Map<string, CoordinatedCampaign>();
const contentDatabase = new Map<string, ContentItem>();
const fingerprintDatabase = new Map<string, MemeticFingerprint>();

/**
 * Detect coordinated campaign
 */
export function detectCampaign(
  content: string,
  platform: string,
  metadata?: {
    authorId?: string;
    timestamp?: number;
    engagement?: { shares: number; likes: number; comments: number };
  }
): CampaignDetectionResult {
  const indicators: string[] = [];
  let confidence = 0;

  // Generate fingerprint
  const fingerprint = generateMemeticFingerprint(content);
  fingerprintDatabase.set(fingerprint.id, fingerprint);

  // Check for similar content in known campaigns
  const relatedCampaigns: string[] = [];
  for (const [id, campaign] of knownCampaigns) {
    for (const item of campaign.content) {
      const storedFp = fingerprintDatabase.get(item.hash);
      if (storedFp) {
        const similarity = compareFingerprints(fingerprint, storedFp);
        if (similarity > 0.7) {
          relatedCampaigns.push(id);
          indicators.push(`Similar to content in campaign: ${campaign.name}`);
          confidence += 0.2;
        }
      }
    }
  }

  // Check for coordination indicators
  const styleFeatures = extractStyleFeatures(content);
  const emotionalMarkers = extractEmotionalMarkers(content);

  // High emotional manipulation
  if (emotionalMarkers.length >= 3) {
    indicators.push('High emotional manipulation content');
    confidence += 0.15;
  }

  // Suspicious style features
  if (styleFeatures.exclamationRatio > 0.02 || styleFeatures.capitalRatio > 0.3) {
    indicators.push('Suspicious formatting patterns');
    confidence += 0.1;
  }

  // Check engagement anomalies
  if (metadata?.engagement) {
    const engagementRatio = metadata.engagement.shares / Math.max(1, metadata.engagement.likes);
    if (engagementRatio > 5) {
      indicators.push('Abnormal share-to-like ratio suggesting amplification');
      confidence += 0.2;
    }
  }

  // Determine if campaign detected
  const detected = confidence > 0.3;

  // Generate recommendations
  const recommendedActions: string[] = [];
  if (detected) {
    recommendedActions.push('Monitor content propagation');
    recommendedActions.push('Identify amplification network');
    recommendedActions.push('Cross-reference with known campaigns');
    recommendedActions.push('Consider content labeling');
  }

  return {
    detected,
    campaign: detected ? createCampaignFromDetection(content, platform, fingerprint, indicators) : undefined,
    confidence: Math.min(1, confidence),
    indicators,
    relatedCampaigns: [...new Set(relatedCampaigns)],
    recommendedActions
  };
}

/**
 * Create campaign from detection
 */
function createCampaignFromDetection(
  content: string,
  platform: string,
  fingerprint: MemeticFingerprint,
  indicators: string[]
): CoordinatedCampaign {
  const now = Date.now();
  const id = `campaign_${now}_${randomBytes(4).toString('hex')}`;

  const contentItem: ContentItem = {
    id: `content_${now}_${randomBytes(4).toString('hex')}`,
    hash: fingerprint.contentHash,
    type: 'text',
    platform,
    firstSeen: now,
    lastSeen: now,
    occurrences: 1,
    variants: [],
    engagement: { shares: 0, likes: 0, comments: 0, reach: 0 },
    deepfakeScore: 0
  };

  contentDatabase.set(contentItem.id, contentItem);

  return {
    id,
    type: 'disinformation',
    name: `Campaign ${id.slice(0, 8)}`,
    status: 'detected',
    participants: [],
    content: [contentItem],
    timeline: [{
      timestamp: now,
      type: 'detected',
      description: `Initial detection: ${indicators[0] || 'Coordinated activity detected'}`,
      contentIds: [contentItem.id],
      participantIds: []
    }],
    reach: {
      estimated: 1000,
      platforms: [platform],
      geographic: []
    },
    threatLevel: 'medium',
    detectedAt: now,
    lastActivity: now
  };
}

/**
 * Update campaign with new content
 */
export function updateCampaign(
  campaignId: string,
  content: string,
  platform: string
): CoordinatedCampaign | null {
  const campaign = knownCampaigns.get(campaignId);
  if (!campaign) return null;

  const fingerprint = generateMemeticFingerprint(content);
  const now = Date.now();

  // Add new content
  const contentItem: ContentItem = {
    id: `content_${now}_${randomBytes(4).toString('hex')}`,
    hash: fingerprint.contentHash,
    type: 'text',
    platform,
    firstSeen: now,
    lastSeen: now,
    occurrences: 1,
    variants: [],
    engagement: { shares: 0, likes: 0, comments: 0, reach: 0 },
    deepfakeScore: 0
  };

  campaign.content.push(contentItem);
  campaign.lastActivity = now;

  if (!campaign.reach.platforms.includes(platform)) {
    campaign.reach.platforms.push(platform);
  }

  // Update timeline
  campaign.timeline.push({
    timestamp: now,
    type: 'amplify',
    description: `New content detected on ${platform}`,
    contentIds: [contentItem.id],
    participantIds: []
  });

  return campaign;
}

/**
 * Get all known campaigns
 */
export function getKnownCampaigns(): CoordinatedCampaign[] {
  return Array.from(knownCampaigns.values());
}

/**
 * Get campaign by ID
 */
export function getCampaign(id: string): CoordinatedCampaign | undefined {
  return knownCampaigns.get(id);
}

/**
 * Get campaign statistics
 */
export function getCampaignStats(): {
  totalCampaigns: number;
  activeCampaigns: number;
  byType: Record<CampaignType, number>;
  byThreatLevel: Record<string, number>;
  avgReach: number;
} {
  const campaigns = Array.from(knownCampaigns.values());

  const byType: Record<CampaignType, number> = {
    disinformation: 0,
    propaganda: 0,
    astroturfing: 0,
    hijacking: 0,
    amplification: 0,
    suppression: 0,
    polarization: 0,
    destabilization: 0
  };

  const byThreatLevel: Record<string, number> = {
    low: 0,
    medium: 0,
    high: 0,
    critical: 0
  };

  for (const campaign of campaigns) {
    byType[campaign.type]++;
    byThreatLevel[campaign.threatLevel]++;
  }

  const avgReach = campaigns.length > 0
    ? campaigns.reduce((sum, c) => sum + c.reach.estimated, 0) / campaigns.length
    : 0;

  return {
    totalCampaigns: campaigns.length,
    activeCampaigns: campaigns.filter(c => c.status === 'active').length,
    byType,
    byThreatLevel,
    avgReach
  };
}

// ============================================================================
// TESTING
// ============================================================================

/**
 * Run memetic warfare tests
 */
export function runMemeticWarfareTests(): {
  passed: boolean;
  tests: Array<{ name: string; passed: boolean; message: string }>;
  summary: { total: number; passed: number; failed: number };
} {
  const tests: Array<{ name: string; passed: boolean; message: string }> = [];

  // Test 1: Memetic fingerprint generation
  const content = 'SHOCKING revelation: Government experts EXPOSE corruption!';
  const fp = generateMemeticFingerprint(content);
  tests.push({
    name: 'Fingerprint generation',
    passed: fp.id.length > 0 && fp.semanticSignature.length === 64,
    message: `Generated fingerprint: ${fp.id}`
  });

  // Test 2: Style feature extraction
  const style = extractStyleFeatures(content);
  tests.push({
    name: 'Style extraction',
    passed: style.capitalRatio > 0.1 && style.exclamationRatio > 0,
    message: `Capital ratio: ${style.capitalRatio.toFixed(2)}, exclamation: ${style.exclamationRatio.toFixed(3)}`
  });

  // Test 3: Emotional marker extraction
  const emotional = extractEmotionalMarkers(content);
  tests.push({
    name: 'Emotional markers',
    passed: emotional.includes('shocking') || emotional.includes('exposed'),
    message: `Markers: ${emotional.join(', ')}`
  });

  // Test 4: Fingerprint comparison
  const fp2 = generateMemeticFingerprint(content);
  const similarity = compareFingerprints(fp, fp2);
  tests.push({
    name: 'Fingerprint comparison',
    passed: similarity > 0.9,
    message: `Similarity: ${similarity.toFixed(2)}`
  });

  // Test 5: Network building
  const interactions = [
    { source: 'a', target: 'b', timestamp: 1, type: 'share' },
    { source: 'b', target: 'c', timestamp: 2, type: 'share' },
    { source: 'a', target: 'c', timestamp: 3, type: 'share' }
  ];
  const network = buildCoordinationNetwork(interactions);
  tests.push({
    name: 'Network building',
    passed: network.nodes.length === 3 && network.edges.length === 2,
    message: `Nodes: ${network.nodes.length}, edges: ${network.edges.length}, clusters: ${network.clusters}`
  });

  // Test 6: Temporal pattern analysis
  const events = [
    { timestamp: 1, intensity: 0.1 },
    { timestamp: 2, intensity: 0.3 },
    { timestamp: 3, intensity: 0.8 },
    { timestamp: 4, intensity: 0.6 },
    { timestamp: 5, intensity: 0.2 }
  ];
  const pattern = analyzeTemporalPattern(events);
  tests.push({
    name: 'Temporal analysis',
    passed: pattern.peakIntensity === 0.8 && pattern.type !== undefined,
    message: `Pattern: ${pattern.type}, peak: ${pattern.peakIntensity}`
  });

  // Test 7: Campaign detection
  const detection = detectCampaign(
    'SHOCKING: Experts reveal URGENT threat! Act NOW before it\'s too late!!!',
    'twitter',
    {
      engagement: { shares: 1000, likes: 50, comments: 20 }
    }
  );
  tests.push({
    name: 'Campaign detection',
    passed: detection.indicators.length > 0,
    message: `Detected: ${detection.detected}, indicators: ${detection.indicators.length}`
  });

  // Test 8: Campaign stats
  const stats = getCampaignStats();
  tests.push({
    name: 'Campaign stats',
    passed: stats.totalCampaigns >= 0,
    message: `Total: ${stats.totalCampaigns}, active: ${stats.activeCampaigns}`
  });

  // Test 9: Modularity calculation
  tests.push({
    name: 'Modularity calculation',
    passed: network.modularity >= 0 && network.modularity <= 1,
    message: `Modularity: ${network.modularity.toFixed(3)}`
  });

  // Test 10: Predictability calculation
  tests.push({
    name: 'Predictability calculation',
    passed: pattern.predictability >= 0 && pattern.predictability <= 1,
    message: `Predictability: ${pattern.predictability.toFixed(2)}`
  });

  const passed = tests.filter(t => t.passed).length;
  const failed = tests.filter(t => !t.passed).length;

  return {
    passed: failed === 0,
    tests,
    summary: { total: tests.length, passed, failed }
  };
}

// Export all
export default {
  generateMemeticFingerprint,
  compareFingerprints,
  buildCoordinationNetwork,
  analyzeTemporalPattern,
  detectCampaign,
  updateCampaign,
  getKnownCampaigns,
  getCampaign,
  getCampaignStats,
  runMemeticWarfareTests
};
