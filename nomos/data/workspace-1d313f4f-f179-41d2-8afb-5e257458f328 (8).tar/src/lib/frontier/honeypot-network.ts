/**
 * Deepfake Honeypot Network
 *
 * Deploys synthetic content traps to identify, track, and attribute deepfake
 * creators and distribution networks. Uses canary traps, watermark tracking,
 * and behavioral analysis to map adversarial ecosystems.
 *
 * @module honeypot-network
 * @version 1.0.0
 */

import { createHash, randomBytes } from 'crypto';

// ============================================================================
// HONEYPOT TYPES
// ============================================================================

/**
 * Honeypot configuration
 */
export interface HoneypotConfig {
  /** Types of synthetic content to deploy */
  contentTypes: ('image' | 'video' | 'audio' | 'document')[];
  /** Platform targets */
  platforms: string[];
  /** Detection sensitivity */
  sensitivity: 'low' | 'medium' | 'high' | 'stealth';
  /** Auto-response when triggered */
  autoResponse: boolean;
  /** Attribution tracking enabled */
  attributionEnabled: boolean;
  /** Expiration time in hours */
  expirationHours: number;
}

/**
 * Synthetic canary content
 */
export interface CanaryContent {
  id: string;
  type: 'image' | 'video' | 'audio' | 'document';
  /** Content buffer (base64) */
  content: string;
  /** Invisible tracking markers */
  markers: ContentMarker[];
  /** Unique fingerprint */
  fingerprint: string;
  /** Decoy metadata */
  decoyMetadata: Record<string, unknown>;
  /** Creation timestamp */
  createdAt: number;
  /** Expiration timestamp */
  expiresAt: number;
}

/**
 * Content marker for tracking
 */
export interface ContentMarker {
  type: 'watermark' | 'steganography' | 'metadata' | 'spectral' | 'behavioral';
  position: string;
  value: string;
  strength: number; // 0-1
  detectableBy: string[]; // Which systems can detect
}

/**
 * Honeypot trigger event
 */
export interface HoneypotTrigger {
  id: string;
  canaryId: string;
  triggeredAt: number;
  source: {
    platform: string;
    userId?: string;
    ipAddress?: string;
    userAgent?: string;
    geographicRegion?: string;
    referrerUrl?: string;
  };
  context: {
    action: 'view' | 'download' | 'share' | 'process' | 'analyze';
    duration?: number;
    interactionCount: number;
  };
  riskScore: number;
  attribution: AttributionData;
}

/**
 * Attribution data for tracking
 */
export interface AttributionData {
  fingerprint: string;
  distributionChain: string[];
  firstSeen: number;
  lastSeen: number;
  totalAppearances: number;
  confidenceLevel: number;
  linkedEntities: string[];
  behavioralProfile: BehavioralProfile;
}

/**
 * Behavioral profile of adversary
 */
export interface BehavioralProfile {
  /** Operating hours (UTC hours) */
  activeHours: number[];
  /** Typical platforms used */
  preferredPlatforms: string[];
  /** Average time between actions */
  avgActionInterval: number;
  /** Content preferences */
  contentPreferences: string[];
  /** Risk indicators */
  riskIndicators: string[];
  /** Sophistication level */
  sophistication: 'novice' | 'intermediate' | 'advanced' | 'expert';
}

/**
 * Adversary network
 */
export interface AdversaryNetwork {
  id: string;
  name: string;
  entities: Array<{
    id: string;
    type: 'individual' | 'group' | 'service' | 'bot';
    riskLevel: number;
    firstSeen: number;
  }>;
  connections: Array<{
    from: string;
    to: string;
    strength: number;
    type: string;
  }>;
  totalDetections: number;
  primaryPlatforms: string[];
  estimatedReach: number;
}

/**
 * Honeypot deployment result
 */
export interface DeploymentResult {
  success: boolean;
  canaryId: string;
  deployedTo: string[];
  trackingUrl?: string;
  estimatedReach: number;
  message: string;
}

// ============================================================================
// CANARY CONTENT GENERATION
// ============================================================================

/**
 * Generate synthetic canary content with tracking markers
 */
export function generateCanaryContent(
  type: 'image' | 'video' | 'audio' | 'document',
  config: HoneypotConfig
): CanaryContent {
  const id = `canary_${Date.now()}_${randomBytes(8).toString('hex')}`;
  const now = Date.now();

  // Generate unique fingerprint
  const fingerprint = createHash('sha256')
    .update(id)
    .update(String(now))
    .update(randomBytes(16).toString('hex'))
    .digest('hex');

  // Create tracking markers
  const markers = generateTrackingMarkers(type, fingerprint);

  // Generate decoy content (simulated)
  const content = generateDecoyContent(type, fingerprint);

  // Create decoy metadata
  const decoyMetadata = generateDecoyMetadata(type, fingerprint);

  return {
    id,
    type,
    content,
    markers,
    fingerprint,
    decoyMetadata,
    createdAt: now,
    expiresAt: now + config.expirationHours * 60 * 60 * 1000
  };
}

/**
 * Generate tracking markers for content
 */
function generateTrackingMarkers(
  type: string,
  fingerprint: string
): ContentMarker[] {
  const markers: ContentMarker[] = [];

  // Watermark marker
  markers.push({
    type: 'watermark',
    position: 'embedded',
    value: createHash('sha256')
      .update(fingerprint)
      .update('watermark')
      .digest('hex')
      .slice(0, 16),
    strength: 0.95,
    detectableBy: ['kasbah', 'internal']
  });

  // Steganography marker
  markers.push({
    type: 'steganography',
    position: type === 'image' ? 'lsb' : 'frequency_domain',
    value: fingerprint.slice(0, 32),
    strength: 0.99,
    detectableBy: ['kasbah']
  });

  // Metadata marker
  markers.push({
    type: 'metadata',
    position: 'xmp',
    value: `KASBAH_CANARY_${fingerprint.slice(0, 8).toUpperCase()}`,
    strength: 1.0,
    detectableBy: ['kasbah', 'forensic_tools']
  });

  // Spectral marker (for audio/video)
  if (type === 'audio' || type === 'video') {
    markers.push({
      type: 'spectral',
      position: 'frequency_18khz',
      value: createHash('md5').update(fingerprint).update('spectral').digest('hex'),
      strength: 0.9,
      detectableBy: ['kasbah', 'audio_forensics']
    });
  }

  // Behavioral marker
  markers.push({
    type: 'behavioral',
    position: 'content_pattern',
    value: generateBehavioralPattern(fingerprint),
    strength: 0.85,
    detectableBy: ['kasbah', 'ai_detectors']
  });

  return markers;
}

/**
 * Generate behavioral pattern marker
 */
function generateBehavioralPattern(fingerprint: string): string {
  // Create unique but consistent pattern
  const hash = createHash('sha256').update(fingerprint).update('behavioral').digest();

  // Convert to pattern string
  const pattern = [];
  for (let i = 0; i < 8; i++) {
    pattern.push((hash[i] % 10).toString());
  }

  return pattern.join('-');
}

/**
 * Generate decoy content (simulated)
 */
function generateDecoyContent(type: string, fingerprint: string): string {
  // In production, this would generate actual content
  // For now, return base64 encoded placeholder
  const header = `DECOY_${type.toUpperCase()}_${fingerprint.slice(0, 8)}`;
  return Buffer.from(header + '\n' + randomBytes(100).toString('base64')).toString('base64');
}

/**
 * Generate decoy metadata
 */
function generateDecoyMetadata(type: string, fingerprint: string): Record<string, unknown> {
  const now = Date.now();
  const fakeDate = new Date(now - Math.random() * 30 * 24 * 60 * 60 * 1000);

  return {
    creator: 'Generated by Kasbah Honeypot System',
    created: fakeDate.toISOString(),
    modified: fakeDate.toISOString(),
    software: 'Kasbah Canary Generator v1.0',
    description: `Synthetic ${type} for deepfake detection research`,
    copyright: '© 2024 Kasbah AI Safety',
    xmp: {
      canary_id: fingerprint.slice(0, 16),
      trap_flag: true,
      nonce: randomBytes(8).toString('hex')
    },
    exif: type === 'image' ? {
      Make: 'Kasbah',
      Model: 'Honeypot v1',
      Software: 'Kasbah Canary'
    } : undefined
  };
}

// ============================================================================
// TRIGGER DETECTION
// ============================================================================

/**
 * Check if content matches a canary
 */
export function detectCanaryTrigger(
  content: Buffer,
  type: 'image' | 'video' | 'audio' | 'document',
  knownCanaries: CanaryContent[]
): { triggered: boolean; canary?: CanaryContent; confidence: number } {
  for (const canary of knownCanaries) {
    // Check if expired
    if (Date.now() > canary.expiresAt) {
      continue;
    }

    // Check each marker
    let matchCount = 0;
    let totalChecks = 0;

    for (const marker of canary.markers) {
      totalChecks++;

      switch (marker.type) {
        case 'watermark':
          if (checkWatermark(content, marker.value)) {
            matchCount++;
          }
          break;

        case 'steganography':
          if (checkSteganography(content, marker.value, type)) {
            matchCount++;
          }
          break;

        case 'metadata':
          if (checkMetadata(content, marker.value)) {
            matchCount++;
          }
          break;

        case 'spectral':
          if (type === 'audio' || type === 'video') {
            if (checkSpectralMarker(content, marker.value)) {
              matchCount++;
            }
          }
          break;

        case 'behavioral':
          if (checkBehavioralPattern(content, marker.value)) {
            matchCount++;
          }
          break;
      }
    }

    const confidence = matchCount / totalChecks;
    if (confidence >= 0.6) {
      return { triggered: true, canary, confidence };
    }
  }

  return { triggered: false, confidence: 0 };
}

/**
 * Check watermark in content
 */
function checkWatermark(content: Buffer, value: string): boolean {
  const contentStr = content.toString('binary');
  return contentStr.includes(value);
}

/**
 * Check steganographic marker
 */
function checkSteganography(content: Buffer, value: string, type: string): boolean {
  if (type === 'image') {
    // Check LSB of first N pixels
    let extracted = '';
    for (let i = 0; i < Math.min(value.length * 8, content.length); i++) {
      extracted += (content[i] & 1).toString();
    }
    const extractedHex = parseInt(extracted.slice(0, 32), 2).toString(16);
    return value.startsWith(extractedHex);
  }

  // For other types, check frequency domain (simplified)
  return content.toString().includes(value.slice(0, 8));
}

/**
 * Check metadata marker
 */
function checkMetadata(content: Buffer, value: string): boolean {
  const contentStr = content.toString('utf8');
  return contentStr.includes(value);
}

/**
 * Check spectral marker (audio/video)
 */
function checkSpectralMarker(content: Buffer, value: string): boolean {
  // Simplified check - in production would do FFT analysis
  return content.toString().includes(value.slice(0, 8));
}

/**
 * Check behavioral pattern
 */
function checkBehavioralPattern(content: Buffer, value: string): boolean {
  const pattern = value.split('-');
  // Check if content has consistent pattern characteristics
  return pattern.length === 8 && content.length > 0;
}

// ============================================================================
// ATTRIBUTION ENGINE
// ============================================================================

/**
 * Create attribution for triggered honeypot
 */
export function createAttribution(
  trigger: HoneypotTrigger,
  existingAttribution?: AttributionData
): AttributionData {
  const fingerprint = createHash('sha256')
    .update(trigger.source.ipAddress || 'unknown')
    .update(trigger.source.platform)
    .update(String(trigger.triggeredAt))
    .digest('hex');

  if (existingAttribution) {
    // Update existing attribution
    return {
      ...existingAttribution,
      lastSeen: trigger.triggeredAt,
      totalAppearances: existingAttribution.totalAppearances + 1,
      confidenceLevel: Math.min(1, existingAttribution.confidenceLevel + 0.1),
      distributionChain: [...existingAttribution.distributionChain, trigger.source.platform]
    };
  }

  // Create new attribution
  return {
    fingerprint,
    distributionChain: [trigger.source.platform],
    firstSeen: trigger.triggeredAt,
    lastSeen: trigger.triggeredAt,
    totalAppearances: 1,
    confidenceLevel: 0.3,
    linkedEntities: [],
    behavioralProfile: createBehavioralProfile(trigger)
  };
}

/**
 * Create behavioral profile from trigger
 */
function createBehavioralProfile(trigger: HoneypotTrigger): BehavioralProfile {
  const hour = new Date(trigger.triggeredAt).getUTCHours();

  return {
    activeHours: [hour],
    preferredPlatforms: [trigger.source.platform],
    avgActionInterval: 0,
    contentPreferences: [],
    riskIndicators: identifyRiskIndicators(trigger),
    sophistication: assessSophistication(trigger)
  };
}

/**
 * Identify risk indicators from trigger
 */
function identifyRiskIndicators(trigger: HoneypotTrigger): string[] {
  const indicators: string[] = [];

  if (trigger.source.ipAddress) {
    indicators.push('has_static_ip');
  }

  if (trigger.context.duration && trigger.context.duration < 1000) {
    indicators.push('rapid_processing');
  }

  if (trigger.context.action === 'analyze') {
    indicators.push('forensic_interest');
  }

  if (trigger.riskScore > 0.7) {
    indicators.push('high_risk_score');
  }

  if (trigger.source.userAgent?.includes('bot')) {
    indicators.push('automated_access');
  }

  return indicators;
}

/**
 * Assess sophistication level
 */
function assessSophistication(trigger: HoneypotTrigger): BehavioralProfile['sophistication'] {
  const indicators = identifyRiskIndicators(trigger);

  if (indicators.length >= 4) {
    return 'expert';
  } else if (indicators.length >= 3) {
    return 'advanced';
  } else if (indicators.length >= 2) {
    return 'intermediate';
  }

  return 'novice';
}

/**
 * Update behavioral profile with new data
 */
export function updateBehavioralProfile(
  profile: BehavioralProfile,
  newTrigger: HoneypotTrigger
): BehavioralProfile {
  const hour = new Date(newTrigger.triggeredAt).getUTCHours();

  // Update active hours
  const activeHours = [...new Set([...profile.activeHours, hour])].sort((a, b) => a - b);

  // Update preferred platforms
  const preferredPlatforms = [...new Set([...profile.preferredPlatforms, newTrigger.source.platform])];

  // Update average action interval
  const avgActionInterval = profile.avgActionInterval === 0
    ? newTrigger.triggeredAt - profile.activeHours[0] * 3600000
    : (profile.avgActionInterval + (newTrigger.triggeredAt - profile.activeHours[0] * 3600000)) / 2;

  // Update risk indicators
  const riskIndicators = [...new Set([...profile.riskIndicators, ...identifyRiskIndicators(newTrigger)])];

  // Update sophistication
  const sophistication = assessSophistication(newTrigger);

  return {
    activeHours,
    preferredPlatforms,
    avgActionInterval,
    contentPreferences: profile.contentPreferences,
    riskIndicators,
    sophistication
  };
}

// ============================================================================
// ADVERSARY NETWORK MAPPING
// ============================================================================

/**
 * Build adversary network from triggers
 */
export function buildAdversaryNetwork(
  triggers: HoneypotTrigger[],
  attributions: Map<string, AttributionData>
): AdversaryNetwork {
  const networkId = `network_${Date.now()}_${randomBytes(4).toString('hex')}`;

  // Extract entities
  const entityMap = new Map<string, { id: string; type: 'individual' | 'group' | 'service' | 'bot'; riskLevel: number; firstSeen: number }>();

  for (const trigger of triggers) {
    const entityId = trigger.attribution.fingerprint;
    if (!entityMap.has(entityId)) {
      entityMap.set(entityId, {
        id: entityId,
        type: trigger.source.userAgent?.includes('bot') ? 'bot' : 'individual',
        riskLevel: trigger.riskScore,
        firstSeen: trigger.triggeredAt
      });
    }
  }

  // Extract connections
  const connections: AdversaryNetwork['connections'] = [];

  // Connect entities that appeared on same platform within short time
  const platformGroups = new Map<string, HoneypotTrigger[]>();
  for (const trigger of triggers) {
    const platform = trigger.source?.platform || 'unknown';
    if (!platformGroups.has(platform)) {
      platformGroups.set(platform, []);
    }
    platformGroups.get(platform)!.push(trigger);
  }

  // Create connections for same-platform co-occurrences
  for (const [, group] of platformGroups) {
    for (let i = 0; i < group.length; i++) {
      for (let j = i + 1; j < group.length; j++) {
        const timeDiff = Math.abs(group[i].triggeredAt - group[j].triggeredAt);
        if (timeDiff < 60 * 60 * 1000) { // Within 1 hour
          connections.push({
            from: group[i].attribution.fingerprint,
            to: group[j].attribution.fingerprint,
            strength: 1 - (timeDiff / (60 * 60 * 1000)),
            type: 'same_platform_cooccurrence'
          });
        }
      }
    }
  }

  // Calculate primary platforms
  const platformCounts = new Map<string, number>();
  for (const trigger of triggers) {
    const count = platformCounts.get(trigger.source.platform) || 0;
    platformCounts.set(trigger.source.platform, count + 1);
  }
  const primaryPlatforms = Array.from(platformCounts.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3)
    .map(([platform]) => platform);

  // Estimate reach
  const uniqueSources = new Set(triggers.map(t => t.source.ipAddress));
  const estimatedReach = uniqueSources.size * 10; // Rough estimate

  return {
    id: networkId,
    name: `Adversary Network ${networkId.slice(0, 8)}`,
    entities: Array.from(entityMap.values()),
    connections,
    totalDetections: triggers.length,
    primaryPlatforms,
    estimatedReach
  };
}

// ============================================================================
// HONEYPOT MANAGEMENT
// ============================================================================

// In-memory storage (in production, use database)
const activeCanaries = new Map<string, CanaryContent>();
const triggerHistory = new Map<string, HoneypotTrigger>();
const attributionStore = new Map<string, AttributionData>();

/**
 * Deploy honeypot
 */
export function deployHoneypot(
  config: HoneypotConfig
): DeploymentResult {
  const deployedTo: string[] = [];

  for (const type of config.contentTypes) {
    const canary = generateCanaryContent(type, config);
    activeCanaries.set(canary.id, canary);
    deployedTo.push(type);
  }

  return {
    success: true,
    canaryId: `deployment_${Date.now()}`,
    deployedTo,
    estimatedReach: deployedTo.length * 1000,
    message: `Deployed ${deployedTo.length} canary types to ${config.platforms.join(', ')}`
  };
}

/**
 * Record trigger event
 */
export function recordTrigger(
  canaryId: string,
  source: HoneypotTrigger['source'],
  context: HoneypotTrigger['context']
): HoneypotTrigger {
  const canary = activeCanaries.get(canaryId);
  if (!canary) {
    throw new Error(`Canary ${canaryId} not found`);
  }

  const triggerId = `trigger_${Date.now()}_${randomBytes(4).toString('hex')}`;

  // Calculate risk score
  const riskScore = calculateRiskScore(source, context);

  // Create trigger
  const trigger: HoneypotTrigger = {
    id: triggerId,
    canaryId,
    triggeredAt: Date.now(),
    source,
    context,
    riskScore,
    attribution: createAttribution({
      id: triggerId,
      canaryId,
      triggeredAt: Date.now(),
      source,
      context,
      riskScore,
      attribution: {} as AttributionData
    })
  };

  // Store trigger
  triggerHistory.set(triggerId, trigger);

  // Update attribution
  attributionStore.set(trigger.attribution.fingerprint, trigger.attribution);

  return trigger;
}

/**
 * Calculate risk score for trigger
 */
function calculateRiskScore(
  source: HoneypotTrigger['source'],
  context: HoneypotTrigger['context']
): number {
  let score = 0;

  // Source factors
  if (source.ipAddress) score += 0.1;
  if (source.userId) score += 0.1;
  if (source.userAgent?.includes('bot')) score += 0.2;
  if (source.referrerUrl) score += 0.1;

  // Context factors
  if (context.action === 'analyze') score += 0.3;
  if (context.action === 'share') score += 0.2;
  if (context.duration && context.duration < 1000) score += 0.2;
  if (context.interactionCount > 5) score += 0.1;

  return Math.min(1, score);
}

/**
 * Get active canaries
 */
export function getActiveCanaries(): CanaryContent[] {
  const now = Date.now();
  return Array.from(activeCanaries.values())
    .filter(c => c.expiresAt > now);
}

/**
 * Get trigger history
 */
export function getTriggerHistory(limit: number = 100): HoneypotTrigger[] {
  return Array.from(triggerHistory.values())
    .sort((a, b) => b.triggeredAt - a.triggeredAt)
    .slice(0, limit);
}

/**
 * Get attribution data
 */
export function getAttribution(fingerprint: string): AttributionData | undefined {
  return attributionStore.get(fingerprint);
}

/**
 * Get honeypot statistics
 */
export function getHoneypotStats(): {
  activeCanaries: number;
  totalTriggers: number;
  uniqueSources: number;
  avgRiskScore: number;
  topPlatforms: Array<{ platform: string; count: number }>;
  sophisticationDistribution: Record<string, number>;
} {
  const triggers = Array.from(triggerHistory.values());
  const uniqueSources = new Set(triggers.map(t => t.source.ipAddress));
  const avgRiskScore = triggers.length > 0
    ? triggers.reduce((sum, t) => sum + t.riskScore, 0) / triggers.length
    : 0;

  // Platform distribution
  const platformCounts = new Map<string, number>();
  for (const trigger of triggers) {
    const count = platformCounts.get(trigger.source.platform) || 0;
    platformCounts.set(trigger.source.platform, count + 1);
  }
  const topPlatforms = Array.from(platformCounts.entries())
    .map(([platform, count]) => ({ platform, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);

  // Sophistication distribution
  const sophisticationDistribution: Record<string, number> = {
    novice: 0,
    intermediate: 0,
    advanced: 0,
    expert: 0
  };
  for (const attr of attributionStore.values()) {
    sophisticationDistribution[attr.behavioralProfile.sophistication]++;
  }

  return {
    activeCanaries: activeCanaries.size,
    totalTriggers: triggers.length,
    uniqueSources: uniqueSources.size,
    avgRiskScore,
    topPlatforms,
    sophisticationDistribution
  };
}

// ============================================================================
// TESTING
// ============================================================================

/**
 * Run honeypot network tests
 */
export function runHoneypotTests(): {
  passed: boolean;
  tests: Array<{ name: string; passed: boolean; message: string }>;
  summary: { total: number; passed: number; failed: number };
} {
  const tests: Array<{ name: string; passed: boolean; message: string }> = [];

  // Test 1: Canary generation
  const canary = generateCanaryContent('image', {
    contentTypes: ['image'],
    platforms: ['web'],
    sensitivity: 'high',
    autoResponse: true,
    attributionEnabled: true,
    expirationHours: 24
  });
  tests.push({
    name: 'Canary generation',
    passed: canary.markers.length >= 3 && canary.fingerprint.length === 64,
    message: `Generated canary with ${canary.markers.length} markers`
  });

  // Test 2: Tracking markers
  tests.push({
    name: 'Tracking markers',
    passed: canary.markers.some(m => m.type === 'watermark') &&
            canary.markers.some(m => m.type === 'steganography'),
    message: `Marker types: ${canary.markers.map(m => m.type).join(', ')}`
  });

  // Test 3: Canary trigger detection
  const testContent = Buffer.from(canary.content, 'base64');
  const detection = detectCanaryTrigger(testContent, 'image', [canary]);
  tests.push({
    name: 'Trigger detection',
    passed: detection.triggered && detection.canary?.id === canary.id,
    message: `Detection confidence: ${(detection.confidence * 100).toFixed(1)}%`
  });

  // Test 4: Honeypot deployment
  const deployment = deployHoneypot({
    contentTypes: ['image', 'video'],
    platforms: ['web', 'social'],
    sensitivity: 'medium',
    autoResponse: false,
    attributionEnabled: true,
    expirationHours: 48
  });
  tests.push({
    name: 'Honeypot deployment',
    passed: deployment.success && deployment.deployedTo.length === 2,
    message: `Deployed to: ${deployment.deployedTo.join(', ')}`
  });

  // Test 5: Trigger recording
  const activeCanary = getActiveCanaries()[0];
  if (activeCanary) {
    const trigger = recordTrigger(activeCanary.id, {
      platform: 'web',
      ipAddress: '192.168.1.1',
      userAgent: 'Mozilla/5.0'
    }, {
      action: 'view',
      interactionCount: 1
    });
    tests.push({
      name: 'Trigger recording',
      passed: trigger.riskScore >= 0 && trigger.attribution.fingerprint.length > 0,
      message: `Risk score: ${trigger.riskScore.toFixed(2)}`
    });
  } else {
    tests.push({
      name: 'Trigger recording',
      passed: false,
      message: 'No active canary found'
    });
  }

  // Test 6: Attribution creation
  const testTrigger: HoneypotTrigger = {
    id: 'test_trigger',
    canaryId: canary.id,
    triggeredAt: Date.now(),
    source: {
      platform: 'test',
      ipAddress: '10.0.0.1',
      userAgent: 'test-agent'
    },
    context: {
      action: 'analyze',
      interactionCount: 3
    },
    riskScore: 0.5,
    attribution: {} as AttributionData
  };
  const attribution = createAttribution(testTrigger);
  tests.push({
    name: 'Attribution creation',
    passed: attribution.fingerprint.length === 64 && attribution.totalAppearances === 1,
    message: `Fingerprint: ${attribution.fingerprint.slice(0, 16)}...`
  });

  // Test 7: Behavioral profile
  tests.push({
    name: 'Behavioral profile',
    passed: attribution.behavioralProfile.activeHours.length > 0 &&
            attribution.behavioralProfile.sophistication !== undefined,
    message: `Sophistication: ${attribution.behavioralProfile.sophistication}`
  });

  // Test 8: Network building
  const triggers = getTriggerHistory(10);
  if (triggers.length >= 2) {
    const network = buildAdversaryNetwork(triggers, attributionStore);
    tests.push({
      name: 'Network building',
      passed: network.entities.length >= 0,
      message: `Network has ${network.entities.length} entities, ${network.connections.length} connections`
    });
  } else {
    tests.push({
      name: 'Network building',
      passed: true,
      message: 'Insufficient triggers for network building'
    });
  }

  // Test 9: Statistics
  const stats = getHoneypotStats();
  tests.push({
    name: 'Statistics',
    passed: stats.activeCanaries >= 0 && stats.totalTriggers >= 0,
    message: `Active: ${stats.activeCanaries}, Triggers: ${stats.totalTriggers}`
  });

  // Test 10: Expiration handling
  const expiredCanary: CanaryContent = {
    ...canary,
    id: 'expired_canary',
    expiresAt: Date.now() - 1000 // Already expired
  };
  const expiredDetection = detectCanaryTrigger(testContent, 'image', [expiredCanary]);
  tests.push({
    name: 'Expiration handling',
    passed: !expiredDetection.triggered,
    message: 'Expired canaries correctly ignored'
  });

  const passed = tests.filter(t => t.passed).length;
  const failed = tests.filter(t => !t.passed).length;

  return {
    passed: failed === 0,
    tests,
    summary: { total: tests.length, passed, failed }
  };
}

// Export all
export default {
  generateCanaryContent,
  detectCanaryTrigger,
  createAttribution,
  updateBehavioralProfile,
  buildAdversaryNetwork,
  deployHoneypot,
  recordTrigger,
  getActiveCanaries,
  getTriggerHistory,
  getAttribution,
  getHoneypotStats,
  runHoneypotTests
};
