/**
 * Enterprise-grade retry utility with exponential backoff
 * Implements circuit breaker pattern for resilience
 */

interface RetryConfig {
  maxAttempts: number
  initialDelayMs: number
  maxDelayMs: number
  backoffMultiplier: number
  retryableErrors: string[] // Error messages/patterns that should trigger retry
  onRetry?: (attempt: number, error: Error, delayMs: number) => void
}

interface CircuitBreakerState {
  isOpen: boolean
  failureCount: number
  lastFailureTime: number
  nextAttemptTime: number
}

// Circuit breaker configuration
interface CircuitBreakerConfig {
  failureThreshold: number     // Number of failures before opening circuit
  resetTimeoutMs: number       // Time to wait before attempting to close circuit
  halfOpenMaxAttempts: number  // Max attempts in half-open state
}

// Default configurations
export const DEFAULT_RETRY_CONFIG: RetryConfig = {
  maxAttempts: 3,
  initialDelayMs: 1000,
  maxDelayMs: 30000,
  backoffMultiplier: 2,
  retryableErrors: [
    'ECONNRESET',
    'ETIMEDOUT',
    'ENOTFOUND',
    'EAI_AGAIN',
    'ECONNREFUSED',
    'network',
    'timeout',
    'rate limit',
    'overloaded',
    'temporarily unavailable'
  ]
}

export const DEFAULT_CIRCUIT_BREAKER_CONFIG: CircuitBreakerConfig = {
  failureThreshold: 5,
  resetTimeoutMs: 60000, // 1 minute
  halfOpenMaxAttempts: 3
}

// Circuit breaker instances store
const circuitBreakers = new Map<string, CircuitBreakerState>()

/**
 * Calculate delay with exponential backoff and jitter
 */
function calculateDelay(attempt: number, config: RetryConfig): number {
  const baseDelay = config.initialDelayMs * Math.pow(config.backoffMultiplier, attempt - 1)
  const cappedDelay = Math.min(baseDelay, config.maxDelayMs)
  
  // Add jitter (±25%) to prevent thundering herd
  const jitter = cappedDelay * 0.25 * (Math.random() * 2 - 1)
  
  return Math.max(0, Math.round(cappedDelay + jitter))
}

/**
 * Check if error is retryable
 */
function isRetryableError(error: Error, config: RetryConfig): boolean {
  const errorMessage = error.message.toLowerCase()
  const errorName = error.name.toLowerCase()
  
  return config.retryableErrors.some(retryable => 
    errorMessage.includes(retryable.toLowerCase()) ||
    errorName.includes(retryable.toLowerCase())
  )
}

/**
 * Execute function with retry logic
 */
export async function withRetry<T>(
  fn: () => Promise<T>,
  config: Partial<RetryConfig> = {}
): Promise<T> {
  const fullConfig = { ...DEFAULT_RETRY_CONFIG, ...config }
  let lastError: Error | undefined

  for (let attempt = 1; attempt <= fullConfig.maxAttempts; attempt++) {
    try {
      return await fn()
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error))
      
      // Check if error is retryable
      if (!isRetryableError(lastError, fullConfig)) {
        throw lastError
      }
      
      // Check if we've exhausted attempts
      if (attempt >= fullConfig.maxAttempts) {
        throw lastError
      }
      
      // Calculate delay
      const delayMs = calculateDelay(attempt, fullConfig)
      
      // Log retry
      if (fullConfig.onRetry) {
        fullConfig.onRetry(attempt, lastError, delayMs)
      }
      
      // Wait before next attempt
      await sleep(delayMs)
    }
  }

  throw lastError || new Error('Retry failed without error')
}

/**
 * Circuit breaker implementation
 */
export class CircuitBreaker {
  private state: CircuitBreakerState
  private config: CircuitBreakerConfig
  private halfOpenAttempts: number = 0

  constructor(
    private name: string,
    config: Partial<CircuitBreakerConfig> = {}
  ) {
    this.config = { ...DEFAULT_CIRCUIT_BREAKER_CONFIG, ...config }
    this.state = {
      isOpen: false,
      failureCount: 0,
      lastFailureTime: 0,
      nextAttemptTime: 0
    }
  }

  /**
   * Execute function through circuit breaker
   */
  async execute<T>(fn: () => Promise<T>): Promise<T> {
    // Check if circuit is open
    if (this.state.isOpen) {
      const now = Date.now()
      
      // Check if we can try half-open
      if (now >= this.state.nextAttemptTime) {
        // In half-open state, allow limited attempts
        if (this.halfOpenAttempts >= this.config.halfOpenMaxAttempts) {
          throw new Error(`Circuit breaker '${this.name}' is open. Please try again later.`)
        }
        this.halfOpenAttempts++
      } else {
        throw new Error(`Circuit breaker '${this.name}' is open. Next attempt in ${Math.ceil((this.state.nextAttemptTime - now) / 1000)} seconds.`)
      }
    }

    try {
      const result = await fn()
      this.onSuccess()
      return result
    } catch (error) {
      this.onFailure()
      throw error
    }
  }

  /**
   * Handle successful execution
   */
  private onSuccess(): void {
    this.state.failureCount = 0
    this.state.isOpen = false
    this.halfOpenAttempts = 0
  }

  /**
   * Handle failed execution
   */
  private onFailure(): void {
    this.state.failureCount++
    this.state.lastFailureTime = Date.now()

    if (this.state.failureCount >= this.config.failureThreshold) {
      this.state.isOpen = true
      this.state.nextAttemptTime = Date.now() + this.config.resetTimeoutMs
    }
  }

  /**
   * Get current state
   */
  getState(): CircuitBreakerState {
    return { ...this.state }
  }

  /**
   * Reset circuit breaker
   */
  reset(): void {
    this.state = {
      isOpen: false,
      failureCount: 0,
      lastFailureTime: 0,
      nextAttemptTime: 0
    }
    this.halfOpenAttempts = 0
  }
}

// Pre-configured circuit breakers
export const vlmCircuitBreaker = new CircuitBreaker('vlm-api', {
  failureThreshold: 5,
  resetTimeoutMs: 60000,
  halfOpenMaxAttempts: 2
})

export const dbCircuitBreaker = new CircuitBreaker('database', {
  failureThreshold: 3,
  resetTimeoutMs: 30000,
  halfOpenMaxAttempts: 1
})

/**
 * Combine retry with circuit breaker
 */
export async function withRetryAndCircuitBreaker<T>(
  circuitBreaker: CircuitBreaker,
  fn: () => Promise<T>,
  retryConfig: Partial<RetryConfig> = {}
): Promise<T> {
  return circuitBreaker.execute(() => withRetry(fn, retryConfig))
}

/**
 * Sleep utility
 */
export function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms))
}

/**
 * Timeout wrapper
 */
export async function withTimeout<T>(
  fn: () => Promise<T>,
  timeoutMs: number,
  errorMessage: string = 'Operation timed out'
): Promise<T> {
  let timeoutId: NodeJS.Timeout | undefined
  
  const timeoutPromise = new Promise<never>((_, reject) => {
    timeoutId = setTimeout(() => {
      reject(new Error(`${errorMessage} after ${timeoutMs}ms`))
    }, timeoutMs)
  })

  try {
    const result = await Promise.race([fn(), timeoutPromise])
    if (timeoutId) clearTimeout(timeoutId)
    return result
  } catch (error) {
    if (timeoutId) clearTimeout(timeoutId)
    throw error
  }
}

/**
 * Debounce utility
 */
export function debounce<T extends (...args: unknown[]) => unknown>(
  fn: T,
  delayMs: number
): (...args: Parameters<T>) => void {
  let timeoutId: NodeJS.Timeout | undefined

  return (...args: Parameters<T>) => {
    if (timeoutId) clearTimeout(timeoutId)
    timeoutId = setTimeout(() => fn(...args), delayMs)
  }
}

/**
 * Throttle utility
 */
export function throttle<T extends (...args: unknown[]) => unknown>(
  fn: T,
  limitMs: number
): (...args: Parameters<T>) => void {
  let inThrottle = false

  return (...args: Parameters<T>) => {
    if (!inThrottle) {
      fn(...args)
      inThrottle = true
      setTimeout(() => { inThrottle = false }, limitMs)
    }
  }
}
