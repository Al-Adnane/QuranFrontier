/**
 * Privacy-Preserving Analytics with Differential Privacy
 *
 * Implements differential privacy for analytics to protect individual privacy
 * while allowing meaningful aggregate insights.
 *
 * Key Features:
 * 1. Differential Privacy Mechanisms
 * 2. Privacy Budget Management
 * 3. Secure Aggregation
 * 4. Synthetic Data Generation
 * 5. Private Query Engine
 */

// ============================================================================
// Types and Interfaces
// ============================================================================

export interface DifferentialPrivacyConfig {
  epsilon: number; // Privacy budget
  delta: number; // Failure probability
  mechanism: PrivacyMechanism;
  sensitivity: number;
  clippingBound?: number;
}

export type PrivacyMechanism =
  | 'laplace'
  | 'gaussian'
  | 'exponential'
  | 'geometric'
  | 'randomized_response';

export interface PrivacyBudget {
  id: string;
  totalEpsilon: number;
  totalDelta: number;
  spentEpsilon: number;
  spentDelta: number;
  remainingEpsilon: number;
  remainingDelta: number;
  operations: BudgetOperation[];
  createdAt: Date;
  expiresAt?: Date;
}

export interface BudgetOperation {
  id: string;
  timestamp: Date;
  epsilon: number;
  delta: number;
  query: string;
  result: string;
}

export interface PrivateQuery {
  id: string;
  type: QueryType;
  target: string;
  aggregation: AggregationType;
  filters?: QueryFilter[];
  groupBy?: string[];
  epsilon: number;
  delta: number;
}

export type QueryType =
  | 'count'
  | 'sum'
  | 'average'
  | 'min'
  | 'max'
  | 'histogram'
  | 'percentile';

export type AggregationType =
  | 'exact'
  | 'noisy'
  | 'threshold';

export interface QueryFilter {
  field: string;
  operator: 'eq' | 'neq' | 'gt' | 'gte' | 'lt' | 'lte' | 'in' | 'contains';
  value: unknown;
}

export interface PrivateQueryResult {
  id: string;
  queryId: string;
  timestamp: Date;
  result: unknown;
  noiseAdded: number;
  epsilonUsed: number;
  deltaUsed: number;
  confidenceInterval?: [number, number];
  accuracy: number;
}

export interface SecureAggregationConfig {
  minParticipants: number;
  maxParticipants: number;
  threshold: number; // Secret sharing threshold
  noiseScale: number;
}

export interface AggregationRound {
  id: string;
  participants: string[];
  threshold: number;
  status: 'collecting' | 'computing' | 'completed' | 'failed';
  contributions: Map<string, unknown>;
  result?: unknown;
  createdAt: Date;
  completedAt?: Date;
}

export interface SyntheticDataConfig {
  sourceSchema: Record<string, SchemaField>;
  rowCount: number;
  privacyBudget: number;
  preserveStatistics: string[];
  constraints: DataConstraint[];
}

export interface SchemaField {
  name: string;
  type: 'string' | 'number' | 'boolean' | 'date' | 'categorical';
  nullable: boolean;
  categories?: string[];
  min?: number;
  max?: number;
}

export interface DataConstraint {
  type: ConstraintType;
  fields: string[];
  parameters: Record<string, unknown>;
}

export type ConstraintType =
  | 'unique'
  | 'foreign_key'
  | 'check'
  | 'correlation_preserve'
  | 'distribution_match';

export interface AnalyticsReport {
  id: string;
  timestamp: Date;
  queries: PrivateQueryResult[];
  totalEpsilon: number;
  totalDelta: number;
  summary: Record<string, unknown>;
  visualizations: Visualization[];
}

export interface Visualization {
  id: string;
  type: 'histogram' | 'line' | 'pie' | 'bar' | 'scatter';
  title: string;
  data: Record<string, unknown>;
  private: boolean;
}

// ============================================================================
// Differential Privacy Engine
// ============================================================================

export class DifferentialPrivacyEngine {
  private budgets: Map<string, PrivacyBudget> = new Map();

  /**
   * Create a new privacy budget
   */
  createBudget(
    totalEpsilon: number,
    totalDelta: number = 1e-6,
    expiresAt?: Date
  ): PrivacyBudget {
    const id = this.generateId('budget');

    const budget: PrivacyBudget = {
      id,
      totalEpsilon,
      totalDelta,
      spentEpsilon: 0,
      spentDelta: 0,
      remainingEpsilon: totalEpsilon,
      remainingDelta: totalDelta,
      operations: [],
      createdAt: new Date(),
      expiresAt,
    };

    this.budgets.set(id, budget);

    return budget;
  }

  /**
   * Add Laplace noise for differential privacy
   */
  addLaplaceNoise(
    value: number,
    sensitivity: number,
    epsilon: number
  ): number {
    const scale = sensitivity / epsilon;
    const noise = this.sampleLaplace(0, scale);
    return value + noise;
  }

  /**
   * Add Gaussian noise for (epsilon, delta)-differential privacy
   */
  addGaussianNoise(
    value: number,
    sensitivity: number,
    epsilon: number,
    delta: number
  ): number {
    const sigma = sensitivity * Math.sqrt(2 * Math.log(1.25 / delta)) / epsilon;
    const noise = this.sampleGaussian(0, sigma);
    return value + noise;
  }

  /**
   * Apply exponential mechanism for categorical data
   */
  exponentialMechanism<T>(
    items: T[],
    scoreFunction: (item: T) => number,
    sensitivity: number,
    epsilon: number
  ): T {
    const scores = items.map((item) => ({
      item,
      score: scoreFunction(item),
    }));

    const probabilities = scores.map(({ score }) =>
      Math.exp((epsilon * score) / (2 * sensitivity))
    );

    const totalProb = probabilities.reduce((sum, p) => sum + p, 0);
    const normalizedProbs = probabilities.map((p) => p / totalProb);

    return this.sampleCategorical(items, normalizedProbs);
  }

  /**
   * Apply randomized response for binary data
   */
  randomizedResponse(value: boolean, epsilon: number): boolean {
    const p = Math.exp(epsilon) / (Math.exp(epsilon) + 1);

    if (Math.random() < p) {
      return value; // Return true value with probability p
    }
    return !value; // Return flipped value with probability 1-p
  }

  /**
   * Execute a private query
   */
  async executePrivateQuery(
    budgetId: string,
    query: PrivateQuery,
    data: Record<string, unknown>[]
  ): Promise<PrivateQueryResult> {
    const budget = this.budgets.get(budgetId);
    if (!budget) {
      throw new Error('Budget not found');
    }

    // Check if budget has remaining capacity
    if (budget.remainingEpsilon < query.epsilon) {
      throw new Error('Insufficient privacy budget');
    }

    // Calculate true result
    const trueResult = this.calculateTrueResult(query, data);

    // Calculate sensitivity
    const sensitivity = this.calculateSensitivity(query, data);

    // Add noise based on mechanism
    let noisyResult: number;
    let noiseAdded: number;

    switch (query.type) {
      case 'count':
        noisyResult = this.addLaplaceNoise(
          trueResult as number,
          sensitivity,
          query.epsilon
        );
        noiseAdded = Math.abs(noisyResult - (trueResult as number));
        break;
      case 'sum':
        noisyResult = this.addLaplaceNoise(
          trueResult as number,
          sensitivity,
          query.epsilon
        );
        noiseAdded = Math.abs(noisyResult - (trueResult as number));
        break;
      case 'average':
        // Average requires two queries: sum and count
        const sum = this.addLaplaceNoise(
          this.calculateSum(query, data),
          sensitivity,
          query.epsilon / 2
        );
        const count = this.addLaplaceNoise(
          data.length,
          1,
          query.epsilon / 2
        );
        noisyResult = count > 0 ? sum / count : 0;
        noiseAdded = Math.abs(noisyResult - (trueResult as number));
        break;
      default:
        noisyResult = trueResult as number;
        noiseAdded = 0;
    }

    // Update budget
    budget.spentEpsilon += query.epsilon;
    budget.spentDelta += query.delta;
    budget.remainingEpsilon -= query.epsilon;
    budget.remainingDelta -= query.delta;

    budget.operations.push({
      id: this.generateId('op'),
      timestamp: new Date(),
      epsilon: query.epsilon,
      delta: query.delta,
      query: JSON.stringify(query),
      result: String(noisyResult),
    });

    return {
      id: this.generateId('result'),
      queryId: query.id,
      timestamp: new Date(),
      result: noisyResult,
      noiseAdded,
      epsilonUsed: query.epsilon,
      deltaUsed: query.delta,
      confidenceInterval: this.calculateConfidenceInterval(
        noisyResult,
        noiseAdded,
        0.95
      ),
      accuracy: 1 - noiseAdded / Math.max(Math.abs(noisyResult), 1),
    };
  }

  /**
   * Create a private histogram
   */
  async createPrivateHistogram(
    budgetId: string,
    data: Record<string, unknown>[],
    field: string,
    bins: number,
    epsilon: number
  ): Promise<{ bins: number[]; counts: number[] }> {
    const binWidth = 1 / bins;
    const counts: number[] = [];
    const binEdges: number[] = [];

    // Get min/max
    const values = data.map((d) => d[field] as number).filter((v) => !isNaN(v));
    const min = Math.min(...values);
    const max = Math.max(...values);
    const range = max - min;

    // Create bins
    for (let i = 0; i <= bins; i++) {
      binEdges.push(min + (range * i) / bins);
    }

    // Count in each bin with noise
    const epsilonPerBin = epsilon / bins;

    for (let i = 0; i < bins; i++) {
      const count = values.filter(
        (v) => v >= binEdges[i] && v < binEdges[i + 1]
      ).length;

      const noisyCount = this.addLaplaceNoise(count, 1, epsilonPerBin);
      counts.push(Math.max(0, Math.round(noisyCount)));
    }

    return { bins: binEdges.slice(0, -1), counts };
  }

  // Private methods

  private sampleLaplace(mean: number, scale: number): number {
    const u = Math.random() - 0.5;
    return mean - scale * Math.sign(u) * Math.log(1 - 2 * Math.abs(u));
  }

  private sampleGaussian(mean: number, stdDev: number): number {
    // Box-Muller transform
    const u1 = Math.random();
    const u2 = Math.random();
    const z0 = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
    return mean + stdDev * z0;
  }

  private sampleCategorical<T>(items: T[], probabilities: number[]): T {
    const r = Math.random();
    let cumProb = 0;

    for (let i = 0; i < items.length; i++) {
      cumProb += probabilities[i];
      if (r < cumProb) {
        return items[i];
      }
    }

    return items[items.length - 1];
  }

  private calculateTrueResult(
    query: PrivateQuery,
    data: Record<string, unknown>[]
  ): unknown {
    // Apply filters
    let filtered = data;
    if (query.filters) {
      filtered = data.filter((row) =>
        query.filters!.every((f) => this.applyFilter(row, f))
      );
    }

    switch (query.type) {
      case 'count':
        return filtered.length;
      case 'sum':
        return this.calculateSum(query, filtered);
      case 'average':
        const sum = this.calculateSum(query, filtered);
        return sum / filtered.length;
      case 'min':
        return Math.min(...filtered.map((d) => d[query.target] as number));
      case 'max':
        return Math.max(...filtered.map((d) => d[query.target] as number));
      default:
        return null;
    }
  }

  private calculateSum(
    query: PrivateQuery,
    data: Record<string, unknown>[]
  ): number {
    return data.reduce((sum, row) => {
      const value = row[query.target];
      return sum + (typeof value === 'number' ? value : 0);
    }, 0);
  }

  private calculateSensitivity(
    query: PrivateQuery,
    _data: Record<string, unknown>[]
  ): number {
    switch (query.type) {
      case 'count':
        return 1; // Adding/removing one row changes count by 1
      case 'sum':
        // Need to know the maximum possible value
        return 100; // Assume max value of 100 for simplicity
      case 'average':
        return 1;
      default:
        return 1;
    }
  }

  private applyFilter(
    row: Record<string, unknown>,
    filter: QueryFilter
  ): boolean {
    const value = row[filter.field];

    switch (filter.operator) {
      case 'eq':
        return value === filter.value;
      case 'neq':
        return value !== filter.value;
      case 'gt':
        return (value as number) > (filter.value as number);
      case 'gte':
        return (value as number) >= (filter.value as number);
      case 'lt':
        return (value as number) < (filter.value as number);
      case 'lte':
        return (value as number) <= (filter.value as number);
      case 'in':
        return (filter.value as unknown[]).includes(value);
      case 'contains':
        return String(value).includes(filter.value as string);
      default:
        return true;
    }
  }

  private calculateConfidenceInterval(
    value: number,
    noise: number,
    confidence: number
  ): [number, number] {
    const z = confidence === 0.95 ? 1.96 : confidence === 0.99 ? 2.576 : 1;
    const margin = z * noise;
    return [value - margin, value + margin];
  }

  private generateId(prefix: string): string {
    return `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  // Getters
  getBudget(id: string): PrivacyBudget | undefined {
    return this.budgets.get(id);
  }
}

// ============================================================================
// Secure Aggregation Service
// ============================================================================

export class SecureAggregationService {
  private rounds: Map<string, AggregationRound> = new Map();

  /**
   * Start a new secure aggregation round
   */
  startRound(
    participants: string[],
    config: SecureAggregationConfig
  ): AggregationRound {
    const id = this.generateId('round');

    const round: AggregationRound = {
      id,
      participants,
      threshold: config.threshold,
      status: 'collecting',
      contributions: new Map(),
      createdAt: new Date(),
    };

    this.rounds.set(id, round);

    return round;
  }

  /**
   * Submit contribution to aggregation round
   */
  submitContribution(
    roundId: string,
    participantId: string,
    contribution: unknown
  ): boolean {
    const round = this.rounds.get(roundId);
    if (!round) {
      throw new Error('Round not found');
    }

    if (round.status !== 'collecting') {
      throw new Error('Round not accepting contributions');
    }

    if (!round.participants.includes(participantId)) {
      throw new Error('Participant not in round');
    }

    // In production, contribution would be secret-shared
    round.contributions.set(participantId, contribution);

    // Check if threshold reached
    if (round.contributions.size >= round.threshold) {
      round.status = 'computing';
    }

    return true;
  }

  /**
   * Compute aggregate result
   */
  async computeAggregate(roundId: string): Promise<unknown> {
    const round = this.rounds.get(roundId);
    if (!round) {
      throw new Error('Round not found');
    }

    if (round.status !== 'computing') {
      throw new Error('Round not ready for computation');
    }

    // Sum all contributions (simplified - in production use secret sharing)
    let sum = 0;
    for (const contribution of round.contributions.values()) {
      if (typeof contribution === 'number') {
        sum += contribution;
      }
    }

    // Add noise for differential privacy
    const noise = this.sampleGaussian(0, 1);
    const result = sum + noise;

    round.result = result;
    round.status = 'completed';
    round.completedAt = new Date();

    return result;
  }

  private sampleGaussian(mean: number, stdDev: number): number {
    const u1 = Math.random();
    const u2 = Math.random();
    const z0 = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
    return mean + stdDev * z0;
  }

  private generateId(prefix: string): string {
    return `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  getRound(id: string): AggregationRound | undefined {
    return this.rounds.get(id);
  }
}

// ============================================================================
// Synthetic Data Generator
// ============================================================================

export class SyntheticDataGenerator {
  /**
   * Generate synthetic data with differential privacy guarantees
   */
  async generate(
    config: SyntheticDataConfig,
    sampleData?: Record<string, unknown>[]
  ): Promise<Record<string, unknown>[]> {
    const syntheticData: Record<string, unknown>[] = [];

    // Learn distributions from sample data (with privacy)
    const distributions = sampleData
      ? this.learnPrivateDistributions(sampleData, config)
      : this.getDefaultDistributions(config);

    // Generate synthetic records
    for (let i = 0; i < config.rowCount; i++) {
      const record: Record<string, unknown> = {};

      for (const [fieldName, field] of Object.entries(config.sourceSchema)) {
        record[fieldName] = this.generateFieldValue(
          fieldName,
          field,
          distributions[fieldName]
        );
      }

      syntheticData.push(record);
    }

    // Apply constraints
    this.applyConstraints(syntheticData, config.constraints);

    return syntheticData;
  }

  private learnPrivateDistributions(
    data: Record<string, unknown>[],
    config: SyntheticDataConfig
  ): Record<string, DistributionInfo> {
    const distributions: Record<string, DistributionInfo> = {};

    for (const [fieldName, field] of Object.entries(config.sourceSchema)) {
      if (field.type === 'number') {
        const values = data
          .map((d) => d[fieldName] as number)
          .filter((v) => !isNaN(v));

        // Add noise to statistics for privacy
        const mean = this.addNoise(
          values.reduce((s, v) => s + v, 0) / values.length,
          config.privacyBudget / Object.keys(config.sourceSchema).length
        );
        const stdDev = this.addNoise(
          Math.sqrt(
            values.reduce((s, v) => s + Math.pow(v - mean, 2), 0) / values.length
          ),
          config.privacyBudget / Object.keys(config.sourceSchema).length
        );

        distributions[fieldName] = { type: 'gaussian', mean, stdDev };
      } else if (field.type === 'categorical' && field.categories) {
        const counts: Record<string, number> = {};
        for (const cat of field.categories) {
          counts[cat] = data.filter((d) => d[fieldName] === cat).length;
        }

        // Add noise to counts
        for (const cat of Object.keys(counts)) {
          counts[cat] = Math.max(0, this.addNoise(counts[cat], 0.1));
        }

        distributions[fieldName] = { type: 'categorical', probabilities: counts };
      }
    }

    return distributions;
  }

  private getDefaultDistributions(
    config: SyntheticDataConfig
  ): Record<string, DistributionInfo> {
    const distributions: Record<string, DistributionInfo> = {};

    for (const [fieldName, field] of Object.entries(config.sourceSchema)) {
      if (field.type === 'number') {
        distributions[fieldName] = {
          type: 'gaussian',
          mean: (field.min || 0 + field.max || 100) / 2,
          stdDev: ((field.max || 100) - (field.min || 0)) / 4,
        };
      } else if (field.type === 'categorical' && field.categories) {
        const prob = 1 / field.categories.length;
        distributions[fieldName] = {
          type: 'categorical',
          probabilities: Object.fromEntries(
            field.categories.map((c) => [c, prob])
          ),
        };
      }
    }

    return distributions;
  }

  private generateFieldValue(
    _fieldName: string,
    field: SchemaField,
    distribution?: DistributionInfo
  ): unknown {
    if (!distribution) {
      return null;
    }

    if (distribution.type === 'gaussian') {
      let value = this.sampleGaussian(distribution.mean, distribution.stdDev);
      if (field.min !== undefined) value = Math.max(field.min, value);
      if (field.max !== undefined) value = Math.min(field.max, value);
      return value;
    }

    if (distribution.type === 'categorical') {
      const categories = Object.keys(distribution.probabilities);
      const probs = Object.values(distribution.probabilities);
      const total = probs.reduce((s, p) => s + p, 0);
      const normalized = probs.map((p) => p / total);

      return this.sampleCategorical(categories, normalized);
    }

    return null;
  }

  private applyConstraints(
    data: Record<string, unknown>[],
    _constraints: DataConstraint[]
  ): void {
    // Apply constraints to synthetic data
    // In production, implement constraint satisfaction
  }

  private addNoise(value: number, epsilon: number): number {
    const scale = 1 / epsilon;
    const noise = this.sampleLaplace(0, scale);
    return value + noise;
  }

  private sampleGaussian(mean: number, stdDev: number): number {
    const u1 = Math.random();
    const u2 = Math.random();
    const z0 = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
    return mean + stdDev * z0;
  }

  private sampleLaplace(mean: number, scale: number): number {
    const u = Math.random() - 0.5;
    return mean - scale * Math.sign(u) * Math.log(1 - 2 * Math.abs(u));
  }

  private sampleCategorical<T>(items: T[], probabilities: number[]): T {
    const r = Math.random();
    let cumProb = 0;

    for (let i = 0; i < items.length; i++) {
      cumProb += probabilities[i];
      if (r < cumProb) {
        return items[i];
      }
    }

    return items[items.length - 1];
  }
}

interface DistributionInfo {
  type: 'gaussian' | 'categorical';
  mean?: number;
  stdDev?: number;
  probabilities?: Record<string, number>;
}

// ============================================================================
// Privacy Analytics Dashboard
// ============================================================================

export class PrivacyAnalyticsDashboard {
  private dpEngine: DifferentialPrivacyEngine;
  private reports: Map<string, AnalyticsReport> = new Map();

  constructor(dpEngine: DifferentialPrivacyEngine) {
    this.dpEngine = dpEngine;
  }

  /**
   * Generate a privacy-preserving analytics report
   */
  async generateReport(
    budgetId: string,
    queries: PrivateQuery[],
    data: Record<string, unknown>[]
  ): Promise<AnalyticsReport> {
    const results: PrivateQueryResult[] = [];
    let totalEpsilon = 0;
    let totalDelta = 0;

    for (const query of queries) {
      const result = await this.dpEngine.executePrivateQuery(budgetId, query, data);
      results.push(result);
      totalEpsilon += result.epsilonUsed;
      totalDelta += result.deltaUsed;
    }

    const summary = this.generateSummary(results);
    const visualizations = this.generateVisualizations(results);

    const report: AnalyticsReport = {
      id: this.generateId('report'),
      timestamp: new Date(),
      queries: results,
      totalEpsilon,
      totalDelta,
      summary,
      visualizations,
    };

    this.reports.set(report.id, report);

    return report;
  }

  private generateSummary(results: PrivateQueryResult[]): Record<string, unknown> {
    const summary: Record<string, unknown> = {};

    for (const result of results) {
      summary[result.queryId] = {
        value: result.result,
        accuracy: result.accuracy,
        confidenceInterval: result.confidenceInterval,
      };
    }

    return summary;
  }

  private generateVisualizations(results: PrivateQueryResult[]): Visualization[] {
    return results.map((result) => ({
      id: this.generateId('viz'),
      type: 'bar' as const,
      title: `Query ${result.queryId}`,
      data: { value: result.result, noise: result.noiseAdded },
      private: true,
    }));
  }

  private generateId(prefix: string): string {
    return `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  getReport(id: string): AnalyticsReport | undefined {
    return this.reports.get(id);
  }
}

// ============================================================================
// Export
// ============================================================================

export const dpEngine = new DifferentialPrivacyEngine();
export const secureAggregation = new SecureAggregationService();
export const syntheticDataGenerator = new SyntheticDataGenerator();
export const analyticsDashboard = new PrivacyAnalyticsDashboard(dpEngine);
