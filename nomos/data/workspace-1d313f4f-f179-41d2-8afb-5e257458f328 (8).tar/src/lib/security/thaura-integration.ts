/**
 * Thaura.ai Integration Index
 * Exports all Thaura-inspired modules for ethical AI integration
 * 
 * This module provides comprehensive integration with Thaura.ai-style
 * ethical AI capabilities including:
 * 
 * - External AI Provider Integration (multi-provider support)
 * - Multi-Modal Attachment Processing (images, PDFs, audio, video)
 * - Function Calling Framework for deepfake detection tools
 * - Ethical AI Verification aligned with Thaura principles
 * - API Gateway with rate limiting and billing
 * 
 * @module ThauraIntegration
 * @version 1.0.0
 * @author Kasbah Security Team
 */

// ============================================================================
// EXTERNAL AI PROVIDER
// ============================================================================

export {
  // Types
  type AIProvider,
  type ProviderConfig,
  type MessageRole,
  type ChatMessage,
  type FunctionCall,
  type ToolCall,
  type FunctionDefinition,
  type JSONSchema,
  type ToolDefinition,
  type AttachmentType,
  type FileAttachment,
  type CompletionRequest,
  type CompletionResponse,
  type CompletionChoice,
  type TokenUsage,
  type StreamingChunk,
  type StreamingChoice,
  type APIKeyInfo,
  type UsageRecord,
  type EthicalVerification,
  type ProviderHealth,

  // Constants
  DEFAULT_PROVIDERS,
  DEEPFAKE_DETECTION_TOOLS,

  // Classes and Functions
  ExternalAIProviderManager,
  getExternalAIProviderManager,
  initializeExternalAIProvider,
} from './external-ai-provider';

// ============================================================================
// MULTI-MODAL PROCESSOR
// ============================================================================

export {
  // Types
  type MediaType,
  type ImageFormat,
  type AudioFormat,
  type VideoFormat,
  type DocumentFormat,
  type ProcessingResult,
  type MediaMetadata,
  type EXIFData,
  type GeoLocation,
  type DetectedArtifact,
  type ArtifactLocation,
  type AnalysisHint,
  type ProcessingOptions,
  type ImageAnalysisResult,
  type FaceDetection,
  type FacialLandmarks,
  type FaceAttributes,
  type ObjectDetection,
  type TextRegion,
  type ColorProfile,
  type RGBColor,
  type NoiseProfile,
  type CompressionArtifact,
  type AudioAnalysisResult,
  type VoiceActivitySegment,
  type SpeakerSegment,
  type SpeakerFeatures,
  type AudioQualityMetrics,
  type AudioDeepfakeIndicator,
  type VideoAnalysisResult,
  type FrameAnalysis,
  type TemporalAnalysis,
  type MotionVector,
  type FaceTrack,
  type SceneChange,
  type PDFAnalysisResult,
  type PageAnalysis,
  type FontInfo,
  type ImageExtraction,
  type Annotation,
  type PDFMetadata,
  type PDFSecurityFeatures,
  type AITextIndicator,

  // Constants
  DEFAULT_PROCESSING_OPTIONS,

  // Classes and Functions
  MultiModalProcessor,
  getMultiModalProcessor,
  processMediaAttachment,
} from './multimodal-processor';

// ============================================================================
// FUNCTION CALLING FRAMEWORK
// ============================================================================

export {
  // Types
  type ParameterType,
  type ParameterSchema,
  type DetectionFunction,
  type FunctionCategory,
  type FunctionPriority,
  type FunctionCallRequest,
  type FunctionCallResponse,
  type FunctionError,
  type ResponseMetadata,
  type ExecutionContext,
  type FunctionHandler,
  type RegistryEntry,
  type ArgumentValidator,
  type ValidationResult,
  type ValidationError,
  type CacheEntry,
  type FunctionStats,
  type BatchRequest,
  type BatchResponse,

  // Constants
  DETECTION_FUNCTIONS,

  // Classes and Functions
  FunctionCallingExecutor,
  getFunctionCallingExecutor,
  executeDetectionFunction,
} from './function-calling-framework';

// ============================================================================
// ETHICAL AI VERIFICATION
// ============================================================================

export {
  // Types
  type EthicalCategory,
  type EthicalPrinciple,
  type VerificationMethod,
  type VerificationResult,
  type EthicalIssue,
  type EthicalComplianceReport,
  type ComplianceLevel,
  type CertificationBadge,
  type MaqasidPrinciple,
  type BiasDetectionResult,
  type PrivacyVerification,
  type TransparencyVerification,

  // Constants
  CORE_ETHICAL_PRINCIPLES,
  MAQASID_PRINCIPLES,

  // Classes and Functions
  EthicalAIVerifier,
  getEthicalAIVerifier,
  verifyProviderEthics,
} from './ethical-ai-verification';

// ============================================================================
// API GATEWAY
// ============================================================================

export {
  // Types
  type GatewayConfig,
  type APIKey,
  type APIScope,
  type RateLimitStatus,
  type GatewayUsageRecord,
  type BillingTier,
  type BillingAccount,
  type Invoice,
  type InvoiceItem,
  type ProviderHealthStatus,
  type RoutingDecision,
  type GatewayCacheEntry,
  type GatewayRequest,
  type GatewayResponse,

  // Constants
  DEFAULT_GATEWAY_CONFIG,
  BILLING_TIERS,

  // Classes and Functions
  APIGateway,
  getAPIGateway,
  initializeAPIGateway,
} from './api-gateway';

// ============================================================================
// INTEGRATION HELPER
// ============================================================================

import { getExternalAIProviderManager, type AIProvider } from './external-ai-provider';
import { getMultiModalProcessor, type MediaType } from './multimodal-processor';
import { getFunctionCallingExecutor } from './function-calling-framework';
import { getEthicalAIVerifier } from './ethical-ai-verification';
import { getAPIGateway } from './api-gateway';

/**
 * Integration configuration
 */
export interface ThauraIntegrationConfig {
  providers?: {
    [key in AIProvider]?: {
      apiKey?: string;
      endpoint?: string;
      enabled?: boolean;
    };
  };
  ethicalVerification?: {
    enabled: boolean;
    strictMode: boolean;
  };
  multimodal?: {
    maxFileSize: number;
    supportedFormats: MediaType[];
  };
  gateway?: {
    rateLimit: number;
    enableCaching: boolean;
    enableBilling: boolean;
  };
}

/**
 * Initialize Thaura integration
 */
export function initializeThauraIntegration(
  config: ThauraIntegrationConfig = {}
): {
  aiProvider: ReturnType<typeof getExternalAIProviderManager>;
  multimodal: ReturnType<typeof getMultiModalProcessor>;
  functions: ReturnType<typeof getFunctionCallingExecutor>;
  ethics: ReturnType<typeof getEthicalAIVerifier>;
  gateway: ReturnType<typeof getAPIGateway>;
} {
  // Initialize AI providers
  const aiProvider = getExternalAIProviderManager();
  if (config.providers) {
    for (const [provider, settings] of Object.entries(config.providers)) {
      if (settings?.apiKey) {
        aiProvider.setAPIKey(provider as AIProvider, settings.apiKey);
      }
      if (settings?.endpoint) {
        aiProvider.configureProvider(provider as AIProvider, { endpoint: settings.endpoint });
      }
    }
  }

  // Initialize other modules
  const multimodal = getMultiModalProcessor();
  const functions = getFunctionCallingExecutor();
  const ethics = getEthicalAIVerifier();
  const gateway = getAPIGateway();

  return {
    aiProvider,
    multimodal,
    functions,
    ethics,
    gateway,
  };
}

/**
 * Complete deepfake analysis pipeline using Thaura-style integration
 */
export async function performIntegratedDeepfakeAnalysis(
  mediaData: string,
  mediaType: 'image' | 'video' | 'audio',
  options: {
    provider?: AIProvider;
    analysisDepth?: 'quick' | 'standard' | 'deep';
    verifyEthics?: boolean;
  } = {}
): Promise<{
  deepfakeScore: number;
  confidence: number;
  artifacts: Array<{ type: string; severity: string; description: string }>;
  analysis: string;
  ethicalCompliance?: {
    score: number;
    isCompliant: boolean;
  };
  provider: AIProvider;
  processingTime: number;
}> {
  const startTime = Date.now();
  const provider = options.provider || 'thaura';

  // Get instances
  const aiProvider = getExternalAIProviderManager();
  const multimodal = getMultiModalProcessor();
  const ethics = getEthicalAIVerifier();

  // Process media
  const processingResult = await multimodal.processMedia(
    mediaData,
    mediaType === 'image' ? 'image/jpeg' : mediaType === 'audio' ? 'audio/wav' : 'video/mp4'
  );

  // Perform AI analysis
  const analysisResult = await aiProvider.analyzeMediaForDeepfake(
    provider,
    mediaData,
    mediaType,
    { analysisDepth: options.analysisDepth || 'standard' }
  );

  // Verify ethical compliance if requested
  let ethicalCompliance;
  if (options.verifyEthics) {
    const ethicalResult = await ethics.verifyProvider(
      provider,
      provider.toUpperCase(),
      {}
    );
    ethicalCompliance = {
      score: ethicalResult.overallScore,
      isCompliant: ethicalResult.isCompliant,
    };
  }

  // Combine results
  const deepfakeScore = analysisResult.confidence;
  const confidence = processingResult.success ? 0.9 : 0.5;

  return {
    deepfakeScore,
    confidence,
    artifacts: [
      ...processingResult.artifacts.map((a) => ({
        type: a.type,
        severity: a.severity,
        description: a.description,
      })),
      ...analysisResult.artifacts.map((a) => ({
        type: a,
        severity: 'medium',
        description: `Detected: ${a}`,
      })),
    ],
    analysis: analysisResult.analysis,
    ethicalCompliance,
    provider,
    processingTime: Date.now() - startTime,
  };
}

/**
 * Get integration status
 */
export function getIntegrationStatus(): {
  modules: {
    aiProvider: boolean;
    multimodal: boolean;
    functions: boolean;
    ethics: boolean;
    gateway: boolean;
  };
  ready: boolean;
} {
  const aiProvider = getExternalAIProviderManager();
  const multimodal = getMultiModalProcessor();
  const functions = getFunctionCallingExecutor();
  const ethics = getEthicalAIVerifier();
  const gateway = getAPIGateway();

  const modules = {
    aiProvider: !!aiProvider,
    multimodal: !!multimodal,
    functions: !!functions,
    ethics: !!ethics,
    gateway: !!gateway,
  };

  return {
    modules,
    ready: Object.values(modules).every((v) => v),
  };
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

export default {
  initializeThauraIntegration,
  performIntegratedDeepfakeAnalysis,
  getIntegrationStatus,
};
