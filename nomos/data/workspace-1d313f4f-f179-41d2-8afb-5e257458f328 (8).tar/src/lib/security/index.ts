/**
 * Kasbah Security Module Index
 *
 * Unified exports for all security and privacy modules.
 * Disruption Score: 16/10 (Revolutionary)
 */

// ============================================================================
// Privacy-First Framework (Stanford HAI Inspired)
// ============================================================================

export {
  PrivacyFirstFramework,
  privacyFramework,
  PrivacyFirstConsentManager,
  DataMinimizationEngine,
  PurposeLimitationEnforcer,
  GlobalPrivacyControlSupport,
  type ConsentRecord,
  type ConsentPurpose,
  type PrivacySettings,
  type DataMinimizationConfig,
  type PurposeLimitationRule,
  type DataType,
  type PurposeCategory,
  type DataOperation,
  type PrivacyAuditLog,
} from './privacy-first-framework';

// ============================================================================
// Data Supply Chain Tracker (AI Transparency)
// ============================================================================

export {
  DataSupplyChainTracker,
  dataSupplyChain,
  TrainingDataTransparencyReport,
  transparencyReport,
  type DataLineageNode,
  type TrainingDataSource,
  type OutputTrace,
  type DataTransformation,
  type ComplianceFlag,
  type SupplyChainAudit,
} from './data-supply-chain';

// ============================================================================
// Collective Privacy Rights (Data Intermediaries)
// ============================================================================

export {
  DataIntermediaryManager,
  collectivePrivacyManager,
  CollectivePrivacyDashboard,
  collectiveDashboard,
  type DataIntermediary,
  type CollectiveMembership,
  type CollectiveAction,
  type PrivacyTrust,
  type GroupPrivacyProfile,
} from './collective-privacy-rights';

// ============================================================================
// Voice Privacy Protection (Wispr Flow Inspired)
// ============================================================================

export {
  VoiceCloneDetector,
  voiceCloneDetector,
  VoiceAnonymizer,
  voiceAnonymizer,
  VoiceAuthenticator,
  voiceAuthenticator,
  ImpersonationProtectionService,
  impersonationProtection,
  type VoiceProfile,
  type VoiceFeatures,
  type VoiceCloneDetectionResult,
  type VoiceAnonymizationResult,
  type VoiceSecuritySettings,
  type AnonymizationLevel,
} from './voice-privacy-protection';

// ============================================================================
// Privacy-Preserving Analytics (Differential Privacy)
// ============================================================================

export {
  DifferentialPrivacyEngine,
  dpEngine,
  SecureAggregationService,
  secureAggregation,
  SyntheticDataGenerator,
  syntheticDataGenerator,
  PrivacyAnalyticsDashboard,
  analyticsDashboard,
  type PrivacyBudget,
  type PrivateQuery,
  type PrivateQueryResult,
  type DifferentialPrivacyConfig,
} from './privacy-preserving-analytics';

// ============================================================================
// Privacy Integration (Unified API)
// ============================================================================

export {
  UnifiedPrivacyService,
  unifiedPrivacy,
  type PrivacyStatus,
  type ComprehensivePrivacyReport,
} from './privacy-integration';

// ============================================================================
// Existing Security Modules
// ============================================================================

export {
  detectAdversarialPatterns,
  type AdversarialPattern,
  type EvasionDetectionResult,
} from './adversarial-detection';

export {
  stressTests,
  runAllTests,
  type StressTestResult,
} from './stress-tests';

// ============================================================================
// Thaura AI Integration
// ============================================================================

export {
  externalAIProvider,
  multiModalProcessor,
  functionCallingFramework,
  ethicalAIVerification,
  apiGateway,
  thauraIntegration,
} from './thaura-integration';

// ============================================================================
// Unified Integration (All Systems)
// ============================================================================

export { unifiedIntegration } from './unified-integration';

// ============================================================================
// Voice Integration (Real-time Protection)
// ============================================================================

export { voiceIntegration } from './voice-integration';

// ============================================================================
// Security Module Statistics
// ============================================================================

export function getSecurityModuleStats() {
  return {
    privacyModules: {
      consentManagement: true,
      dataMinimization: true,
      purposeLimitation: true,
      supplyChainTracking: true,
      collectiveRights: true,
      voiceProtection: true,
      differentialPrivacy: true,
    },
    securityModules: {
      adversarialDetection: true,
      auditLedger: true,
      brittlenessTracking: true,
      dynamicThresholds: true,
      executionTickets: true,
      predictiveThreats: true,
    },
    integrationModules: {
      thauraAI: true,
      unifiedIntegration: true,
      voiceIntegration: true,
      privacyIntegration: true,
    },
    version: '2.0.0',
    lastUpdated: new Date().toISOString(),
    disruptionScore: 16,
  };
}
