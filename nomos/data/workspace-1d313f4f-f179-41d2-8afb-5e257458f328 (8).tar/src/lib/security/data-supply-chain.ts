/**
 * Data Supply Chain Tracker
 *
 * Inspired by Stanford HAI's recommendation for a "supply chain approach to data privacy"
 * Reference: https://hai.stanford.edu/news/privacy-ai-era-how-do-we-protect-our-personal-information
 *
 * Key Features:
 * 1. Track data lineage from input to output
 * 2. Monitor training data sources
 * 3. Detect personal information in data flows
 * 4. Trace AI outputs back to source data
 * 5. Provide transparency for regulatory compliance
 */

// ============================================================================
// Types and Interfaces
// ============================================================================

export interface DataLineageNode {
  id: string;
  type: LineageNodeType;
  timestamp: Date;
  source: string;
  metadata: Record<string, unknown>;
  checksum: string;
  parentId?: string;
  childrenIds: string[];
  transformations: DataTransformation[];
  privacyLevel: PrivacyLevel;
  piiDetected: boolean;
  piiTypes?: PIICategory[];
  consentReferences: string[];
}

export type LineageNodeType =
  | 'source_data'
  | 'ingestion'
  | 'preprocessing'
  | 'transformation'
  | 'training_data'
  | 'model_input'
  | 'model_output'
  | 'postprocessing'
  | 'final_output'
  | 'storage'
  | 'deletion';

export type PrivacyLevel =
  | 'public'
  | 'internal'
  | 'confidential'
  | 'restricted'
  | 'pii'
  | 'sensitive_pii';

export type PIICategory =
  | 'name'
  | 'email'
  | 'phone'
  | 'address'
  | 'ssn'
  | 'credit_card'
  | 'biometric'
  | 'medical'
  | 'financial'
  | 'location'
  | 'ip_address'
  | 'device_id'
  | 'date_of_birth'
  | 'national_id'
  | 'passport'
  | 'driver_license';

export interface DataTransformation {
  id: string;
  type: TransformationType;
  description: string;
  inputSchema: Record<string, unknown>;
  outputSchema: Record<string, unknown>;
  parameters: Record<string, unknown>;
  reversible: boolean;
  privacyImpact: 'none' | 'low' | 'medium' | 'high';
}

export type TransformationType =
  | 'anonymization'
  | 'pseudonymization'
  | 'encryption'
  | 'hashing'
  | 'masking'
  | 'generalization'
  | 'sampling'
  | 'aggregation'
  | 'filtering'
  | 'enrichment'
  | 'merge'
  | 'split'
  | 'format_conversion'
  | 'feature_extraction'
  | 'embedding_generation';

export interface TrainingDataSource {
  id: string;
  name: string;
  type: DataSourceType;
  url?: string;
  license?: string;
  collectionDate?: Date;
  recordCount: number;
  piiScanned: boolean;
  piiFound: boolean;
  piiRemoved: boolean;
  consentObtained: boolean;
  checksum: string;
  provenance: DataProvenance;
}

export type DataSourceType =
  | 'web_scrape'
  | 'api'
  | 'database'
  | 'file_upload'
  | 'user_generated'
  | 'third_party'
  | 'public_dataset'
  | 'synthetic';

export interface DataProvenance {
  origin: string;
  owner: string;
  collector: string;
  collectionMethod: string;
  collectionPurpose: string;
  retentionPeriod: number;
  geographicOrigin?: string;
  transferHistory: DataTransfer[];
}

export interface DataTransfer {
  id: string;
  timestamp: Date;
  from: string;
  to: string;
  purpose: string;
  legalBasis: string;
  dataCategories: string[];
  protectionMeasures: string[];
}

export interface OutputTrace {
  id: string;
  modelId: string;
  inputPrompt: string;
  outputContent: string;
  trainingDataSources: string[];
  confidenceScores: Record<string, number>;
  memorizationRisk: number;
  piiLeakRisk: number;
  timestamp: Date;
}

export interface SupplyChainAudit {
  id: string;
  timestamp: Date;
  eventType: AuditEventType;
  nodeId: string;
  userId: string;
  details: Record<string, unknown>;
  complianceFlags: ComplianceFlag[];
}

export type AuditEventType =
  | 'data_ingested'
  | 'data_transformed'
  | 'data_accessed'
  | 'data_shared'
  | 'data_deleted'
  | 'pii_detected'
  | 'pii_removed'
  | 'consent_verified'
  | 'consent_expired'
  | 'retention_exceeded'
  | 'breach_detected'
  | 'output_generated';

export interface ComplianceFlag {
  regulation: 'GDPR' | 'CCPA' | 'HIPAA' | 'SOX' | 'PCI_DSS' | 'AI_ACT';
  article?: string;
  severity: 'info' | 'warning' | 'violation';
  description: string;
  remediation?: string;
}

// ============================================================================
// Data Supply Chain Tracker
// ============================================================================

export class DataSupplyChainTracker {
  private lineageNodes: Map<string, DataLineageNode> = new Map();
  private dataSources: Map<string, TrainingDataSource> = new Map();
  private outputTraces: Map<string, OutputTrace> = new Map();
  private auditLog: SupplyChainAudit[] = [];
  private piiPatterns: Map<PIICategory, RegExp> = new Map();

  constructor() {
    this.initializePIIPatterns();
  }

  /**
   * Register a new data source in the supply chain
   */
  async registerDataSource(
    source: Omit<TrainingDataSource, 'id' | 'piiScanned' | 'piiFound' | 'piiRemoved'>
  ): Promise<TrainingDataSource> {
    const id = this.generateId('source');

    const dataSource: TrainingDataSource = {
      ...source,
      id,
      piiScanned: false,
      piiFound: false,
      piiRemoved: false,
    };

    // Scan for PII
    const piiScan = await this.scanForPII(source.recordCount, source.type);
    dataSource.piiScanned = true;
    dataSource.piiFound = piiScan.found;
    if (piiScan.found) {
      dataSource.piiRemoved = await this.removePII(id);
    }

    this.dataSources.set(id, dataSource);

    // Create lineage node
    const lineageNode: DataLineageNode = {
      id: this.generateId('node'),
      type: 'source_data',
      timestamp: new Date(),
      source: source.name,
      metadata: {
        dataSourceId: id,
        type: source.type,
        recordCount: source.recordCount,
      },
      checksum: source.checksum,
      childrenIds: [],
      transformations: [],
      privacyLevel: piiScan.found ? 'pii' : 'internal',
      piiDetected: piiScan.found,
      piiTypes: piiScan.types,
      consentReferences: source.consentObtained ? [id] : [],
    };

    this.lineageNodes.set(lineageNode.id, lineageNode);

    this.logAudit({
      id: this.generateId('audit'),
      timestamp: new Date(),
      eventType: 'data_ingested',
      nodeId: lineageNode.id,
      userId: 'system',
      details: { sourceId: id, piiScan },
      complianceFlags: this.checkCompliance(dataSource),
    });

    return dataSource;
  }

  /**
   * Track data transformation in the supply chain
   */
  async trackTransformation(
    parentId: string,
    transformation: DataTransformation
  ): Promise<DataLineageNode> {
    const parent = this.lineageNodes.get(parentId);
    if (!parent) {
      throw new Error(`Parent node not found: ${parentId}`);
    }

    const node: DataLineageNode = {
      id: this.generateId('node'),
      type: 'transformation',
      timestamp: new Date(),
      source: parent.source,
      metadata: {
        transformationType: transformation.type,
        privacyImpact: transformation.privacyImpact,
      },
      checksum: this.calculateChecksum({ parent, transformation }),
      parentId,
      childrenIds: [],
      transformations: [...parent.transformations, transformation],
      privacyLevel: this.calculatePrivacyLevel(parent.privacyLevel, transformation),
      piiDetected: parent.piiDetected && transformation.privacyImpact !== 'none',
      consentReferences: parent.consentReferences,
    };

    // Update parent's children
    parent.childrenIds.push(node.id);

    this.lineageNodes.set(node.id, node);

    this.logAudit({
      id: this.generateId('audit'),
      timestamp: new Date(),
      eventType: 'data_transformed',
      nodeId: node.id,
      userId: 'system',
      details: { transformation },
      complianceFlags: [],
    });

    return node;
  }

  /**
   * Trace output back to training data sources
   * Critical for AI transparency and right to explanation
   */
  async traceOutput(outputId: string): Promise<{
    sources: TrainingDataSource[];
    transformations: DataTransformation[];
    lineage: DataLineageNode[];
    risks: {
      memorization: number;
      piiLeak: number;
      attribution: string[];
    };
  }> {
    const trace = this.outputTraces.get(outputId);
    if (!trace) {
      throw new Error(`Output trace not found: ${outputId}`);
    }

    // Get source data
    const sources: TrainingDataSource[] = [];
    for (const sourceId of trace.trainingDataSources) {
      const source = this.dataSources.get(sourceId);
      if (source) {
        sources.push(source);
      }
    }

    // Build lineage chain
    const lineage: DataLineageNode[] = [];
    for (const node of this.lineageNodes.values()) {
      if (
        trace.trainingDataSources.some((s) =>
          node.metadata['dataSourceId'] === s ||
          node.source === s
        )
      ) {
        lineage.push(node);
      }
    }

    // Get all transformations
    const transformations: DataTransformation[] = [];
    for (const node of lineage) {
      transformations.push(...node.transformations);
    }

    return {
      sources,
      transformations,
      lineage,
      risks: {
        memorization: trace.memorizationRisk,
        piiLeak: trace.piiLeakRisk,
        attribution: this.calculateAttribution(sources),
      },
    };
  }

  /**
   * Check if output contains memorized training data
   * Prevents training data extraction attacks
   */
  async checkMemorizationRisk(
    output: string,
    trainingDataSample: string[]
  ): Promise<{ risk: number; matches: string[] }> {
    const matches: string[] = [];
    let maxSimilarity = 0;

    for (const sample of trainingDataSample) {
      const similarity = this.calculateSimilarity(output, sample);
      if (similarity > 0.8) {
        matches.push(sample.substring(0, 100) + '...');
      }
      maxSimilarity = Math.max(maxSimilarity, similarity);
    }

    return { risk: maxSimilarity, matches };
  }

  /**
   * Generate data lineage report for compliance
   */
  async generateLineageReport(
    nodeId: string
  ): Promise<{
    node: DataLineageNode;
    ancestors: DataLineageNode[];
    descendants: DataLineageNode[];
    transformations: DataTransformation[];
    complianceStatus: ComplianceFlag[];
  }> {
    const node = this.lineageNodes.get(nodeId);
    if (!node) {
      throw new Error(`Node not found: ${nodeId}`);
    }

    // Get ancestors
    const ancestors: DataLineageNode[] = [];
    let current = node;
    while (current.parentId) {
      const parent = this.lineageNodes.get(current.parentId);
      if (parent) {
        ancestors.unshift(parent);
        current = parent;
      } else {
        break;
      }
    }

    // Get descendants
    const descendants = this.getDescendants(node);

    // Get all transformations
    const transformations = [
      ...ancestors.flatMap((a) => a.transformations),
      ...node.transformations,
      ...descendants.flatMap((d) => d.transformations),
    ];

    // Check compliance
    const complianceStatus: ComplianceFlag[] = [];

    // GDPR compliance checks
    if (node.piiDetected) {
      if (node.consentReferences.length === 0) {
        complianceStatus.push({
          regulation: 'GDPR',
          article: 'Article 6',
          severity: 'violation',
          description: 'PII present without valid consent',
          remediation: 'Obtain explicit consent or remove PII',
        });
      }
    }

    // Check retention
    const age = Date.now() - node.timestamp.getTime();
    const maxRetention = 365 * 24 * 60 * 60 * 1000; // 1 year
    if (age > maxRetention) {
      complianceStatus.push({
        regulation: 'GDPR',
        article: 'Article 5(1)(e)',
        severity: 'warning',
        description: 'Data may exceed retention period',
        remediation: 'Review retention policy and delete if necessary',
      });
    }

    return {
      node,
      ancestors,
      descendants,
      transformations,
      complianceStatus,
    };
  }

  /**
   * Record an output trace for AI transparency
   */
  async recordOutputTrace(
    modelId: string,
    inputPrompt: string,
    outputContent: string,
    trainingDataSources: string[]
  ): Promise<OutputTrace> {
    const id = this.generateId('output');

    // Calculate risks
    const memorizationRisk = await this.calculateMemorizationRiskScore(outputContent);
    const piiLeakRisk = await this.calculatePIILeakRisk(outputContent);

    const trace: OutputTrace = {
      id,
      modelId,
      inputPrompt,
      outputContent,
      trainingDataSources,
      confidenceScores: {},
      memorizationRisk,
      piiLeakRisk,
      timestamp: new Date(),
    };

    this.outputTraces.set(id, trace);

    // Check for compliance issues
    if (piiLeakRisk > 0.5) {
      this.logAudit({
        id: this.generateId('audit'),
        timestamp: new Date(),
        eventType: 'pii_detected',
        nodeId: id,
        userId: 'system',
        details: { piiLeakRisk, outputId: id },
        complianceFlags: [
          {
            regulation: 'GDPR',
            article: 'Article 5(1)(f)',
            severity: 'violation',
            description: 'Potential PII leak in AI output',
            remediation: 'Review output and apply filtering',
          },
        ],
      });
    }

    return trace;
  }

  /**
   * Delete data and all associated records
   * Implements right to erasure (GDPR Article 17)
   */
  async deleteData(nodeId: string, userId: string): Promise<boolean> {
    const node = this.lineageNodes.get(nodeId);
    if (!node) {
      return false;
    }

    // Check if user has right to delete
    // In production, verify ownership or consent

    // Delete node and descendants
    const toDelete = [nodeId, ...this.getDescendantIds(node)];

    for (const id of toDelete) {
      this.lineageNodes.delete(id);
    }

    this.logAudit({
      id: this.generateId('audit'),
      timestamp: new Date(),
      eventType: 'data_deleted',
      nodeId,
      userId,
      details: { deletedCount: toDelete.length, deletedIds: toDelete },
      complianceFlags: [],
    });

    return true;
  }

  // Private methods

  private initializePIIPatterns(): void {
    this.piiPatterns.set('email', /^[^\s@]+@[^\s@]+\.[^\s@]+$/);
    this.piiPatterns.set('phone', /^\+?[\d\s\-()]{10,}$/);
    this.piiPatterns.set('ssn', /^\d{3}-\d{2}-\d{4}$/);
    this.piiPatterns.set('credit_card', /^\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}$/);
    this.piiPatterns.set('ip_address', /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/);
    this.piiPatterns.set('date_of_birth', /^\d{2}\/\d{2}\/\d{4}$/);
  }

  private async scanForPII(
    recordCount: number,
    _sourceType: DataSourceType
  ): Promise<{ found: boolean; types: PIICategory[] }> {
    const types: PIICategory[] = [];

    // Simulate PII scanning
    // In production, use actual PII detection
    if (recordCount > 1000) {
      // Larger datasets more likely to contain PII
      types.push('email', 'name');
    }

    return { found: types.length > 0, types };
  }

  private async removePII(sourceId: string): Promise<boolean> {
    // In production, implement actual PII removal
    console.log(`Removing PII from source: ${sourceId}`);
    return true;
  }

  private checkCompliance(source: TrainingDataSource): ComplianceFlag[] {
    const flags: ComplianceFlag[] = [];

    if (source.piiFound && !source.consentObtained) {
      flags.push({
        regulation: 'GDPR',
        article: 'Article 6',
        severity: 'warning',
        description: 'PII detected without explicit consent',
        remediation: 'Obtain consent or remove PII before processing',
      });
    }

    if (!source.license) {
      flags.push({
        regulation: 'AI_ACT',
        severity: 'info',
        description: 'Data source license not specified',
        remediation: 'Document license terms for transparency',
      });
    }

    return flags;
  }

  private calculatePrivacyLevel(
    current: PrivacyLevel,
    transformation: DataTransformation
  ): PrivacyLevel {
    if (transformation.type === 'anonymization') {
      return 'internal';
    }
    if (transformation.type === 'pseudonymization') {
      return 'confidential';
    }
    if (transformation.privacyImpact === 'high') {
      return 'restricted';
    }
    return current;
  }

  private calculateChecksum(data: unknown): string {
    const str = JSON.stringify(data);
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash = hash & hash;
    }
    return `sha256_${Math.abs(hash).toString(16)}`;
  }

  private calculateSimilarity(text1: string, text2: string): number {
    // Simple Jaccard similarity
    const words1 = new Set(text1.toLowerCase().split(/\s+/));
    const words2 = new Set(text2.toLowerCase().split(/\s+/));
    const intersection = new Set([...words1].filter((x) => words2.has(x)));
    const union = new Set([...words1, ...words2]);
    return intersection.size / union.size;
  }

  private calculateAttribution(sources: TrainingDataSource[]): string[] {
    return sources.map((s) => s.name);
  }

  private async calculateMemorizationRiskScore(output: string): Promise<number> {
    // Check for exact phrases that might indicate memorization
    const suspiciousPatterns = [
      /password\s*[:=]/i,
      /api[_-]?key\s*[:=]/i,
      /secret\s*[:=]/i,
      /\d{3}-\d{2}-\d{4}/, // SSN
      /\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}/, // Credit card
    ];

    let risk = 0;
    for (const pattern of suspiciousPatterns) {
      if (pattern.test(output)) {
        risk += 0.2;
      }
    }

    return Math.min(risk, 1);
  }

  private async calculatePIILeakRisk(output: string): Promise<number> {
    let risk = 0;

    for (const [type, pattern] of this.piiPatterns) {
      if (pattern.test(output)) {
        risk += 0.25;
        console.log(`PII detected: ${type}`);
      }
    }

    return Math.min(risk, 1);
  }

  private getDescendants(node: DataLineageNode): DataLineageNode[] {
    const descendants: DataLineageNode[] = [];
    for (const childId of node.childrenIds) {
      const child = this.lineageNodes.get(childId);
      if (child) {
        descendants.push(child, ...this.getDescendants(child));
      }
    }
    return descendants;
  }

  private getDescendantIds(node: DataLineageNode): string[] {
    const ids: string[] = [];
    for (const childId of node.childrenIds) {
      ids.push(childId);
      const child = this.lineageNodes.get(childId);
      if (child) {
        ids.push(...this.getDescendantIds(child));
      }
    }
    return ids;
  }

  private logAudit(audit: SupplyChainAudit): void {
    this.auditLog.push(audit);
  }

  private generateId(prefix: string): string {
    return `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  // Getters

  getLineageNode(id: string): DataLineageNode | undefined {
    return this.lineageNodes.get(id);
  }

  getDataSource(id: string): TrainingDataSource | undefined {
    return this.dataSources.get(id);
  }

  getOutputTrace(id: string): OutputTrace | undefined {
    return this.outputTraces.get(id);
  }

  getAuditLog(nodeId?: string): SupplyChainAudit[] {
    if (nodeId) {
      return this.auditLog.filter((a) => a.nodeId === nodeId);
    }
    return [...this.auditLog];
  }

  getAllDataSources(): TrainingDataSource[] {
    return Array.from(this.dataSources.values());
  }
}

// ============================================================================
// Training Data Transparency Report Generator
// ============================================================================

export class TrainingDataTransparencyReport {
  private tracker: DataSupplyChainTracker;

  constructor(tracker: DataSupplyChainTracker) {
    this.tracker = tracker;
  }

  /**
   * Generate a comprehensive transparency report
   * Required for AI Act compliance and ethical AI practices
   */
  async generateReport(modelId: string): Promise<{
    summary: {
      totalDataSources: number;
      totalRecords: number;
      piiDataSources: number;
      consentVerified: number;
    };
    dataSources: {
      id: string;
      name: string;
      type: string;
      recordCount: number;
      piiStatus: string;
      consent: boolean;
      license: string;
    }[];
    compliance: {
      gdpr: ComplianceFlag[];
      aiAct: ComplianceFlag[];
    };
    recommendations: string[];
  }> {
    const sources = this.tracker.getAllDataSources();

    const summary = {
      totalDataSources: sources.length,
      totalRecords: sources.reduce((sum, s) => sum + s.recordCount, 0),
      piiDataSources: sources.filter((s) => s.piiFound).length,
      consentVerified: sources.filter((s) => s.consentObtained).length,
    };

    const dataSources = sources.map((s) => ({
      id: s.id,
      name: s.name,
      type: s.type,
      recordCount: s.recordCount,
      piiStatus: s.piiFound ? (s.piiRemoved ? 'removed' : 'present') : 'none',
      consent: s.consentObtained,
      license: s.license || 'unknown',
    }));

    const compliance = {
      gdpr: this.checkGDPRCompliance(sources),
      aiAct: this.checkAIActCompliance(sources),
    };

    const recommendations = this.generateRecommendations(summary, compliance);

    return {
      summary,
      dataSources,
      compliance,
      recommendations,
    };
  }

  private checkGDPRCompliance(sources: TrainingDataSource[]): ComplianceFlag[] {
    const flags: ComplianceFlag[] = [];

    for (const source of sources) {
      if (source.piiFound && !source.consentObtained) {
        flags.push({
          regulation: 'GDPR',
          article: 'Article 6',
          severity: 'violation',
          description: `Source "${source.name}" contains PII without consent`,
          remediation: 'Obtain explicit consent or remove PII',
        });
      }

      if (source.piiFound && !source.piiRemoved) {
        flags.push({
          regulation: 'GDPR',
          article: 'Article 17',
          severity: 'warning',
          description: `Source "${source.name}" may contain PII that should be reviewed`,
          remediation: 'Implement PII removal process',
        });
      }
    }

    return flags;
  }

  private checkAIActCompliance(sources: TrainingDataSource[]): ComplianceFlag[] {
    const flags: ComplianceFlag[] = [];

    const sourcesWithoutLicense = sources.filter((s) => !s.license);
    if (sourcesWithoutLicense.length > 0) {
      flags.push({
        regulation: 'AI_ACT',
        severity: 'warning',
        description: `${sourcesWithoutLicense.length} data sources without documented license`,
        remediation: 'Document license terms for all training data sources',
      });
    }

    const sourcesWithoutProvenance = sources.filter(
      (s) => !s.provenance || !s.provenance.origin
    );
    if (sourcesWithoutProvenance.length > 0) {
      flags.push({
        regulation: 'AI_ACT',
        severity: 'info',
        description: `${sourcesWithoutProvenance.length} data sources without complete provenance`,
        remediation: 'Document data provenance for transparency',
      });
    }

    return flags;
  }

  private generateRecommendations(
    summary: { piiDataSources: number; consentVerified: number; totalDataSources: number },
    compliance: { gdpr: ComplianceFlag[]; aiAct: ComplianceFlag[] }
  ): string[] {
    const recommendations: string[] = [];

    if (summary.piiDataSources > 0) {
      recommendations.push(
        'Implement automated PII detection and removal pipeline'
      );
    }

    if (summary.consentVerified < summary.totalDataSources) {
      recommendations.push(
        'Obtain explicit consent for all data sources containing personal information'
      );
    }

    const violations = compliance.gdpr.filter((f) => f.severity === 'violation');
    if (violations.length > 0) {
      recommendations.push(
        'URGENT: Address GDPR violations before deploying AI system'
      );
    }

    return recommendations;
  }
}

// ============================================================================
// Export
// ============================================================================

export const dataSupplyChain = new DataSupplyChainTracker();
export const transparencyReport = new TrainingDataTransparencyReport(dataSupplyChain);
