/**
 * API Gateway and Marketplace
 * Unified gateway for multiple AI providers with rate limiting and billing
 * 
 * Features:
 * - Multi-provider aggregation
 * - Intelligent routing and load balancing
 * - Rate limiting per provider and user
 * - Usage tracking and billing
 * - API key management
 * - Streaming support
 * - Request caching
 * - Failover and redundancy
 * 
 * @module APIGateway
 * @version 1.0.0
 * @author Kasbah Security Team
 */

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

import { AIProvider, CompletionRequest, CompletionResponse } from './external-ai-provider';

/**
 * Gateway configuration
 */
export interface GatewayConfig {
  name: string;
  version: string;
  defaultProvider: AIProvider;
  fallbackProviders: AIProvider[];
  rateLimitWindowMs: number;
  defaultRateLimit: number;
  enableCaching: boolean;
  cacheTTL: number;
  enableBilling: boolean;
  enableStreaming: boolean;
  maxRequestSize: number;
  timeout: number;
}

/**
 * API key structure
 */
export interface APIKey {
  id: string;
  key: string;
  prefix: string;
  userId: string;
  name: string;
  scopes: APIScope[];
  rateLimit: number;
  usageLimit?: number;
  currentUsage: number;
  createdAt: Date;
  expiresAt?: Date;
  lastUsed?: Date;
  isActive: boolean;
  metadata: Record<string, unknown>;
}

/**
 * API scope
 */
export type APIScope =
  | 'chat:read'
  | 'chat:write'
  | 'analysis:read'
  | 'analysis:write'
  | 'admin:read'
  | 'admin:write'
  | 'billing:read'
  | 'billing:write';

/**
 * Rate limit status
 */
export interface RateLimitStatus {
  limit: number;
  remaining: number;
  resetAt: Date;
  retryAfter?: number;
}

/**
 * Usage record
 */
export interface GatewayUsageRecord {
  id: string;
  apiKeyId: string;
  userId: string;
  provider: AIProvider;
  endpoint: string;
  method: string;
  requestSize: number;
  responseSize: number;
  tokensUsed: number;
  latencyMs: number;
  statusCode: number;
  success: boolean;
  cached: boolean;
  timestamp: Date;
  cost: number;
  metadata: Record<string, unknown>;
}

/**
 * Billing tier
 */
export interface BillingTier {
  id: string;
  name: string;
  description: string;
  monthlyPrice: number;
  includedTokens: number;
  pricePerInputToken: number;
  pricePerOutputToken: number;
  rateLimit: number;
  features: string[];
}

/**
 * Billing account
 */
export interface BillingAccount {
  id: string;
  userId: string;
  tier: BillingTier;
  balance: number;
  usedTokens: number;
  billingCycleStart: Date;
  billingCycleEnd: Date;
  autoRecharge: boolean;
  autoRechargeAmount?: number;
  autoRechargeThreshold?: number;
  paymentMethodId?: string;
  invoices: Invoice[];
}

/**
 * Invoice
 */
export interface Invoice {
  id: string;
  accountId: string;
  period: { start: Date; end: Date };
  amount: number;
  tokensUsed: number;
  status: 'pending' | 'paid' | 'overdue' | 'cancelled';
  dueDate: Date;
  paidAt?: Date;
  items: InvoiceItem[];
}

/**
 * Invoice item
 */
export interface InvoiceItem {
  description: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

/**
 * Provider health
 */
export interface ProviderHealthStatus {
  provider: AIProvider;
  status: 'healthy' | 'degraded' | 'down';
  latency: number;
  successRate: number;
  lastCheck: Date;
  consecutiveFailures: number;
  lastError?: string;
}

/**
 * Routing decision
 */
export interface RoutingDecision {
  selectedProvider: AIProvider;
  fallbackProviders: AIProvider[];
  reason: string;
  estimatedLatency: number;
  costEstimate: number;
}

/**
 * Cache entry
 */
export interface GatewayCacheEntry {
  key: string;
  response: CompletionResponse;
  timestamp: Date;
  ttl: number;
  hits: number;
  provider: AIProvider;
}

/**
 * Gateway request
 */
export interface GatewayRequest {
  id: string;
  apiKeyId: string;
  userId: string;
  provider?: AIProvider;
  endpoint: string;
  method: string;
  body: unknown;
  headers: Record<string, string>;
  timestamp: Date;
  metadata: Record<string, unknown>;
}

/**
 * Gateway response
 */
export interface GatewayResponse {
  id: string;
  requestId: string;
  statusCode: number;
  body: unknown;
  headers: Record<string, string>;
  provider: AIProvider;
  latencyMs: number;
  cached: boolean;
  tokensUsed: number;
  cost: number;
}

// ============================================================================
// DEFAULT CONFIGURATION
// ============================================================================

/**
 * Default gateway configuration
 */
export const DEFAULT_GATEWAY_CONFIG: GatewayConfig = {
  name: 'Kasbah API Gateway',
  version: '1.0.0',
  defaultProvider: 'thaura',
  fallbackProviders: ['openai', 'anthropic', 'local'],
  rateLimitWindowMs: 60000, // 1 minute
  defaultRateLimit: 60, // 60 requests per minute
  enableCaching: true,
  cacheTTL: 300000, // 5 minutes
  enableBilling: true,
  enableStreaming: true,
  maxRequestSize: 50 * 1024 * 1024, // 50MB
  timeout: 120000, // 2 minutes
};

/**
 * Available billing tiers
 */
export const BILLING_TIERS: BillingTier[] = [
  {
    id: 'free',
    name: 'Free Tier',
    description: 'Get started with basic AI capabilities',
    monthlyPrice: 0,
    includedTokens: 100000,
    pricePerInputToken: 0.0000005,
    pricePerOutputToken: 0.000002,
    rateLimit: 20,
    features: ['Basic chat', 'Image analysis', 'Community support'],
  },
  {
    id: 'starter',
    name: 'Starter',
    description: 'For individuals and small projects',
    monthlyPrice: 10,
    includedTokens: 1000000,
    pricePerInputToken: 0.0000004,
    pricePerOutputToken: 0.0000016,
    rateLimit: 60,
    features: ['All Free features', 'Video analysis', 'Audio analysis', 'Priority support', 'API access'],
  },
  {
    id: 'professional',
    name: 'Professional',
    description: 'For teams and businesses',
    monthlyPrice: 50,
    includedTokens: 10000000,
    pricePerInputToken: 0.0000003,
    pricePerOutputToken: 0.0000012,
    rateLimit: 300,
    features: [
      'All Starter features',
      'Batch processing',
      'Custom models',
      'Advanced analytics',
      'Dedicated support',
      'SLA guarantee',
    ],
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    description: 'For large-scale deployments',
    monthlyPrice: 200,
    includedTokens: 100000000,
    pricePerInputToken: 0.0000002,
    pricePerOutputToken: 0.0000008,
    rateLimit: 1000,
    features: [
      'All Professional features',
      'Unlimited tokens',
      'Custom integrations',
      'On-premise deployment',
      '24/7 support',
      'Dedicated account manager',
    ],
  },
];

// ============================================================================
// API GATEWAY CLASS
// ============================================================================

/**
 * API Gateway and Marketplace
 */
export class APIGateway {
  private config: GatewayConfig;
  private apiKeys: Map<string, APIKey> = new Map();
  private rateLimiters: Map<string, RateLimiter> = new Map();
  private providerHealth: Map<AIProvider, ProviderHealthStatus> = new Map();
  private cache: Map<string, GatewayCacheEntry> = new Map();
  private usageRecords: GatewayUsageRecord[] = [];
  private billingAccounts: Map<string, BillingAccount> = new Map();
  private pendingRequests: Map<string, GatewayRequest> = new Map();

  constructor(config: Partial<GatewayConfig> = {}) {
    this.config = { ...DEFAULT_GATEWAY_CONFIG, ...config };
    this.initializeProviderHealth();
  }

  /**
   * Process a gateway request
   */
  async processRequest(request: GatewayRequest): Promise<GatewayResponse> {
    const startTime = Date.now();

    // Validate API key
    const apiKey = this.validateAPIKey(request.apiKeyId);
    if (!apiKey) {
      return this.createErrorResponse(request, 401, 'Invalid API key');
    }

    // Check rate limit
    const rateLimitStatus = this.checkRateLimit(request.apiKeyId);
    if (!rateLimitStatus) {
      return this.createErrorResponse(request, 429, 'Rate limit exceeded');
    }

    // Check usage limit
    if (apiKey.usageLimit && apiKey.currentUsage >= apiKey.usageLimit) {
      return this.createErrorResponse(request, 402, 'Usage limit exceeded');
    }

    // Check billing if enabled
    if (this.config.enableBilling) {
      const billingCheck = await this.checkBilling(apiKey.userId);
      if (!billingCheck.valid) {
        return this.createErrorResponse(request, 402, billingCheck.reason);
      }
    }

    // Route to appropriate provider
    const routing = this.routeRequest(request);

    // Check cache
    if (this.config.enableCaching) {
      const cacheKey = this.getCacheKey(request);
      const cached = this.cache.get(cacheKey);
      if (cached && Date.now() - cached.timestamp.getTime() < cached.ttl) {
        cached.hits++;
        return {
          id: `resp-${Date.now()}`,
          requestId: request.id,
          statusCode: 200,
          body: cached.response,
          headers: { 'X-Cache': 'HIT' },
          provider: cached.provider,
          latencyMs: Date.now() - startTime,
          cached: true,
          tokensUsed: cached.response.usage?.totalTokens || 0,
          cost: 0, // No cost for cached responses
        };
      }
    }

    // Execute request
    try {
      const response = await this.executeWithProvider(request, routing.selectedProvider);
      const latencyMs = Date.now() - startTime;

      // Record usage
      this.recordUsage({
        apiKeyId: request.apiKeyId,
        userId: request.userId,
        provider: routing.selectedProvider,
        endpoint: request.endpoint,
        method: request.method,
        requestSize: JSON.stringify(request.body).length,
        responseSize: JSON.stringify(response.body).length,
        tokensUsed: (response.body as CompletionResponse)?.usage?.totalTokens || 0,
        latencyMs,
        statusCode: response.statusCode,
        success: response.statusCode < 400,
        cached: false,
        cost: this.calculateCost(routing.selectedProvider, response),
        metadata: {},
      });

      // Update API key usage
      apiKey.currentUsage++;
      apiKey.lastUsed = new Date();

      // Cache response if enabled
      if (this.config.enableCaching && response.statusCode === 200) {
        const cacheKey = this.getCacheKey(request);
        this.cache.set(cacheKey, {
          key: cacheKey,
          response: response.body as CompletionResponse,
          timestamp: new Date(),
          ttl: this.config.cacheTTL,
          hits: 0,
          provider: routing.selectedProvider,
        });
      }

      return response;
    } catch (error) {
      // Try fallback providers
      for (const fallback of routing.fallbackProviders) {
        try {
          return await this.executeWithProvider(request, fallback);
        } catch {
          continue;
        }
      }

      return this.createErrorResponse(
        request,
        500,
        error instanceof Error ? error.message : 'Internal server error'
      );
    }
  }

  /**
   * Create a new API key
   */
  createAPIKey(
    userId: string,
    name: string,
    scopes: APIScope[],
    options: {
      rateLimit?: number;
      usageLimit?: number;
      expiresIn?: number;
    } = {}
  ): APIKey {
    const id = `key-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const key = `kb_${this.generateRandomString(32)}`;
    const prefix = key.slice(0, 12);

    const apiKey: APIKey = {
      id,
      key,
      prefix,
      userId,
      name,
      scopes,
      rateLimit: options.rateLimit || this.config.defaultRateLimit,
      usageLimit: options.usageLimit,
      currentUsage: 0,
      createdAt: new Date(),
      expiresAt: options.expiresIn ? new Date(Date.now() + options.expiresIn) : undefined,
      isActive: true,
      metadata: {},
    };

    this.apiKeys.set(key, apiKey);
    this.rateLimiters.set(key, new RateLimiter(apiKey.rateLimit, this.config.rateLimitWindowMs));

    return apiKey;
  }

  /**
   * Revoke an API key
   */
  revokeAPIKey(keyId: string): boolean {
    for (const [key, apiKey] of this.apiKeys) {
      if (apiKey.id === keyId) {
        apiKey.isActive = false;
        return true;
      }
    }
    return false;
  }

  /**
   * Get API key info
   */
  getAPIKeyInfo(keyId: string): APIKey | undefined {
    for (const apiKey of this.apiKeys.values()) {
      if (apiKey.id === keyId) {
        return apiKey;
      }
    }
    return undefined;
  }

  /**
   * List API keys for a user
   */
  listAPIKeys(userId: string): APIKey[] {
    return Array.from(this.apiKeys.values())
      .filter((key) => key.userId === userId)
      .map((key) => ({ ...key, key: '***' + key.prefix.slice(-4) })); // Mask full key
  }

  /**
   * Get rate limit status for an API key
   */
  getRateLimitStatus(apiKeyId: string): RateLimitStatus | undefined {
    const apiKey = this.getAPIKeyInfo(apiKeyId);
    const limiter = this.rateLimiters.get(apiKey?.key || '');

    if (!limiter || !apiKey) return undefined;

    const status = limiter.getStatus();
    return {
      limit: apiKey.rateLimit,
      remaining: status.remaining,
      resetAt: new Date(Date.now() + status.resetIn),
      retryAfter: status.remaining === 0 ? status.resetIn : undefined,
    };
  }

  /**
   * Get usage statistics
   */
  getUsageStats(
    userId?: string,
    options: {
      startDate?: Date;
      endDate?: Date;
      provider?: AIProvider;
    } = {}
  ): {
    totalRequests: number;
    totalTokens: number;
    totalCost: number;
    avgLatency: number;
    successRate: number;
    byProvider: Record<AIProvider, { requests: number; tokens: number; cost: number }>;
    byEndpoint: Record<string, { requests: number; tokens: number }>;
  } {
    let records = this.usageRecords;

    if (userId) {
      records = records.filter((r) => r.userId === userId);
    }
    if (options.startDate) {
      records = records.filter((r) => r.timestamp >= options.startDate!);
    }
    if (options.endDate) {
      records = records.filter((r) => r.timestamp <= options.endDate!);
    }
    if (options.provider) {
      records = records.filter((r) => r.provider === options.provider);
    }

    const totalRequests = records.length;
    const totalTokens = records.reduce((sum, r) => sum + r.tokensUsed, 0);
    const totalCost = records.reduce((sum, r) => sum + r.cost, 0);
    const avgLatency =
      totalRequests > 0 ? records.reduce((sum, r) => sum + r.latencyMs, 0) / totalRequests : 0;
    const successRate =
      totalRequests > 0 ? records.filter((r) => r.success).length / totalRequests : 0;

    const byProvider: Record<string, { requests: number; tokens: number; cost: number }> = {};
    const byEndpoint: Record<string, { requests: number; tokens: number }> = {};

    for (const record of records) {
      if (!byProvider[record.provider]) {
        byProvider[record.provider] = { requests: 0, tokens: 0, cost: 0 };
      }
      byProvider[record.provider].requests++;
      byProvider[record.provider].tokens += record.tokensUsed;
      byProvider[record.provider].cost += record.cost;

      if (!byEndpoint[record.endpoint]) {
        byEndpoint[record.endpoint] = { requests: 0, tokens: 0 };
      }
      byEndpoint[record.endpoint].requests++;
      byEndpoint[record.endpoint].tokens += record.tokensUsed;
    }

    return {
      totalRequests,
      totalTokens,
      totalCost,
      avgLatency,
      successRate,
      byProvider: byProvider as Record<AIProvider, { requests: number; tokens: number; cost: number }>,
      byEndpoint,
    };
  }

  /**
   * Get billing account
   */
  getBillingAccount(userId: string): BillingAccount | undefined {
    return this.billingAccounts.get(userId);
  }

  /**
   * Create or update billing account
   */
  setBillingAccount(userId: string, tierId: string): BillingAccount {
    const tier = BILLING_TIERS.find((t) => t.id === tierId) || BILLING_TIERS[0];
    const now = new Date();

    const account: BillingAccount = {
      id: `billing-${userId}`,
      userId,
      tier,
      balance: 0,
      usedTokens: 0,
      billingCycleStart: now,
      billingCycleEnd: new Date(now.getFullYear(), now.getMonth() + 1, 1),
      autoRecharge: false,
      invoices: [],
    };

    this.billingAccounts.set(userId, account);
    return account;
  }

  /**
   * Add balance to account
   */
  addBalance(userId: string, amount: number): void {
    const account = this.billingAccounts.get(userId);
    if (account) {
      account.balance += amount;
    }
  }

  /**
   * Get provider health status
   */
  getProviderHealth(): Map<AIProvider, ProviderHealthStatus> {
    return new Map(this.providerHealth);
  }

  /**
   * Clear cache
   */
  clearCache(): void {
    this.cache.clear();
  }

  /**
   * Get gateway metrics
   */
  getMetrics(): {
    totalAPIKeys: number;
    activeAPIKeys: number;
    totalRequests: number;
    cacheHitRate: number;
    avgLatency: number;
    providerHealth: Record<AIProvider, string>;
  } {
    const activeKeys = Array.from(this.apiKeys.values()).filter((k) => k.isActive).length;
    const cacheHits = Array.from(this.cache.values()).reduce((sum, e) => sum + e.hits, 0);
    const totalRequests = this.usageRecords.length;
    const avgLatency =
      totalRequests > 0
        ? this.usageRecords.reduce((sum, r) => sum + r.latencyMs, 0) / totalRequests
        : 0;

    const providerHealth: Record<string, string> = {};
    for (const [provider, health] of this.providerHealth) {
      providerHealth[provider] = health.status;
    }

    return {
      totalAPIKeys: this.apiKeys.size,
      activeAPIKeys: activeKeys,
      totalRequests,
      cacheHitRate: totalRequests > 0 ? cacheHits / totalRequests : 0,
      avgLatency,
      providerHealth: providerHealth as Record<AIProvider, string>,
    };
  }

  // ============================================================================
  // PRIVATE METHODS
  // ============================================================================

  private initializeProviderHealth(): void {
    const providers: AIProvider[] = ['thaura', 'openai', 'anthropic', 'local'];

    for (const provider of providers) {
      this.providerHealth.set(provider, {
        provider,
        status: 'healthy',
        latency: 0,
        successRate: 1,
        lastCheck: new Date(),
        consecutiveFailures: 0,
      });
    }
  }

  private validateAPIKey(keyOrId: string): APIKey | null {
    // Try to find by full key
    const byKey = this.apiKeys.get(keyOrId);
    if (byKey && byKey.isActive) {
      if (byKey.expiresAt && byKey.expiresAt < new Date()) {
        return null;
      }
      return byKey;
    }

    // Try to find by ID
    for (const apiKey of this.apiKeys.values()) {
      if (apiKey.id === keyOrId && apiKey.isActive) {
        if (apiKey.expiresAt && apiKey.expiresAt < new Date()) {
          return null;
        }
        return apiKey;
      }
    }

    return null;
  }

  private checkRateLimit(apiKeyId: string): boolean {
    const apiKey = this.getAPIKeyInfo(apiKeyId);
    if (!apiKey) return false;

    const limiter = this.rateLimiters.get(apiKey.key);
    if (!limiter) return false;

    if (!limiter.canMakeRequest()) {
      return false;
    }

    limiter.recordRequest();
    return true;
  }

  private async checkBilling(userId: string): Promise<{ valid: boolean; reason: string }> {
    const account = this.billingAccounts.get(userId);

    if (!account) {
      return { valid: false, reason: 'No billing account found' };
    }

    if (account.balance <= 0 && account.usedTokens >= account.tier.includedTokens) {
      return { valid: false, reason: 'Insufficient balance' };
    }

    return { valid: true, reason: '' };
  }

  private routeRequest(request: GatewayRequest): RoutingDecision {
    // If specific provider requested, use that
    if (request.provider) {
      const health = this.providerHealth.get(request.provider);
      if (health?.status === 'healthy') {
        return {
          selectedProvider: request.provider,
          fallbackProviders: this.config.fallbackProviders,
          reason: 'User-specified provider',
          estimatedLatency: health.latency,
          costEstimate: 0,
        };
      }
    }

    // Select best available provider
    const providers = [this.config.defaultProvider, ...this.config.fallbackProviders];

    for (const provider of providers) {
      const health = this.providerHealth.get(provider);
      if (health?.status === 'healthy') {
        return {
          selectedProvider: provider,
          fallbackProviders: providers.filter((p) => p !== provider),
          reason: 'Health-based routing',
          estimatedLatency: health.latency,
          costEstimate: 0,
        };
      }
    }

    // Fallback to default even if degraded
    return {
      selectedProvider: this.config.defaultProvider,
      fallbackProviders: this.config.fallbackProviders,
      reason: 'Default fallback',
      estimatedLatency: 0,
      costEstimate: 0,
    };
  }

  private async executeWithProvider(
    request: GatewayRequest,
    provider: AIProvider
  ): Promise<GatewayResponse> {
    const startTime = Date.now();

    // Simulate provider execution
    // In real implementation, this would call the actual provider API
    const response: CompletionResponse = {
      id: `chatcmpl-${Date.now()}`,
      object: 'chat.completion',
      created: Date.now(),
      model: 'thaura',
      choices: [
        {
          index: 0,
          message: {
            role: 'assistant',
            content: 'This is a simulated response from the AI provider.',
          },
          finishReason: 'stop',
        },
      ],
      usage: {
        promptTokens: 50,
        completionTokens: 30,
        totalTokens: 80,
      },
    };

    const latencyMs = Date.now() - startTime;

    // Update provider health
    this.updateProviderHealth(provider, true, latencyMs);

    return {
      id: `resp-${Date.now()}`,
      requestId: request.id,
      statusCode: 200,
      body: response,
      headers: {
        'X-Provider': provider,
        'X-Request-Id': request.id,
      },
      provider,
      latencyMs,
      cached: false,
      tokensUsed: response.usage.totalTokens,
      cost: this.calculateCost(provider, { statusCode: 200, body: response }),
    };
  }

  private updateProviderHealth(provider: AIProvider, success: boolean, latency: number): void {
    const current = this.providerHealth.get(provider) || {
      provider,
      status: 'healthy' as const,
      latency: 0,
      successRate: 1,
      lastCheck: new Date(),
      consecutiveFailures: 0,
    };

    const consecutiveFailures = success ? 0 : current.consecutiveFailures + 1;

    let status: 'healthy' | 'degraded' | 'down';
    if (consecutiveFailures >= 5) {
      status = 'down';
    } else if (consecutiveFailures >= 2 || latency > 5000) {
      status = 'degraded';
    } else {
      status = 'healthy';
    }

    this.providerHealth.set(provider, {
      provider,
      status,
      latency: (current.latency * 0.8 + latency * 0.2), // Exponential moving average
      successRate: success
        ? Math.min(1, current.successRate + 0.01)
        : Math.max(0, current.successRate - 0.05),
      lastCheck: new Date(),
      consecutiveFailures,
    });
  }

  private calculateCost(
    provider: AIProvider,
    response: { statusCode: number; body: unknown }
  ): number {
    const usage = (response.body as CompletionResponse)?.usage;
    if (!usage) return 0;

    // Pricing per provider (simplified)
    const pricing: Record<AIProvider, { input: number; output: number }> = {
      thaura: { input: 0.0000005, output: 0.000002 },
      openai: { input: 0.0000025, output: 0.00001 },
      anthropic: { input: 0.000003, output: 0.000015 },
      local: { input: 0, output: 0 },
      custom: { input: 0.000001, output: 0.000004 },
    };

    const providerPricing = pricing[provider] || pricing.custom;
    return (
      usage.promptTokens * providerPricing.input +
      usage.completionTokens * providerPricing.output
    );
  }

  private recordUsage(record: Omit<GatewayUsageRecord, 'id' | 'timestamp'>): void {
    const usageRecord: GatewayUsageRecord = {
      id: `usage-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      ...record,
      timestamp: new Date(),
    };

    this.usageRecords.push(usageRecord);

    // Keep only last 100000 records
    if (this.usageRecords.length > 100000) {
      this.usageRecords = this.usageRecords.slice(-100000);
    }

    // Update billing account
    const account = this.billingAccounts.get(record.userId);
    if (account) {
      account.usedTokens += record.tokensUsed;
      account.balance -= record.cost;
    }
  }

  private getCacheKey(request: GatewayRequest): string {
    const bodyHash = this.hashString(JSON.stringify(request.body));
    return `${request.endpoint}:${bodyHash}`;
  }

  private hashString(str: string): string {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash = hash & hash;
    }
    return hash.toString(16);
  }

  private generateRandomString(length: number): string {
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }

  private createErrorResponse(
    request: GatewayRequest,
    statusCode: number,
    message: string
  ): GatewayResponse {
    return {
      id: `resp-${Date.now()}`,
      requestId: request.id,
      statusCode,
      body: { error: message },
      headers: {
        'X-Request-Id': request.id,
      },
      provider: request.provider || this.config.defaultProvider,
      latencyMs: 0,
      cached: false,
      tokensUsed: 0,
      cost: 0,
    };
  }
}

// ============================================================================
// RATE LIMITER
// ============================================================================

class RateLimiter {
  private requests: number[] = [];
  private maxRequests: number;
  private windowMs: number;

  constructor(maxRequests: number, windowMs: number) {
    this.maxRequests = maxRequests;
    this.windowMs = windowMs;
  }

  canMakeRequest(): boolean {
    const now = Date.now();
    this.requests = this.requests.filter((time) => time > now - this.windowMs);
    return this.requests.length < this.maxRequests;
  }

  recordRequest(): void {
    this.requests.push(Date.now());
  }

  getStatus(): { remaining: number; resetIn: number } {
    const now = Date.now();
    this.requests = this.requests.filter((time) => time > now - this.windowMs);
    const oldestRequest = this.requests[0] || now;
    const resetIn = Math.max(0, this.windowMs - (now - oldestRequest));

    return {
      remaining: Math.max(0, this.maxRequests - this.requests.length),
      resetIn,
    };
  }
}

// ============================================================================
// SINGLETON INSTANCE
// ============================================================================

let gatewayInstance: APIGateway | null = null;

/**
 * Get the singleton instance of the API Gateway
 */
export function getAPIGateway(): APIGateway {
  if (!gatewayInstance) {
    gatewayInstance = new APIGateway();
  }
  return gatewayInstance;
}

/**
 * Initialize the API Gateway with configuration
 */
export function initializeAPIGateway(config: Partial<GatewayConfig>): APIGateway {
  gatewayInstance = new APIGateway(config);
  return gatewayInstance;
}

// ============================================================================
// EXPORTS
// ============================================================================

export default APIGateway;
