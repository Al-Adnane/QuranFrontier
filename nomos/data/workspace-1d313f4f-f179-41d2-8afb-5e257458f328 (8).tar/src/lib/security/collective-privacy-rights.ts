/**
 * Collective Privacy Rights Manager
 *
 * Inspired by Stanford HAI's recommendation for collective data rights solutions:
 * "The concept of a data intermediary makes the most sense. It involves delegating
 * the negotiating power over your data rights to a collective that does the work
 * for you, which gives consumers more leverage."
 *
 * Reference: https://hai.stanford.edu/news/privacy-ai-era-how-do-we-protect-our-personal-information
 *
 * Key Features:
 * 1. Data Intermediary/Steward Management
 * 2. Collective Negotiation Power
 * 3. Group Privacy Rights Exercise
 * 4. Privacy Trust Framework
 * 5. Data Cooperative Support
 */

// ============================================================================
// Types and Interfaces
// ============================================================================

export interface DataIntermediary {
  id: string;
  name: string;
  type: IntermediaryType;
  description: string;
  members: string[];
  totalMembers: number;
  establishedDate: Date;
  governanceModel: GovernanceModel;
  services: IntermediaryService[];
  accreditation: AccreditationStatus;
  contactInfo: {
    email: string;
    website: string;
    address?: string;
  };
  feeStructure?: {
    membershipFee: number;
    transactionFee?: number;
    currency: string;
  };
}

export type IntermediaryType =
  | 'data_trust'
  | 'data_cooperative'
  | 'data_steward'
  | 'privacy_collective'
  | 'consumer_advocacy'
  | 'non_profit';

export type GovernanceModel =
  | 'democratic'
  | 'representative'
  | 'expert_led'
  | 'hybrid';

export type IntermediaryService =
  | 'consent_management'
  | 'data_access_requests'
  | 'deletion_requests'
  | 'data_portability'
  | 'complaint_handling'
  | 'negotiation'
  | 'monitoring'
  | 'legal_support';

export type AccreditationStatus =
  | 'pending'
  | 'accredited'
  | 'suspended'
  | 'revoked';

export interface CollectiveMembership {
  id: string;
  userId: string;
  intermediaryId: string;
  joinDate: Date;
  status: MembershipStatus;
  votingRights: boolean;
  delegatedRights: DelegatedRight[];
  preferences: MembershipPreferences;
}

export type MembershipStatus =
  | 'active'
  | 'suspended'
  | 'withdrawn'
  | 'pending_approval';

export interface DelegatedRight {
  right: PrivacyRight;
  scope: RightScope;
  delegatedAt: Date;
  expiresAt?: Date;
  conditions?: string[];
}

export type PrivacyRight =
  | 'access'
  | 'rectification'
  | 'erasure'
  | 'portability'
  | 'restriction'
  | 'objection'
  | 'automated_decision_making';

export type RightScope =
  | 'all_data'
  | 'specific_categories'
  | 'specific_controllers'
  | 'time_limited';

export interface MembershipPreferences {
  autoNegotiate: boolean;
  notifyOnAccess: boolean;
  notifyOnDeletion: boolean;
  notifyOnSharing: boolean;
  preferredCommunication: 'email' | 'sms' | 'app';
  language: string;
}

export interface CollectiveAction {
  id: string;
  type: CollectiveActionType;
  initiator: string;
  intermediaryId: string;
  participants: string[];
  target: string;
  status: ActionStatus;
  createdAt: Date;
  updatedAt: Date;
  result?: ActionResult;
  votes: VoteRecord[];
}

export type CollectiveActionType =
  | 'access_request'
  | 'deletion_request'
  | 'data_portability'
  | 'consent_withdrawal'
  | 'complaint'
  | 'negotiation'
  | 'legal_action';

export type ActionStatus =
  | 'proposed'
  | 'voting'
  | 'approved'
  | 'executed'
  | 'completed'
  | 'rejected'
  | 'failed';

export interface ActionResult {
  success: boolean;
  responseDate: Date;
  responseContent: string;
  dataRetrieved?: unknown;
  compensation?: {
    amount: number;
    currency: string;
  };
}

export interface VoteRecord {
  memberId: string;
  vote: 'for' | 'against' | 'abstain';
  timestamp: Date;
  reason?: string;
}

export interface GroupPrivacyProfile {
  id: string;
  name: string;
  description: string;
  members: string[];
  sharedConcerns: PrivacyConcern[];
  riskProfile: GroupRiskProfile;
  protections: GroupProtection[];
}

export interface PrivacyConcern {
  category: string;
  severity: 'low' | 'medium' | 'high';
  description: string;
  affectedMembers: number;
}

export interface GroupRiskProfile {
  overallRisk: number;
  categoryRisks: Record<string, number>;
  vulnerabilities: string[];
  mitigations: string[];
}

export interface GroupProtection {
  id: string;
  type: ProtectionType;
  description: string;
  effectiveness: number;
  implemented: boolean;
}

export type ProtectionType =
  | 'consent_requirement'
  | 'data_minimization'
  | 'anonymization'
  | 'access_control'
  | 'retention_limit'
  | 'audit_trail';

export interface PrivacyTrust {
  id: string;
  name: string;
  trustees: Trustee[];
  beneficiaries: string[];
  assets: DataAsset[];
  rules: TrustRule[];
  createdDate: Date;
  expiryDate?: Date;
}

export interface Trustee {
  id: string;
  name: string;
  role: 'primary' | 'secondary' | 'advisor';
  organization: string;
  expertise: string[];
}

export interface DataAsset {
  id: string;
  description: string;
  dataType: string;
  value?: number;
  restrictions: string[];
}

export interface TrustRule {
  id: string;
  description: string;
  condition: string;
  action: string;
  priority: number;
}

// ============================================================================
// Data Intermediary Manager
// ============================================================================

export class DataIntermediaryManager {
  private intermediaries: Map<string, DataIntermediary> = new Map();
  private memberships: Map<string, CollectiveMembership> = new Map();
  private actions: Map<string, CollectiveAction> = new Map();
  private groupProfiles: Map<string, GroupPrivacyProfile> = new Map();
  private trusts: Map<string, PrivacyTrust> = new Map();

  constructor() {
    this.initializeDefaultIntermediaries();
  }

  /**
   * Register a new data intermediary
   */
  async registerIntermediary(
    intermediary: Omit<DataIntermediary, 'id' | 'members' | 'totalMembers' | 'establishedDate'>
  ): Promise<DataIntermediary> {
    const id = this.generateId('intermediary');

    const newIntermediary: DataIntermediary = {
      ...intermediary,
      id,
      members: [],
      totalMembers: 0,
      establishedDate: new Date(),
    };

    this.intermediaries.set(id, newIntermediary);

    return newIntermediary;
  }

  /**
   * Join a collective/intermediary
   */
  async joinCollective(
    userId: string,
    intermediaryId: string,
    preferences: MembershipPreferences,
    delegatedRights?: DelegatedRight[]
  ): Promise<CollectiveMembership> {
    const intermediary = this.intermediaries.get(intermediaryId);
    if (!intermediary) {
      throw new Error(`Intermediary not found: ${intermediaryId}`);
    }

    // Check if already a member
    const existingMembership = this.findMembership(userId, intermediaryId);
    if (existingMembership) {
      throw new Error('Already a member of this collective');
    }

    const membershipId = this.generateId('membership');

    const membership: CollectiveMembership = {
      id: membershipId,
      userId,
      intermediaryId,
      joinDate: new Date(),
      status: 'active',
      votingRights: true,
      delegatedRights: delegatedRights || this.getDefaultDelegatedRights(),
      preferences,
    };

    this.memberships.set(membershipId, membership);

    // Update intermediary
    intermediary.members.push(userId);
    intermediary.totalMembers = intermediary.members.length;

    return membership;
  }

  /**
   * Delegate privacy rights to intermediary
   */
  async delegateRights(
    membershipId: string,
    rights: DelegatedRight[]
  ): Promise<CollectiveMembership> {
    const membership = this.memberships.get(membershipId);
    if (!membership) {
      throw new Error(`Membership not found: ${membershipId}`);
    }

    // Add new delegated rights
    for (const right of rights) {
      const existing = membership.delegatedRights.find(
        (r) => r.right === right.right && r.scope === right.scope
      );
      if (!existing) {
        membership.delegatedRights.push(right);
      }
    }

    return membership;
  }

  /**
   * Initiate a collective action
   */
  async initiateCollectiveAction(
    initiatorId: string,
    intermediaryId: string,
    type: CollectiveActionType,
    target: string,
    participantIds?: string[]
  ): Promise<CollectiveAction> {
    const intermediary = this.intermediaries.get(intermediaryId);
    if (!intermediary) {
      throw new Error(`Intermediary not found: ${intermediaryId}`);
    }

    // Verify initiator is a member
    const membership = this.findMembership(initiatorId, intermediaryId);
    if (!membership) {
      throw new Error('Initiator is not a member of this collective');
    }

    const actionId = this.generateId('action');

    // Determine participants
    const participants = participantIds || intermediary.members;

    const action: CollectiveAction = {
      id: actionId,
      type,
      initiator: initiatorId,
      intermediaryId,
      participants,
      target,
      status: 'proposed',
      createdAt: new Date(),
      updatedAt: new Date(),
      votes: [],
    };

    this.actions.set(actionId, action);

    return action;
  }

  /**
   * Vote on a collective action
   */
  async vote(
    actionId: string,
    memberId: string,
    vote: 'for' | 'against' | 'abstain',
    reason?: string
  ): Promise<CollectiveAction> {
    const action = this.actions.get(actionId);
    if (!action) {
      throw new Error(`Action not found: ${actionId}`);
    }

    // Verify member is participant
    if (!action.participants.includes(memberId)) {
      throw new Error('Member is not a participant in this action');
    }

    // Check if already voted
    const existingVote = action.votes.find((v) => v.memberId === memberId);
    if (existingVote) {
      throw new Error('Member has already voted');
    }

    action.votes.push({
      memberId,
      vote,
      timestamp: new Date(),
      reason,
    });

    action.updatedAt = new Date();

    // Check if voting complete
    if (action.votes.length === action.participants.length) {
      action.status = this.determineActionStatus(action.votes);
    }

    return action;
  }

  /**
   * Execute collective action after approval
   */
  async executeCollectiveAction(
    actionId: string
  ): Promise<{ success: boolean; result?: ActionResult }> {
    const action = this.actions.get(actionId);
    if (!action) {
      throw new Error(`Action not found: ${actionId}`);
    }

    if (action.status !== 'approved') {
      throw new Error('Action not approved for execution');
    }

    action.status = 'executed';
    action.updatedAt = new Date();

    // Simulate action execution
    const result: ActionResult = await this.performAction(action);

    action.result = result;
    action.status = result.success ? 'completed' : 'failed';

    return { success: result.success, result };
  }

  /**
   * Create a group privacy profile
   */
  async createGroupProfile(
    name: string,
    description: string,
    memberIds: string[],
    concerns: PrivacyConcern[]
  ): Promise<GroupPrivacyProfile> {
    const id = this.generateId('profile');

    const riskProfile = this.calculateGroupRisk(concerns);
    const protections = this.recommendProtections(riskProfile);

    const profile: GroupPrivacyProfile = {
      id,
      name,
      description,
      members: memberIds,
      sharedConcerns: concerns,
      riskProfile,
      protections,
    };

    this.groupProfiles.set(id, profile);

    return profile;
  }

  /**
   * Create a data trust
   */
  async createDataTrust(
    name: string,
    trustees: Trustee[],
    beneficiaries: string[],
    assets: DataAsset[],
    rules: TrustRule[]
  ): Promise<PrivacyTrust> {
    const id = this.generateId('trust');

    const trust: PrivacyTrust = {
      id,
      name,
      trustees,
      beneficiaries,
      assets,
      rules: rules.sort((a, b) => b.priority - a.priority),
      createdDate: new Date(),
    };

    this.trusts.set(id, trust);

    return trust;
  }

  /**
   * Negotiate on behalf of collective
   */
  async negotiateWithController(
    intermediaryId: string,
    controllerId: string,
    terms: {
      dataTypes: string[];
      purposes: string[];
      compensation?: { amount: number; currency: string };
      restrictions: string[];
    }
  ): Promise<{
    success: boolean;
    agreedTerms?: Record<string, unknown>;
    negotiationId: string;
  }> {
    const intermediary = this.intermediaries.get(intermediaryId);
    if (!intermediary) {
      throw new Error(`Intermediary not found: ${intermediaryId}`);
    }

    // Calculate collective bargaining power
    const bargainingPower = intermediary.totalMembers;

    // Simulate negotiation
    const negotiationId = this.generateId('negotiation');

    // Higher membership = better negotiation outcomes
    const successProbability = Math.min(0.5 + bargainingPower * 0.001, 0.95);
    const success = Math.random() < successProbability;

    const agreedTerms: Record<string, unknown> = success
      ? {
          dataTypes: terms.dataTypes,
          purposes: terms.purposes,
          compensation: terms.compensation,
          restrictions: terms.restrictions,
          auditRights: true,
          dataSubjectRights: ['access', 'erasure', 'portability'],
          retentionLimitDays: 365,
        }
      : {};

    return { success, agreedTerms, negotiationId };
  }

  /**
   * Bulk exercise of privacy rights
   */
  async bulkExerciseRights(
    intermediaryId: string,
    right: PrivacyRight,
    controllerId: string
  ): Promise<{
    totalRequests: number;
    successful: number;
    failed: number;
    results: Array<{ userId: string; success: boolean; response?: string }>;
  }> {
    const intermediary = this.intermediaries.get(intermediaryId);
    if (!intermediary) {
      throw new Error(`Intermediary not found: ${intermediaryId}`);
    }

    const results: Array<{ userId: string; success: boolean; response?: string }> = [];

    for (const userId of intermediary.members) {
      // Simulate right exercise
      const success = Math.random() > 0.1; // 90% success rate
      results.push({
        userId,
        success,
        response: success
          ? `Right ${right} exercised successfully`
          : 'Controller did not respond within deadline',
      });
    }

    return {
      totalRequests: results.length,
      successful: results.filter((r) => r.success).length,
      failed: results.filter((r) => !r.success).length,
      results,
    };
  }

  // Private methods

  private initializeDefaultIntermediaries(): void {
    // Digital Rights Collective
    this.intermediaries.set('drc_001', {
      id: 'drc_001',
      name: 'Digital Rights Collective',
      type: 'privacy_collective',
      description: 'A collective for protecting digital privacy rights',
      members: [],
      totalMembers: 0,
      establishedDate: new Date(),
      governanceModel: 'democratic',
      services: [
        'consent_management',
        'data_access_requests',
        'deletion_requests',
        'negotiation',
      ],
      accreditation: 'accredited',
      contactInfo: {
        email: 'contact@digitalrightscollective.org',
        website: 'https://digitalrightscollective.org',
      },
      feeStructure: {
        membershipFee: 0,
        currency: 'USD',
      },
    });

    // AI Ethics Data Trust
    this.intermediaries.set('aedt_001', {
      id: 'aedt_001',
      name: 'AI Ethics Data Trust',
      type: 'data_trust',
      description: 'Trust for managing data rights in AI systems',
      members: [],
      totalMembers: 0,
      establishedDate: new Date(),
      governanceModel: 'expert_led',
      services: [
        'consent_management',
        'monitoring',
        'legal_support',
        'complaint_handling',
      ],
      accreditation: 'accredited',
      contactInfo: {
        email: 'trust@aiethics.org',
        website: 'https://aiethicsdatatrust.org',
      },
      feeStructure: {
        membershipFee: 0,
        transactionFee: 0.05,
        currency: 'USD',
      },
    });
  }

  private findMembership(
    userId: string,
    intermediaryId: string
  ): CollectiveMembership | undefined {
    for (const membership of this.memberships.values()) {
      if (membership.userId === userId && membership.intermediaryId === intermediaryId) {
        return membership;
      }
    }
    return undefined;
  }

  private getDefaultDelegatedRights(): DelegatedRight[] {
    return [
      {
        right: 'access',
        scope: 'all_data',
        delegatedAt: new Date(),
      },
      {
        right: 'erasure',
        scope: 'all_data',
        delegatedAt: new Date(),
      },
      {
        right: 'portability',
        scope: 'all_data',
        delegatedAt: new Date(),
      },
    ];
  }

  private determineActionStatus(votes: VoteRecord[]): ActionStatus {
    const forVotes = votes.filter((v) => v.vote === 'for').length;
    const againstVotes = votes.filter((v) => v.vote === 'against').length;

    if (forVotes > againstVotes) {
      return 'approved';
    }
    return 'rejected';
  }

  private async performAction(action: CollectiveAction): Promise<ActionResult> {
    // Simulate action execution based on type
    switch (action.type) {
      case 'access_request':
        return {
          success: true,
          responseDate: new Date(),
          responseContent: 'Data access granted',
          dataRetrieved: { records: 42 },
        };
      case 'deletion_request':
        return {
          success: true,
          responseDate: new Date(),
          responseContent: 'Data deleted successfully',
        };
      case 'data_portability':
        return {
          success: true,
          responseDate: new Date(),
          responseContent: 'Data exported successfully',
          dataRetrieved: { exportUrl: 'https://example.com/export' },
        };
      default:
        return {
          success: false,
          responseDate: new Date(),
          responseContent: 'Action not supported',
        };
    }
  }

  private calculateGroupRisk(concerns: PrivacyConcern[]): GroupRiskProfile {
    const categoryRisks: Record<string, number> = {};
    let overallRisk = 0;

    for (const concern of concerns) {
      const weight = concern.severity === 'high' ? 0.8 : concern.severity === 'medium' ? 0.5 : 0.2;
      categoryRisks[concern.category] = (categoryRisks[concern.category] || 0) + weight;
      overallRisk += weight * (concern.affectedMembers / 100);
    }

    return {
      overallRisk: Math.min(overallRisk, 1),
      categoryRisks,
      vulnerabilities: concerns
        .filter((c) => c.severity === 'high')
        .map((c) => c.description),
      mitigations: [],
    };
  }

  private recommendProtections(riskProfile: GroupRiskProfile): GroupProtection[] {
    const protections: GroupProtection[] = [];

    if (riskProfile.overallRisk > 0.5) {
      protections.push({
        id: this.generateId('protection'),
        type: 'consent_requirement',
        description: 'Require explicit consent for all data processing',
        effectiveness: 0.8,
        implemented: false,
      });
    }

    protections.push({
      id: this.generateId('protection'),
      type: 'audit_trail',
      description: 'Maintain comprehensive audit trail',
      effectiveness: 0.6,
      implemented: false,
    });

    return protections;
  }

  private generateId(prefix: string): string {
    return `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  // Getters

  getIntermediary(id: string): DataIntermediary | undefined {
    return this.intermediaries.get(id);
  }

  getAllIntermediaries(): DataIntermediary[] {
    return Array.from(this.intermediaries.values());
  }

  getMembership(id: string): CollectiveMembership | undefined {
    return this.memberships.get(id);
  }

  getAction(id: string): CollectiveAction | undefined {
    return this.actions.get(id);
  }

  getGroupProfile(id: string): GroupPrivacyProfile | undefined {
    return this.groupProfiles.get(id);
  }

  getTrust(id: string): PrivacyTrust | undefined {
    return this.trusts.get(id);
  }

  getUserMemberships(userId: string): CollectiveMembership[] {
    return Array.from(this.memberships.values()).filter((m) => m.userId === userId);
  }
}

// ============================================================================
// Collective Privacy Dashboard
// ============================================================================

export interface CollectiveDashboard {
  userId: string;
  memberships: {
    intermediaryName: string;
    joinDate: Date;
    status: MembershipStatus;
    delegatedRights: string[];
  }[];
  activeActions: {
    actionType: string;
    status: ActionStatus;
    participants: number;
    target: string;
  }[];
  groupProfiles: {
    name: string;
    members: number;
    overallRisk: number;
  }[];
  trustAssets: {
    trustName: string;
    assetCount: number;
    isBeneficiary: boolean;
  }[];
}

export class CollectivePrivacyDashboard {
  private manager: DataIntermediaryManager;

  constructor(manager: DataIntermediaryManager) {
    this.manager = manager;
  }

  async getDashboard(userId: string): Promise<CollectiveDashboard> {
    const memberships = this.manager.getUserMemberships(userId);

    const membershipDetails = memberships.map((m) => {
      const intermediary = this.manager.getIntermediary(m.intermediaryId);
      return {
        intermediaryName: intermediary?.name || 'Unknown',
        joinDate: m.joinDate,
        status: m.status,
        delegatedRights: m.delegatedRights.map((r) => r.right),
      };
    });

    // Get active actions involving user
    const activeActions: CollectiveDashboard['activeActions'] = [];
    // In production, query actions where user is participant

    // Get group profiles
    const groupProfiles: CollectiveDashboard['groupProfiles'] = [];
    for (const profile of this.manager['groupProfiles'].values()) {
      if (profile.members.includes(userId)) {
        groupProfiles.push({
          name: profile.name,
          members: profile.members.length,
          overallRisk: profile.riskProfile.overallRisk,
        });
      }
    }

    // Get trust assets
    const trustAssets: CollectiveDashboard['trustAssets'] = [];
    for (const trust of this.manager['trusts'].values()) {
      if (trust.beneficiaries.includes(userId)) {
        trustAssets.push({
          trustName: trust.name,
          assetCount: trust.assets.length,
          isBeneficiary: true,
        });
      }
    }

    return {
      userId,
      memberships: membershipDetails,
      activeActions,
      groupProfiles,
      trustAssets,
    };
  }
}

// ============================================================================
// Export
// ============================================================================

export const collectivePrivacyManager = new DataIntermediaryManager();
export const collectiveDashboard = new CollectivePrivacyDashboard(collectivePrivacyManager);
