/**
 * Adversarial Pattern Detection System
 * Moat 8: Adversarial Pattern Detection - Detects obfuscation attempts
 * 
 * Detects evasion attempts: base64-encoded secrets, unicode lookalikes, 
 * whitespace-injected tokens, and other adversarial patterns.
 */

// Unicode homoglyphs that look like ASCII but aren't
const HOMOGLYPHS: Record<string, string[]> = {
  'a': ['а', 'ạ', 'ä', 'ą', 'å', 'α'],
  'c': ['с', 'ç', 'ć', 'č'],
  'e': ['е', 'é', 'ê', 'ë', 'ę'],
  'i': ['і', 'ı', 'ї', 'і'],
  'o': ['о', 'ọ', 'ö', 'ő', 'ο'],
  'p': ['р', 'ρ'],
  's': ['ѕ', 'ś', 'š', 'ş'],
  'x': ['х', 'χ'],
  'y': ['у', 'ý', 'γ'],
  // Numbers
  '0': ['ο', 'о', '𝟎', '𝟘'],
  '1': ['l', 'і', '𝟏', '𝟙'],
  '3': ['Ʒ', 'ʒ'],
  '4': ['𝟒', '𝟜'],
  '5': ['ѕ', '𝟓', '𝟝'],
  '6': ['Ƅ', '𝟔', '𝟞'],
  '7': ['𝟕', '𝟟'],
  '8': ['𝟖', '𝟠'],
  '9': ['𝟗', '𝟡'],
}

// Known evasion patterns
const EVASION_SIGNATURES = [
  // Base64 patterns (common prefixes)
  /(?:[A-Za-z0-9+/]{4}){10,}(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?/,
  
  // Hex-encoded patterns
  /(?:[0-9a-fA-F]{2}\s*){20,}/,
  
  // Unicode escape sequences
  /(?:\\u[0-9a-fA-F]{4}){5,}/,
  
  // HTML entities
  /(?:&(?:#x?[0-9a-fA-F]+|[a-zA-Z]+);){5,}/,
  
  // Zero-width character injection
  /[\u200B\u200C\u200D\uFEFF\u00AD]/,
  
  // URL encoding abuse
  /(?:%[0-9a-fA-F]{2}){10,}/,
  
  // ROT13 patterns (common encoded words)
  /(?:frperg|cebwrpg|fxlfurq|qvfcynl)/i,
  
  // Split string patterns
  /['"`]\s*\+\s*['"`]/,
  
  // Character code construction
  /String\.fromCharCode\s*\(/,
  
  // JSON stringify evasion
  /JSON\.stringify\s*\(\s*atob/,
  
  // eval patterns
  /eval\s*\(\s*(?:atob|String|JSON)/,
  
  // setTimeout/setInterval with strings
  /set(?:Timeout|Interval)\s*\(\s*['"`]/,
]

// Deepfake-specific adversarial patterns
const DEEPFAKE_EVASION_PATTERNS = [
  // Noise injection patterns
  /\b(?:noise|gaussian|uniform|salt|pepper)\s*(?:injection|perturbation)\b/i,
  
  // Adversarial example mentions
  /\b(?:adversarial|fgsm|pgd|cw)\s*(?:attack|example|perturbation)\b/i,
  
  // GAN-specific evasion
  /\b(?:progan|stylegan|stargan|deepfake)\s*(?:evade|bypass|fool)\b/i,
  
  // Detection bypass keywords
  /\b(?:bypass|evade|fool|trick|deceive)\s*(?:detection|classifier|model)\b/i,
  
  // Face manipulation markers
  /\b(?:face2face|faceswap|deepfacelab|first_order_model)\b/i,
  
  // Gradient-based attack references
  /\b(?:gradient|backprop|optimization)\s*(?:attack|descent)\b/i,
]

export interface EvasionDetectionResult {
  isEvasive: boolean
  riskScore: number // 0-1
  detectedPatterns: string[]
  homoglyphsFound: Array<{ original: string; position: number; normalizedTo: string }>
  obfuscationMethods: string[]
  recommendations: string[]
}

/**
 * Normalize homoglyphs to ASCII equivalents
 */
export function normalizeHomoglyphs(input: string): string {
  let normalized = input
  
  for (const [ascii, variants] of Object.entries(HOMOGLYPHS)) {
    for (const variant of variants) {
      normalized = normalized.replace(new RegExp(variant, 'g'), ascii)
    }
  }
  
  return normalized
}

/**
 * Detect homoglyphs in text
 */
export function detectHomoglyphs(input: string): Array<{ original: string; position: number; normalizedTo: string }> {
  const found: Array<{ original: string; position: number; normalizedTo: string }> = []
  
  for (let i = 0; i < input.length; i++) {
    const char = input[i]
    for (const [ascii, variants] of Object.entries(HOMOGLYPHS)) {
      if (variants.includes(char)) {
        found.push({
          original: char,
          position: i,
          normalizedTo: ascii
        })
        break
      }
    }
  }
  
  return found
}

/**
 * Decode various obfuscation layers
 */
export function decodeObfuscationLayers(input: string): string[] {
  const layers: string[] = [input]
  
  try {
    // Base64 decode
    if (/^[A-Za-z0-9+/]+=*$/.test(input.replace(/\s/g, ''))) {
      const decoded = Buffer.from(input.replace(/\s/g, ''), 'base64').toString('utf8')
      layers.push(decoded)
    }
  } catch {}
  
  try {
    // URL decode
    const urlDecoded = decodeURIComponent(input)
    if (urlDecoded !== input) {
      layers.push(urlDecoded)
    }
  } catch {}
  
  try {
    // Hex decode
    if (/^(?:[0-9a-fA-F]{2})+$/.test(input.replace(/\s/g, ''))) {
      const hexDecoded = Buffer.from(input.replace(/\s/g, ''), 'hex').toString('utf8')
      layers.push(hexDecoded)
    }
  } catch {}
  
  try {
    // ROT13 decode
    const rot13 = input.replace(/[a-zA-Z]/g, (char) => {
      const base = char <= 'Z' ? 65 : 97
      return String.fromCharCode(((char.charCodeAt(0) - base + 13) % 26) + base)
    })
    if (rot13 !== input) {
      layers.push(rot13)
    }
  } catch {}
  
  // Remove zero-width characters
  const cleaned = input.replace(/[\u200B\u200C\u200D\uFEFF\u00AD]/g, '')
  if (cleaned !== input) {
    layers.push(cleaned)
  }
  
  // Normalize homoglyphs
  const normalized = normalizeHomoglyphs(input)
  if (normalized !== input) {
    layers.push(normalized)
  }
  
  return [...new Set(layers)]
}

/**
 * Check for adversarial evasion patterns
 */
export function detectEvasionPatterns(input: string): string[] {
  const detected: string[] = []
  
  for (const pattern of EVASION_SIGNATURES) {
    if (pattern.test(input)) {
      detected.push(`evasion_pattern:${pattern.source.slice(0, 30)}`)
    }
  }
  
  for (const pattern of DEEPFAKE_EVASION_PATTERNS) {
    if (pattern.test(input)) {
      detected.push(`deepfake_evasion:${pattern.source.slice(0, 30)}`)
    }
  }
  
  return detected
}

/**
 * Calculate overall evasion risk score
 */
export function calculateEvasionRisk(
  patterns: string[],
  homoglyphs: Array<{ original: string; position: number; normalizedTo: string }>,
  layers: string[]
): number {
  let score = 0
  
  // Each detected pattern adds risk
  score += patterns.length * 0.15
  
  // Homoglyphs are high-risk
  score += homoglyphs.length * 0.2
  
  // Multiple decode layers suggest intentional obfuscation
  if (layers.length > 3) {
    score += 0.3
  }
  
  // Cap at 1.0
  return Math.min(score, 1.0)
}

/**
 * Main function: Detect adversarial patterns in analysis content
 */
export function detectAdversarialPatterns(
  fileName: string,
  analysis: string,
  metadata?: Record<string, unknown>
): EvasionDetectionResult {
  const allText = `${fileName} ${analysis} ${JSON.stringify(metadata || {})}`
  
  // Decode all layers
  const layers = decodeObfuscationLayers(allText)
  
  // Check each layer for patterns
  const allPatterns: string[] = []
  for (const layer of layers) {
    const patterns = detectEvasionPatterns(layer)
    allPatterns.push(...patterns)
  }
  
  // Detect homoglyphs
  const homoglyphs = detectHomoglyphs(allText)
  
  // Calculate risk
  const riskScore = calculateEvasionRisk(allPatterns, homoglyphs, layers)
  
  // Generate recommendations
  const recommendations: string[] = []
  
  if (homoglyphs.length > 0) {
    recommendations.push('Unicode homoglyphs detected - possible visual spoofing attempt')
  }
  
  if (allPatterns.some(p => p.includes('base64') || p.includes('hex'))) {
    recommendations.push('Encoded content detected - analyze decoded content separately')
  }
  
  if (allPatterns.some(p => p.includes('deepfake_evasion'))) {
    recommendations.push('Deepfake evasion terminology detected - flag for manual review')
  }
  
  if (riskScore > 0.5) {
    recommendations.push('High evasion risk - recommend additional verification methods')
  }
  
  // Identify obfuscation methods
  const obfuscationMethods: string[] = []
  if (homoglyphs.length > 0) obfuscationMethods.push('homoglyph_substitution')
  if (allPatterns.some(p => p.includes('base64'))) obfuscationMethods.push('base64_encoding')
  if (allPatterns.some(p => p.includes('hex'))) obfuscationMethods.push('hex_encoding')
  if (allPatterns.some(p => p.includes('zero_width'))) obfuscationMethods.push('zero_width_injection')
  if (allPatterns.some(p => p.includes('url'))) obfuscationMethods.push('url_encoding')
  
  return {
    isEvasive: riskScore > 0.3,
    riskScore,
    detectedPatterns: [...new Set(allPatterns)],
    homoglyphsFound: homoglyphs,
    obfuscationMethods,
    recommendations
  }
}

/**
 * Generate adversarial test cases for validation
 */
export function generateAdversarialTestCases(): Array<{
  name: string
  input: string
  expectedRisk: 'low' | 'medium' | 'high'
  expectedPatterns: number
}> {
  return [
    {
      name: 'base64_encoded_secret',
      input: Buffer.from('sk_live_secretkey1234567890').toString('base64'),
      expectedRisk: 'medium',
      expectedPatterns: 1
    },
    {
      name: 'homoglyph_attack',
      input: 'ѕk_live_secretkey1234567890', // Cyrillic 'ѕ'
      expectedRisk: 'high',
      expectedPatterns: 1
    },
    {
      name: 'zero_width_injection',
      input: 'sk_live_\u200Bsecret\u200Bkey1234567890',
      expectedRisk: 'high',
      expectedPatterns: 1
    },
    {
      name: 'hex_encoded',
      input: Buffer.from('sk_live_secretkey').toString('hex'),
      expectedRisk: 'medium',
      expectedPatterns: 1
    },
    {
      name: 'clean_input',
      input: 'This is a normal analysis text without any evasion',
      expectedRisk: 'low',
      expectedPatterns: 0
    },
    {
      name: 'deepfake_evasion_keyword',
      input: 'Using fgsm attack to bypass detection classifier',
      expectedRisk: 'high',
      expectedPatterns: 1
    },
    {
      name: 'combined_evasion',
      input: Buffer.from(normalizeHomoglyphs('ѕk_live_\u200Bsecret')).toString('base64'),
      expectedRisk: 'high',
      expectedPatterns: 2
    }
  ]
}

/**
 * Run adversarial test suite
 */
export function runAdversarialTests(): {
  passed: number
  failed: number
  results: Array<{ name: string; passed: boolean; details: string }>
} {
  const testCases = generateAdversarialTestCases()
  const results: Array<{ name: string; passed: boolean; details: string }> = []
  
  let passed = 0
  let failed = 0
  
  for (const test of testCases) {
    const detection = detectAdversarialPatterns(test.input, '', {})
    
    const expectedRiskScore = 
      test.expectedRisk === 'low' ? 0.3 :
      test.expectedRisk === 'medium' ? 0.5 : 0.7
    
    const riskMatches = 
      (test.expectedRisk === 'low' && detection.riskScore < 0.3) ||
      (test.expectedRisk === 'medium' && detection.riskScore >= 0.3 && detection.riskScore < 0.6) ||
      (test.expectedRisk === 'high' && detection.riskScore >= 0.6)
    
    const patternsMatch = detection.detectedPatterns.length >= test.expectedPatterns
    
    const testPassed = riskMatches && patternsMatch
    
    if (testPassed) {
      passed++
      results.push({
        name: test.name,
        passed: true,
        details: `Risk: ${detection.riskScore.toFixed(2)}, Patterns: ${detection.detectedPatterns.length}`
      })
    } else {
      failed++
      results.push({
        name: test.name,
        passed: false,
        details: `Expected risk: ${test.expectedRisk}, got: ${detection.riskScore.toFixed(2)}. Expected patterns: ${test.expectedPatterns}, got: ${detection.detectedPatterns.length}`
      })
    }
  }
  
  return { passed, failed, results }
}
