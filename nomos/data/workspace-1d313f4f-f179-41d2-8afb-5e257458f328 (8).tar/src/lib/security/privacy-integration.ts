/**
 * Privacy Integration Module
 *
 * Unified integration of all privacy modules for the Kasbah Deepfake Detector.
 * Inspired by Stanford HAI and IBM AI Privacy research.
 *
 * Modules Integrated:
 * 1. Privacy-First Data Framework (opt-in consent, data minimization)
 * 2. Data Supply Chain Tracker (AI transparency, lineage)
 * 3. Collective Privacy Rights Manager (data intermediaries)
 * 4. Voice Privacy Protection (clone detection, anonymization)
 * 5. Privacy-Preserving Analytics (differential privacy)
 */

import {
  PrivacyFirstFramework,
  privacyFramework,
  type ConsentRecord,
  type PrivacySettings,
  type DataMinimizationConfig,
  type PurposeLimitationRule,
  type DataType,
  type PurposeCategory,
  type DataOperation,
} from './privacy-first-framework';

import {
  DataSupplyChainTracker,
  dataSupplyChain,
  TrainingDataTransparencyReport,
  transparencyReport,
  type DataLineageNode,
  type TrainingDataSource,
  type OutputTrace,
  type ComplianceFlag,
} from './data-supply-chain';

import {
  DataIntermediaryManager,
  collectivePrivacyManager,
  type DataIntermediary,
  type CollectiveMembership,
  type CollectiveAction,
  type PrivacyTrust,
} from './collective-privacy-rights';

import {
  VoiceCloneDetector,
  voiceCloneDetector,
  VoiceAnonymizer,
  voiceAnonymizer,
  VoiceAuthenticator,
  voiceAuthenticator,
  ImpersonationProtectionService,
  impersonationProtection,
  type VoiceProfile,
  type VoiceCloneDetectionResult,
  type VoiceAnonymizationResult,
  type AnonymizationLevel,
} from './voice-privacy-protection';

import {
  DifferentialPrivacyEngine,
  dpEngine,
  PrivacyAnalyticsDashboard,
  analyticsDashboard,
  type PrivacyBudget,
  type PrivateQuery,
  type PrivateQueryResult,
} from './privacy-preserving-analytics';

// ============================================================================
// Unified Privacy API
// ============================================================================

export interface PrivacyStatus {
  userId: string;
  settings: PrivacySettings;
  consentRecords: ConsentRecord[];
  memberships: CollectiveMembership[];
  voiceProfileRegistered: boolean;
  privacyBudgetRemaining: number;
}

export interface ComprehensivePrivacyReport {
  generatedAt: Date;
  userId: string;
  consent: {
    active: number;
    withdrawn: number;
    pendingReview: number;
  };
  dataLineage: {
    sources: number;
    piiDetected: number;
    complianceIssues: ComplianceFlag[];
  };
  collectiveRights: {
    memberships: number;
    activeActions: number;
    trusts: number;
  };
  voiceProtection: {
    profileActive: boolean;
    cloneDetections: number;
    alertsRaised: number;
  };
  analytics: {
    budgetUsed: number;
    budgetTotal: number;
    queriesExecuted: number;
  };
  recommendations: string[];
}

export class UnifiedPrivacyService {
  private privacy: PrivacyFirstFramework;
  private supplyChain: DataSupplyChainTracker;
  private collective: DataIntermediaryManager;
  private voiceDetector: VoiceCloneDetector;
  private voiceAnon: VoiceAnonymizer;
  private voiceAuth: VoiceAuthenticator;
  private impersonation: ImpersonationProtectionService;
  private dp: DifferentialPrivacyEngine;
  private analytics: PrivacyAnalyticsDashboard;

  constructor() {
    this.privacy = privacyFramework;
    this.supplyChain = dataSupplyChain;
    this.collective = collectivePrivacyManager;
    this.voiceDetector = voiceCloneDetector;
    this.voiceAnon = voiceAnonymizer;
    this.voiceAuth = voiceAuthenticator;
    this.impersonation = impersonationProtection;
    this.dp = dpEngine;
    this.analytics = analyticsDashboard;
  }

  /**
   * Get comprehensive privacy status for a user
   */
  async getPrivacyStatus(userId: string): Promise<PrivacyStatus> {
    const settings = this.privacy.consent.getPrivacySettings(userId);
    const memberships = this.collective.getUserMemberships(userId);
    const voiceProfile = this.voiceDetector.getVoiceProfile(userId);

    // Calculate remaining privacy budget
    const budgets = Array.from(this.dp['budgets'].values());
    const totalBudget = budgets.reduce((sum, b) => sum + b.remainingEpsilon, 0);

    return {
      userId,
      settings,
      consentRecords: [], // Would fetch from consent manager
      memberships,
      voiceProfileRegistered: !!voiceProfile,
      privacyBudgetRemaining: totalBudget,
    };
  }

  /**
   * Generate comprehensive privacy report
   */
  async generatePrivacyReport(userId: string): Promise<ComprehensivePrivacyReport> {
    // Consent status
    const auditLogs = this.privacy.consent.getAuditLogs(userId);
    const consent = {
      active: auditLogs.filter((l) => l.action === 'consent_granted').length,
      withdrawn: auditLogs.filter((l) => l.action === 'consent_withdrawn').length,
      pendingReview: 0,
    };

    // Data lineage
    const sources = this.supplyChain.getAllDataSources();
    const dataLineage = {
      sources: sources.length,
      piiDetected: sources.filter((s) => s.piiFound).length,
      complianceIssues: [], // Would aggregate from transparency report
    };

    // Collective rights
    const memberships = this.collective.getUserMemberships(userId);
    const collectiveRights = {
      memberships: memberships.length,
      activeActions: 0, // Would count active actions
      trusts: 0, // Would count trusts
    };

    // Voice protection
    const voiceProfile = this.voiceDetector.getVoiceProfile(userId);
    const detections = this.voiceDetector.getDetectionHistory();
    const alerts = this.impersonation.getAlerts(userId);
    const voiceProtection = {
      profileActive: !!voiceProfile,
      cloneDetections: detections.length,
      alertsRaised: alerts.length,
    };

    // Analytics
    const budgets = Array.from(this.dp['budgets'].values());
    const analytics = {
      budgetUsed: budgets.reduce((sum, b) => sum + b.spentEpsilon, 0),
      budgetTotal: budgets.reduce((sum, b) => sum + b.totalEpsilon, 0),
      queriesExecuted: budgets.reduce(
        (sum, b) => sum + b.operations.length,
        0
      ),
    };

    // Generate recommendations
    const recommendations = this.generateRecommendations({
      consent,
      dataLineage,
      collectiveRights,
      voiceProtection,
      analytics,
    });

    return {
      generatedAt: new Date(),
      userId,
      consent,
      dataLineage,
      collectiveRights,
      voiceProtection,
      analytics,
      recommendations,
    };
  }

  /**
   * Process media with full privacy protections
   */
  async processMediaWithPrivacy(
    userId: string,
    mediaUrl: string,
    mediaType: 'image' | 'video' | 'audio',
    purpose: PurposeCategory
  ): Promise<{
    allowed: boolean;
    consentId?: string;
    lineageId?: string;
    anonymizedUrl?: string;
    reason?: string;
  }> {
    // Map media type to data type
    const dataType: DataType = mediaType;

    // Check consent
    const consentCheck = await this.privacy.consent.checkConsent(
      userId,
      dataType,
      purpose,
      'process'
    );

    if (!consentCheck.allowed) {
      return { allowed: false, reason: consentCheck.reason };
    }

    // Check purpose limitation
    const operationCheck = await this.privacy.limitation.checkOperation(
      purpose,
      'process'
    );

    if (!operationCheck.allowed) {
      return { allowed: false, reason: operationCheck.reason };
    }

    // If audio, check for voice cloning and optionally anonymize
    let anonymizedUrl: string | undefined;
    if (mediaType === 'audio') {
      const cloneResult = await this.voiceDetector.detectClone(mediaUrl, userId);

      if (cloneResult.isClone && cloneResult.confidence > 0.8) {
        return {
          allowed: false,
          reason: 'Detected as potential voice clone',
        };
      }

      const settings = this.privacy.consent.getPrivacySettings(userId);
      if (settings.anonymousModeEnabled) {
        const anonResult = await this.voiceAnon.anonymize(mediaUrl, 'advanced');
        anonymizedUrl = anonResult.anonymizedAudioUrl;
      }
    }

    return {
      allowed: true,
      anonymizedUrl,
    };
  }

  /**
   * Register user with full privacy protections
   */
  async registerUserWithPrivacy(
    userId: string,
    options?: {
      joinCollective?: string;
      registerVoice?: string;
      privacySettings?: Partial<PrivacySettings>;
    }
  ): Promise<{
    success: boolean;
    settings: PrivacySettings;
    membershipId?: string;
    voiceProfileId?: string;
  }> {
    // Update privacy settings
    const settings = await this.privacy.consent.updatePrivacySettings(
      userId,
      options?.privacySettings || {}
    );

    let membershipId: string | undefined;
    let voiceProfileId: string | undefined;

    // Join collective if specified
    if (options?.joinCollective) {
      const intermediary = this.collective.getIntermediary(options.joinCollective);
      if (intermediary) {
        const membership = await this.collective.joinCollective(
          userId,
          options.joinCollective,
          {
            autoNegotiate: true,
            notifyOnAccess: true,
            notifyOnDeletion: true,
            notifyOnSharing: true,
            preferredCommunication: 'email',
            language: 'en',
          }
        );
        membershipId = membership.id;
      }
    }

    // Register voice if specified
    if (options?.registerVoice) {
      const profile = await this.voiceDetector.registerVoiceProfile(
        userId,
        options.registerVoice
      );
      voiceProfileId = profile.id;
    }

    // Create privacy budget
    this.dp.createBudget(1.0, 1e-6);

    return {
      success: true,
      settings,
      membershipId,
      voiceProfileId,
    };
  }

  /**
   * Execute analytics query with differential privacy
   */
  async executePrivateAnalytics(
    budgetId: string,
    query: PrivateQuery,
    data: Record<string, unknown>[]
  ): Promise<PrivateQueryResult> {
    return this.dp.executePrivateQuery(budgetId, query, data);
  }

  /**
   * Create a data trust for collective privacy
   */
  async createDataTrust(
    name: string,
    trustees: Array<{ name: string; organization: string; expertise: string[] }>,
    beneficiaries: string[],
    assets: Array<{ description: string; dataType: string; restrictions: string[] }>
  ): Promise<PrivacyTrust> {
    return this.collective.createDataTrust(
      name,
      trustees.map((t, i) => ({
        id: `trustee_${i}`,
        name: t.name,
        role: 'primary' as const,
        organization: t.organization,
        expertise: t.expertise,
      })),
      beneficiaries,
      assets.map((a, i) => ({
        id: `asset_${i}`,
        ...a,
        value: undefined,
      })),
      [
        {
          id: 'rule_1',
          description: 'Data can only be used for stated purposes',
          condition: 'purpose_verified',
          action: 'allow_processing',
          priority: 1,
        },
        {
          id: 'rule_2',
          description: 'PII must be anonymized before sharing',
          condition: 'contains_pii',
          action: 'anonymize_first',
          priority: 2,
        },
      ]
    );
  }

  /**
   * Detect voice clone and raise alert if needed
   */
  async detectVoiceClone(
    audioUrl: string,
    userId?: string
  ): Promise<VoiceCloneDetectionResult> {
    const result = await this.voiceDetector.detectClone(audioUrl, userId);

    // If high confidence clone and user specified, raise alert
    if (result.isClone && result.confidence > 0.8 && userId) {
      // Alert would be raised through impersonation protection
      console.log(`Alert: Potential voice clone detected for user ${userId}`);
    }

    return result;
  }

  /**
   * Anonymize voice for privacy protection
   */
  async anonymizeVoice(
    audioUrl: string,
    level: AnonymizationLevel = 'advanced'
  ): Promise<VoiceAnonymizationResult> {
    return this.voiceAnon.anonymize(audioUrl, level);
  }

  /**
   * Generate training data transparency report
   */
  async generateTransparencyReport(
    modelId: string
  ): Promise<ReturnType<TrainingDataTransparencyReport['generateReport']>> {
    return transparencyReport.generateReport(modelId);
  }

  // Private methods

  private generateRecommendations(status: {
    consent: { active: number; withdrawn: number };
    dataLineage: { piiDetected: number; complianceIssues: ComplianceFlag[] };
    collectiveRights: { memberships: number };
    voiceProtection: { profileActive: boolean; alertsRaised: number };
    analytics: { budgetUsed: number; budgetTotal: number };
  }): string[] {
    const recommendations: string[] = [];

    // Consent recommendations
    if (status.consent.withdrawn > status.consent.active) {
      recommendations.push(
        'Consider reviewing your consent preferences - multiple withdrawals detected'
      );
    }

    // Data lineage recommendations
    if (status.dataLineage.piiDetected > 0) {
      recommendations.push(
        'Personal data detected in training sources. Review data minimization policies.'
      );
    }

    if (status.dataLineage.complianceIssues.length > 0) {
      recommendations.push(
        `${status.dataLineage.complianceIssues.length} compliance issues require attention`
      );
    }

    // Collective rights recommendations
    if (status.collectiveRights.memberships === 0) {
      recommendations.push(
        'Consider joining a data collective for enhanced privacy protection and collective bargaining power'
      );
    }

    // Voice protection recommendations
    if (!status.voiceProtection.profileActive) {
      recommendations.push(
        'Register your voice profile for protection against voice cloning and impersonation'
      );
    }

    if (status.voiceProtection.alertsRaised > 0) {
      recommendations.push(
        `${status.voiceProtection.alertsRaised} voice impersonation alerts require review`
      );
    }

    // Analytics recommendations
    if (status.analytics.budgetTotal > 0) {
      const usage = status.analytics.budgetUsed / status.analytics.budgetTotal;
      if (usage > 0.8) {
        recommendations.push(
          'Privacy budget nearly exhausted. Consider prioritizing essential queries.'
        );
      }
    }

    return recommendations;
  }
}

// ============================================================================
// Export Singleton Instance
// ============================================================================

export const unifiedPrivacy = new UnifiedPrivacyService();

// Re-export all types and modules
export {
  // Privacy-First Framework
  PrivacyFirstFramework,
  privacyFramework,
  type ConsentRecord,
  type PrivacySettings,
  type DataMinimizationConfig,
  type PurposeLimitationRule,
  type DataType,
  type PurposeCategory,
  type DataOperation,

  // Data Supply Chain
  DataSupplyChainTracker,
  dataSupplyChain,
  TrainingDataTransparencyReport,
  transparencyReport,
  type DataLineageNode,
  type TrainingDataSource,
  type OutputTrace,
  type ComplianceFlag,

  // Collective Privacy
  DataIntermediaryManager,
  collectivePrivacyManager,
  type DataIntermediary,
  type CollectiveMembership,
  type CollectiveAction,
  type PrivacyTrust,

  // Voice Privacy
  VoiceCloneDetector,
  voiceCloneDetector,
  VoiceAnonymizer,
  voiceAnonymizer,
  VoiceAuthenticator,
  voiceAuthenticator,
  ImpersonationProtectionService,
  impersonationProtection,
  type VoiceProfile,
  type VoiceCloneDetectionResult,
  type VoiceAnonymizationResult,
  type AnonymizationLevel,

  // Differential Privacy
  DifferentialPrivacyEngine,
  dpEngine,
  PrivacyAnalyticsDashboard,
  analyticsDashboard,
  type PrivacyBudget,
  type PrivateQuery,
  type PrivateQueryResult,
};
