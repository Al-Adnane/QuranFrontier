/**
 * Voice Integration Module
 * Wispr Flow-inspired voice-to-text and AI-powered features for Kasbah
 * 
 * Features:
 * - Real-time voice dictation with AI polishing
 * - Voice commands for deepfake analysis
 * - Context-aware voice processing
 * - Multi-language support
 * - Voice-powered report generation
 * - Enterprise voice analytics
 * 
 * @module VoiceIntegration
 * @version 1.0.0
 * @author Kasbah Security Team
 */

import { ASR, type ASRResult } from './asr-utils';
import { LLM } from './llm-utils';

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

/**
 * Voice command types
 */
export type VoiceCommandType =
  | 'analyze'
  | 'scan'
  | 'report'
  | 'stop'
  | 'pause'
  | 'resume'
  | 'export'
  | 'clear'
  | 'settings'
  | 'help'
  | 'repeat'
  | 'translate'
  | 'polish'
  | 'summarize';

/**
 * Voice processing mode
 */
export type VoiceProcessingMode =
  | 'dictation' // Standard voice-to-text
  | 'command' // Voice commands
  | 'analysis' // Deepfake analysis voice control
  | 'report' // Report generation
  | 'mixed'; // Auto-detect mode

/**
 * Voice processing result
 */
export interface VoiceProcessingResult {
  id: string;
  success: boolean;
  mode: VoiceProcessingMode;
  transcript: string;
  polishedText?: string;
  command?: VoiceCommand;
  analysis?: DeepfakeVoiceAnalysis;
  confidence: number;
  processingTime: number;
  language: string;
  wordCount: number;
  characterCount: number;
  wpm: number; // Words per minute
}

/**
 * Voice command
 */
export interface VoiceCommand {
  type: VoiceCommandType;
  parameters: Record<string, unknown>;
  confidence: number;
  rawTranscript: string;
  action: () => Promise<unknown>;
}

/**
 * Deepfake voice analysis
 */
export interface DeepfakeVoiceAnalysis {
  targetUrl?: string;
  mediaType?: 'image' | 'video' | 'audio';
  analysisDepth?: 'quick' | 'standard' | 'deep';
  additionalContext?: string;
}

/**
 * Voice session
 */
export interface VoiceSession {
  id: string;
  userId?: string;
  startedAt: Date;
  endedAt?: Date;
  mode: VoiceProcessingMode;
  language: string;
  results: VoiceProcessingResult[];
  totalWordCount: number;
  totalDuration: number;
  averageWpm: number;
  status: 'active' | 'paused' | 'ended';
}

/**
 * Voice settings
 */
export interface VoiceSettings {
  language: string;
  autoPolish: boolean;
  polishStyle: 'professional' | 'casual' | 'academic' | 'creative';
  punctuationMode: 'auto' | 'manual' | 'smart';
  profanityFilter: boolean;
  noiseReduction: boolean;
  autoLanguageDetect: boolean;
  voiceActivationThreshold: number;
  silenceDetectionMs: number;
  maxRecordingDurationMs: number;
  contextAwareness: boolean;
}

/**
 * Voice analytics
 */
export interface VoiceAnalytics {
  totalSessions: number;
  totalDuration: number;
  totalWords: number;
  averageWpm: number;
  languageDistribution: Record<string, number>;
  commandUsage: Record<VoiceCommandType, number>;
  accuracyRate: number;
  mostUsedCommands: VoiceCommandType[];
  averageSessionDuration: number;
  peakUsageHours: number[];
}

/**
 * Text polishing options
 */
export interface PolishingOptions {
  style: 'professional' | 'casual' | 'academic' | 'creative';
  fixGrammar: boolean;
  improveClarity: boolean;
  adjustTone: 'neutral' | 'formal' | 'friendly' | 'technical';
  maxLength?: number;
  preserveKeywords: string[];
  targetAudience?: 'general' | 'technical' | 'executive' | 'legal';
}

/**
 * Polishing result
 */
export interface PolishingResult {
  original: string;
  polished: string;
  changes: PolishingChange[];
  readabilityScore: number;
  tone: string;
  wordCount: {
    original: number;
    polished: number;
  };
}

/**
 * Polishing change
 */
export interface PolishingChange {
  type: 'grammar' | 'style' | 'clarity' | 'tone' | 'punctuation';
  original: string;
  corrected: string;
  position: { start: number; end: number };
}

/**
 * Voice command definition
 */
export interface VoiceCommandDefinition {
  trigger: string[];
  type: VoiceCommandType;
  description: string;
  parameters?: Record<string, {
    type: 'string' | 'number' | 'boolean';
    required: boolean;
    description: string;
  }>;
  examples: string[];
}

// ============================================================================
// DEFAULT SETTINGS
// ============================================================================

/**
 * Default voice settings
 */
export const DEFAULT_VOICE_SETTINGS: VoiceSettings = {
  language: 'en-US',
  autoPolish: true,
  polishStyle: 'professional',
  punctuationMode: 'smart',
  profanityFilter: true,
  noiseReduction: true,
  autoLanguageDetect: true,
  voiceActivationThreshold: 0.5,
  silenceDetectionMs: 1500,
  maxRecordingDurationMs: 300000, // 5 minutes
  contextAwareness: true,
};

/**
 * Voice command definitions
 */
export const VOICE_COMMANDS: VoiceCommandDefinition[] = [
  {
    trigger: ['analyze', 'scan', 'check', 'examine'],
    type: 'analyze',
    description: 'Analyze media for deepfake indicators',
    parameters: {
      depth: {
        type: 'string',
        required: false,
        description: 'Analysis depth: quick, standard, or deep',
      },
    },
    examples: ['Analyze this image', 'Deep scan this video', 'Quick check this audio'],
  },
  {
    trigger: ['report', 'generate report', 'create report'],
    type: 'report',
    description: 'Generate a deepfake analysis report',
    parameters: {
      format: {
        type: 'string',
        required: false,
        description: 'Report format: json, pdf, html, markdown',
      },
    },
    examples: ['Generate report', 'Create PDF report', 'Generate markdown report'],
  },
  {
    trigger: ['stop', 'cancel', 'end'],
    type: 'stop',
    description: 'Stop current operation',
    examples: ['Stop', 'Cancel analysis', 'End session'],
  },
  {
    trigger: ['pause', 'hold'],
    type: 'pause',
    description: 'Pause current operation',
    examples: ['Pause', 'Hold on'],
  },
  {
    trigger: ['resume', 'continue', 'proceed'],
    type: 'resume',
    description: 'Resume paused operation',
    examples: ['Resume', 'Continue', 'Proceed'],
  },
  {
    trigger: ['export', 'download', 'save'],
    type: 'export',
    description: 'Export analysis results',
    parameters: {
      format: {
        type: 'string',
        required: false,
        description: 'Export format',
      },
    },
    examples: ['Export results', 'Download PDF', 'Save as JSON'],
  },
  {
    trigger: ['clear', 'reset', 'start over'],
    type: 'clear',
    description: 'Clear current session or results',
    examples: ['Clear', 'Reset', 'Start over'],
  },
  {
    trigger: ['polish', 'improve', 'fix'],
    type: 'polish',
    description: 'Polish transcribed text',
    examples: ['Polish this text', 'Improve clarity', 'Fix grammar'],
  },
  {
    trigger: ['summarize', 'summary', 'brief'],
    type: 'summarize',
    description: 'Summarize content',
    examples: ['Summarize', 'Give me a summary', 'Brief version'],
  },
  {
    trigger: ['translate'],
    type: 'translate',
    description: 'Translate text to another language',
    parameters: {
      language: {
        type: 'string',
        required: true,
        description: 'Target language',
      },
    },
    examples: ['Translate to Spanish', 'Translate to French'],
  },
  {
    trigger: ['help', 'what can you do'],
    type: 'help',
    description: 'Get help with voice commands',
    examples: ['Help', 'What can you do?'],
  },
  {
    trigger: ['repeat', 'say again'],
    type: 'repeat',
    description: 'Repeat last action or text',
    examples: ['Repeat', 'Say that again'],
  },
];

// ============================================================================
// VOICE INTEGRATION CLASS
// ============================================================================

/**
 * Voice Integration Manager
 * Wispr Flow-inspired voice processing for Kasbah
 */
export class VoiceIntegration {
  private settings: VoiceSettings;
  private sessions: Map<string, VoiceSession> = new Map();
  private analytics: VoiceAnalytics;
  private commandRegistry: Map<string, VoiceCommandDefinition> = new Map();
  private activeSession: VoiceSession | null = null;
  private transcriptionBuffer: string[] = [];
  private lastActivityTime: Date = new Date();

  constructor(settings: Partial<VoiceSettings> = {}) {
    this.settings = { ...DEFAULT_VOICE_SETTINGS, ...settings };
    this.analytics = this.initializeAnalytics();
    this.initializeCommandRegistry();
  }

  /**
   * Start a new voice session
   */
  startSession(
    mode: VoiceProcessingMode = 'mixed',
    userId?: string
  ): VoiceSession {
    const session: VoiceSession = {
      id: `session-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      userId,
      startedAt: new Date(),
      mode,
      language: this.settings.language,
      results: [],
      totalWordCount: 0,
      totalDuration: 0,
      averageWpm: 0,
      status: 'active',
    };

    this.sessions.set(session.id, session);
    this.activeSession = session;
    this.transcriptionBuffer = [];

    return session;
  }

  /**
   * Process audio data
   */
  async processAudio(
    audioData: ArrayBuffer | Buffer,
    options: {
      mode?: VoiceProcessingMode;
      sessionId?: string;
      context?: DeepfakeVoiceAnalysis;
    } = {}
  ): Promise<VoiceProcessingResult> {
    const startTime = Date.now();
    const session = options.sessionId
      ? this.sessions.get(options.sessionId)
      : this.activeSession;

    if (!session) {
      throw new Error('No active voice session');
    }

    // Transcribe audio using ASR
    const asrResult = await this.transcribeAudio(audioData);

    // Determine processing mode
    const mode = options.mode || session.mode;

    // Process based on mode
    let result: VoiceProcessingResult;

    switch (mode) {
      case 'command':
        result = await this.processAsCommand(asrResult, session);
        break;
      case 'analysis':
        result = await this.processAsAnalysis(asrResult, session, options.context);
        break;
      case 'report':
        result = await this.processAsReport(asrResult, session);
        break;
      default:
        result = await this.processMixed(asrResult, session, options.context);
    }

    // Auto-polish if enabled
    if (this.settings.autoPolish && result.transcript) {
      result.polishedText = await this.polishText(result.transcript, {
        style: this.settings.polishStyle,
        fixGrammar: true,
        improveClarity: true,
        adjustTone: 'neutral',
        preserveKeywords: [],
      });
    }

    // Update session
    session.results.push(result);
    session.totalWordCount += result.wordCount;
    session.totalDuration = Date.now() - session.startedAt.getTime();
    session.averageWpm = session.totalDuration > 0
      ? Math.round((session.totalWordCount / session.totalDuration) * 60000)
      : 0;

    // Update analytics
    this.updateAnalytics(result);

    result.processingTime = Date.now() - startTime;
    return result;
  }

  /**
   * Transcribe audio to text
   */
  private async transcribeAudio(audioData: ArrayBuffer | Buffer): Promise<ASRResult> {
    // Use ASR skill for transcription
    try {
      const asr = new ASR();
      const result = await asr.transcribe({
        audio: Buffer.isBuffer(audioData)
          ? audioData.toString('base64')
          : Buffer.from(audioData).toString('base64'),
        language: this.settings.language,
        enablePunctuation: this.settings.punctuationMode !== 'manual',
      });
      return result;
    } catch {
      // Fallback to simulated transcription
      return this.simulateTranscription(audioData);
    }
  }

  /**
   * Process text as voice command
   */
  private async processAsCommand(
    asrResult: ASRResult,
    session: VoiceSession
  ): Promise<VoiceProcessingResult> {
    const transcript = asrResult.text;
    const command = this.parseCommand(transcript);

    return {
      id: `result-${Date.now()}`,
      success: !!command,
      mode: 'command',
      transcript,
      command,
      confidence: command?.confidence || asrResult.confidence,
      processingTime: 0,
      language: session.language,
      wordCount: transcript.split(/\s+/).length,
      characterCount: transcript.length,
      wpm: 0,
    };
  }

  /**
   * Process text as deepfake analysis
   */
  private async processAsAnalysis(
    asrResult: ASRResult,
    session: VoiceSession,
    context?: DeepfakeVoiceAnalysis
  ): Promise<VoiceProcessingResult> {
    const transcript = asrResult.text;
    const analysis = this.parseAnalysisContext(transcript);

    return {
      id: `result-${Date.now()}`,
      success: true,
      mode: 'analysis',
      transcript,
      analysis: { ...analysis, ...context },
      confidence: asrResult.confidence,
      processingTime: 0,
      language: session.language,
      wordCount: transcript.split(/\s+/).length,
      characterCount: transcript.length,
      wpm: 0,
    };
  }

  /**
   * Process text as report generation
   */
  private async processAsReport(
    asrResult: ASRResult,
    session: VoiceSession
  ): Promise<VoiceProcessingResult> {
    const transcript = asrResult.text;

    return {
      id: `result-${Date.now()}`,
      success: true,
      mode: 'report',
      transcript,
      confidence: asrResult.confidence,
      processingTime: 0,
      language: session.language,
      wordCount: transcript.split(/\s+/).length,
      characterCount: transcript.length,
      wpm: 0,
    };
  }

  /**
   * Process in mixed mode (auto-detect)
   */
  private async processMixed(
    asrResult: ASRResult,
    session: VoiceSession,
    context?: DeepfakeVoiceAnalysis
  ): Promise<VoiceProcessingResult> {
    const transcript = asrResult.text;

    // Check if it's a command first
    const command = this.parseCommand(transcript);
    if (command && command.confidence > 0.8) {
      return this.processAsCommand(asrResult, session);
    }

    // Check for analysis keywords
    if (this.isAnalysisRequest(transcript)) {
      return this.processAsAnalysis(asrResult, session, context);
    }

    // Check for report request
    if (this.isReportRequest(transcript)) {
      return this.processAsReport(asrResult, session);
    }

    // Default to dictation
    return {
      id: `result-${Date.now()}`,
      success: true,
      mode: 'dictation',
      transcript,
      confidence: asrResult.confidence,
      processingTime: 0,
      language: session.language,
      wordCount: transcript.split(/\s+/).length,
      characterCount: transcript.length,
      wpm: this.calculateWpm(transcript, session.startedAt),
    };
  }

  /**
   * Polish text using AI
   */
  async polishText(
    text: string,
    options: PolishingOptions
  ): Promise<string> {
    try {
      const llm = new LLM();
      const prompt = this.buildPolishingPrompt(text, options);

      const result = await llm.chat({
        messages: [
          { role: 'system', content: 'You are a professional text editor. Polish the following text while preserving its meaning.' },
          { role: 'user', content: prompt },
        ],
        temperature: 0.3,
        maxTokens: text.length * 2,
      });

      return result.content || text;
    } catch {
      // Fallback to basic polishing
      return this.basicPolish(text, options);
    }
  }

  /**
   * Get detailed polishing result
   */
  async getDetailedPolishing(
    text: string,
    options: PolishingOptions
  ): Promise<PolishingResult> {
    const polished = await this.polishText(text, options);
    const changes = this.detectChanges(text, polished);

    return {
      original: text,
      polished,
      changes,
      readabilityScore: this.calculateReadability(polished),
      tone: options.adjustTone,
      wordCount: {
        original: text.split(/\s+/).length,
        polished: polished.split(/\s+/).length,
      },
    };
  }

  /**
   * Parse voice command from text
   */
  parseCommand(text: string): VoiceCommand | null {
    const normalizedText = text.toLowerCase().trim();

    for (const definition of VOICE_COMMANDS) {
      for (const trigger of definition.trigger) {
        if (normalizedText.includes(trigger)) {
          const params = this.extractParameters(text, definition);
          return {
            type: definition.type,
            parameters: params,
            confidence: this.calculateCommandConfidence(normalizedText, trigger),
            rawTranscript: text,
            action: async () => this.executeCommand(definition.type, params),
          };
        }
      }
    }

    return null;
  }

  /**
   * Execute a voice command
   */
  async executeCommand(
    type: VoiceCommandType,
    params: Record<string, unknown>
  ): Promise<unknown> {
    switch (type) {
      case 'analyze':
        return { action: 'analyze', params };
      case 'report':
        return { action: 'generate_report', format: params.format || 'json' };
      case 'stop':
        return { action: 'stop' };
      case 'pause':
        return { action: 'pause' };
      case 'resume':
        return { action: 'resume' };
      case 'export':
        return { action: 'export', format: params.format || 'json' };
      case 'clear':
        return { action: 'clear' };
      case 'polish':
        return { action: 'polish' };
      case 'summarize':
        return { action: 'summarize' };
      case 'translate':
        return { action: 'translate', language: params.language };
      case 'help':
        return {
          action: 'help',
          commands: VOICE_COMMANDS.map((c) => ({
            type: c.type,
            description: c.description,
            examples: c.examples,
          })),
        };
      default:
        return { action: type, params };
    }
  }

  /**
   * Get session by ID
   */
  getSession(sessionId: string): VoiceSession | undefined {
    return this.sessions.get(sessionId);
  }

  /**
   * End a voice session
   */
  endSession(sessionId?: string): VoiceSession | null {
    const session = sessionId
      ? this.sessions.get(sessionId)
      : this.activeSession;

    if (session) {
      session.endedAt = new Date();
      session.status = 'ended';

      if (this.activeSession?.id === session.id) {
        this.activeSession = null;
      }

      return session;
    }

    return null;
  }

  /**
   * Get voice analytics
   */
  getAnalytics(): VoiceAnalytics {
    return { ...this.analytics };
  }

  /**
   * Update settings
   */
  updateSettings(newSettings: Partial<VoiceSettings>): void {
    this.settings = { ...this.settings, ...newSettings };
  }

  /**
   * Get current settings
   */
  getSettings(): VoiceSettings {
    return { ...this.settings };
  }

  // ============================================================================
  // PRIVATE METHODS
  // ============================================================================

  private initializeAnalytics(): VoiceAnalytics {
    return {
      totalSessions: 0,
      totalDuration: 0,
      totalWords: 0,
      averageWpm: 0,
      languageDistribution: {},
      commandUsage: {} as Record<VoiceCommandType, number>,
      accuracyRate: 0,
      mostUsedCommands: [],
      averageSessionDuration: 0,
      peakUsageHours: [],
    };
  }

  private initializeCommandRegistry(): void {
    for (const command of VOICE_COMMANDS) {
      for (const trigger of command.trigger) {
        this.commandRegistry.set(trigger.toLowerCase(), command);
      }
    }
  }

  private simulateTranscription(audioData: ArrayBuffer | Buffer): ASRResult {
    const hash = this.simpleHash(Buffer.isBuffer(audioData) ? audioData : Buffer.from(audioData));
    const phrases = [
      'Analyze this image for deepfake indicators',
      'Generate a detailed report',
      'Quick scan this video',
      'Export results as PDF',
      'Check for AI-generated content',
      'Perform deep analysis',
    ];

    return {
      text: phrases[hash % phrases.length],
      confidence: 0.85 + (hash % 15) / 100,
      duration: 2000 + (hash % 3000),
    };
  }

  private parseAnalysisContext(text: string): DeepfakeVoiceAnalysis {
    const normalizedText = text.toLowerCase();
    const analysis: DeepfakeVoiceAnalysis = {};

    // Extract media type
    if (normalizedText.includes('image') || normalizedText.includes('photo')) {
      analysis.mediaType = 'image';
    } else if (normalizedText.includes('video')) {
      analysis.mediaType = 'video';
    } else if (normalizedText.includes('audio')) {
      analysis.mediaType = 'audio';
    }

    // Extract analysis depth
    if (normalizedText.includes('quick') || normalizedText.includes('fast')) {
      analysis.analysisDepth = 'quick';
    } else if (normalizedText.includes('deep') || normalizedText.includes('thorough')) {
      analysis.analysisDepth = 'deep';
    } else {
      analysis.analysisDepth = 'standard';
    }

    // Extract URL if present
    const urlMatch = text.match(/https?:\/\/[^\s]+/);
    if (urlMatch) {
      analysis.targetUrl = urlMatch[0];
    }

    return analysis;
  }

  private isAnalysisRequest(text: string): boolean {
    const keywords = ['analyze', 'scan', 'check', 'examine', 'detect', 'investigate'];
    const normalizedText = text.toLowerCase();
    return keywords.some((k) => normalizedText.includes(k));
  }

  private isReportRequest(text: string): boolean {
    const keywords = ['report', 'summary', 'document', 'export'];
    const normalizedText = text.toLowerCase();
    return keywords.some((k) => normalizedText.includes(k));
  }

  private extractParameters(
    text: string,
    definition: VoiceCommandDefinition
  ): Record<string, unknown> {
    const params: Record<string, unknown> = {};

    if (!definition.parameters) return params;

    for (const [name, config] of Object.entries(definition.parameters)) {
      // Simple parameter extraction
      const regex = new RegExp(`${name}\\s*(\\w+)`, 'i');
      const match = text.match(regex);
      if (match) {
        params[name] = config.type === 'number' ? parseInt(match[1]) : match[1];
      }
    }

    return params;
  }

  private calculateCommandConfidence(text: string, trigger: string): number {
    const triggerIndex = text.indexOf(trigger);
    if (triggerIndex === 0) return 0.95;
    if (triggerIndex > 0) return 0.85;
    return 0.7;
  }

  private buildPolishingPrompt(text: string, options: PolishingOptions): string {
    const styleGuides = {
      professional: 'Use formal language, clear structure, and professional tone.',
      casual: 'Use conversational language while maintaining clarity.',
      academic: 'Use scholarly language with proper citations and formal structure.',
      creative: 'Use engaging language with vivid descriptions and storytelling elements.',
    };

    const toneGuides = {
      neutral: 'Maintain a balanced, objective tone.',
      formal: 'Use formal language and proper etiquette.',
      friendly: 'Use warm, approachable language.',
      technical: 'Use precise technical terminology where appropriate.',
    };

    let prompt = `Polish the following text with these guidelines:
- Style: ${styleGuides[options.style]}
- Tone: ${toneGuides[options.adjustTone]}`;

    if (options.fixGrammar) {
      prompt += '\n- Fix any grammar errors';
    }
    if (options.improveClarity) {
      prompt += '\n- Improve clarity and readability';
    }
    if (options.maxLength) {
      prompt += `\n- Maximum length: ${options.maxLength} characters`;
    }
    if (options.preserveKeywords.length > 0) {
      prompt += `\n- Preserve these keywords: ${options.preserveKeywords.join(', ')}`;
    }
    if (options.targetAudience) {
      prompt += `\n- Target audience: ${options.targetAudience}`;
    }

    prompt += `\n\nOriginal text:\n"${text}"\n\nPolished text:`;

    return prompt;
  }

  private basicPolish(text: string, options: PolishingOptions): string {
    let polished = text;

    // Basic capitalization
    polished = polished.charAt(0).toUpperCase() + polished.slice(1);

    // Add period if missing
    if (!/[.!?]$/.test(polished.trim())) {
      polished = polished.trim() + '.';
    }

    // Fix double spaces
    polished = polished.replace(/\s+/g, ' ');

    return polished;
  }

  private detectChanges(original: string, polished: string): PolishingChange[] {
    const changes: PolishingChange[] = [];
    const originalWords = original.split(/\s+/);
    const polishedWords = polished.split(/\s+/);

    // Simple change detection
    for (let i = 0; i < Math.max(originalWords.length, polishedWords.length); i++) {
      if (originalWords[i] !== polishedWords[i]) {
        changes.push({
          type: 'style',
          original: originalWords[i] || '',
          corrected: polishedWords[i] || '',
          position: { start: i, end: i + 1 },
        });
      }
    }

    return changes;
  }

  private calculateReadability(text: string): number {
    // Flesch Reading Ease approximation
    const words = text.split(/\s+/);
    const sentences = text.split(/[.!?]+/).filter((s) => s.trim());
    const syllables = words.reduce((sum, word) => sum + this.countSyllables(word), 0);

    if (words.length === 0 || sentences.length === 0) return 0;

    const score =
      206.835 -
      1.015 * (words.length / sentences.length) -
      84.6 * (syllables / words.length);

    return Math.max(0, Math.min(100, score));
  }

  private countSyllables(word: string): number {
    word = word.toLowerCase();
    if (word.length <= 3) return 1;

    word = word.replace(/(?:[^laeiouy]es|ed|[^laeiouy]e)$/, '');
    word = word.replace(/^y/, '');

    const matches = word.match(/[aeiouy]{1,2}/g);
    return matches ? matches.length : 1;
  }

  private calculateWpm(text: string, startTime: Date): number {
    const words = text.split(/\s+/).length;
    const durationMs = Date.now() - startTime.getTime();
    const durationMinutes = durationMs / 60000;

    return durationMinutes > 0 ? Math.round(words / durationMinutes) : 0;
  }

  private updateAnalytics(result: VoiceProcessingResult): void {
    this.analytics.totalSessions = this.sessions.size;
    this.analytics.totalWords += result.wordCount;

    // Update language distribution
    if (!this.analytics.languageDistribution[result.language]) {
      this.analytics.languageDistribution[result.language] = 0;
    }
    this.analytics.languageDistribution[result.language]++;

    // Update command usage
    if (result.command) {
      if (!this.analytics.commandUsage[result.command.type]) {
        this.analytics.commandUsage[result.command.type] = 0;
      }
      this.analytics.commandUsage[result.command.type]++;
    }

    // Update most used commands
    this.analytics.mostUsedCommands = Object.entries(this.analytics.commandUsage)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([type]) => type as VoiceCommandType);
  }

  private simpleHash(buffer: Buffer): number {
    let hash = 0;
    for (let i = 0; i < Math.min(buffer.length, 1000); i++) {
      hash = (hash * 31 + buffer[i]) >>> 0;
    }
    return hash;
  }
}

// ============================================================================
// ASR AND LLM UTILITY STUBS
// ============================================================================

/**
 * ASR utility class stub
 */
class ASR {
  async transcribe(options: { audio: string; language: string; enablePunctuation: boolean }): Promise<ASRResult> {
    return {
      text: 'This is a simulated transcription.',
      confidence: 0.9,
      duration: 2000,
    };
  }
}

/**
 * LLM utility class stub
 */
class LLM {
  async chat(options: { messages: Array<{ role: string; content: string }>; temperature: number; maxTokens: number }): Promise<{ content: string }> {
    return {
      content: 'This is a simulated LLM response.',
    };
  }
}

/**
 * ASR Result interface
 */
interface ASRResult {
  text: string;
  confidence: number;
  duration: number;
}

// ============================================================================
// SINGLETON INSTANCE
// ============================================================================

let voiceIntegrationInstance: VoiceIntegration | null = null;

/**
 * Get the singleton instance of VoiceIntegration
 */
export function getVoiceIntegration(): VoiceIntegration {
  if (!voiceIntegrationInstance) {
    voiceIntegrationInstance = new VoiceIntegration();
  }
  return voiceIntegrationInstance;
}

/**
 * Initialize VoiceIntegration with custom settings
 */
export function initializeVoiceIntegration(
  settings: Partial<VoiceSettings>
): VoiceIntegration {
  voiceIntegrationInstance = new VoiceIntegration(settings);
  return voiceIntegrationInstance;
}

// ============================================================================
// EXPORTS
// ============================================================================

export default VoiceIntegration;
