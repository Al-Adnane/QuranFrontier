/**
 * Privacy-First Data Framework
 *
 * Inspired by Stanford HAI's "Rethinking Privacy in the AI Era" white paper
 * and IBM's AI Privacy insights.
 *
 * Key Principles:
 * 1. Opt-in by default (no data collection without affirmative consent)
 * 2. Data minimization (collect only what's necessary)
 * 3. Purpose limitation (use data only for stated purposes)
 * 4. Transparency (clear data supply chain tracking)
 * 5. Collective rights (data intermediary support)
 *
 * Reference: https://hai.stanford.edu/news/privacy-ai-era-how-do-we-protect-our-personal-information
 */

// ============================================================================
// Types and Interfaces
// ============================================================================

export interface ConsentRecord {
  id: string;
  userId: string;
  timestamp: Date;
  purposes: ConsentPurpose[];
  dataTypes: DataType[];
  retentionPeriod: number; // days
  withdrawalMechanism: string;
  consentReceipt: string;
  version: string;
  ipAddress?: string;
  userAgent?: string;
  geoLocation?: string;
}

export interface ConsentPurpose {
  id: string;
  name: string;
  description: string;
  category: PurposeCategory;
  legalBasis: LegalBasis;
  thirdPartySharing: boolean;
  thirdParties?: ThirdParty[];
  optInRequired: boolean;
  expiresAt?: Date;
}

export interface ThirdParty {
  id: string;
  name: string;
  purpose: string;
  dataTypes: DataType[];
  privacyPolicy: string;
  dpaSigned: boolean; // Data Processing Agreement
}

export type PurposeCategory =
  | 'deepfake_detection'
  | 'model_training'
  | 'analytics'
  | 'security'
  | 'research'
  | 'marketing'
  | 'third_party_sharing'
  | 'legal_compliance';

export type LegalBasis =
  | 'consent'
  | 'contract'
  | 'legal_obligation'
  | 'vital_interests'
  | 'public_task'
  | 'legitimate_interests';

export type DataType =
  | 'image'
  | 'video'
  | 'audio'
  | 'text'
  | 'metadata'
  | 'biometric'
  | 'behavioral'
  | 'location'
  | 'device_info'
  | 'ip_address'
  | 'user_agent';

export interface DataMinimizationConfig {
  enabled: boolean;
  maxRetentionDays: number;
  allowedDataTypes: DataType[];
  requiredFields: string[];
  optionalFields: string[];
  prohibitedFields: string[];
  anonymizationRequired: boolean;
  pseudonymizationRequired: boolean;
}

export interface PurposeLimitationRule {
  purposeId: string;
  allowedOperations: DataOperation[];
  prohibitedOperations: DataOperation[];
  auditRequired: boolean;
  approvalRequired: boolean;
  timeRestrictions?: TimeRestriction[];
}

export type DataOperation =
  | 'read'
  | 'write'
  | 'process'
  | 'analyze'
  | 'train'
  | 'share'
  | 'export'
  | 'delete'
  | 'anonymize'
  | 'aggregate';

export interface TimeRestriction {
  type: 'business_hours' | 'weekdays' | 'custom';
  allowedHours?: { start: number; end: number };
  allowedDays?: number[];
}

export interface PrivacySettings {
  globalOptIn: boolean;
  analyticsOptIn: boolean;
  trainingOptIn: boolean;
  thirdPartyOptIn: boolean;
  marketingOptIn: boolean;
  researchOptIn: boolean;
  biometricOptIn: boolean;
  locationOptIn: boolean;
  autoDeleteEnabled: boolean;
  autoDeleteDays: number;
  dataPortabilityEnabled: boolean;
  anonymousModeEnabled: boolean;
}

export interface PrivacyAuditLog {
  id: string;
  timestamp: Date;
  action: AuditAction;
  dataType: DataType;
  purpose: string;
  userId: string;
  dataSubject?: string;
  details: Record<string, unknown>;
  ipAddress: string;
  consentId?: string;
  result: 'allowed' | 'denied' | 'modified';
  reason?: string;
}

export type AuditAction =
  | 'consent_granted'
  | 'consent_withdrawn'
  | 'consent_updated'
  | 'data_accessed'
  | 'data_processed'
  | 'data_shared'
  | 'data_deleted'
  | 'data_exported'
  | 'data_anonymized'
  | 'privacy_settings_changed'
  | 'retention_applied'
  | 'breach_detected';

// ============================================================================
// Privacy-First Consent Manager
// ============================================================================

export class PrivacyFirstConsentManager {
  private consentRecords: Map<string, ConsentRecord> = new Map();
  private privacySettings: Map<string, PrivacySettings> = new Map();
  private auditLogs: PrivacyAuditLog[] = [];
  private defaultSettings: PrivacySettings;

  constructor() {
    // Default is OPT-OUT of everything (privacy-first approach)
    // Inspired by Apple's App Tracking Transparency where 80-90% opt out
    this.defaultSettings = {
      globalOptIn: false,
      analyticsOptIn: false,
      trainingOptIn: false,
      thirdPartyOptIn: false,
      marketingOptIn: false,
      researchOptIn: false,
      biometricOptIn: false,
      locationOptIn: false,
      autoDeleteEnabled: true,
      autoDeleteDays: 30,
      dataPortabilityEnabled: true,
      anonymousModeEnabled: true,
    };
  }

  /**
   * Request consent from user - OPT-IN required by default
   * Following Stanford HAI recommendation: data should not be collected
   * unless user makes an affirmative choice
   */
  async requestConsent(
    userId: string,
    purposes: ConsentPurpose[],
    dataTypes: DataType[],
    options?: {
      retentionPeriod?: number;
      ipAddress?: string;
      userAgent?: string;
    }
  ): Promise<ConsentRecord> {
    // Check if opt-in is required for any purpose
    const optInRequiredPurposes = purposes.filter((p) => p.optInRequired);
    if (optInRequiredPurposes.length > 0) {
      const currentSettings = this.privacySettings.get(userId) || this.defaultSettings;
      const hasConsent = this.checkConsentForPurposes(currentSettings, optInRequiredPurposes);

      if (!hasConsent) {
        throw new Error(
          `Opt-in consent required for purposes: ${optInRequiredPurposes.map((p) => p.name).join(', ')}`
        );
      }
    }

    const consentId = this.generateConsentId();
    const consentRecord: ConsentRecord = {
      id: consentId,
      userId,
      timestamp: new Date(),
      purposes,
      dataTypes,
      retentionPeriod: options?.retentionPeriod || 365,
      withdrawalMechanism: '/api/privacy/consent/withdraw',
      consentReceipt: this.generateConsentReceipt(consentId, userId, purposes),
      version: '1.0',
      ipAddress: options?.ipAddress,
      userAgent: options?.userAgent,
    };

    this.consentRecords.set(consentId, consentRecord);
    this.logAudit({
      id: this.generateAuditId(),
      timestamp: new Date(),
      action: 'consent_granted',
      dataType: dataTypes[0],
      purpose: purposes.map((p) => p.name).join(','),
      userId,
      details: { consentId, purposes, dataTypes },
      ipAddress: options?.ipAddress || 'unknown',
      consentId,
      result: 'allowed',
    });

    return consentRecord;
  }

  /**
   * Withdraw consent - immediate effect
   */
  async withdrawConsent(consentId: string, userId: string, reason?: string): Promise<void> {
    const record = this.consentRecords.get(consentId);
    if (!record) {
      throw new Error('Consent record not found');
    }

    if (record.userId !== userId) {
      throw new Error('Unauthorized: consent belongs to different user');
    }

    // Mark for deletion of associated data
    this.consentRecords.delete(consentId);

    this.logAudit({
      id: this.generateAuditId(),
      timestamp: new Date(),
      action: 'consent_withdrawn',
      dataType: record.dataTypes[0],
      purpose: record.purposes.map((p) => p.name).join(','),
      userId,
      details: { consentId, reason, withdrawnAt: new Date() },
      ipAddress: 'unknown',
      consentId,
      result: 'allowed',
    });
  }

  /**
   * Update privacy settings - granular control
   */
  async updatePrivacySettings(
    userId: string,
    settings: Partial<PrivacySettings>
  ): Promise<PrivacySettings> {
    const current = this.privacySettings.get(userId) || { ...this.defaultSettings };
    const updated = { ...current, ...settings };

    this.privacySettings.set(userId, updated);

    this.logAudit({
      id: this.generateAuditId(),
      timestamp: new Date(),
      action: 'privacy_settings_changed',
      dataType: 'behavioral',
      purpose: 'privacy_management',
      userId,
      details: { changes: settings, previousSettings: current },
      ipAddress: 'unknown',
      result: 'allowed',
    });

    return updated;
  }

  /**
   * Check if operation is permitted under consent
   */
  async checkConsent(
    userId: string,
    dataType: DataType,
    purpose: PurposeCategory,
    operation: DataOperation
  ): Promise<{ allowed: boolean; reason?: string }> {
    const settings = this.privacySettings.get(userId) || this.defaultSettings;

    // Check global opt-in
    if (!settings.globalOptIn) {
      return { allowed: false, reason: 'Global opt-in not granted' };
    }

    // Check purpose-specific consent
    const purposeConsent = this.checkPurposeConsent(settings, purpose);
    if (!purposeConsent.allowed) {
      return purposeConsent;
    }

    // Check data type restrictions
    const dataTypeConsent = this.checkDataTypeConsent(settings, dataType);
    if (!dataTypeConsent.allowed) {
      return dataTypeConsent;
    }

    // Check for valid consent record
    const activeConsent = this.findActiveConsent(userId, dataType, purpose);
    if (!activeConsent) {
      return { allowed: false, reason: 'No active consent record found' };
    }

    return { allowed: true };
  }

  /**
   * Generate GDPR-compliant consent receipt
   */
  private generateConsentReceipt(
    consentId: string,
    userId: string,
    purposes: ConsentPurpose[]
  ): string {
    const receipt = {
      version: '1.0',
      consentId,
      publicKey: 'kasbah-deepfake-detector',
      jurisdiction: 'global',
      consentTimestamp: new Date().toISOString(),
      collectionMethod: 'digital_form',
      language: 'en',
      dataController: {
        name: 'Kasbah Deepfake Detector',
        id: 'kasbah-ai-inc',
      },
      purposes: purposes.map((p) => ({
        id: p.id,
        name: p.name,
        legalBasis: p.legalBasis,
        category: p.category,
      })),
      consentReceiptURL: `https://kasbah.ai/privacy/receipt/${consentId}`,
    };

    return Buffer.from(JSON.stringify(receipt)).toString('base64');
  }

  private checkConsentForPurposes(
    settings: PrivacySettings,
    purposes: ConsentPurpose[]
  ): boolean {
    return purposes.every((purpose) => {
      switch (purpose.category) {
        case 'analytics':
          return settings.analyticsOptIn;
        case 'model_training':
          return settings.trainingOptIn;
        case 'marketing':
          return settings.marketingOptIn;
        case 'research':
          return settings.researchOptIn;
        case 'third_party_sharing':
          return settings.thirdPartyOptIn;
        default:
          return settings.globalOptIn;
      }
    });
  }

  private checkPurposeConsent(
    settings: PrivacySettings,
    purpose: PurposeCategory
  ): { allowed: boolean; reason?: string } {
    switch (purpose) {
      case 'analytics':
        return settings.analyticsOptIn
          ? { allowed: true }
          : { allowed: false, reason: 'Analytics opt-in not granted' };
      case 'model_training':
        return settings.trainingOptIn
          ? { allowed: true }
          : { allowed: false, reason: 'Training opt-in not granted' };
      case 'marketing':
        return settings.marketingOptIn
          ? { allowed: true }
          : { allowed: false, reason: 'Marketing opt-in not granted' };
      case 'research':
        return settings.researchOptIn
          ? { allowed: true }
          : { allowed: false, reason: 'Research opt-in not granted' };
      case 'third_party_sharing':
        return settings.thirdPartyOptIn
          ? { allowed: true }
          : { allowed: false, reason: 'Third-party sharing opt-in not granted' };
      default:
        return settings.globalOptIn
          ? { allowed: true }
          : { allowed: false, reason: 'Global opt-in not granted' };
    }
  }

  private checkDataTypeConsent(
    settings: PrivacySettings,
    dataType: DataType
  ): { allowed: boolean; reason?: string } {
    switch (dataType) {
      case 'biometric':
        return settings.biometricOptIn
          ? { allowed: true }
          : { allowed: false, reason: 'Biometric data opt-in not granted' };
      case 'location':
        return settings.locationOptIn
          ? { allowed: true }
          : { allowed: false, reason: 'Location data opt-in not granted' };
      default:
        return { allowed: true };
    }
  }

  private findActiveConsent(
    userId: string,
    dataType: DataType,
    purpose: PurposeCategory
  ): ConsentRecord | null {
    for (const record of this.consentRecords.values()) {
      if (
        record.userId === userId &&
        record.dataTypes.includes(dataType) &&
        record.purposes.some((p) => p.category === purpose)
      ) {
        // Check if consent has expired
        const expiresAt = new Date(
          record.timestamp.getTime() + record.retentionPeriod * 24 * 60 * 60 * 1000
        );
        if (expiresAt > new Date()) {
          return record;
        }
      }
    }
    return null;
  }

  private logAudit(audit: PrivacyAuditLog): void {
    this.auditLogs.push(audit);
  }

  private generateConsentId(): string {
    return `consent_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private generateAuditId(): string {
    return `audit_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  // Getters
  getPrivacySettings(userId: string): PrivacySettings {
    return this.privacySettings.get(userId) || this.defaultSettings;
  }

  getAuditLogs(userId?: string): PrivacyAuditLog[] {
    if (userId) {
      return this.auditLogs.filter((log) => log.userId === userId);
    }
    return [...this.auditLogs];
  }

  getConsentRecord(consentId: string): ConsentRecord | undefined {
    return this.consentRecords.get(consentId);
  }
}

// ============================================================================
// Data Minimization Engine
// ============================================================================

export class DataMinimizationEngine {
  private configs: Map<string, DataMinimizationConfig> = new Map();

  constructor() {
    this.initializeDefaultConfigs();
  }

  /**
   * Apply data minimization to input data
   * Removes unnecessary fields and applies anonymization where required
   */
  minimizeData(
    purpose: PurposeCategory,
    data: Record<string, unknown>
  ): Record<string, unknown> {
    const config = this.configs.get(purpose);
    if (!config || !config.enabled) {
      return data;
    }

    const minimized: Record<string, unknown> = {};

    // Only include required fields
    for (const field of config.requiredFields) {
      if (data[field] !== undefined) {
        minimized[field] = data[field];
      }
    }

    // Include allowed optional fields
    for (const field of config.optionalFields) {
      if (data[field] !== undefined && config.allowedDataTypes.length > 0) {
        minimized[field] = data[field];
      }
    }

    // Remove prohibited fields
    for (const field of config.prohibitedFields) {
      delete minimized[field];
    }

    // Apply anonymization if required
    if (config.anonymizationRequired) {
      this.applyAnonymization(minimized);
    }

    // Apply pseudonymization if required
    if (config.pseudonymizationRequired) {
      this.applyPseudonymization(minimized);
    }

    return minimized;
  }

  /**
   * Validate data against minimization rules
   */
  validateData(
    purpose: PurposeCategory,
    data: Record<string, unknown>
  ): { valid: boolean; issues: string[] } {
    const config = this.configs.get(purpose);
    const issues: string[] = [];

    if (!config) {
      return { valid: true, issues: [] };
    }

    // Check for missing required fields
    for (const field of config.requiredFields) {
      if (data[field] === undefined) {
        issues.push(`Missing required field: ${field}`);
      }
    }

    // Check for prohibited fields
    for (const field of config.prohibitedFields) {
      if (data[field] !== undefined) {
        issues.push(`Prohibited field present: ${field}`);
      }
    }

    // Check retention period
    if (data['retentionDays'] && typeof data['retentionDays'] === 'number') {
      if (data['retentionDays'] > config.maxRetentionDays) {
        issues.push(
          `Retention period exceeds maximum allowed: ${config.maxRetentionDays} days`
        );
      }
    }

    return { valid: issues.length === 0, issues };
  }

  private applyAnonymization(data: Record<string, unknown>): void {
    // Remove direct identifiers
    const identifierFields = ['email', 'name', 'phone', 'ssn', 'ipAddress', 'address'];
    for (const field of identifierFields) {
      delete data[field];
    }

    // Hash any remaining PII-like fields
    for (const key of Object.keys(data)) {
      if (typeof data[key] === 'string') {
        const value = data[key] as string;
        if (this.looksLikePII(value)) {
          data[key] = this.hashValue(value);
        }
      }
    }
  }

  private applyPseudonymization(data: Record<string, unknown>): void {
    // Replace identifiers with pseudonyms
    const pseudonymMap = new Map<string, string>();

    for (const key of Object.keys(data)) {
      if (typeof data[key] === 'string') {
        const value = data[key] as string;
        if (this.looksLikePII(value)) {
          let pseudonym = pseudonymMap.get(value);
          if (!pseudonym) {
            pseudonym = `user_${pseudonymMap.size + 1}`;
            pseudonymMap.set(value, pseudonym);
          }
          data[key] = pseudonym;
        }
      }
    }
  }

  private looksLikePII(value: string): boolean {
    // Email pattern
    if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) return true;
    // Phone pattern
    if (/^\+?[\d\s\-()]{10,}$/.test(value)) return true;
    // SSN pattern
    if (/^\d{3}-\d{2}-\d{4}$/.test(value)) return true;
    return false;
  }

  private hashValue(value: string): string {
    // Simple hash for anonymization (in production, use crypto)
    let hash = 0;
    for (let i = 0; i < value.length; i++) {
      const char = value.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash = hash & hash;
    }
    return `anon_${Math.abs(hash).toString(16)}`;
  }

  private initializeDefaultConfigs(): void {
    // Deepfake detection - minimal data needed
    this.configs.set('deepfake_detection', {
      enabled: true,
      maxRetentionDays: 30,
      allowedDataTypes: ['image', 'video', 'audio'],
      requiredFields: ['mediaUrl', 'mediaType'],
      optionalFields: ['metadata'],
      prohibitedFields: ['ipAddress', 'location', 'userAgent', 'email'],
      anonymizationRequired: true,
      pseudonymizationRequired: false,
    });

    // Model training - stricter requirements
    this.configs.set('model_training', {
      enabled: true,
      maxRetentionDays: 90,
      allowedDataTypes: ['image', 'video', 'audio', 'metadata'],
      requiredFields: ['mediaUrl', 'mediaType', 'label'],
      optionalFields: ['annotations'],
      prohibitedFields: ['ipAddress', 'location', 'userAgent', 'email', 'name', 'phone'],
      anonymizationRequired: true,
      pseudonymizationRequired: true,
    });

    // Analytics - highest privacy
    this.configs.set('analytics', {
      enabled: true,
      maxRetentionDays: 7,
      allowedDataTypes: ['behavioral'],
      requiredFields: ['event'],
      optionalFields: ['timestamp'],
      prohibitedFields: [
        'ipAddress',
        'location',
        'userAgent',
        'email',
        'name',
        'phone',
        'mediaUrl',
      ],
      anonymizationRequired: true,
      pseudonymizationRequired: true,
    });
  }

  getConfig(purpose: PurposeCategory): DataMinimizationConfig | undefined {
    return this.configs.get(purpose);
  }

  setConfig(purpose: PurposeCategory, config: DataMinimizationConfig): void {
    this.configs.set(purpose, config);
  }
}

// ============================================================================
// Purpose Limitation Enforcer
// ============================================================================

export class PurposeLimitationEnforcer {
  private rules: Map<string, PurposeLimitationRule> = new Map();

  constructor() {
    this.initializeDefaultRules();
  }

  /**
   * Check if an operation is allowed for a purpose
   */
  async checkOperation(
    purpose: PurposeCategory,
    operation: DataOperation,
    context?: { userId?: string; dataType?: DataType }
  ): Promise<{ allowed: boolean; reason?: string }> {
    const rule = this.rules.get(purpose);
    if (!rule) {
      return { allowed: false, reason: `No rules defined for purpose: ${purpose}` };
    }

    // Check if operation is explicitly allowed
    if (rule.allowedOperations.includes(operation)) {
      // Check time restrictions
      if (rule.timeRestrictions) {
        const timeCheck = this.checkTimeRestrictions(rule.timeRestrictions);
        if (!timeCheck.allowed) {
          return timeCheck;
        }
      }

      // Check if approval is required
      if (rule.approvalRequired) {
        // In production, check approval system
        return { allowed: true, reason: 'Approval required - pending' };
      }

      return { allowed: true };
    }

    // Check if operation is explicitly prohibited
    if (rule.prohibitedOperations.includes(operation)) {
      return { allowed: false, reason: `Operation ${operation} is prohibited for purpose ${purpose}` };
    }

    // Default deny
    return { allowed: false, reason: `Operation ${operation} not explicitly allowed for purpose ${purpose}` };
  }

  private checkTimeRestrictions(
    restrictions: TimeRestriction[]
  ): { allowed: boolean; reason?: string } {
    const now = new Date();
    const currentHour = now.getHours();
    const currentDay = now.getDay();

    for (const restriction of restrictions) {
      switch (restriction.type) {
        case 'business_hours':
          if (currentHour < 9 || currentHour >= 17) {
            return { allowed: false, reason: 'Operation only allowed during business hours' };
          }
          break;
        case 'weekdays':
          if (currentDay === 0 || currentDay === 6) {
            return { allowed: false, reason: 'Operation only allowed on weekdays' };
          }
          break;
        case 'custom':
          if (restriction.allowedHours) {
            if (
              currentHour < restriction.allowedHours.start ||
              currentHour >= restriction.allowedHours.end
            ) {
              return {
                allowed: false,
                reason: `Operation only allowed between ${restriction.allowedHours.start} and ${restriction.allowedHours.end}`,
              };
            }
          }
          if (restriction.allowedDays && !restriction.allowedDays.includes(currentDay)) {
            return { allowed: false, reason: 'Operation not allowed on this day' };
          }
          break;
      }
    }

    return { allowed: true };
  }

  private initializeDefaultRules(): void {
    // Deepfake detection rules
    this.rules.set('deepfake_detection', {
      purposeId: 'deepfake_detection',
      allowedOperations: ['read', 'process', 'analyze'],
      prohibitedOperations: ['train', 'share', 'export'],
      auditRequired: true,
      approvalRequired: false,
    });

    // Model training rules
    this.rules.set('model_training', {
      purposeId: 'model_training',
      allowedOperations: ['read', 'process', 'analyze', 'train'],
      prohibitedOperations: ['share', 'export'],
      auditRequired: true,
      approvalRequired: true,
      timeRestrictions: [{ type: 'business_hours' }],
    });

    // Third-party sharing rules (most restrictive)
    this.rules.set('third_party_sharing', {
      purposeId: 'third_party_sharing',
      allowedOperations: ['read', 'export'],
      prohibitedOperations: ['train', 'process', 'analyze'],
      auditRequired: true,
      approvalRequired: true,
    });
  }

  getRule(purpose: PurposeCategory): PurposeLimitationRule | undefined {
    return this.rules.get(purpose);
  }
}

// ============================================================================
// Global Privacy Control (GPC) Support
// ============================================================================

export interface GPCSignal {
  enabled: boolean;
  timestamp: Date;
  source: 'browser' | 'extension' | 'app';
}

export class GlobalPrivacyControlSupport {
  private gpcSignals: Map<string, GPCSignal> = new Map();

  /**
   * Check if GPC signal is present
   * Following California CPPA regulations
   */
  checkGPCSignal(request: Request): GPCSignal | null {
    // Check for GPC header
    const gpcHeader = request.headers.get('Sec-GPC');
    if (gpcHeader === '1') {
      return {
        enabled: true,
        timestamp: new Date(),
        source: 'browser',
      };
    }

    // Check for DNT header (legacy)
    const dntHeader = request.headers.get('DNT');
    if (dntHeader === '1') {
      return {
        enabled: true,
        timestamp: new Date(),
        source: 'browser',
      };
    }

    return null;
  }

  /**
   * Apply GPC restrictions
   * If GPC is enabled, do not sell/share data
   */
  applyGPCRestrictions(
    userId: string,
    signal: GPCSignal
  ): PrivacySettings {
    this.gpcSignals.set(userId, signal);

    // Return maximally restricted settings
    return {
      globalOptIn: false,
      analyticsOptIn: false,
      trainingOptIn: false,
      thirdPartyOptIn: false,
      marketingOptIn: false,
      researchOptIn: false,
      biometricOptIn: false,
      locationOptIn: false,
      autoDeleteEnabled: true,
      autoDeleteDays: 1, // Minimal retention
      dataPortabilityEnabled: true,
      anonymousModeEnabled: true,
    };
  }

  getGPCSignal(userId: string): GPCSignal | undefined {
    return this.gpcSignals.get(userId);
  }
}

// ============================================================================
// Export unified privacy framework
// ============================================================================

export class PrivacyFirstFramework {
  public consent: PrivacyFirstConsentManager;
  public minimization: DataMinimizationEngine;
  public limitation: PurposeLimitationEnforcer;
  public gpc: GlobalPrivacyControlSupport;

  constructor() {
    this.consent = new PrivacyFirstConsentManager();
    this.minimization = new DataMinimizationEngine();
    this.limitation = new PurposeLimitationEnforcer();
    this.gpc = new GlobalPrivacyControlSupport();
  }

  /**
   * Process data with full privacy protections
   */
  async processWithPrivacy(
    userId: string,
    purpose: PurposeCategory,
    dataType: DataType,
    operation: DataOperation,
    data: Record<string, unknown>
  ): Promise<{
    success: boolean;
    data?: Record<string, unknown>;
    error?: string;
    auditId?: string;
  }> {
    // 1. Check consent
    const consentCheck = await this.consent.checkConsent(userId, dataType, purpose, operation);
    if (!consentCheck.allowed) {
      return { success: false, error: consentCheck.reason };
    }

    // 2. Check purpose limitation
    const operationCheck = await this.limitation.checkOperation(purpose, operation);
    if (!operationCheck.allowed) {
      return { success: false, error: operationCheck.reason };
    }

    // 3. Apply data minimization
    const minimizedData = this.minimization.minimizeData(purpose, data);

    // 4. Validate minimized data
    const validation = this.minimization.validateData(purpose, minimizedData);
    if (!validation.valid) {
      return { success: false, error: validation.issues.join('; ') };
    }

    // 5. Log audit
    const auditId = `audit_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    return { success: true, data: minimizedData, auditId };
  }
}

// Singleton instance
export const privacyFramework = new PrivacyFirstFramework();
