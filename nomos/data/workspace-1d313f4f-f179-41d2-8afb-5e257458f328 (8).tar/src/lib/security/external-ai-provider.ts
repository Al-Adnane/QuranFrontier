/**
 * External AI Provider Integration Module
 * Compatible with Thaura.ai API and similar ethical AI platforms
 * 
 * Features:
 * - Multi-provider support (Thaura, OpenAI-compatible, custom)
 * - Multi-modal attachments (Image, PDF, Audio analysis)
 * - Function calling framework for deepfake detection
 * - Streaming SSE support for real-time analysis
 * - Privacy-first design with no training on user data
 * - Ethical AI verification and alignment
 * 
 * @module ExternalAIProvider
 * @version 1.0.0
 * @author Kasbah Security Team
 */

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

/**
 * Supported AI providers
 */
export type AIProvider = 'thaura' | 'openai' | 'anthropic' | 'local' | 'custom';

/**
 * Provider configuration
 */
export interface ProviderConfig {
  name: string;
  endpoint: string;
  apiKey?: string;
  model: string;
  maxTokens: number;
  temperature: number;
  timeout: number;
  retryAttempts: number;
  retryDelay: number;
  streamEnabled: boolean;
  ethicalAlignment: boolean;
  privacyFirst: boolean;
  noTraining: boolean;
}

/**
 * Message role types
 */
export type MessageRole = 'system' | 'user' | 'assistant' | 'function' | 'tool';

/**
 * Chat message
 */
export interface ChatMessage {
  role: MessageRole;
  content: string;
  name?: string;
  functionCall?: FunctionCall;
  toolCalls?: ToolCall[];
}

/**
 * Function call structure
 */
export interface FunctionCall {
  name: string;
  arguments: string;
}

/**
 * Tool call structure
 */
export interface ToolCall {
  id: string;
  type: 'function';
  function: FunctionCall;
}

/**
 * Function definition for tools
 */
export interface FunctionDefinition {
  name: string;
  description: string;
  parameters: JSONSchema;
  required?: string[];
}

/**
 * JSON Schema definition
 */
export interface JSONSchema {
  type: string;
  properties?: Record<string, JSONSchema>;
  items?: JSONSchema;
  required?: string[];
  enum?: string[];
  description?: string;
  default?: unknown;
  minimum?: number;
  maximum?: number;
  minLength?: number;
  maxLength?: number;
  pattern?: string;
  format?: string;
}

/**
 * Tool definition
 */
export interface ToolDefinition {
  type: 'function';
  function: FunctionDefinition;
}

/**
 * Attachment types
 */
export type AttachmentType = 'image' | 'pdf' | 'audio' | 'video' | 'document';

/**
 * File attachment
 */
export interface FileAttachment {
  type: AttachmentType;
  mimeType: string;
  data: string; // Base64 encoded
  filename?: string;
  size?: number;
  metadata?: Record<string, unknown>;
}

/**
 * Completion request
 */
export interface CompletionRequest {
  messages: ChatMessage[];
  model?: string;
  temperature?: number;
  maxTokens?: number;
  stream?: boolean;
  streamOptions?: {
    includeUsage?: boolean;
  };
  tools?: ToolDefinition[];
  toolChoice?: 'auto' | 'required' | 'none' | string;
  parallelToolCalls?: boolean;
  attachments?: FileAttachment[];
  responseFormat?: {
    type: 'text' | 'json_object';
  };
  metadata?: Record<string, unknown>;
}

/**
 * Completion response
 */
export interface CompletionResponse {
  id: string;
  object: string;
  created: number;
  model: string;
  choices: CompletionChoice[];
  usage: TokenUsage;
  ethicalScore?: number;
  privacyScore?: number;
}

/**
 * Completion choice
 */
export interface CompletionChoice {
  index: number;
  message: ChatMessage;
  finishReason: string;
}

/**
 * Token usage
 */
export interface TokenUsage {
  promptTokens: number;
  completionTokens: number;
  totalTokens: number;
}

/**
 * Streaming chunk
 */
export interface StreamingChunk {
  id: string;
  object: string;
  created: number;
  model: string;
  choices: StreamingChoice[];
  usage?: TokenUsage;
}

/**
 * Streaming choice
 */
export interface StreamingChoice {
  index: number;
  delta: {
    role?: MessageRole;
    content?: string;
    functionCall?: FunctionCall;
    toolCalls?: ToolCall[];
  };
  finishReason: string | null;
}

/**
 * API key information
 */
export interface APIKeyInfo {
  id: string;
  provider: AIProvider;
  keyPrefix: string;
  createdAt: Date;
  lastUsed?: Date;
  isActive: boolean;
  rateLimit: number;
  usageLimit?: number;
  currentUsage: number;
}

/**
 * Usage record
 */
export interface UsageRecord {
  id: string;
  providerId: string;
  timestamp: Date;
  requestTokens: number;
  responseTokens: number;
  totalTokens: number;
  model: string;
  endpoint: string;
  success: boolean;
  latencyMs: number;
  ethicalScore?: number;
}

/**
 * Ethical AI verification result
 */
export interface EthicalVerification {
  isCompliant: boolean;
  score: number;
  violations: string[];
  recommendations: string[];
  alignmentScore: number;
  privacyScore: number;
  biasScore: number;
  transparencyScore: number;
}

/**
 * Provider health status
 */
export interface ProviderHealth {
  provider: AIProvider;
  status: 'healthy' | 'degraded' | 'down';
  latency: number;
  successRate: number;
  lastCheck: Date;
  errors: string[];
}

// ============================================================================
// PROVIDER CONFIGURATIONS
// ============================================================================

/**
 * Default provider configurations
 */
export const DEFAULT_PROVIDERS: Record<AIProvider, ProviderConfig> = {
  thaura: {
    name: 'Thaura AI',
    endpoint: 'https://backend.thaura.ai/v1',
    model: 'thaura',
    maxTokens: 4096,
    temperature: 0.7,
    timeout: 60000,
    retryAttempts: 3,
    retryDelay: 1000,
    streamEnabled: true,
    ethicalAlignment: true,
    privacyFirst: true,
    noTraining: true,
  },
  openai: {
    name: 'OpenAI',
    endpoint: 'https://api.openai.com/v1',
    model: 'gpt-4o',
    maxTokens: 4096,
    temperature: 0.7,
    timeout: 60000,
    retryAttempts: 3,
    retryDelay: 1000,
    streamEnabled: true,
    ethicalAlignment: false,
    privacyFirst: false,
    noTraining: false,
  },
  anthropic: {
    name: 'Anthropic',
    endpoint: 'https://api.anthropic.com/v1',
    model: 'claude-3-opus-20240229',
    maxTokens: 4096,
    temperature: 0.7,
    timeout: 60000,
    retryAttempts: 3,
    retryDelay: 1000,
    streamEnabled: true,
    ethicalAlignment: true,
    privacyFirst: true,
    noTraining: true,
  },
  local: {
    name: 'Local Model',
    endpoint: 'http://localhost:11434/v1',
    model: 'llama3.1:70b',
    maxTokens: 4096,
    temperature: 0.7,
    timeout: 120000,
    retryAttempts: 2,
    retryDelay: 2000,
    streamEnabled: true,
    ethicalAlignment: true,
    privacyFirst: true,
    noTraining: true,
  },
  custom: {
    name: 'Custom Provider',
    endpoint: '',
    model: 'custom',
    maxTokens: 4096,
    temperature: 0.7,
    timeout: 60000,
    retryAttempts: 3,
    retryDelay: 1000,
    streamEnabled: false,
    ethicalAlignment: false,
    privacyFirst: false,
    noTraining: false,
  },
};

// ============================================================================
// DEEPFAKE DETECTION TOOLS
// ============================================================================

/**
 * Deepfake detection tool definitions
 */
export const DEEPFAKE_DETECTION_TOOLS: ToolDefinition[] = [
  {
    type: 'function',
    function: {
      name: 'analyze_image_manipulation',
      description: 'Analyze an image for signs of AI-generated content, manipulation, or deepfake artifacts',
      parameters: {
        type: 'object',
        properties: {
          imageData: {
            type: 'string',
            description: 'Base64 encoded image data',
          },
          analysisDepth: {
            type: 'string',
            enum: ['quick', 'standard', 'deep'],
            description: 'Depth of analysis to perform',
          },
          detectSpecificArtifacts: {
            type: 'array',
            items: { type: 'string' },
            description: 'Specific artifacts to detect (e.g., GAN artifacts, noise patterns, color inconsistencies)',
          },
        },
        required: ['imageData'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'analyze_audio_deepfake',
      description: 'Analyze audio for signs of synthetic voice generation, cloning, or manipulation',
      parameters: {
        type: 'object',
        properties: {
          audioData: {
            type: 'string',
            description: 'Base64 encoded audio data',
          },
          voiceprintComparison: {
            type: 'string',
            description: 'Known voiceprint to compare against (optional)',
          },
          analysisType: {
            type: 'string',
            enum: ['voice_cloning', 'synthetic_speech', 'audio_manipulation', 'full'],
            description: 'Type of audio analysis to perform',
          },
        },
        required: ['audioData'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'analyze_video_deepfake',
      description: 'Analyze video content for deepfake indicators including face swaps, lip-sync manipulation, and AI-generated footage',
      parameters: {
        type: 'object',
        properties: {
          videoData: {
            type: 'string',
            description: 'Base64 encoded video data or URL',
          },
          frameAnalysis: {
            type: 'boolean',
            description: 'Whether to perform frame-by-frame analysis',
          },
          audioVideoSync: {
            type: 'boolean',
            description: 'Check audio-video synchronization for manipulation',
          },
        },
        required: ['videoData'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'verify_document_authenticity',
      description: 'Verify the authenticity of a document, detect AI-generated text or manipulated content',
      parameters: {
        type: 'object',
        properties: {
          documentData: {
            type: 'string',
            description: 'Base64 encoded document data',
          },
          documentType: {
            type: 'string',
            enum: ['pdf', 'image', 'text'],
            description: 'Type of document',
          },
          checkAI: {
            type: 'boolean',
            description: 'Check for AI-generated text',
          },
          checkMetadata: {
            type: 'boolean',
            description: 'Analyze document metadata for manipulation',
          },
        },
        required: ['documentData', 'documentType'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'cross_reference_sources',
      description: 'Cross-reference content against known sources to verify authenticity and detect potential deepfakes',
      parameters: {
        type: 'object',
        properties: {
          content: {
            type: 'string',
            description: 'Content to cross-reference',
          },
          sourceType: {
            type: 'string',
            enum: ['image', 'video', 'audio', 'text'],
            description: 'Type of content',
          },
          searchDepth: {
            type: 'string',
            enum: ['surface', 'deep', 'comprehensive'],
            description: 'Depth of source search',
          },
        },
        required: ['content', 'sourceType'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'assess_credibility',
      description: 'Assess the overall credibility of media content using multiple indicators',
      parameters: {
        type: 'object',
        properties: {
          mediaType: {
            type: 'string',
            enum: ['image', 'video', 'audio', 'document', 'mixed'],
            description: 'Type of media',
          },
          analysisResults: {
            type: 'object',
            description: 'Results from previous analysis steps',
          },
          context: {
            type: 'string',
            description: 'Additional context about the media',
          },
        },
        required: ['mediaType', 'analysisResults'],
      },
    },
  },
];

// ============================================================================
// EXTERNAL AI PROVIDER CLASS
// ============================================================================

/**
 * External AI Provider Manager
 * Handles communication with external AI providers like Thaura.ai
 */
export class ExternalAIProviderManager {
  private providers: Map<AIProvider, ProviderConfig> = new Map();
  private apiKeys: Map<AIProvider, string> = new Map();
  private usageRecords: UsageRecord[] = [];
  private healthStatus: Map<AIProvider, ProviderHealth> = new Map();
  private requestQueue: Map<AIProvider, PendingRequest[]> = new Map();
  private rateLimiters: Map<AIProvider, RateLimiter> = new Map();

  constructor() {
    // Initialize default providers
    for (const [provider, config] of Object.entries(DEFAULT_PROVIDERS)) {
      this.providers.set(provider as AIProvider, config);
      this.rateLimiters.set(provider as AIProvider, new RateLimiter(60, 60000)); // 60 requests per minute
    }
  }

  /**
   * Configure a provider
   */
  configureProvider(provider: AIProvider, config: Partial<ProviderConfig>): void {
    const existing = this.providers.get(provider);
    if (existing) {
      this.providers.set(provider, { ...existing, ...config });
    } else {
      this.providers.set(provider, config as ProviderConfig);
    }
  }

  /**
   * Set API key for a provider
   */
  setAPIKey(provider: AIProvider, apiKey: string): void {
    this.apiKeys.set(provider, apiKey);
  }

  /**
   * Create a completion request
   */
  async createCompletion(
    provider: AIProvider,
    request: CompletionRequest
  ): Promise<CompletionResponse> {
    const config = this.providers.get(provider);
    if (!config) {
      throw new Error(`Provider ${provider} not configured`);
    }

    const apiKey = this.apiKeys.get(provider);
    if (!apiKey && provider !== 'local') {
      throw new Error(`API key not set for provider ${provider}`);
    }

    // Check rate limit
    const limiter = this.rateLimiters.get(provider);
    if (limiter && !limiter.canMakeRequest()) {
      throw new Error(`Rate limit exceeded for provider ${provider}`);
    }

    // Prepare request
    const preparedRequest = this.prepareRequest(config, request);

    // Make request with retry
    return this.makeRequestWithRetry(provider, config, preparedRequest, apiKey);
  }

  /**
   * Create a streaming completion
   */
  async *createStreamingCompletion(
    provider: AIProvider,
    request: CompletionRequest
  ): AsyncGenerator<StreamingChunk, void, unknown> {
    const config = this.providers.get(provider);
    if (!config || !config.streamEnabled) {
      throw new Error(`Streaming not enabled for provider ${provider}`);
    }

    const apiKey = this.apiKeys.get(provider);
    if (!apiKey && provider !== 'local') {
      throw new Error(`API key not set for provider ${provider}`);
    }

    // Check rate limit
    const limiter = this.rateLimiters.get(provider);
    if (limiter && !limiter.canMakeRequest()) {
      throw new Error(`Rate limit exceeded for provider ${provider}`);
    }

    const preparedRequest = { ...request, stream: true };
    const startTime = Date.now();

    try {
      const response = await fetch(`${config.endpoint}/chat/completions`, {
        method: 'POST',
        headers: this.getHeaders(apiKey),
        body: JSON.stringify(preparedRequest),
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const reader = response.body?.getReader();
      if (!reader) {
        throw new Error('No response body');
      }

      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6);
            if (data === '[DONE]') {
              return;
            }
            try {
              const chunk = JSON.parse(data) as StreamingChunk;
              yield chunk;
            } catch {
              // Skip invalid JSON
            }
          }
        }
      }
    } finally {
      this.recordUsage(provider, request, Date.now() - startTime, true);
    }
  }

  /**
   * Analyze media for deepfakes using AI
   */
  async analyzeMediaForDeepfake(
    provider: AIProvider,
    mediaData: string,
    mediaType: 'image' | 'video' | 'audio',
    options?: {
      analysisDepth?: 'quick' | 'standard' | 'deep';
      additionalContext?: string;
    }
  ): Promise<{
    isDeepfake: boolean;
    confidence: number;
    analysis: string;
    artifacts: string[];
    recommendations: string[];
  }> {
    const tools = DEEPFAKE_DETECTION_TOOLS.filter((t) =>
      t.function.name.includes(mediaType)
    );

    const systemPrompt = `You are an expert deepfake detection AI assistant. Analyze the provided ${mediaType} for signs of manipulation, AI generation, or deepfake artifacts. Provide a detailed assessment with confidence scores and specific indicators found.

Your analysis should consider:
1. Technical artifacts (GAN patterns, noise inconsistencies, compression anomalies)
2. Visual/audio coherence (natural movements, lighting consistency, audio-visual sync)
3. Metadata analysis (EXIF data, creation timestamps, editing software traces)
4. Known deepfake signatures and techniques
5. Contextual credibility factors

Always provide honest assessments with clear confidence levels. When uncertain, explain what additional analysis would help.`;

    const request: CompletionRequest = {
      messages: [
        { role: 'system', content: systemPrompt },
        {
          role: 'user',
          content: options?.additionalContext
            ? `Analyze this ${mediaType} for deepfake indicators. Context: ${options.additionalContext}`
            : `Analyze this ${mediaType} for deepfake indicators.`,
        },
      ],
      tools,
      toolChoice: 'auto',
      attachments: [
        {
          type: mediaType === 'image' ? 'image' : mediaType === 'audio' ? 'audio' : 'video',
          mimeType:
            mediaType === 'image'
              ? 'image/jpeg'
              : mediaType === 'audio'
                ? 'audio/wav'
                : 'video/mp4',
          data: mediaData,
        },
      ],
      stream: false,
    };

    const response = await this.createCompletion(provider, request);
    const content = response.choices[0]?.message?.content || '';

    // Parse the response into structured format
    return this.parseDeepfakeAnalysis(content, response.ethicalScore);
  }

  /**
   * Analyze document for AI-generated content
   */
  async analyzeDocumentForAI(
    provider: AIProvider,
    documentData: string,
    documentType: 'pdf' | 'image' | 'text'
  ): Promise<{
    isAIGenerated: boolean;
    confidence: number;
    indicators: string[];
    humanProbability: number;
    aiProbability: number;
  }> {
    const request: CompletionRequest = {
      messages: [
        {
          role: 'system',
          content:
            'You are an expert in detecting AI-generated text. Analyze the provided document for indicators of AI authorship including writing style, vocabulary patterns, consistency, and typical AI artifacts.',
        },
        {
          role: 'user',
          content: 'Analyze this document for AI-generated content indicators.',
        },
      ],
      tools: [
        DEEPFAKE_DETECTION_TOOLS.find((t) => t.function.name === 'verify_document_authenticity')!,
      ],
      toolChoice: 'auto',
      attachments: [
        {
          type: documentType === 'pdf' ? 'pdf' : 'document',
          mimeType:
            documentType === 'pdf'
              ? 'application/pdf'
              : documentType === 'image'
                ? 'image/png'
                : 'text/plain',
          data: documentData,
        },
      ],
    };

    const response = await this.createCompletion(provider, request);
    const content = response.choices[0]?.message?.content || '';

    return this.parseDocumentAnalysis(content);
  }

  /**
   * Get provider health status
   */
  async checkProviderHealth(provider: AIProvider): Promise<ProviderHealth> {
    const config = this.providers.get(provider);
    if (!config) {
      return {
        provider,
        status: 'down',
        latency: 0,
        successRate: 0,
        lastCheck: new Date(),
        errors: ['Provider not configured'],
      };
    }

    const startTime = Date.now();
    try {
      const response = await fetch(`${config.endpoint}/models`, {
        method: 'GET',
        headers: this.getHeaders(this.apiKeys.get(provider)),
        signal: AbortSignal.timeout(5000),
      });

      const latency = Date.now() - startTime;
      const status = response.ok ? 'healthy' : 'degraded';

      const health: ProviderHealth = {
        provider,
        status,
        latency,
        successRate: response.ok ? 1.0 : 0.5,
        lastCheck: new Date(),
        errors: response.ok ? [] : [`HTTP ${response.status}`],
      };

      this.healthStatus.set(provider, health);
      return health;
    } catch (error) {
      const health: ProviderHealth = {
        provider,
        status: 'down',
        latency: Date.now() - startTime,
        successRate: 0,
        lastCheck: new Date(),
        errors: [error instanceof Error ? error.message : 'Unknown error'],
      };

      this.healthStatus.set(provider, health);
      return health;
    }
  }

  /**
   * Get usage statistics
   */
  getUsageStats(provider?: AIProvider): {
    totalRequests: number;
    totalTokens: number;
    successRate: number;
    avgLatency: number;
    byProvider: Record<string, UsageRecord[]>;
  } {
    const records = provider
      ? this.usageRecords.filter((r) => r.providerId === provider)
      : this.usageRecords;

    const totalRequests = records.length;
    const totalTokens = records.reduce((sum, r) => sum + r.totalTokens, 0);
    const successRate =
      totalRequests > 0 ? records.filter((r) => r.success).length / totalRequests : 0;
    const avgLatency =
      totalRequests > 0 ? records.reduce((sum, r) => sum + r.latencyMs, 0) / totalRequests : 0;

    const byProvider: Record<string, UsageRecord[]> = {};
    for (const record of this.usageRecords) {
      if (!byProvider[record.providerId]) {
        byProvider[record.providerId] = [];
      }
      byProvider[record.providerId].push(record);
    }

    return { totalRequests, totalTokens, successRate, avgLatency, byProvider };
  }

  /**
   * Verify ethical AI compliance
   */
  verifyEthicalCompliance(provider: AIProvider): EthicalVerification {
    const config = this.providers.get(provider);
    if (!config) {
      return {
        isCompliant: false,
        score: 0,
        violations: ['Provider not configured'],
        recommendations: ['Configure the provider before use'],
        alignmentScore: 0,
        privacyScore: 0,
        biasScore: 0,
        transparencyScore: 0,
      };
    }

    const violations: string[] = [];
    const recommendations: string[] = [];

    // Check ethical alignment
    let alignmentScore = 100;
    if (!config.ethicalAlignment) {
      violations.push('Provider does not guarantee ethical AI alignment');
      alignmentScore -= 30;
      recommendations.push('Consider using an ethically-aligned provider');
    }

    // Check privacy
    let privacyScore = 100;
    if (!config.privacyFirst) {
      violations.push('Provider may process data without privacy guarantees');
      privacyScore -= 40;
      recommendations.push('Review provider privacy policy before processing sensitive data');
    }

    // Check training on user data
    if (!config.noTraining) {
      violations.push('Provider may train on user data');
      privacyScore -= 30;
      recommendations.push('Disable data sharing or use privacy-first provider');
    }

    // Check for bias mitigation
    const biasScore = config.ethicalAlignment ? 80 : 40;

    // Check transparency
    const transparencyScore = config.ethicalAlignment ? 85 : 50;

    const score = (alignmentScore + privacyScore + biasScore + transparencyScore) / 4;

    return {
      isCompliant: violations.length === 0,
      score,
      violations,
      recommendations,
      alignmentScore,
      privacyScore,
      biasScore,
      transparencyScore,
    };
  }

  // ============================================================================
  // PRIVATE METHODS
  // ============================================================================

  private prepareRequest(
    config: ProviderConfig,
    request: CompletionRequest
  ): Record<string, unknown> {
    const prepared: Record<string, unknown> = {
      messages: request.messages,
      model: request.model || config.model,
      temperature: request.temperature ?? config.temperature,
      max_tokens: request.maxTokens ?? config.maxTokens,
      stream: request.stream ?? false,
    };

    if (request.streamOptions) {
      prepared.stream_options = request.streamOptions;
    }

    if (request.tools) {
      prepared.tools = request.tools;
    }

    if (request.toolChoice) {
      prepared.tool_choice = request.toolChoice;
    }

    if (request.parallelToolCalls !== undefined) {
      prepared.parallel_tool_calls = request.parallelToolCalls;
    }

    if (request.responseFormat) {
      prepared.response_format = request.responseFormat;
    }

    // Handle attachments (Thaura-style simplified base64)
    if (request.attachments && request.attachments.length > 0) {
      if (request.attachments.length === 1) {
        prepared.attachment = request.attachments[0].data;
      } else {
        prepared.attachments = request.attachments.map((a) => a.data);
      }
    }

    return prepared;
  }

  private getHeaders(apiKey?: string): HeadersInit {
    const headers: HeadersInit = {
      'Content-Type': 'application/json',
    };

    if (apiKey) {
      headers['Authorization'] = `Bearer ${apiKey}`;
    }

    return headers;
  }

  private async makeRequestWithRetry(
    provider: AIProvider,
    config: ProviderConfig,
    request: Record<string, unknown>,
    apiKey?: string
  ): Promise<CompletionResponse> {
    let lastError: Error | null = null;
    const startTime = Date.now();

    for (let attempt = 0; attempt < config.retryAttempts; attempt++) {
      try {
        const response = await fetch(`${config.endpoint}/chat/completions`, {
          method: 'POST',
          headers: this.getHeaders(apiKey),
          body: JSON.stringify(request),
          signal: AbortSignal.timeout(config.timeout),
        });

        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }

        const data = await response.json();
        const completion = this.parseResponse(provider, data);

        this.recordUsage(provider, request as CompletionRequest, Date.now() - startTime, true);
        return completion;
      } catch (error) {
        lastError = error instanceof Error ? error : new Error('Unknown error');

        if (attempt < config.retryAttempts - 1) {
          await new Promise((resolve) => setTimeout(resolve, config.retryDelay * (attempt + 1)));
        }
      }
    }

    this.recordUsage(provider, request as CompletionRequest, Date.now() - startTime, false);
    throw lastError || new Error('Request failed after retries');
  }

  private parseResponse(provider: AIProvider, data: Record<string, unknown>): CompletionResponse {
    const choices = ((data.choices as Record<string, unknown>[]) || []).map((choice, index) => ({
      index,
      message: {
        role: (choice.message as Record<string, unknown>)?.role as MessageRole,
        content: (choice.message as Record<string, unknown>)?.content as string,
      },
      finishReason: (choice.finish_reason as string) || 'stop',
    }));

    const usage = data.usage as Record<string, unknown> | undefined;

    return {
      id: (data.id as string) || `chatcmpl-${Date.now()}`,
      object: (data.object as string) || 'chat.completion',
      created: (data.created as number) || Date.now(),
      model: (data.model as string) || DEFAULT_PROVIDERS[provider]?.model || 'unknown',
      choices,
      usage: {
        promptTokens: (usage?.prompt_tokens as number) || 0,
        completionTokens: (usage?.completion_tokens as number) || 0,
        totalTokens: (usage?.total_tokens as number) || 0,
      },
      ethicalScore: this.providers.get(provider)?.ethicalAlignment ? 0.9 : undefined,
      privacyScore: this.providers.get(provider)?.privacyFirst ? 0.95 : undefined,
    };
  }

  private recordUsage(
    provider: AIProvider,
    request: CompletionRequest,
    latencyMs: number,
    success: boolean
  ): void {
    const record: UsageRecord = {
      id: `usage-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      providerId: provider,
      timestamp: new Date(),
      requestTokens: 0, // Would be calculated from request
      responseTokens: 0, // Would be calculated from response
      totalTokens: 0,
      model: request.model || DEFAULT_PROVIDERS[provider]?.model || 'unknown',
      endpoint: '/chat/completions',
      success,
      latencyMs,
    };

    this.usageRecords.push(record);

    // Keep only last 10000 records
    if (this.usageRecords.length > 10000) {
      this.usageRecords = this.usageRecords.slice(-10000);
    }
  }

  private parseDeepfakeAnalysis(
    content: string,
    ethicalScore?: number
  ): {
    isDeepfake: boolean;
    confidence: number;
    analysis: string;
    artifacts: string[];
    recommendations: string[];
  } {
    // Extract confidence score
    const confidenceMatch = content.match(/confidence[:\s]+(\d+(?:\.\d+)?)%?/i);
    const confidence = confidenceMatch ? parseFloat(confidenceMatch[1]) / 100 : 0.5;

    // Extract deepfake determination
    const isDeepfake =
      /deepfake[:\s]+yes/i.test(content) ||
      /manipulated[:\s]+true/i.test(content) ||
      /is\s+(?:a\s+)?deepfake/i.test(content);

    // Extract artifacts
    const artifactsMatch = content.match(
      /artifacts?[:\s]+(.*?)(?=recommendations?|$)/is
    );
    const artifacts = artifactsMatch
      ? artifactsMatch[1]
          .split(/[,\n]/)
          .map((s) => s.trim())
          .filter((s) => s.length > 0)
      : [];

    // Extract recommendations
    const recommendationsMatch = content.match(/recommendations?[:\s]+(.*?)(?=$)/is);
    const recommendations = recommendationsMatch
      ? recommendationsMatch[1]
          .split(/[,\n]/)
          .map((s) => s.trim())
          .filter((s) => s.length > 0)
      : [];

    return {
      isDeepfake,
      confidence: confidence * (ethicalScore || 1),
      analysis: content,
      artifacts,
      recommendations,
    };
  }

  private parseDocumentAnalysis(content: string): {
    isAIGenerated: boolean;
    confidence: number;
    indicators: string[];
    humanProbability: number;
    aiProbability: number;
  } {
    // Extract AI probability
    const aiMatch = content.match(/ai\s+probability[:\s]+(\d+(?:\.\d+)?)/i);
    const aiProbability = aiMatch ? parseFloat(aiMatch[1]) : 0.5;

    // Extract human probability
    const humanMatch = content.match(/human\s+probability[:\s]+(\d+(?:\.\d+)?)/i);
    const humanProbability = humanMatch ? parseFloat(humanMatch[1]) : 0.5;

    // Extract indicators
    const indicatorsMatch = content.match(/indicators?[:\s]+(.*?)(?=probability|$)/is);
    const indicators = indicatorsMatch
      ? indicatorsMatch[1]
          .split(/[,\n]/)
          .map((s) => s.trim())
          .filter((s) => s.length > 0)
      : [];

    return {
      isAIGenerated: aiProbability > 0.5,
      confidence: Math.max(aiProbability, humanProbability),
      indicators,
      humanProbability,
      aiProbability,
    };
  }
}

// ============================================================================
// RATE LIMITER
// ============================================================================

/**
 * Rate limiter for API requests
 */
class RateLimiter {
  private requests: number[] = [];
  private maxRequests: number;
  private windowMs: number;

  constructor(maxRequests: number, windowMs: number) {
    this.maxRequests = maxRequests;
    this.windowMs = windowMs;
  }

  canMakeRequest(): boolean {
    const now = Date.now();
    this.requests = this.requests.filter((time) => time > now - this.windowMs);
    return this.requests.length < this.maxRequests;
  }

  recordRequest(): void {
    this.requests.push(Date.now());
  }

  getStatus(): { remaining: number; resetIn: number } {
    const now = Date.now();
    this.requests = this.requests.filter((time) => time > now - this.windowMs);
    const oldestRequest = this.requests[0] || now;
    const resetIn = Math.max(0, this.windowMs - (now - oldestRequest));

    return {
      remaining: Math.max(0, this.maxRequests - this.requests.length),
      resetIn,
    };
  }
}

// ============================================================================
// PENDING REQUEST INTERFACE
// ============================================================================

interface PendingRequest {
  id: string;
  timestamp: Date;
  provider: AIProvider;
  status: 'pending' | 'processing' | 'completed' | 'failed';
}

// ============================================================================
// SINGLETON INSTANCE
// ============================================================================

let managerInstance: ExternalAIProviderManager | null = null;

/**
 * Get the singleton instance of the External AI Provider Manager
 */
export function getExternalAIProviderManager(): ExternalAIProviderManager {
  if (!managerInstance) {
    managerInstance = new ExternalAIProviderManager();
  }
  return managerInstance;
}

/**
 * Initialize the External AI Provider Manager with configuration
 */
export function initializeExternalAIProvider(
  provider: AIProvider,
  config: Partial<ProviderConfig> & { apiKey?: string }
): ExternalAIProviderManager {
  const manager = getExternalAIProviderManager();

  if (config.apiKey) {
    manager.setAPIKey(provider, config.apiKey);
    delete config.apiKey;
  }

  manager.configureProvider(provider, config);
  return manager;
}

// ============================================================================
// EXPORTS
// ============================================================================

export default ExternalAIProviderManager;
