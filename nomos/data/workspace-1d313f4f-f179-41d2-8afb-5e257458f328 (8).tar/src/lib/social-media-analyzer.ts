/**
 * Social Media URL Analyzer
 * Analyze videos/images from TikTok, Instagram, YouTube, Twitter, etc.
 * Zero friction - just paste URL and get results
 */

import ZAI from 'z-ai-web-dev-sdk'

export interface SocialMediaInfo {
  platform: 'tiktok' | 'instagram' | 'youtube' | 'twitter' | 'facebook' | 'linkedin' | 'unknown'
  postId: string | null
  username: string | null
  thumbnailUrl: string | null
  title: string | null
  duration: number | null
}

export interface URLAnalysisResult {
  success: boolean
  platform: string
  mediaType: 'image' | 'video'
  thumbnailBase64: string | null
  analysisResult: {
    result: 'authentic' | 'deepfake' | 'uncertain'
    confidence: number
    analysis: string
    indicators: string[]
  } | null
  error: string | null
  shareableCard: string | null // Base64 shareable image
}

// Platform detection patterns
const PLATFORM_PATTERNS = {
  tiktok: /(?:https?:\/\/)?(?:www\.)?(?:vm\.)?tiktok\.com\/@?[\w.-]+\/(?:video\/)?(\d+)/i,
  instagram: /(?:https?:\/\/)?(?:www\.)?instagram\.com\/(?:p|reel|tv)\/([\w-]+)/i,
  youtube: /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:watch\?v=|shorts\/)|youtu\.be\/)([\w-]+)/i,
  twitter: /(?:https?:\/\/)?(?:www\.)?(?:twitter|x)\.com\/([\w]+)\/status\/(\d+)/i,
  facebook: /(?:https?:\/\/)?(?:www\.)?facebook\.com\/.*(?:videos|posts)\/(\d+)/i,
  linkedin: /(?:https?:\/\/)?(?:www\.)?linkedin\.com\/(?:posts|feed)\/(?:update|activity)\/([\w-]+)/i,
}

/**
 * Detect platform from URL
 */
export function detectPlatform(url: string): SocialMediaInfo {
  for (const [platform, pattern] of Object.entries(PLATFORM_PATTERNS)) {
    const match = url.match(pattern)
    if (match) {
      return {
        platform: platform as SocialMediaInfo['platform'],
        postId: match[1] || null,
        username: null,
        thumbnailUrl: null,
        title: null,
        duration: null
      }
    }
  }
  
  return {
    platform: 'unknown',
    postId: null,
    username: null,
    thumbnailUrl: null,
    title: null,
    duration: null
  }
}

/**
 * Extract metadata from social media URL
 * In production, you'd use proper APIs or scraping services
 */
export async function extractSocialMediaMetadata(url: string): Promise<{
  info: SocialMediaInfo
  mediaUrl: string | null
  thumbnailBase64: string | null
}> {
  const info = detectPlatform(url)
  
  // In production, you would:
  // 1. Call TikTok/Instagram/YouTube APIs
  // 2. Or use a scraping service like RapidAPI
  // 3. Or use yt-dlp on the backend
  
  // For demo, we return metadata indicating we need user upload
  return {
    info,
    mediaUrl: null,
    thumbnailBase64: null
  }
}

/**
 * Generate a shareable result card image
 */
export async function generateShareableCard(params: {
  platform: string
  result: 'authentic' | 'deepfake' | 'uncertain'
  confidence: number
  analysis: string
  indicators: string[]
}): Promise<string> {
  // Create SVG card
  const resultColors = {
    authentic: { bg: '#10B981', icon: '✅', label: 'AUTHENTIC' },
    deepfake: { bg: '#EF4444', icon: '⚠️', label: 'DEEPFAKE DETECTED' },
    uncertain: { bg: '#F59E0B', icon: '❓', label: 'UNCERTAIN' }
  }
  
  const color = resultColors[params.result]
  const confidencePercent = Math.round(params.confidence * 100)
  
  const svg = `
  <svg width="500" height="600" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" style="stop-color:#1a1a2e"/>
        <stop offset="100%" style="stop-color:#16213e"/>
      </linearGradient>
    </defs>
    
    <!-- Background -->
    <rect width="500" height="600" fill="url(#grad)" rx="20"/>
    
    <!-- Header -->
    <rect width="500" height="80" fill="${color.bg}" rx="20 20 0 0"/>
    <text x="250" y="50" font-family="Arial, sans-serif" font-size="28" font-weight="bold" fill="white" text-anchor="middle">
      ${color.icon} ${color.label}
    </text>
    
    <!-- Platform Badge -->
    <rect x="180" y="100" width="140" height="35" fill="#374151" rx="17"/>
    <text x="250" y="123" font-family="Arial, sans-serif" font-size="14" fill="white" text-anchor="middle">
      ${params.platform.toUpperCase()}
    </text>
    
    <!-- Confidence Circle -->
    <circle cx="250" cy="220" r="70" fill="none" stroke="${color.bg}" stroke-width="8"/>
    <circle cx="250" cy="220" r="70" fill="none" stroke="${color.bg}" stroke-width="8" 
            stroke-dasharray="${confidencePercent * 4.4} 440" stroke-linecap="round"/>
    <text x="250" y="215" font-family="Arial, sans-serif" font-size="36" font-weight="bold" fill="white" text-anchor="middle">
      ${confidencePercent}%
    </text>
    <text x="250" y="245" font-family="Arial, sans-serif" font-size="14" fill="#9CA3AF" text-anchor="middle">
      Confidence
    </text>
    
    <!-- Analysis Box -->
    <rect x="30" y="310" width="440" height="120" fill="#1F2937" rx="10"/>
    <text x="50" y="345" font-family="Arial, sans-serif" font-size="14" fill="#9CA3AF">
      Analysis:
    </text>
    <text x="50" y="375" font-family="Arial, sans-serif" font-size="13" fill="white">
      ${params.analysis.slice(0, 120)}${params.analysis.length > 120 ? '...' : ''}
    </text>
    
    <!-- Indicators -->
    <text x="50" y="460" font-family="Arial, sans-serif" font-size="14" fill="#9CA3AF">
      Key Indicators:
    </text>
    ${params.indicators.slice(0, 4).map((ind, i) => `
      <text x="50" y="${485 + i * 22}" font-family="Arial, sans-serif" font-size="12" fill="white">
        • ${ind.slice(0, 50)}
      </text>
    `).join('')}
    
    <!-- Footer -->
    <text x="250" y="570" font-family="Arial, sans-serif" font-size="11" fill="#6B7280" text-anchor="middle">
      Analyzed by Deepfake Detector • deepfake-detector.app
    </text>
  </svg>
  `
  
  // Convert SVG to base64
  return Buffer.from(svg).toString('base64')
}

/**
 * Main URL analysis function
 */
export async function analyzeSocialMediaURL(
  url: string,
  onProgress?: (progress: number, message: string) => void
): Promise<URLAnalysisResult> {
  onProgress?.(5, 'Detecting platform...')
  
  const { info, mediaUrl, thumbnailBase64 } = await extractSocialMediaMetadata(url)
  
  // If we can't fetch the media directly, return instructions
  if (!mediaUrl && !thumbnailBase64) {
    return {
      success: false,
      platform: info.platform,
      mediaType: 'video',
      thumbnailBase64: null,
      analysisResult: null,
      error: `To analyze this ${info.platform} content, please download the video/image and upload it directly. This gives you:\n\n✅ 100% privacy - we don't access your accounts\n✅ Faster analysis\n✅ More accurate results\n\nTip: On mobile, long-press the video and select "Save"`,
      shareableCard: null
    }
  }
  
  onProgress?.(30, 'Fetching media...')
  
  // If we have the media, analyze it
  if (mediaUrl || thumbnailBase64) {
    onProgress?.(50, 'Analyzing content...')
    
    try {
      const zai = await ZAI.create()
      
      const analysisPrompt = `You are an expert deepfake detection AI. Analyze this media for signs of AI manipulation or deepfake technology.

Platform: ${info.platform}
${info.username ? `Creator: @${info.username}` : ''}

Examine for:
1. Facial inconsistencies, unnatural movements
2. Lip-sync mismatches
3. Artifacts around face edges
4. Unnatural skin texture
5. Background inconsistencies
6. Audio-visual sync issues

Respond ONLY with JSON:
{
  "result": "authentic" | "deepfake" | "uncertain",
  "confidence": 0.0-1.0,
  "analysis": "Brief explanation (2-3 sentences)",
  "indicators": ["indicator1", "indicator2"]
}`

      const content = thumbnailBase64 
        ? [
            { type: 'text', text: analysisPrompt },
            { type: 'image_url', image_url: { url: `data:image/jpeg;base64,${thumbnailBase64}` } }
          ]
        : [{ type: 'text', text: analysisPrompt }]
      
      const response = await zai.chat.completions.createVision({
        messages: [{ role: 'user', content }],
        thinking: { type: 'disabled' }
      })
      
      const content_text = response.choices[0]?.message?.content || ''
      
      // Parse result
      const jsonMatch = content_text.match(/\{[\s\S]*?\}/)
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0])
        
        onProgress?.(90, 'Generating share card...')
        
        const result: 'authentic' | 'deepfake' | 'uncertain' = 
          ['authentic', 'deepfake', 'uncertain'].includes(parsed.result) 
            ? parsed.result 
            : 'uncertain'
        
        const confidence = Math.max(0, Math.min(1, parseFloat(parsed.confidence) || 0.5))
        
        const analysis: string = parsed.analysis || 'Analysis complete'
        const indicators: string[] = Array.isArray(parsed.indicators) 
          ? parsed.indicators.filter((i: unknown): i is string => typeof i === 'string')
          : []
        
        // Generate shareable card
        const shareableCard = await generateShareableCard({
          platform: info.platform,
          result,
          confidence,
          analysis,
          indicators
        })
        
        onProgress?.(100, 'Complete!')
        
        return {
          success: true,
          platform: info.platform,
          mediaType: thumbnailBase64 ? 'image' : 'video',
          thumbnailBase64,
          analysisResult: { result, confidence, analysis, indicators },
          error: null,
          shareableCard
        }
      }
    } catch (error) {
      return {
        success: false,
        platform: info.platform,
        mediaType: 'video',
        thumbnailBase64: null,
        analysisResult: null,
        error: 'Analysis failed. Please try uploading the file directly.',
        shareableCard: null
      }
    }
  }
  
  return {
    success: false,
    platform: info.platform,
    mediaType: 'video',
    thumbnailBase64: null,
    analysisResult: null,
    error: 'Could not analyze URL. Please upload the file directly.',
    shareableCard: null
  }
}
