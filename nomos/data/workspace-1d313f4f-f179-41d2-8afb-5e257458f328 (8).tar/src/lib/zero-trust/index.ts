/**
 * Zero-Trust Protocol Module
 */

export { 
  ZeroTrustEngine, 
  MultiFactorVerifier,
  zeroTrustEngine, 
  multiFactorVerifier,
  type TrustSession,
  type Challenge,
  type BehaviorRecord,
  type TrustFactor,
  type AnomalyDetection,
  type VerificationResult
} from './zero-trust-protocol';
