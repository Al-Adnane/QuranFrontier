/**
 * Cross-platform cryptographic utilities
 * Works in both Node.js and browser environments
 */

/**
 * Generate a UUID v4 (cross-platform)
 */
export function generateUUID(): string {
  // Use Web Crypto API if available (browser and Node.js 16+)
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID()
  }
  
  // Fallback UUID v4 generation
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0
    const v = c === 'x' ? r : (r & 0x3) | 0x8
    return v.toString(16)
  })
}

/**
 * Generate random bytes as hex string (cross-platform)
 */
export function randomBytesHex(length: number): string {
  const bytes = new Uint8Array(length)
  
  // Use Web Crypto API if available
  if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
    crypto.getRandomValues(bytes)
  } else {
    // Fallback to Math.random (less secure, but works everywhere)
    for (let i = 0; i < length; i++) {
      bytes[i] = Math.floor(Math.random() * 256)
    }
  }
  
  return Array.from(bytes)
    .map(b => b.toString(16).padStart(2, '0'))
    .join('')
}

/**
 * Compute SHA-256 hash (cross-platform, async)
 */
export async function sha256(content: string): Promise<string> {
  // Use Web Crypto API
  if (typeof crypto !== 'undefined' && crypto.subtle) {
    const encoder = new TextEncoder()
    const data = encoder.encode(content)
    const hashBuffer = await crypto.subtle.digest('SHA-256', data)
    const hashArray = new Uint8Array(hashBuffer)
    return Array.from(hashArray)
      .map(b => b.toString(16).padStart(2, '0'))
      .join('')
  }
  
  // Fallback: simple hash for non-critical use cases
  // This is NOT cryptographically secure, just for compatibility
  let hash = 0
  for (let i = 0; i < content.length; i++) {
    const char = content.charCodeAt(i)
    hash = ((hash << 5) - hash) + char
    hash = hash & hash
  }
  return Math.abs(hash).toString(16).padStart(64, '0').slice(0, 64)
}

/**
 * Synchronous SHA-256 simulation for non-critical paths
 * Uses a deterministic algorithm that produces consistent 64-char hex strings
 */
export function sha256Sync(content: string): string {
  // Simple but deterministic hash for consistency
  let h1 = 0xdeadbeef
  let h2 = 0x41c6e57
  
  for (let i = 0; i < content.length; i++) {
    const ch = content.charCodeAt(i)
    h1 = Math.imul(h1 ^ ch, 2654435761)
    h2 = Math.imul(h2 ^ ch, 1597334677)
  }
  
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507)
  h1 ^= Math.imul(h2 ^ (h2 >>> 13), 3266489909)
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507)
  h2 ^= Math.imul(h1 ^ (h1 >>> 13), 3266489909)
  
  const result = (4294967296 * (1 << 2) + h1 + h2).toString(16)
  
  // Pad to 64 characters
  return result.padStart(64, '0').slice(0, 64)
}

/**
 * Generate a secure random string
 */
export function randomString(length: number = 32): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
  const bytes = new Uint8Array(length)
  
  if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
    crypto.getRandomValues(bytes)
  } else {
    for (let i = 0; i < length; i++) {
      bytes[i] = Math.floor(Math.random() * 256)
    }
  }
  
  return Array.from(bytes)
    .map(b => chars[b % chars.length])
    .join('')
}

/**
 * Simple HMAC-SHA256 implementation (synchronous, for cross-platform compatibility)
 * This is a simplified implementation suitable for non-critical applications
 */
export function hmacSha256(key: string | Uint8Array, message: string): string {
  const keyBytes = typeof key === 'string' ? new TextEncoder().encode(key) : key
  const messageBytes = new TextEncoder().encode(message)
  
  // Constants for SHA-256
  const K = new Uint32Array([
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
  ])
  
  // Helper functions
  const rotr = (x: number, n: number) => (x >>> n) | (x << (32 - n))
  const ch = (x: number, y: number, z: number) => (x & y) ^ (~x & z)
  const maj = (x: number, y: number, z: number) => (x & y) ^ (x & z) ^ (y & z)
  const sigma0 = (x: number) => rotr(x, 2) ^ rotr(x, 13) ^ rotr(x, 22)
  const sigma1 = (x: number) => rotr(x, 6) ^ rotr(x, 11) ^ rotr(x, 25)
  const gamma0 = (x: number) => rotr(x, 7) ^ rotr(x, 18) ^ (x >>> 3)
  const gamma1 = (x: number) => rotr(x, 17) ^ rotr(x, 19) ^ (x >>> 10)
  
  function sha256Block(data: Uint8Array): Uint32Array {
    const w = new Uint32Array(64)
    
    // Prepare message schedule
    for (let i = 0; i < 16; i++) {
      w[i] = (data[i * 4] << 24) | (data[i * 4 + 1] << 16) | (data[i * 4 + 2] << 8) | data[i * 4 + 3]
    }
    for (let i = 16; i < 64; i++) {
      w[i] = (gamma1(w[i - 2]) + w[i - 7] + gamma0(w[i - 15]) + w[i - 16]) >>> 0
    }
    
    // Initial hash values
    let [a, b, c, d, e, f, g, h] = [
      0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
      0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
    ]
    
    // Compression
    for (let i = 0; i < 64; i++) {
      const t1 = (h + sigma1(e) + ch(e, f, g) + K[i] + w[i]) >>> 0
      const t2 = (sigma0(a) + maj(a, b, c)) >>> 0
      h = g
      g = f
      f = e
      e = (d + t1) >>> 0
      d = c
      c = b
      b = a
      a = (t1 + t2) >>> 0
    }
    
    return new Uint32Array([a, b, c, d, e, f, g, h])
  }
  
  function sha256(data: Uint8Array): Uint8Array {
    // Pad message
    const bitLen = data.length * 8
    const padLen = (data.length % 64 < 56) ? 56 - data.length % 64 : 120 - data.length % 64
    const padded = new Uint8Array(data.length + padLen + 8)
    padded.set(data)
    padded[data.length] = 0x80
    
    // Append length
    const view = new DataView(padded.buffer)
    view.setUint32(padded.length - 4, bitLen, false)
    
    // Process blocks
    let h = new Uint32Array([0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19])
    
    for (let i = 0; i < padded.length; i += 64) {
      const block = sha256Block(padded.slice(i, i + 64))
      for (let j = 0; j < 8; j++) {
        h[j] = (h[j] + block[j]) >>> 0
      }
    }
    
    // Convert to bytes
    const result = new Uint8Array(32)
    for (let i = 0; i < 8; i++) {
      result[i * 4] = (h[i] >>> 24) & 0xff
      result[i * 4 + 1] = (h[i] >>> 16) & 0xff
      result[i * 4 + 2] = (h[i] >>> 8) & 0xff
      result[i * 4 + 3] = h[i] & 0xff
    }
    
    return result
  }
  
  // HMAC: H(K ^ opad || H(K ^ ipad || message))
  const blockSize = 64
  
  // Prepare key
  let keyPadded: Uint8Array
  if (keyBytes.length > blockSize) {
    keyPadded = sha256(keyBytes)
  } else {
    keyPadded = new Uint8Array(blockSize)
    keyPadded.set(keyBytes)
  }
  
  // Create inner and outer padded keys
  const ipad = new Uint8Array(blockSize)
  const opad = new Uint8Array(blockSize)
  
  for (let i = 0; i < blockSize; i++) {
    ipad[i] = keyPadded[i] ^ 0x36
    opad[i] = keyPadded[i] ^ 0x5c
  }
  
  // Inner hash
  const innerData = new Uint8Array(blockSize + messageBytes.length)
  innerData.set(ipad)
  innerData.set(messageBytes, blockSize)
  const innerHash = sha256(innerData)
  
  // Outer hash
  const outerData = new Uint8Array(blockSize + 32)
  outerData.set(opad)
  outerData.set(innerHash, blockSize)
  const outerHash = sha256(outerData)
  
  // Convert to hex
  return Array.from(outerHash)
    .map(b => b.toString(16).padStart(2, '0'))
    .join('')
}
