/**
 * C2PA & SynthID Content Credentials Module
 */

export { 
  C2PAVerifier,
  SynthIDDetector,
  AuthenticityCertificateIssuer,
  ContentVerificationService,
  c2paVerifier,
  synthIDDetector,
  authenticityCertificateIssuer,
  contentVerificationService,
  type C2PAClaim,
  type C2PAAssertion,
  type ContentCredential,
  type SynthIDWatermark,
  type AuthenticityCertificate,
  type ContentVerificationResult,
  type VerificationReport
} from './content-credentials';
