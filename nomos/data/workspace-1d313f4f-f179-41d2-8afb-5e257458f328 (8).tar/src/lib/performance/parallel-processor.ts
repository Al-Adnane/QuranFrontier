/**
 * Kasbah Parallel Processing Engine
 * Multi-threaded processing for maximum throughput
 */

// ============================================================================
// TYPES
// ============================================================================

export interface Task<T, R> {
  id: string;
  type: string;
  input: T;
  priority: 'critical' | 'high' | 'normal' | 'low';
  status: 'pending' | 'running' | 'completed' | 'failed';
  result?: R;
  error?: string;
  startTime?: number;
  endTime?: number;
  retryCount: number;
  maxRetries: number;
}

export interface WorkerPoolConfig {
  maxWorkers: number;
  taskTimeout: number;
  maxRetries: number;
  taskQueueSize: number;
  idleTimeout: number;
}

export interface ProcessingResult<R> {
  taskId: string;
  result: R;
  processingTime: number;
  workerId: number;
  cached: boolean;
}

export interface ParallelProcessorStats {
  totalTasks: number;
  completedTasks: number;
  failedTasks: number;
  avgProcessingTime: number;
  throughput: number;
  queueLength: number;
  activeWorkers: number;
  idleWorkers: number;
  cacheHits: number;
  cacheMisses: number;
}

// ============================================================================
// PARALLEL PROCESSOR
// ============================================================================

export class ParallelProcessor<I, O> {
  private taskQueue: Task<I, O>[] = [];
  private activeTasks = new Map<string, Task<I, O>>();
  private completedTasks = new Map<string, Task<I, O>>();
  private results = new Map<string, O>();
  private workers: Array<{
    id: number;
    busy: boolean;
    taskCount: number;
    totalProcessed: number;
  }> = [];
  private config: WorkerPoolConfig;
  private processor: (input: I) => Promise<O>;
  private keyGenerator?: (input: I) => string;
  private cacheHits = 0;
  private cacheMisses = 0;
  private processingTimes: number[] = [];
  private isProcessing = false;

  constructor(
    processor: (input: I) => Promise<O>,
    config: Partial<WorkerPoolConfig> = {},
    keyGenerator?: (input: I) => string
  ) {
    this.processor = processor;
    this.keyGenerator = keyGenerator;
    this.config = {
      maxWorkers: navigator.hardwareConcurrency || 4,
      taskTimeout: 30000,
      maxRetries: 3,
      taskQueueSize: 1000,
      idleTimeout: 60000,
      ...config
    };

    // Initialize workers
    for (let i = 0; i < this.config.maxWorkers; i++) {
      this.workers.push({
        id: i,
        busy: false,
        taskCount: 0,
        totalProcessed: 0
      });
    }
  }

  async submit(input: I, priority: Task<I, O>['priority'] = 'normal'): Promise<O> {
    // Check cache first
    if (this.keyGenerator) {
      const cacheKey = this.keyGenerator(input);
      const cached = this.results.get(cacheKey);
      if (cached !== undefined) {
        this.cacheHits++;
        return cached;
      }
      this.cacheMisses++;
    }

    const task: Task<I, O> = {
      id: this.generateTaskId(),
      type: 'process',
      input,
      priority,
      status: 'pending',
      retryCount: 0,
      maxRetries: this.config.maxRetries
    };

    return new Promise((resolve, reject) => {
      // Add to queue
      this.enqueueTask(task);

      // Start processing
      this.processQueue();

      // Wait for result
      const checkResult = () => {
        const completed = this.completedTasks.get(task.id);
        if (completed) {
          if (completed.status === 'completed' && completed.result !== undefined) {
            resolve(completed.result);
          } else if (completed.error) {
            reject(new Error(completed.error));
          } else {
            reject(new Error('Task failed without error'));
          }
        } else {
          setTimeout(checkResult, 10);
        }
      };

      checkResult();
    });
  }

  async submitBatch(inputs: I[], priority: Task<I, O>['priority'] = 'normal'): Promise<O[]> {
    const promises = inputs.map(input => this.submit(input, priority));
    return Promise.all(promises);
  }

  private enqueueTask(task: Task<I, O>): void {
    // Priority insertion
    const priorityOrder = { critical: 0, high: 1, normal: 2, low: 3 };
    const insertIndex = this.taskQueue.findIndex(
      t => priorityOrder[t.priority] > priorityOrder[task.priority]
    );

    if (insertIndex === -1) {
      this.taskQueue.push(task);
    } else {
      this.taskQueue.splice(insertIndex, 0, task);
    }

    // Enforce queue size
    while (this.taskQueue.length > this.config.taskQueueSize) {
      const removed = this.taskQueue.pop();
      if (removed) {
        removed.status = 'failed';
        removed.error = 'Queue overflow';
        this.completedTasks.set(removed.id, removed);
      }
    }
  }

  private async processQueue(): Promise<void> {
    if (this.isProcessing) return;
    this.isProcessing = true;

    while (this.taskQueue.length > 0) {
      const worker = this.getAvailableWorker();
      if (!worker) break;

      const task = this.taskQueue.shift();
      if (!task) break;

      worker.busy = true;
      worker.taskCount++;
      task.status = 'running';
      task.startTime = performance.now();
      this.activeTasks.set(task.id, task);

      this.executeTask(task, worker.id);
    }

    this.isProcessing = false;
  }

  private async executeTask(task: Task<I, O>, workerId: number): Promise<void> {
    const worker = this.workers.find(w => w.id === workerId)!;

    try {
      const startTime = performance.now();
      
      // Execute with timeout
      const result = await Promise.race([
        this.processor(task.input),
        this.createTimeout(this.config.taskTimeout)
      ]);

      task.endTime = performance.now();
      task.result = result as O;
      task.status = 'completed';

      // Cache result
      if (this.keyGenerator) {
        const cacheKey = this.keyGenerator(task.input);
        this.results.set(cacheKey, result as O);
      }

      // Record processing time
      this.processingTimes.push(task.endTime - task.startTime!);
      if (this.processingTimes.length > 1000) {
        this.processingTimes.shift();
      }

      worker.totalProcessed++;
      worker.busy = false;

    } catch (error) {
      task.retryCount++;
      
      if (task.retryCount < task.maxRetries) {
        // Retry
        task.status = 'pending';
        this.taskQueue.unshift(task);
      } else {
        task.status = 'failed';
        task.error = error instanceof Error ? error.message : String(error);
      }

      worker.busy = false;
    }

    this.activeTasks.delete(task.id);
    this.completedTasks.set(task.id, task);

    // Continue processing
    this.processQueue();
  }

  private getAvailableWorker(): typeof this.workers[0] | null {
    return this.workers.find(w => !w.busy) || null;
  }

  private createTimeout(ms: number): Promise<never> {
    return new Promise((_, reject) => {
      setTimeout(() => reject(new Error('Task timeout')), ms);
    });
  }

  private generateTaskId(): string {
    return `task-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  getStats(): ParallelProcessorStats {
    const totalTasks = this.taskQueue.length + this.activeTasks.size + this.completedTasks.size;
    const completedTasks = Array.from(this.completedTasks.values()).filter(t => t.status === 'completed').length;
    const failedTasks = Array.from(this.completedTasks.values()).filter(t => t.status === 'failed').length;
    
    const avgProcessingTime = this.processingTimes.length > 0
      ? this.processingTimes.reduce((a, b) => a + b, 0) / this.processingTimes.length
      : 0;

    const throughput = this.processingTimes.length > 0
      ? 1000 / avgProcessingTime
      : 0;

    return {
      totalTasks,
      completedTasks,
      failedTasks,
      avgProcessingTime,
      throughput,
      queueLength: this.taskQueue.length,
      activeWorkers: this.workers.filter(w => w.busy).length,
      idleWorkers: this.workers.filter(w => !w.busy).length,
      cacheHits: this.cacheHits,
      cacheMisses: this.cacheMisses
    };
  }

  clearCache(): void {
    this.results.clear();
    this.cacheHits = 0;
    this.cacheMisses = 0;
  }

  getQueueLength(): number {
    return this.taskQueue.length;
  }

  getActiveTaskCount(): number {
    return this.activeTasks.size;
  }
}

// ============================================================================
// STREAMING PROCESSOR
// ============================================================================

export class StreamingProcessor<T, R> {
  private buffer: T[] = [];
  private processor: (batch: T[]) => Promise<R[]>;
  private batchSize: number;
  private flushInterval: number;
  private onResult?: (result: R, input: T) => void;
  private flushTimer: ReturnType<typeof setInterval> | null = null;
  private pendingInputs = new Map<string, T>();
  private pendingCallbacks = new Map<string, (result: R) => void>();

  constructor(
    processor: (batch: T[]) => Promise<R[]>,
    batchSize: number = 100,
    flushInterval: number = 100, // ms
    onResult?: (result: R, input: T) => void
  ) {
    this.processor = processor;
    this.batchSize = batchSize;
    this.flushInterval = flushInterval;
    this.onResult = onResult;

    this.startFlushTimer();
  }

  async add(input: T, id?: string): Promise<R> {
    const inputId = id || `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    return new Promise((resolve) => {
      this.pendingInputs.set(inputId, input);
      this.pendingCallbacks.set(inputId, resolve);
      this.buffer.push(input);

      // Immediate flush if batch size reached
      if (this.buffer.length >= this.batchSize) {
        this.flush();
      }
    });
  }

  private startFlushTimer(): void {
    this.flushTimer = setInterval(() => {
      if (this.buffer.length > 0) {
        this.flush();
      }
    }, this.flushInterval);
  }

  private async flush(): Promise<void> {
    if (this.buffer.length === 0) return;

    const batch = this.buffer.splice(0, this.batchSize);
    const ids = Array.from(this.pendingInputs.keys()).slice(0, batch.length);

    try {
      const results = await this.processor(batch);

      // Distribute results
      ids.forEach((id, index) => {
        const callback = this.pendingCallbacks.get(id);
        if (callback && results[index] !== undefined) {
          callback(results[index]);
          this.pendingCallbacks.delete(id);
          this.pendingInputs.delete(id);

          if (this.onResult) {
            const input = this.pendingInputs.get(id);
            if (input) {
              this.onResult(results[index], input);
            }
          }
        }
      });
    } catch (error) {
      console.error('Batch processing error:', error);
    }
  }

  stop(): void {
    if (this.flushTimer) {
      clearInterval(this.flushTimer);
      this.flushTimer = null;
    }
  }

  getBufferSize(): number {
    return this.buffer.length;
  }

  getPendingCount(): number {
    return this.pendingInputs.size;
  }
}

// ============================================================================
// PIPELINE PROCESSOR
// ============================================================================

export class PipelineProcessor<T> {
  private stages: Array<{
    name: string;
    process: (input: unknown) => Promise<unknown>;
    parallel: boolean;
  }> = [];
  private currentStage = 0;

  addStage<R>(
    name: string,
    processor: (input: T) => Promise<R>,
    parallel: boolean = false
  ): PipelineProcessor<T> {
    this.stages.push({
      name,
      process: processor as (input: unknown) => Promise<unknown>,
      parallel
    });
    return this;
  }

  async execute(input: T): Promise<unknown> {
    let current: unknown = input;

    for (const stage of this.stages) {
      const startTime = performance.now();
      
      if (stage.parallel && Array.isArray(current)) {
        current = await Promise.all(
          current.map(item => stage.process(item))
        );
      } else {
        current = await stage.process(current);
      }

      console.log(`Stage ${stage.name} completed in ${(performance.now() - startTime).toFixed(2)}ms`);
    }

    return current;
  }

  async executeBatch(inputs: T[]): Promise<unknown[]> {
    return Promise.all(inputs.map(input => this.execute(input)));
  }

  getStageCount(): number {
    return this.stages.length;
  }

  getCurrentStage(): number {
    return this.currentStage;
  }
}

// ============================================================================
// PRIORITY SCHEDULER
// ============================================================================

export class PriorityScheduler<T, R> {
  private queues: Map<Task<T, R>['priority'], Array<{
    task: Task<T, R>;
    resolve: (result: R) => void;
    reject: (error: Error) => void;
  }>> = new Map();
  private processor: (input: T) => Promise<R>;
  private maxConcurrent: number;
  private activeCount = 0;
  private processing = false;

  constructor(
    processor: (input: T) => Promise<R>,
    maxConcurrent: number = 10
  ) {
    this.processor = processor;
    this.maxConcurrent = maxConcurrent;

    // Initialize queues
    ['critical', 'high', 'normal', 'low'].forEach(priority => {
      this.queues.set(priority as Task<T, R>['priority'], []);
    });
  }

  async schedule(input: T, priority: Task<T, R>['priority'] = 'normal'): Promise<R> {
    return new Promise((resolve, reject) => {
      const queue = this.queues.get(priority);
      if (!queue) {
        reject(new Error('Invalid priority'));
        return;
      }

      const task: Task<T, R> = {
        id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        type: 'scheduled',
        input,
        priority,
        status: 'pending',
        retryCount: 0,
        maxRetries: 0
      };

      queue.push({ task, resolve, reject });
      this.processNext();
    });
  }

  private async processNext(): Promise<void> {
    if (this.activeCount >= this.maxConcurrent || this.processing) return;

    // Get next task by priority
    let next: { task: Task<T, R>; resolve: (result: R) => void; reject: (error: Error) => void } | undefined;

    for (const priority of ['critical', 'high', 'normal', 'low'] as const) {
      const queue = this.queues.get(priority);
      if (queue && queue.length > 0) {
        next = queue.shift();
        break;
      }
    }

    if (!next) return;

    this.activeCount++;
    this.processing = true;
    next.task.status = 'running';

    try {
      const result = await this.processor(next.task.input);
      next.task.status = 'completed';
      next.task.result = result;
      next.resolve(result);
    } catch (error) {
      next.task.status = 'failed';
      next.task.error = error instanceof Error ? error.message : String(error);
      next.reject(error as Error);
    }

    this.activeCount--;
    this.processing = false;

    // Process next in queue
    if (this.activeCount < this.maxConcurrent) {
      this.processNext();
    }
  }

  getQueueLength(priority?: Task<T, R>['priority']): number {
    if (priority) {
      return this.queues.get(priority)?.length || 0;
    }
    
    let total = 0;
    for (const queue of this.queues.values()) {
      total += queue.length;
    }
    return total;
  }

  getActiveCount(): number {
    return this.activeCount;
  }

  clearQueues(): void {
    for (const queue of this.queues.values()) {
      queue.length = 0;
    }
  }
}

// ============================================================================
// DETECTION PARALLEL PROCESSOR
// ============================================================================

export class DetectionParallelProcessor {
  private imageProcessor: ParallelProcessor<ImageData, DetectionResult>;
  private audioProcessor: ParallelProcessor<AudioBuffer, DetectionResult>;
  private videoProcessor: ParallelProcessor<VideoFrame, DetectionResult>;
  private scheduler: PriorityScheduler<unknown, DetectionResult>;

  constructor() {
    // Initialize processors
    this.imageProcessor = new ParallelProcessor(
      this.processImage.bind(this),
      { maxWorkers: 8, taskTimeout: 5000 },
      (input) => `img-${(input as ImageData).width}-${(input as ImageData).height}`
    );

    this.audioProcessor = new ParallelProcessor(
      this.processAudio.bind(this),
      { maxWorkers: 4, taskTimeout: 10000 },
      (input) => `audio-${(input as AudioBuffer).duration}`
    );

    this.videoProcessor = new ParallelProcessor(
      this.processVideo.bind(this),
      { maxWorkers: 6, taskTimeout: 15000 },
      (input) => `video-${(input as VideoFrame).timestamp}`
    );

    this.scheduler = new PriorityScheduler(
      this.processGeneric.bind(this),
      20
    );
  }

  async detectImage(imageData: ImageData, priority: 'critical' | 'high' | 'normal' | 'low' = 'normal'): Promise<DetectionResult> {
    return this.imageProcessor.submit(imageData, priority);
  }

  async detectAudio(audioBuffer: AudioBuffer, priority: 'critical' | 'high' | 'normal' | 'low' = 'normal'): Promise<DetectionResult> {
    return this.audioProcessor.submit(audioBuffer, priority);
  }

  async detectVideo(frame: VideoFrame, priority: 'critical' | 'high' | 'normal' | 'low' = 'normal'): Promise<DetectionResult> {
    return this.videoProcessor.submit(frame, priority);
  }

  async detectBatch(
    items: Array<{ type: 'image' | 'audio' | 'video'; data: unknown }>,
    priority: 'critical' | 'high' | 'normal' | 'low' = 'normal'
  ): Promise<DetectionResult[]> {
    return Promise.all(
      items.map(item => {
        if (item.type === 'image') {
          return this.detectImage(item.data as ImageData, priority);
        } else if (item.type === 'audio') {
          return this.detectAudio(item.data as AudioBuffer, priority);
        } else {
          return this.detectVideo(item.data as VideoFrame, priority);
        }
      })
    );
  }

  private async processImage(data: ImageData): Promise<DetectionResult> {
    // Simulate processing
    return {
      type: 'image',
      isDeepfake: Math.random() > 0.5,
      confidence: 0.85 + Math.random() * 0.15,
      processingTime: Math.random() * 50 + 10,
      attributes: {
        width: data.width,
        height: data.height
      }
    };
  }

  private async processAudio(data: AudioBuffer): Promise<DetectionResult> {
    // Simulate processing
    return {
      type: 'audio',
      isDeepfake: Math.random() > 0.5,
      confidence: 0.80 + Math.random() * 0.15,
      processingTime: Math.random() * 100 + 30,
      attributes: {
        duration: data.duration,
        sampleRate: data.sampleRate
      }
    };
  }

  private async processVideo(data: VideoFrame): Promise<DetectionResult> {
    // Simulate processing
    return {
      type: 'video',
      isDeepfake: Math.random() > 0.5,
      confidence: 0.82 + Math.random() * 0.15,
      processingTime: Math.random() * 80 + 40,
      attributes: {
        timestamp: data.timestamp
      }
    };
  }

  private async processGeneric(data: unknown): Promise<DetectionResult> {
    return {
      type: 'generic',
      isDeepfake: Math.random() > 0.5,
      confidence: 0.75 + Math.random() * 0.2,
      processingTime: Math.random() * 30 + 5,
      attributes: {}
    };
  }

  getStats(): {
    image: ParallelProcessorStats;
    audio: ParallelProcessorStats;
    video: ParallelProcessorStats;
  } {
    return {
      image: this.imageProcessor.getStats(),
      audio: this.audioProcessor.getStats(),
      video: this.videoProcessor.getStats()
    };
  }
}

// ============================================================================
// TYPES FOR DETECTION
// ============================================================================

interface DetectionResult {
  type: string;
  isDeepfake: boolean;
  confidence: number;
  processingTime: number;
  attributes: Record<string, unknown>;
}

interface ImageData {
  width: number;
  height: number;
  data: Uint8ClampedArray;
}

interface AudioBuffer {
  duration: number;
  sampleRate: number;
  length: number;
}

interface VideoFrame {
  timestamp: number;
  width: number;
  height: number;
}

// ============================================================================
// SINGLETON EXPORTS
// ============================================================================

export const detectionParallelProcessor = new DetectionParallelProcessor();

export default ParallelProcessor;
