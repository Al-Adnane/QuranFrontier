/**
 * Kasbah Performance Module
 * Index file for all performance optimization components
 */

export * from './instant-response-engine';
export * from './stress-test-engine';
export * from './parallel-processor';

import { InstantResponseEngine, instantEngine } from './instant-response-engine';
import { StressTestEngine, DetectionStressTests, PerformanceMonitor, stressTestEngine, detectionStressTests, performanceMonitor } from './stress-test-engine';
import { ParallelProcessor, StreamingProcessor, PipelineProcessor, PriorityScheduler, DetectionParallelProcessor, detectionParallelProcessor } from './parallel-processor';

export {
  InstantResponseEngine,
  instantEngine,
  StressTestEngine,
  DetectionStressTests,
  PerformanceMonitor,
  stressTestEngine,
  detectionStressTests,
  performanceMonitor,
  ParallelProcessor,
  StreamingProcessor,
  PipelineProcessor,
  PriorityScheduler,
  DetectionParallelProcessor,
  detectionParallelProcessor
};

/**
 * Initialize all performance optimizations
 */
export async function initializePerformanceOptimizations(): Promise<{
  cacheWarming: boolean;
  precomputation: boolean;
  workerPools: boolean;
  monitoring: boolean;
}> {
  const results = {
    cacheWarming: false,
    precomputation: false,
    workerPools: false,
    monitoring: false
  };

  try {
    // Warm up cache with common patterns
    await instantEngine.warmup(
      ['detection-default', 'attribution-default', 'analysis-default'],
      async (key) => ({ key, warmed: true, timestamp: Date.now() })
    );
    results.cacheWarming = true;
  } catch (e) {
    console.error('Cache warming failed:', e);
  }

  try {
    // Check precomputation status
    const stats = instantEngine.getPrecomputationStats();
    results.precomputation = !stats.computing;
  } catch (e) {
    console.error('Precomputation check failed:', e);
  }

  try {
    // Verify worker pools
    const processorStats = detectionParallelProcessor.getStats();
    results.workerPools = processorStats.image.idleWorkers > 0;
  } catch (e) {
    console.error('Worker pool check failed:', e);
  }

  try {
    // Start monitoring
    performanceMonitor.setThreshold('response_time', 100);
    performanceMonitor.setThreshold('error_rate', 0.01);
    results.monitoring = true;
  } catch (e) {
    console.error('Monitoring setup failed:', e);
  }

  return results;
}

/**
 * Get comprehensive performance report
 */
export function getPerformanceReport(): {
  instantEngine: {
    metrics: ReturnType<typeof instantEngine.getMetrics>;
    cacheStats: ReturnType<typeof instantEngine.getCacheStats>;
    precomputationStats: ReturnType<typeof instantEngine.getPrecomputationStats>;
  };
  parallelProcessor: ReturnType<typeof detectionParallelProcessor.getStats>;
  monitoring: ReturnType<typeof performanceMonitor.export>;
} {
  return {
    instantEngine: {
      metrics: instantEngine.getMetrics(),
      cacheStats: instantEngine.getCacheStats(),
      precomputationStats: instantEngine.getPrecomputationStats()
    },
    parallelProcessor: detectionParallelProcessor.getStats(),
    monitoring: performanceMonitor.export()
  };
}

/**
 * Run full stress test suite
 */
export async function runFullStressTest(config?: Parameters<typeof detectionStressTests.runFullStressTest>[0]): Promise<{
  passed: boolean;
  score: number;
  grade: string;
  details: Awaited<ReturnType<typeof detectionStressTests.runFullStressTest>>;
}> {
  const results = await detectionStressTests.runFullStressTest();
  
  return {
    passed: results.overall.passed,
    score: results.overall.score,
    grade: results.overall.grade,
    details: results
  };
}

export default {
  instantEngine,
  stressTestEngine,
  detectionStressTests,
  performanceMonitor,
  detectionParallelProcessor,
  initializePerformanceOptimizations,
  getPerformanceReport,
  runFullStressTest
};
