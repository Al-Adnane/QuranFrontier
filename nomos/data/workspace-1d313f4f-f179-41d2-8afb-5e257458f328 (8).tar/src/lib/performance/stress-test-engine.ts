/**
 * Kasbah Stress Testing Engine
 * 100% efficiency stress testing with comprehensive benchmarking
 */

// ============================================================================
// TYPES
// ============================================================================

export interface StressTestConfig {
  concurrentUsers: number;
  requestsPerUser: number;
  rampUpTime: number; // ms
  duration: number; // ms
  targetThroughput: number; // requests/second
  timeoutMs: number;
  retryAttempts: number;
}

export interface StressTestResult {
  totalRequests: number;
  successfulRequests: number;
  failedRequests: number;
  avgResponseTime: number;
  minResponseTime: number;
  maxResponseTime: number;
  p50ResponseTime: number;
  p95ResponseTime: number;
  p99ResponseTime: number;
  throughput: number; // requests/second
  errorRate: number;
  timeoutRate: number;
  memoryPeak: number;
  cpuPeak: number;
  duration: number;
  passed: boolean;
  grade: 'A+' | 'A' | 'B' | 'C' | 'D' | 'F';
}

export interface BenchmarkResult {
  name: string;
  iterations: number;
  totalTime: number;
  avgTime: number;
  minTime: number;
  maxTime: number;
  opsPerSecond: number;
  memoryUsed: number;
  passed: boolean;
  threshold: number;
}

export interface LoadTestScenario {
  name: string;
  weight: number;
  execute: () => Promise<unknown>;
  timeout?: number;
}

export interface ConcurrentTestResult {
  testName: string;
  concurrentOps: number;
  totalOps: number;
  successfulOps: number;
  failedOps: number;
  avgLatency: number;
  throughput: number;
  errors: string[];
}

export interface MemoryLeakResult {
  detected: boolean;
  baseline: number;
  peak: number;
  growth: number;
  samples: number;
  leakRate: number; // bytes/second
  passed: boolean;
}

export interface SystemLoadTestResult {
  cpuUtilization: number[];
  memoryUtilization: number[];
  networkThroughput: number[];
  diskIO: number[];
  timestamps: number[];
  passed: boolean;
  recommendations: string[];
}

// ============================================================================
// STRESS TEST ENGINE
// ============================================================================

export class StressTestEngine {
  private results: StressTestResult[] = [];
  private benchmarks: BenchmarkResult[] = [];
  private scenarios: LoadTestScenario[] = [];
  private isRunning = false;
  private abortController: AbortController | null = null;

  addScenario(scenario: LoadTestScenario): void {
    this.scenarios.push(scenario);
  }

  clearScenarios(): void {
    this.scenarios = [];
  }

  async runStressTest(config: StressTestConfig): Promise<StressTestResult> {
    if (this.isRunning) {
      throw new Error('Stress test already running');
    }

    this.isRunning = true;
    this.abortController = new AbortController();

    const startTime = Date.now();
    const responseTimes: number[] = [];
    const errors: Error[] = [];
    let successfulRequests = 0;
    let failedRequests = 0;
    let timeoutCount = 0;

    // Create user workers
    const userWorkers = Array(config.concurrentUsers).fill(null).map((_, userId) => ({
      id: userId,
      requests: 0,
      errors: 0
    }));

    // Ramp up users gradually
    const rampUpDelay = config.rampUpTime / config.concurrentUsers;

    // Run concurrent requests
    const runUserSession = async (userId: number): Promise<void> => {
      // Ramp up delay
      await this.delay(userId * rampUpDelay);

      for (let i = 0; i < config.requestsPerUser; i++) {
        if (this.abortController?.signal.aborted) break;

        const requestStart = performance.now();

        try {
          // Execute random scenario based on weight
          const scenario = this.selectWeightedScenario();
          
          await Promise.race([
            scenario.execute(),
            this.createTimeout(config.timeoutMs)
          ]);

          responseTimes.push(performance.now() - requestStart);
          successfulRequests++;
          userWorkers[userId].requests++;

        } catch (error) {
          failedRequests++;
          userWorkers[userId].errors++;
          
          if (error instanceof Error && error.message === 'TIMEOUT') {
            timeoutCount++;
          } else {
            errors.push(error as Error);
          }
        }

        // Throttle to target throughput
        const targetInterval = 1000 / (config.targetThroughput / config.concurrentUsers);
        const elapsed = performance.now() - requestStart;
        if (elapsed < targetInterval) {
          await this.delay(targetInterval - elapsed);
        }
      }
    };

    // Start all users
    const userPromises = userWorkers.map((user) => runUserSession(user.id));
    await Promise.all(userPromises);

    const endTime = Date.now();
    const duration = endTime - startTime;

    // Calculate metrics
    const totalRequests = successfulRequests + failedRequests;
    const sortedTimes = responseTimes.sort((a, b) => a - b);

    const result: StressTestResult = {
      totalRequests,
      successfulRequests,
      failedRequests,
      avgResponseTime: responseTimes.length > 0 
        ? responseTimes.reduce((a, b) => a + b, 0) / responseTimes.length 
        : 0,
      minResponseTime: sortedTimes[0] || 0,
      maxResponseTime: sortedTimes[sortedTimes.length - 1] || 0,
      p50ResponseTime: sortedTimes[Math.floor(sortedTimes.length * 0.5)] || 0,
      p95ResponseTime: sortedTimes[Math.floor(sortedTimes.length * 0.95)] || 0,
      p99ResponseTime: sortedTimes[Math.floor(sortedTimes.length * 0.99)] || 0,
      throughput: (successfulRequests / duration) * 1000,
      errorRate: failedRequests / totalRequests,
      timeoutRate: timeoutCount / totalRequests,
      memoryPeak: this.getMemoryUsage(),
      cpuPeak: 0, // Would need Node.js os module
      duration,
      passed: false,
      grade: 'F'
    };

    // Determine grade
    result.grade = this.calculateGrade(result);
    result.passed = result.grade !== 'F';

    this.results.push(result);
    this.isRunning = false;

    return result;
  }

  async runBenchmark(
    name: string,
    fn: () => Promise<unknown>,
    iterations: number = 1000,
    threshold: number = 100 // ms
  ): Promise<BenchmarkResult> {
    const times: number[] = [];
    let memoryBefore = this.getMemoryUsage();

    for (let i = 0; i < iterations; i++) {
      const start = performance.now();
      await fn();
      times.push(performance.now() - start);
    }

    const totalTime = times.reduce((a, b) => a + b, 0);
    const memoryAfter = this.getMemoryUsage();

    const result: BenchmarkResult = {
      name,
      iterations,
      totalTime,
      avgTime: totalTime / iterations,
      minTime: Math.min(...times),
      maxTime: Math.max(...times),
      opsPerSecond: (iterations / totalTime) * 1000,
      memoryUsed: memoryAfter - memoryBefore,
      passed: (totalTime / iterations) < threshold,
      threshold
    };

    this.benchmarks.push(result);
    return result;
  }

  async runConcurrentTest(
    testName: string,
    fn: () => Promise<unknown>,
    concurrentOps: number,
    totalOps: number
  ): Promise<ConcurrentTestResult> {
    const startTime = Date.now();
    const errors: string[] = [];
    let successfulOps = 0;
    let failedOps = 0;

    // Run operations in batches
    const batches = Math.ceil(totalOps / concurrentOps);

    for (let batch = 0; batch < batches; batch++) {
      const batchSize = Math.min(concurrentOps, totalOps - batch * concurrentOps);
      
      const batchPromises = Array(batchSize).fill(null).map(async () => {
        try {
          await fn();
          successfulOps++;
        } catch (error) {
          failedOps++;
          errors.push(error instanceof Error ? error.message : String(error));
        }
      });

      await Promise.all(batchPromises);
    }

    const totalTime = Date.now() - startTime;

    return {
      testName,
      concurrentOps,
      totalOps,
      successfulOps,
      failedOps,
      avgLatency: totalTime / totalOps,
      throughput: (successfulOps / totalTime) * 1000,
      errors: errors.slice(0, 10) // Keep first 10 errors
    };
  }

  async runMemoryLeakTest(
    fn: () => Promise<unknown>,
    iterations: number = 1000,
    threshold: number = 1024 * 1024 // 1MB growth
  ): Promise<MemoryLeakResult> {
    const samples: number[] = [];
    const baseline = this.getMemoryUsage();

    for (let i = 0; i < iterations; i++) {
      await fn();
      
      // Sample memory every 100 iterations
      if (i % 100 === 0) {
        samples.push(this.getMemoryUsage());
        // Force garbage collection if available
        if (global.gc) {
          global.gc();
        }
      }
    }

    const peak = Math.max(...samples);
    const growth = peak - baseline;
    const leakRate = growth / (iterations * (Date.now() / 1000));

    return {
      detected: growth > threshold,
      baseline,
      peak,
      growth,
      samples: samples.length,
      leakRate,
      passed: growth <= threshold
    };
  }

  async runFullSuite(config?: Partial<StressTestConfig>): Promise<{
    stressTest: StressTestResult;
    benchmarks: BenchmarkResult[];
    concurrent: ConcurrentTestResult[];
    memory: MemoryLeakResult;
    overall: {
      passed: boolean;
      score: number;
      grade: string;
    };
  }> {
    const defaultConfig: StressTestConfig = {
      concurrentUsers: 100,
      requestsPerUser: 100,
      rampUpTime: 5000,
      duration: 60000,
      targetThroughput: 10000,
      timeoutMs: 5000,
      retryAttempts: 3,
      ...config
    };

    // Run stress test
    const stressTest = await this.runStressTest(defaultConfig);

    // Run benchmarks for each scenario
    for (const scenario of this.scenarios) {
      await this.runBenchmark(
        scenario.name,
        scenario.execute,
        100,
        100
      );
    }

    // Run concurrent tests
    const concurrent: ConcurrentTestResult[] = [];
    for (const scenario of this.scenarios) {
      const result = await this.runConcurrentTest(
        scenario.name,
        scenario.execute,
        50,
        1000
      );
      concurrent.push(result);
    }

    // Run memory leak test with first scenario
    const memory = this.scenarios.length > 0
      ? await this.runMemoryLeakTest(this.scenarios[0].execute, 500)
      : { detected: false, baseline: 0, peak: 0, growth: 0, samples: 0, leakRate: 0, passed: true };

    // Calculate overall score
    const benchmarkScore = this.benchmarks.filter(b => b.passed).length / Math.max(this.benchmarks.length, 1);
    const concurrentScore = concurrent.reduce((sum, c) => sum + (c.failedOps / c.totalOps), 0) / Math.max(concurrent.length, 1);
    
    const overallScore = (
      (stressTest.passed ? 0.4 : 0) +
      (benchmarkScore * 0.3) +
      ((1 - concurrentScore) * 0.2) +
      (memory.passed ? 0.1 : 0)
    );

    return {
      stressTest,
      benchmarks: this.benchmarks,
      concurrent,
      memory,
      overall: {
        passed: overallScore >= 0.7,
        score: overallScore * 100,
        grade: this.scoreToGrade(overallScore * 100)
      }
    };
  }

  abort(): void {
    this.abortController?.abort();
    this.isRunning = false;
  }

  getResults(): StressTestResult[] {
    return [...this.results];
  }

  getBenchmarks(): BenchmarkResult[] {
    return [...this.benchmarks];
  }

  private selectWeightedScenario(): LoadTestScenario {
    const totalWeight = this.scenarios.reduce((sum, s) => sum + s.weight, 0);
    let random = Math.random() * totalWeight;

    for (const scenario of this.scenarios) {
      random -= scenario.weight;
      if (random <= 0) return scenario;
    }

    return this.scenarios[0];
  }

  private createTimeout(ms: number): Promise<never> {
    return new Promise((_, reject) => {
      setTimeout(() => reject(new Error('TIMEOUT')), ms);
    });
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  private getMemoryUsage(): number {
    if (typeof process !== 'undefined' && process.memoryUsage) {
      return process.memoryUsage().heapUsed;
    }
    return 0;
  }

  private calculateGrade(result: StressTestResult): StressTestResult['grade'] {
    const score = this.scoreStressTest(result);
    return this.scoreToGrade(score);
  }

  private scoreStressTest(result: StressTestResult): number {
    let score = 100;

    // Penalize high response times
    if (result.avgResponseTime > 1000) score -= 30;
    else if (result.avgResponseTime > 500) score -= 20;
    else if (result.avgResponseTime > 200) score -= 10;
    else if (result.avgResponseTime > 100) score -= 5;

    // Penalize high error rates
    score -= result.errorRate * 50;

    // Penalize timeouts
    score -= result.timeoutRate * 30;

    // Penalize low throughput
    if (result.throughput < 100) score -= 20;
    else if (result.throughput < 500) score -= 10;
    else if (result.throughput < 1000) score -= 5;

    // Reward high success rate
    if (result.successfulRequests / result.totalRequests > 0.99) score += 10;

    return Math.max(0, Math.min(100, score));
  }

  private scoreToGrade(score: number): 'A+' | 'A' | 'B' | 'C' | 'D' | 'F' {
    if (score >= 98) return 'A+';
    if (score >= 90) return 'A';
    if (score >= 80) return 'B';
    if (score >= 70) return 'C';
    if (score >= 60) return 'D';
    return 'F';
  }
}

// ============================================================================
// DETECTION STRESS TESTS
// ============================================================================

export class DetectionStressTests {
  private engine: StressTestEngine;

  constructor() {
    this.engine = new StressTestEngine();
    this.setupScenarios();
  }

  private setupScenarios(): void {
    // Deepfake detection scenarios
    this.engine.addScenario({
      name: 'image-detection',
      weight: 3,
      execute: async () => {
        // Simulate image detection
        return { type: 'image', confidence: 0.92, processingTime: Math.random() * 50 + 10 };
      }
    });

    this.engine.addScenario({
      name: 'video-detection',
      weight: 2,
      execute: async () => {
        // Simulate video detection
        await this.delay(Math.random() * 100 + 50);
        return { type: 'video', confidence: 0.88, framesProcessed: 30 };
      }
    });

    this.engine.addScenario({
      name: 'audio-detection',
      weight: 2,
      execute: async () => {
        // Simulate audio detection
        await this.delay(Math.random() * 80 + 30);
        return { type: 'audio', confidence: 0.84, segmentsAnalyzed: 10 };
      }
    });

    this.engine.addScenario({
      name: 'attribution',
      weight: 1,
      execute: async () => {
        // Simulate generator attribution
        await this.delay(Math.random() * 30 + 10);
        return { generator: 'runway-gen3', confidence: 0.91 };
      }
    });

    this.engine.addScenario({
      name: 'agentic-analysis',
      weight: 1,
      execute: async () => {
        // Simulate agentic behavior analysis
        await this.delay(Math.random() * 40 + 20);
        return { agentId: 'agent-001', trustScore: 0.95, anomalies: [] };
      }
    });
  }

  async runFullStressTest(): Promise<{
    stressTest: StressTestResult;
    benchmarks: BenchmarkResult[];
    concurrent: ConcurrentTestResult[];
    memory: MemoryLeakResult;
    overall: { passed: boolean; score: number; grade: string };
  }> {
    return this.engine.runFullSuite({
      concurrentUsers: 200,
      requestsPerUser: 200,
      rampUpTime: 10000,
      duration: 120000,
      targetThroughput: 20000,
      timeoutMs: 3000,
      retryAttempts: 2
    });
  }

  getEngine(): StressTestEngine {
    return this.engine;
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// ============================================================================
// PERFORMANCE MONITOR
// ============================================================================

export class PerformanceMonitor {
  private metrics: Map<string, number[]> = new Map();
  private thresholds: Map<string, number> = new Map();
  private alerts: Array<{ metric: string; value: number; threshold: number; timestamp: number }> = [];

  setThreshold(metric: string, threshold: number): void {
    this.thresholds.set(metric, threshold);
  }

  record(metric: string, value: number): void {
    if (!this.metrics.has(metric)) {
      this.metrics.set(metric, []);
    }
    
    const values = this.metrics.get(metric)!;
    values.push(value);

    // Keep last 1000 samples
    if (values.length > 1000) {
      values.shift();
    }

    // Check threshold
    const threshold = this.thresholds.get(metric);
    if (threshold !== undefined && value > threshold) {
      this.alerts.push({
        metric,
        value,
        threshold,
        timestamp: Date.now()
      });
    }
  }

  getStats(metric: string): {
    count: number;
    avg: number;
    min: number;
    max: number;
    p50: number;
    p95: number;
    p99: number;
  } | null {
    const values = this.metrics.get(metric);
    if (!values || values.length === 0) return null;

    const sorted = [...values].sort((a, b) => a - b);
    const len = sorted.length;

    return {
      count: len,
      avg: values.reduce((a, b) => a + b, 0) / len,
      min: sorted[0],
      max: sorted[len - 1],
      p50: sorted[Math.floor(len * 0.5)],
      p95: sorted[Math.floor(len * 0.95)],
      p99: sorted[Math.floor(len * 0.99)]
    };
  }

  getAlerts(since?: number): typeof this.alerts {
    if (since) {
      return this.alerts.filter(a => a.timestamp >= since);
    }
    return [...this.alerts];
  }

  clearAlerts(): void {
    this.alerts = [];
  }

  clearMetrics(): void {
    this.metrics.clear();
  }

  export(): Record<string, ReturnType<PerformanceMonitor['getStats']>> {
    const result: Record<string, ReturnType<PerformanceMonitor['getStats']>> = {};
    
    for (const metric of this.metrics.keys()) {
      result[metric] = this.getStats(metric);
    }
    
    return result;
  }
}

// ============================================================================
// SINGLETON EXPORTS
// ============================================================================

export const stressTestEngine = new StressTestEngine();
export const detectionStressTests = new DetectionStressTests();
export const performanceMonitor = new PerformanceMonitor();

// Set default thresholds
performanceMonitor.setThreshold('response_time', 100); // 100ms
performanceMonitor.setThreshold('error_rate', 0.01); // 1%
performanceMonitor.setThreshold('memory_usage', 500 * 1024 * 1024); // 500MB

export default StressTestEngine;
