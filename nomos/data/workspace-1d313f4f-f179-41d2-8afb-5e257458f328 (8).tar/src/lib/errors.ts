/**
 * Enterprise-grade error handling
 * Custom error types with proper inheritance and error codes
 */

/**
 * Base application error
 */
export class AppError extends Error {
  public readonly code: string
  public readonly statusCode: number
  public readonly isOperational: boolean
  public readonly timestamp: string
  public readonly context?: Record<string, unknown>

  constructor(
    message: string,
    code: string,
    statusCode: number = 500,
    isOperational: boolean = true,
    context?: Record<string, unknown>
  ) {
    super(message)
    this.name = this.constructor.name
    this.code = code
    this.statusCode = statusCode
    this.isOperational = isOperational
    this.timestamp = new Date().toISOString()
    this.context = context

    // Maintains proper stack trace for where error was thrown
    if (Error.captureStackTrace) {
      Error.captureStackTrace(this, this.constructor)
    }
  }

  toJSON() {
    return {
      success: false,
      error: {
        message: this.message,
        code: this.code,
        statusCode: this.statusCode,
        timestamp: this.timestamp,
        ...(this.context && { context: this.context })
      }
    }
  }
}

/**
 * Validation error - client sent invalid input
 */
export class ValidationError extends AppError {
  constructor(message: string, context?: Record<string, unknown>) {
    super(message, 'VALIDATION_ERROR', 400, true, context)
  }
}

/**
 * File validation error
 */
export class FileValidationError extends AppError {
  constructor(message: string, code: string = 'FILE_VALIDATION_ERROR', context?: Record<string, unknown>) {
    super(message, code, 400, true, context)
  }
}

/**
 * Authentication error
 */
export class AuthenticationError extends AppError {
  constructor(message: string = 'Authentication required') {
    super(message, 'AUTHENTICATION_ERROR', 401, true)
  }
}

/**
 * Authorization error
 */
export class AuthorizationError extends AppError {
  constructor(message: string = 'Insufficient permissions') {
    super(message, 'AUTHORIZATION_ERROR', 403, true)
  }
}

/**
 * Not found error
 */
export class NotFoundError extends AppError {
  constructor(resource: string = 'Resource') {
    super(`${resource} not found`, 'NOT_FOUND', 404, true)
  }
}

/**
 * Rate limit error
 */
export class RateLimitError extends AppError {
  public readonly retryAfter: number

  constructor(retryAfter: number) {
    super(
      `Rate limit exceeded. Please try again in ${retryAfter} seconds.`,
      'RATE_LIMIT_EXCEEDED',
      429,
      true
    )
    this.retryAfter = retryAfter
  }
}

/**
 * File size error
 */
export class FileSizeError extends FileValidationError {
  constructor(size: number, maxSize: number) {
    super(
      `File size (${formatBytes(size)}) exceeds maximum allowed size (${formatBytes(maxSize)})`,
      'FILE_TOO_LARGE',
      { size, maxSize }
    )
  }
}

/**
 * File type error
 */
export class FileTypeError extends FileValidationError {
  constructor(type: string, allowedTypes: string[]) {
    super(
      `File type '${type}' is not allowed. Allowed types: ${allowedTypes.join(', ')}`,
      'INVALID_FILE_TYPE',
      { type, allowedTypes }
    )
  }
}

/**
 * File signature error (potential spoofing)
 */
export class FileSignatureError extends FileValidationError {
  constructor(claimedType: string, detectedType?: string) {
    super(
      detectedType
        ? `File signature mismatch: claimed ${claimedType} but detected ${detectedType}. Possible file type spoofing.`
        : `Invalid file signature for ${claimedType}. File may be corrupted or spoofed.`,
      'FILE_SIGNATURE_MISMATCH',
      { claimedType, detectedType }
    )
  }
}

/**
 * Analysis error
 */
export class AnalysisError extends AppError {
  constructor(message: string, context?: Record<string, unknown>) {
    super(message, 'ANALYSIS_ERROR', 500, true, context)
  }
}

/**
 * AI service error
 */
export class AIServiceError extends AppError {
  constructor(message: string, context?: Record<string, unknown>) {
    super(message, 'AI_SERVICE_ERROR', 503, true, context)
  }
}

/**
 * Circuit breaker error
 */
export class CircuitBreakerError extends AppError {
  constructor(serviceName: string, retryAfterMs: number) {
    super(
      `Service '${serviceName}' is temporarily unavailable. Please try again later.`,
      'CIRCUIT_BREAKER_OPEN',
      503,
      true,
      { serviceName, retryAfterMs }
    )
  }
}

/**
 * Database error
 */
export class DatabaseError extends AppError {
  constructor(message: string, context?: Record<string, unknown>) {
    super(message, 'DATABASE_ERROR', 500, true, context)
  }
}

/**
 * Timeout error
 */
export class TimeoutError extends AppError {
  constructor(operation: string, timeoutMs: number) {
    super(
      `Operation '${operation}' timed out after ${timeoutMs}ms`,
      'TIMEOUT_ERROR',
      504,
      true,
      { operation, timeoutMs }
    )
  }
}

/**
 * Error handler utility
 */
export function handleError(error: unknown): AppError {
  // Already an AppError
  if (error instanceof AppError) {
    return error
  }

  // Standard Error
  if (error instanceof Error) {
    // Check for specific error types
    if (error.name === 'PrismaClientKnownRequestError') {
      return new DatabaseError('Database operation failed', { originalError: error.message })
    }
    
    if (error.name === 'PrismaClientValidationError') {
      return new ValidationError('Invalid data provided')
    }
    
    if (error.message.includes('timeout') || error.message.includes('ETIMEDOUT')) {
      return new TimeoutError('request', 30000)
    }
    
    if (error.message.includes('rate limit') || error.message.includes('429')) {
      return new RateLimitError(60)
    }

    // Generic error
    return new AppError(
      process.env.NODE_ENV === 'production' 
        ? 'An unexpected error occurred' 
        : error.message,
      'INTERNAL_ERROR',
      500,
      false,
      { originalError: error.message, stack: error.stack }
    )
  }

  // Unknown error type
  return new AppError(
    'An unexpected error occurred',
    'UNKNOWN_ERROR',
    500,
    false,
    { error: String(error) }
  )
}

/**
 * Check if error is operational (expected) or programming error
 */
export function isOperationalError(error: Error): boolean {
  if (error instanceof AppError) {
    return error.isOperational
  }
  return false
}

/**
 * Format bytes to human readable
 */
function formatBytes(bytes: number): string {
  if (bytes === 0) return '0 Bytes'
  const k = 1024
  const sizes = ['Bytes', 'KB', 'MB', 'GB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
}

/**
 * Create error response for API
 */
export function createErrorResponse(error: unknown): {
  success: false
  error: string
  code?: string
  details?: Record<string, unknown>
} {
  const appError = handleError(error)
  
  const response: {
    success: false
    error: string
    code?: string
    details?: Record<string, unknown>
  } = {
    success: false,
    error: appError.message
  }
  
  if (appError.code) {
    response.code = appError.code
  }
  
  // Only include details in development
  if (process.env.NODE_ENV !== 'production' && appError.context) {
    response.details = appError.context
  }
  
  return response
}
