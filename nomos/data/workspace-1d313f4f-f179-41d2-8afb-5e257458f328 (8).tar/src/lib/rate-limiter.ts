/**
 * Enterprise-grade rate limiting utility
 * Implements sliding window rate limiting with memory-efficient storage
 */

interface RateLimitEntry {
  count: number
  resetTime: number
  blocked: boolean
}

interface RateLimitConfig {
  windowMs: number        // Time window in milliseconds
  maxRequests: number     // Maximum requests per window
  blockDurationMs: number // How long to block after exceeding limit
  keyGenerator?: (identifier: string) => string
}

interface RateLimitResult {
  allowed: boolean
  remaining: number
  resetTime: number
  retryAfter?: number
  blocked: boolean
}

// In-memory store for rate limiting
// Using Map for O(1) lookups
const rateLimitStore = new Map<string, RateLimitEntry>()

// Cleanup interval to prevent memory leaks
const CLEANUP_INTERVAL = 60 * 1000 // 1 minute
const STORE_MAX_SIZE = 10000 // Maximum entries to prevent memory exhaustion

// Cleanup function
function cleanupStore() {
  const now = Date.now()
  let size = rateLimitStore.size
  
  for (const [key, entry] of rateLimitStore) {
    if (entry.resetTime < now && !entry.blocked) {
      rateLimitStore.delete(key)
      size--
    }
    // Also remove blocked entries that have served their time
    if (entry.blocked && entry.resetTime < now) {
      rateLimitStore.delete(key)
      size--
    }
    // Stop if we're under limit
    if (size < STORE_MAX_SIZE * 0.8) break
  }
}

// Run cleanup periodically
if (typeof setInterval !== 'undefined') {
  setInterval(cleanupStore, CLEANUP_INTERVAL)
}

/**
 * Default rate limit configurations for different scenarios
 */
export const RATE_LIMITS = {
  // General API rate limit
  API: {
    windowMs: 60 * 1000,        // 1 minute
    maxRequests: 60,             // 60 requests per minute
    blockDurationMs: 60 * 1000, // 1 minute block
  },
  
  // Strict rate limit for detection endpoint (computationally expensive)
  DETECTION: {
    windowMs: 60 * 1000,         // 1 minute
    maxRequests: 20,              // 20 requests per minute (increased for better UX)
    blockDurationMs: 60 * 1000,   // 1 minute block (reduced from 10 min)
  },
  
  // More lenient for read operations
  READ: {
    windowMs: 60 * 1000,         // 1 minute
    maxRequests: 120,             // 120 requests per minute
    blockDurationMs: 30 * 1000,   // 30 second block
  },
  
  // Very strict for unauthenticated requests
  ANONYMOUS: {
    windowMs: 60 * 1000,         // 1 minute
    maxRequests: 10,               // 10 requests per minute
    blockDurationMs: 60 * 1000, // 1 minute block
  },
} as const

/**
 * Create a rate limiter instance
 */
export function createRateLimiter(config: RateLimitConfig) {
  return {
    /**
     * Check if request is allowed
     */
    check(identifier: string): RateLimitResult {
      const now = Date.now()
      const key = config.keyGenerator 
        ? config.keyGenerator(identifier) 
        : `ratelimit:${identifier}`

      const entry = rateLimitStore.get(key)

      // No entry exists - allow and create new
      if (!entry) {
        rateLimitStore.set(key, {
          count: 1,
          resetTime: now + config.windowMs,
          blocked: false
        })
        
        return {
          allowed: true,
          remaining: config.maxRequests - 1,
          resetTime: now + config.windowMs,
          blocked: false
        }
      }

      // Entry exists and is blocked
      if (entry.blocked) {
        if (now < entry.resetTime) {
          const retryAfter = Math.ceil((entry.resetTime - now) / 1000)
          return {
            allowed: false,
            remaining: 0,
            resetTime: entry.resetTime,
            retryAfter,
            blocked: true
          }
        }
        // Block has expired, reset
        rateLimitStore.set(key, {
          count: 1,
          resetTime: now + config.windowMs,
          blocked: false
        })
        return {
          allowed: true,
          remaining: config.maxRequests - 1,
          resetTime: now + config.windowMs,
          blocked: false
        }
      }

      // Window has expired - reset
      if (now >= entry.resetTime) {
        rateLimitStore.set(key, {
          count: 1,
          resetTime: now + config.windowMs,
          blocked: false
        })
        return {
          allowed: true,
          remaining: config.maxRequests - 1,
          resetTime: now + config.windowMs,
          blocked: false
        }
      }

      // Within window - increment count
      const newCount = entry.count + 1
      
      if (newCount > config.maxRequests) {
        // Exceeded limit - block
        const blockUntil = now + config.blockDurationMs
        rateLimitStore.set(key, {
          count: newCount,
          resetTime: blockUntil,
          blocked: true
        })
        
        return {
          allowed: false,
          remaining: 0,
          resetTime: blockUntil,
          retryAfter: Math.ceil(config.blockDurationMs / 1000),
          blocked: true
        }
      }

      // Still within limits
      rateLimitStore.set(key, {
        ...entry,
        count: newCount
      })

      return {
        allowed: true,
        remaining: config.maxRequests - newCount,
        resetTime: entry.resetTime,
        blocked: false
      }
    },

    /**
     * Reset rate limit for an identifier
     */
    reset(identifier: string): void {
      const key = config.keyGenerator 
        ? config.keyGenerator(identifier) 
        : `ratelimit:${identifier}`
      rateLimitStore.delete(key)
    },

    /**
     * Get current status without incrementing
     */
    peek(identifier: string): RateLimitResult {
      const now = Date.now()
      const key = config.keyGenerator 
        ? config.keyGenerator(identifier) 
        : `ratelimit:${identifier}`

      const entry = rateLimitStore.get(key)

      if (!entry || now >= entry.resetTime) {
        return {
          allowed: true,
          remaining: config.maxRequests,
          resetTime: now + config.windowMs,
          blocked: false
        }
      }

      if (entry.blocked) {
        return {
          allowed: false,
          remaining: 0,
          resetTime: entry.resetTime,
          retryAfter: Math.ceil((entry.resetTime - now) / 1000),
          blocked: true
        }
      }

      return {
        allowed: entry.count < config.maxRequests,
        remaining: Math.max(0, config.maxRequests - entry.count),
        resetTime: entry.resetTime,
        blocked: false
      }
    }
  }
}

// Pre-configured rate limiters
export const apiLimiter = createRateLimiter(RATE_LIMITS.API)
export const detectionLimiter = createRateLimiter(RATE_LIMITS.DETECTION)
export const readLimiter = createRateLimiter(RATE_LIMITS.READ)
export const anonymousLimiter = createRateLimiter(RATE_LIMITS.ANONYMOUS)

/**
 * Get client identifier from request
 * Uses multiple factors to identify clients reliably
 */
export function getClientIdentifier(request: Request): string {
  // Try various headers that might identify the client
  const headers = request.headers
  
  // Priority order for identification
  const identifiers = [
    headers.get('x-forwarded-for'),
    headers.get('x-real-ip'),
    headers.get('cf-connecting-ip'), // Cloudflare
    headers.get('true-client-ip'),   // Akamai
    headers.get('x-client-ip'),
  ]

  // Find first valid IP
  for (const id of identifiers) {
    if (id) {
      // x-forwarded-for can have multiple IPs, take the first
      const ip = id.split(',')[0].trim()
      if (ip && ip !== 'unknown') {
        return ip
      }
    }
  }

  // Fallback to a hash of user agent + accept headers
  const userAgent = headers.get('user-agent') || 'unknown'
  const accept = headers.get('accept') || ''
  
  // Simple hash function
  const str = `${userAgent}:${accept}`
  let hash = 0
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i)
    hash = ((hash << 5) - hash) + char
    hash = hash & hash // Convert to 32bit integer
  }
  
  return `anon:${Math.abs(hash).toString(36)}`
}

/**
 * Create rate limit headers for response
 */
export function createRateLimitHeaders(result: RateLimitResult): Headers {
  const headers = new Headers()
  
  headers.set('X-RateLimit-Limit', RATE_LIMITS.DETECTION.maxRequests.toString())
  headers.set('X-RateLimit-Remaining', result.remaining.toString())
  headers.set('X-RateLimit-Reset', result.resetTime.toString())
  
  if (result.retryAfter) {
    headers.set('Retry-After', result.retryAfter.toString())
  }
  
  return headers
}
