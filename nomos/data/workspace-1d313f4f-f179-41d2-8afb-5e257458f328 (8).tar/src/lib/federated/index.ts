/**
 * Federated Learning Module
 */

export { 
  FederatedLearningCoordinator,
  EdgeNodeSimulator,
  federatedLearningCoordinator,
  type FederatedNode,
  type ModelUpdate,
  type GlobalModel,
  type TrainingRound,
  type PrivacyConfig,
  type FederatedConfig,
  type AggregationResult
} from './federated-learning';
