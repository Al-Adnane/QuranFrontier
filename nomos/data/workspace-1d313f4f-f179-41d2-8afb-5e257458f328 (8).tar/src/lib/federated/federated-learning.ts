/**
 * Kasbah Federated Learning Network
 * Privacy-preserving distributed model training
 */

// ============================================================================
// TYPES
// ============================================================================

export interface FederatedNode {
  id: string;
  type: 'edge' | 'cloud' | 'mobile' | 'enterprise';
  status: 'online' | 'offline' | 'training' | 'syncing';
  lastSync: number;
  modelVersion: string;
  dataPoints: number;
  computeCapacity: number;
  trustScore: number;
  contributions: number;
  location?: string;
}

export interface ModelUpdate {
  id: string;
  nodeId: string;
  modelVersion: string;
  timestamp: number;
  gradients: number[];
  weights: Record<string, number[]>;
  metrics: {
    loss: number;
    accuracy: number;
    samplesProcessed: number;
  };
  signature: string;
  verified: boolean;
}

export interface GlobalModel {
  version: string;
  createdAt: number;
  updatedAt: number;
  architecture: string;
  weights: Record<string, number[]>;
  metrics: {
    globalAccuracy: number;
    globalLoss: number;
    participatingNodes: number;
    totalDataPoints: number;
  };
  updateHistory: ModelUpdate[];
}

export interface TrainingRound {
  id: string;
  roundNumber: number;
  startTime: number;
  endTime?: number;
  status: 'pending' | 'active' | 'aggregating' | 'completed' | 'failed';
  participatingNodes: string[];
  receivedUpdates: ModelUpdate[];
  aggregatedUpdate?: ModelUpdate;
  metrics: {
    avgLoss: number;
    avgAccuracy: number;
    convergenceScore: number;
  };
}

export interface PrivacyConfig {
  differentialPrivacy: boolean;
  epsilon: number; // Privacy budget
  delta: number; // Privacy relaxation
  secureAggregation: boolean;
  gradientClipping: boolean;
  clippingNorm: number;
  noiseMultiplier: number;
}

export interface FederatedConfig {
  minNodesPerRound: number;
  maxNodesPerRound: number;
  roundsPerVersion: number;
  learningRate: number;
  batchSize: number;
  localEpochs: number;
  convergenceThreshold: number;
  timeout: number;
  privacy: PrivacyConfig;
}

export interface DataSummary {
  nodeId: string;
  dataType: 'image' | 'video' | 'audio' | 'text';
  sampleCount: number;
  labelDistribution: Record<string, number>;
  qualityScore: number;
  lastUpdated: number;
}

export interface AggregationResult {
  roundId: string;
  nodeContributions: Array<{
    nodeId: string;
    weight: number;
    qualityScore: number;
  }>;
  aggregatedGradients: number[];
  aggregatedWeights: Record<string, number[]>;
  noiseAdded: number;
  privacyBudgetUsed: number;
}

export interface FederatedStats {
  totalNodes: number;
  activeNodes: number;
  totalDataPoints: number;
  currentRound: number;
  modelVersion: string;
  avgAccuracy: number;
  privacyBudgetRemaining: number;
  roundsCompleted: number;
  lastUpdate: number;
}

// ============================================================================
// FEDERATED LEARNING COORDINATOR
// ============================================================================

export class FederatedLearningCoordinator {
  private nodes = new Map<string, FederatedNode>();
  private globalModel: GlobalModel;
  private currentRound: TrainingRound | null = null;
  private roundHistory: TrainingRound[] = [];
  private config: FederatedConfig;
  private privacyBudget: number;
  private dataSummaries = new Map<string, DataSummary>();

  constructor(config?: Partial<FederatedConfig>) {
    this.config = {
      minNodesPerRound: config?.minNodesPerRound || 3,
      maxNodesPerRound: config?.maxNodesPerRound || 100,
      roundsPerVersion: config?.roundsPerVersion || 10,
      learningRate: config?.learningRate || 0.01,
      batchSize: config?.batchSize || 32,
      localEpochs: config?.localEpochs || 5,
      convergenceThreshold: config?.convergenceThreshold || 0.001,
      timeout: config?.timeout || 300000, // 5 minutes
      privacy: {
        differentialPrivacy: config?.privacy?.differentialPrivacy ?? true,
        epsilon: config?.privacy?.epsilon || 1.0,
        delta: config?.privacy?.delta || 1e-5,
        secureAggregation: config?.privacy?.secureAggregation ?? true,
        gradientClipping: config?.privacy?.gradientClipping ?? true,
        clippingNorm: config?.privacy?.clippingNorm || 1.0,
        noiseMultiplier: config?.privacy?.noiseMultiplier || 0.1
      },
      ...config
    };

    this.privacyBudget = this.config.privacy.epsilon * 100; // Total budget

    // Initialize global model
    this.globalModel = {
      version: 'v0.0.1',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      architecture: 'deepfake-detection-v1',
      weights: this.initializeWeights(),
      metrics: {
        globalAccuracy: 0.5,
        globalLoss: 1.0,
        participatingNodes: 0,
        totalDataPoints: 0
      },
      updateHistory: []
    };
  }

  private initializeWeights(): Record<string, number[]> {
    // Initialize model weights (simplified representation)
    return {
      'layer1': Array(100).fill(0).map(() => Math.random() * 0.1 - 0.05),
      'layer2': Array(200).fill(0).map(() => Math.random() * 0.1 - 0.05),
      'layer3': Array(100).fill(0).map(() => Math.random() * 0.1 - 0.05),
      'output': Array(2).fill(0).map(() => Math.random() * 0.1 - 0.05)
    };
  }

  // ============================================================================
  // NODE MANAGEMENT
  // ============================================================================

  registerNode(node: Omit<FederatedNode, 'id' | 'status' | 'lastSync' | 'contributions'>): FederatedNode {
    const id = `node-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    const newNode: FederatedNode = {
      id,
      status: 'online',
      lastSync: Date.now(),
      contributions: 0,
      ...node
    };

    this.nodes.set(id, newNode);
    return newNode;
  }

  unregisterNode(nodeId: string): void {
    const node = this.nodes.get(nodeId);
    if (node) {
      node.status = 'offline';
    }
  }

  updateNodeStatus(nodeId: string, status: FederatedNode['status']): void {
    const node = this.nodes.get(nodeId);
    if (node) {
      node.status = status;
      node.lastSync = Date.now();
    }
  }

  getNode(nodeId: string): FederatedNode | undefined {
    return this.nodes.get(nodeId);
  }

  getActiveNodes(): FederatedNode[] {
    return Array.from(this.nodes.values()).filter(n => n.status !== 'offline');
  }

  submitDataSummary(summary: DataSummary): void {
    this.dataSummaries.set(summary.nodeId, summary);
  }

  // ============================================================================
  // TRAINING ROUNDS
  // ============================================================================

  async startTrainingRound(): Promise<TrainingRound> {
    if (this.currentRound && this.currentRound.status === 'active') {
      throw new Error('A training round is already in progress');
    }

    // Select participating nodes
    const activeNodes = this.getActiveNodes()
      .filter(n => n.trustScore >= 50 && n.status === 'online');
    
    if (activeNodes.length < this.config.minNodesPerRound) {
      throw new Error(`Not enough nodes. Need ${this.config.minNodesPerRound}, have ${activeNodes.length}`);
    }

    const selectedNodes = this.selectNodes(activeNodes);

    const round: TrainingRound = {
      id: `round-${Date.now()}`,
      roundNumber: this.roundHistory.length + 1,
      startTime: Date.now(),
      status: 'active',
      participatingNodes: selectedNodes.map(n => n.id),
      receivedUpdates: [],
      metrics: {
        avgLoss: 0,
        avgAccuracy: 0,
        convergenceScore: 1
      }
    };

    this.currentRound = round;

    // Notify selected nodes
    await this.notifyNodes(selectedNodes, round);

    // Set timeout
    setTimeout(() => this.checkRoundCompletion(round.id), this.config.timeout);

    return round;
  }

  private selectNodes(nodes: FederatedNode[]): FederatedNode[] {
    // Weighted random selection based on trust score and data points
    const maxNodes = Math.min(this.config.maxNodesPerRound, nodes.length);
    
    // Sort by trust score * data points (prioritize reliable nodes with more data)
    const sorted = [...nodes].sort((a, b) => 
      (b.trustScore * Math.log10(b.dataPoints + 1)) - (a.trustScore * Math.log10(a.dataPoints + 1))
    );

    return sorted.slice(0, maxNodes);
  }

  private async notifyNodes(nodes: FederatedNode[], round: TrainingRound): Promise<void> {
    // In production, would send notifications to nodes
    for (const node of nodes) {
      node.status = 'training';
    }
  }

  async submitUpdate(update: Omit<ModelUpdate, 'id' | 'verified'>): Promise<{ accepted: boolean; reason?: string }> {
    if (!this.currentRound || this.currentRound.status !== 'active') {
      return { accepted: false, reason: 'No active training round' };
    }

    if (!this.currentRound.participatingNodes.includes(update.nodeId)) {
      return { accepted: false, reason: 'Node not participating in this round' };
    }

    // Verify update signature
    const verified = this.verifyUpdate(update);
    if (!verified) {
      return { accepted: false, reason: 'Update signature verification failed' };
    }

    // Apply differential privacy if enabled
    let processedUpdate = update;
    if (this.config.privacy.differentialPrivacy) {
      processedUpdate = this.applyDifferentialPrivacy(update);
    }

    const fullUpdate: ModelUpdate = {
      id: `update-${Date.now()}`,
      verified: true,
      ...processedUpdate
    };

    this.currentRound.receivedUpdates.push(fullUpdate);

    // Check if all updates received
    if (this.currentRound.receivedUpdates.length >= this.currentRound.participatingNodes.length) {
      await this.aggregateUpdates();
    }

    return { accepted: true };
  }

  private verifyUpdate(update: Omit<ModelUpdate, 'id' | 'verified'>): boolean {
    // Verify HMAC signature
    // Simplified for demo
    return update.signature.length > 0;
  }

  private applyDifferentialPrivacy(update: Omit<ModelUpdate, 'id' | 'verified'>): Omit<ModelUpdate, 'id' | 'verified'> {
    // Clip gradients
    if (this.config.privacy.gradientClipping && update.gradients) {
      const norm = Math.sqrt(update.gradients.reduce((sum, g) => sum + g * g, 0));
      if (norm > this.config.privacy.clippingNorm) {
        const scale = this.config.privacy.clippingNorm / norm;
        update.gradients = update.gradients.map(g => g * scale);
      }
    }

    // Add noise for differential privacy
    if (this.config.privacy.differentialPrivacy) {
      const noiseScale = this.config.privacy.noiseMultiplier * this.config.privacy.clippingNorm;
      update.gradients = update.gradients.map(g => 
        g + this.gaussianNoise(0, noiseScale)
      );
    }

    return update;
  }

  private gaussianNoise(mean: number, std: number): number {
    // Box-Muller transform for Gaussian noise
    const u1 = Math.random();
    const u2 = Math.random();
    return mean + std * Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
  }

  // ============================================================================
  // AGGREGATION
  // ============================================================================

  private async aggregateUpdates(): Promise<AggregationResult> {
    if (!this.currentRound) return {} as AggregationResult;

    this.currentRound.status = 'aggregating';

    const updates = this.currentRound.receivedUpdates;
    if (updates.length === 0) {
      this.currentRound.status = 'failed';
      return {} as AggregationResult;
    }

    // Calculate node contributions and weights
    const nodeContributions = updates.map(update => {
      const node = this.nodes.get(update.nodeId);
      const summary = this.dataSummaries.get(update.nodeId);
      
      return {
        nodeId: update.nodeId,
        weight: this.calculateNodeWeight(node, summary, update),
        qualityScore: update.metrics.accuracy
      };
    });

    // Normalize weights
    const totalWeight = nodeContributions.reduce((sum, c) => sum + c.weight, 0);
    nodeContributions.forEach(c => c.weight /= totalWeight);

    // Federated averaging (FedAvg)
    const aggregatedGradients = this.aggregateGradients(updates, nodeContributions);
    const aggregatedWeights = this.aggregateWeights(updates, nodeContributions);

    // Add noise for privacy
    const noiseAdded = this.config.privacy.differentialPrivacy 
      ? this.config.privacy.noiseMultiplier * this.config.privacy.clippingNorm
      : 0;

    // Update privacy budget
    const privacyBudgetUsed = this.config.privacy.epsilon / this.config.roundsPerVersion;
    this.privacyBudget -= privacyBudgetUsed;

    // Update global model
    this.updateGlobalModel(aggregatedWeights, updates);

    const result: AggregationResult = {
      roundId: this.currentRound.id,
      nodeContributions,
      aggregatedGradients,
      aggregatedWeights,
      noiseAdded,
      privacyBudgetUsed
    };

    // Complete the round
    this.currentRound.endTime = Date.now();
    this.currentRound.status = 'completed';
    this.currentRound.metrics = {
      avgLoss: updates.reduce((sum, u) => sum + u.metrics.loss, 0) / updates.length,
      avgAccuracy: updates.reduce((sum, u) => sum + u.metrics.accuracy, 0) / updates.length,
      convergenceScore: this.calculateConvergence(updates)
    };

    this.roundHistory.push(this.currentRound);

    // Update node statuses
    for (const nodeId of this.currentRound.participatingNodes) {
      const node = this.nodes.get(nodeId);
      if (node) {
        node.status = 'online';
        node.contributions++;
        node.modelVersion = this.globalModel.version;
      }
    }

    this.currentRound = null;

    return result;
  }

  private calculateNodeWeight(
    node: FederatedNode | undefined,
    summary: DataSummary | undefined,
    update: ModelUpdate
  ): number {
    let weight = 1.0;

    // Weight by number of samples
    if (update.metrics.samplesProcessed) {
      weight *= Math.log10(update.metrics.samplesProcessed + 1);
    }

    // Weight by trust score
    if (node) {
      weight *= node.trustScore / 100;
    }

    // Weight by data quality
    if (summary) {
      weight *= summary.qualityScore;
    }

    return weight;
  }

  private aggregateGradients(updates: ModelUpdate[], contributions: AggregationResult['nodeContributions']): number[] {
    // Initialize with zeros
    const firstUpdate = updates[0];
    const dim = firstUpdate.gradients.length;
    const aggregated = Array(dim).fill(0);

    for (let i = 0; i < updates.length; i++) {
      const weight = contributions[i].weight;
      const gradients = updates[i].gradients;
      
      for (let j = 0; j < dim; j++) {
        aggregated[j] += weight * gradients[j];
      }
    }

    return aggregated;
  }

  private aggregateWeights(updates: ModelUpdate[], contributions: AggregationResult['nodeContributions']): Record<string, number[]> {
    const aggregated: Record<string, number[]> = {};
    const firstUpdate = updates[0];

    for (const layer of Object.keys(firstUpdate.weights)) {
      const dim = firstUpdate.weights[layer].length;
      aggregated[layer] = Array(dim).fill(0);

      for (let i = 0; i < updates.length; i++) {
        const weight = contributions[i].weight;
        const layerWeights = updates[i].weights[layer];
        
        for (let j = 0; j < dim; j++) {
          aggregated[layer][j] += weight * layerWeights[j];
        }
      }
    }

    return aggregated;
  }

  private updateGlobalModel(newWeights: Record<string, number[]>, updates: ModelUpdate[]): void {
    // Update weights
    for (const layer of Object.keys(newWeights)) {
      this.globalModel.weights[layer] = newWeights[layer];
    }

    // Update metrics
    this.globalModel.metrics.globalAccuracy = updates.reduce((sum, u) => sum + u.metrics.accuracy, 0) / updates.length;
    this.globalModel.metrics.globalLoss = updates.reduce((sum, u) => sum + u.metrics.loss, 0) / updates.length;
    this.globalModel.metrics.participatingNodes = updates.length;
    this.globalModel.metrics.totalDataPoints += updates.reduce((sum, u) => sum + u.metrics.samplesProcessed, 0);
    this.globalModel.updatedAt = Date.now();

    // Bump version every N rounds
    if (this.roundHistory.length % this.config.roundsPerVersion === 0) {
      const [major, minor, patch] = this.globalModel.version.replace('v', '').split('.').map(Number);
      this.globalModel.version = `v${major}.${minor + 1}.${patch}`;
    }
  }

  private calculateConvergence(updates: ModelUpdate[]): number {
    // Calculate convergence based on variance of updates
    if (updates.length < 2) return 1;

    const avgLoss = updates.reduce((sum, u) => sum + u.metrics.loss, 0) / updates.length;
    const variance = updates.reduce((sum, u) => sum + Math.pow(u.metrics.loss - avgLoss, 2), 0) / updates.length;

    return Math.exp(-variance); // Higher convergence = lower variance
  }

  private async checkRoundCompletion(roundId: string): Promise<void> {
    if (this.currentRound && this.currentRound.id === roundId && this.currentRound.status === 'active') {
      // Force aggregation with available updates
      if (this.currentRound.receivedUpdates.length >= this.config.minNodesPerRound) {
        await this.aggregateUpdates();
      } else {
        this.currentRound.status = 'failed';
        this.roundHistory.push(this.currentRound);
        this.currentRound = null;
      }
    }
  }

  // ============================================================================
  // MODEL DISTRIBUTION
  // ============================================================================

  getGlobalModel(): GlobalModel {
    return { ...this.globalModel };
  }

  getModelForNode(nodeId: string): {
    version: string;
    weights: Record<string, number[]>;
    config: { learningRate: number; batchSize: number; localEpochs: number };
  } {
    return {
      version: this.globalModel.version,
      weights: { ...this.globalModel.weights },
      config: {
        learningRate: this.config.learningRate,
        batchSize: this.config.batchSize,
        localEpochs: this.config.localEpochs
      }
    };
  }

  // ============================================================================
  // STATISTICS
  // ============================================================================

  getStats(): FederatedStats {
    const activeNodes = this.getActiveNodes();
    
    return {
      totalNodes: this.nodes.size,
      activeNodes: activeNodes.length,
      totalDataPoints: activeNodes.reduce((sum, n) => sum + n.dataPoints, 0),
      currentRound: this.currentRound?.roundNumber || this.roundHistory.length,
      modelVersion: this.globalModel.version,
      avgAccuracy: this.globalModel.metrics.globalAccuracy,
      privacyBudgetRemaining: this.privacyBudget,
      roundsCompleted: this.roundHistory.length,
      lastUpdate: this.globalModel.updatedAt
    };
  }

  getRoundHistory(): TrainingRound[] {
    return [...this.roundHistory];
  }
}

// ============================================================================
// EDGE NODE SIMULATOR
// ============================================================================

export class EdgeNodeSimulator {
  private nodeId: string;
  private coordinator: FederatedLearningCoordinator;
  private localDataCount: number;
  private localModel: Record<string, number[]> | null = null;

  constructor(coordinator: FederatedLearningCoordinator, type: FederatedNode['type'] = 'edge') {
    this.coordinator = coordinator;
    this.localDataCount = Math.floor(Math.random() * 10000) + 100;

    const node = coordinator.registerNode({
      type,
      modelVersion: 'v0.0.1',
      dataPoints: this.localDataCount,
      computeCapacity: Math.random() * 100,
      trustScore: 70 + Math.random() * 30
    });

    this.nodeId = node.id;
  }

  async participate(): Promise<void> {
    // Get latest model
    const model = this.coordinator.getModelForNode(this.nodeId);
    this.localModel = model.weights;

    // Simulate local training
    const update = await this.trainLocally(model);

    // Submit update
    await this.coordinator.submitUpdate(update);
  }

  private async trainLocally(model: { version: string; weights: Record<string, number[]>; config: { learningRate: number; batchSize: number; localEpochs: number } }): Promise<Omit<ModelUpdate, 'id' | 'verified'>> {
    // Simulate local training epochs
    await new Promise(resolve => setTimeout(resolve, 100 * model.config.localEpochs));

    // Simulate gradient computation
    const gradients = Array(100).fill(0).map(() => (Math.random() - 0.5) * 0.1);

    // Simulate weight updates
    const weights: Record<string, number[]> = {};
    for (const layer of Object.keys(model.weights)) {
      weights[layer] = model.weights[layer].map(w => 
        w + model.config.learningRate * (Math.random() - 0.5) * 0.01
      );
    }

    // Simulate metrics
    const baseAccuracy = 0.7 + Math.random() * 0.2;
    const baseLoss = 0.2 + Math.random() * 0.3;

    return {
      nodeId: this.nodeId,
      modelVersion: model.version,
      timestamp: Date.now(),
      gradients,
      weights,
      metrics: {
        loss: baseLoss,
        accuracy: baseAccuracy,
        samplesProcessed: Math.min(model.config.batchSize * model.config.localEpochs, this.localDataCount)
      },
      signature: `sig-${this.nodeId}-${Date.now()}`
    };
  }

  getNodeId(): string {
    return this.nodeId;
  }
}

// ============================================================================
// SINGLETON EXPORT
// ============================================================================

export const federatedLearningCoordinator = new FederatedLearningCoordinator();

export default FederatedLearningCoordinator;
