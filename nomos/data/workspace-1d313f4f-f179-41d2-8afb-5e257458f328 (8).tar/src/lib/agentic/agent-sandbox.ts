/**
 * Agent Sandbox & Containment System
 * Kasbah AI Safety Platform - Moat: Secure Execution Environments
 * 
 * Provides secure execution environments for untrusted agents with:
 * - Resource usage limits and circuit breakers
 * - Automatic termination triggers
 * - Sandbox isolation levels
 * - Escape detection and prevention
 * 
 * @module agent-sandbox
 * @version 1.0.0
 */

import { generateUUID, randomBytesHex, sha256Sync, hmacSha256 } from '@/lib/crypto-utils'

// ============================================================================
// Type Definitions
// ============================================================================

/**
 * Isolation levels for sandbox environments
 * - strict: Complete isolation, minimal system access
 * - moderate: Limited system access with monitoring
 * - permissive: Broad access with logging only
 */
export type IsolationLevel = 'strict' | 'moderate' | 'permissive'

/**
 * Sandbox session status
 */
export type SandboxStatus = 'initializing' | 'running' | 'paused' | 'terminated' | 'escaped'

/**
 * Severity levels for sandbox violations
 */
export type ViolationSeverity = 'warning' | 'violation' | 'critical'

/**
 * Actions taken for violations
 */
export type ViolationAction = 'logged' | 'blocked' | 'terminated'

/**
 * Types of sandbox violations
 */
export type ViolationType = 
  | 'resource_limit' 
  | 'forbidden_operation' 
  | 'network_violation' 
  | 'file_violation' 
  | 'escape_attempt'

/**
 * Circuit breaker states
 */
export type CircuitBreakerState = 'closed' | 'open' | 'half_open'

/**
 * Trigger types for circuit breakers
 */
export type CircuitBreakerTriggerType = 'error_rate' | 'latency' | 'resource_usage' | 'custom'

/**
 * Comparison operators for termination triggers
 */
export type ComparisonOperator = 'gt' | 'lt' | 'eq' | 'gte' | 'lte'

/**
 * Termination actions
 */
export type TerminationAction = 'terminate' | 'quarantine' | 'alert'

/**
 * Configuration for a sandbox environment
 */
export interface SandboxConfig {
  id: string
  agentId: string
  isolationLevel: IsolationLevel
  resourceLimits: {
    maxCpuMs: number
    maxMemoryBytes: number
    maxNetworkRequests: number
    maxFileOperations: number
    maxExecutionTimeMs: number
  }
  allowedOperations: string[]
  deniedOperations: string[]
  networkAllowList: string[]
  fileAllowList: string[]
  environmentVariables: Record<string, string>
  createdAt: number
}

/**
 * Active sandbox session
 */
export interface SandboxSession {
  id: string
  configId: string
  agentId: string
  status: SandboxStatus
  startTime: number
  endTime?: number
  resourceUsage: {
    cpuMs: number
    memoryBytes: number
    networkRequests: number
    fileOperations: number
  }
  violations: SandboxViolation[]
  terminationReason?: string
}

/**
 * Recorded violation in a sandbox session
 */
export interface SandboxViolation {
  id: string
  sessionId: string
  timestamp: number
  type: ViolationType
  severity: ViolationSeverity
  description: string
  details: Record<string, unknown>
  action: ViolationAction
}

/**
 * Circuit breaker for protecting system resources
 */
export interface CircuitBreaker {
  id: string
  name: string
  agentId?: string
  trigger: {
    type: CircuitBreakerTriggerType
    threshold: number
    timeWindowMs: number
  }
  state: CircuitBreakerState
  failureCount: number
  successCount: number
  lastFailureTime?: number
  lastStateChange: number
  resetTimeoutMs: number
}

/**
 * Termination trigger configuration
 */
export interface TerminationTrigger {
  id: string
  name: string
  conditions: Array<{
    metric: string
    operator: ComparisonOperator
    value: number
  }>
  logic: 'any' | 'all'
  action: TerminationAction
  enabled: boolean
  cooldownMs: number
  lastTriggered?: number
}

/**
 * Configuration for creating a sandbox
 */
export type CreateSandboxConfigInput = Omit<SandboxConfig, 'id' | 'agentId' | 'createdAt'>

/**
 * Configuration for creating a circuit breaker
 */
export type CreateCircuitBreakerInput = Omit<CircuitBreaker, 
  'id' | 'state' | 'failureCount' | 'successCount' | 'lastFailureTime' | 'lastStateChange'>

/**
 * Configuration for creating a termination trigger
 */
export type CreateTerminationTriggerInput = Omit<TerminationTrigger, 'id' | 'lastTriggered'>

/**
 * Input for recording a violation
 */
export type RecordViolationInput = Omit<SandboxViolation, 'id' | 'sessionId' | 'timestamp'>

// ============================================================================
// Constants and Default Values
// ============================================================================

/** Default resource limits for strict isolation */
const STRICT_RESOURCE_LIMITS: SandboxConfig['resourceLimits'] = {
  maxCpuMs: 5000,           // 5 seconds CPU time
  maxMemoryBytes: 128 * 1024 * 1024,  // 128 MB
  maxNetworkRequests: 10,
  maxFileOperations: 20,
  maxExecutionTimeMs: 30000  // 30 seconds max execution
}

/** Default resource limits for moderate isolation */
const MODERATE_RESOURCE_LIMITS: SandboxConfig['resourceLimits'] = {
  maxCpuMs: 30000,          // 30 seconds CPU time
  maxMemoryBytes: 512 * 1024 * 1024,  // 512 MB
  maxNetworkRequests: 100,
  maxFileOperations: 200,
  maxExecutionTimeMs: 300000  // 5 minutes max execution
}

/** Default resource limits for permissive isolation */
const PERMISSIVE_RESOURCE_LIMITS: SandboxConfig['resourceLimits'] = {
  maxCpuMs: 300000,         // 5 minutes CPU time
  maxMemoryBytes: 2 * 1024 * 1024 * 1024,  // 2 GB
  maxNetworkRequests: 1000,
  maxFileOperations: 5000,
  maxExecutionTimeMs: 3600000  // 1 hour max execution
}

/** Secret key for sandbox integrity verification */
const SANDBOX_SECRET = randomBytesHex(32)

/** Known escape patterns to detect */
const ESCAPE_PATTERNS = [
  /\beval\s*\(/gi,
  /\bFunction\s*\(/gi,
  /\brequire\s*\(\s*['"]child_process['"]\s*\)/gi,
  /\brequire\s*\(\s*['"]fs['"]\s*\)/gi,
  /\bprocess\s*\.\s*exit/gi,
  /\bprocess\s*\.\s*binding/gi,
  /\bglobal\s*\./gi,
  /\bglobalThis\s*\./gi,
  /__proto__/gi,
  /\bconstructor\s*\(\s*\)/gi,
  /\[\s*['"]constructor['"]\s*\]/gi,
  /\bimport\s*\(/gi,
  /\bexport\s*\{/gi,
]

// ============================================================================
// In-Memory Storage
// ============================================================================

/** Store for sandbox configurations */
const sandboxConfigs = new Map<string, SandboxConfig>()

/** Store for active sandbox sessions */
const sandboxSessions = new Map<string, SandboxSession>()

/** Store for circuit breakers */
const circuitBreakers = new Map<string, CircuitBreaker>()

/** Store for termination triggers */
const terminationTriggers = new Map<string, TerminationTrigger>()

/** Store for agent quarantine status */
const quarantinedAgents = new Set<string>()

/** Store for escape attempt tracking */
const escapeAttempts = new Map<string, number>()

// ============================================================================
// Sandbox Configuration Management
// ============================================================================

/**
 * Creates a new sandbox configuration for an agent.
 * 
 * @param agentId - Unique identifier for the agent
 * @param config - Sandbox configuration options
 * @returns The created sandbox configuration
 * 
 * @example
 * ```typescript
 * const config = createSandboxConfig('agent-123', {
 *   isolationLevel: 'strict',
 *   resourceLimits: {
 *     maxCpuMs: 10000,
 *     maxMemoryBytes: 256 * 1024 * 1024,
 *     maxNetworkRequests: 50,
 *     maxFileOperations: 100,
 *     maxExecutionTimeMs: 60000
 *   },
 *   allowedOperations: ['read', 'compute'],
 *   deniedOperations: ['write', 'execute'],
 *   networkAllowList: ['api.example.com'],
 *   fileAllowList: ['/tmp/agent-workspace'],
 *   environmentVariables: { NODE_ENV: 'sandbox' }
 * })
 * ```
 */
export function createSandboxConfig(
  agentId: string,
  config: CreateSandboxConfigInput
): SandboxConfig {
  const id = generateUUID()
  const createdAt = Date.now()
  
  // Apply default resource limits based on isolation level if not specified
  const resourceLimits = config.resourceLimits ?? 
    getDefaultResourceLimits(config.isolationLevel)
  
  const sandboxConfig: SandboxConfig = {
    id,
    agentId,
    isolationLevel: config.isolationLevel,
    resourceLimits,
    allowedOperations: config.allowedOperations ?? [],
    deniedOperations: config.deniedOperations ?? [],
    networkAllowList: config.networkAllowList ?? [],
    fileAllowList: config.fileAllowList ?? [],
    environmentVariables: config.environmentVariables ?? {},
    createdAt
  }
  
  // Generate integrity hash for the configuration
  const integrityHash = generateConfigIntegrityHash(sandboxConfig)
  sandboxConfig.environmentVariables['__SANDBOX_INTEGRITY__'] = integrityHash
  
  sandboxConfigs.set(id, sandboxConfig)
  
  return sandboxConfig
}

/**
 * Gets default resource limits for an isolation level.
 */
function getDefaultResourceLimits(level: IsolationLevel): SandboxConfig['resourceLimits'] {
  switch (level) {
    case 'strict':
      return { ...STRICT_RESOURCE_LIMITS }
    case 'moderate':
      return { ...MODERATE_RESOURCE_LIMITS }
    case 'permissive':
      return { ...PERMISSIVE_RESOURCE_LIMITS }
    default:
      return { ...MODERATE_RESOURCE_LIMITS }
  }
}

/**
 * Generates an integrity hash for a sandbox configuration.
 */
function generateConfigIntegrityHash(config: SandboxConfig): string {
  const content = JSON.stringify({
    agentId: config.agentId,
    isolationLevel: config.isolationLevel,
    resourceLimits: config.resourceLimits,
    allowedOperations: config.allowedOperations.sort(),
    deniedOperations: config.deniedOperations.sort(),
    createdAt: config.createdAt
  })
  return sha256Sync(content)
}

/**
 * Retrieves a sandbox configuration by ID.
 * 
 * @param configId - The sandbox configuration ID
 * @returns The sandbox configuration or undefined
 */
export function getSandboxConfig(configId: string): SandboxConfig | undefined {
  return sandboxConfigs.get(configId)
}

/**
 * Retrieves all sandbox configurations for an agent.
 * 
 * @param agentId - The agent ID
 * @returns Array of sandbox configurations
 */
export function getSandboxConfigsByAgent(agentId: string): SandboxConfig[] {
  return Array.from(sandboxConfigs.values()).filter(c => c.agentId === agentId)
}

/**
 * Updates a sandbox configuration.
 * 
 * @param configId - The sandbox configuration ID
 * @param updates - Partial configuration updates
 * @returns The updated configuration or undefined
 */
export function updateSandboxConfig(
  configId: string, 
  updates: Partial<CreateSandboxConfigInput>
): SandboxConfig | undefined {
  const config = sandboxConfigs.get(configId)
  if (!config) return undefined
  
  const updated: SandboxConfig = {
    ...config,
    ...updates,
    resourceLimits: updates.resourceLimits ?? config.resourceLimits
  }
  
  // Update integrity hash
  const integrityHash = generateConfigIntegrityHash(updated)
  updated.environmentVariables['__SANDBOX_INTEGRITY__'] = integrityHash
  
  sandboxConfigs.set(configId, updated)
  return updated
}

/**
 * Deletes a sandbox configuration.
 * 
 * @param configId - The sandbox configuration ID
 * @returns True if deleted, false if not found
 */
export function deleteSandboxConfig(configId: string): boolean {
  return sandboxConfigs.delete(configId)
}

// ============================================================================
// Sandbox Session Management
// ============================================================================

/**
 * Starts a new sandbox session using a configuration.
 * 
 * @param configId - The sandbox configuration ID to use
 * @returns The created sandbox session
 * @throws Error if configuration not found or agent is quarantined
 * 
 * @example
 * ```typescript
 * const session = startSandboxSession('config-uuid')
 * console.log(`Session started: ${session.id}`)
 * ```
 */
export function startSandboxSession(configId: string): SandboxSession {
  const config = sandboxConfigs.get(configId)
  if (!config) {
    throw new Error(`Sandbox configuration not found: ${configId}`)
  }
  
  // Check if agent is quarantined
  if (quarantinedAgents.has(config.agentId)) {
    throw new Error(`Agent is quarantined and cannot start new sessions: ${config.agentId}`)
  }
  
  const id = generateUUID()
  const session: SandboxSession = {
    id,
    configId,
    agentId: config.agentId,
    status: 'initializing',
    startTime: Date.now(),
    resourceUsage: {
      cpuMs: 0,
      memoryBytes: 0,
      networkRequests: 0,
      fileOperations: 0
    },
    violations: []
  }
  
  sandboxSessions.set(id, session)
  
  // Transition to running after initialization
  setTimeout(() => {
    const currentSession = sandboxSessions.get(id)
    if (currentSession && currentSession.status === 'initializing') {
      currentSession.status = 'running'
    }
  }, 100)
  
  return session
}

/**
 * Ends a sandbox session with a reason.
 * 
 * @param sessionId - The sandbox session ID
 * @param reason - The reason for ending the session
 * @returns True if session ended successfully
 * 
 * @example
 * ```typescript
 * endSandboxSession('session-uuid', 'Task completed successfully')
 * ```
 */
export function endSandboxSession(sessionId: string, reason: string): boolean {
  const session = sandboxSessions.get(sessionId)
  if (!session) return false
  
  session.status = 'terminated'
  session.endTime = Date.now()
  session.terminationReason = reason
  
  return true
}

/**
 * Retrieves a sandbox session by ID.
 * 
 * @param sessionId - The sandbox session ID
 * @returns The sandbox session or undefined
 */
export function getSandboxSession(sessionId: string): SandboxSession | undefined {
  return sandboxSessions.get(sessionId)
}

/**
 * Retrieves all active sessions for an agent.
 * 
 * @param agentId - The agent ID
 * @returns Array of active sandbox sessions
 */
export function getActiveSessionsByAgent(agentId: string): SandboxSession[] {
  return Array.from(sandboxSessions.values()).filter(
    s => s.agentId === agentId && (s.status === 'running' || s.status === 'initializing')
  )
}

/**
 * Pauses a sandbox session.
 * 
 * @param sessionId - The sandbox session ID
 * @returns True if paused successfully
 */
export function pauseSandboxSession(sessionId: string): boolean {
  const session = sandboxSessions.get(sessionId)
  if (!session || session.status !== 'running') return false
  
  session.status = 'paused'
  return true
}

/**
 * Resumes a paused sandbox session.
 * 
 * @param sessionId - The sandbox session ID
 * @returns True if resumed successfully
 */
export function resumeSandboxSession(sessionId: string): boolean {
  const session = sandboxSessions.get(sessionId)
  if (!session || session.status !== 'paused') return false
  
  session.status = 'running'
  return true
}

// ============================================================================
// Resource Usage Tracking
// ============================================================================

/**
 * Checks and returns current resource usage for a session.
 * 
 * @param sessionId - The sandbox session ID
 * @returns Current resource usage or undefined if session not found
 * 
 * @example
 * ```typescript
 * const usage = checkResourceUsage('session-uuid')
 * if (usage && usage.cpuMs > 10000) {
 *   console.warn('High CPU usage detected')
 * }
 * ```
 */
export function checkResourceUsage(sessionId: string): SandboxSession['resourceUsage'] | undefined {
  const session = sandboxSessions.get(sessionId)
  if (!session) return undefined
  
  return { ...session.resourceUsage }
}

/**
 * Updates resource usage for a session.
 * 
 * @param sessionId - The sandbox session ID
 * @param usage - Partial resource usage to update
 * @returns Updated resource usage or undefined
 */
export function updateResourceUsage(
  sessionId: string,
  usage: Partial<SandboxSession['resourceUsage']>
): SandboxSession['resourceUsage'] | undefined {
  const session = sandboxSessions.get(sessionId)
  if (!session) return undefined
  
  session.resourceUsage = {
    ...session.resourceUsage,
    ...usage
  }
  
  // Check for resource limit violations
  const config = sandboxConfigs.get(session.configId)
  if (config) {
    checkResourceLimits(session, config)
  }
  
  return { ...session.resourceUsage }
}

/**
 * Increments a specific resource usage counter.
 * 
 * @param sessionId - The sandbox session ID
 * @param resource - The resource type to increment
 * @param amount - The amount to increment by
 */
export function incrementResourceUsage(
  sessionId: string,
  resource: keyof SandboxSession['resourceUsage'],
  amount: number = 1
): void {
  const session = sandboxSessions.get(sessionId)
  if (!session) return
  
  session.resourceUsage[resource] += amount
  
  const config = sandboxConfigs.get(session.configId)
  if (config) {
    checkResourceLimits(session, config)
  }
}

/**
 * Checks if resource limits have been exceeded.
 */
function checkResourceLimits(session: SandboxSession, config: SandboxConfig): void {
  const { resourceUsage, resourceLimits } = { 
    resourceUsage: session.resourceUsage, 
    resourceLimits: config.resourceLimits 
  }
  
  const violations: Array<{ type: string; current: number; limit: number }> = []
  
  if (resourceUsage.cpuMs > resourceLimits.maxCpuMs) {
    violations.push({ type: 'cpuMs', current: resourceUsage.cpuMs, limit: resourceLimits.maxCpuMs })
  }
  
  if (resourceUsage.memoryBytes > resourceLimits.maxMemoryBytes) {
    violations.push({ type: 'memoryBytes', current: resourceUsage.memoryBytes, limit: resourceLimits.maxMemoryBytes })
  }
  
  if (resourceUsage.networkRequests > resourceLimits.maxNetworkRequests) {
    violations.push({ type: 'networkRequests', current: resourceUsage.networkRequests, limit: resourceLimits.maxNetworkRequests })
  }
  
  if (resourceUsage.fileOperations > resourceLimits.maxFileOperations) {
    violations.push({ type: 'fileOperations', current: resourceUsage.fileOperations, limit: resourceLimits.maxFileOperations })
  }
  
  // Check execution time
  const executionTime = Date.now() - session.startTime
  if (executionTime > resourceLimits.maxExecutionTimeMs) {
    violations.push({ type: 'executionTime', current: executionTime, limit: resourceLimits.maxExecutionTimeMs })
  }
  
  // Record violations
  for (const v of violations) {
    recordViolation(session.id, {
      type: 'resource_limit',
      severity: 'critical',
      description: `Resource limit exceeded: ${v.type}`,
      details: { current: v.current, limit: v.limit },
      action: 'terminated'
    })
    
    // Terminate session on resource limit violation
    if (config.isolationLevel === 'strict') {
      session.status = 'terminated'
      session.endTime = Date.now()
      session.terminationReason = `Resource limit exceeded: ${v.type}`
    }
  }
}

// ============================================================================
// Violation Management
// ============================================================================

/**
 * Records a violation in a sandbox session.
 * 
 * @param sessionId - The sandbox session ID
 * @param violation - The violation details
 * @returns The recorded violation
 * 
 * @example
 * ```typescript
 * const violation = recordViolation('session-uuid', {
 *   type: 'forbidden_operation',
 *   severity: 'violation',
 *   description: 'Attempted to access forbidden API',
 *   details: { operation: 'system.execute', blocked: true },
 *   action: 'blocked'
 * })
 * ```
 */
export function recordViolation(
  sessionId: string,
  violation: RecordViolationInput
): SandboxViolation {
  const session = sandboxSessions.get(sessionId)
  const id = generateUUID()
  const timestamp = Date.now()
  
  const recordedViolation: SandboxViolation = {
    id,
    sessionId,
    timestamp,
    type: violation.type,
    severity: violation.severity,
    description: violation.description,
    details: violation.details,
    action: violation.action
  }
  
  if (session) {
    session.violations.push(recordedViolation)
    
    // Handle escape attempts specially
    if (violation.type === 'escape_attempt') {
      handleEscapeAttempt(session, recordedViolation)
    }
    
    // Auto-terminate on critical violations in strict mode
    const config = sandboxConfigs.get(session.configId)
    if (config && config.isolationLevel === 'strict' && violation.severity === 'critical') {
      session.status = 'terminated'
      session.endTime = timestamp
      session.terminationReason = `Critical violation: ${violation.description}`
    }
  }
  
  return recordedViolation
}

/**
 * Retrieves all violations for a session.
 * 
 * @param sessionId - The sandbox session ID
 * @returns Array of violations
 */
export function getViolations(sessionId: string): SandboxViolation[] {
  const session = sandboxSessions.get(sessionId)
  return session ? [...session.violations] : []
}

/**
 * Retrieves violations by severity.
 * 
 * @param sessionId - The sandbox session ID
 * @param severity - The severity level to filter by
 * @returns Array of violations matching the severity
 */
export function getViolationsBySeverity(
  sessionId: string, 
  severity: ViolationSeverity
): SandboxViolation[] {
  const session = sandboxSessions.get(sessionId)
  if (!session) return []
  
  return session.violations.filter(v => v.severity === severity)
}

// ============================================================================
// Escape Detection and Prevention
// ============================================================================

/**
 * Scans code or input for escape patterns.
 * 
 * @param sessionId - The sandbox session ID
 * @param content - The content to scan
 * @returns Array of detected escape patterns
 */
export function scanForEscapePatterns(
  sessionId: string, 
  content: string
): Array<{ pattern: string; match: string; position: number }> {
  const detected: Array<{ pattern: string; match: string; position: number }> = []
  
  for (const pattern of ESCAPE_PATTERNS) {
    let match: RegExpExecArray | null
    const regex = new RegExp(pattern.source, pattern.flags)
    
    while ((match = regex.exec(content)) !== null) {
      detected.push({
        pattern: pattern.source,
        match: match[0],
        position: match.index
      })
    }
  }
  
  // Record violation if patterns detected
  if (detected.length > 0) {
    recordViolation(sessionId, {
      type: 'escape_attempt',
      severity: 'critical',
      description: `Detected ${detected.length} potential escape pattern(s)`,
      details: { patterns: detected },
      action: 'blocked'
    })
  }
  
  return detected
}

/**
 * Handles an escape attempt.
 */
function handleEscapeAttempt(session: SandboxSession, violation: SandboxViolation): void {
  // Track escape attempts
  const currentCount = escapeAttempts.get(session.agentId) ?? 0
  escapeAttempts.set(session.agentId, currentCount + 1)
  
  // Terminate session immediately
  session.status = 'escaped'
  session.endTime = Date.now()
  session.terminationReason = `Escape attempt detected: ${violation.description}`
  
  // Quarantine agent after 3 escape attempts
  if (currentCount + 1 >= 3) {
    quarantinedAgents.add(session.agentId)
    
    // Terminate all active sessions for this agent
    for (const s of sandboxSessions.values()) {
      if (s.agentId === session.agentId && s.status === 'running') {
        s.status = 'terminated'
        s.endTime = Date.now()
        s.terminationReason = 'Agent quarantined due to repeated escape attempts'
      }
    }
  }
}

/**
 * Checks if an agent is quarantined.
 * 
 * @param agentId - The agent ID
 * @returns True if the agent is quarantined
 */
export function isAgentQuarantined(agentId: string): boolean {
  return quarantinedAgents.has(agentId)
}

/**
 * Removes an agent from quarantine.
 * 
 * @param agentId - The agent ID
 * @returns True if the agent was removed from quarantine
 */
export function releaseAgentFromQuarantine(agentId: string): boolean {
  escapeAttempts.delete(agentId)
  return quarantinedAgents.delete(agentId)
}

// ============================================================================
// Circuit Breaker Implementation
// ============================================================================

/**
 * Creates a new circuit breaker.
 * 
 * @param config - Circuit breaker configuration
 * @returns The created circuit breaker
 * 
 * @example
 * ```typescript
 * const breaker = createCircuitBreaker({
 *   name: 'api-protection',
 *   agentId: 'agent-123',
 *   trigger: {
 *     type: 'error_rate',
 *     threshold: 0.5,  // 50% error rate
 *     timeWindowMs: 60000  // 1 minute window
 *   },
 *   resetTimeoutMs: 30000  // 30 seconds before retry
 * })
 * ```
 */
export function createCircuitBreaker(config: CreateCircuitBreakerInput): CircuitBreaker {
  const id = generateUUID()
  
  const breaker: CircuitBreaker = {
    id,
    name: config.name,
    agentId: config.agentId,
    trigger: config.trigger,
    state: 'closed',
    failureCount: 0,
    successCount: 0,
    lastStateChange: Date.now(),
    resetTimeoutMs: config.resetTimeoutMs
  }
  
  circuitBreakers.set(id, breaker)
  return breaker
}

/**
 * Checks if a circuit breaker allows execution.
 * 
 * @param breakerId - The circuit breaker ID
 * @returns Object indicating if execution is allowed and current state
 * 
 * @example
 * ```typescript
 * const { allowed, state } = checkCircuitBreaker('breaker-uuid')
 * if (!allowed) {
 *   console.log('Circuit breaker is open, rejecting request')
 * }
 * ```
 */
export function checkCircuitBreaker(breakerId: string): { 
  allowed: boolean
  state: CircuitBreakerState 
} {
  const breaker = circuitBreakers.get(breakerId)
  if (!breaker) {
    return { allowed: false, state: 'open' }
  }
  
  // Check if we should transition from open to half-open
  if (breaker.state === 'open') {
    const timeSinceLastFailure = Date.now() - (breaker.lastFailureTime ?? 0)
    if (timeSinceLastFailure >= breaker.resetTimeoutMs) {
      breaker.state = 'half_open'
      breaker.lastStateChange = Date.now()
    }
  }
  
  const allowed = breaker.state !== 'open'
  
  return { allowed, state: breaker.state }
}

/**
 * Records a success or failure for a circuit breaker.
 * 
 * @param breakerId - The circuit breaker ID
 * @param success - Whether the operation succeeded
 * 
 * @example
 * ```typescript
 * try {
 *   await performOperation()
 *   recordCircuitBreakerResult('breaker-uuid', true)
 * } catch (error) {
 *   recordCircuitBreakerResult('breaker-uuid', false)
 * }
 * ```
 */
export function recordCircuitBreakerResult(breakerId: string, success: boolean): void {
  const breaker = circuitBreakers.get(breakerId)
  if (!breaker) return
  
  if (success) {
    breaker.successCount++
    
    // In half-open state, success closes the circuit
    if (breaker.state === 'half_open') {
      breaker.state = 'closed'
      breaker.failureCount = 0
      breaker.lastStateChange = Date.now()
    }
  } else {
    breaker.failureCount++
    breaker.lastFailureTime = Date.now()
    
    // In half-open state, failure reopens the circuit
    if (breaker.state === 'half_open') {
      breaker.state = 'open'
      breaker.lastStateChange = Date.now()
    } else if (breaker.state === 'closed') {
      // Check if we should trip the circuit
      const totalRequests = breaker.successCount + breaker.failureCount
      const errorRate = totalRequests > 0 ? breaker.failureCount / totalRequests : 0
      
      let shouldTrip = false
      
      switch (breaker.trigger.type) {
        case 'error_rate':
          shouldTrip = errorRate >= breaker.trigger.threshold
          break
        case 'latency':
        case 'resource_usage':
        case 'custom':
          shouldTrip = breaker.failureCount >= breaker.trigger.threshold
          break
      }
      
      if (shouldTrip) {
        breaker.state = 'open'
        breaker.lastStateChange = Date.now()
      }
    }
  }
}

/**
 * Manually resets a circuit breaker.
 * 
 * @param breakerId - The circuit breaker ID
 * @returns True if reset successfully
 */
export function resetCircuitBreaker(breakerId: string): boolean {
  const breaker = circuitBreakers.get(breakerId)
  if (!breaker) return false
  
  breaker.state = 'closed'
  breaker.failureCount = 0
  breaker.successCount = 0
  breaker.lastStateChange = Date.now()
  breaker.lastFailureTime = undefined
  
  return true
}

/**
 * Retrieves a circuit breaker by ID.
 * 
 * @param breakerId - The circuit breaker ID
 * @returns The circuit breaker or undefined
 */
export function getCircuitBreaker(breakerId: string): CircuitBreaker | undefined {
  return circuitBreakers.get(breakerId)
}

/**
 * Retrieves all circuit breakers for an agent.
 * 
 * @param agentId - The agent ID (or undefined for global breakers)
 * @returns Array of circuit breakers
 */
export function getCircuitBreakersByAgent(agentId?: string): CircuitBreaker[] {
  return Array.from(circuitBreakers.values()).filter(
    b => b.agentId === agentId
  )
}

// ============================================================================
// Termination Triggers
// ============================================================================

/**
 * Creates a new termination trigger.
 * 
 * @param config - Termination trigger configuration
 * @returns The created termination trigger
 * 
 * @example
 * ```typescript
 * const trigger = createTerminationTrigger({
 *   name: 'high-cpu-terminator',
 *   conditions: [
 *     { metric: 'cpuUsage', operator: 'gte', value: 90 },
 *     { metric: 'duration', operator: 'gte', value: 60 }
 *   ],
 *   logic: 'all',
 *   action: 'terminate',
 *   enabled: true,
 *   cooldownMs: 60000
 * })
 * ```
 */
export function createTerminationTrigger(config: CreateTerminationTriggerInput): TerminationTrigger {
  const id = generateUUID()
  
  const trigger: TerminationTrigger = {
    id,
    name: config.name,
    conditions: config.conditions,
    logic: config.logic,
    action: config.action,
    enabled: config.enabled,
    cooldownMs: config.cooldownMs
  }
  
  terminationTriggers.set(id, trigger)
  return trigger
}

/**
 * Evaluates all termination triggers against current system state.
 * 
 * @returns Array of triggered termination triggers with associated agent IDs
 * 
 * @example
 * ```typescript
 * const triggered = evaluateTerminationTriggers()
 * for (const { trigger, agentId } of triggered) {
 *   console.log(`Trigger ${trigger.name} fired for agent ${agentId}`)
 *   // Handle trigger action
 * }
 * ```
 */
export function evaluateTerminationTriggers(): Array<{ 
  trigger: TerminationTrigger
  agentId?: string 
}> {
  const results: Array<{ trigger: TerminationTrigger; agentId?: string }> = []
  const now = Date.now()
  
  for (const trigger of terminationTriggers.values()) {
    if (!trigger.enabled) continue
    
    // Check cooldown
    if (trigger.lastTriggered && now - trigger.lastTriggered < trigger.cooldownMs) {
      continue
    }
    
    // Evaluate conditions
    const conditionResults = trigger.conditions.map(condition => 
      evaluateCondition(condition)
    )
    
    const shouldTrigger = trigger.logic === 'all'
      ? conditionResults.every(r => r)
      : conditionResults.some(r => r)
    
    if (shouldTrigger) {
      // Find associated agent(s) if applicable
      const agentId = findTriggerAgent(trigger)
      results.push({ trigger, agentId })
      
      // Update last triggered time
      trigger.lastTriggered = now
    }
  }
  
  return results
}

/**
 * Evaluates a single condition against current metrics.
 */
function evaluateCondition(condition: TerminationTrigger['conditions'][0]): boolean {
  const currentValue = getMetricValue(condition.metric)
  
  switch (condition.operator) {
    case 'gt': return currentValue > condition.value
    case 'lt': return currentValue < condition.value
    case 'eq': return currentValue === condition.value
    case 'gte': return currentValue >= condition.value
    case 'lte': return currentValue <= condition.value
    default: return false
  }
}

/**
 * Gets the current value for a metric.
 */
function getMetricValue(metric: string): number {
  // Aggregate metrics across all sessions
  let totalValue = 0
  
  for (const session of sandboxSessions.values()) {
    if (session.status !== 'running') continue
    
    switch (metric) {
      case 'cpuUsage':
      case 'cpuMs':
        totalValue += session.resourceUsage.cpuMs
        break
      case 'memoryUsage':
      case 'memoryBytes':
        totalValue += session.resourceUsage.memoryBytes
        break
      case 'networkRequests':
        totalValue += session.resourceUsage.networkRequests
        break
      case 'fileOperations':
        totalValue += session.resourceUsage.fileOperations
        break
      case 'violationCount':
        totalValue += session.violations.length
        break
      case 'activeSessions':
        totalValue += 1
        break
    }
  }
  
  return totalValue
}

/**
 * Finds the agent associated with a trigger (if applicable).
 */
function findTriggerAgent(trigger: TerminationTrigger): string | undefined {
  // Check conditions for agent-specific metrics
  for (const condition of trigger.conditions) {
    if (condition.metric.includes('agent:')) {
      return condition.metric.split(':')[1]
    }
  }
  return undefined
}

/**
 * Retrieves a termination trigger by ID.
 * 
 * @param triggerId - The termination trigger ID
 * @returns The termination trigger or undefined
 */
export function getTerminationTrigger(triggerId: string): TerminationTrigger | undefined {
  return terminationTriggers.get(triggerId)
}

/**
 * Updates a termination trigger.
 * 
 * @param triggerId - The termination trigger ID
 * @param updates - Partial updates to apply
 * @returns The updated trigger or undefined
 */
export function updateTerminationTrigger(
  triggerId: string,
  updates: Partial<CreateTerminationTriggerInput>
): TerminationTrigger | undefined {
  const trigger = terminationTriggers.get(triggerId)
  if (!trigger) return undefined
  
  const updated: TerminationTrigger = {
    ...trigger,
    ...updates,
    conditions: updates.conditions ?? trigger.conditions
  }
  
  terminationTriggers.set(triggerId, updated)
  return updated
}

/**
 * Deletes a termination trigger.
 * 
 * @param triggerId - The termination trigger ID
 * @returns True if deleted successfully
 */
export function deleteTerminationTrigger(triggerId: string): boolean {
  return terminationTriggers.delete(triggerId)
}

// ============================================================================
// Agent Termination
// ============================================================================

/**
 * Terminates an agent and all its active sessions.
 * 
 * @param agentId - The agent ID to terminate
 * @param reason - The reason for termination
 * 
 * @example
 * ```typescript
 * terminateAgent('agent-123', 'Security policy violation')
 * ```
 */
export function terminateAgent(agentId: string, reason: string): void {
  // Terminate all active sessions
  for (const session of sandboxSessions.values()) {
    if (session.agentId === agentId && session.status === 'running') {
      session.status = 'terminated'
      session.endTime = Date.now()
      session.terminationReason = reason
    }
  }
  
  // Open all circuit breakers for this agent
  for (const breaker of circuitBreakers.values()) {
    if (breaker.agentId === agentId) {
      breaker.state = 'open'
      breaker.lastStateChange = Date.now()
    }
  }
}

/**
 * Quarantines an agent, preventing new sessions.
 * 
 * @param agentId - The agent ID to quarantine
 * @param reason - The reason for quarantine
 */
export function quarantineAgent(agentId: string, reason: string): void {
  quarantinedAgents.add(agentId)
  terminateAgent(agentId, `Quarantined: ${reason}`)
}

// ============================================================================
// Operation Validation
// ============================================================================

/**
 * Validates if an operation is allowed for a sandbox session.
 * 
 * @param sessionId - The sandbox session ID
 * @param operation - The operation to validate
 * @returns Object indicating if operation is allowed and why
 * 
 * @example
 * ```typescript
 * const validation = validateOperation('session-uuid', 'file.write')
 * if (!validation.allowed) {
 *   console.log(`Operation blocked: ${validation.reason}`)
 * }
 * ```
 */
export function validateOperation(
  sessionId: string,
  operation: string
): { allowed: boolean; reason?: string } {
  const session = sandboxSessions.get(sessionId)
  if (!session) {
    return { allowed: false, reason: 'Session not found' }
  }
  
  if (session.status !== 'running') {
    return { allowed: false, reason: `Session is ${session.status}` }
  }
  
  const config = sandboxConfigs.get(session.configId)
  if (!config) {
    return { allowed: false, reason: 'Configuration not found' }
  }
  
  // Check denied operations first
  for (const denied of config.deniedOperations) {
    if (operation.startsWith(denied) || operation === denied) {
      recordViolation(sessionId, {
        type: 'forbidden_operation',
        severity: 'critical',
        description: `Attempted denied operation: ${operation}`,
        details: { operation, deniedPattern: denied },
        action: 'blocked'
      })
      return { allowed: false, reason: `Operation '${operation}' is denied` }
    }
  }
  
  // Check allowed operations (if any specified)
  if (config.allowedOperations.length > 0) {
    let isAllowed = false
    for (const allowed of config.allowedOperations) {
      if (operation.startsWith(allowed) || operation === allowed) {
        isAllowed = true
        break
      }
    }
    
    if (!isAllowed) {
      recordViolation(sessionId, {
        type: 'forbidden_operation',
        severity: 'violation',
        description: `Attempted non-allowed operation: ${operation}`,
        details: { operation },
        action: 'blocked'
      })
      return { allowed: false, reason: `Operation '${operation}' is not in allowed list` }
    }
  }
  
  return { allowed: true }
}

/**
 * Validates if a network request is allowed.
 * 
 * @param sessionId - The sandbox session ID
 * @param url - The URL to validate
 * @returns Object indicating if request is allowed and why
 */
export function validateNetworkRequest(
  sessionId: string,
  url: string
): { allowed: boolean; reason?: string } {
  const session = sandboxSessions.get(sessionId)
  if (!session) {
    return { allowed: false, reason: 'Session not found' }
  }
  
  const config = sandboxConfigs.get(session.configId)
  if (!config) {
    return { allowed: false, reason: 'Configuration not found' }
  }
  
  // Check network request limit
  if (session.resourceUsage.networkRequests >= config.resourceLimits.maxNetworkRequests) {
    recordViolation(sessionId, {
      type: 'network_violation',
      severity: 'critical',
      description: 'Network request limit exceeded',
      details: { 
        current: session.resourceUsage.networkRequests,
        limit: config.resourceLimits.maxNetworkRequests
      },
      action: 'blocked'
    })
    return { allowed: false, reason: 'Network request limit exceeded' }
  }
  
  // Check allow list
  if (config.networkAllowList.length > 0) {
    const urlObj = new URL(url)
    const host = urlObj.hostname
    
    let isAllowed = false
    for (const allowed of config.networkAllowList) {
      if (host === allowed || host.endsWith('.' + allowed)) {
        isAllowed = true
        break
      }
    }
    
    if (!isAllowed) {
      recordViolation(sessionId, {
        type: 'network_violation',
        severity: 'violation',
        description: `Attempted request to non-allowed host: ${host}`,
        details: { url, host },
        action: 'blocked'
      })
      return { allowed: false, reason: `Host '${host}' is not in allow list` }
    }
  }
  
  // Increment request count
  incrementResourceUsage(sessionId, 'networkRequests')
  
  return { allowed: true }
}

/**
 * Validates if a file operation is allowed.
 * 
 * @param sessionId - The sandbox session ID
 * @param filePath - The file path to validate
 * @param operation - The file operation type
 * @returns Object indicating if operation is allowed and why
 */
export function validateFileOperation(
  sessionId: string,
  filePath: string,
  operation: 'read' | 'write' | 'delete' | 'execute'
): { allowed: boolean; reason?: string } {
  const session = sandboxSessions.get(sessionId)
  if (!session) {
    return { allowed: false, reason: 'Session not found' }
  }
  
  const config = sandboxConfigs.get(session.configId)
  if (!config) {
    return { allowed: false, reason: 'Configuration not found' }
  }
  
  // Check file operation limit
  if (session.resourceUsage.fileOperations >= config.resourceLimits.maxFileOperations) {
    recordViolation(sessionId, {
      type: 'file_violation',
      severity: 'critical',
      description: 'File operation limit exceeded',
      details: {
        current: session.resourceUsage.fileOperations,
        limit: config.resourceLimits.maxFileOperations
      },
      action: 'blocked'
    })
    return { allowed: false, reason: 'File operation limit exceeded' }
  }
  
  // Normalize path
  const normalizedPath = filePath.replace(/\\/g, '/')
  
  // Check for path traversal attempts
  if (normalizedPath.includes('..') || normalizedPath.includes('~')) {
    recordViolation(sessionId, {
      type: 'file_violation',
      severity: 'critical',
      description: 'Path traversal attempt detected',
      details: { filePath, normalizedPath },
      action: 'blocked'
    })
    return { allowed: false, reason: 'Path traversal not allowed' }
  }
  
  // Check allow list
  if (config.fileAllowList.length > 0) {
    let isAllowed = false
    for (const allowed of config.fileAllowList) {
      if (normalizedPath.startsWith(allowed)) {
        isAllowed = true
        break
      }
    }
    
    if (!isAllowed) {
      recordViolation(sessionId, {
        type: 'file_violation',
        severity: 'violation',
        description: `Attempted access to non-allowed path: ${normalizedPath}`,
        details: { filePath, normalizedPath },
        action: 'blocked'
      })
      return { allowed: false, reason: `Path '${normalizedPath}' is not in allow list` }
    }
  }
  
  // Strict mode: no execute operations
  if (config.isolationLevel === 'strict' && operation === 'execute') {
    recordViolation(sessionId, {
      type: 'file_violation',
      severity: 'critical',
      description: 'File execution not allowed in strict mode',
      details: { filePath, operation },
      action: 'blocked'
    })
    return { allowed: false, reason: 'File execution not allowed in strict isolation mode' }
  }
  
  // Increment operation count
  incrementResourceUsage(sessionId, 'fileOperations')
  
  return { allowed: true }
}

// ============================================================================
// Statistics and Monitoring
// ============================================================================

/**
 * Gets comprehensive statistics about the sandbox system.
 * 
 * @returns Object containing various sandbox statistics
 */
export function getSandboxStats(): {
  configs: { total: number; byIsolationLevel: Record<IsolationLevel, number> }
  sessions: { 
    total: number
    active: number
    terminated: number
    escaped: number
  }
  violations: { 
    total: number
    bySeverity: Record<ViolationSeverity, number>
    byType: Record<ViolationType, number>
  }
  circuitBreakers: {
    total: number
    closed: number
    open: number
    halfOpen: number
  }
  quarantine: { agents: number }
} {
  const configs = Array.from(sandboxConfigs.values())
  const sessions = Array.from(sandboxSessions.values())
  const breakers = Array.from(circuitBreakers.values())
  
  // Count violations across all sessions
  const allViolations = sessions.flatMap(s => s.violations)
  
  return {
    configs: {
      total: configs.length,
      byIsolationLevel: {
        strict: configs.filter(c => c.isolationLevel === 'strict').length,
        moderate: configs.filter(c => c.isolationLevel === 'moderate').length,
        permissive: configs.filter(c => c.isolationLevel === 'permissive').length
      }
    },
    sessions: {
      total: sessions.length,
      active: sessions.filter(s => s.status === 'running' || s.status === 'initializing').length,
      terminated: sessions.filter(s => s.status === 'terminated').length,
      escaped: sessions.filter(s => s.status === 'escaped').length
    },
    violations: {
      total: allViolations.length,
      bySeverity: {
        warning: allViolations.filter(v => v.severity === 'warning').length,
        violation: allViolations.filter(v => v.severity === 'violation').length,
        critical: allViolations.filter(v => v.severity === 'critical').length
      },
      byType: {
        resource_limit: allViolations.filter(v => v.type === 'resource_limit').length,
        forbidden_operation: allViolations.filter(v => v.type === 'forbidden_operation').length,
        network_violation: allViolations.filter(v => v.type === 'network_violation').length,
        file_violation: allViolations.filter(v => v.type === 'file_violation').length,
        escape_attempt: allViolations.filter(v => v.type === 'escape_attempt').length
      }
    },
    circuitBreakers: {
      total: breakers.length,
      closed: breakers.filter(b => b.state === 'closed').length,
      open: breakers.filter(b => b.state === 'open').length,
      halfOpen: breakers.filter(b => b.state === 'half_open').length
    },
    quarantine: {
      agents: quarantinedAgents.size
    }
  }
}

/**
 * Clears all sandbox data (useful for testing/reset).
 */
export function clearAllSandboxData(): void {
  sandboxConfigs.clear()
  sandboxSessions.clear()
  circuitBreakers.clear()
  terminationTriggers.clear()
  quarantinedAgents.clear()
  escapeAttempts.clear()
}

// ============================================================================
// Exports
// ============================================================================

const agentSandbox = {
  // Sandbox Configuration
  createSandboxConfig,
  getSandboxConfig,
  getSandboxConfigsByAgent,
  updateSandboxConfig,
  deleteSandboxConfig,
  
  // Sandbox Sessions
  startSandboxSession,
  endSandboxSession,
  getSandboxSession,
  getActiveSessionsByAgent,
  pauseSandboxSession,
  resumeSandboxSession,
  
  // Resource Management
  checkResourceUsage,
  updateResourceUsage,
  incrementResourceUsage,
  
  // Violations
  recordViolation,
  getViolations,
  getViolationsBySeverity,
  
  // Escape Detection
  scanForEscapePatterns,
  isAgentQuarantined,
  releaseAgentFromQuarantine,
  
  // Circuit Breakers
  createCircuitBreaker,
  checkCircuitBreaker,
  recordCircuitBreakerResult,
  resetCircuitBreaker,
  getCircuitBreaker,
  getCircuitBreakersByAgent,
  
  // Termination Triggers
  createTerminationTrigger,
  evaluateTerminationTriggers,
  getTerminationTrigger,
  updateTerminationTrigger,
  deleteTerminationTrigger,
  
  // Agent Management
  terminateAgent,
  quarantineAgent,
  
  // Validation
  validateOperation,
  validateNetworkRequest,
  validateFileOperation,
  
  // Statistics
  getSandboxStats,
  clearAllSandboxData
}

export default agentSandbox
