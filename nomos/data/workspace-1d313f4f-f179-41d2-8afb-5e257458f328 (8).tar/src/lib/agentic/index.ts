/**
 * Kasbah Agentic AI Safety Platform
 * 
 * Comprehensive security suite for autonomous AI agents
 */

// Import functions needed locally
import { getMonitoringStats } from './agent-behavior-monitor'
import { getPolicyStats } from './policy-guardrails'
import { getSystemStats } from './multi-agent-coordination'
import { getAgentIdentityStats } from './agent-identity'
import { getAuditStatistics } from './decision-auditing'
import { getSandboxStats } from './agent-sandbox'

// Agent Behavior Monitoring
export {
  type AgentDecision,
  type AgentProfile,
  type AgentBaseline,
  type BehaviorAnomaly,
  type AlertConfig,
  registerAgent,
  recordDecision,
  getAgentProfile,
  getAllAgents,
  analyzeBehavior,
  getDecisionChain,
  detectAnomalies,
  updateTrustScore,
  setAlertCallback,
  getMonitoringStats as getBehaviorMonitorStats
} from './agent-behavior-monitor'

// Policy Guardrails
export {
  type Policy,
  type PolicyCondition,
  type PolicyEvaluationRequest,
  type PolicyEvaluationResult,
  type PolicyAuditEntry,
  type PolicyVersion,
  createPolicy,
  updatePolicy,
  deletePolicy,
  getPolicy,
  listPolicies,
  evaluatePolicy,
  getPolicyAuditTrail,
  verifyAuditIntegrity,
  explainDecision as explainPolicyDecision,
  batchEvaluate,
  getPolicyStats
} from './policy-guardrails'

// Multi-Agent Coordination
export {
  type AgentNode,
  type AgentGroup,
  type ConsensusProposal,
  type AgentMessage,
  type RogueAgentDetection,
  type AgentStatistics,
  registerAgentNode,
  getAgent as getCoordinationAgent,
  updateAgentCapabilities,
  removeAgent,
  heartbeat,
  checkHeartbeatTimeouts,
  createGroup,
  addAgentToGroup,
  removeAgentFromGroup,
  setGroupLeader,
  updateConsensusThreshold,
  proposeConsensus,
  vote,
  getProposal,
  getGroupProposals,
  sendMessage,
  verifyMessage,
  detectRogueAgents,
  quarantineAgent,
  suspendAgent,
  adjustTrustScore,
  getCoordinationStats
} from './multi-agent-coordination'

// Agent Identity & Attestation
export {
  type AgentIdentity,
  type AgentCertificate,
  type AttestationReport,
  type SupplyChainEntry,
  type CertificateRevocation,
  type KeyRotationRecord,
  createAgentIdentity,
  getAgentIdentity,
  listAgentIdentities,
  rotateAgentKeys,
  issueCertificate,
  verifyCertificate,
  revokeCertificate,
  getRevocationList,
  generateAttestation,
  verifyAttestation,
  getAgentAttestations,
  recordSupplyChainEntry,
  verifySupplyChainEntry,
  verifySupplyChain,
  getAgentIdentityStats,
  verifyAgentComplete
} from './agent-identity'

// Decision Auditing
export {
  type DecisionRecord,
  type DecisionReasoning,
  type DecisionImpact,
  type DecisionRollback,
  type DecisionQuery,
  type ForensicAnalysis,
  recordAuditDecision,
  updateDecisionStatus,
  getDecision,
  getDecisionProvenance,
  explainDecision,
  rollbackDecision,
  assessImpact,
  getDecisionTimeline,
  replayDecision,
  performForensicAnalysis,
  queryDecisions,
  getAuditStatistics,
  exportDecisions,
  importDecisions
} from './decision-auditing'

// Agent Sandbox & Containment
export {
  type SandboxConfig,
  type SandboxSession,
  type SandboxViolation,
  type CircuitBreaker,
  type TerminationTrigger,
  type EscapePattern,
  createSandboxConfig,
  getSandboxConfig,
  listSandboxConfigs,
  startSandboxSession,
  getSandboxSession,
  endSandboxSession,
  checkResourceUsage,
  incrementResourceUsage,
  recordViolation,
  scanForEscapePatterns,
  createCircuitBreaker,
  getCircuitBreaker,
  checkCircuitBreaker,
  recordCircuitBreakerResult,
  createTerminationTrigger,
  getTerminationTrigger,
  evaluateTerminationTriggers,
  terminateAgent,
  quarantineAgent as quarantineSandboxAgent,
  validateOperation,
  validateNetworkRequest,
  validateFileOperation,
  getSandboxStats
} from './agent-sandbox'

/**
 * Get comprehensive system status for all agentic modules
 */
export function getAgenticSystemStatus(): {
  behaviorMonitoring: { totalAgents: number; totalDecisions: number; activeAnomalies: number }
  policyGuardrails: { totalPolicies: number; enabledPolicies: number; auditEntries: number }
  multiAgentCoordination: { totalAgents: number; activeAgents: number; totalGroups: number; activeProposals: number; quarantinedAgents: number }
  identityAttestation: { totalIdentities: number; activeCertificates: number; revokedCertificates: number; totalAttestations: number }
  decisionAuditing: { totalDecisions: number; pendingDecisions: number; rolledBackDecisions: number }
  sandboxContainment: { totalConfigs: number; activeSessions: number; totalViolations: number; openCircuitBreakers: number }
} {
  const behaviorStats = getMonitoringStats()
  const policyStats = getPolicyStats()
  const coordinationStats = getSystemStats()
  const identityStats = getAgentIdentityStats()
  const auditStats = getAuditStatistics()
  const sandboxStats = getSandboxStats()

  return {
    behaviorMonitoring: {
      totalAgents: behaviorStats.totalAgents,
      totalDecisions: behaviorStats.totalDecisions,
      activeAnomalies: behaviorStats.activeAnomalies
    },
    policyGuardrails: {
      totalPolicies: policyStats.totalPolicies,
      enabledPolicies: policyStats.enabledPolicies,
      auditEntries: policyStats.auditEntries
    },
    multiAgentCoordination: {
      totalAgents: coordinationStats.totalAgents,
      activeAgents: coordinationStats.activeAgents,
      totalGroups: coordinationStats.totalGroups,
      activeProposals: coordinationStats.activeProposals,
      quarantinedAgents: coordinationStats.quarantinedAgents
    },
    identityAttestation: {
      totalIdentities: identityStats.totalIdentities,
      activeCertificates: identityStats.activeCertificates,
      revokedCertificates: identityStats.revokedCertificates,
      totalAttestations: identityStats.totalAttestations
    },
    decisionAuditing: {
      totalDecisions: auditStats.totalDecisions,
      pendingDecisions: auditStats.pendingDecisions,
      rolledBackDecisions: auditStats.rolledBackDecisions
    },
    sandboxContainment: {
      totalConfigs: sandboxStats.totalConfigs,
      activeSessions: sandboxStats.activeSessions,
      totalViolations: sandboxStats.totalViolations,
      openCircuitBreakers: sandboxStats.openCircuitBreakers
    }
  }
}

/**
 * Initialize all agentic modules
 */
export function initializeAgenticModules(): void {
  console.log('[Agentic] All modules initialized')
}
