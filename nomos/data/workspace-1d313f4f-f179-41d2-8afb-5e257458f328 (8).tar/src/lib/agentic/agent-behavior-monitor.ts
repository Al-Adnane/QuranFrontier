/**
 * Agent Behavior Monitoring Module
 * Real-time monitoring of AI agent decision chains with anomaly detection
 * Part of the Kasbah AI Safety Platform
 */

import { generateUUID, sha256Sync } from '@/lib/crypto-utils'

// ============================================================================
// Core Types
// ============================================================================

/**
 * Represents a single decision made by an AI agent
 */
export interface AgentDecision {
  /** Unique identifier for this decision */
  id: string
  /** ID of the agent that made this decision */
  agentId: string
  /** Unix timestamp when the decision was made */
  timestamp: number
  /** The action type (e.g., 'query', 'execute', 'delegate', 'analyze') */
  action: string
  /** Input parameters for the decision */
  input: Record<string, unknown>
  /** Output/result of the decision */
  output: Record<string, unknown>
  /** Optional reasoning chain explaining the decision */
  reasoning?: string
  /** Confidence level (0-1) */
  confidence: number
  /** Assessed risk level of this decision */
  riskLevel: 'low' | 'medium' | 'high' | 'critical'
  /** Parent decision ID for decision chain tracking */
  parentDecisionId?: string
  /** Hash of the decision for integrity verification */
  hash: string
  /** Resource usage metrics */
  resources?: {
    cpuMs?: number
    memoryBytes?: number
    apiCalls?: number
    tokensUsed?: number
  }
}

/**
 * Profile of an AI agent being monitored
 */
export interface AgentProfile {
  /** Unique identifier for the agent */
  id: string
  /** Human-readable name for the agent */
  name: string
  /** Type classification (e.g., 'assistant', 'autonomous', 'tool-user') */
  type: string
  /** Creation timestamp */
  createdAt: number
  /** Dynamic trust score (0-100) */
  trustScore: number
  /** Total number of decisions recorded */
  totalDecisions: number
  /** Current anomaly score (0-100) */
  anomalyScore: number
  /** Last activity timestamp */
  lastActive: number
  /** List of agent capabilities */
  capabilities: string[]
  /** Restrictions placed on this agent */
  restrictions: string[]
  /** Baseline behavior profile for comparison */
  baseline?: AgentBaseline
}

/**
 * Baseline behavior profile for anomaly detection
 */
export interface AgentBaseline {
  /** Average decisions per hour */
  avgDecisionFrequency: number
  /** Distribution of action types */
  actionDistribution: Record<string, number>
  /** Average confidence level */
  avgConfidence: number
  /** Typical resource usage */
  avgResourceUsage: {
    cpuMs: number
    memoryBytes: number
    apiCalls: number
    tokensUsed: number
  }
  /** Common input patterns (hashed for privacy) */
  inputPatterns: string[]
  /** Time-based activity pattern (hour of day -> count) */
  hourlyActivity: number[]
  /** Created/updated timestamp */
  lastUpdated: number
}

/**
 * Detected behavioral anomaly
 */
export interface BehaviorAnomaly {
  /** Unique identifier for this anomaly */
  id: string
  /** ID of the agent exhibiting the anomaly */
  agentId: string
  /** Detection timestamp */
  timestamp: number
  /** Type of anomaly detected */
  type: 'action_deviation' | 'frequency_anomaly' | 'resource_abuse' | 'policy_violation' | 'reasoning_inconsistency'
  /** Severity level */
  severity: 'low' | 'medium' | 'high' | 'critical'
  /** Human-readable description */
  description: string
  /** Supporting evidence for the anomaly */
  evidence: Record<string, unknown>
  /** Whether the anomaly has been resolved */
  resolved: boolean
  /** Related decision IDs */
  relatedDecisions: string[]
  /** Recommended actions */
  recommendations: string[]
}

/**
 * Alert configuration for behavior monitoring
 */
export interface AlertConfig {
  /** Threshold for anomaly score alerts */
  anomalyScoreThreshold: number
  /** Threshold for trust score alerts */
  trustScoreThreshold: number
  /** Maximum decisions per minute before alert */
  maxDecisionsPerMinute: number
  /** Critical action types that trigger immediate alerts */
  criticalActions: string[]
  /** Enable real-time alerts */
  enableRealTimeAlerts: boolean
}

/**
 * Behavior analysis result
 */
export interface BehaviorAnalysisResult {
  /** Current anomaly score (0-100) */
  anomalyScore: number
  /** List of detected anomalies */
  anomalies: BehaviorAnomaly[]
  /** Recommended actions */
  recommendations: string[]
  /** Trust score adjustment suggestion */
  trustScoreDelta: number
  /** Behavior patterns detected */
  patterns: {
    actionTrends: Record<string, number>
    riskTrend: 'increasing' | 'stable' | 'decreasing'
    confidenceTrend: 'increasing' | 'stable' | 'decreasing'
  }
}

/**
 * Callback for alert notifications
 */
export type AlertCallback = (anomaly: BehaviorAnomaly) => void

// ============================================================================
// Configuration & Constants
// ============================================================================

const DEFAULT_ALERT_CONFIG: AlertConfig = {
  anomalyScoreThreshold: 50,
  trustScoreThreshold: 30,
  maxDecisionsPerMinute: 100,
  criticalActions: ['execute', 'delete', 'modify', 'delegate', 'escalate'],
  enableRealTimeAlerts: true
}

const ANOMALY_WEIGHTS = {
  action_deviation: 25,
  frequency_anomaly: 15,
  resource_abuse: 20,
  policy_violation: 35,
  reasoning_inconsistency: 30
}

const SEVERITY_MULTIPLIERS = {
  low: 1,
  medium: 1.5,
  high: 2,
  critical: 3
}

// ============================================================================
// Storage (In-Memory with Persistence Interface)
// ============================================================================

class BehaviorMonitorStorage {
  private agents: Map<string, AgentProfile> = new Map()
  private decisions: Map<string, AgentDecision> = new Map()
  private decisionsByAgent: Map<string, Set<string>> = new Map()
  private anomalies: Map<string, BehaviorAnomaly> = new Map()
  private anomaliesByAgent: Map<string, Set<string>> = new Map()
  private alertCallbacks: AlertCallback[] = []
  private config: AlertConfig = { ...DEFAULT_ALERT_CONFIG }

  // Decision frequency tracking (per agent, per minute buckets)
  private decisionFrequency: Map<string, Map<number, number>> = new Map()

  /**
   * Store an agent profile
   */
  setAgent(profile: AgentProfile): void {
    this.agents.set(profile.id, { ...profile })
  }

  /**
   * Get an agent profile
   */
  getAgent(id: string): AgentProfile | undefined {
    return this.agents.get(id)
  }

  /**
   * Get all agent profiles
   */
  getAllAgents(): AgentProfile[] {
    return Array.from(this.agents.values())
  }

  /**
   * Store a decision
   */
  setDecision(decision: AgentDecision): void {
    this.decisions.set(decision.id, { ...decision })
    
    // Index by agent
    if (!this.decisionsByAgent.has(decision.agentId)) {
      this.decisionsByAgent.set(decision.agentId, new Set())
    }
    this.decisionsByAgent.get(decision.agentId)!.add(decision.id)

    // Track frequency
    this.trackDecisionFrequency(decision.agentId, decision.timestamp)
  }

  /**
   * Get a decision by ID
   */
  getDecision(id: string): AgentDecision | undefined {
    return this.decisions.get(id)
  }

  /**
   * Get decisions for an agent
   */
  getDecisionsByAgent(agentId: string, limit?: number): AgentDecision[] {
    const ids = this.decisionsByAgent.get(agentId)
    if (!ids) return []
    
    const decisions = Array.from(ids)
      .map(id => this.decisions.get(id)!)
      .filter(d => d !== undefined)
      .sort((a, b) => b.timestamp - a.timestamp)
    
    return limit ? decisions.slice(0, limit) : decisions
  }

  /**
   * Store an anomaly
   */
  setAnomaly(anomaly: BehaviorAnomaly): void {
    this.anomalies.set(anomaly.id, { ...anomaly })
    
    // Index by agent
    if (!this.anomaliesByAgent.has(anomaly.agentId)) {
      this.anomaliesByAgent.set(anomaly.agentId, new Set())
    }
    this.anomaliesByAgent.get(anomaly.agentId)!.add(anomaly.id)

    // Trigger alerts
    if (this.config.enableRealTimeAlerts) {
      this.alertCallbacks.forEach(cb => cb(anomaly))
    }
  }

  /**
   * Get anomalies for an agent
   */
  getAnomaliesByAgent(agentId: string, unresolvedOnly?: boolean): BehaviorAnomaly[] {
    const ids = this.anomaliesByAgent.get(agentId)
    if (!ids) return []
    
    return Array.from(ids)
      .map(id => this.anomalies.get(id)!)
      .filter(a => a !== undefined && (!unresolvedOnly || !a.resolved))
      .sort((a, b) => b.timestamp - a.timestamp)
  }

  /**
   * Get all anomalies
   */
  getAllAnomalies(unresolvedOnly?: boolean): BehaviorAnomaly[] {
    return Array.from(this.anomalies.values())
      .filter(a => !unresolvedOnly || !a.resolved)
      .sort((a, b) => b.timestamp - a.timestamp)
  }

  /**
   * Mark anomaly as resolved
   */
  resolveAnomaly(id: string): boolean {
    const anomaly = this.anomalies.get(id)
    if (anomaly) {
      anomaly.resolved = true
      return true
    }
    return false
  }

  /**
   * Track decision frequency
   */
  private trackDecisionFrequency(agentId: string, timestamp: number): void {
    if (!this.decisionFrequency.has(agentId)) {
      this.decisionFrequency.set(agentId, new Map())
    }
    
    const minuteBucket = Math.floor(timestamp / 60000)
    const freq = this.decisionFrequency.get(agentId)!
    freq.set(minuteBucket, (freq.get(minuteBucket) || 0) + 1)

    // Cleanup old buckets (keep last 60 minutes)
    const cutoff = minuteBucket - 60
    for (const [bucket] of freq) {
      if (bucket < cutoff) {
        freq.delete(bucket)
      }
    }
  }

  /**
   * Get decision frequency for an agent
   */
  getDecisionFrequency(agentId: string): Map<number, number> {
    return this.decisionFrequency.get(agentId) || new Map()
  }

  /**
   * Register alert callback
   */
  onAlert(callback: AlertCallback): void {
    this.alertCallbacks.push(callback)
  }

  /**
   * Get configuration
   */
  getConfig(): AlertConfig {
    return { ...this.config }
  }

  /**
   * Update configuration
   */
  setConfig(config: Partial<AlertConfig>): void {
    this.config = { ...this.config, ...config }
  }

  /**
   * Get statistics
   */
  getStats(): {
    totalAgents: number
    totalDecisions: number
    totalAnomalies: number
    unresolvedAnomalies: number
  } {
    return {
      totalAgents: this.agents.size,
      totalDecisions: this.decisions.size,
      totalAnomalies: this.anomalies.size,
      unresolvedAnomalies: this.getAllAnomalies(true).length
    }
  }
}

// Singleton storage instance
const storage = new BehaviorMonitorStorage()

// ============================================================================
// Utility Functions
// ============================================================================

/**
 * Compute hash of a decision for integrity verification
 */
function computeDecisionHash(decision: Omit<AgentDecision, 'hash'>): string {
  const data = JSON.stringify({
    agentId: decision.agentId,
    timestamp: decision.timestamp,
    action: decision.action,
    input: decision.input,
    output: decision.output,
    reasoning: decision.reasoning,
    confidence: decision.confidence,
    riskLevel: decision.riskLevel,
    parentDecisionId: decision.parentDecisionId
  })
  return sha256Sync(data)
}

/**
 * Calculate risk level based on action and confidence
 */
function assessRiskLevel(
  action: string,
  confidence: number,
  input: Record<string, unknown>,
  config: AlertConfig
): 'low' | 'medium' | 'high' | 'critical' {
  // Critical actions are always at least medium risk
  if (config.criticalActions.includes(action)) {
    if (confidence < 0.5) return 'critical'
    if (confidence < 0.7) return 'high'
    return 'medium'
  }

  // Low confidence on any action is risky
  if (confidence < 0.3) return 'high'
  if (confidence < 0.5) return 'medium'

  // Check for dangerous input patterns
  const inputStr = JSON.stringify(input).toLowerCase()
  const dangerousPatterns = ['delete', 'drop', 'truncate', 'remove', 'destroy', 'wipe']
  for (const pattern of dangerousPatterns) {
    if (inputStr.includes(pattern)) {
      return 'high'
    }
  }

  return 'low'
}

/**
 * Generate recommendations based on anomaly type and severity
 */
function generateRecommendations(anomaly: BehaviorAnomaly): string[] {
  const recommendations: string[] = []

  switch (anomaly.type) {
    case 'action_deviation':
      recommendations.push('Review agent capabilities and restrictions')
      recommendations.push('Consider tightening allowed action types')
      recommendations.push('Investigate if agent is operating outside its scope')
      break
    case 'frequency_anomaly':
      recommendations.push('Check for runaway processes or loops')
      recommendations.push('Consider implementing rate limits')
      recommendations.push('Verify agent is not being abused')
      break
    case 'resource_abuse':
      recommendations.push('Implement resource quotas')
      recommendations.push('Review recent decisions for efficiency')
      recommendations.push('Check for memory leaks or infinite loops')
      break
    case 'policy_violation':
      recommendations.push('Immediately review policy constraints')
      recommendations.push('Consider temporarily restricting agent')
      recommendations.push('Audit all recent decisions for violations')
      break
    case 'reasoning_inconsistency':
      recommendations.push('Review reasoning chains for logical errors')
      recommendations.push('Check for conflicting goals or objectives')
      recommendations.push('Consider model retraining or adjustment')
      break
  }

  if (anomaly.severity === 'critical') {
    recommendations.unshift('Consider immediate agent suspension')
    recommendations.push('Escalate to security team for review')
  }

  return recommendations
}

/**
 * Build or update baseline behavior profile
 */
function buildBaseline(decisions: AgentDecision[]): AgentBaseline {
  if (decisions.length === 0) {
    return {
      avgDecisionFrequency: 0,
      actionDistribution: {},
      avgConfidence: 0,
      avgResourceUsage: { cpuMs: 0, memoryBytes: 0, apiCalls: 0, tokensUsed: 0 },
      inputPatterns: [],
      hourlyActivity: new Array(24).fill(0),
      lastUpdated: Date.now()
    }
  }

  // Calculate action distribution
  const actionDistribution: Record<string, number> = {}
  decisions.forEach(d => {
    actionDistribution[d.action] = (actionDistribution[d.action] || 0) + 1
  })

  // Normalize to percentages
  const total = decisions.length
  Object.keys(actionDistribution).forEach(action => {
    actionDistribution[action] = actionDistribution[action] / total
  })

  // Calculate average confidence
  const avgConfidence = decisions.reduce((sum, d) => sum + d.confidence, 0) / total

  // Calculate average resource usage
  const avgResourceUsage = {
    cpuMs: 0,
    memoryBytes: 0,
    apiCalls: 0,
    tokensUsed: 0
  }
  const resourceDecisions = decisions.filter(d => d.resources)
  if (resourceDecisions.length > 0) {
    avgResourceUsage.cpuMs = resourceDecisions.reduce((sum, d) => sum + (d.resources?.cpuMs || 0), 0) / resourceDecisions.length
    avgResourceUsage.memoryBytes = resourceDecisions.reduce((sum, d) => sum + (d.resources?.memoryBytes || 0), 0) / resourceDecisions.length
    avgResourceUsage.apiCalls = resourceDecisions.reduce((sum, d) => sum + (d.resources?.apiCalls || 0), 0) / resourceDecisions.length
    avgResourceUsage.tokensUsed = resourceDecisions.reduce((sum, d) => sum + (d.resources?.tokensUsed || 0), 0) / resourceDecisions.length
  }

  // Calculate hourly activity pattern
  const hourlyActivity = new Array(24).fill(0)
  decisions.forEach(d => {
    const hour = new Date(d.timestamp).getHours()
    hourlyActivity[hour]++
  })

  // Extract input patterns (hashed for privacy)
  const inputPatterns = decisions.slice(0, 100).map(d => 
    sha256Sync(JSON.stringify(Object.keys(d.input).sort()))
  )

  // Calculate average decision frequency (decisions per hour)
  const timestamps = decisions.map(d => d.timestamp).sort((a, b) => a - b)
  let avgDecisionFrequency = 0
  if (timestamps.length > 1) {
    const timeSpanHours = (timestamps[timestamps.length - 1] - timestamps[0]) / (1000 * 60 * 60)
    avgDecisionFrequency = timeSpanHours > 0 ? decisions.length / timeSpanHours : decisions.length
  }

  return {
    avgDecisionFrequency,
    actionDistribution,
    avgConfidence,
    avgResourceUsage,
    inputPatterns: [...new Set(inputPatterns)],
    hourlyActivity,
    lastUpdated: Date.now()
  }
}

// ============================================================================
// Core API Functions
// ============================================================================

/**
 * Register a new agent for behavior monitoring
 * 
 * @param profile - Agent profile information (excluding auto-generated fields)
 * @returns The created agent profile with generated ID and initial values
 * 
 * @example
 * ```typescript
 * const profile = registerAgent({
 *   name: 'TaskBot-1',
 *   type: 'autonomous',
 *   capabilities: ['query', 'execute', 'delegate'],
 *   restrictions: ['no_delete', 'no_external_api']
 * })
 * console.log(profile.id) // Generated UUID
 * console.log(profile.trustScore) // Initial 100
 * ```
 */
export function registerAgent(
  profile: Omit<AgentProfile, 'id' | 'createdAt' | 'trustScore' | 'totalDecisions' | 'anomalyScore' | 'lastActive'>
): AgentProfile {
  const now = Date.now()
  const agentProfile: AgentProfile = {
    id: generateUUID(),
    name: profile.name,
    type: profile.type,
    createdAt: now,
    trustScore: 100, // Start with full trust
    totalDecisions: 0,
    anomalyScore: 0,
    lastActive: now,
    capabilities: [...profile.capabilities],
    restrictions: [...profile.restrictions],
    baseline: undefined
  }

  storage.setAgent(agentProfile)
  
  return agentProfile
}

/**
 * Record a decision made by an agent
 * 
 * @param agentId - ID of the agent making the decision
 * @param decision - Decision details (excluding auto-generated fields)
 * @returns The recorded decision with generated ID and hash
 * 
 * @example
 * ```typescript
 * const decision = recordDecision('agent-uuid', {
 *   action: 'query',
 *   input: { question: 'What is the weather?' },
 *   output: { answer: 'Sunny, 72°F' },
 *   reasoning: 'User asked about weather, queried weather API',
 *   confidence: 0.95,
 *   riskLevel: 'low'
 * })
 * ```
 */
export function recordDecision(
  agentId: string,
  decision: Omit<AgentDecision, 'id' | 'timestamp' | 'hash'>
): AgentDecision {
  const agent = storage.getAgent(agentId)
  if (!agent) {
    throw new Error(`Agent not found: ${agentId}`)
  }

  const config = storage.getConfig()
  const now = Date.now()
  
  // Auto-assess risk level if not critical and not provided
  const riskLevel = decision.riskLevel || assessRiskLevel(
    decision.action,
    decision.confidence,
    decision.input,
    config
  )

  const fullDecision: Omit<AgentDecision, 'hash'> = {
    id: generateUUID(),
    agentId,
    timestamp: now,
    action: decision.action,
    input: decision.input,
    output: decision.output,
    reasoning: decision.reasoning,
    confidence: decision.confidence,
    riskLevel,
    parentDecisionId: decision.parentDecisionId,
    resources: decision.resources
  }

  // Compute integrity hash
  const hash = computeDecisionHash(fullDecision)
  const finalDecision: AgentDecision = { ...fullDecision, hash }

  // Store decision
  storage.setDecision(finalDecision)

  // Update agent profile
  agent.totalDecisions++
  agent.lastActive = now

  // Check for immediate anomalies
  const immediateAnomalies = checkImmediateAnomalies(agent, finalDecision, config)
  immediateAnomalies.forEach(anomaly => {
    storage.setAnomaly(anomaly)
    updateAnomalyScore(agentId)
  })

  // Update baseline periodically
  if (agent.totalDecisions % 100 === 0) {
    const decisions = storage.getDecisionsByAgent(agentId, 1000)
    agent.baseline = buildBaseline(decisions)
  }

  storage.setAgent(agent)

  return finalDecision
}

/**
 * Check for immediate anomalies when a decision is recorded
 */
function checkImmediateAnomalies(
  agent: AgentProfile,
  decision: AgentDecision,
  config: AlertConfig
): BehaviorAnomaly[] {
  const anomalies: BehaviorAnomaly[] = []
  const now = decision.timestamp

  // Check frequency anomaly
  const freq = storage.getDecisionFrequency(agent.id)
  const currentMinute = Math.floor(now / 60000)
  const currentCount = freq.get(currentMinute) || 0
  
  if (currentCount > config.maxDecisionsPerMinute) {
    anomalies.push({
      id: generateUUID(),
      agentId: agent.id,
      timestamp: now,
      type: 'frequency_anomaly',
      severity: currentCount > config.maxDecisionsPerMinute * 2 ? 'critical' : 'high',
      description: `Decision frequency (${currentCount}/min) exceeds threshold (${config.maxDecisionsPerMinute}/min)`,
      evidence: {
        currentFrequency: currentCount,
        threshold: config.maxDecisionsPerMinute,
        minute: currentMinute
      },
      resolved: false,
      relatedDecisions: [decision.id],
      recommendations: []
    })
  }

  // Check for critical action with low confidence
  if (config.criticalActions.includes(decision.action) && decision.confidence < 0.5) {
    anomalies.push({
      id: generateUUID(),
      agentId: agent.id,
      timestamp: now,
      type: 'action_deviation',
      severity: 'critical',
      description: `Critical action '${decision.action}' executed with low confidence (${(decision.confidence * 100).toFixed(1)}%)`,
      evidence: {
        action: decision.action,
        confidence: decision.confidence,
        input: decision.input
      },
      resolved: false,
      relatedDecisions: [decision.id],
      recommendations: []
    })
  }

  // Check for action outside capabilities
  if (!agent.capabilities.includes(decision.action) && !agent.capabilities.includes('*')) {
    anomalies.push({
      id: generateUUID(),
      agentId: agent.id,
      timestamp: now,
      type: 'policy_violation',
      severity: 'high',
      description: `Action '${decision.action}' not in agent capabilities: [${agent.capabilities.join(', ')}]`,
      evidence: {
        action: decision.action,
        capabilities: agent.capabilities
      },
      resolved: false,
      relatedDecisions: [decision.id],
      recommendations: []
    })
  }

  // Check for violation of restrictions
  const inputStr = JSON.stringify(decision.input).toLowerCase()
  for (const restriction of agent.restrictions) {
    if (inputStr.includes(restriction.replace('no_', ''))) {
      anomalies.push({
        id: generateUUID(),
        agentId: agent.id,
        timestamp: now,
        type: 'policy_violation',
        severity: 'critical',
        description: `Decision may violate restriction: ${restriction}`,
        evidence: {
          restriction,
          inputPreview: inputStr.substring(0, 200)
        },
        resolved: false,
        relatedDecisions: [decision.id],
        recommendations: []
      })
    }
  }

  // Add recommendations to anomalies
  anomalies.forEach(anomaly => {
    anomaly.recommendations = generateRecommendations(anomaly)
  })

  return anomalies
}

/**
 * Update anomaly score for an agent based on recent anomalies
 */
function updateAnomalyScore(agentId: string): void {
  const agent = storage.getAgent(agentId)
  if (!agent) return

  const anomalies = storage.getAnomaliesByAgent(agentId, true)
  
  // Calculate weighted anomaly score
  let totalScore = 0
  const recentCutoff = Date.now() - (24 * 60 * 60 * 1000) // Last 24 hours
  
  anomalies
    .filter(a => a.timestamp > recentCutoff)
    .forEach(anomaly => {
      const weight = ANOMALY_WEIGHTS[anomaly.type]
      const multiplier = SEVERITY_MULTIPLIERS[anomaly.severity]
      totalScore += weight * multiplier
    })

  // Normalize to 0-100 with decay
  const previousScore = agent.anomalyScore
  agent.anomalyScore = Math.min(100, Math.round(totalScore * 0.7 + previousScore * 0.3))
  
  // Update trust score inversely
  agent.trustScore = Math.max(0, Math.min(100, 100 - agent.anomalyScore))

  storage.setAgent(agent)
}

/**
 * Get an agent's profile
 * 
 * @param agentId - ID of the agent
 * @returns The agent profile or null if not found
 */
export function getAgentProfile(agentId: string): AgentProfile | null {
  return storage.getAgent(agentId) || null
}

/**
 * Analyze behavior patterns for an agent
 * 
 * @param agentId - ID of the agent to analyze
 * @returns Analysis result with anomaly score, detected anomalies, and recommendations
 * 
 * @example
 * ```typescript
 * const analysis = analyzeBehavior('agent-uuid')
 * console.log(analysis.anomalyScore) // 0-100
 * console.log(analysis.anomalies) // List of detected anomalies
 * console.log(analysis.recommendations) // Recommended actions
 * ```
 */
export function analyzeBehavior(agentId: string): BehaviorAnalysisResult {
  const agent = storage.getAgent(agentId)
  if (!agent) {
    throw new Error(`Agent not found: ${agentId}`)
  }

  const decisions = storage.getDecisionsByAgent(agentId, 1000)
  const anomalies = storage.getAnomaliesByAgent(agentId, true)

  // Build/update baseline if needed
  if (!agent.baseline || decisions.length >= 100) {
    agent.baseline = buildBaseline(decisions)
    storage.setAgent(agent)
  }

  const baseline = agent.baseline
  const newAnomalies: BehaviorAnomaly[] = []
  const recommendations: string[] = []
  const now = Date.now()

  // Analyze action distribution deviation
  if (Object.keys(baseline.actionDistribution).length > 0) {
    const currentDistribution: Record<string, number> = {}
    const recentDecisions = decisions.slice(0, 100)
    recentDecisions.forEach(d => {
      currentDistribution[d.action] = (currentDistribution[d.action] || 0) + 1
    })

    // Normalize
    Object.keys(currentDistribution).forEach(action => {
      currentDistribution[action] /= recentDecisions.length
    })

    // Compare with baseline using KL-divergence-like measure
    for (const action of Object.keys({ ...baseline.actionDistribution, ...currentDistribution })) {
      const baselineProb = baseline.actionDistribution[action] || 0.01
      const currentProb = currentDistribution[action] || 0.01
      const divergence = Math.abs(baselineProb - currentProb)

      if (divergence > 0.2) {
        const anomaly: BehaviorAnomaly = {
          id: generateUUID(),
          agentId,
          timestamp: now,
          type: 'action_deviation',
          severity: divergence > 0.4 ? 'high' : 'medium',
          description: `Action '${action}' frequency changed significantly: ${(baselineProb * 100).toFixed(1)}% → ${(currentProb * 100).toFixed(1)}%`,
          evidence: { action, baselineProb, currentProb, divergence },
          resolved: false,
          relatedDecisions: recentDecisions.slice(0, 10).map(d => d.id),
          recommendations: []
        }
        anomaly.recommendations = generateRecommendations(anomaly)
        newAnomalies.push(anomaly)
      }
    }
  }

  // Analyze confidence trend
  const confidenceWindow = 20
  const recentConfidences = decisions.slice(0, confidenceWindow).map(d => d.confidence)
  const olderConfidences = decisions.slice(confidenceWindow, confidenceWindow * 2).map(d => d.confidence)
  
  let confidenceTrend: 'increasing' | 'stable' | 'decreasing' = 'stable'
  if (recentConfidences.length > 0 && olderConfidences.length > 0) {
    const recentAvg = recentConfidences.reduce((a, b) => a + b, 0) / recentConfidences.length
    const olderAvg = olderConfidences.reduce((a, b) => a + b, 0) / olderConfidences.length
    
    if (recentAvg > olderAvg + 0.1) {
      confidenceTrend = 'increasing'
    } else if (recentAvg < olderAvg - 0.1) {
      confidenceTrend = 'decreasing'
      
      // Flag decreasing confidence as potential issue
      if (recentAvg < 0.6) {
        const anomaly: BehaviorAnomaly = {
          id: generateUUID(),
          agentId,
          timestamp: now,
          type: 'reasoning_inconsistency',
          severity: recentAvg < 0.4 ? 'high' : 'medium',
          description: `Confidence trend decreasing: ${(olderAvg * 100).toFixed(1)}% → ${(recentAvg * 100).toFixed(1)}%`,
          evidence: { olderAvg, recentAvg, trend: 'decreasing' },
          resolved: false,
          relatedDecisions: decisions.slice(0, confidenceWindow).map(d => d.id),
          recommendations: []
        }
        anomaly.recommendations = generateRecommendations(anomaly)
        newAnomalies.push(anomaly)
      }
    }
  }

  // Analyze risk level trend
  const riskLevels = decisions.slice(0, 50).map(d => d.riskLevel)
  const riskScores = { low: 1, medium: 2, high: 3, critical: 4 }
  const avgRisk = riskLevels.reduce((sum, level) => sum + riskScores[level], 0) / riskLevels.length
  let riskTrend: 'increasing' | 'stable' | 'decreasing' = 'stable'
  
  if (avgRisk > 2.5) {
    riskTrend = 'increasing'
    recommendations.push('Recent decisions show elevated risk levels - review agent behavior')
  }

  // Analyze resource usage
  const resourceDecisions = decisions.filter(d => d.resources).slice(0, 100)
  if (resourceDecisions.length > 10) {
    const avgTokens = resourceDecisions.reduce((sum, d) => sum + (d.resources?.tokensUsed || 0), 0) / resourceDecisions.length
    
    if (avgTokens > baseline.avgResourceUsage.tokensUsed * 3) {
      const anomaly: BehaviorAnomaly = {
        id: generateUUID(),
        agentId,
        timestamp: now,
        type: 'resource_abuse',
        severity: avgTokens > baseline.avgResourceUsage.tokensUsed * 5 ? 'critical' : 'high',
        description: `Resource usage spike detected: avg ${(avgTokens / 1000).toFixed(1)}K tokens vs baseline ${(baseline.avgResourceUsage.tokensUsed / 1000).toFixed(1)}K`,
        evidence: { avgTokens, baselineTokens: baseline.avgResourceUsage.tokensUsed },
        resolved: false,
        relatedDecisions: resourceDecisions.slice(0, 10).map(d => d.id),
        recommendations: []
      }
      anomaly.recommendations = generateRecommendations(anomaly)
      newAnomalies.push(anomaly)
    }
  }

  // Analyze reasoning consistency
  const decisionsWithReasoning = decisions.filter(d => d.reasoning).slice(0, 50)
  if (decisionsWithReasoning.length > 5) {
    // Check for self-contradictions in reasoning
    const reasoningTexts = decisionsWithReasoning.map(d => d.reasoning!.toLowerCase())
    
    // Simple contradiction detection (would be enhanced in production)
    const contradictionPatterns = [
      ['cannot', 'can'],
      ['impossible', 'possible'],
      ['not allowed', 'allowed'],
      ['forbidden', 'permitted']
    ]

    for (const [neg, pos] of contradictionPatterns) {
      const hasNeg = reasoningTexts.some(t => t.includes(neg))
      const hasPos = reasoningTexts.some(t => t.includes(pos))
      
      if (hasNeg && hasPos) {
        // Found potential contradiction
        recommendations.push(`Potential reasoning inconsistency detected: '${neg}' vs '${pos}' in recent reasoning chains`)
        break
      }
    }
  }

  // Store new anomalies
  newAnomalies.forEach(anomaly => storage.setAnomaly(anomaly))

  // Calculate overall anomaly score
  const allUnresolved = [...anomalies, ...newAnomalies]
  let calculatedAnomalyScore = agent.anomalyScore

  if (allUnresolved.length > 0) {
    const severityWeights = { low: 1, medium: 2, high: 3, critical: 4 }
    const totalWeight = allUnresolved.reduce((sum, a) => sum + severityWeights[a.severity] * ANOMALY_WEIGHTS[a.type], 0)
    calculatedAnomalyScore = Math.min(100, Math.round(totalWeight / Math.max(allUnresolved.length, 1) * 5))
  }

  // Calculate trust score adjustment
  const trustScoreDelta = Math.round((agent.trustScore - (100 - calculatedAnomalyScore)) * 0.5)

  // Calculate action trends
  const actionTrends: Record<string, number> = {}
  const recentActions = decisions.slice(0, 50)
  recentActions.forEach(d => {
    actionTrends[d.action] = (actionTrends[d.action] || 0) + 1
  })

  // Add general recommendations
  if (calculatedAnomalyScore > 50) {
    recommendations.push('Consider temporarily restricting agent capabilities')
  }
  if (allUnresolved.filter(a => a.severity === 'critical').length > 0) {
    recommendations.push('Critical anomalies detected - immediate review recommended')
  }
  if (agent.trustScore < 50) {
    recommendations.push('Agent trust score is low - consider additional oversight')
  }

  return {
    anomalyScore: calculatedAnomalyScore,
    anomalies: allUnresolved,
    recommendations: [...new Set(recommendations)],
    trustScoreDelta,
    patterns: {
      actionTrends,
      riskTrend,
      confidenceTrend
    }
  }
}

/**
 * Get the decision chain starting from a specific decision
 * 
 * @param decisionId - ID of the starting decision
 * @returns Array of decisions forming the chain (most recent first)
 * 
 * @example
 * ```typescript
 * const chain = getDecisionChain('decision-uuid')
 * console.log(chain.length) // Number of decisions in chain
 * console.log(chain[0].action) // Most recent decision
 * ```
 */
export function getDecisionChain(decisionId: string): AgentDecision[] {
  const chain: AgentDecision[] = []
  let currentId: string | undefined = decisionId
  const visited = new Set<string>()
  const maxDepth = 100 // Prevent infinite loops

  while (currentId && chain.length < maxDepth) {
    if (visited.has(currentId)) {
      break // Cycle detected
    }
    visited.add(currentId)

    const decision = storage.getDecision(currentId)
    if (!decision) {
      break
    }

    chain.push(decision)
    currentId = decision.parentDecisionId
  }

  return chain
}

/**
 * Detect anomalies across all agents
 * 
 * @returns Array of all unresolved anomalies
 * 
 * @example
 * ```typescript
 * const anomalies = detectAnomalies()
 * anomalies.forEach(a => {
 *   console.log(`${a.severity}: ${a.description}`)
 * })
 * ```
 */
export function detectAnomalies(): BehaviorAnomaly[] {
  const allAnomalies = storage.getAllAnomalies(true)
  const agents = storage.getAllAgents()
  const config = storage.getConfig()

  // Cross-agent analysis
  const now = Date.now()
  const hourAgo = now - (60 * 60 * 1000)
  
  // Detect coordinated behavior patterns
  const recentAnomalies = allAnomalies.filter(a => a.timestamp > hourAgo)
  
  // Check for similar anomalies across agents (potential attack)
  const anomalyTypes = new Map<string, number>()
  recentAnomalies.forEach(a => {
    const key = `${a.type}:${a.severity}`
    anomalyTypes.set(key, (anomalyTypes.get(key) || 0) + 1)
  })

  // If multiple agents show same anomaly type, flag it
  for (const [key, count] of anomalyTypes) {
    if (count >= 3) {
      const [type, severity] = key.split(':')
      const crossAgentAnomaly: BehaviorAnomaly = {
        id: generateUUID(),
        agentId: 'system',
        timestamp: now,
        type: type as BehaviorAnomaly['type'],
        severity: severity as BehaviorAnomaly['severity'],
        description: `Cross-agent anomaly pattern detected: ${count} agents showing ${type}`,
        evidence: {
          affectedAgents: [...new Set(recentAnomalies.filter(a => a.type === type).map(a => a.agentId))],
          count
        },
        resolved: false,
        relatedDecisions: [],
        recommendations: [
          'Investigate potential coordinated attack',
          'Review common input sources',
          'Consider temporary system-wide restrictions'
        ]
      }
      storage.setAnomaly(crossAgentAnomaly)
    }
  }

  // Check for agents with critical trust scores
  agents.forEach(agent => {
    if (agent.trustScore < config.trustScoreThreshold) {
      const trustAnomaly: BehaviorAnomaly = {
        id: generateUUID(),
        agentId: agent.id,
        timestamp: now,
        type: 'policy_violation',
        severity: 'critical',
        description: `Agent trust score (${agent.trustScore}) below threshold (${config.trustScoreThreshold})`,
        evidence: {
          trustScore: agent.trustScore,
          threshold: config.trustScoreThreshold,
          anomalyScore: agent.anomalyScore
        },
        resolved: false,
        relatedDecisions: [],
        recommendations: [
          'Review all recent decisions from this agent',
          'Consider agent suspension',
          'Investigate root cause of trust degradation'
        ]
      }
      storage.setAnomaly(trustAnomaly)
    }
  })

  return storage.getAllAnomalies(true)
}

/**
 * Update an agent's trust score manually
 * 
 * @param agentId - ID of the agent
 * @param delta - Amount to change trust score (-100 to +100)
 * @returns The new trust score
 * 
 * @example
 * ```typescript
 * // Reward good behavior
 * const newScore = updateTrustScore('agent-uuid', 5)
 * 
 * // Penalize bad behavior
 * const newScore = updateTrustScore('agent-uuid', -10)
 * ```
 */
export function updateTrustScore(agentId: string, delta: number): number {
  const agent = storage.getAgent(agentId)
  if (!agent) {
    throw new Error(`Agent not found: ${agentId}`)
  }

  // Clamp delta to reasonable range
  const clampedDelta = Math.max(-100, Math.min(100, delta))
  
  // Update trust score with bounds
  agent.trustScore = Math.max(0, Math.min(100, agent.trustScore + clampedDelta))
  
  // Update anomaly score inversely
  agent.anomalyScore = Math.max(0, Math.min(100, 100 - agent.trustScore))
  
  storage.setAgent(agent)
  
  return agent.trustScore
}

// ============================================================================
// Additional API Functions
// ============================================================================

/**
 * Register a callback for anomaly alerts
 * 
 * @param callback - Function to call when an anomaly is detected
 */
export function onAnomalyDetected(callback: AlertCallback): void {
  storage.onAlert(callback)
}

/**
 * Update alert configuration
 * 
 * @param config - Partial configuration to update
 */
export function setAlertConfig(config: Partial<AlertConfig>): void {
  storage.setConfig(config)
}

/**
 * Get current alert configuration
 * 
 * @returns Current alert configuration
 */
export function getAlertConfig(): AlertConfig {
  return storage.getConfig()
}

/**
 * Resolve an anomaly
 * 
 * @param anomalyId - ID of the anomaly to resolve
 * @returns True if resolved successfully
 */
export function resolveAnomaly(anomalyId: string): boolean {
  return storage.resolveAnomaly(anomalyId)
}

/**
 * Get all registered agents
 * 
 * @returns Array of all agent profiles
 */
export function getAllAgents(): AgentProfile[] {
  return storage.getAllAgents()
}

/**
 * Get monitoring statistics
 * 
 * @returns Statistics about monitored agents and anomalies
 */
export function getMonitoringStats(): {
  totalAgents: number
  totalDecisions: number
  totalAnomalies: number
  unresolvedAnomalies: number
  averageTrustScore: number
  averageAnomalyScore: number
} {
  const stats = storage.getStats()
  const agents = storage.getAllAgents()
  
  const avgTrust = agents.length > 0
    ? agents.reduce((sum, a) => sum + a.trustScore, 0) / agents.length
    : 0
  
  const avgAnomaly = agents.length > 0
    ? agents.reduce((sum, a) => sum + a.anomalyScore, 0) / agents.length
    : 0

  return {
    ...stats,
    averageTrustScore: Math.round(avgTrust * 10) / 10,
    averageAnomalyScore: Math.round(avgAnomaly * 10) / 10
  }
}

/**
 * Get decisions for an agent with optional filtering
 * 
 * @param agentId - ID of the agent
 * @param options - Filter options
 * @returns Filtered decisions
 */
export function getAgentDecisions(
  agentId: string,
  options?: {
    limit?: number
    actionType?: string
    riskLevel?: AgentDecision['riskLevel']
    since?: number
  }
): AgentDecision[] {
  let decisions = storage.getDecisionsByAgent(agentId)

  if (options?.actionType) {
    decisions = decisions.filter(d => d.action === options.actionType)
  }

  if (options?.riskLevel) {
    decisions = decisions.filter(d => d.riskLevel === options.riskLevel)
  }

  if (options?.since) {
    decisions = decisions.filter(d => d.timestamp >= options.since)
  }

  return options?.limit ? decisions.slice(0, options.limit) : decisions
}

/**
 * Export agent data for external analysis
 * 
 * @param agentId - ID of the agent
 * @returns Serialized agent data
 */
export function exportAgentData(agentId: string): {
  profile: AgentProfile | null
  decisions: AgentDecision[]
  anomalies: BehaviorAnomaly[]
} {
  return {
    profile: getAgentProfile(agentId),
    decisions: storage.getDecisionsByAgent(agentId),
    anomalies: storage.getAnomaliesByAgent(agentId)
  }
}

// Default export for module
export default {
  registerAgent,
  recordDecision,
  getAgentProfile,
  analyzeBehavior,
  getDecisionChain,
  detectAnomalies,
  updateTrustScore,
  onAnomalyDetected,
  setAlertConfig,
  getAlertConfig,
  resolveAnomaly,
  getAllAgents,
  getMonitoringStats,
  getAgentDecisions,
  exportAgentData
}
