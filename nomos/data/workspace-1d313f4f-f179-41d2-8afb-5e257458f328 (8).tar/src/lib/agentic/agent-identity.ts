/**
 * Agent Identity & Attestation System
 * 
 * Provides cryptographic agent identity certificates, remote attestation
 * for AI agent integrity, supply chain verification, and key management.
 * 
 * Features:
 * - Cryptographic agent identity certificates
 * - Remote attestation for AI agent integrity
 * - Agent supply chain verification
 * - Key rotation and management
 * - Certificate revocation
 * 
 * @module agent-identity
 */

import {
  generateUUID,
  randomBytesHex,
  sha256Sync,
  hmacSha256,
  randomString
} from '@/lib/crypto-utils'

// ============================================================================
// Type Definitions
// ============================================================================

/**
 * Represents a cryptographic agent identity
 */
export interface AgentIdentity {
  /** Unique identifier for the agent */
  id: string
  /** Public key in PEM-like format (base64 encoded) */
  publicKey: string
  /** Encrypted private key (only stored if needed, base64 encoded) */
  privateKeyEncrypted?: string
  /** The agent's certificate */
  certificate: AgentCertificate
  /** Creation timestamp (Unix ms) */
  createdAt: number
  /** Expiration timestamp (Unix ms) */
  expiresAt: number
  /** Current status of the identity */
  status: 'active' | 'expired' | 'revoked'
}

/**
 * X.509-like certificate for agent authentication
 */
export interface AgentCertificate {
  /** Unique certificate identifier */
  id: string
  /** Associated agent ID */
  agentId: string
  /** Public key in base64 format */
  publicKey: string
  /** Certificate issuer ('kasbah-ca' or custom) */
  issuer: string
  /** Subject/agent name */
  subject: string
  /** Valid from timestamp (Unix ms) */
  notBefore: number
  /** Valid until timestamp (Unix ms) */
  notAfter: number
  /** Allowed capabilities for this agent */
  capabilities: string[]
  /** Restrictions applied to this agent */
  restrictions: string[]
  /** Cryptographic signature of certificate content */
  signature: string
  /** Unique serial number for the certificate */
  serialNumber: string
}

/**
 * Remote attestation report for agent integrity verification
 */
export interface AttestationReport {
  /** Unique attestation ID */
  id: string
  /** Associated agent ID */
  agentId: string
  /** Timestamp of attestation (Unix ms) */
  timestamp: number
  /** Type of attestation */
  type: 'boot' | 'runtime' | 'periodic'
  /** Cryptographic measurements of agent components */
  measurements: {
    /** Hash of agent code */
    codeHash: string
    /** Hash of agent configuration */
    configHash: string
    /** Hash of AI model (if applicable) */
    modelHash?: string
    /** Hash of execution environment */
    environmentHash: string
  }
  /** Validation status */
  status: 'valid' | 'invalid' | 'suspicious'
  /** Detailed information about the attestation */
  details: string[]
  /** Cryptographic signature of the report */
  signature: string
}

/**
 * Supply chain verification entry
 */
export interface SupplyChainEntry {
  /** Unique entry ID */
  id: string
  /** Associated agent ID */
  agentId: string
  /** Stage in the supply chain */
  stage: 'source' | 'build' | 'deploy' | 'runtime'
  /** Timestamp of entry (Unix ms) */
  timestamp: number
  /** Hash of the artifact */
  artifactHash: string
  /** Name of the artifact */
  artifactName: string
  /** Whether this entry has been verified */
  verified: boolean
  /** Identity of the verifier (if applicable) */
  verifier?: string
  /** Additional metadata */
  metadata: Record<string, unknown>
}

/**
 * Certificate revocation record
 */
export interface CertificateRevocation {
  /** Unique revocation ID */
  id: string
  /** ID of the revoked certificate */
  certificateId: string
  /** Timestamp of revocation (Unix ms) */
  revokedAt: number
  /** Reason for revocation */
  reason: string
  /** Identity that performed the revocation */
  revokedBy: string
}

/**
 * Key rotation record
 */
export interface KeyRotationRecord {
  /** Unique rotation ID */
  id: string
  /** Agent ID */
  agentId: string
  /** Old public key (truncated) */
  oldPublicKey: string
  /** New public key */
  newPublicKey: string
  /** Timestamp of rotation */
  rotatedAt: number
  /** Reason for rotation */
  reason: string
}

// ============================================================================
// Internal State
// ============================================================================

// Platform CA secret key (in production, this would be from secure storage/HSM)
const PLATFORM_CA_SECRET = randomBytesHex(64)
const PLATFORM_CA_ISSUER = 'kasbah-ca'

// In-memory stores
const agentIdentities = new Map<string, AgentIdentity>()
const certificates = new Map<string, AgentCertificate>()
const revocationList = new Map<string, CertificateRevocation>()
const attestationReports = new Map<string, AttestationReport>()
const supplyChainEntries = new Map<string, SupplyChainEntry[]>()
const keyRotationHistory = new Map<string, KeyRotationRecord[]>()

// Default certificate validity (365 days)
const DEFAULT_CERTIFICATE_VALIDITY_DAYS = 365

// Default identity validity (365 days)
const DEFAULT_IDENTITY_VALIDITY_DAYS = 365

// ============================================================================
// Key Generation Functions
// ============================================================================

/**
 * Generate a cryptographic key pair for an agent
 * Uses a deterministic but secure approach based on random seed
 * 
 * @returns Object containing publicKey and privateKey
 */
export function generateKeyPair(): { publicKey: string; privateKey: string } {
  // Generate a seed for the key pair
  const seed = randomBytesHex(64)
  
  // Derive public key from seed using HMAC
  const publicKey = hmacSha256(seed, 'public-key-derivation')
  
  // Derive private key from seed using HMAC with different context
  const privateKey = hmacSha256(seed, 'private-key-derivation')
  
  return {
    publicKey: Buffer.from(publicKey, 'hex').toString('base64'),
    privateKey: Buffer.from(privateKey, 'hex').toString('base64')
  }
}

/**
 * Encrypt a private key for storage
 * Uses HMAC-based encryption with platform secret
 * 
 * @param privateKey - The private key to encrypt
 * @returns Encrypted private key (base64)
 */
export function encryptPrivateKey(privateKey: string): string {
  const nonce = randomBytesHex(16)
  const encrypted = hmacSha256(PLATFORM_CA_SECRET, `${nonce}|${privateKey}`)
  return Buffer.from(`${nonce}:${encrypted}`).toString('base64')
}

/**
 * Decrypt a private key
 * 
 * @param encryptedKey - The encrypted private key
 * @returns Decrypted private key
 */
export function decryptPrivateKey(encryptedKey: string): string {
  const decoded = Buffer.from(encryptedKey, 'base64').toString()
  const [nonce, encrypted] = decoded.split(':')
  
  // In production, this would use proper decryption
  // For now, return the key directly (encryption is simulated)
  return encrypted || ''
}

// ============================================================================
// Agent Identity Functions
// ============================================================================

/**
 * Create a new agent identity with cryptographic certificate
 * 
 * @param capabilities - List of capabilities the agent is allowed to perform
 * @param restrictions - List of restrictions applied to the agent
 * @param validityDays - Number of days until the identity expires (default: 365)
 * @returns The newly created agent identity
 * 
 * @example
 * ```typescript
 * const identity = createAgentIdentity(
 *   ['detect.deepfake', 'analyze.media'],
 *   ['no-network-access', 'no-file-write'],
 *   90
 * )
 * ```
 */
export function createAgentIdentity(
  capabilities: string[],
  restrictions: string[],
  validityDays: number = DEFAULT_IDENTITY_VALIDITY_DAYS
): AgentIdentity {
  const id = generateUUID()
  const createdAt = Date.now()
  const expiresAt = createdAt + (validityDays * 24 * 60 * 60 * 1000)
  
  // Generate cryptographic key pair
  const { publicKey, privateKey } = generateKeyPair()
  
  // Issue certificate
  const certificate = issueCertificate(
    id,
    publicKey,
    capabilities,
    restrictions,
    validityDays
  )
  
  const identity: AgentIdentity = {
    id,
    publicKey,
    privateKeyEncrypted: encryptPrivateKey(privateKey),
    certificate,
    createdAt,
    expiresAt,
    status: 'active'
  }
  
  // Store the identity
  agentIdentities.set(id, identity)
  
  // Record supply chain entry for identity creation
  recordSupplyChainEntry(id, {
    stage: 'source',
    artifactHash: sha256Sync(JSON.stringify({ id, publicKey, capabilities })),
    artifactName: `agent-identity-${id.slice(0, 8)}`,
    metadata: { type: 'identity_creation', capabilities, restrictions }
  })
  
  return identity
}

/**
 * Get an agent identity by ID
 * 
 * @param agentId - The agent ID to look up
 * @returns The agent identity or undefined if not found
 */
export function getAgentIdentity(agentId: string): AgentIdentity | undefined {
  const identity = agentIdentities.get(agentId)
  
  if (identity) {
    // Check if expired
    if (Date.now() > identity.expiresAt && identity.status === 'active') {
      identity.status = 'expired'
    }
  }
  
  return identity
}

/**
 * List all agent identities with optional filtering
 * 
 * @param statusFilter - Optional status to filter by
 * @returns Array of agent identities
 */
export function listAgentIdentities(
  statusFilter?: 'active' | 'expired' | 'revoked'
): AgentIdentity[] {
  const identities = Array.from(agentIdentities.values())
  
  if (statusFilter) {
    return identities.filter(i => i.status === statusFilter)
  }
  
  return identities
}

/**
 * Rotate keys for an agent identity
 * 
 * @param agentId - The agent ID to rotate keys for
 * @param reason - Reason for key rotation
 * @returns The updated identity with new keys
 */
export function rotateAgentKeys(
  agentId: string,
  reason: string
): { success: boolean; identity?: AgentIdentity; error?: string } {
  const identity = agentIdentities.get(agentId)
  
  if (!identity) {
    return { success: false, error: 'Agent identity not found' }
  }
  
  if (identity.status !== 'active') {
    return { success: false, error: `Agent identity is ${identity.status}` }
  }
  
  // Store old key for history
  const oldPublicKey = identity.publicKey
  
  // Generate new key pair
  const { publicKey, privateKey } = generateKeyPair()
  
  // Issue new certificate
  const newCertificate = issueCertificate(
    agentId,
    publicKey,
    identity.certificate.capabilities,
    identity.certificate.restrictions,
    Math.ceil((identity.expiresAt - Date.now()) / (24 * 60 * 60 * 1000))
  )
  
  // Record rotation
  const rotationRecord: KeyRotationRecord = {
    id: generateUUID(),
    agentId,
    oldPublicKey: oldPublicKey.slice(0, 32) + '...',
    newPublicKey: publicKey,
    rotatedAt: Date.now(),
    reason
  }
  
  const history = keyRotationHistory.get(agentId) || []
  history.push(rotationRecord)
  keyRotationHistory.set(agentId, history)
  
  // Update identity
  identity.publicKey = publicKey
  identity.privateKeyEncrypted = encryptPrivateKey(privateKey)
  identity.certificate = newCertificate
  
  // Revoke old certificate
  revokeCertificate(identity.certificate.id, 'Key rotation', 'system')
  
  return { success: true, identity }
}

// ============================================================================
// Certificate Functions
// ============================================================================

/**
 * Issue a new certificate for an agent
 * 
 * @param agentId - The agent ID to issue certificate for
 * @param publicKey - The agent's public key
 * @param capabilities - Allowed capabilities
 * @param restrictions - Applied restrictions
 * @param validityDays - Certificate validity in days
 * @returns The issued certificate
 */
export function issueCertificate(
  agentId: string,
  publicKey: string,
  capabilities: string[],
  restrictions: string[],
  validityDays: number = DEFAULT_CERTIFICATE_VALIDITY_DAYS
): AgentCertificate {
  const id = generateUUID()
  const serialNumber = randomBytesHex(16)
  const notBefore = Date.now()
  const notAfter = notBefore + (validityDays * 24 * 60 * 60 * 1000)
  const subject = `agent:${agentId}`
  
  // Create certificate content (without signature)
  const certContent = [
    id,
    agentId,
    publicKey,
    PLATFORM_CA_ISSUER,
    subject,
    notBefore.toString(),
    notAfter.toString(),
    capabilities.join(','),
    restrictions.join(','),
    serialNumber
  ].join('|')
  
  // Sign with platform CA
  const signature = hmacSha256(PLATFORM_CA_SECRET, certContent)
  
  const certificate: AgentCertificate = {
    id,
    agentId,
    publicKey,
    issuer: PLATFORM_CA_ISSUER,
    subject,
    notBefore,
    notAfter,
    capabilities,
    restrictions,
    signature,
    serialNumber
  }
  
  // Store certificate
  certificates.set(id, certificate)
  
  return certificate
}

/**
 * Verify a certificate's validity
 * 
 * @param certificate - The certificate to verify
 * @returns Verification result with validity status and optional reason
 */
export function verifyCertificate(
  certificate: AgentCertificate
): { valid: boolean; reason?: string } {
  // Check if revoked
  if (revocationList.has(certificate.id)) {
    return { valid: false, reason: 'Certificate has been revoked' }
  }
  
  // Check time validity
  const now = Date.now()
  if (now < certificate.notBefore) {
    return { valid: false, reason: 'Certificate is not yet valid' }
  }
  if (now > certificate.notAfter) {
    return { valid: false, reason: 'Certificate has expired' }
  }
  
  // Verify signature
  const certContent = [
    certificate.id,
    certificate.agentId,
    certificate.publicKey,
    certificate.issuer,
    certificate.subject,
    certificate.notBefore.toString(),
    certificate.notAfter.toString(),
    certificate.capabilities.join(','),
    certificate.restrictions.join(','),
    certificate.serialNumber
  ].join('|')
  
  const expectedSignature = hmacSha256(PLATFORM_CA_SECRET, certContent)
  
  if (certificate.signature !== expectedSignature) {
    return { valid: false, reason: 'Certificate signature is invalid' }
  }
  
  // Check issuer
  if (certificate.issuer !== PLATFORM_CA_ISSUER) {
    return { valid: false, reason: 'Certificate issuer is not trusted' }
  }
  
  return { valid: true }
}

/**
 * Get a certificate by ID
 * 
 * @param certificateId - The certificate ID
 * @returns The certificate or undefined
 */
export function getCertificate(certificateId: string): AgentCertificate | undefined {
  return certificates.get(certificateId)
}

/**
 * Revoke a certificate
 * 
 * @param certificateId - The certificate ID to revoke
 * @param reason - Reason for revocation
 * @param revokedBy - Identity performing the revocation
 * @returns The revocation record
 */
export function revokeCertificate(
  certificateId: string,
  reason: string,
  revokedBy: string
): CertificateRevocation {
  const certificate = certificates.get(certificateId)
  
  const revocation: CertificateRevocation = {
    id: generateUUID(),
    certificateId,
    revokedAt: Date.now(),
    reason,
    revokedBy
  }
  
  revocationList.set(certificateId, revocation)
  
  // Update agent identity status if exists
  if (certificate) {
    const identity = agentIdentities.get(certificate.agentId)
    if (identity) {
      identity.status = 'revoked'
    }
  }
  
  return revocation
}

/**
 * Check if a certificate is revoked
 * 
 * @param certificateId - The certificate ID to check
 * @returns True if revoked, false otherwise
 */
export function isCertificateRevoked(certificateId: string): boolean {
  return revocationList.has(certificateId)
}

/**
 * Get the certificate revocation list
 * 
 * @returns Array of all revocation records
 */
export function getRevocationList(): CertificateRevocation[] {
  return Array.from(revocationList.values())
}

// ============================================================================
// Attestation Functions
// ============================================================================

/**
 * Generate an attestation report for an agent
 * 
 * @param agentId - The agent ID to attest
 * @param type - Type of attestation (boot, runtime, periodic)
 * @param measurements - Cryptographic measurements of agent components
 * @returns The attestation report
 */
export function generateAttestation(
  agentId: string,
  type: AttestationReport['type'],
  measurements: AttestationReport['measurements']
): AttestationReport {
  const id = generateUUID()
  const timestamp = Date.now()
  
  // Validate measurements and determine status
  const details: string[] = []
  let status: AttestationReport['status'] = 'valid'
  
  // Check code hash against expected (in production, would have reference values)
  if (!measurements.codeHash || measurements.codeHash.length !== 64) {
    details.push('Invalid code hash format')
    status = 'invalid'
  } else {
    details.push('Code hash verified')
  }
  
  // Check config hash
  if (!measurements.configHash || measurements.configHash.length !== 64) {
    details.push('Invalid config hash format')
    status = 'invalid'
  } else {
    details.push('Config hash verified')
  }
  
  // Check environment hash
  if (!measurements.environmentHash || measurements.environmentHash.length !== 64) {
    details.push('Invalid environment hash format')
    status = 'invalid'
  } else {
    details.push('Environment hash verified')
  }
  
  // Model hash is optional
  if (measurements.modelHash) {
    if (measurements.modelHash.length !== 64) {
      details.push('Invalid model hash format')
      status = 'suspicious'
    } else {
      details.push('Model hash verified')
    }
  }
  
  // Create attestation content
  const attestationContent = [
    id,
    agentId,
    timestamp.toString(),
    type,
    measurements.codeHash,
    measurements.configHash,
    measurements.modelHash || '',
    measurements.environmentHash,
    status,
    details.join(';')
  ].join('|')
  
  // Sign attestation
  const signature = hmacSha256(PLATFORM_CA_SECRET, attestationContent)
  
  const report: AttestationReport = {
    id,
    agentId,
    timestamp,
    type,
    measurements,
    status,
    details,
    signature
  }
  
  // Store report
  attestationReports.set(id, report)
  
  // Record in supply chain
  recordSupplyChainEntry(agentId, {
    stage: 'runtime',
    artifactHash: sha256Sync(attestationContent),
    artifactName: `attestation-${type}-${id.slice(0, 8)}`,
    metadata: { type: 'attestation', attestationType: type, status }
  })
  
  return report
}

/**
 * Verify an attestation report
 * 
 * @param report - The attestation report to verify
 * @returns Verification result
 */
export function verifyAttestation(
  report: AttestationReport
): { valid: boolean; reason?: string } {
  // Recreate attestation content
  const attestationContent = [
    report.id,
    report.agentId,
    report.timestamp.toString(),
    report.type,
    report.measurements.codeHash,
    report.measurements.configHash,
    report.measurements.modelHash || '',
    report.measurements.environmentHash,
    report.status,
    report.details.join(';')
  ].join('|')
  
  // Verify signature
  const expectedSignature = hmacSha256(PLATFORM_CA_SECRET, attestationContent)
  
  if (report.signature !== expectedSignature) {
    return { valid: false, reason: 'Attestation signature is invalid' }
  }
  
  // Check status
  if (report.status === 'invalid') {
    return { valid: false, reason: 'Attestation status is invalid' }
  }
  
  if (report.status === 'suspicious') {
    return { valid: false, reason: 'Attestation status is suspicious' }
  }
  
  // Check timestamp (attestations older than 24 hours may need re-verification)
  const attestationAge = Date.now() - report.timestamp
  const maxAge = 24 * 60 * 60 * 1000 // 24 hours
  
  if (attestationAge > maxAge) {
    return { valid: false, reason: 'Attestation is too old (older than 24 hours)' }
  }
  
  return { valid: true }
}

/**
 * Get attestation reports for an agent
 * 
 * @param agentId - The agent ID
 * @param limit - Maximum number of reports to return
 * @returns Array of attestation reports
 */
export function getAgentAttestations(
  agentId: string,
  limit: number = 10
): AttestationReport[] {
  return Array.from(attestationReports.values())
    .filter(r => r.agentId === agentId)
    .sort((a, b) => b.timestamp - a.timestamp)
    .slice(0, limit)
}

/**
 * Calculate hash for attestation measurements
 * 
 * @param content - Content to hash
 * @returns SHA-256 hash
 */
export function calculateMeasurementHash(content: string): string {
  return sha256Sync(content)
}

// ============================================================================
// Supply Chain Functions
// ============================================================================

/**
 * Record a supply chain entry for an agent
 * 
 * @param agentId - The agent ID
 * @param entry - Supply chain entry data (without id, timestamp, verified)
 * @returns The created supply chain entry
 */
export function recordSupplyChainEntry(
  agentId: string,
  entry: Omit<SupplyChainEntry, 'id' | 'timestamp' | 'verified' | 'agentId'>
): SupplyChainEntry {
  const fullEntry: SupplyChainEntry = {
    id: generateUUID(),
    agentId,
    timestamp: Date.now(),
    verified: false,
    ...entry
  }
  
  const entries = supplyChainEntries.get(agentId) || []
  entries.push(fullEntry)
  supplyChainEntries.set(agentId, entries)
  
  return fullEntry
}

/**
 * Verify a supply chain entry
 * 
 * @param entryId - The entry ID to verify
 * @param verifier - Identity of the verifier
 * @returns Updated entry or undefined
 */
export function verifySupplyChainEntry(
  entryId: string,
  verifier: string
): SupplyChainEntry | undefined {
  for (const [, entries] of Array.from(supplyChainEntries.entries())) {
    const entry = entries.find(e => e.id === entryId)
    if (entry) {
      entry.verified = true
      entry.verifier = verifier
      return entry
    }
  }
  return undefined
}

/**
 * Verify the complete supply chain for an agent
 * 
 * @param agentId - The agent ID to verify
 * @returns Verification result with entries and any gaps
 */
export function verifySupplyChain(
  agentId: string
): { verified: boolean; entries: SupplyChainEntry[]; gaps: string[] } {
  const entries = supplyChainEntries.get(agentId) || []
  const gaps: string[] = []
  
  // Check for required stages
  const requiredStages: Array<'source' | 'build' | 'deploy' | 'runtime'> = ['source', 'build', 'deploy']
  const presentStages = new Set(entries.map(e => e.stage))
  
  for (const stage of requiredStages) {
    if (!presentStages.has(stage)) {
      gaps.push(`Missing supply chain stage: ${stage}`)
    }
  }
  
  // Check for verified entries
  const unverifiedEntries = entries.filter(e => !e.verified)
  if (unverifiedEntries.length > 0) {
    gaps.push(`${unverifiedEntries.length} unverified entries in supply chain`)
  }
  
  // Check for hash continuity (entries should be chronologically ordered)
  const sortedEntries = [...entries].sort((a, b) => a.timestamp - b.timestamp)
  
  for (let i = 1; i < sortedEntries.length; i++) {
    const prev = sortedEntries[i - 1]
    const curr = sortedEntries[i]
    
    // Ensure timestamps are in order
    if (curr.timestamp < prev.timestamp) {
      gaps.push(`Supply chain order violation at entry ${curr.id}`)
    }
  }
  
  return {
    verified: gaps.length === 0 && entries.length > 0,
    entries: sortedEntries,
    gaps
  }
}

/**
 * Get supply chain entries for an agent
 * 
 * @param agentId - The agent ID
 * @returns Array of supply chain entries
 */
export function getSupplyChainEntries(agentId: string): SupplyChainEntry[] {
  return supplyChainEntries.get(agentId) || []
}

/**
 * Record deployment of an agent
 * 
 * @param agentId - The agent ID
 * @param deploymentInfo - Deployment information
 * @returns The created supply chain entry
 */
export function recordAgentDeployment(
  agentId: string,
  deploymentInfo: {
    artifactHash: string
    artifactName: string
    environment: string
    version: string
  }
): SupplyChainEntry {
  return recordSupplyChainEntry(agentId, {
    stage: 'deploy',
    artifactHash: deploymentInfo.artifactHash,
    artifactName: deploymentInfo.artifactName,
    metadata: {
      environment: deploymentInfo.environment,
      version: deploymentInfo.version,
      deployedAt: new Date().toISOString()
    }
  })
}

// ============================================================================
// Utility Functions
// ============================================================================

/**
 * Get statistics about the agent identity system
 * 
 * @returns Statistics object
 */
export function getAgentIdentityStats(): {
  totalIdentities: number
  activeIdentities: number
  expiredIdentities: number
  revokedIdentities: number
  totalCertificates: number
  revokedCertificates: number
  totalAttestations: number
  supplyChainEntries: number
} {
  const identities = Array.from(agentIdentities.values())
  
  return {
    totalIdentities: identities.length,
    activeIdentities: identities.filter(i => i.status === 'active').length,
    expiredIdentities: identities.filter(i => i.status === 'expired').length,
    revokedIdentities: identities.filter(i => i.status === 'revoked').length,
    totalCertificates: certificates.size,
    revokedCertificates: revocationList.size,
    totalAttestations: attestationReports.size,
    supplyChainEntries: Array.from(supplyChainEntries.values())
      .reduce((sum, entries) => sum + entries.length, 0)
  }
}

/**
 * Clean up expired identities and certificates
 * 
 * @returns Number of items cleaned up
 */
export function cleanupExpiredIdentities(): number {
  let cleaned = 0
  const now = Date.now()
  
  for (const identity of Array.from(agentIdentities.values())) {
    if (now > identity.expiresAt && identity.status === 'active') {
      identity.status = 'expired'
      cleaned++
    }
  }
  
  return cleaned
}

/**
 * Export agent identity data for audit purposes
 * 
 * @param agentId - The agent ID to export
 * @returns Complete agent data or null if not found
 */
export function exportAgentData(agentId: string): {
  identity: AgentIdentity | undefined
  attestations: AttestationReport[]
  supplyChain: SupplyChainEntry[]
  keyRotations: KeyRotationRecord[]
  revocations: CertificateRevocation[]
} | null {
  const identity = agentIdentities.get(agentId)
  
  if (!identity) {
    return null
  }
  
  return {
    identity,
    attestations: getAgentAttestations(agentId, 100),
    supplyChain: getSupplyChainEntries(agentId),
    keyRotations: keyRotationHistory.get(agentId) || [],
    revocations: Array.from(revocationList.values())
      .filter(r => r.certificateId === identity.certificate.id)
  }
}

/**
 * Verify an agent is fully validated
 * Checks identity, certificate, attestation, and supply chain
 * 
 * @param agentId - The agent ID to verify
 * @returns Comprehensive verification result
 */
export function verifyAgentComplete(
  agentId: string
): {
  valid: boolean
  identity: { valid: boolean; reason?: string }
  certificate: { valid: boolean; reason?: string }
  attestation: { valid: boolean; reason?: string }
  supplyChain: { valid: boolean; gaps: string[] }
} {
  const result = {
    valid: true,
    identity: { valid: false, reason: 'Identity not found' },
    certificate: { valid: false, reason: 'Certificate not found' },
    attestation: { valid: false, reason: 'No attestation found' },
    supplyChain: { valid: false, gaps: ['No supply chain entries'] }
  }
  
  // Check identity
  const identity = getAgentIdentity(agentId)
  if (identity) {
    if (identity.status !== 'active') {
      result.identity = { valid: false, reason: `Identity is ${identity.status}` }
      result.valid = false
    } else if (Date.now() > identity.expiresAt) {
      result.identity = { valid: false, reason: 'Identity has expired' }
      result.valid = false
    } else {
      result.identity = { valid: true, reason: undefined }
    }
  } else {
    result.valid = false
  }
  
  // Check certificate
  if (identity?.certificate) {
    const certResult = verifyCertificate(identity.certificate)
    result.certificate = { valid: certResult.valid, reason: certResult.reason }
    if (!certResult.valid) {
      result.valid = false
    }
  }
  
  // Check attestation (recent)
  const attestations = getAgentAttestations(agentId, 1)
  if (attestations.length > 0) {
    const attestResult = verifyAttestation(attestations[0])
    result.attestation = { valid: attestResult.valid, reason: attestResult.reason }
    if (!attestResult.valid) {
      result.valid = false
    }
  } else {
    result.valid = false
  }
  
  // Check supply chain
  const chainResult = verifySupplyChain(agentId)
  result.supplyChain = {
    valid: chainResult.verified,
    gaps: chainResult.gaps
  }
  if (!chainResult.verified) {
    result.valid = false
  }
  
  return result
}

// ============================================================================
// Initialization
// ============================================================================

// Initialize on module load
if (typeof window !== 'undefined' || typeof process !== 'undefined') {
  // Module is loaded and ready
}
