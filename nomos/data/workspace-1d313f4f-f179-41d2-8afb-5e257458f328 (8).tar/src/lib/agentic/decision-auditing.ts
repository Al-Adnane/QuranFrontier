/**
 * Autonomous Decision Auditing System
 * Part of Kasbah AI Safety Platform
 * 
 * This module provides comprehensive decision provenance tracking,
 * explainability, rollback capabilities, impact assessment, and forensics
 * for autonomous AI agent decisions.
 * 
 * Features:
 * - Complete decision provenance tracking with parent/child relationships
 * - "Why did this agent do X?" explainability with evidence
 * - Rollback capabilities for harmful decisions
 * - Decision impact assessment with risk levels
 * - Decision replay and forensics capabilities
 */

import { generateUUID, sha256Sync, hmacSha256, randomBytesHex } from '@/lib/crypto-utils'

// ============================================================================
// Core Type Definitions
// ============================================================================

/**
 * Represents a single decision made by an autonomous agent
 */
export interface DecisionRecord {
  /** Unique identifier for the decision */
  id: string
  /** ID of the agent that made this decision */
  agentId: string
  /** Unix timestamp (ms) when the decision was made */
  timestamp: number
  /** Type/category of decision (e.g., 'action', 'planning', 'resource_allocation') */
  decisionType: string
  /** Input data that influenced the decision */
  input: Record<string, unknown>
  /** Output/result of the decision */
  output: Record<string, unknown>
  /** Reasoning chain explaining the decision */
  reasoning: DecisionReasoning
  /** Confidence level (0-1) */
  confidence: number
  /** ID of the parent decision that led to this one */
  parentDecisionId?: string
  /** IDs of child decisions that resulted from this one */
  childrenDecisionIds: string[]
  /** Impact assessment of the decision */
  impact: DecisionImpact
  /** Current status of the decision */
  status: 'pending' | 'executed' | 'rolled_back' | 'failed'
  /** Data needed to reverse the decision (if applicable) */
  rollbackData?: Record<string, unknown>
  /** Cryptographic hash for integrity verification */
  hash: string
  /** Previous decision hash for chain integrity */
  previousHash: string
}

/**
 * Detailed reasoning breakdown for a decision
 */
export interface DecisionReasoning {
  /** Primary reason for the decision */
  primaryReason: string
  /** Factors that influenced the decision with weights */
  factors: Array<{
    name: string
    weight: number
    value: unknown
    description: string
  }>
  /** Alternative actions that were considered */
  alternatives: Array<{
    action: string
    score: number
    rejected: boolean
    rejectionReason?: string
  }>
  /** Version of the model used */
  modelVersion?: string
  /** Number of prompt tokens used */
  promptTokens?: number
  /** Number of completion tokens generated */
  completionTokens?: number
}

/**
 * Impact assessment for a decision
 */
export interface DecisionImpact {
  /** Immediate effects of the decision */
  immediate: string[]
  /** Downstream/cascading effects */
  downstream: string[]
  /** Resources affected by the decision */
  affectedResources: string[]
  /** Other agents affected by the decision */
  affectedAgents: string[]
  /** Risk level assessment */
  riskLevel: 'none' | 'low' | 'medium' | 'high' | 'critical'
  /** Whether the decision can be reversed */
  reversible: boolean
}

/**
 * Record of a decision rollback operation
 */
export interface DecisionRollback {
  /** Unique identifier for the rollback */
  id: string
  /** ID of the decision being rolled back */
  decisionId: string
  /** Timestamp when the rollback was performed */
  rolledBackAt: number
  /** ID or name of who initiated the rollback */
  rolledBackBy: string
  /** Reason for the rollback */
  reason: string
  /** Individual actions taken during rollback */
  rollbackActions: Array<{
    action: string
    status: 'success' | 'failed' | 'pending'
    error?: string
  }>
  /** Overall status of the rollback */
  status: 'completed' | 'partial' | 'failed'
  /** Cryptographic hash for audit trail */
  hash: string
}

/**
 * Query result for explainability questions
 */
export interface DecisionQuery {
  /** The original question asked */
  question: string
  /** ID of the decision being queried */
  decisionId: string
  /** Human-readable explanation */
  explanation: string
  /** Evidence supporting the explanation */
  evidence: Array<{
    type: 'input' | 'reasoning' | 'context' | 'external'
    description: string
    data: unknown
  }>
  /** IDs of related decisions */
  relatedDecisions: string[]
}

/**
 * Options for querying decisions
 */
export interface DecisionQueryOptions {
  /** Filter by agent ID */
  agentId?: string
  /** Filter by decision type */
  decisionType?: string
  /** Filter by status */
  status?: DecisionRecord['status']
  /** Filter by risk level */
  riskLevel?: DecisionImpact['riskLevel']
  /** Start time (Unix timestamp ms) */
  startTime?: number
  /** End time (Unix timestamp ms) */
  endTime?: number
  /** Maximum number of results */
  limit?: number
}

/**
 * Decision timeline entry for visualization
 */
export interface DecisionTimelineEntry {
  decision: DecisionRecord
  depth: number
  branchIndex: number
  path: string[]
}

/**
 * Forensic analysis result
 */
export interface ForensicAnalysis {
  decisionId: string
  analysisTimestamp: number
  integrity: {
    valid: boolean
    hashMatches: boolean
    chainIntact: boolean
    tamperingDetected: boolean
    issues: string[]
  }
  provenance: {
    rootDecision: string
    depth: number
    totalDecisionsInChain: number
    branchCount: number
  }
  impact: {
    directDecisions: number
    indirectDecisions: number
    totalAffectedResources: number
    totalAffectedAgents: number
  }
  recommendations: string[]
}

// ============================================================================
// In-Memory Storage (would be persisted in production)
// ============================================================================

/** Decision storage with hash chain */
const decisionStore: Map<string, DecisionRecord> = new Map()

/** Decision index by agent ID */
const agentDecisionIndex: Map<string, Set<string>> = new Map()

/** Decision index by parent ID */
const parentDecisionIndex: Map<string, Set<string>> = new Map()

/** Rollback records */
const rollbackStore: Map<string, DecisionRollback> = new Map()

/** Last decision hash for chain integrity */
let lastDecisionHash: string = '0'.repeat(64)

/** Secret key for HMAC signatures */
const AUDIT_SECRET = randomBytesHex(32)

// ============================================================================
// Core Functions
// ============================================================================

/**
 * Record a new decision in the audit system
 * 
 * @param decision - Decision data (without auto-generated fields)
 * @returns The complete decision record with ID and timestamp
 * 
 * @example
 * ```typescript
 * const decision = recordDecision({
 *   agentId: 'agent-001',
 *   decisionType: 'resource_allocation',
 *   input: { availableResources: 100, requestAmount: 30 },
 *   output: { allocated: 30, remaining: 70 },
 *   reasoning: {
 *     primaryReason: 'Sufficient resources available',
 *     factors: [{ name: 'availability', weight: 0.8, value: 100, description: 'Total available' }],
 *     alternatives: [{ action: 'deny', score: 0.2, rejected: true, rejectionReason: 'Resources available' }]
 *   },
 *   confidence: 0.95,
 *   parentDecisionId: 'parent-123',
 *   impact: {
 *     immediate: ['Resource pool reduced by 30'],
 *     downstream: ['Future allocations may be limited'],
 *     affectedResources: ['compute-pool-1'],
 *     affectedAgents: [],
 *     riskLevel: 'low',
 *     reversible: true
 *   }
 * })
 * ```
 */
export function recordAuditDecision(
  decision: Omit<DecisionRecord, 'id' | 'timestamp' | 'childrenDecisionIds' | 'status' | 'hash' | 'previousHash'>
): DecisionRecord {
  const id = generateUUID()
  const timestamp = Date.now()
  
  // Create the decision record
  const record: DecisionRecord = {
    ...decision,
    id,
    timestamp,
    childrenDecisionIds: [],
    status: 'pending',
    hash: '',
    previousHash: lastDecisionHash
  }
  
  // Compute hash for integrity
  record.hash = computeDecisionHash(record)
  
  // Update last hash for chain
  lastDecisionHash = record.hash
  
  // Store the decision
  decisionStore.set(id, record)
  
  // Update agent index
  if (!agentDecisionIndex.has(decision.agentId)) {
    agentDecisionIndex.set(decision.agentId, new Set())
  }
  agentDecisionIndex.get(decision.agentId)!.add(id)
  
  // Update parent index
  if (decision.parentDecisionId) {
    if (!parentDecisionIndex.has(decision.parentDecisionId)) {
      parentDecisionIndex.set(decision.parentDecisionId, new Set())
    }
    parentDecisionIndex.get(decision.parentDecisionId)!.add(id)
    
    // Update parent's children list
    const parent = decisionStore.get(decision.parentDecisionId)
    if (parent) {
      parent.childrenDecisionIds.push(id)
    }
  }
  
  return record
}

/**
 * Update the status of a decision
 * 
 * @param decisionId - ID of the decision to update
 * @param status - New status
 * @param rollbackData - Optional data for rollback capability
 * @returns True if update was successful
 */
export function updateDecisionStatus(
  decisionId: string,
  status: DecisionRecord['status'],
  rollbackData?: Record<string, unknown>
): boolean {
  const decision = decisionStore.get(decisionId)
  if (!decision) {
    return false
  }
  
  decision.status = status
  if (rollbackData) {
    decision.rollbackData = rollbackData
  }
  
  // Recompute hash to reflect status change
  decision.hash = computeDecisionHash(decision)
  
  return true
}

/**
 * Get the full provenance chain for a decision
 * Traces back from the given decision to the root decision
 * 
 * @param decisionId - ID of the decision to trace
 * @returns Array of decisions from root to the given decision
 */
export function getDecisionProvenance(decisionId: string): DecisionRecord[] {
  const decision = decisionStore.get(decisionId)
  if (!decision) {
    return []
  }
  
  const chain: DecisionRecord[] = [decision]
  let current: DecisionRecord | undefined = decision
  
  // Walk up the parent chain
  while (current?.parentDecisionId) {
    const parent = decisionStore.get(current.parentDecisionId)
    if (parent) {
      chain.unshift(parent)
      current = parent
    } else {
      break
    }
  }
  
  return chain
}

/**
 * Explain a decision with detailed reasoning and evidence
 * 
 * @param decisionId - ID of the decision to explain
 * @param question - Optional specific question to answer
 * @returns Query result with explanation and evidence
 */
export function explainDecision(decisionId: string, question?: string): DecisionQuery {
  const decision = decisionStore.get(decisionId)
  
  if (!decision) {
    return {
      question: question || 'Why was this decision made?',
      decisionId,
      explanation: 'Decision not found in audit trail.',
      evidence: [],
      relatedDecisions: []
    }
  }
  
  // Build explanation based on reasoning
  const defaultQuestion = `Why did agent ${decision.agentId} make decision ${decision.decisionType}?`
  const actualQuestion = question || defaultQuestion
  
  // Build evidence array
  const evidence: DecisionQuery['evidence'] = []
  
  // Input evidence
  evidence.push({
    type: 'input',
    description: 'Input data that influenced the decision',
    data: sanitizeForDisplay(decision.input)
  })
  
  // Reasoning evidence
  evidence.push({
    type: 'reasoning',
    description: 'Primary reason for the decision',
    data: decision.reasoning.primaryReason
  })
  
  // Factor evidence
  const topFactors = [...decision.reasoning.factors]
    .sort((a, b) => b.weight - a.weight)
    .slice(0, 3)
  
  for (const factor of topFactors) {
    evidence.push({
      type: 'reasoning',
      description: `Factor: ${factor.name} (weight: ${(factor.weight * 100).toFixed(0)}%)`,
      data: { value: factor.value, description: factor.description }
    })
  }
  
  // Context evidence (parent decision)
  if (decision.parentDecisionId) {
    const parent = decisionStore.get(decision.parentDecisionId)
    if (parent) {
      evidence.push({
        type: 'context',
        description: 'Parent decision that led to this one',
        data: {
          parentId: parent.id,
          type: parent.decisionType,
          output: sanitizeForDisplay(parent.output)
        }
      })
    }
  }
  
  // Build human-readable explanation
  const factorNames = decision.reasoning.factors
    .sort((a, b) => b.weight - a.weight)
    .slice(0, 3)
    .map(f => f.name)
    .join(', ')
  
  const alternativesRejected = decision.reasoning.alternatives
    .filter(a => a.rejected)
    .map(a => a.action)
  
  let explanation = `Agent ${decision.agentId} made this ${decision.decisionType} decision ` +
    `with ${(decision.confidence * 100).toFixed(0)}% confidence.\n\n` +
    `Primary reason: ${decision.reasoning.primaryReason}\n\n` +
    `Key factors (ranked by importance): ${factorNames}.\n`
  
  if (alternativesRejected.length > 0) {
    explanation += `\nAlternatives considered but rejected: ${alternativesRejected.join(', ')}.`
  }
  
  if (decision.impact.riskLevel !== 'none') {
    explanation += `\n\nRisk level assessed: ${decision.impact.riskLevel}.`
  }
  
  // Get related decisions
  const relatedDecisions = [
    decision.parentDecisionId,
    ...decision.childrenDecisionIds
  ].filter(Boolean) as string[]
  
  return {
    question: actualQuestion,
    decisionId,
    explanation,
    evidence,
    relatedDecisions
  }
}

/**
 * Roll back a decision and all its effects
 * 
 * @param decisionId - ID of the decision to roll back
 * @param reason - Reason for the rollback
 * @param rolledBackBy - Who initiated the rollback
 * @returns Rollback record
 */
export function rollbackDecision(
  decisionId: string,
  reason: string,
  rolledBackBy: string
): DecisionRollback {
  const decision = decisionStore.get(decisionId)
  
  const rollbackId = generateUUID()
  const rollbackActions: DecisionRollback['rollbackActions'] = []
  
  // Check if decision exists
  if (!decision) {
    rollbackActions.push({
      action: 'locate_decision',
      status: 'failed',
      error: 'Decision not found'
    })
    
    return {
      id: rollbackId,
      decisionId,
      rolledBackAt: Date.now(),
      rolledBackBy,
      reason,
      rollbackActions,
      status: 'failed',
      hash: computeRollbackHash(rollbackId, decisionId, 'failed')
    }
  }
  
  // Check if already rolled back
  if (decision.status === 'rolled_back') {
    rollbackActions.push({
      action: 'check_status',
      status: 'failed',
      error: 'Decision already rolled back'
    })
    
    return {
      id: rollbackId,
      decisionId,
      rolledBackAt: Date.now(),
      rolledBackBy,
      reason,
      rollbackActions,
      status: 'failed',
      hash: computeRollbackHash(rollbackId, decisionId, 'failed')
    }
  }
  
  // Check reversibility
  if (!decision.impact.reversible) {
    rollbackActions.push({
      action: 'check_reversibility',
      status: 'failed',
      error: 'Decision is marked as irreversible'
    })
    
    return {
      id: rollbackId,
      decisionId,
      rolledBackAt: Date.now(),
      rolledBackBy,
      reason,
      rollbackActions,
      status: 'failed',
      hash: computeRollbackHash(rollbackId, decisionId, 'failed')
    }
  }
  
  // Perform rollback of child decisions first (recursive)
  let allChildrenRolledBack = true
  for (const childId of decision.childrenDecisionIds) {
    const child = decisionStore.get(childId)
    if (child && child.status !== 'rolled_back') {
      const childRollback = rollbackDecision(
        childId,
        `Cascade rollback from parent ${decisionId}`,
        rolledBackBy
      )
      rollbackActions.push({
        action: `rollback_child_${childId}`,
        status: childRollback.status === 'completed' ? 'success' : 'failed',
        error: childRollback.status !== 'completed' ? 'Child rollback failed' : undefined
      })
      if (childRollback.status !== 'completed') {
        allChildrenRolledBack = false
      }
    }
  }
  
  // Perform the actual rollback
  if (decision.rollbackData) {
    rollbackActions.push({
      action: 'restore_state',
      status: 'success'
    })
  } else {
    rollbackActions.push({
      action: 'restore_state',
      status: 'pending',
      error: 'No rollback data available - manual intervention required'
    })
  }
  
  // Update decision status
  decision.status = 'rolled_back'
  decision.hash = computeDecisionHash(decision)
  
  const status: DecisionRollback['status'] = 
    allChildrenRolledBack && rollbackActions.every(a => a.status !== 'failed')
      ? 'completed'
      : rollbackActions.some(a => a.status === 'success')
        ? 'partial'
        : 'failed'
  
  const rollback: DecisionRollback = {
    id: rollbackId,
    decisionId,
    rolledBackAt: Date.now(),
    rolledBackBy,
    reason,
    rollbackActions,
    status,
    hash: computeRollbackHash(rollbackId, decisionId, status)
  }
  
  // Store rollback record
  rollbackStore.set(rollbackId, rollback)
  
  return rollback
}

/**
 * Assess the impact of a decision
 * 
 * @param decisionId - ID of the decision to assess
 * @returns Impact assessment
 */
export function assessImpact(decisionId: string): DecisionImpact {
  const decision = decisionStore.get(decisionId)
  
  if (!decision) {
    return {
      immediate: [],
      downstream: [],
      affectedResources: [],
      affectedAgents: [],
      riskLevel: 'none',
      reversible: true
    }
  }
  
  // Count downstream effects
  const downstreamEffects: string[] = [...decision.impact.downstream]
  const affectedResources = new Set(decision.impact.affectedResources)
  const affectedAgents = new Set(decision.impact.affectedAgents)
  
  // Traverse children to assess cascading impact
  const traverseChildren = (parentId: string, depth: number) => {
    if (depth > 10) return // Prevent infinite loops
    
    const children = parentDecisionIndex.get(parentId)
    if (!children) return
    
    for (const childId of children) {
      const child = decisionStore.get(childId)
      if (child) {
        child.impact.affectedResources.forEach(r => affectedResources.add(r))
        child.impact.affectedAgents.forEach(a => affectedAgents.add(a))
        downstreamEffects.push(`Decision ${childId}: ${child.decisionType}`)
        traverseChildren(childId, depth + 1)
      }
    }
  }
  
  traverseChildren(decisionId, 0)
  
  // Reassess risk level based on cascade
  let riskLevel = decision.impact.riskLevel
  if (downstreamEffects.length > 5 && riskLevel === 'low') {
    riskLevel = 'medium'
  }
  if (downstreamEffects.length > 10 && riskLevel !== 'critical') {
    riskLevel = 'high'
  }
  if (affectedAgents.size > 3 && riskLevel !== 'critical') {
    riskLevel = 'high'
  }
  
  return {
    immediate: decision.impact.immediate,
    downstream: downstreamEffects,
    affectedResources: Array.from(affectedResources),
    affectedAgents: Array.from(affectedAgents),
    riskLevel,
    reversible: decision.impact.reversible
  }
}

/**
 * Get decision timeline for an agent or time range
 * 
 * @param agentId - Optional filter by agent ID
 * @param startTime - Optional start time filter
 * @param endTime - Optional end time filter
 * @returns Array of decisions in chronological order
 */
export function getDecisionTimeline(
  agentId?: string,
  startTime?: number,
  endTime?: number
): DecisionRecord[] {
  let decisions: DecisionRecord[]
  
  if (agentId) {
    const decisionIds = agentDecisionIndex.get(agentId)
    if (!decisionIds) return []
    decisions = Array.from(decisionIds)
      .map(id => decisionStore.get(id))
      .filter((d): d is DecisionRecord => d !== undefined)
  } else {
    decisions = Array.from(decisionStore.values())
  }
  
  // Apply time filters
  if (startTime !== undefined) {
    decisions = decisions.filter(d => d.timestamp >= startTime)
  }
  if (endTime !== undefined) {
    decisions = decisions.filter(d => d.timestamp <= endTime)
  }
  
  // Sort by timestamp
  return decisions.sort((a, b) => a.timestamp - b.timestamp)
}

/**
 * Replay a decision to verify its output
 * 
 * @param decisionId - ID of the decision to replay
 * @returns Input and expected output for replay verification
 */
export function replayDecision(decisionId: string): {
  input: Record<string, unknown>
  expectedOutput: Record<string, unknown>
  reasoning: DecisionReasoning
  confidence: number
  replayable: boolean
  message: string
} {
  const decision = decisionStore.get(decisionId)
  
  if (!decision) {
    return {
      input: {},
      expectedOutput: {},
      reasoning: { primaryReason: '', factors: [], alternatives: [] },
      confidence: 0,
      replayable: false,
      message: 'Decision not found in audit trail'
    }
  }
  
  return {
    input: sanitizeForDisplay(decision.input),
    expectedOutput: sanitizeForDisplay(decision.output),
    reasoning: decision.reasoning,
    confidence: decision.confidence,
    replayable: true,
    message: 'Decision data available for replay verification'
  }
}

/**
 * Perform forensic analysis on a decision
 * 
 * @param decisionId - ID of the decision to analyze
 * @returns Comprehensive forensic analysis
 */
export function performForensicAnalysis(decisionId: string): ForensicAnalysis {
  const decision = decisionStore.get(decisionId)
  const issues: string[] = []
  
  if (!decision) {
    return {
      decisionId,
      analysisTimestamp: Date.now(),
      integrity: {
        valid: false,
        hashMatches: false,
        chainIntact: false,
        tamperingDetected: false,
        issues: ['Decision not found in audit trail']
      },
      provenance: {
        rootDecision: '',
        depth: 0,
        totalDecisionsInChain: 0,
        branchCount: 0
      },
      impact: {
        directDecisions: 0,
        indirectDecisions: 0,
        totalAffectedResources: 0,
        totalAffectedAgents: 0
      },
      recommendations: ['Investigate why decision ID is not in audit trail']
    }
  }
  
  // Verify hash integrity
  const expectedHash = computeDecisionHash(decision)
  const hashMatches = decision.hash === expectedHash
  if (!hashMatches) {
    issues.push('Decision hash does not match computed hash - possible tampering')
  }
  
  // Verify chain integrity
  const provenance = getDecisionProvenance(decisionId)
  let chainIntact = true
  
  for (let i = 1; i < provenance.length; i++) {
    if (provenance[i].previousHash !== provenance[i - 1].hash) {
      chainIntact = false
      issues.push(`Chain broken between decisions ${provenance[i - 1].id} and ${provenance[i].id}`)
    }
  }
  
  // Calculate cascade impact
  const directChildren = decision.childrenDecisionIds.length
  let indirectCount = 0
  const allAffectedResources = new Set(decision.impact.affectedResources)
  const allAffectedAgents = new Set(decision.impact.affectedAgents)
  
  const countIndirect = (parentId: string, depth: number) => {
    if (depth > 20) return
    const children = parentDecisionIndex.get(parentId)
    if (!children) return
    
    for (const childId of children) {
      indirectCount++
      const child = decisionStore.get(childId)
      if (child) {
        child.impact.affectedResources.forEach(r => allAffectedResources.add(r))
        child.impact.affectedAgents.forEach(a => allAffectedAgents.add(a))
        countIndirect(childId, depth + 1)
      }
    }
  }
  
  countIndirect(decisionId, 0)
  
  // Generate recommendations
  const recommendations: string[] = []
  
  if (!hashMatches) {
    recommendations.push('Investigate potential tampering with decision record')
  }
  
  if (!chainIntact) {
    recommendations.push('Verify audit trail integrity with system administrator')
  }
  
  if (decision.impact.riskLevel === 'high' || decision.impact.riskLevel === 'critical') {
    recommendations.push('Review decision for potential harmful effects')
    recommendations.push('Consider implementing additional safeguards for similar decisions')
  }
  
  if (directChildren > 5) {
    recommendations.push('High cascade count - review downstream decisions')
  }
  
  if (allAffectedAgents.size > 3) {
    recommendations.push('Multiple agents affected - ensure proper notification')
  }
  
  return {
    decisionId,
    analysisTimestamp: Date.now(),
    integrity: {
      valid: hashMatches && chainIntact,
      hashMatches,
      chainIntact,
      tamperingDetected: !hashMatches || !chainIntact,
      issues
    },
    provenance: {
      rootDecision: provenance[0]?.id || '',
      depth: provenance.length,
      totalDecisionsInChain: provenance.length,
      branchCount: directChildren
    },
    impact: {
      directDecisions: directChildren,
      indirectDecisions: indirectCount,
      totalAffectedResources: allAffectedResources.size,
      totalAffectedAgents: allAffectedAgents.size
    },
    recommendations
  }
}

// ============================================================================
// Query and Search Functions
// ============================================================================

/**
 * Query decisions with filters
 * 
 * @param options - Query options
 * @returns Matching decisions
 */
export function queryDecisions(options: DecisionQueryOptions = {}): DecisionRecord[] {
  let decisions = Array.from(decisionStore.values())
  
  if (options.agentId) {
    decisions = decisions.filter(d => d.agentId === options.agentId)
  }
  
  if (options.decisionType) {
    decisions = decisions.filter(d => d.decisionType === options.decisionType)
  }
  
  if (options.status) {
    decisions = decisions.filter(d => d.status === options.status)
  }
  
  if (options.riskLevel) {
    decisions = decisions.filter(d => d.impact.riskLevel === options.riskLevel)
  }
  
  if (options.startTime !== undefined) {
    decisions = decisions.filter(d => d.timestamp >= options.startTime!)
  }
  
  if (options.endTime !== undefined) {
    decisions = decisions.filter(d => d.timestamp <= options.endTime!)
  }
  
  // Sort by timestamp descending
  decisions.sort((a, b) => b.timestamp - a.timestamp)
  
  // Apply limit
  if (options.limit !== undefined && options.limit > 0) {
    decisions = decisions.slice(0, options.limit)
  }
  
  return decisions
}

/**
 * Get a single decision by ID
 * 
 * @param decisionId - Decision ID
 * @returns Decision record or null
 */
export function getDecision(decisionId: string): DecisionRecord | null {
  return decisionStore.get(decisionId) || null
}

/**
 * Get all children of a decision
 * 
 * @param decisionId - Parent decision ID
 * @returns Array of child decisions
 */
export function getChildDecisions(decisionId: string): DecisionRecord[] {
  const children = parentDecisionIndex.get(decisionId)
  if (!children) return []
  
  return Array.from(children)
    .map(id => decisionStore.get(id))
    .filter((d): d is DecisionRecord => d !== undefined)
}

/**
 * Get rollback history for a decision
 * 
 * @param decisionId - Decision ID
 * @returns Array of rollback records
 */
export function getRollbackHistory(decisionId: string): DecisionRollback[] {
  return Array.from(rollbackStore.values())
    .filter(r => r.decisionId === decisionId)
    .sort((a, b) => b.rolledBackAt - a.rolledBackAt)
}

// ============================================================================
// Statistics and Monitoring
// ============================================================================

/**
 * Get statistics about the decision audit system
 * 
 * @returns Statistics object
 */
export function getAuditStatistics(): {
  totalDecisions: number
  totalAgents: number
  totalRollbacks: number
  decisionsByStatus: Record<string, number>
  decisionsByRiskLevel: Record<string, number>
  decisionsByType: Record<string, number>
  averageConfidence: number
  chainDepth: { min: number; max: number; average: number }
} {
  const decisions = Array.from(decisionStore.values())
  
  const decisionsByStatus: Record<string, number> = {}
  const decisionsByRiskLevel: Record<string, number> = {}
  const decisionsByType: Record<string, number> = {}
  
  let totalConfidence = 0
  const depths: number[] = []
  
  for (const decision of decisions) {
    // Count by status
    decisionsByStatus[decision.status] = (decisionsByStatus[decision.status] || 0) + 1
    
    // Count by risk level
    decisionsByRiskLevel[decision.impact.riskLevel] = 
      (decisionsByRiskLevel[decision.impact.riskLevel] || 0) + 1
    
    // Count by type
    decisionsByType[decision.decisionType] = 
      (decisionsByType[decision.decisionType] || 0) + 1
    
    // Sum confidence
    totalConfidence += decision.confidence
    
    // Calculate depth
    const provenance = getDecisionProvenance(decision.id)
    depths.push(provenance.length)
  }
  
  return {
    totalDecisions: decisions.length,
    totalAgents: agentDecisionIndex.size,
    totalRollbacks: rollbackStore.size,
    decisionsByStatus,
    decisionsByRiskLevel,
    decisionsByType,
    averageConfidence: decisions.length > 0 ? totalConfidence / decisions.length : 0,
    chainDepth: {
      min: depths.length > 0 ? Math.min(...depths) : 0,
      max: depths.length > 0 ? Math.max(...depths) : 0,
      average: depths.length > 0 ? depths.reduce((a, b) => a + b, 0) / depths.length : 0
    }
  }
}

/**
 * Generate a decision timeline visualization
 * 
 * @param agentId - Agent ID to visualize
 * @param maxDepth - Maximum depth to traverse
 * @returns Timeline entries for visualization
 */
export function generateDecisionTimelineVisualization(
  agentId: string,
  maxDepth: number = 10
): DecisionTimelineEntry[] {
  const decisions = getDecisionTimeline(agentId)
  const entries: DecisionTimelineEntry[] = []
  const visited = new Set<string>()
  
  // Find root decisions (no parent)
  const roots = decisions.filter(d => !d.parentDecisionId)
  
  const traverse = (decision: DecisionRecord, depth: number, path: string[], branchIndex: number) => {
    if (visited.has(decision.id) || depth > maxDepth) return
    visited.add(decision.id)
    
    entries.push({
      decision,
      depth,
      branchIndex,
      path: [...path, decision.id]
    })
    
    const children = getChildDecisions(decision.id)
    children.forEach((child, index) => {
      traverse(child, depth + 1, [...path, decision.id], index)
    })
  }
  
  roots.forEach((root, index) => {
    traverse(root, 0, [], index)
  })
  
  return entries.sort((a, b) => a.decision.timestamp - b.decision.timestamp)
}

// ============================================================================
// Export and Import Functions
// ============================================================================

/**
 * Export all decision records for backup or external audit
 * 
 * @returns Exportable data structure
 */
export function exportDecisions(): {
  version: string
  exportedAt: number
  decisions: DecisionRecord[]
  rollbacks: DecisionRollback[]
  statistics: ReturnType<typeof getAuditStatistics>
} {
  return {
    version: '1.0.0',
    exportedAt: Date.now(),
    decisions: Array.from(decisionStore.values()),
    rollbacks: Array.from(rollbackStore.values()),
    statistics: getAuditStatistics()
  }
}

/**
 * Import decision records from a backup
 * 
 * @param data - Exported data to import
 * @returns Number of decisions imported
 */
export function importDecisions(data: {
  version: string
  decisions: DecisionRecord[]
  rollbacks?: DecisionRollback[]
}): number {
  let count = 0
  
  for (const decision of data.decisions) {
    if (!decisionStore.has(decision.id)) {
      decisionStore.set(decision.id, decision)
      
      // Rebuild indices
      if (!agentDecisionIndex.has(decision.agentId)) {
        agentDecisionIndex.set(decision.agentId, new Set())
      }
      agentDecisionIndex.get(decision.agentId)!.add(decision.id)
      
      if (decision.parentDecisionId) {
        if (!parentDecisionIndex.has(decision.parentDecisionId)) {
          parentDecisionIndex.set(decision.parentDecisionId, new Set())
        }
        parentDecisionIndex.get(decision.parentDecisionId)!.add(decision.id)
      }
      
      count++
    }
  }
  
  // Import rollbacks
  if (data.rollbacks) {
    for (const rollback of data.rollbacks) {
      if (!rollbackStore.has(rollback.id)) {
        rollbackStore.set(rollback.id, rollback)
      }
    }
  }
  
  // Update last hash
  const allDecisions = Array.from(decisionStore.values())
  if (allDecisions.length > 0) {
    lastDecisionHash = allDecisions.sort((a, b) => b.timestamp - a.timestamp)[0].hash
  }
  
  return count
}

/**
 * Clear all decision records (for testing/reset)
 * 
 * @param confirmSecurityKey - Security key to confirm action
 */
export function clearAllDecisions(confirmSecurityKey: string): boolean {
  // Simple security check
  if (confirmSecurityKey !== 'CONFIRM_CLEAR_DECISIONS') {
    return false
  }
  
  decisionStore.clear()
  agentDecisionIndex.clear()
  parentDecisionIndex.clear()
  rollbackStore.clear()
  lastDecisionHash = '0'.repeat(64)
  
  return true
}

// ============================================================================
// Helper Functions
// ============================================================================

/**
 * Compute hash for a decision record
 */
function computeDecisionHash(decision: Omit<DecisionRecord, 'hash'>): string {
  const content = [
    decision.id,
    decision.timestamp.toString(),
    decision.agentId,
    decision.decisionType,
    JSON.stringify(decision.input),
    JSON.stringify(decision.output),
    decision.reasoning.primaryReason,
    decision.confidence.toString(),
    decision.parentDecisionId || '',
    decision.status,
    decision.previousHash
  ].join('|')
  
  return sha256Sync(content)
}

/**
 * Compute hash for a rollback record
 */
function computeRollbackHash(id: string, decisionId: string, status: string): string {
  return hmacSha256(AUDIT_SECRET, `${id}|${decisionId}|${status}`)
}

/**
 * Sanitize data for display (remove sensitive info, truncate long strings)
 */
function sanitizeForDisplay(data: Record<string, unknown>): Record<string, unknown> {
  const sanitized: Record<string, unknown> = {}
  
  for (const [key, value] of Object.entries(data)) {
    if (typeof value === 'string') {
      sanitized[key] = value.length > 200 ? value.slice(0, 200) + '...' : value
    } else if (typeof value === 'number' || typeof value === 'boolean') {
      sanitized[key] = value
    } else if (value === null) {
      sanitized[key] = null
    } else if (Array.isArray(value)) {
      sanitized[key] = value.slice(0, 10)
    } else if (typeof value === 'object') {
      sanitized[key] = '[object]'
    }
  }
  
  return sanitized
}

// ============================================================================
// Initialize Module
// ============================================================================

// Log initialization
console.log('[Decision Auditing] Module initialized with', decisionStore.size, 'existing decisions')
