/**
 * Policy-as-Code Guardrails for Kasbah AI Safety Platform
 * 
 * OPA-style policy engine with deny-by-default security model.
 * Provides real-time policy enforcement, versioning, and comprehensive audit trails.
 * 
 * @module policy-guardrails
 * @version 1.0.0
 */

import { generateUUID, sha256Sync, hmacSha256, randomBytesHex } from '@/lib/crypto-utils'

// ============================================================================
// Core Type Definitions
// ============================================================================

/**
 * Represents a single policy rule in the system
 */
export interface Policy {
  /** Unique identifier for the policy */
  id: string
  /** Human-readable name */
  name: string
  /** Semantic version string (e.g., "1.0.0") */
  version: string
  /** Detailed description of what this policy does */
  description: string
  /** Whether this policy allows or denies actions */
  effect: 'allow' | 'deny'
  /** Priority level (higher = evaluated first). Deny policies always override allow. */
  priority: number
  /** Conditions that must be met for this policy to apply */
  conditions: PolicyCondition[]
  /** Actions this policy applies to (e.g., "file:read", "model:invoke") */
  actions: string[]
  /** Resources this policy applies to (e.g., "s3://bucket/*", "model:gpt-4") */
  resources: string[]
  /** Additional metadata for extensibility */
  metadata: Record<string, unknown>
  /** Creation timestamp (Unix epoch milliseconds) */
  createdAt: number
  /** Last update timestamp (Unix epoch milliseconds) */
  updatedAt: number
  /** Whether this policy is currently active */
  enabled: boolean
}

/**
 * Condition type for policy evaluation
 */
export type ConditionType = 'equals' | 'notEquals' | 'contains' | 'greaterThan' | 'lessThan' | 'regex' | 'in' | 'notIn' | 'exists' | 'notExists' | 'startsWith' | 'endsWith'

/**
 * A single condition within a policy
 */
export interface PolicyCondition {
  /** Type of comparison to perform */
  type: ConditionType
  /** JSON path in the request context to evaluate */
  field: string
  /** Value to compare against */
  value: unknown
  /** Optional description of what this condition checks */
  description?: string
}

/**
 * Request to evaluate a policy decision
 */
export interface PolicyEvaluationRequest {
  /** ID of the agent making the request */
  agentId: string
  /** Action being requested (e.g., "file:read", "model:invoke") */
  action: string
  /** Resource being accessed */
  resource: string
  /** Additional context for evaluation (e.g., confidence, timestamp, source IP) */
  context: Record<string, unknown>
  /** Request timestamp (Unix epoch milliseconds) */
  timestamp: number
  /** Optional request ID for tracking */
  requestId?: string
}

/**
 * Result of a policy evaluation
 */
export interface PolicyEvaluationResult {
  /** Whether the action is allowed */
  allowed: boolean
  /** Unique identifier for this decision */
  decisionId: string
  /** IDs of policies that matched this request */
  matchedPolicies: string[]
  /** ID of the policy that denied the request (if denied) */
  deniedBy?: string
  /** Human-readable reason for the decision */
  reason?: string
  /** Audit entry record */
  auditEntry: {
    request: PolicyEvaluationRequest
    result: 'allow' | 'deny'
    evaluatedAt: number
    policiesChecked: number
    evaluationTimeMs: number
  }
  /** Execution ticket for this decision (for replay prevention) */
  ticket?: string
}

/**
 * Audit entry for policy decisions
 */
export interface PolicyAuditEntry {
  /** Unique identifier */
  id: string
  /** Timestamp of the decision */
  timestamp: number
  /** Agent that made the request */
  agentId: string
  /** Action requested */
  action: string
  /** Resource requested */
  resource: string
  /** Final decision */
  decision: 'allow' | 'deny'
  /** Policies that matched */
  matchedPolicies: string[]
  /** Reason for denial (if denied) */
  reason?: string
  /** Hash for integrity verification */
  hash: string
  /** Previous entry hash for chain verification */
  previousHash: string
  /** Request ID if provided */
  requestId?: string
}

/**
 * Policy version history entry
 */
export interface PolicyVersion {
  /** Version identifier */
  version: string
  /** Policy state at this version */
  policy: Policy
  /** Who made the change */
  changedBy: string
  /** When the change was made */
  changedAt: number
  /** What changed */
  changeDescription: string
}

/**
 * Filter options for listing policies
 */
export interface PolicyFilter {
  /** Filter by action pattern */
  action?: string
  /** Filter by resource pattern */
  resource?: string
  /** Filter by effect type */
  effect?: 'allow' | 'deny'
  /** Filter by enabled status */
  enabled?: boolean
  /** Minimum priority */
  minPriority?: number
  /** Maximum priority */
  maxPriority?: number
}

/**
 * Rate limit tracking entry
 */
interface RateLimitEntry {
  count: number
  windowStart: number
}

// ============================================================================
// Policy Store & State Management
// ============================================================================

/**
 * In-memory policy store
 * In production, this would be backed by a database with caching
 */
class PolicyStore {
  private policies: Map<string, Policy> = new Map()
  private policyVersions: Map<string, PolicyVersion[]> = new Map()
  private auditLog: PolicyAuditEntry[] = []
  private rateLimitStore: Map<string, RateLimitEntry> = new Map()
  private lastAuditHash: string = '0'.repeat(64)
  private initialized: boolean = false

  constructor() {
    this.initialize()
  }

  /**
   * Initialize with default policies
   */
  private initialize(): void {
    if (this.initialized) return
    
    // Load default policies
    const defaultPolicies = createDefaultPolicies()
    for (const policy of defaultPolicies) {
      this.policies.set(policy.id, policy)
      this.policyVersions.set(policy.id, [{
        version: policy.version,
        policy: { ...policy },
        changedBy: 'system',
        changedAt: policy.createdAt,
        changeDescription: 'Initial policy creation'
      }])
    }
    
    this.initialized = true
  }

  /**
   * Add a policy to the store
   */
  addPolicy(policy: Policy): void {
    this.policies.set(policy.id, policy)
  }

  /**
   * Get a policy by ID
   */
  getPolicy(id: string): Policy | undefined {
    return this.policies.get(id)
  }

  /**
   * Get all policies
   */
  getAllPolicies(): Policy[] {
    return Array.from(this.policies.values())
  }

  /**
   * Delete a policy
   */
  deletePolicy(id: string): boolean {
    return this.policies.delete(id)
  }

  /**
   * Update a policy
   */
  updatePolicy(id: string, updates: Partial<Policy>, changedBy: string, changeDescription: string): Policy | null {
    const existing = this.policies.get(id)
    if (!existing) return null

    const updated: Policy = {
      ...existing,
      ...updates,
      id: existing.id, // Prevent ID changes
      createdAt: existing.createdAt, // Preserve creation time
      updatedAt: Date.now()
    }

    // Parse version and increment
    const [major, minor, patch] = updated.version.split('.').map(Number)
    updated.version = `${major}.${minor}.${patch + 1}`

    this.policies.set(id, updated)

    // Record version history
    const versions = this.policyVersions.get(id) || []
    versions.push({
      version: updated.version,
      policy: { ...updated },
      changedBy,
      changedAt: updated.updatedAt,
      changeDescription
    })
    this.policyVersions.set(id, versions)

    return updated
  }

  /**
   * Get version history for a policy
   */
  getPolicyVersions(id: string): PolicyVersion[] {
    return this.policyVersions.get(id) || []
  }

  /**
   * Add audit entry
   */
  addAuditEntry(entry: Omit<PolicyAuditEntry, 'id' | 'hash' | 'previousHash'>): PolicyAuditEntry {
    const fullEntry: PolicyAuditEntry = {
      ...entry,
      id: generateUUID(),
      previousHash: this.lastAuditHash,
      hash: ''
    }
    fullEntry.hash = this.computeAuditHash(fullEntry)
    this.lastAuditHash = fullEntry.hash
    this.auditLog.push(fullEntry)
    return fullEntry
  }

  /**
   * Get audit trail
   */
  getAuditTrail(agentId?: string, limit?: number): PolicyAuditEntry[] {
    let entries = this.auditLog
    if (agentId) {
      entries = entries.filter(e => e.agentId === agentId)
    }
    if (limit && limit > 0) {
      entries = entries.slice(-limit)
    }
    return entries
  }

  /**
   * Compute hash for audit entry
   */
  private computeAuditHash(entry: Omit<PolicyAuditEntry, 'hash'>): string {
    const content = [
      entry.id,
      entry.timestamp,
      entry.agentId,
      entry.action,
      entry.resource,
      entry.decision,
      entry.matchedPolicies.join(','),
      entry.reason || '',
      entry.previousHash
    ].join('|')
    return sha256Sync(content)
  }

  /**
   * Verify audit log integrity
   */
  verifyAuditIntegrity(): { valid: boolean; errors: string[] } {
    const errors: string[] = []
    
    for (let i = 0; i < this.auditLog.length; i++) {
      const entry = this.auditLog[i]
      
      // Verify hash chain
      if (i > 0 && entry.previousHash !== this.auditLog[i - 1].hash) {
        errors.push(`Hash chain broken at entry ${i}`)
      }
      
      // Verify entry hash
      const expectedHash = this.computeAuditHash({ ...entry, hash: '' })
      if (entry.hash !== expectedHash) {
        errors.push(`Entry ${i} has invalid hash`)
      }
    }
    
    return { valid: errors.length === 0, errors }
  }

  /**
   * Rate limit operations
   */
  checkRateLimit(key: string, maxRequests: number, windowMs: number): { allowed: boolean; remaining: number; resetIn: number } {
    const now = Date.now()
    const entry = this.rateLimitStore.get(key)
    
    if (!entry || now - entry.windowStart > windowMs) {
      // New window
      this.rateLimitStore.set(key, { count: 1, windowStart: now })
      return { allowed: true, remaining: maxRequests - 1, resetIn: windowMs }
    }
    
    if (entry.count >= maxRequests) {
      const resetIn = windowMs - (now - entry.windowStart)
      return { allowed: false, remaining: 0, resetIn }
    }
    
    entry.count++
    const resetIn = windowMs - (now - entry.windowStart)
    return { allowed: true, remaining: maxRequests - entry.count, resetIn }
  }

  /**
   * Clean up expired rate limit entries
   */
  cleanupRateLimits(windowMs: number): number {
    const now = Date.now()
    let cleaned = 0
    for (const [key, entry] of this.rateLimitStore.entries()) {
      if (now - entry.windowStart > windowMs) {
        this.rateLimitStore.delete(key)
        cleaned++
      }
    }
    return cleaned
  }

  /**
   * Get store statistics
   */
  getStats(): {
    policyCount: number
    auditCount: number
    rateLimitEntries: number
    oldestAudit: number | null
    newestAudit: number | null
  } {
    return {
      policyCount: this.policies.size,
      auditCount: this.auditLog.length,
      rateLimitEntries: this.rateLimitStore.size,
      oldestAudit: this.auditLog.length > 0 ? this.auditLog[0].timestamp : null,
      newestAudit: this.auditLog.length > 0 ? this.auditLog[this.auditLog.length - 1].timestamp : null
    }
  }
}

// Singleton store instance
const policyStore = new PolicyStore()

// ============================================================================
// Policy Condition Evaluation
// ============================================================================

/**
 * Get a value from an object by JSON path
 */
function getValueByPath(obj: Record<string, unknown>, path: string): unknown {
  const parts = path.split('.')
  let current: unknown = obj
  
  for (const part of parts) {
    if (current === null || current === undefined) {
      return undefined
    }
    
    // Handle array indices
    const arrayMatch = part.match(/^(\w+)\[(\d+)\]$/)
    if (arrayMatch) {
      const [, key, index] = arrayMatch
      current = (current as Record<string, unknown>)[key]
      if (Array.isArray(current)) {
        current = current[parseInt(index, 10)]
      } else {
        return undefined
      }
    } else {
      current = (current as Record<string, unknown>)[part]
    }
  }
  
  return current
}

/**
 * Evaluate a single condition against context
 */
function evaluateCondition(condition: PolicyCondition, context: Record<string, unknown>): boolean {
  const fieldValue = getValueByPath(context, condition.field)
  
  switch (condition.type) {
    case 'equals':
      return fieldValue === condition.value
    
    case 'notEquals':
      return fieldValue !== condition.value
    
    case 'contains':
      if (typeof fieldValue === 'string' && typeof condition.value === 'string') {
        return fieldValue.includes(condition.value)
      }
      if (Array.isArray(fieldValue)) {
        return fieldValue.includes(condition.value)
      }
      return false
    
    case 'greaterThan':
      if (typeof fieldValue === 'number' && typeof condition.value === 'number') {
        return fieldValue > condition.value
      }
      return false
    
    case 'lessThan':
      if (typeof fieldValue === 'number' && typeof condition.value === 'number') {
        return fieldValue < condition.value
      }
      return false
    
    case 'regex':
      if (typeof fieldValue === 'string' && typeof condition.value === 'string') {
        try {
          const regex = new RegExp(condition.value)
          return regex.test(fieldValue)
        } catch {
          return false
        }
      }
      return false
    
    case 'in':
      if (Array.isArray(condition.value)) {
        return condition.value.includes(fieldValue)
      }
      return false
    
    case 'notIn':
      if (Array.isArray(condition.value)) {
        return !condition.value.includes(fieldValue)
      }
      return true
    
    case 'exists':
      return fieldValue !== undefined && fieldValue !== null
    
    case 'notExists':
      return fieldValue === undefined || fieldValue === null
    
    case 'startsWith':
      if (typeof fieldValue === 'string' && typeof condition.value === 'string') {
        return fieldValue.startsWith(condition.value)
      }
      return false
    
    case 'endsWith':
      if (typeof fieldValue === 'string' && typeof condition.value === 'string') {
        return fieldValue.endsWith(condition.value)
      }
      return false
    
    default:
      return false
  }
}

/**
 * Evaluate all conditions of a policy (AND logic)
 */
function evaluateConditions(conditions: PolicyCondition[], context: Record<string, unknown>): boolean {
  if (conditions.length === 0) return true
  return conditions.every(condition => evaluateCondition(condition, context))
}

/**
 * Check if action matches pattern
 */
function matchesAction(policyActions: string[], requestAction: string): boolean {
  for (const pattern of policyActions) {
    if (pattern === '*') return true
    if (pattern === requestAction) return true
    
    // Handle wildcards like "file:*" or "model:invoke*"
    if (pattern.includes('*')) {
      const regex = new RegExp('^' + pattern.replace(/\*/g, '.*') + '$')
      if (regex.test(requestAction)) return true
    }
  }
  return false
}

/**
 * Check if resource matches pattern
 */
function matchesResource(policyResources: string[], requestResource: string): boolean {
  for (const pattern of policyResources) {
    if (pattern === '*') return true
    if (pattern === requestResource) return true
    
    // Handle wildcards like "s3://bucket/*" or "model:*"
    if (pattern.includes('*')) {
      const regex = new RegExp('^' + pattern.replace(/\*/g, '.*') + '$')
      if (regex.test(requestResource)) return true
    }
  }
  return false
}

// ============================================================================
// Default Policies
// ============================================================================

/**
 * Create the default policy set
 */
function createDefaultPolicies(): Policy[] {
  const now = Date.now()
  
  return [
    // Policy 1: Default Deny All (lowest priority - catch-all)
    {
      id: 'policy-deny-all',
      name: 'Default Deny All',
      version: '1.0.0',
      description: 'Deny-by-default: All actions are denied unless explicitly allowed by another policy',
      effect: 'deny',
      priority: 0,
      conditions: [],
      actions: ['*'],
      resources: ['*'],
      metadata: { type: 'default-deny', system: true },
      createdAt: now,
      updatedAt: now,
      enabled: true
    },
    
    // Policy 2: Rate Limiting (max 100 actions per minute)
    {
      id: 'policy-rate-limit',
      name: 'Rate Limiting Policy',
      version: '1.0.0',
      description: 'Enforces maximum 100 actions per minute per agent to prevent abuse',
      effect: 'deny',
      priority: 100,
      conditions: [
        {
          type: 'greaterThan',
          field: 'rateLimit.count',
          value: 100,
          description: 'Deny if action count exceeds 100 in current window'
        }
      ],
      actions: ['*'],
      resources: ['*'],
      metadata: { 
        type: 'rate-limit', 
        system: true,
        maxRequests: 100,
        windowMs: 60000
      },
      createdAt: now,
      updatedAt: now,
      enabled: true
    },
    
    // Policy 3: Resource Access Control
    {
      id: 'policy-resource-access',
      name: 'Resource Access Control',
      version: '1.0.0',
      description: 'Only allows access to explicitly permitted resources',
      effect: 'deny',
      priority: 200,
      conditions: [
        {
          type: 'notIn',
          field: 'resource',
          value: [
            'public/*',
            'models/approved/*',
            'data/agent-workspace/*',
            'api/v1/standard/*'
          ],
          description: 'Deny access to resources not in allowed list'
        }
      ],
      actions: ['*'],
      resources: ['*'],
      metadata: { type: 'resource-control', system: true },
      createdAt: now,
      updatedAt: now,
      enabled: true
    },
    
    // Policy 4: Time-Based Restrictions (business hours for sensitive operations)
    {
      id: 'policy-time-restrictions',
      name: 'Time-Based Restrictions',
      version: '1.0.0',
      description: 'Restricts sensitive operations to business hours (8 AM - 8 PM UTC)',
      effect: 'deny',
      priority: 300,
      conditions: [
        {
          type: 'in',
          field: 'action',
          value: [
            'admin:delete',
            'admin:modify',
            'security:configure',
            'data:export',
            'model:train'
          ],
          description: 'Only applies to sensitive actions'
        },
        {
          type: 'notIn',
          field: 'hour',
          value: [8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20],
          description: 'Deny if outside business hours (8 AM - 8 PM)'
        }
      ],
      actions: ['*'],
      resources: ['*'],
      metadata: { 
        type: 'time-restriction', 
        system: true,
        businessHours: { start: 8, end: 20, timezone: 'UTC' }
      },
      createdAt: now,
      updatedAt: now,
      enabled: true
    },
    
    // Policy 5: Confidence Threshold
    {
      id: 'policy-confidence-threshold',
      name: 'Confidence Threshold Policy',
      version: '1.0.0',
      description: 'Blocks actions when AI confidence is below threshold to prevent errors',
      effect: 'deny',
      priority: 400,
      conditions: [
        {
          type: 'lessThan',
          field: 'confidence',
          value: 0.7,
          description: 'Deny if confidence is below 70%'
        },
        {
          type: 'exists',
          field: 'confidence',
          description: 'Only apply when confidence is measured'
        }
      ],
      actions: ['decision:*', 'action:execute', 'model:invoke'],
      resources: ['*'],
      metadata: { 
        type: 'confidence-threshold', 
        system: true,
        minConfidence: 0.7
      },
      createdAt: now,
      updatedAt: now,
      enabled: true
    },
    
    // Policy 6: Allow Basic Operations
    {
      id: 'policy-allow-basic',
      name: 'Allow Basic Operations',
      version: '1.0.0',
      description: 'Allows basic read and query operations for all agents',
      effect: 'allow',
      priority: 50,
      conditions: [],
      actions: ['file:read', 'data:query', 'model:list', 'status:check'],
      resources: ['public/*', 'data/agent-workspace/*'],
      metadata: { type: 'basic-operations', system: true },
      createdAt: now,
      updatedAt: now,
      enabled: true
    },
    
    // Policy 7: Sensitive Data Protection
    {
      id: 'policy-sensitive-data',
      name: 'Sensitive Data Protection',
      version: '1.0.0',
      description: 'Prevents exfiltration of sensitive data patterns',
      effect: 'deny',
      priority: 500,
      conditions: [
        {
          type: 'regex',
          field: 'context.output',
          value: '(password|api_key|secret|token)\\s*[=:"]\\s*[\\w-]{10,}',
          description: 'Detect potential secret leakage in output'
        }
      ],
      actions: ['output:generate', 'response:send', 'data:export'],
      resources: ['*'],
      metadata: { type: 'dlp', system: true },
      createdAt: now,
      updatedAt: now,
      enabled: true
    },
    
    // Policy 8: Agent Authentication Required
    {
      id: 'policy-auth-required',
      name: 'Agent Authentication Required',
      version: '1.0.0',
      description: 'Requires all agents to be authenticated for any action',
      effect: 'deny',
      priority: 1000,
      conditions: [
        {
          type: 'notExists',
          field: 'agentAuthenticated',
          description: 'Agent must be authenticated'
        }
      ],
      actions: ['*'],
      resources: ['*'],
      metadata: { type: 'auth-required', system: true },
      createdAt: now,
      updatedAt: now,
      enabled: true
    }
  ]
}

// ============================================================================
// Core Policy Functions
// ============================================================================

/**
 * Create a new policy
 * 
 * @param policyData - Policy data without auto-generated fields
 * @returns The created policy with generated ID and timestamps
 * 
 * @example
 * ```typescript
 * const policy = createPolicy({
 *   name: 'My Custom Policy',
 *   version: '1.0.0',
 *   description: 'A custom policy for specific use case',
 *   effect: 'allow',
 *   priority: 100,
 *   conditions: [{ type: 'equals', field: 'user.role', value: 'admin' }],
 *   actions: ['admin:*'],
 *   resources: ['admin/*'],
 *   metadata: {},
 *   enabled: true
 * })
 * ```
 */
export function createPolicy(policyData: Omit<Policy, 'id' | 'createdAt' | 'updatedAt'>): Policy {
  const now = Date.now()
  const policy: Policy = {
    ...policyData,
    id: `policy-${generateUUID()}`,
    createdAt: now,
    updatedAt: now
  }
  
  policyStore.addPolicy(policy)
  
  // Record version history
  policyStore.updatePolicy(policy.id, {}, 'creator', 'Initial policy creation')
  
  return policy
}

/**
 * Update an existing policy
 * 
 * @param policyId - ID of the policy to update
 * @param updates - Partial policy data to update
 * @param changedBy - Identifier of who made the change
 * @param changeDescription - Description of what changed
 * @returns The updated policy or null if not found
 */
export function updatePolicy(
  policyId: string, 
  updates: Partial<Policy>, 
  changedBy: string = 'system',
  changeDescription: string = 'Policy updated'
): Policy | null {
  // Prevent modification of system policies
  const existing = policyStore.getPolicy(policyId)
  if (existing?.metadata?.system === true) {
    console.warn(`Attempted to modify system policy ${policyId}`)
    return null
  }
  
  return policyStore.updatePolicy(policyId, updates, changedBy, changeDescription)
}

/**
 * Delete a policy
 * 
 * @param policyId - ID of the policy to delete
 * @returns True if deleted, false if not found or is system policy
 */
export function deletePolicy(policyId: string): boolean {
  const policy = policyStore.getPolicy(policyId)
  
  // Prevent deletion of system policies
  if (policy?.metadata?.system === true) {
    console.warn(`Attempted to delete system policy ${policyId}`)
    return false
  }
  
  return policyStore.deletePolicy(policyId)
}

/**
 * List policies with optional filtering
 * 
 * @param filter - Optional filter criteria
 * @returns Array of matching policies
 */
export function listPolicies(filter?: PolicyFilter): Policy[] {
  let policies = policyStore.getAllPolicies()
  
  if (filter) {
    if (filter.action) {
      policies = policies.filter(p => 
        p.actions.some(a => a === filter.action || a === '*' || 
          (a.includes('*') && new RegExp('^' + a.replace(/\*/g, '.*') + '$').test(filter.action!)))
      )
    }
    
    if (filter.resource) {
      policies = policies.filter(p => 
        p.resources.some(r => r === filter.resource || r === '*' ||
          (r.includes('*') && new RegExp('^' + r.replace(/\*/g, '.*') + '$').test(filter.resource!)))
      )
    }
    
    if (filter.effect) {
      policies = policies.filter(p => p.effect === filter.effect)
    }
    
    if (filter.enabled !== undefined) {
      policies = policies.filter(p => p.enabled === filter.enabled)
    }
    
    if (filter.minPriority !== undefined) {
      policies = policies.filter(p => p.priority >= filter.minPriority!)
    }
    
    if (filter.maxPriority !== undefined) {
      policies = policies.filter(p => p.priority <= filter.maxPriority!)
    }
  }
  
  // Sort by priority (highest first)
  return policies.sort((a, b) => b.priority - a.priority)
}

/**
 * Get a specific policy by ID
 * 
 * @param policyId - ID of the policy
 * @returns The policy or undefined if not found
 */
export function getPolicy(policyId: string): Policy | undefined {
  return policyStore.getPolicy(policyId)
}

/**
 * Get version history for a policy
 * 
 * @param policyId - ID of the policy
 * @returns Array of version entries
 */
export function getPolicyVersions(policyId: string): PolicyVersion[] {
  return policyStore.getPolicyVersions(policyId)
}

// ============================================================================
// Policy Evaluation Engine
// ============================================================================

/**
 * Evaluate a policy request and return a decision
 * 
 * Implements deny-by-default security model:
 * 1. Check authentication requirement
 * 2. Evaluate all policies in priority order (highest first)
 * 3. Deny policies override allow policies at same priority
 * 4. If no explicit allow, default to deny
 * 
 * @param request - The policy evaluation request
 * @returns The evaluation result with decision and audit entry
 * 
 * @example
 * ```typescript
 * const result = evaluatePolicy({
 *   agentId: 'agent-123',
 *   action: 'file:read',
 *   resource: 'data/reports/annual.pdf',
 *   context: { confidence: 0.85, agentAuthenticated: true },
 *   timestamp: Date.now()
 * })
 * 
 * if (!result.allowed) {
 *   console.log(`Action denied: ${result.reason}`)
 * }
 * ```
 */
export function evaluatePolicy(request: PolicyEvaluationRequest): PolicyEvaluationResult {
  const startTime = Date.now()
  const decisionId = generateUUID()
  
  // Get all enabled policies sorted by priority
  const policies = listPolicies({ enabled: true })
  
  // Build evaluation context with request data
  const evaluationContext: Record<string, unknown> = {
    ...request.context,
    agentId: request.agentId,
    action: request.action,
    resource: request.resource,
    timestamp: request.timestamp,
    hour: new Date(request.timestamp).getHours(),
    date: new Date(request.timestamp).toISOString().split('T')[0]
  }
  
  // Track matched policies
  const matchedAllowPolicies: string[] = []
  const matchedDenyPolicies: string[] = []
  let deniedByPolicy: string | undefined
  let denyReason: string | undefined
  
  // Check rate limits
  const rateLimitKey = `ratelimit:${request.agentId}`
  const rateLimitResult = policyStore.checkRateLimit(rateLimitKey, 100, 60000)
  evaluationContext.rateLimit = rateLimitResult
  
  // Evaluate each policy
  for (const policy of policies) {
    // Check if policy applies to this action/resource
    const actionMatches = matchesAction(policy.actions, request.action)
    const resourceMatches = matchesResource(policy.resources, request.resource)
    
    if (!actionMatches || !resourceMatches) continue
    
    // Evaluate conditions
    const conditionsMet = evaluateConditions(policy.conditions, evaluationContext)
    
    if (conditionsMet) {
      if (policy.effect === 'allow') {
        matchedAllowPolicies.push(policy.id)
      } else {
        matchedDenyPolicies.push(policy.id)
        // First deny wins (but we continue to log all matching policies)
        if (!deniedByPolicy) {
          deniedByPolicy = policy.id
          denyReason = policy.description
        }
      }
    }
  }
  
  // Determine final decision
  // Deny-by-default: need explicit allow AND no denies
  const hasAllow = matchedAllowPolicies.length > 0
  const hasDeny = matchedDenyPolicies.length > 0
  const allowed = hasAllow && !hasDeny
  
  const allMatchedPolicies = [...matchedDenyPolicies, ...matchedAllowPolicies]
  
  // Generate execution ticket for allowed decisions
  let ticket: string | undefined
  if (allowed) {
    ticket = generateExecutionTicket(decisionId, request)
  }
  
  const evaluationTimeMs = Date.now() - startTime
  
  // Create audit entry
  const auditEntry = policyStore.addAuditEntry({
    timestamp: request.timestamp,
    agentId: request.agentId,
    action: request.action,
    resource: request.resource,
    decision: allowed ? 'allow' : 'deny',
    matchedPolicies: allMatchedPolicies,
    reason: denyReason,
    requestId: request.requestId
  })
  
  return {
    allowed,
    decisionId,
    matchedPolicies: allMatchedPolicies,
    deniedBy: deniedByPolicy,
    reason: denyReason || (hasAllow ? undefined : 'No allow policy matched'),
    ticket,
    auditEntry: {
      request,
      result: allowed ? 'allow' : 'deny',
      evaluatedAt: Date.now(),
      policiesChecked: policies.length,
      evaluationTimeMs
    }
  }
}

/**
 * Generate an execution ticket for a decision
 * This ticket can be used for one-time execution validation
 */
function generateExecutionTicket(decisionId: string, request: PolicyEvaluationRequest): string {
  const payload = JSON.stringify({
    decisionId,
    agentId: request.agentId,
    action: request.action,
    resource: request.resource,
    timestamp: request.timestamp,
    nonce: randomBytesHex(16)
  })
  
  return hmacSha256('kasbah-policy-key', payload)
}

/**
 * Validate an execution ticket
 * 
 * @param decisionId - The decision ID associated with the ticket
 * @param request - The original request
 * @param ticket - The ticket to validate
 * @returns True if the ticket is valid
 */
export function validateExecutionTicket(
  decisionId: string, 
  request: PolicyEvaluationRequest, 
  ticket: string
): boolean {
  // In production, this would check against a store of used tickets
  // to prevent replay attacks
  const expectedTicket = generateExecutionTicket(decisionId, request)
  return ticket === expectedTicket
}

// ============================================================================
// Audit Trail Functions
// ============================================================================

/**
 * Get the policy audit trail
 * 
 * @param agentId - Optional filter by agent ID
 * @param limit - Maximum number of entries to return
 * @returns Array of audit entries
 */
export function getPolicyAuditTrail(agentId?: string, limit?: number): PolicyAuditEntry[] {
  return policyStore.getAuditTrail(agentId, limit)
}

/**
 * Verify the integrity of the audit trail
 * 
 * @returns Integrity check result
 */
export function verifyAuditIntegrity(): { valid: boolean; errors: string[] } {
  return policyStore.verifyAuditIntegrity()
}

/**
 * Export audit trail for external analysis
 * 
 * @param format - Export format ('json' | 'csv')
 * @returns Exported audit data
 */
export function exportAuditTrail(format: 'json' | 'csv' = 'json'): string {
  const entries = policyStore.getAuditTrail()
  const integrity = policyStore.verifyAuditIntegrity()
  
  if (format === 'csv') {
    const headers = ['id', 'timestamp', 'agentId', 'action', 'resource', 'decision', 'reason', 'matchedPolicies']
    const rows = entries.map(e => [
      e.id,
      e.timestamp,
      e.agentId,
      e.action,
      e.resource,
      e.decision,
      e.reason || '',
      e.matchedPolicies.join(';')
    ])
    return [headers.join(','), ...rows.map(r => r.join(','))].join('\n')
  }
  
  return JSON.stringify({
    version: '1.0.0',
    exportedAt: new Date().toISOString(),
    integrity,
    entries
  }, null, 2)
}

// ============================================================================
// Utility Functions
// ============================================================================

/**
 * Get policy engine statistics
 */
export function getPolicyStats(): ReturnType<PolicyStore['getStats']> {
  return policyStore.getStats()
}

/**
 * Clean up expired rate limit entries
 */
export function cleanupRateLimits(): number {
  return policyStore.cleanupRateLimits(60000)
}

/**
 * Check if an action would be allowed without creating audit entry
 * Useful for UI previews or conditional logic
 * 
 * @param request - The request to check
 * @returns Whether the action would be allowed
 */
export function wouldAllow(request: PolicyEvaluationRequest): boolean {
  const result = evaluatePolicy(request)
  return result.allowed
}

/**
 * Batch evaluate multiple requests
 * 
 * @param requests - Array of requests to evaluate
 * @returns Array of evaluation results
 */
export function batchEvaluate(requests: PolicyEvaluationRequest[]): PolicyEvaluationResult[] {
  return requests.map(request => evaluatePolicy(request))
}

/**
 * Get applicable policies for an action/resource combination
 * Useful for documentation and debugging
 * 
 * @param action - The action to check
 * @param resource - The resource to check
 * @returns Policies that would apply to this request
 */
export function getApplicablePolicies(action: string, resource: string): Policy[] {
  return listPolicies().filter(policy => {
    if (!policy.enabled) return false
    const actionMatches = matchesAction(policy.actions, action)
    const resourceMatches = matchesResource(policy.resources, resource)
    return actionMatches && resourceMatches
  })
}

/**
 * Explain why a request would be allowed or denied
 * 
 * @param request - The request to explain
 * @returns Detailed explanation of the decision
 */
export function explainDecision(request: PolicyEvaluationRequest): {
  allowed: boolean
  explanation: string
  matchedPolicies: Array<{ policy: Policy; matched: boolean; reason: string }>
} {
  const result = evaluatePolicy(request)
  const applicablePolicies = getApplicablePolicies(request.action, request.resource)
  
  const policyExplanations = applicablePolicies.map(policy => {
    const context = {
      ...request.context,
      agentId: request.agentId,
      action: request.action,
      resource: request.resource,
      timestamp: request.timestamp,
      hour: new Date(request.timestamp).getHours()
    }
    
    const conditionsMet = evaluateConditions(policy.conditions, context)
    const reason = conditionsMet 
      ? `All ${policy.conditions.length} conditions passed`
      : 'Conditions not met'
    
    return {
      policy,
      matched: result.matchedPolicies.includes(policy.id),
      reason
    }
  })
  
  let explanation = `Request for action "${request.action}" on resource "${request.resource}" was ${result.allowed ? 'ALLOWED' : 'DENIED'}.\n\n`
  
  if (result.deniedBy) {
    const denyPolicy = getPolicy(result.deniedBy)
    explanation += `Denied by policy: ${denyPolicy?.name || result.deniedBy}\n`
    explanation += `Reason: ${result.reason || 'No reason provided'}\n\n`
  }
  
  explanation += `Matched ${result.matchedPolicies.length} policies.\n`
  explanation += `Evaluated ${result.auditEntry.policiesChecked} total policies in ${result.auditEntry.evaluationTimeMs}ms.`
  
  return {
    allowed: result.allowed,
    explanation,
    matchedPolicies: policyExplanations
  }
}

// Export types for external use
export type {
  Policy,
  PolicyCondition,
  PolicyEvaluationRequest,
  PolicyEvaluationResult,
  PolicyAuditEntry,
  PolicyVersion,
  PolicyFilter,
  ConditionType
}
