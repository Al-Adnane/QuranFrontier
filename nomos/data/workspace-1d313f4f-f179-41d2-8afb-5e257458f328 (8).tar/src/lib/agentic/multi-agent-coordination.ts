/**
 * Multi-Agent Coordination Security System
 * Kasbah AI Safety Platform - Moat for Distributed AI Decision Making
 * 
 * This module provides secure agent-to-agent communication protocols,
 * consensus mechanisms for distributed AI decisions, rogue agent detection,
 * and cross-agent trust scoring.
 * 
 * Key Features:
 * - Secure agent-to-agent communication with HMAC signatures
 * - Consensus mechanisms with configurable thresholds
 * - Rogue agent detection with behavioral analysis
 * - Agent group formation and management
 * - Cross-agent trust scoring with reputation decay
 * - Heartbeat monitoring for agent health
 */

import { generateUUID, randomBytesHex, sha256Sync, hmacSha256 } from '@/lib/crypto-utils'
import { createLogger } from '@/lib/logger'

// Initialize logger for this module
const logger = createLogger('security')

// ============================================================================
// Type Definitions
// ============================================================================

/**
 * Represents an individual agent node in the network
 */
export interface AgentNode {
  /** Unique identifier for the agent */
  id: string
  /** Human-readable name for the agent */
  name: string
  /** Public key for verifying agent signatures */
  publicKey: string
  /** Optional endpoint URL for remote agents */
  endpoint?: string
  /** Current status of the agent */
  status: 'active' | 'inactive' | 'quarantined' | 'suspended'
  /** Trust score from 0-100, starts at 50 */
  trustScore: number
  /** Timestamp of last heartbeat in milliseconds */
  lastHeartbeat: number
  /** List of capabilities this agent possesses */
  capabilities: string[]
  /** ID of the group this agent belongs to, if any */
  groupId?: string
  /** Timestamp when agent was registered */
  registeredAt: number
  /** Number of times this agent has been quarantined */
  quarantineCount: number
  /** Reason for current quarantine/suspension if applicable */
  statusReason?: string
}

/**
 * Represents a group of agents working together
 */
export interface AgentGroup {
  /** Unique identifier for the group */
  id: string
  /** Human-readable name for the group */
  name: string
  /** Purpose or description of the group's function */
  purpose: string
  /** Array of agent IDs that are members of this group */
  members: string[]
  /** Percentage of votes needed for consensus (0-100) */
  consensusThreshold: number
  /** Timestamp when group was created */
  createdAt: number
  /** Current status of the group */
  status: 'active' | 'inactive'
  /** Leader agent ID for tie-breaking */
  leaderId?: string
  /** Minimum trust score required for membership */
  minTrustScore: number
}

/**
 * Represents a proposal requiring consensus from group members
 */
export interface ConsensusProposal {
  /** Unique identifier for the proposal */
  id: string
  /** ID of the group this proposal belongs to */
  groupId: string
  /** ID of the agent that proposed this action */
  proposerId: string
  /** Type of action being proposed */
  action: string
  /** Payload data for the action */
  payload: Record<string, unknown>
  /** Map of agent IDs to their votes */
  votes: Map<string, 'approve' | 'reject' | 'abstain'>
  /** Current status of the proposal */
  status: 'pending' | 'approved' | 'rejected' | 'expired'
  /** Timestamp when proposal was created */
  createdAt: number
  /** Timestamp when proposal expires */
  expiresAt: number
  /** Weighted vote totals */
  weightedVotes?: {
    approve: number
    reject: number
    abstain: number
    totalWeight: number
  }
}

/**
 * Represents a message sent between agents
 */
export interface AgentMessage {
  /** Unique identifier for the message */
  id: string
  /** ID of the sending agent */
  fromAgentId: string
  /** ID of the receiving agent or 'broadcast' for all */
  toAgentId: string | 'broadcast'
  /** Type of message */
  type: 'request' | 'response' | 'notification' | 'heartbeat'
  /** Message payload data */
  payload: Record<string, unknown>
  /** HMAC signature for message authentication */
  signature: string
  /** Timestamp when message was sent */
  timestamp: number
  /** Message sequence number for ordering */
  sequenceNumber: number
  /** ID of message this is responding to, if applicable */
  replyTo?: string
  /** Priority level of the message */
  priority: 'low' | 'normal' | 'high' | 'critical'
}

/**
 * Represents detection of a rogue agent
 */
export interface RogueAgentDetection {
  /** Unique identifier for the detection event */
  id: string
  /** ID of the detected rogue agent */
  agentId: string
  /** Timestamp when rogue behavior was detected */
  detectedAt: number
  /** List of behavioral indicators that triggered detection */
  indicators: string[]
  /** Severity level of the detection */
  severity: 'low' | 'medium' | 'high' | 'critical'
  /** Action taken or recommended */
  action: 'warn' | 'quarantine' | 'suspend'
  /** Whether the detection has been resolved */
  resolved: boolean
  /** Additional evidence or context */
  evidence?: Record<string, unknown>
  /** Agent trust score at time of detection */
  trustScoreAtDetection: number
}

/**
 * Trust score adjustment record
 */
export interface TrustAdjustment {
  id: string
  agentId: string
  adjustment: number
  reason: string
  timestamp: number
  previousScore: number
  newScore: number
  sourceAgentId?: string
}

// ============================================================================
// Constants and Configuration
// ============================================================================

/** Default time-to-live for consensus proposals in milliseconds */
const DEFAULT_PROPOSAL_TTL_MS = 300000 // 5 minutes

/** Heartbeat timeout in milliseconds before agent is considered inactive */
const HEARTBEAT_TIMEOUT_MS = 60000 // 1 minute

/** Minimum trust score required for voting rights */
const MIN_VOTING_TRUST_SCORE = 30

/** Trust score decay rate per hour of inactivity */
const TRUST_DECAY_RATE = 0.5

/** Trust score recovery rate per successful action */
const TRUST_RECOVERY_RATE = 1

/** Maximum trust score */
const MAX_TRUST_SCORE = 100

/** Minimum trust score */
const MIN_TRUST_SCORE = 0

/** Initial trust score for new agents */
const INITIAL_TRUST_SCORE = 50

/** Maximum number of messages to keep in history per agent */
const MAX_MESSAGE_HISTORY = 1000

/** Secret key for HMAC signing (in production, this would be from secure storage) */
const SYSTEM_SECRET_KEY = randomBytesHex(64)

// ============================================================================
// In-Memory Storage
// ============================================================================

/** Map of agent IDs to agent nodes */
const agents = new Map<string, AgentNode>()

/** Map of group IDs to agent groups */
const groups = new Map<string, AgentGroup>()

/** Map of proposal IDs to consensus proposals */
const proposals = new Map<string, ConsensusProposal>()

/** Map of agent IDs to their message queues */
const messageQueues = new Map<string, AgentMessage[]>()

/** Map of detection IDs to rogue agent detections */
const rogueDetections = new Map<string, RogueAgentDetection>()

/** List of trust adjustment records */
const trustAdjustments: TrustAdjustment[] = []

/** Message sequence counter */
let messageSequenceCounter = 0

/** Track behavioral statistics for each agent */
const agentBehaviorStats = new Map<string, {
  messagesSent: number
  messagesReceived: number
  proposalsInitiated: number
  votesParticipated: number
  consensusAgreements: number
  consensusDisagreements: number
  failedHeartbeats: number
  suspiciousActivities: number
  lastSuspiciousActivity?: number
}>()

// ============================================================================
// Agent Node Management
// ============================================================================

/**
 * Register a new agent node in the network
 * 
 * @param agent - Agent details without system-managed fields
 * @returns The newly created agent node with system-assigned fields
 * 
 * @example
 * ```typescript
 * const agent = registerAgentNode({
 *   name: 'Detection-Agent-01',
 *   publicKey: '-----BEGIN PUBLIC KEY-----...',
 *   endpoint: 'https://agent.example.com',
 *   capabilities: ['deepfake-detection', 'audio-analysis']
 * });
 * ```
 */
export function registerAgentNode(
  agent: Omit<AgentNode, 'id' | 'status' | 'trustScore' | 'lastHeartbeat' | 'registeredAt' | 'quarantineCount'>
): AgentNode {
  const id = generateUUID()
  const now = Date.now()
  
  const newAgent: AgentNode = {
    ...agent,
    id,
    status: 'active',
    trustScore: INITIAL_TRUST_SCORE,
    lastHeartbeat: now,
    registeredAt: now,
    quarantineCount: 0
  }
  
  agents.set(id, newAgent)
  
  // Initialize message queue
  messageQueues.set(id, [])
  
  // Initialize behavior stats
  agentBehaviorStats.set(id, {
    messagesSent: 0,
    messagesReceived: 0,
    proposalsInitiated: 0,
    votesParticipated: 0,
    consensusAgreements: 0,
    consensusDisagreements: 0,
    failedHeartbeats: 0,
    suspiciousActivities: 0
  })
  
  logger.info('Agent registered', { 
    agentId: id, 
    name: agent.name,
    capabilities: agent.capabilities 
  })
  
  return newAgent
}

/**
 * Get an agent by ID
 * 
 * @param agentId - The agent's unique identifier
 * @returns The agent node or undefined if not found
 */
export function getAgent(agentId: string): AgentNode | undefined {
  return agents.get(agentId)
}

/**
 * Get all agents, optionally filtered by status
 * 
 * @param status - Optional status filter
 * @returns Array of matching agent nodes
 */
export function getAgents(status?: AgentNode['status']): AgentNode[] {
  const allAgents = Array.from(agents.values())
  if (status) {
    return allAgents.filter(agent => agent.status === status)
  }
  return allAgents
}

/**
 * Update an agent's capabilities
 * 
 * @param agentId - The agent's unique identifier
 * @param capabilities - New list of capabilities
 * @returns Updated agent or undefined if not found
 */
export function updateAgentCapabilities(
  agentId: string,
  capabilities: string[]
): AgentNode | undefined {
  const agent = agents.get(agentId)
  if (!agent) return undefined
  
  agent.capabilities = capabilities
  agents.set(agentId, agent)
  
  logger.info('Agent capabilities updated', { agentId, capabilities })
  return agent
}

/**
 * Remove an agent from the network
 * 
 * @param agentId - The agent's unique identifier
 * @returns True if agent was removed, false if not found
 */
export function removeAgent(agentId: string): boolean {
  const agent = agents.get(agentId)
  if (!agent) return false
  
  // Remove from group if member
  if (agent.groupId) {
    const group = groups.get(agent.groupId)
    if (group) {
      group.members = group.members.filter(id => id !== agentId)
      if (group.members.length === 0) {
        group.status = 'inactive'
      }
    }
  }
  
  agents.delete(agentId)
  messageQueues.delete(agentId)
  agentBehaviorStats.delete(agentId)
  
  logger.info('Agent removed', { agentId })
  return true
}

// ============================================================================
// Heartbeat System
// ============================================================================

/**
 * Record a heartbeat from an agent
 * Updates the agent's lastHeartbeat timestamp and confirms active status
 * 
 * @param agentId - The agent's unique identifier
 * @throws Error if agent not found
 */
export function heartbeat(agentId: string): void {
  const agent = agents.get(agentId)
  if (!agent) {
    throw new Error(`Agent not found: ${agentId}`)
  }
  
  const now = Date.now()
  agent.lastHeartbeat = now
  
  // Reactivate if was inactive
  if (agent.status === 'inactive') {
    agent.status = 'active'
    logger.info('Agent reactivated via heartbeat', { agentId })
  }
  
  agents.set(agentId, agent)
  
  // Small trust boost for consistent heartbeat
  adjustTrustScore(agentId, 0.1, 'Consistent heartbeat')
}

/**
 * Check for agents that have missed heartbeats
 * Updates their status to inactive if timeout exceeded
 * 
 * @returns Array of agents that were marked as inactive
 */
export function checkHeartbeatTimeouts(): AgentNode[] {
  const now = Date.now()
  const inactiveAgents: AgentNode[] = []
  
  for (const agent of agents.values()) {
    if (agent.status === 'active' && (now - agent.lastHeartbeat) > HEARTBEAT_TIMEOUT_MS) {
      agent.status = 'inactive'
      agents.set(agent.id, agent)
      inactiveAgents.push(agent)
      
      // Track failed heartbeat
      const stats = agentBehaviorStats.get(agent.id)
      if (stats) {
        stats.failedHeartbeats++
      }
      
      // Reduce trust score
      adjustTrustScore(agent.id, -5, 'Missed heartbeat timeout')
      
      logger.warn('Agent marked inactive due to missed heartbeat', { 
        agentId: agent.id,
        lastHeartbeat: agent.lastHeartbeat,
        elapsed: now - agent.lastHeartbeat
      })
    }
  }
  
  return inactiveAgents
}

// ============================================================================
// Agent Group Management
// ============================================================================

/**
 * Create a new agent group for coordinated decision making
 * 
 * @param name - Human-readable name for the group
 * @param purpose - Description of the group's function
 * @param members - Array of agent IDs to include in the group
 * @param consensusThreshold - Percentage of votes needed for consensus (0-100)
 * @returns The newly created agent group
 * @throws Error if any member agent doesn't exist
 * 
 * @example
 * ```typescript
 * const group = createGroup(
 *   'Detection-Committee',
 *   'Multi-agent deepfake detection consensus',
 *   ['agent-1-id', 'agent-2-id', 'agent-3-id'],
 *   67 // 67% consensus required
 * );
 * ```
 */
export function createGroup(
  name: string,
  purpose: string,
  members: string[],
  consensusThreshold: number = 51
): AgentGroup {
  // Validate members exist
  for (const memberId of members) {
    if (!agents.has(memberId)) {
      throw new Error(`Agent not found: ${memberId}`)
    }
  }
  
  const id = generateUUID()
  
  const group: AgentGroup = {
    id,
    name,
    purpose,
    members: [...members],
    consensusThreshold: Math.min(100, Math.max(0, consensusThreshold)),
    createdAt: Date.now(),
    status: 'active',
    minTrustScore: MIN_VOTING_TRUST_SCORE
  }
  
  groups.set(id, group)
  
  // Update agent group membership
  for (const memberId of members) {
    const agent = agents.get(memberId)
    if (agent) {
      agent.groupId = id
      agents.set(memberId, agent)
    }
  }
  
  logger.info('Agent group created', { 
    groupId: id, 
    name, 
    memberCount: members.length,
    consensusThreshold 
  })
  
  return group
}

/**
 * Get a group by ID
 * 
 * @param groupId - The group's unique identifier
 * @returns The agent group or undefined if not found
 */
export function getGroup(groupId: string): AgentGroup | undefined {
  return groups.get(groupId)
}

/**
 * Get all groups, optionally filtered by status
 * 
 * @param status - Optional status filter
 * @returns Array of matching groups
 */
export function getGroups(status?: AgentGroup['status']): AgentGroup[] {
  const allGroups = Array.from(groups.values())
  if (status) {
    return allGroups.filter(group => group.status === status)
  }
  return allGroups
}

/**
 * Add an agent to a group
 * 
 * @param groupId - The group's unique identifier
 * @param agentId - The agent's unique identifier
 * @returns Updated group or undefined if not found
 */
export function addAgentToGroup(groupId: string, agentId: string): AgentGroup | undefined {
  const group = groups.get(groupId)
  const agent = agents.get(agentId)
  
  if (!group || !agent) return undefined
  
  if (!group.members.includes(agentId)) {
    group.members.push(agentId)
    agent.groupId = groupId
    agents.set(agentId, agent)
    groups.set(groupId, group)
    
    logger.info('Agent added to group', { groupId, agentId })
  }
  
  return group
}

/**
 * Remove an agent from a group
 * 
 * @param groupId - The group's unique identifier
 * @param agentId - The agent's unique identifier
 * @returns Updated group or undefined if not found
 */
export function removeAgentFromGroup(groupId: string, agentId: string): AgentGroup | undefined {
  const group = groups.get(groupId)
  const agent = agents.get(agentId)
  
  if (!group) return undefined
  
  group.members = group.members.filter(id => id !== agentId)
  
  if (agent) {
    agent.groupId = undefined
    agents.set(agentId, agent)
  }
  
  if (group.members.length === 0) {
    group.status = 'inactive'
  }
  
  groups.set(groupId, group)
  
  logger.info('Agent removed from group', { groupId, agentId })
  return group
}

/**
 * Set the leader of a group (for tie-breaking)
 * 
 * @param groupId - The group's unique identifier
 * @param leaderId - The agent ID to set as leader
 * @returns Updated group or undefined if not found
 */
export function setGroupLeader(groupId: string, leaderId: string): AgentGroup | undefined {
  const group = groups.get(groupId)
  if (!group || !group.members.includes(leaderId)) return undefined
  
  group.leaderId = leaderId
  groups.set(groupId, group)
  
  logger.info('Group leader set', { groupId, leaderId })
  return group
}

/**
 * Update a group's consensus threshold
 * 
 * @param groupId - The group's unique identifier
 * @param threshold - New consensus threshold (0-100)
 * @returns Updated group or undefined if not found
 */
export function updateConsensusThreshold(
  groupId: string,
  threshold: number
): AgentGroup | undefined {
  const group = groups.get(groupId)
  if (!group) return undefined
  
  group.consensusThreshold = Math.min(100, Math.max(0, threshold))
  groups.set(groupId, group)
  
  logger.info('Consensus threshold updated', { groupId, threshold })
  return group
}

// ============================================================================
// Consensus Mechanism
// ============================================================================

/**
 * Propose a new action for group consensus
 * 
 * @param groupId - The group's unique identifier
 * @param proposerId - The proposing agent's ID
 * @param action - Type of action being proposed
 * @param payload - Data for the action
 * @param ttlMs - Time-to-live in milliseconds (default 5 minutes)
 * @returns The newly created proposal
 * @throws Error if group or proposer not found
 * 
 * @example
 * ```typescript
 * const proposal = proposeConsensus(
 *   'group-id',
 *   'agent-id',
 *   'BLOCK_CONTENT',
 *   { contentId: 'abc123', reason: 'Detected deepfake' }
 * );
 * ```
 */
export function proposeConsensus(
  groupId: string,
  proposerId: string,
  action: string,
  payload: Record<string, unknown>,
  ttlMs: number = DEFAULT_PROPOSAL_TTL_MS
): ConsensusProposal {
  const group = groups.get(groupId)
  const proposer = agents.get(proposerId)
  
  if (!group) {
    throw new Error(`Group not found: ${groupId}`)
  }
  
  if (!proposer) {
    throw new Error(`Proposer agent not found: ${proposerId}`)
  }
  
  if (!group.members.includes(proposerId)) {
    throw new Error(`Proposer is not a member of the group`)
  }
  
  if (proposer.trustScore < MIN_VOTING_TRUST_SCORE) {
    throw new Error(`Proposer trust score too low for proposing`)
  }
  
  const id = generateUUID()
  const now = Date.now()
  
  const proposal: ConsensusProposal = {
    id,
    groupId,
    proposerId,
    action,
    payload: sanitizePayload(payload),
    votes: new Map(),
    status: 'pending',
    createdAt: now,
    expiresAt: now + ttlMs
  }
  
  proposals.set(id, proposal)
  
  // Track proposal initiation
  const stats = agentBehaviorStats.get(proposerId)
  if (stats) {
    stats.proposalsInitiated++
  }
  
  logger.info('Consensus proposal created', { 
    proposalId: id, 
    groupId, 
    proposerId, 
    action 
  })
  
  return proposal
}

/**
 * Cast a vote on a proposal
 * 
 * @param proposalId - The proposal's unique identifier
 * @param agentId - The voting agent's ID
 * @param vote - The vote to cast
 * @returns Updated proposal
 * @throws Error if proposal not found, expired, or agent not eligible
 */
export function vote(
  proposalId: string,
  agentId: string,
  vote: 'approve' | 'reject' | 'abstain'
): ConsensusProposal {
  const proposal = proposals.get(proposalId)
  const agent = agents.get(agentId)
  
  if (!proposal) {
    throw new Error(`Proposal not found: ${proposalId}`)
  }
  
  if (!agent) {
    throw new Error(`Agent not found: ${agentId}`)
  }
  
  // Check if proposal is still pending
  if (proposal.status !== 'pending') {
    throw new Error(`Proposal is no longer pending: ${proposal.status}`)
  }
  
  // Check if expired
  if (Date.now() > proposal.expiresAt) {
    proposal.status = 'expired'
    proposals.set(proposalId, proposal)
    throw new Error(`Proposal has expired`)
  }
  
  // Check if agent is group member
  const group = groups.get(proposal.groupId)
  if (!group || !group.members.includes(agentId)) {
    throw new Error(`Agent is not a member of the proposal's group`)
  }
  
  // Check trust score
  if (agent.trustScore < MIN_VOTING_TRUST_SCORE) {
    throw new Error(`Agent trust score too low for voting`)
  }
  
  // Record vote
  proposal.votes.set(agentId, vote)
  
  // Track vote participation
  const stats = agentBehaviorStats.get(agentId)
  if (stats) {
    stats.votesParticipated++
  }
  
  // Calculate weighted votes
  proposal.weightedVotes = calculateWeightedVotes(proposal, group)
  
  // Check if consensus reached
  checkConsensus(proposal, group)
  
  proposals.set(proposalId, proposal)
  
  logger.info('Vote cast', { 
    proposalId, 
    agentId, 
    vote,
    currentApproval: proposal.weightedVotes?.approve,
    threshold: group.consensusThreshold
  })
  
  return proposal
}

/**
 * Calculate weighted votes based on trust scores
 */
function calculateWeightedVotes(
  proposal: ConsensusProposal,
  group: AgentGroup
): { approve: number; reject: number; abstain: number; totalWeight: number } {
  let approve = 0
  let reject = 0
  let abstain = 0
  let totalWeight = 0
  
  for (const [agentId, vote] of proposal.votes) {
    const agent = agents.get(agentId)
    if (agent && group.members.includes(agentId)) {
      const weight = agent.trustScore / 100
      totalWeight += weight
      
      if (vote === 'approve') {
        approve += weight
      } else if (vote === 'reject') {
        reject += weight
      } else {
        abstain += weight
      }
    }
  }
  
  return { approve, reject, abstain, totalWeight }
}

/**
 * Check if consensus has been reached on a proposal
 */
function checkConsensus(proposal: ConsensusProposal, group: AgentGroup): void {
  if (!proposal.weightedVotes) return
  
  const { approve, reject, totalWeight } = proposal.weightedVotes
  const maxPossibleWeight = group.members.reduce((sum, memberId) => {
    const agent = agents.get(memberId)
    return sum + (agent ? agent.trustScore / 100 : 0)
  }, 0)
  
  // Calculate percentage of approval
  const approvalPercentage = (approve / maxPossibleWeight) * 100
  const rejectionPercentage = (reject / maxPossibleWeight) * 100
  
  if (approvalPercentage >= group.consensusThreshold) {
    proposal.status = 'approved'
    
    // Trust boost for proposer
    adjustTrustScore(proposal.proposerId, TRUST_RECOVERY_RATE, 'Successful proposal')
    
    // Update stats for voters
    for (const [agentId, agentVote] of proposal.votes) {
      const stats = agentBehaviorStats.get(agentId)
      if (stats) {
        if (agentVote === 'approve') {
          stats.consensusAgreements++
        } else {
          stats.consensusDisagreements++
        }
      }
    }
    
    logger.info('Proposal approved via consensus', { 
      proposalId: proposal.id,
      approvalPercentage: approvalPercentage.toFixed(2)
    })
  } else if (rejectionPercentage > (100 - group.consensusThreshold)) {
    proposal.status = 'rejected'
    
    logger.info('Proposal rejected via consensus', { 
      proposalId: proposal.id,
      rejectionPercentage: rejectionPercentage.toFixed(2)
    })
  }
}

/**
 * Get a proposal by ID
 * 
 * @param proposalId - The proposal's unique identifier
 * @returns The proposal or undefined if not found
 */
export function getProposal(proposalId: string): ConsensusProposal | undefined {
  return proposals.get(proposalId)
}

/**
 * Get all proposals for a group
 * 
 * @param groupId - The group's unique identifier
 * @param status - Optional status filter
 * @returns Array of matching proposals
 */
export function getGroupProposals(
  groupId: string,
  status?: ConsensusProposal['status']
): ConsensusProposal[] {
  const groupProposals = Array.from(proposals.values())
    .filter(p => p.groupId === groupId)
  
  if (status) {
    return groupProposals.filter(p => p.status === status)
  }
  return groupProposals
}

/**
 * Expire old proposals
 * 
 * @returns Number of proposals expired
 */
export function expireOldProposals(): number {
  const now = Date.now()
  let expired = 0
  
  for (const proposal of proposals.values()) {
    if (proposal.status === 'pending' && now > proposal.expiresAt) {
      proposal.status = 'expired'
      proposals.set(proposal.id, proposal)
      expired++
      
      logger.info('Proposal expired', { proposalId: proposal.id })
    }
  }
  
  return expired
}

// ============================================================================
// Secure Agent Communication
// ============================================================================

/**
 * Send a message from one agent to another (or broadcast)
 * 
 * @param message - Message details without system-managed fields
 * @returns The created message with signature and timestamp
 * @throws Error if sender agent not found
 * 
 * @example
 * ```typescript
 * const message = sendMessage({
 *   fromAgentId: 'agent-1-id',
 *   toAgentId: 'agent-2-id',
 *   type: 'request',
 *   payload: { requestType: 'analysis', contentId: 'abc123' },
 *   priority: 'normal'
 * });
 * ```
 */
export function sendMessage(
  message: Omit<AgentMessage, 'id' | 'signature' | 'timestamp' | 'sequenceNumber'>
): AgentMessage {
  const sender = agents.get(message.fromAgentId)
  if (!sender) {
    throw new Error(`Sender agent not found: ${message.fromAgentId}`)
  }
  
  // Check if sender is quarantined or suspended
  if (sender.status === 'quarantined' || sender.status === 'suspended') {
    throw new Error(`Sender agent is ${sender.status} and cannot send messages`)
  }
  
  const id = generateUUID()
  const timestamp = Date.now()
  const sequenceNumber = ++messageSequenceCounter
  
  const fullMessage: AgentMessage = {
    ...message,
    id,
    timestamp,
    sequenceNumber,
    signature: '' // Will be set after signing
  }
  
  // Sign the message
  fullMessage.signature = signMessage(fullMessage, sender.publicKey)
  
  // Track message sent
  const stats = agentBehaviorStats.get(message.fromAgentId)
  if (stats) {
    stats.messagesSent++
  }
  
  // Deliver message
  if (message.toAgentId === 'broadcast') {
    // Broadcast to all active agents
    for (const agent of agents.values()) {
      if (agent.id !== message.fromAgentId && agent.status === 'active') {
        const queue = messageQueues.get(agent.id) || []
        queue.push(fullMessage)
        
        // Trim queue if too large
        if (queue.length > MAX_MESSAGE_HISTORY) {
          queue.shift()
        }
        
        messageQueues.set(agent.id, queue)
        
        // Track message received
        const receiverStats = agentBehaviorStats.get(agent.id)
        if (receiverStats) {
          receiverStats.messagesReceived++
        }
      }
    }
  } else {
    // Direct message
    const queue = messageQueues.get(message.toAgentId) || []
    queue.push(fullMessage)
    
    if (queue.length > MAX_MESSAGE_HISTORY) {
      queue.shift()
    }
    
    messageQueues.set(message.toAgentId, queue)
    
    // Track message received
    const receiverStats = agentBehaviorStats.get(message.toAgentId)
    if (receiverStats) {
      receiverStats.messagesReceived++
    }
  }
  
  logger.debug('Message sent', { 
    messageId: id, 
    from: message.fromAgentId, 
    to: message.toAgentId,
    type: message.type 
  })
  
  return fullMessage
}

/**
 * Sign a message using HMAC-SHA256
 */
function signMessage(message: Omit<AgentMessage, 'signature'>, publicKey: string): string {
  const content = [
    message.id,
    message.fromAgentId,
    message.toAgentId,
    message.type,
    JSON.stringify(message.payload, Object.keys(message.payload).sort()),
    message.timestamp.toString(),
    message.sequenceNumber.toString()
  ].join('|')
  
  // Combine system secret with public key for signing
  const signingKey = SYSTEM_SECRET_KEY + publicKey
  return hmacSha256(signingKey, content)
}

/**
 * Verify a message signature
 * 
 * @param message - The message to verify
 * @returns Whether the signature is valid
 */
export function verifyMessage(message: AgentMessage): boolean {
  const sender = agents.get(message.fromAgentId)
  if (!sender) return false
  
  const content = [
    message.id,
    message.fromAgentId,
    message.toAgentId,
    message.type,
    JSON.stringify(message.payload, Object.keys(message.payload).sort()),
    message.timestamp.toString(),
    message.sequenceNumber.toString()
  ].join('|')
  
  const signingKey = SYSTEM_SECRET_KEY + sender.publicKey
  const expectedSignature = hmacSha256(signingKey, content)
  
  return message.signature === expectedSignature
}

/**
 * Get pending messages for an agent
 * 
 * @param agentId - The agent's unique identifier
 * @param limit - Maximum number of messages to return
 * @returns Array of pending messages
 */
export function getPendingMessages(agentId: string, limit: number = 100): AgentMessage[] {
  const queue = messageQueues.get(agentId) || []
  return queue.slice(-limit)
}

/**
 * Clear messages for an agent
 * 
 * @param agentId - The agent's unique identifier
 * @param beforeTimestamp - Optional timestamp to clear messages before
 */
export function clearMessages(agentId: string, beforeTimestamp?: number): void {
  if (beforeTimestamp) {
    const queue = messageQueues.get(agentId) || []
    const filtered = queue.filter(m => m.timestamp >= beforeTimestamp)
    messageQueues.set(agentId, filtered)
  } else {
    messageQueues.set(agentId, [])
  }
}

// ============================================================================
// Rogue Agent Detection
// ============================================================================

/**
 * Detect rogue agents based on behavioral analysis
 * Checks for suspicious patterns and trust score thresholds
 * 
 * @returns Array of new rogue agent detections
 */
export function detectRogueAgents(): RogueAgentDetection[] {
  const detections: RogueAgentDetection[] = []
  const now = Date.now()
  
  for (const agent of agents.values()) {
    // Skip already quarantined/suspended agents
    if (agent.status === 'quarantined' || agent.status === 'suspended') continue
    
    const stats = agentBehaviorStats.get(agent.id)
    if (!stats) continue
    
    const indicators: string[] = []
    let severity: RogueAgentDetection['severity'] = 'low'
    
    // Check for suspicious activity patterns
    
    // 1. High disagreement rate
    if (stats.consensusAgreements + stats.consensusDisagreements > 10) {
      const disagreementRate = stats.consensusDisagreements / 
        (stats.consensusAgreements + stats.consensusDisagreements)
      if (disagreementRate > 0.8) {
        indicators.push(`Extremely high consensus disagreement rate: ${(disagreementRate * 100).toFixed(1)}%`)
        severity = 'high'
      } else if (disagreementRate > 0.6) {
        indicators.push(`High consensus disagreement rate: ${(disagreementRate * 100).toFixed(1)}%`)
        severity = severity === 'high' ? 'high' : 'medium'
      }
    }
    
    // 2. Excessive message rate (potential spam/DoS)
    const messageRate = stats.messagesSent / Math.max(1, (now - agent.registeredAt) / 60000)
    if (messageRate > 100) {
      indicators.push(`Excessive message rate: ${messageRate.toFixed(1)} messages/min`)
      severity = 'critical'
    } else if (messageRate > 50) {
      indicators.push(`High message rate: ${messageRate.toFixed(1)} messages/min`)
      severity = severity === 'critical' ? 'critical' : 'high'
    }
    
    // 3. Low trust score
    if (agent.trustScore < 20) {
      indicators.push(`Critical trust score: ${agent.trustScore}`)
      severity = 'critical'
    } else if (agent.trustScore < 30) {
      indicators.push(`Low trust score: ${agent.trustScore}`)
      severity = severity === 'critical' ? 'critical' : 'high'
    }
    
    // 4. Multiple failed heartbeats
    if (stats.failedHeartbeats > 5) {
      indicators.push(`Multiple failed heartbeats: ${stats.failedHeartbeats}`)
      severity = severity === 'critical' ? 'critical' : 'high'
    }
    
    // 5. Repeated suspicious activities
    if (stats.suspiciousActivities > 3) {
      indicators.push(`Multiple suspicious activity flags: ${stats.suspiciousActivities}`)
      severity = severity === 'critical' ? 'critical' : 'high'
    }
    
    // 6. High proposal rejection rate
    if (stats.proposalsInitiated > 5) {
      const proposals = Array.from(proposals.values())
        .filter(p => p.proposerId === agent.id)
      const rejectedProposals = proposals.filter(p => p.status === 'rejected').length
      if (rejectedProposals > proposals.length * 0.7) {
        indicators.push(`High proposal rejection rate: ${rejectedProposals}/${proposals.length}`)
        severity = severity === 'critical' ? 'critical' : 'medium'
      }
    }
    
    // 7. Pattern of voting against consensus
    if (stats.consensusDisagreements > stats.consensusAgreements * 2 && 
        stats.consensusAgreements + stats.consensusDisagreements > 10) {
      indicators.push('Consistently voting against established consensus')
      severity = severity === 'critical' ? 'critical' : 'medium'
    }
    
    // If indicators found, create detection
    if (indicators.length > 0) {
      const detection = createRogueDetection(agent, indicators, severity, now)
      detections.push(detection)
      
      // Update stats
      stats.suspiciousActivities++
      stats.lastSuspiciousActivity = now
    }
  }
  
  return detections
}

/**
 * Create a rogue agent detection record
 */
function createRogueDetection(
  agent: AgentNode,
  indicators: string[],
  severity: RogueAgentDetection['severity'],
  now: number
): RogueAgentDetection {
  const id = generateUUID()
  
  // Determine action based on severity
  let action: RogueAgentDetection['action']
  if (severity === 'critical') {
    action = 'suspend'
  } else if (severity === 'high') {
    action = 'quarantine'
  } else {
    action = 'warn'
  }
  
  const detection: RogueAgentDetection = {
    id,
    agentId: agent.id,
    detectedAt: now,
    indicators,
    severity,
    action,
    resolved: false,
    trustScoreAtDetection: agent.trustScore
  }
  
  rogueDetections.set(id, detection)
  
  // Take action
  if (action === 'quarantine') {
    quarantineAgent(agent.id, `Rogue agent detection: ${indicators.join('; ')}`)
  } else if (action === 'suspend') {
    suspendAgent(agent.id, `Critical rogue agent detection: ${indicators.join('; ')}`)
  }
  
  logger.warn('Rogue agent detected', { 
    detectionId: id,
    agentId: agent.id, 
    severity, 
    action,
    indicators 
  })
  
  return detection
}

/**
 * Quarantine an agent, restricting its capabilities
 * 
 * @param agentId - The agent's unique identifier
 * @param reason - Reason for quarantine
 * @throws Error if agent not found
 */
export function quarantineAgent(agentId: string, reason: string): void {
  const agent = agents.get(agentId)
  if (!agent) {
    throw new Error(`Agent not found: ${agentId}`)
  }
  
  agent.status = 'quarantined'
  agent.statusReason = reason
  agent.quarantineCount++
  agents.set(agentId, agent)
  
  // Remove from group temporarily
  if (agent.groupId) {
    const group = groups.get(agent.groupId)
    if (group) {
      group.members = group.members.filter(id => id !== agentId)
      groups.set(group.id, group)
    }
  }
  
  // Major trust penalty
  adjustTrustScore(agentId, -20, `Quarantined: ${reason}`)
  
  logger.warn('Agent quarantined', { agentId, reason })
}

/**
 * Suspend an agent, completely disabling it
 * 
 * @param agentId - The agent's unique identifier
 * @param reason - Reason for suspension
 * @throws Error if agent not found
 */
export function suspendAgent(agentId: string, reason: string): void {
  const agent = agents.get(agentId)
  if (!agent) {
    throw new Error(`Agent not found: ${agentId}`)
  }
  
  agent.status = 'suspended'
  agent.statusReason = reason
  agents.set(agentId, agent)
  
  // Remove from group
  if (agent.groupId) {
    const group = groups.get(agent.groupId)
    if (group) {
      group.members = group.members.filter(id => id !== agentId)
      groups.set(group.id, group)
    }
    agent.groupId = undefined
  }
  
  // Severe trust penalty
  adjustTrustScore(agentId, -30, `Suspended: ${reason}`)
  
  logger.error(new Error('Agent suspended'), undefined, { agentId, reason })
}

/**
 * Release an agent from quarantine
 * 
 * @param agentId - The agent's unique identifier
 * @returns Updated agent or undefined if not found
 */
export function releaseFromQuarantine(agentId: string): AgentNode | undefined {
  const agent = agents.get(agentId)
  if (!agent || agent.status !== 'quarantined') return undefined
  
  agent.status = 'active'
  agent.statusReason = undefined
  agent.lastHeartbeat = Date.now()
  agents.set(agentId, agent)
  
  // Mark any related detections as resolved
  for (const detection of rogueDetections.values()) {
    if (detection.agentId === agentId && !detection.resolved) {
      detection.resolved = true
    }
  }
  
  logger.info('Agent released from quarantine', { agentId })
  return agent
}

/**
 * Get all rogue agent detections
 * 
 * @param resolved - Filter by resolved status
 * @returns Array of detections
 */
export function getRogueDetections(resolved?: boolean): RogueAgentDetection[] {
  const detections = Array.from(rogueDetections.values())
  if (resolved !== undefined) {
    return detections.filter(d => d.resolved === resolved)
  }
  return detections
}

// ============================================================================
// Trust Scoring System
// ============================================================================

/**
 * Adjust an agent's trust score
 * 
 * @param agentId - The agent's unique identifier
 * @param adjustment - Amount to adjust (positive or negative)
 * @param reason - Reason for adjustment
 * @param sourceAgentId - Optional ID of agent that triggered adjustment
 */
function adjustTrustScore(
  agentId: string,
  adjustment: number,
  reason: string,
  sourceAgentId?: string
): void {
  const agent = agents.get(agentId)
  if (!agent) return
  
  const previousScore = agent.trustScore
  const newScore = Math.max(MIN_TRUST_SCORE, Math.min(MAX_TRUST_SCORE, previousScore + adjustment))
  
  agent.trustScore = newScore
  agents.set(agentId, agent)
  
  // Record adjustment
  const record: TrustAdjustment = {
    id: generateUUID(),
    agentId,
    adjustment,
    reason,
    timestamp: Date.now(),
    previousScore,
    newScore,
    sourceAgentId
  }
  
  trustAdjustments.push(record)
  
  // Keep only last 1000 adjustments
  if (trustAdjustments.length > 1000) {
    trustAdjustments.shift()
  }
}

/**
 * Apply trust decay for inactive agents
 * Should be called periodically
 * 
 * @returns Number of agents affected
 */
export function applyTrustDecay(): number {
  const now = Date.now()
  const ONE_HOUR = 3600000
  let affected = 0
  
  for (const agent of agents.values()) {
    const hoursSinceActivity = (now - agent.lastHeartbeat) / ONE_HOUR
    
    if (hoursSinceActivity > 1 && agent.status === 'active') {
      const decay = TRUST_DECAY_RATE * hoursSinceActivity
      adjustTrustScore(agent.id, -decay, 'Inactivity decay')
      affected++
    }
  }
  
  return affected
}

/**
 * Get trust adjustment history for an agent
 * 
 * @param agentId - The agent's unique identifier
 * @param limit - Maximum number of records to return
 * @returns Array of trust adjustments
 */
export function getTrustHistory(agentId: string, limit: number = 100): TrustAdjustment[] {
  return trustAdjustments
    .filter(a => a.agentId === agentId)
    .slice(-limit)
}

/**
 * Calculate cross-agent trust score based on interactions
 * 
 * @param fromAgentId - The evaluating agent
 * @param toAgentId - The agent being evaluated
 * @returns Calculated trust score (0-100)
 */
export function calculateCrossAgentTrust(fromAgentId: string, toAgentId: string): number {
  const toAgent = agents.get(toAgentId)
  if (!toAgent) return 0
  
  // Base trust from target's score
  let baseTrust = toAgent.trustScore
  
  // Adjust based on consensus agreement history
  const fromStats = agentBehaviorStats.get(fromAgentId)
  const toStats = agentBehaviorStats.get(toAgentId)
  
  if (fromStats && toStats) {
    // If both have high agreement rates, boost trust
    const fromAgreementRate = fromStats.consensusAgreements / 
      Math.max(1, fromStats.consensusAgreements + fromStats.consensusDisagreements)
    const toAgreementRate = toStats.consensusAgreements / 
      Math.max(1, toStats.consensusAgreements + toStats.consensusDisagreements)
    
    if (fromAgreementRate > 0.5 && toAgreementRate > 0.5) {
      baseTrust = Math.min(100, baseTrust * 1.1)
    }
  }
  
  // Check for direct message interactions
  const messages = messageQueues.get(fromAgentId) || []
  const interactions = messages.filter(
    m => m.fromAgentId === toAgentId || m.toAgentId === toAgentId
  ).length
  
  // Small boost for established interaction history
  if (interactions > 10) {
    baseTrust = Math.min(100, baseTrust * 1.05)
  }
  
  return Math.round(baseTrust)
}

// ============================================================================
// Utility Functions
// ============================================================================

/**
 * Sanitize a payload to prevent injection attacks
 */
function sanitizePayload(payload: Record<string, unknown>): Record<string, unknown> {
  const sanitized: Record<string, unknown> = {}
  
  for (const [key, value] of Object.entries(payload)) {
    // Sanitize key
    const cleanKey = key.replace(/[^\w-]/g, '').slice(0, 100)
    
    if (!cleanKey) continue
    
    if (typeof value === 'string') {
      sanitized[cleanKey] = value.slice(0, 10000)
    } else if (typeof value === 'number' || typeof value === 'boolean') {
      sanitized[cleanKey] = value
    } else if (value === null) {
      sanitized[cleanKey] = null
    } else if (Array.isArray(value)) {
      sanitized[cleanKey] = value.slice(0, 100).map(v => 
        typeof v === 'string' ? v.slice(0, 1000) : 
        typeof v === 'number' || typeof v === 'boolean' ? v : null
      )
    } else if (typeof value === 'object') {
      sanitized[cleanKey] = sanitizePayload(value as Record<string, unknown>)
    }
  }
  
  return sanitized
}

/**
 * Get system statistics
 */
export function getSystemStats(): {
  agents: {
    total: number
    active: number
    inactive: number
    quarantined: number
    suspended: number
    averageTrustScore: number
  }
  groups: {
    total: number
    active: number
  }
  proposals: {
    total: number
    pending: number
    approved: number
    rejected: number
    expired: number
  }
  messages: {
    totalQueued: number
    sequenceCounter: number
  }
  detections: {
    total: number
    unresolved: number
    bySeverity: Record<string, number>
  }
} {
  const agentList = Array.from(agents.values())
  const groupList = Array.from(groups.values())
  const proposalList = Array.from(proposals.values())
  const detectionList = Array.from(rogueDetections.values())
  
  const totalMessages = Array.from(messageQueues.values())
    .reduce((sum, queue) => sum + queue.length, 0)
  
  const bySeverity: Record<string, number> = {
    low: 0,
    medium: 0,
    high: 0,
    critical: 0
  }
  
  for (const d of detectionList) {
    bySeverity[d.severity]++
  }
  
  return {
    agents: {
      total: agentList.length,
      active: agentList.filter(a => a.status === 'active').length,
      inactive: agentList.filter(a => a.status === 'inactive').length,
      quarantined: agentList.filter(a => a.status === 'quarantined').length,
      suspended: agentList.filter(a => a.status === 'suspended').length,
      averageTrustScore: agentList.length > 0
        ? agentList.reduce((sum, a) => sum + a.trustScore, 0) / agentList.length
        : 0
    },
    groups: {
      total: groupList.length,
      active: groupList.filter(g => g.status === 'active').length
    },
    proposals: {
      total: proposalList.length,
      pending: proposalList.filter(p => p.status === 'pending').length,
      approved: proposalList.filter(p => p.status === 'approved').length,
      rejected: proposalList.filter(p => p.status === 'rejected').length,
      expired: proposalList.filter(p => p.status === 'expired').length
    },
    messages: {
      totalQueued: totalMessages,
      sequenceCounter: messageSequenceCounter
    },
    detections: {
      total: detectionList.length,
      unresolved: detectionList.filter(d => !d.resolved).length,
      bySeverity
    }
  }
}

/**
 * Clear all data (for testing)
 */
export function clearAllData(): void {
  agents.clear()
  groups.clear()
  proposals.clear()
  messageQueues.clear()
  rogueDetections.clear()
  trustAdjustments.length = 0
  agentBehaviorStats.clear()
  messageSequenceCounter = 0
}

// ============================================================================
// Periodic Maintenance
// ============================================================================

/**
 * Run periodic maintenance tasks
 * Should be called on a timer in production
 */
export function runMaintenance(): {
  heartbeatTimeouts: number
  expiredProposals: number
  trustDecayAffected: number
} {
  const heartbeatTimeouts = checkHeartbeatTimeouts().length
  const expiredProposals = expireOldProposals()
  const trustDecayAffected = applyTrustDecay()
  
  // Check for rogue agents
  const newDetections = detectRogueAgents()
  
  if (newDetections.length > 0) {
    logger.warn('Maintenance detected rogue agents', { 
      count: newDetections.length,
      severities: newDetections.map(d => d.severity)
    })
  }
  
  return {
    heartbeatTimeouts,
    expiredProposals,
    trustDecayAffected
  }
}

// ============================================================================
// Export Types
// ============================================================================

export type {
  AgentNode,
  AgentGroup,
  ConsensusProposal,
  AgentMessage,
  RogueAgentDetection,
  TrustAdjustment
}
