/**
 * VLM Analyzer
 * Vision Language Model-based deepfake detection
 */

import ZAI from 'z-ai-web-dev-sdk'

export interface AnalysisResult {
  result: 'authentic' | 'deepfake' | 'uncertain'
  confidence: number
  analysis: string
  indicators: string[]
}

export interface AnalyzeOptions {
  platform?: string
  timeout?: number
}

const ANALYSIS_PROMPT = `You are an expert deepfake detection AI. Analyze this media for signs of AI manipulation or deepfake technology.

Examine for:
1. Facial inconsistencies, unnatural movements
2. Lip-sync mismatches
3. Artifacts around face edges
4. Unnatural skin texture
5. Background inconsistencies
6. Audio-visual sync issues
7. Unnatural eye movements or reflections
8. Hair and edge artifacts

Respond ONLY with JSON:
{
  "result": "authentic" | "deepfake" | "uncertain",
  "confidence": 0.0-1.0,
  "analysis": "Brief explanation (2-3 sentences)",
  "indicators": ["indicator1", "indicator2"]
}`

/**
 * Analyze an image for deepfake detection
 */
export async function analyzeImage(
  imageSource: string,
  options: AnalyzeOptions = {}
): Promise<AnalysisResult> {
  const { platform } = options

  try {
    const zai = await ZAI.create()

    const platformContext = platform 
      ? `\n\nPlatform: ${platform}` 
      : ''

    const content = [
      { type: 'text', text: ANALYSIS_PROMPT + platformContext },
      { type: 'image_url', image_url: { url: imageSource.startsWith('data:') ? imageSource : `data:image/jpeg;base64,${imageSource}` } }
    ]

    const response = await zai.chat.completions.createVision({
      messages: [{ role: 'user', content }],
      thinking: { type: 'disabled' }
    })

    const responseText = response.choices[0]?.message?.content || ''

    // Parse result
    const jsonMatch = responseText.match(/\{[\s\S]*?\}/)
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0])
      
      const result: 'authentic' | 'deepfake' | 'uncertain' = 
        ['authentic', 'deepfake', 'uncertain'].includes(parsed.result) 
          ? parsed.result 
          : 'uncertain'

      const confidence = Math.max(0, Math.min(1, parseFloat(parsed.confidence) || 0.5))
      const analysis = parsed.analysis || 'Analysis complete'
      const indicators = Array.isArray(parsed.indicators) 
        ? parsed.indicators.filter((i: unknown): i is string => typeof i === 'string')
        : []

      return { result, confidence, analysis, indicators }
    }

    return {
      result: 'uncertain',
      confidence: 0.5,
      analysis: 'Could not parse analysis result',
      indicators: []
    }

  } catch (error) {
    console.error('[VLM] Image analysis error:', error)
    return {
      result: 'uncertain',
      confidence: 0.5,
      analysis: 'Analysis failed - protection still active',
      indicators: ['analysis_error']
    }
  }
}

/**
 * Analyze a video for deepfake detection
 */
export async function analyzeVideo(
  videoUrl: string,
  options: AnalyzeOptions = {}
): Promise<AnalysisResult> {
  const { platform } = options

  try {
    const zai = await ZAI.create()

    const platformContext = platform 
      ? `\n\nPlatform: ${platform}` 
      : ''

    // For video, we analyze frame-by-frame conceptually
    // In production, you'd extract key frames
    const content = [
      { type: 'text', text: ANALYSIS_PROMPT + platformContext + '\n\nNote: This is a video URL. Analyze for video-specific deepfake indicators.' },
      { type: 'text', text: `Video URL: ${videoUrl}` }
    ]

    const response = await zai.chat.completions.create({
      messages: [{ role: 'user', content }],
      thinking: { type: 'disabled' }
    })

    const responseText = response.choices[0]?.message?.content || ''

    // Parse result
    const jsonMatch = responseText.match(/\{[\s\S]*?\}/)
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0])
      
      const result: 'authentic' | 'deepfake' | 'uncertain' = 
        ['authentic', 'deepfake', 'uncertain'].includes(parsed.result) 
          ? parsed.result 
          : 'uncertain'

      const confidence = Math.max(0, Math.min(1, parseFloat(parsed.confidence) || 0.5))
      const analysis = parsed.analysis || 'Video analysis complete'
      const indicators = Array.isArray(parsed.indicators) 
        ? parsed.indicators.filter((i: unknown): i is string => typeof i === 'string')
        : []

      return { result, confidence, analysis, indicators }
    }

    return {
      result: 'uncertain',
      confidence: 0.5,
      analysis: 'Could not parse video analysis result',
      indicators: []
    }

  } catch (error) {
    console.error('[VLM] Video analysis error:', error)
    return {
      result: 'uncertain',
      confidence: 0.5,
      analysis: 'Video analysis failed - protection still active',
      indicators: ['video_analysis_error']
    }
  }
}

/**
 * Quick check if media might be AI-generated
 */
export async function quickCheck(mediaSource: string): Promise<boolean> {
  try {
    const result = await analyzeImage(mediaSource, { timeout: 5000 })
    return result.result === 'deepfake' && result.confidence > 0.7
  } catch {
    return false
  }
}
