/**
 * Enterprise-grade logging utility
 * Structured logging with levels, context, and error tracking
 */

type LogLevel = 'debug' | 'info' | 'warn' | 'error' | 'critical'
type LogCategory = 'api' | 'detection' | 'validation' | 'security' | 'system' | 'performance'

interface LogEntry {
  timestamp: string
  level: LogLevel
  category: LogCategory
  message: string
  context?: Record<string, unknown>
  error?: {
    name: string
    message: string
    stack?: string
  }
  duration?: number
  requestId?: string
}

// Minimum log level based on environment
const MIN_LEVEL: LogLevel = process.env.NODE_ENV === 'production' ? 'info' : 'debug'

// Level priority
const LEVEL_PRIORITY: Record<LogLevel, number> = {
  debug: 0,
  info: 1,
  warn: 2,
  error: 3,
  critical: 4
}

// ANSI color codes for terminal
const LEVEL_COLORS: Record<LogLevel, string> = {
  debug: '\x1b[36m',   // Cyan
  info: '\x1b[32m',    // Green
  warn: '\x1b[33m',    // Yellow
  error: '\x1b[31m',   // Red
  critical: '\x1b[35m' // Magenta
}

const RESET_COLOR = '\x1b[0m'

/**
 * Format timestamp
 */
function formatTimestamp(): string {
  return new Date().toISOString()
}

/**
 * Format log entry for output
 */
function formatEntry(entry: LogEntry): string {
  const color = LEVEL_COLORS[entry.level]
  const levelStr = entry.level.toUpperCase().padEnd(8)
  
  let message = `${color}[${entry.timestamp}] [${levelStr}] [${entry.category.toUpperCase()}]${RESET_COLOR} ${entry.message}`
  
  if (entry.context && Object.keys(entry.context).length > 0) {
    message += `\n  Context: ${JSON.stringify(entry.context, null, 2)}`
  }
  
  if (entry.error) {
    message += `\n  Error: ${entry.error.name}: ${entry.error.message}`
    if (entry.error.stack) {
      message += `\n  Stack: ${entry.error.stack}`
    }
  }
  
  if (entry.duration !== undefined) {
    message += `\n  Duration: ${entry.duration}ms`
  }
  
  return message
}

/**
 * Core logging function
 */
function log(
  level: LogLevel,
  category: LogCategory,
  message: string,
  context?: Record<string, unknown>,
  error?: Error,
  duration?: number,
  requestId?: string
): void {
  // Check if level should be logged
  if (LEVEL_PRIORITY[level] < LEVEL_PRIORITY[MIN_LEVEL]) {
    return
  }

  const entry: LogEntry = {
    timestamp: formatTimestamp(),
    level,
    category,
    message,
    context: context ? sanitizeContext(context) : undefined,
    duration,
    requestId
  }

  if (error) {
    entry.error = {
      name: error.name,
      message: error.message,
      stack: error.stack
    }
  }

  // In production, output JSON for log aggregation
  if (process.env.NODE_ENV === 'production') {
    console.log(JSON.stringify(entry))
  } else {
    console.log(formatEntry(entry))
  }

  // Critical errors should trigger alerts
  if (level === 'critical') {
    handleCriticalError(entry)
  }
}

/**
 * Sanitize context to remove sensitive data
 */
function sanitizeContext(context: Record<string, unknown>): Record<string, unknown> {
  const sanitized = { ...context }
  const sensitiveKeys = ['password', 'token', 'secret', 'key', 'credential', 'auth']
  
  for (const key of Object.keys(sanitized)) {
    // Check for sensitive key names
    if (sensitiveKeys.some(sk => key.toLowerCase().includes(sk))) {
      sanitized[key] = '[REDACTED]'
    }
    
    // Truncate large values
    if (typeof sanitized[key] === 'string' && (sanitized[key] as string).length > 1000) {
      sanitized[key] = (sanitized[key] as string).slice(0, 1000) + '... [truncated]'
    }
    
    // Handle nested objects
    if (typeof sanitized[key] === 'object' && sanitized[key] !== null && !Array.isArray(sanitized[key])) {
      sanitized[key] = sanitizeContext(sanitized[key] as Record<string, unknown>)
    }
  }
  
  return sanitized
}

/**
 * Handle critical errors (could send to monitoring service)
 */
function handleCriticalError(entry: LogEntry): void {
  // In a real application, this would send to:
  // - PagerDuty, Slack, email, etc.
  // For now, just ensure it's logged prominently
  console.error('\n' + '='.repeat(60))
  console.error('CRITICAL ERROR DETECTED')
  console.error('='.repeat(60))
  console.error(JSON.stringify(entry, null, 2))
  console.error('='.repeat(60) + '\n')
}

/**
 * Logger class with chainable methods
 */
class Logger {
  private category: LogCategory
  private requestId?: string

  constructor(category: LogCategory, requestId?: string) {
    this.category = category
    this.requestId = requestId
  }

  setRequestId(requestId: string): Logger {
    this.requestId = requestId
    return this
  }

  debug(message: string, context?: Record<string, unknown>): void {
    log('debug', this.category, message, context, undefined, undefined, this.requestId)
  }

  info(message: string, context?: Record<string, unknown>): void {
    log('info', this.category, message, context, undefined, undefined, this.requestId)
  }

  warn(message: string, context?: Record<string, unknown>): void {
    log('warn', this.category, message, context, undefined, undefined, this.requestId)
  }

  error(message: string, error?: Error, context?: Record<string, unknown>): void {
    log('error', this.category, message, context, error, undefined, this.requestId)
  }

  critical(message: string, error?: Error, context?: Record<string, unknown>): void {
    log('critical', this.category, message, context, error, undefined, this.requestId)
  }

  /**
   * Time an operation
   */
  time<T>(label: string, fn: () => T | Promise<T>): Promise<T> {
    const start = Date.now()
    
    const result = fn()
    
    if (result instanceof Promise) {
      return result
        .then(res => {
          const duration = Date.now() - start
          log('info', this.category, `Operation completed: ${label}`, undefined, undefined, duration, this.requestId)
          return res
        })
        .catch(err => {
          const duration = Date.now() - start
          log('error', this.category, `Operation failed: ${label}`, undefined, err, duration, this.requestId)
          throw err
        })
    }
    
    const duration = Date.now() - start
    log('info', this.category, `Operation completed: ${label}`, undefined, undefined, duration, this.requestId)
    return Promise.resolve(result)
  }
}

/**
 * Create a logger for a specific category
 */
export function createLogger(category: LogCategory, requestId?: string): Logger {
  return new Logger(category, requestId)
}

// Pre-configured loggers
export const apiLogger = createLogger('api')
export const detectionLogger = createLogger('detection')
export const validationLogger = createLogger('validation')
export const securityLogger = createLogger('security')
export const systemLogger = createLogger('system')
export const performanceLogger = createLogger('performance')

/**
 * Generate unique request ID
 */
export function generateRequestId(): string {
  return `req_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`
}

/**
 * Log API request
 */
export function logRequest(
  method: string,
  path: string,
  requestId: string,
  metadata?: Record<string, unknown>
): void {
  apiLogger
    .setRequestId(requestId)
    .info(`Request: ${method} ${path}`, {
      method,
      path,
      ...metadata
    })
}

/**
 * Log API response
 */
export function logResponse(
  method: string,
  path: string,
  statusCode: number,
  duration: number,
  requestId: string
): void {
  const level = statusCode >= 500 ? 'error' : statusCode >= 400 ? 'warn' : 'info'
  
  log(level, 'api', `Response: ${method} ${path} - ${statusCode}`, {
    method,
    path,
    statusCode,
    duration
  }, undefined, duration, requestId)
}
