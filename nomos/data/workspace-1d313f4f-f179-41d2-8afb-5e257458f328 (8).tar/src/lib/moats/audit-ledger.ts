/**
 * Cryptographic Audit Integrity Ledger (CAIL)
 * Moat 7: Hash-chained audit trail. Every entry references previous entry's hash.
 * 
 * This provides tamper detection - any modification to the audit log
 * breaks the hash chain, immediately revealing tampering attempts.
 * 
 * Cross-platform: Works in both Node.js and browser environments
 */

import { generateUUID, randomBytesHex, sha256Sync } from '@/lib/crypto-utils'

export interface AuditEntry {
  id: string
  timestamp: string
  action: 'DETECT' | 'VALIDATE' | 'RATE_LIMIT' | 'ERROR' | 'BLOCK' | 'ALLOW'
  resource: string // File name or resource identifier
  result: 'SUCCESS' | 'FAILURE' | 'BLOCKED'
  metadata: Record<string, unknown>
  previousHash: string
  hash: string
  signature?: string
}

// In-memory ledger (in production, this would be persisted)
const auditLedger: AuditEntry[] = []
let genesisHash: string
let isInitialized = false

/**
 * Initialize the audit ledger with a genesis block
 */
export function initializeLedger(): void {
  if (isInitialized) return
  
  genesisHash = randomBytesHex(32)
  
  const genesisEntry: AuditEntry = {
    id: generateUUID(),
    timestamp: new Date().toISOString(),
    action: 'ALLOW',
    resource: 'LEDGER_INIT',
    result: 'SUCCESS',
    metadata: { type: 'genesis' },
    previousHash: '0'.repeat(64),
    hash: ''
  }
  
  genesisEntry.hash = computeHash(genesisEntry)
  auditLedger.push(genesisEntry)
  isInitialized = true
}

/**
 * Compute SHA-256 hash of an entry (synchronous for cross-platform compatibility)
 */
function computeHash(entry: Omit<AuditEntry, 'hash'>): string {
  const content = [
    entry.id,
    entry.timestamp,
    entry.action,
    entry.resource,
    entry.result,
    JSON.stringify(entry.metadata, Object.keys(entry.metadata).sort()),
    entry.previousHash
  ].join('|')
  
  return sha256Sync(content)
}

/**
 * Add an entry to the audit ledger
 */
export function addAuditEntry(
  action: AuditEntry['action'],
  resource: string,
  result: AuditEntry['result'],
  metadata: Record<string, unknown> = {}
): AuditEntry {
  // Initialize if not done
  if (!isInitialized || auditLedger.length === 0) {
    initializeLedger()
  }
  
  const previousEntry = auditLedger[auditLedger.length - 1]
  
  const entry: Omit<AuditEntry, 'hash'> = {
    id: generateUUID(),
    timestamp: new Date().toISOString(),
    action,
    resource: resource.slice(0, 255), // Limit resource length
    result,
    metadata: sanitizeMetadata(metadata),
    previousHash: previousEntry.hash
  }
  
  const hash = computeHash(entry)
  const fullEntry: AuditEntry = { ...entry, hash }
  
  auditLedger.push(fullEntry)
  
  return fullEntry
}

/**
 * Sanitize metadata to prevent injection
 */
function sanitizeMetadata(metadata: Record<string, unknown>): Record<string, unknown> {
  const sanitized: Record<string, unknown> = {}
  
  for (const [key, value] of Object.entries(metadata)) {
    // Only allow primitive types
    if (typeof value === 'string') {
      sanitized[key] = value.slice(0, 1000) // Limit string length
    } else if (typeof value === 'number') {
      sanitized[key] = value
    } else if (typeof value === 'boolean') {
      sanitized[key] = value
    } else if (value === null) {
      sanitized[key] = null
    }
  }
  
  return sanitized
}

/**
 * Verify the integrity of the entire ledger
 */
export function verifyLedgerIntegrity(): {
  valid: boolean
  brokenAt: number | null
  brokenHash: string | null
  totalEntries: number
  errors: string[]
} {
  const errors: string[] = []
  
  if (auditLedger.length === 0) {
    return { valid: true, brokenAt: null, brokenHash: null, totalEntries: 0, errors: [] }
  }
  
  // Verify genesis block
  const genesis = auditLedger[0]
  if (genesis.previousHash !== '0'.repeat(64)) {
    errors.push('Genesis block has invalid previous hash')
    return { valid: false, brokenAt: 0, brokenHash: genesis.previousHash, totalEntries: auditLedger.length, errors }
  }
  
  // Verify each subsequent entry
  for (let i = 1; i < auditLedger.length; i++) {
    const current = auditLedger[i]
    const previous = auditLedger[i - 1]
    
    // Check hash chain
    if (current.previousHash !== previous.hash) {
      errors.push(`Hash chain broken at entry ${i}: previous hash mismatch`)
      return { valid: false, brokenAt: i, brokenHash: current.previousHash, totalEntries: auditLedger.length, errors }
    }
    
    // Verify current hash
    const expectedHash = computeHash(current)
    if (current.hash !== expectedHash) {
      errors.push(`Hash mismatch at entry ${i}: content may have been modified`)
      return { valid: false, brokenAt: i, brokenHash: current.hash, totalEntries: auditLedger.length, errors }
    }
  }
  
  return { valid: true, brokenAt: null, brokenHash: null, totalEntries: auditLedger.length, errors }
}

/**
 * Get audit trail for a specific resource
 */
export function getResourceAuditTrail(resource: string): AuditEntry[] {
  return auditLedger.filter(entry => entry.resource === resource)
}

/**
 * Get recent audit entries
 */
export function getRecentAuditEntries(limit: number = 100): AuditEntry[] {
  return auditLedger.slice(-limit)
}

/**
 * Generate a cryptographic proof for an entry
 */
export function generateProof(entryId: string): {
  entry: AuditEntry | null
  proof: string[]
  rootHash: string | null
} {
  const entryIndex = auditLedger.findIndex(e => e.id === entryId)
  
  if (entryIndex === -1) {
    return { entry: null, proof: [], rootHash: null }
  }
  
  const entry = auditLedger[entryIndex]
  const proof: string[] = []
  
  // Build Merkle-like proof path
  // Include hashes needed to verify this entry
  if (entryIndex > 0) {
    proof.push(auditLedger[entryIndex - 1].hash)
  }
  
  if (entryIndex < auditLedger.length - 1) {
    proof.push(auditLedger[entryIndex + 1].previousHash)
  }
  
  const rootHash = auditLedger.length > 0 ? auditLedger[auditLedger.length - 1].hash : null
  
  return { entry, proof, rootHash }
}

/**
 * Export ledger for external audit
 */
export function exportLedger(): {
  version: string
  exportedAt: string
  entries: AuditEntry[]
  integrityCheck: ReturnType<typeof verifyLedgerIntegrity>
} {
  return {
    version: '1.0.0',
    exportedAt: new Date().toISOString(),
    entries: [...auditLedger],
    integrityCheck: verifyLedgerIntegrity()
  }
}

/**
 * Get statistics about the audit log
 */
export function getAuditStats(): {
  totalEntries: number
  actions: Record<string, number>
  results: Record<string, number>
  integrity: ReturnType<typeof verifyLedgerIntegrity>
} {
  const actions: Record<string, number> = {}
  const results: Record<string, number> = {}
  
  for (const entry of auditLedger) {
    actions[entry.action] = (actions[entry.action] || 0) + 1
    results[entry.result] = (results[entry.result] || 0) + 1
  }
  
  return {
    totalEntries: auditLedger.length,
    actions,
    results,
    integrity: verifyLedgerIntegrity()
  }
}

/**
 * Clear the ledger (for testing only)
 */
export function clearLedger(): void {
  auditLedger.length = 0
  isInitialized = false
}

// Initialize on module load (safe for both server and client)
if (typeof window !== 'undefined' || typeof process !== 'undefined') {
  initializeLedger()
}
