/**
 * Dynamic Threshold Modulation System
 * Moat 5: Risk thresholds adjust based on threat environment.
 * Higher threat = lower tolerance = more blocks.
 * 
 * This creates adaptive security that responds to attack patterns.
 */

export type ThreatLevel = 'minimal' | 'low' | 'medium' | 'high' | 'critical'
export type ThreatVector = 
  | 'file_upload'
  | 'api_abuse'
  | 'rate_limit_breach'
  | 'evasion_attempt'
  | 'mass_requests'
  | 'suspicious_pattern'
  | 'known_malicious'

export interface ThresholdConfig {
  baseConfidenceThreshold: number
  maxFileSizeMultiplier: number
  rateLimitMultiplier: number
  blockSuspiciousPatterns: boolean
  requireAdditionalVerification: boolean
  loggingLevel: 'minimal' | 'standard' | 'verbose'
}

// Threat level configurations
const THREAT_CONFIGS: Record<ThreatLevel, ThresholdConfig> = {
  minimal: {
    baseConfidenceThreshold: 0.8,
    maxFileSizeMultiplier: 1.5,
    rateLimitMultiplier: 2.0,
    blockSuspiciousPatterns: false,
    requireAdditionalVerification: false,
    loggingLevel: 'minimal'
  },
  low: {
    baseConfidenceThreshold: 0.75,
    maxFileSizeMultiplier: 1.2,
    rateLimitMultiplier: 1.5,
    blockSuspiciousPatterns: false,
    requireAdditionalVerification: false,
    loggingLevel: 'standard'
  },
  medium: {
    baseConfidenceThreshold: 0.65,
    maxFileSizeMultiplier: 1.0,
    rateLimitMultiplier: 1.0,
    blockSuspiciousPatterns: true,
    requireAdditionalVerification: false,
    loggingLevel: 'standard'
  },
  high: {
    baseConfidenceThreshold: 0.5,
    maxFileSizeMultiplier: 0.7,
    rateLimitMultiplier: 0.5,
    blockSuspiciousPatterns: true,
    requireAdditionalVerification: true,
    loggingLevel: 'verbose'
  },
  critical: {
    baseConfidenceThreshold: 0.3,
    maxFileSizeMultiplier: 0.5,
    rateLimitMultiplier: 0.25,
    blockSuspiciousPatterns: true,
    requireAdditionalVerification: true,
    loggingLevel: 'verbose'
  }
}

// Threat scoring weights
const THREAT_WEIGHTS: Record<ThreatVector, number> = {
  file_upload: 5,
  api_abuse: 10,
  rate_limit_breach: 15,
  evasion_attempt: 25,
  mass_requests: 20,
  suspicious_pattern: 15,
  known_malicious: 50
}

// Threshold decay configuration
const THREAT_DECAY_RATE = 0.95 // Per minute
const THREAT_UPDATE_INTERVAL = 60000 // 1 minute

// State
let currentThreatScore = 0
let threatHistory: Array<{ timestamp: number; vector: ThreatVector; score: number }> = []
let lastDecayTime = Date.now()

/**
 * Record a threat event
 */
export function recordThreatEvent(vector: ThreatVector, details?: Record<string, unknown>): {
  newScore: number
  newLevel: ThreatLevel
  action: string
} {
  const score = THREAT_WEIGHTS[vector]
  
  threatHistory.push({
    timestamp: Date.now(),
    vector,
    score
  })
  
  // Apply decay before adding new threat
  applyDecay()
  
  currentThreatScore += score
  
  // Cap at 100
  currentThreatScore = Math.min(currentThreatScore, 100)
  
  const level = calculateThreatLevel(currentThreatScore)
  
  // Determine action based on level
  let action: string
  switch (level) {
    case 'critical':
      action = 'BLOCK - Critical threat level reached'
      break
    case 'high':
      action = 'WARN - High threat level, enhanced scrutiny'
      break
    case 'medium':
      action = 'ALERT - Medium threat level, standard checks'
      break
    case 'low':
      action = 'NOTICE - Low threat level detected'
      break
    default:
      action = 'OK - Minimal threat'
  }
  
  return {
    newScore: currentThreatScore,
    newLevel: level,
    action
  }
}

/**
 * Apply exponential decay to threat score
 */
function applyDecay(): void {
  const now = Date.now()
  const elapsed = (now - lastDecayTime) / THREAT_UPDATE_INTERVAL
  
  if (elapsed > 0) {
    currentThreatScore *= Math.pow(THREAT_DECAY_RATE, elapsed)
    lastDecayTime = now
    
    // Clean old history (keep last hour)
    const cutoff = now - 3600000
    threatHistory = threatHistory.filter(h => h.timestamp > cutoff)
  }
}

/**
 * Calculate threat level from score
 */
export function calculateThreatLevel(score: number): ThreatLevel {
  if (score >= 80) return 'critical'
  if (score >= 60) return 'high'
  if (score >= 40) return 'medium'
  if (score >= 20) return 'low'
  return 'minimal'
}

/**
 * Get current threat configuration
 */
export function getCurrentThresholdConfig(): ThresholdConfig {
  applyDecay()
  const level = calculateThreatLevel(currentThreatScore)
  return THREAT_CONFIGS[level]
}

/**
 * Get adjusted confidence threshold
 * Higher threat = lower threshold (more sensitive detection)
 */
export function getAdjustedConfidenceThreshold(): number {
  const config = getCurrentThresholdConfig()
  return config.baseConfidenceThreshold
}

/**
 * Get adjusted rate limits
 * Higher threat = stricter limits
 */
export function getAdjustedRateLimits(): {
  detectionLimit: number
  readLimit: number
  blockDuration: number
} {
  const config = getCurrentThresholdConfig()
  
  return {
    detectionLimit: Math.floor(20 * config.rateLimitMultiplier),
    readLimit: Math.floor(120 * config.rateLimitMultiplier),
    blockDuration: Math.floor(60000 / config.rateLimitMultiplier)
  }
}

/**
 * Check if an action should be blocked based on current threat
 */
export function shouldBlockAction(
  action: 'upload' | 'detect' | 'read',
  context?: { 
    confidence?: number
    suspiciousPatterns?: string[]
    fileSize?: number
  }
): {
  blocked: boolean
  reason?: string
  recommendation?: string
} {
  const config = getCurrentThresholdConfig()
  
  // Check confidence threshold
  if (action === 'detect' && context?.confidence !== undefined) {
    if (context.confidence < config.baseConfidenceThreshold) {
      return {
        blocked: true,
        reason: `Confidence ${context.confidence.toFixed(2)} below threshold ${config.baseConfidenceThreshold}`,
        recommendation: 'Manual review recommended due to low confidence'
      }
    }
  }
  
  // Check suspicious patterns
  if (config.blockSuspiciousPatterns && context?.suspiciousPatterns?.length) {
    return {
      blocked: true,
      reason: `Suspicious patterns detected: ${context.suspiciousPatterns.join(', ')}`,
      recommendation: 'Threat level elevated - patterns flagged for blocking'
    }
  }
  
  // Check file size
  if (action === 'upload' && context?.fileSize) {
    const baseLimit = 50 * 1024 * 1024 // 50MB
    const adjustedLimit = baseLimit * config.maxFileSizeMultiplier
    
    if (context.fileSize > adjustedLimit) {
      return {
        blocked: true,
        reason: `File size exceeds limit of ${(adjustedLimit / 1024 / 1024).toFixed(0)}MB`,
        recommendation: 'Threat level elevated - file size limits reduced'
      }
    }
  }
  
  // Check if additional verification needed
  if (config.requireAdditionalVerification) {
    return {
      blocked: false,
      reason: 'Action allowed but verification required',
      recommendation: 'Critical threat level - consider additional verification'
    }
  }
  
  return { blocked: false }
}

/**
 * Get threat statistics
 */
export function getThreatStats(): {
  currentScore: number
  currentLevel: ThreatLevel
  recentEvents: Array<{ vector: ThreatVector; count: number; lastSeen: number }>
  topThreatVectors: Array<{ vector: ThreatVector; totalScore: number }>
} {
  applyDecay()
  
  // Aggregate recent events
  const eventCounts = new Map<ThreatVector, { count: number; lastSeen: number; totalScore: number }>()
  
  for (const event of threatHistory) {
    const existing = eventCounts.get(event.vector) || { count: 0, lastSeen: 0, totalScore: 0 }
    eventCounts.set(event.vector, {
      count: existing.count + 1,
      lastSeen: Math.max(existing.lastSeen, event.timestamp),
      totalScore: existing.totalScore + event.score
    })
  }
  
  const recentEvents = [...eventCounts.entries()]
    .map(([vector, data]) => ({ vector, count: data.count, lastSeen: data.lastSeen }))
    .sort((a, b) => b.lastSeen - a.lastSeen)
    .slice(0, 5)
  
  const topThreatVectors = [...eventCounts.entries()]
    .map(([vector, data]) => ({ vector, totalScore: data.totalScore }))
    .sort((a, b) => b.totalScore - a.totalScore)
    .slice(0, 5)
  
  return {
    currentScore: currentThreatScore,
    currentLevel: calculateThreatLevel(currentThreatScore),
    recentEvents,
    topThreatVectors
  }
}

/**
 * Reset threat state (for testing)
 */
export function resetThreatState(): void {
  currentThreatScore = 0
  threatHistory = []
  lastDecayTime = Date.now()
}

/**
 * Run threshold tests
 */
export function runThresholdTests(): {
  passed: boolean
  tests: Array<{ name: string; passed: boolean; message: string }>
} {
  const tests: Array<{ name: string; passed: boolean; message: string }> = []
  
  // Reset for clean tests
  resetThreatState()
  
  // Test 1: Initial state
  const initialConfig = getCurrentThresholdConfig()
  tests.push({
    name: 'Initial threat level is minimal',
    passed: initialConfig.baseConfidenceThreshold === 0.8,
    message: `Expected threshold 0.8, got ${initialConfig.baseConfidenceThreshold}`
  })
  
  // Test 2: Threat escalation
  recordThreatEvent('evasion_attempt')
  const afterEvasion = getCurrentThresholdConfig()
  tests.push({
    name: 'Threat escalates after evasion attempt',
    passed: afterEvasion.baseConfidenceThreshold < initialConfig.baseConfidenceThreshold,
    message: `Threshold reduced from ${initialConfig.baseConfidenceThreshold} to ${afterEvasion.baseConfidenceThreshold}`
  })
  
  // Test 3: Critical threat
  resetThreatState()
  for (let i = 0; i < 5; i++) {
    recordThreatEvent('known_malicious')
  }
  const criticalConfig = getCurrentThresholdConfig()
  tests.push({
    name: 'Critical threat level reached',
    passed: criticalConfig.baseConfidenceThreshold === 0.3 && criticalConfig.requireAdditionalVerification,
    message: `Threshold: ${criticalConfig.baseConfidenceThreshold}, verification required: ${criticalConfig.requireAdditionalVerification}`
  })
  
  // Test 4: Blocking logic
  const blockResult = shouldBlockAction('upload', { 
    fileSize: 100 * 1024 * 1024 // 100MB 
  })
  tests.push({
    name: 'Large files blocked under critical threat',
    passed: blockResult.blocked === true,
    message: blockResult.reason || 'Not blocked'
  })
  
  // Test 5: Decay
  resetThreatState()
  recordThreatEvent('api_abuse')
  const scoreBeforeDecay = currentThreatScore
  lastDecayTime -= 60000 * 10 // Simulate 10 minutes passing
  applyDecay()
  tests.push({
    name: 'Threat score decays over time',
    passed: currentThreatScore < scoreBeforeDecay,
    message: `Score decayed from ${scoreBeforeDecay} to ${currentThreatScore.toFixed(2)}`
  })
  
  // Clean up
  resetThreatState()
  
  const passed = tests.every(t => t.passed)
  
  return { passed, tests }
}
