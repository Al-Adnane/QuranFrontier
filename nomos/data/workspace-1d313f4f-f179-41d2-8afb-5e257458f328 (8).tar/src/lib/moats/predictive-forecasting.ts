/**
 * Predictive Threat Forecasting
 * Moat 9: Uses historical patterns to predict future leak vectors before they happen.
 * 
 * Analyzes trends, patterns, and correlations to forecast potential threats.
 */

// Threat event types
export interface ThreatEvent {
  id: string
  timestamp: number
  vector: string
  severity: 'low' | 'medium' | 'high' | 'critical'
  category: 'evasion' | 'injection' | 'exfiltration' | 'manipulation' | 'bypass'
  source: string
  context: Record<string, unknown>
  resolved: boolean
}

// Forecast types
export interface ThreatForecast {
  id: string
  generatedAt: number
  validUntil: number
  predictions: Prediction[]
  confidence: number
  basedOn: number // Number of historical events
}

export interface Prediction {
  threat: string
  probability: number
  timeWindow: string
  category: ThreatEvent['category']
  mitigation: string
  indicators: string[]
}

// Historical events store (in-memory for demo)
const threatHistory: ThreatEvent[] = []
const MAX_HISTORY = 10000

// Threat patterns for prediction
const THREAT_PATTERNS = {
  evasion: {
    indicators: ['obfuscation', 'encoding', 'mutation', 'fragmentation'],
    typicalTimeWindows: ['1h', '6h', '24h'],
    mitigations: [
      'Enable multi-layer decoding',
      'Increase AST analysis depth',
      'Add behavioral heuristics'
    ]
  },
  injection: {
    indicators: ['payload', 'script', 'sql', 'command'],
    typicalTimeWindows: ['15m', '1h', '6h'],
    mitigations: [
      'Strengthen input validation',
      'Enable sandbox execution',
      'Add content-type verification'
    ]
  },
  exfiltration: {
    indicators: ['secret', 'credential', 'api_key', 'token'],
    typicalTimeWindows: ['5m', '30m', '2h'],
    mitigations: [
      'Block outbound connections',
      'Enable DLP scanning',
      'Activate secret rotation alerts'
    ]
  },
  manipulation: {
    indicators: ['deepfake', 'synthetic', 'generated', 'fake'],
    typicalTimeWindows: ['1h', '12h', '48h'],
    mitigations: [
      'Increase detection sensitivity',
      'Enable temporal analysis',
      'Add biological signal detection'
    ]
  },
  bypass: {
    indicators: ['hook', 'override', 'patch', 'detour'],
    typicalTimeWindows: ['10m', '1h', '6h'],
    mitigations: [
      'Verify hook integrity',
      'Enable self-healing hooks',
      'Add tamper detection'
    ]
  }
}

/**
 * Record a threat event
 */
export function recordThreatEvent(
  vector: string,
  severity: ThreatEvent['severity'],
  category: ThreatEvent['category'],
  source: string,
  context: Record<string, unknown> = {}
): ThreatEvent {
  const event: ThreatEvent = {
    id: `evt_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    timestamp: Date.now(),
    vector,
    severity,
    category,
    source,
    context,
    resolved: false
  }

  threatHistory.push(event)

  // Trim old events
  if (threatHistory.length > MAX_HISTORY) {
    threatHistory.shift()
  }

  return event
}

/**
 * Get threat trend analysis
 */
export function analyzeThreatTrends(timeWindowMs: number = 3600000): {
  totalEvents: number
  byCategory: Record<string, number>
  bySeverity: Record<string, number>
  topVectors: Array<{ vector: string; count: number }>
  trend: 'increasing' | 'stable' | 'decreasing'
} {
  const cutoff = Date.now() - timeWindowMs
  const recentEvents = threatHistory.filter(e => e.timestamp >= cutoff)

  // Count by category
  const byCategory: Record<string, number> = {}
  const bySeverity: Record<string, number> = {}
  const vectorCounts: Record<string, number> = {}

  for (const event of recentEvents) {
    byCategory[event.category] = (byCategory[event.category] || 0) + 1
    bySeverity[event.severity] = (bySeverity[event.severity] || 0) + 1
    vectorCounts[event.vector] = (vectorCounts[event.vector] || 0) + 1
  }

  // Get top vectors
  const topVectors = Object.entries(vectorCounts)
    .map(([vector, count]) => ({ vector, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 10)

  // Determine trend (compare first half vs second half of time window)
  const halfWindow = timeWindowMs / 2
  const firstHalf = recentEvents.filter(e => e.timestamp < cutoff + halfWindow).length
  const secondHalf = recentEvents.filter(e => e.timestamp >= cutoff + halfWindow).length

  let trend: 'increasing' | 'stable' | 'decreasing' = 'stable'
  if (secondHalf > firstHalf * 1.2) trend = 'increasing'
  else if (secondHalf < firstHalf * 0.8) trend = 'decreasing'

  return {
    totalEvents: recentEvents.length,
    byCategory,
    bySeverity,
    topVectors,
    trend
  }
}

/**
 * Generate threat forecast
 */
export function generateForecast(): ThreatForecast {
  const now = Date.now()
  const oneHourAgo = now - 3600000
  const sixHoursAgo = now - 21600000

  const recentEvents = threatHistory.filter(e => e.timestamp >= oneHourAgo)
  const historicalEvents = threatHistory.filter(e => e.timestamp >= sixHoursAgo)

  const predictions: Prediction[] = []

  // Analyze each threat category
  for (const [category, pattern] of Object.entries(THREAT_PATTERNS)) {
    const categoryEvents = recentEvents.filter(e => e.category === category)
    
    if (categoryEvents.length > 0) {
      // Calculate probability based on frequency and severity
      const severityWeights = { critical: 4, high: 3, medium: 2, low: 1 }
      const weightedScore = categoryEvents.reduce((sum, e) => 
        sum + severityWeights[e.severity], 0)
      
      // Normalize probability
      const baseProbability = Math.min(weightedScore / 20, 0.95)
      
      // Adjust based on historical patterns
      const historicalRate = historicalEvents.filter(e => e.category === category).length / 6
      const probability = Math.max(baseProbability, historicalRate * 0.3)

      // Get most common indicators from recent events
      const indicators = [...new Set(
        categoryEvents
          .flatMap(e => Object.keys(e.context))
          .filter(k => pattern.indicators.some(i => k.toLowerCase().includes(i)))
      )].slice(0, 5)

      predictions.push({
        threat: `${category.charAt(0).toUpperCase() + category.slice(1)} threat likely`,
        probability: Math.round(probability * 100) / 100,
        timeWindow: pattern.typicalTimeWindows[0],
        category: category as ThreatEvent['category'],
        mitigation: pattern.mitigations[Math.floor(Math.random() * pattern.mitigations.length)],
        indicators: indicators.length > 0 ? indicators : pattern.indicators.slice(0, 3)
      })
    }
  }

  // Sort by probability
  predictions.sort((a, b) => b.probability - a.probability)

  // Calculate overall confidence
  const confidence = predictions.length > 0
    ? predictions.reduce((sum, p) => sum + p.probability, 0) / predictions.length
    : 0.5

  return {
    id: `forecast_${now}`,
    generatedAt: now,
    validUntil: now + 3600000, // Valid for 1 hour
    predictions: predictions.slice(0, 5), // Top 5 predictions
    confidence,
    basedOn: historicalEvents.length
  }
}

/**
 * Get threat score (0-100)
 */
export function getThreatScore(): {
  score: number
  level: 'minimal' | 'low' | 'moderate' | 'high' | 'critical'
  factors: Array<{ factor: string; contribution: number }>
} {
  const trends = analyzeThreatTrends(3600000) // Last hour

  let score = 0
  const factors: Array<{ factor: string; contribution: number }> = []

  // Base score from event count
  const eventScore = Math.min(trends.totalEvents * 2, 30)
  score += eventScore
  if (eventScore > 0) factors.push({ factor: 'Recent events', contribution: eventScore })

  // Severity contribution
  const severityScore = (trends.bySeverity['critical'] || 0) * 15 +
                        (trends.bySeverity['high'] || 0) * 10 +
                        (trends.bySeverity['medium'] || 0) * 5
  score += Math.min(severityScore, 40)
  if (severityScore > 0) factors.push({ factor: 'Severity distribution', contribution: Math.min(severityScore, 40) })

  // Trend contribution
  if (trends.trend === 'increasing') {
    score += 20
    factors.push({ factor: 'Increasing trend', contribution: 20 })
  } else if (trends.trend === 'decreasing') {
    score -= 10
    factors.push({ factor: 'Decreasing trend', contribution: -10 })
  }

  // Cap score
  score = Math.max(0, Math.min(100, score))

  // Determine level
  let level: 'minimal' | 'low' | 'moderate' | 'high' | 'critical' = 'minimal'
  if (score >= 80) level = 'critical'
  else if (score >= 60) level = 'high'
  else if (score >= 40) level = 'moderate'
  else if (score >= 20) level = 'low'

  return { score, level, factors }
}

/**
 * Get predictive stats for dashboard
 */
export function getPredictiveStats(): {
  historyCount: number
  recentEvents: number
  threatScore: ReturnType<typeof getThreatScore>
  forecast: ThreatForecast
} {
  const oneHourAgo = Date.now() - 3600000

  return {
    historyCount: threatHistory.length,
    recentEvents: threatHistory.filter(e => e.timestamp >= oneHourAgo).length,
    threatScore: getThreatScore(),
    forecast: generateForecast()
  }
}

// Initialize with some sample events
function initializeSampleData(): void {
  const vectors = [
    { vector: 'base64_encoded_secret', severity: 'high' as const, category: 'evasion' as const },
    { vector: 'deepfake_video', severity: 'critical' as const, category: 'manipulation' as const },
    { vector: 'api_key_exfiltration', severity: 'critical' as const, category: 'exfiltration' as const },
    { vector: 'hook_bypass_attempt', severity: 'high' as const, category: 'bypass' as const },
    { vector: 'sql_injection', severity: 'high' as const, category: 'injection' as const }
  ]

  // Add some historical events
  for (let i = 0; i < 10; i++) {
    const sample = vectors[Math.floor(Math.random() * vectors.length)]
    recordThreatEvent(
      sample.vector,
      sample.severity,
      sample.category,
      'system',
      { source: 'initialization' }
    )
  }
}

// Initialize on load
initializeSampleData()
