/**
 * HMAC-SHA256 Execution Tickets
 * Moat 10: All decision tickets signed. Replay attacks impossible.
 * 
 * Each ticket is one-time-use with HMAC-SHA256 signature.
 * Provides cryptographic proof of decision authenticity.
 * 
 * Cross-platform: Works in both Node.js and browser environments
 */

import { generateUUID, randomBytesHex, sha256Sync, hmacSha256 } from '@/lib/crypto-utils'

// Secret key for HMAC signing (in production, this would be from secure storage)
const HMAC_SECRET = randomBytesHex(32)
const TICKET_EXPIRY_MS = 60000 // 1 minute expiry

export interface ExecutionTicket {
  id: string
  timestamp: number
  action: 'DETECT' | 'ALLOW' | 'BLOCK' | 'VALIDATE'
  resource: string
  result: 'AUTHENTIC' | 'DEEPFAKE' | 'UNCERTAIN'
  confidence: number
  threatLevel: string
  nonce: string
  expiresAt: number
  signature: string
  used: boolean
}

// In-memory store for used tickets (prevent replay)
const usedTickets = new Map<string, number>()

/**
 * Generate a new execution ticket
 */
export function generateTicket(
  action: ExecutionTicket['action'],
  resource: string,
  result: ExecutionTicket['result'],
  confidence: number,
  threatLevel: string
): ExecutionTicket {
  const id = generateUUID()
  const timestamp = Date.now()
  const nonce = randomBytesHex(16)
  const expiresAt = timestamp + TICKET_EXPIRY_MS

  // Create ticket content
  const content = [
    id,
    timestamp.toString(),
    action,
    resource,
    result,
    confidence.toFixed(4),
    threatLevel,
    nonce,
    expiresAt.toString()
  ].join('|')

  // Sign with HMAC-SHA256
  const signature = hmacSha256(HMAC_SECRET, content)

  return {
    id,
    timestamp,
    action,
    resource,
    result,
    confidence,
    threatLevel,
    nonce,
    expiresAt,
    signature,
    used: false
  }
}

/**
 * Verify an execution ticket
 */
export function verifyTicket(ticket: ExecutionTicket): {
  valid: boolean
  reason?: string
} {
  // Check if already used (replay protection)
  if (usedTickets.has(ticket.id)) {
    return { valid: false, reason: 'Ticket already used (replay attack detected)' }
  }

  // Check expiry
  if (Date.now() > ticket.expiresAt) {
    return { valid: false, reason: 'Ticket expired' }
  }

  // Recreate content
  const content = [
    ticket.id,
    ticket.timestamp.toString(),
    ticket.action,
    ticket.resource,
    ticket.result,
    ticket.confidence.toFixed(4),
    ticket.threatLevel,
    ticket.nonce,
    ticket.expiresAt.toString()
  ].join('|')

  // Verify signature
  const expectedSignature = hmacSha256(HMAC_SECRET, content)

  if (ticket.signature !== expectedSignature) {
    return { valid: false, reason: 'Invalid signature (ticket tampered)' }
  }

  return { valid: true }
}

/**
 * Consume a ticket (mark as used)
 */
export function consumeTicket(ticket: ExecutionTicket): {
  success: boolean
  reason?: string
} {
  const verification = verifyTicket(ticket)
  
  if (!verification.valid) {
    return { success: false, reason: verification.reason }
  }

  // Mark as used
  usedTickets.set(ticket.id, Date.now())
  
  // Clean up old tickets
  cleanupExpiredTickets()
  
  return { success: true }
}

/**
 * Clean up expired used tickets
 */
function cleanupExpiredTickets(): void {
  const now = Date.now()
  const maxAge = 5 * 60 * 1000 // 5 minutes

  for (const [id, usedAt] of usedTickets.entries()) {
    if (now - usedAt > maxAge) {
      usedTickets.delete(id)
    }
  }
}

/**
 * Generate proof for external verification
 */
export function generateProof(ticket: ExecutionTicket): {
  ticketId: string
  action: string
  result: string
  timestamp: number
  proofHash: string
} {
  const proofContent = [
    ticket.id,
    ticket.action,
    ticket.result,
    ticket.timestamp.toString(),
    ticket.signature
  ].join('|')

  return {
    ticketId: ticket.id,
    action: ticket.action,
    result: ticket.result,
    timestamp: ticket.timestamp,
    proofHash: sha256Sync(proofContent)
  }
}

/**
 * Get ticket statistics
 */
export function getTicketStats(): {
  totalGenerated: number
  activeUsed: number
  replayAttacksBlocked: number
} {
  return {
    totalGenerated: usedTickets.size,
    activeUsed: usedTickets.size,
    replayAttacksBlocked: 0 // Would need to track this separately
  }
}
