/**
 * Chunked Video Processing Service
 * Solves the timeout issue by processing videos in segments
 * Implements streaming analysis for large files
 */

import ZAI from 'z-ai-web-dev-sdk'

export interface VideoChunk {
  index: number
  startTime: number
  endTime: number
  frameCount: number
  base64Data: string
}

export interface ChunkedAnalysisResult {
  chunks: Array<{
    index: number
    result: 'authentic' | 'deepfake' | 'uncertain'
    confidence: number
    analysis: string
    indicators: string[]
  }>
  aggregatedResult: 'authentic' | 'deepfake' | 'uncertain'
  aggregatedConfidence: number
  aggregatedAnalysis: string
  aggregatedIndicators: string[]
  processingTime: number
  chunksProcessed: number
}

const CHUNK_DURATION_SECONDS = 5 // Analyze 5-second chunks
const MAX_CHUNKS = 12 // Maximum 12 chunks (60 seconds total analyzed)
const CHUNK_TIMEOUT_MS = 30000 // 30 seconds per chunk

const CHUNK_DETECTION_PROMPT = `You are an expert deepfake detection AI. Analyze this video segment for signs of manipulation.

This is segment {chunkIndex} of {totalChunks} from a larger video.

Examine these aspects:
1. FACIAL MOTION: Unnatural movements, lip-sync issues, rigid expressions
2. EYE MOVEMENTS: Unusual blinking, inconsistent gaze
3. FRAME CONSISTENCY: Flickering, morphing artifacts
4. EDGE ARTIFACTS: Artifacts around face boundaries
5. TEMPORAL COHERENCE: Issues between frames

Respond ONLY with valid JSON:
{
  "result": "authentic" | "deepfake" | "uncertain",
  "confidence": 0.0-1.0,
  "analysis": "Brief analysis for this segment (1-2 sentences)",
  "indicators": ["indicator1", "indicator2"]
}`

/**
 * Extract keyframes from video buffer
 */
export async function extractVideoChunks(
  videoBuffer: Buffer,
  mimeType: string,
  onProgress?: (progress: number) => void
): Promise<VideoChunk[]> {
  // For now, we'll create chunks based on the video data
  // In production, you'd use ffmpeg or similar
  
  const chunks: VideoChunk[] = []
  const totalSize = videoBuffer.length
  const chunkSize = Math.floor(totalSize / MAX_CHUNKS)
  
  for (let i = 0; i < MAX_CHUNKS; i++) {
    const start = i * chunkSize
    const end = Math.min(start + chunkSize, totalSize)
    
    if (start >= totalSize) break
    
    const chunkBuffer = videoBuffer.slice(start, end)
    
    chunks.push({
      index: i,
      startTime: i * CHUNK_DURATION_SECONDS,
      endTime: (i + 1) * CHUNK_DURATION_SECONDS,
      frameCount: CHUNK_DURATION_SECONDS * 30, // Assume 30fps
      base64Data: chunkBuffer.toString('base64')
    })
    
    if (onProgress) {
      onProgress((i + 1) / MAX_CHUNKS * 30) // 30% for extraction
    }
  }
  
  return chunks
}

/**
 * Analyze a single video chunk
 */
async function analyzeChunk(
  chunk: VideoChunk,
  totalChunks: number,
  mimeType: string
): Promise<{
  result: 'authentic' | 'deepfake' | 'uncertain'
  confidence: number
  analysis: string
  indicators: string[]
}> {
  const zai = await ZAI.create()
  
  const prompt = CHUNK_DETECTION_PROMPT
    .replace('{chunkIndex}', (chunk.index + 1).toString())
    .replace('{totalChunks}', totalChunks.toString())
  
  const dataUrl = `data:${mimeType};base64,${chunk.base64Data}`
  
  try {
    const response = await Promise.race([
      zai.chat.completions.createVision({
        messages: [{
          role: 'user',
          content: [
            { type: 'text', text: prompt },
            { type: 'video_url', video_url: { url: dataUrl } }
          ]
        }],
        thinking: { type: 'disabled' }
      }),
      new Promise<never>((_, reject) => 
        setTimeout(() => reject(new Error('Chunk analysis timeout')), CHUNK_TIMEOUT_MS)
      )
    ])
    
    const content = response.choices[0]?.message?.content || ''
    
    // Parse JSON response
    const jsonMatch = content.match(/\{[\s\S]*?\}/)
    if (!jsonMatch) {
      return {
        result: 'uncertain',
        confidence: 0.5,
        analysis: 'Unable to analyze chunk',
        indicators: ['analysis_failed']
      }
    }
    
    const parsed = JSON.parse(jsonMatch[0])
    
    return {
      result: ['authentic', 'deepfake', 'uncertain'].includes(parsed.result) 
        ? parsed.result 
        : 'uncertain',
      confidence: Math.max(0, Math.min(1, parseFloat(parsed.confidence) || 0.5)),
      analysis: String(parsed.analysis || 'No analysis'),
      indicators: Array.isArray(parsed.indicators) 
        ? parsed.indicators.filter((i: unknown): i is string => typeof i === 'string').slice(0, 10)
        : []
    }
  } catch (error) {
    return {
      result: 'uncertain',
      confidence: 0.5,
      analysis: `Chunk ${chunk.index + 1} analysis failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
      indicators: ['chunk_analysis_error']
    }
  }
}

/**
 * Aggregate results from multiple chunks
 */
function aggregateResults(
  chunkResults: Array<{
    result: 'authentic' | 'deepfake' | 'uncertain'
    confidence: number
    analysis: string
    indicators: string[]
  }>
): {
  result: 'authentic' | 'deepfake' | 'uncertain'
  confidence: number
  analysis: string
  indicators: string[]
} {
  if (chunkResults.length === 0) {
    return {
      result: 'uncertain',
      confidence: 0.5,
      analysis: 'No chunks were successfully analyzed',
      indicators: ['no_chunks_analyzed']
    }
  }
  
  // Count votes
  const votes = {
    authentic: 0,
    deepfake: 0,
    uncertain: 0
  }
  
  let totalConfidence = 0
  const allIndicators = new Set<string>()
  const analyses: string[] = []
  
  for (const chunk of chunkResults) {
    votes[chunk.result]++
    totalConfidence += chunk.confidence
    chunk.indicators.forEach(i => allIndicators.add(i))
    if (chunk.analysis && !chunk.analysis.includes('failed')) {
      analyses.push(`Chunk: ${chunk.analysis}`)
    }
  }
  
  // Determine winner
  let result: 'authentic' | 'deepfake' | 'uncertain'
  const maxVotes = Math.max(votes.authentic, votes.deepfake, votes.uncertain)
  
  // If deepfake votes > 30%, mark as deepfake (be conservative)
  if (votes.deepfake / chunkResults.length > 0.3) {
    result = 'deepfake'
  } else if (votes.authentic === maxVotes && votes.authentic > chunkResults.length / 2) {
    result = 'authentic'
  } else {
    result = 'uncertain'
  }
  
  // Calculate confidence
  const avgConfidence = totalConfidence / chunkResults.length
  
  // Adjust confidence based on consistency
  const consistencyBonus = maxVotes / chunkResults.length
  const confidence = Math.min(0.99, avgConfidence * 0.7 + consistencyBonus * 0.3)
  
  // Build analysis
  let analysis: string
  if (result === 'deepfake') {
    analysis = `Deepfake indicators detected in ${(votes.deepfake / chunkResults.length * 100).toFixed(0)}% of video segments. ${analyses.slice(0, 2).join(' ')}`
  } else if (result === 'authentic') {
    analysis = `No significant deepfake indicators detected. Analyzed ${chunkResults.length} video segments. ${analyses.slice(0, 2).join(' ')}`
  } else {
    analysis = `Mixed results across ${chunkResults.length} segments. Some segments showed potential manipulation indicators. Manual review recommended.`
  }
  
  return {
    result,
    confidence,
    analysis,
    indicators: [...allIndicators].slice(0, 15)
  }
}

/**
 * Main chunked video analysis function
 */
export async function analyzeVideoChunked(
  videoBuffer: Buffer,
  mimeType: string,
  onProgress?: (progress: number, message: string) => void
): Promise<ChunkedAnalysisResult> {
  const startTime = Date.now()
  
  // Extract chunks
  onProgress?.(5, 'Extracting video segments...')
  const chunks = await extractVideoChunks(videoBuffer, mimeType, (p) => {
    onProgress?.(5 + p * 0.25, `Extracting video segments... ${Math.round(p)}%`)
  })
  
  // Analyze each chunk
  const chunkResults: Array<{
    result: 'authentic' | 'deepfake' | 'uncertain'
    confidence: number
    analysis: string
    indicators: string[]
  }> = []
  
  for (let i = 0; i < chunks.length; i++) {
    const progress = 30 + (i / chunks.length) * 65
    onProgress?.(progress, `Analyzing segment ${i + 1}/${chunks.length}...`)
    
    const result = await analyzeChunk(chunks[i], chunks.length, mimeType)
    chunkResults.push(result)
  }
  
  // Aggregate results
  onProgress?.(95, 'Aggregating results...')
  const aggregated = aggregateResults(chunkResults)
  
  const processingTime = Date.now() - startTime
  onProgress?.(100, 'Analysis complete!')
  
  return {
    chunks: chunkResults,
    aggregatedResult: aggregated.result,
    aggregatedConfidence: aggregated.confidence,
    aggregatedAnalysis: aggregated.analysis,
    aggregatedIndicators: aggregated.indicators,
    processingTime,
    chunksProcessed: chunks.length
  }
}
