/**
 * Enterprise-grade validation utilities
 * Implements strict input validation following security best practices
 */

// Magic bytes for file type verification (prevents file type spoofing)
export const MAGIC_BYTES: Record<string, { bytes: number[]; offset: number; mask?: number[] }> = {
  // Images
  'image/jpeg': { bytes: [0xFF, 0xD8, 0xFF], offset: 0 },
  'image/png': { bytes: [0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A], offset: 0 },
  'image/gif': { bytes: [0x47, 0x49, 0x46, 0x38], offset: 0 },
  'image/webp': { bytes: [0x52, 0x49, 0x46, 0x46], offset: 0 }, // RIFF, then check WEBP at offset 8
  'image/bmp': { bytes: [0x42, 0x4D], offset: 0 },
  
  // Videos
  'video/mp4': { bytes: [0x00, 0x00, 0x00], offset: 0 }, // ftyp box check needed
  'video/webm': { bytes: [0x1A, 0x45, 0xDF, 0xA3], offset: 0 }, // EBML
  'video/quicktime': { bytes: [0x00, 0x00, 0x00], offset: 0 }, // moov atom check
  
  // Audio
  'audio/mpeg': { bytes: [0xFF], offset: 0, mask: [0xE0] }, // MP3 frame sync
  'audio/mp3': { bytes: [0xFF], offset: 0, mask: [0xE0] }, // MP3 alias
  'audio/wav': { bytes: [0x52, 0x49, 0x46, 0x46], offset: 0 }, // RIFF, then WAVE at offset 8
  'audio/wave': { bytes: [0x52, 0x49, 0x46, 0x46], offset: 0 }, // WAV alias
  'audio/x-wav': { bytes: [0x52, 0x49, 0x46, 0x46], offset: 0 }, // WAV alias
  'audio/ogg': { bytes: [0x4F, 0x67, 0x67, 0x53], offset: 0 },
  'audio/x-mpeg': { bytes: [0xFF], offset: 0, mask: [0xE0] }, // MP3 alias
}

// Additional signature patterns for more accurate detection
const SECONDARY_SIGNATURES: Record<string, { bytes: number[]; offset: number }[]> = {
  'image/webp': [{ bytes: [0x57, 0x45, 0x42, 0x50], offset: 8 }], // WEBP marker
  'audio/wav': [{ bytes: [0x57, 0x41, 0x56, 0x45], offset: 8 }], // WAVE marker
  'audio/wave': [{ bytes: [0x57, 0x41, 0x56, 0x45], offset: 8 }], // WAVE marker
  'audio/x-wav': [{ bytes: [0x57, 0x41, 0x56, 0x45], offset: 8 }], // WAVE marker
  'video/mp4': [
    { bytes: [0x66, 0x74, 0x79, 0x70], offset: 4 }, // ftyp
    { bytes: [0x6D, 0x70, 0x34, 0x32], offset: 8 }, // mp42
    { bytes: [0x69, 0x73, 0x6F, 0x6D], offset: 8 }, // isom
  ],
}

// File size limits (in bytes)
export const FILE_SIZE_LIMITS: Record<string, number> = {
  'image/jpeg': 50 * 1024 * 1024,    // 50MB
  'image/png': 50 * 1024 * 1024,     // 50MB
  'image/gif': 50 * 1024 * 1024,     // 50MB
  'image/webp': 50 * 1024 * 1024,    // 50MB
  'image/bmp': 50 * 1024 * 1024,     // 50MB
  'video/mp4': 500 * 1024 * 1024,    // 500MB
  'video/webm': 500 * 1024 * 1024,   // 500MB
  'video/quicktime': 500 * 1024 * 1024, // 500MB
  'audio/mpeg': 100 * 1024 * 1024,   // 100MB
  'audio/mp3': 100 * 1024 * 1024,    // 100MB
  'audio/wav': 100 * 1024 * 1024,    // 100MB
  'audio/wave': 100 * 1024 * 1024,   // 100MB
  'audio/ogg': 100 * 1024 * 1024,    // 100MB
  'audio/x-wav': 100 * 1024 * 1024,  // 100MB
  'audio/x-mpeg': 100 * 1024 * 1024, // 100MB
}

// Maximum total file size (absolute limit)
export const MAX_FILE_SIZE = 500 * 1024 * 1024 // 500MB

// Minimum file size (prevent empty or corrupted files)
export const MIN_FILE_SIZE = 100 // 100 bytes

// Allowed MIME types with extensions
export const ALLOWED_MIME_TYPES: Record<string, string[]> = {
  'image/jpeg': ['.jpg', '.jpeg', '.jpe', '.jfif'],
  'image/png': ['.png'],
  'image/gif': ['.gif'],
  'image/webp': ['.webp'],
  'image/bmp': ['.bmp'],
  'video/mp4': ['.mp4', '.m4v', '.m4p'],
  'video/webm': ['.webm'],
  'video/quicktime': ['.mov', '.qt'],
  'audio/mpeg': ['.mp3', '.mp2', '.mpga'],
  'audio/mp3': ['.mp3'], // Common alias for audio/mpeg
  'audio/wav': ['.wav', '.wave'],
  'audio/wave': ['.wav'], // Common alias
  'audio/ogg': ['.ogg', '.oga'],
  'audio/x-wav': ['.wav'], // Common alternative
  'audio/x-mpeg': ['.mp3'], // Common alternative
}

// Dangerous file extensions that should never be allowed
export const BLOCKED_EXTENSIONS = [
  '.exe', '.bat', '.cmd', '.com', '.pif', '.scr', '.vbs', '.js', '.jar',
  '.msi', '.app', '.deb', '.rpm', '.dmg', '.pkg', '.run', '.sh', '.bash',
  '.py', '.pyc', '.pyo', '.rb', '.pl', '.php', '.asp', '.aspx', '.jsp',
  '.cgi', '.dll', '.so', '.dylib', '.sys', '.drv', '.ocx', '.ax',
  '.zip', '.rar', '.7z', '.tar', '.gz', '.bz2', '.xz', '.iso',
  '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.pdf',
  '.html', '.htm', '.xml', '.json', '.yaml', '.yml', '.sql',
  '.key', '.pem', '.crt', '.cer', '.p12', '.pfx',
]

export interface ValidationResult {
  valid: boolean
  error?: string
  code?: string
  sanitizedValue?: unknown
}

export interface FileValidationResult {
  valid: boolean
  error?: string
  code?: string
  detectedMimeType?: string
  warnings?: string[]
}

/**
 * Verify file magic bytes to prevent file type spoofing
 */
export function verifyMagicBytes(buffer: Buffer, claimedMimeType: string): FileValidationResult {
  const warnings: string[] = []
  
  // Get expected signature for claimed MIME type
  const signature = MAGIC_BYTES[claimedMimeType]
  if (!signature) {
    return {
      valid: false,
      error: `Unsupported MIME type: ${claimedMimeType}`,
      code: 'UNSUPPORTED_MIME_TYPE'
    }
  }

  // Check if buffer is large enough
  if (buffer.length < signature.bytes.length + signature.offset) {
    return {
      valid: false,
      error: 'File is too small or corrupted',
      code: 'FILE_TOO_SMALL'
    }
  }

  // Verify primary signature
  let primaryMatch = true
  for (let i = 0; i < signature.bytes.length; i++) {
    const bufferByte = buffer[signature.offset + i]
    const expectedByte = signature.bytes[i]
    
    // Apply mask if present
    if (signature.mask && signature.mask[i]) {
      if ((bufferByte & signature.mask[i]) !== (expectedByte & signature.mask[i])) {
        primaryMatch = false
        break
      }
    } else if (bufferByte !== expectedByte) {
      primaryMatch = false
      break
    }
  }

  // Check secondary signatures if available
  const secondarySigs = SECONDARY_SIGNATURES[claimedMimeType]
  if (secondarySigs && primaryMatch) {
    let secondaryMatch = false
    for (const secSig of secondarySigs) {
      if (buffer.length >= secSig.offset + secSig.bytes.length) {
        let match = true
        for (let i = 0; i < secSig.bytes.length; i++) {
          if (buffer[secSig.offset + i] !== secSig.bytes[i]) {
            match = false
            break
          }
        }
        if (match) {
          secondaryMatch = true
          break
        }
      }
    }
    
    if (!secondaryMatch) {
      warnings.push('Secondary signature verification failed - file may have incorrect format')
    }
  }

  // Detect actual MIME type from magic bytes
  const detectedMimeType = detectMimeType(buffer)
  
  if (primaryMatch) {
    // If we detected a different MIME type, add warning
    if (detectedMimeType && detectedMimeType !== claimedMimeType) {
      // Allow some compatible types (e.g., video/quicktime vs video/mp4)
      const compatibleTypes: Record<string, string[]> = {
        'video/mp4': ['video/quicktime'],
        'video/quicktime': ['video/mp4'],
        'image/webp': ['audio/wav', 'audio/wave', 'audio/x-wav'], // Both use RIFF
        'audio/wav': ['image/webp'], // Both use RIFF
        'audio/wave': ['image/webp'], // Both use RIFF
        'audio/x-wav': ['image/webp'], // Both use RIFF
        'audio/mpeg': ['audio/mp3', 'audio/x-mpeg'],
        'audio/mp3': ['audio/mpeg', 'audio/x-mpeg'],
        'audio/x-mpeg': ['audio/mpeg', 'audio/mp3'],
      }
      
      if (!compatibleTypes[claimedMimeType]?.includes(detectedMimeType)) {
        return {
          valid: false,
          error: `File type mismatch: claimed ${claimedMimeType} but detected ${detectedMimeType}`,
          code: 'MIME_TYPE_MISMATCH',
          detectedMimeType,
          warnings
        }
      }
    }
    
    return {
      valid: true,
      detectedMimeType: claimedMimeType,
      warnings
    }
  }

  return {
    valid: false,
    error: `Invalid file signature for ${claimedMimeType}. Possible file type spoofing detected.`,
    code: 'INVALID_SIGNATURE',
    detectedMimeType,
    warnings
  }
}

/**
 * Detect MIME type from magic bytes
 */
export function detectMimeType(buffer: Buffer): string | null {
  if (buffer.length < 4) return null

  // Check each known signature
  for (const [mimeType, signature] of Object.entries(MAGIC_BYTES)) {
    if (buffer.length < signature.bytes.length + signature.offset) continue

    let match = true
    for (let i = 0; i < signature.bytes.length; i++) {
      const bufferByte = buffer[signature.offset + i]
      const expectedByte = signature.bytes[i]
      
      if (signature.mask && signature.mask[i]) {
        if ((bufferByte & signature.mask[i]) !== (expectedByte & signature.mask[i])) {
          match = false
          break
        }
      } else if (bufferByte !== expectedByte) {
        match = false
        break
      }
    }

    if (match) {
      // Verify secondary signatures if available
      const secondarySigs = SECONDARY_SIGNATURES[mimeType]
      if (secondarySigs) {
        for (const secSig of secondarySigs) {
          if (buffer.length >= secSig.offset + secSig.bytes.length) {
            let secMatch = true
            for (let i = 0; i < secSig.bytes.length; i++) {
              if (buffer[secSig.offset + i] !== secSig.bytes[i]) {
                secMatch = false
                break
              }
            }
            if (secMatch) return mimeType
          }
        }
      } else {
        return mimeType
      }
    }
  }

  return null
}

/**
 * Validate file extension matches MIME type
 */
export function validateFileExtension(filename: string, mimeType: string): ValidationResult {
  // Sanitize filename
  const sanitizedFilename = sanitizeFilename(filename)
  if (sanitizedFilename !== filename) {
    return {
      valid: false,
      error: 'Filename contains invalid characters',
      code: 'INVALID_FILENAME'
    }
  }

  // Extract extension
  const lastDotIndex = filename.toLowerCase().lastIndexOf('.')
  if (lastDotIndex === -1) {
    return {
      valid: false,
      error: 'File must have an extension',
      code: 'MISSING_EXTENSION'
    }
  }

  const extension = filename.toLowerCase().slice(lastDotIndex)

  // Check blocked extensions
  if (BLOCKED_EXTENSIONS.includes(extension)) {
    return {
      valid: false,
      error: `File extension ${extension} is not allowed for security reasons`,
      code: 'BLOCKED_EXTENSION'
    }
  }

  // Check extension matches MIME type
  const allowedExtensions = ALLOWED_MIME_TYPES[mimeType]
  if (!allowedExtensions) {
    return {
      valid: false,
      error: `MIME type ${mimeType} is not supported`,
      code: 'UNSUPPORTED_MIME_TYPE'
    }
  }

  if (!allowedExtensions.includes(extension)) {
    return {
      valid: false,
      error: `Extension ${extension} does not match MIME type ${mimeType}`,
      code: 'EXTENSION_MISMATCH'
    }
  }

  return { valid: true, sanitizedValue: filename }
}

/**
 * Validate file size
 */
export function validateFileSize(size: number, mimeType: string): ValidationResult {
  if (size < MIN_FILE_SIZE) {
    return {
      valid: false,
      error: `File is too small (${size} bytes). Minimum size is ${MIN_FILE_SIZE} bytes`,
      code: 'FILE_TOO_SMALL'
    }
  }

  if (size > MAX_FILE_SIZE) {
    return {
      valid: false,
      error: `File exceeds maximum size limit of ${MAX_FILE_SIZE / (1024 * 1024)}MB`,
      code: 'FILE_TOO_LARGE'
    }
  }

  const typeLimit = FILE_SIZE_LIMITS[mimeType]
  if (typeLimit && size > typeLimit) {
    return {
      valid: false,
      error: `File exceeds ${mimeType} size limit of ${typeLimit / (1024 * 1024)}MB`,
      code: 'FILE_TOO_LARGE'
    }
  }

  return { valid: true, sanitizedValue: size }
}

/**
 * Sanitize filename to prevent path traversal and other attacks
 */
export function sanitizeFilename(filename: string): string {
  // Remove path separators
  let sanitized = filename.replace(/[\/\\]/g, '')
  
  // Remove null bytes
  sanitized = sanitized.replace(/\0/g, '')
  
  // Remove control characters
  sanitized = sanitized.replace(/[\x00-\x1F\x7F]/g, '')
  
  // Remove leading dots (hidden files)
  sanitized = sanitized.replace(/^\.+/, '')
  
  // Limit length
  if (sanitized.length > 255) {
    const ext = sanitized.slice(sanitized.lastIndexOf('.'))
    sanitized = sanitized.slice(0, 255 - ext.length) + ext
  }
  
  return sanitized
}

/**
 * Comprehensive file validation
 */
export function validateFile(
  file: File,
  buffer: Buffer
): FileValidationResult {
  const errors: string[] = []
  const warnings: string[] = []
  let detectedMimeType: string | undefined

  // 1. Validate MIME type
  if (!ALLOWED_MIME_TYPES[file.type]) {
    return {
      valid: false,
      error: `Unsupported file type: ${file.type}`,
      code: 'UNSUPPORTED_MIME_TYPE'
    }
  }

  // 2. Validate file extension
  const extResult = validateFileExtension(file.name, file.type)
  if (!extResult.valid) {
    return {
      valid: false,
      error: extResult.error,
      code: extResult.code
    }
  }

  // 3. Validate file size
  const sizeResult = validateFileSize(file.size, file.type)
  if (!sizeResult.valid) {
    return {
      valid: false,
      error: sizeResult.error,
      code: sizeResult.code
    }
  }

  // 4. Verify magic bytes (most important security check)
  const magicResult = verifyMagicBytes(buffer, file.type)
  if (!magicResult.valid) {
    return magicResult
  }

  if (magicResult.warnings) {
    warnings.push(...magicResult.warnings)
  }
  detectedMimeType = magicResult.detectedMimeType

  // 5. Additional content checks
  // Check for embedded scripts or suspicious content
  const suspiciousPatterns = [
    /<script/i,
    /javascript:/i,
    /data:text\/html/i,
    /vbscript:/i,
    /on\w+\s*=/i, // Event handlers
  ]

  const contentPreview = buffer.slice(0, 10000).toString('utf8')
  for (const pattern of suspiciousPatterns) {
    if (pattern.test(contentPreview)) {
      warnings.push('File may contain suspicious content')
      break
    }
  }

  return {
    valid: true,
    detectedMimeType,
    warnings: warnings.length > 0 ? warnings : undefined
  }
}

/**
 * Sanitize string input to prevent XSS and injection
 */
export function sanitizeString(input: string, maxLength: number = 1000): ValidationResult {
  if (typeof input !== 'string') {
    return {
      valid: false,
      error: 'Input must be a string',
      code: 'INVALID_TYPE'
    }
  }

  if (input.length > maxLength) {
    return {
      valid: false,
      error: `Input exceeds maximum length of ${maxLength} characters`,
      code: 'INPUT_TOO_LONG'
    }
  }

  // Remove null bytes and control characters
  const sanitized = input
    .replace(/\0/g, '')
    .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '')

  return { valid: true, sanitizedValue: sanitized }
}

/**
 * Validate JSON analysis result from AI
 */
export function validateAnalysisResult(result: unknown): ValidationResult {
  if (!result || typeof result !== 'object') {
    return {
      valid: false,
      error: 'Invalid analysis result format',
      code: 'INVALID_FORMAT'
    }
  }

  const obj = result as Record<string, unknown>

  // Validate result field
  if (!['authentic', 'deepfake', 'uncertain'].includes(obj.result as string)) {
    return {
      valid: false,
      error: 'Invalid result value',
      code: 'INVALID_RESULT_VALUE'
    }
  }

  // Validate confidence
  const confidence = Number(obj.confidence)
  if (isNaN(confidence) || confidence < 0 || confidence > 1) {
    return {
      valid: false,
      error: 'Invalid confidence value',
      code: 'INVALID_CONFIDENCE'
    }
  }

  // Validate analysis string
  if (typeof obj.analysis !== 'string' || obj.analysis.length > 10000) {
    return {
      valid: false,
      error: 'Invalid analysis text',
      code: 'INVALID_ANALYSIS'
    }
  }

  // Validate indicators array
  if (!Array.isArray(obj.indicators)) {
    return {
      valid: false,
      error: 'Indicators must be an array',
      code: 'INVALID_INDICATORS'
    }
  }

  const sanitizedIndicators = obj.indicators
    .filter((i): i is string => typeof i === 'string')
    .map(i => i.slice(0, 100)) // Limit each indicator length
    .slice(0, 20) // Limit number of indicators

  return {
    valid: true,
    sanitizedValue: {
      result: obj.result,
      confidence: Math.round(confidence * 1000) / 1000, // 3 decimal places
      analysis: obj.analysis.slice(0, 10000),
      indicators: sanitizedIndicators
    }
  }
}
