'use client'

import { useState, useCallback } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { 
  Share2, 
  Copy, 
  Check, 
  Twitter, 
  MessageCircle,
  Download,
  CheckCircle,
  AlertTriangle,
  HelpCircle
} from 'lucide-react'

interface ShareableResultCardProps {
  result: 'authentic' | 'deepfake' | 'uncertain'
  confidence: number
  analysis: string
  indicators: string[]
  platform?: string
  thumbnailBase64?: string
}

const RESULT_CONFIG = {
  authentic: {
    icon: CheckCircle,
    color: 'text-green-500',
    bgColor: 'bg-green-500',
    label: 'AUTHENTIC',
    emoji: '✅'
  },
  deepfake: {
    icon: AlertTriangle,
    color: 'text-red-500',
    bgColor: 'bg-red-500',
    label: 'DEEPFAKE',
    emoji: '⚠️'
  },
  uncertain: {
    icon: HelpCircle,
    color: 'text-yellow-500',
    bgColor: 'bg-yellow-500',
    label: 'UNCERTAIN',
    emoji: '❓'
  }
}

export function ShareableResultCard({
  result,
  confidence,
  analysis,
  indicators,
  platform,
  thumbnailBase64
}: ShareableResultCardProps) {
  const [copied, setCopied] = useState(false)
  const config = RESULT_CONFIG[result]
  const Icon = config.icon
  const confidencePercent = Math.round(confidence * 100)

  const shareText = `${config.emoji} ${config.label} (${confidencePercent}%)\n\n${analysis}\n\nCheck your media at deepfake-detector.app`

  const shareToTwitter = useCallback(() => {
    const url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}`
    window.open(url, '_blank')
  }, [shareText])

  const shareToWhatsApp = useCallback(() => {
    const url = `https://wa.me/?text=${encodeURIComponent(shareText)}`
    window.open(url, '_blank')
  }, [shareText])

  const copyResult = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(shareText)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch {
      // Copy failed
    }
  }, [shareText])

  const downloadCard = useCallback(() => {
    // Create text content for download
    const content = `Deepfake Detection Result\n\n${config.emoji} ${config.label}\nConfidence: ${confidencePercent}%\n\nAnalysis:\n${analysis}\n\nIndicators:\n${indicators.join('\n')}\n\nVerified by Deepfake Detector`
    
    const blob = new Blob([content], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = `deepfake-result-${result}.txt`
    link.click()
    URL.revokeObjectURL(url)
  }, [analysis, confidencePercent, config.emoji, config.label, indicators, result])

  return (
    <Card className="overflow-hidden border-2">
      {/* Result Header */}
      <div className={`${config.bgColor} p-6 text-white text-center`}>
        <Icon className="h-16 w-16 mx-auto mb-3" />
        <h2 className="text-2xl font-bold">{config.label}</h2>
        <p className="text-white/80 mt-1">
          {config.emoji} {confidencePercent}% Confidence
        </p>
        {platform && (
          <Badge variant="secondary" className="mt-2">
            {platform}
          </Badge>
        )}
      </div>

      <CardContent className="p-4 space-y-4">
        {/* Analysis */}
        <div>
          <h3 className="font-semibold mb-2">Analysis</h3>
          <p className="text-sm text-muted-foreground">{analysis}</p>
        </div>

        {/* Indicators */}
        {indicators.length > 0 && (
          <div>
            <h3 className="font-semibold mb-2">Key Indicators</h3>
            <div className="flex flex-wrap gap-2">
              {indicators.slice(0, 6).map((indicator, i) => (
                <Badge key={i} variant="outline" className="text-xs">
                  {indicator}
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Share Buttons */}
        <div className="pt-4 border-t">
          <p className="text-sm text-muted-foreground mb-3 text-center">
            Share this result
          </p>
          <div className="flex gap-2">
            <Button
              variant="outline"
              className="flex-1"
              onClick={shareToTwitter}
            >
              <Twitter className="h-4 w-4 mr-2" />
              Tweet
            </Button>
            <Button
              variant="outline"
              className="flex-1"
              onClick={shareToWhatsApp}
            >
              <MessageCircle className="h-4 w-4 mr-2" />
              WhatsApp
            </Button>
            <Button
              variant="outline"
              className="flex-1"
              onClick={copyResult}
            >
              {copied ? (
                <>
                  <Check className="h-4 w-4 mr-2" />
                  Copied!
                </>
              ) : (
                <>
                  <Copy className="h-4 w-4 mr-2" />
                  Copy
                </>
              )}
            </Button>
          </div>
        </div>

        {/* Trust Badge */}
        <div className="text-center pt-2">
          <p className="text-xs text-muted-foreground">
            Verified by{' '}
            <span className="font-semibold bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">
              Deepfake Detector
            </span>
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
