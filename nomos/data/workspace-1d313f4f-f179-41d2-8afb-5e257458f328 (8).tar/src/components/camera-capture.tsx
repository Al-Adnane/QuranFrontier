'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Camera, X, SwitchCamera, Flashlight, Image as ImageIcon } from 'lucide-react'

interface CameraCaptureProps {
  onCapture: (file: File) => void
  onClose: () => void
}

export function CameraCapture({ onCapture, onClose }: CameraCaptureProps) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [stream, setStream] = useState<MediaStream | null>(null)
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('environment')
  const [error, setError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [hasFlash, setHasFlash] = useState(false)
  const [flashOn, setFlashOn] = useState(false)

  // Start camera
  const startCamera = useCallback(async () => {
    setIsLoading(true)
    setError(null)

    try {
      // Stop existing stream
      if (stream) {
        stream.getTracks().forEach(track => track.stop())
      }

      // Request camera access
      const newStream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode,
          width: { ideal: 1920 },
          height: { ideal: 1080 }
        },
        audio: false
      })

      setStream(newStream)

      if (videoRef.current) {
        videoRef.current.srcObject = newStream
        await videoRef.current.play()
      }

      // Check for flash support
      const track = newStream.getVideoTracks()[0]
      const capabilities = track.getCapabilities?.()
      if (capabilities?.torch) {
        setHasFlash(true)
      }
    } catch (err) {
      console.error('Camera error:', err)
      if (err instanceof Error) {
        if (err.name === 'NotAllowedError') {
          setError('Camera access denied. Please allow camera access to use this feature.')
        } else if (err.name === 'NotFoundError') {
          setError('No camera found on this device.')
        } else {
          setError(err.message)
        }
      } else {
        setError('Failed to access camera')
      }
    } finally {
      setIsLoading(false)
    }
  }, [facingMode, stream])

  // Initialize camera on mount
  useEffect(() => {
    startCamera()

    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop())
      }
    }
  }, [])

  // Switch camera
  const switchCamera = useCallback(() => {
    setFacingMode(prev => prev === 'user' ? 'environment' : 'user')
  }, [])

  // Toggle flash
  const toggleFlash = useCallback(async () => {
    if (!stream || !hasFlash) return

    const track = stream.getVideoTracks()[0]
    try {
      await track.applyConstraints({
        advanced: [{ torch: !flashOn } as MediaTrackConstraintSet]
      })
      setFlashOn(!flashOn)
    } catch (err) {
      console.error('Flash error:', err)
    }
  }, [stream, hasFlash, flashOn])

  // Capture photo
  const capturePhoto = useCallback(() => {
    if (!videoRef.current || !canvasRef.current) return

    const video = videoRef.current
    const canvas = canvasRef.current

    // Set canvas size to video size
    canvas.width = video.videoWidth
    canvas.height = video.videoHeight

    // Draw video frame to canvas
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    ctx.drawImage(video, 0, 0, canvas.width, canvas.height)

    // Convert to blob
    canvas.toBlob((blob) => {
      if (!blob) return

      // Create file from blob
      const file = new File([blob], `capture_${Date.now()}.jpg`, {
        type: 'image/jpeg'
      })

      onCapture(file)
    }, 'image/jpeg', 0.95)
  }, [onCapture])

  // Handle facing mode change
  useEffect(() => {
    if (stream) {
      startCamera()
    }
  }, [facingMode, startCamera, stream])

  return (
    <div className="fixed inset-0 z-50 bg-black">
      {/* Video Preview */}
      <video
        ref={videoRef}
        className="w-full h-full object-cover"
        playsInline
        autoPlay
        muted
      />

      {/* Hidden canvas for capture */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Loading overlay */}
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/80">
          <div className="text-center">
            <div className="animate-spin h-12 w-12 border-4 border-white border-t-transparent rounded-full mx-auto mb-4" />
            <p className="text-white">Starting camera...</p>
          </div>
        </div>
      )}

      {/* Error overlay */}
      {error && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/80 p-4">
          <Card className="max-w-sm w-full">
            <CardContent className="pt-6 text-center">
              <div className="text-4xl mb-4">📷</div>
              <h3 className="font-semibold mb-2">Camera Error</h3>
              <p className="text-sm text-muted-foreground mb-4">{error}</p>
              <div className="flex gap-2">
                <Button variant="outline" onClick={onClose} className="flex-1">
                  Cancel
                </Button>
                <Button onClick={startCamera} className="flex-1">
                  Retry
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Top bar */}
      <div className="absolute top-0 left-0 right-0 p-4 flex items-center justify-between bg-gradient-to-b from-black/60 to-transparent">
        <Button
          variant="ghost"
          size="icon"
          className="text-white hover:bg-white/20"
          onClick={onClose}
        >
          <X className="h-6 w-6" />
        </Button>

        <div className="flex gap-2">
          {hasFlash && (
            <Button
              variant="ghost"
              size="icon"
              className={`text-white hover:bg-white/20 ${flashOn ? 'bg-yellow-500/50' : ''}`}
              onClick={toggleFlash}
            >
              <Flashlight className="h-5 w-5" />
            </Button>
          )}

          <Button
            variant="ghost"
            size="icon"
            className="text-white hover:bg-white/20"
            onClick={switchCamera}
          >
            <SwitchCamera className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Bottom controls */}
      <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black/60 to-transparent">
        <div className="flex items-center justify-center gap-8">
          {/* Gallery button */}
          <label className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center cursor-pointer">
            <ImageIcon className="h-6 w-6 text-white" />
            <input
              type="file"
              accept="image/*,video/*"
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0]
                if (file) {
                  onCapture(file)
                }
              }}
            />
          </label>

          {/* Capture button */}
          <button
            onClick={capturePhoto}
            disabled={isLoading || !!error}
            className="w-20 h-20 rounded-full bg-white border-4 border-white/30 flex items-center justify-center transition-transform active:scale-95 disabled:opacity-50"
          >
            <div className="w-16 h-16 rounded-full bg-white" />
          </button>

          {/* Placeholder for symmetry */}
          <div className="w-12 h-12" />
        </div>

        <p className="text-white/60 text-center text-sm mt-4">
          Tap to capture • Long press for video
        </p>
      </div>
    </div>
  )
}
