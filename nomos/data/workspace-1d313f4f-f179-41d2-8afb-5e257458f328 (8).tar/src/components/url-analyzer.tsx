'use client'

import { useState, useCallback } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { 
  Link2, 
  Loader2, 
  AlertCircle, 
  ExternalLink,
  Share2,
  Copy,
  Check,
  ScanSearch
} from 'lucide-react'

interface URLAnalyzerProps {
  onResult: (result: {
    result: 'authentic' | 'deepfake' | 'uncertain'
    confidence: number
    analysis: string
    indicators: string[]
  }) => void
  onError: (error: string) => void
}

const PLATFORM_INFO = {
  tiktok: { name: 'TikTok', color: 'bg-black', icon: '🎵' },
  instagram: { name: 'Instagram', color: 'bg-pink-500', icon: '📸' },
  youtube: { name: 'YouTube', color: 'bg-red-500', icon: '▶️' },
  twitter: { name: 'Twitter/X', color: 'bg-blue-400', icon: '🐦' },
  facebook: { name: 'Facebook', color: 'bg-blue-600', icon: '👥' },
  unknown: { name: 'Website', color: 'bg-gray-500', icon: '🌐' }
}

export function URLAnalyzer({ onResult, onError }: URLAnalyzerProps) {
  const [url, setUrl] = useState('')
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [platform, setPlatform] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)

  const detectPlatform = (inputUrl: string): string => {
    if (inputUrl.includes('tiktok.com')) return 'tiktok'
    if (inputUrl.includes('instagram.com')) return 'instagram'
    if (inputUrl.includes('youtube.com') || inputUrl.includes('youtu.be')) return 'youtube'
    if (inputUrl.includes('twitter.com') || inputUrl.includes('x.com')) return 'twitter'
    if (inputUrl.includes('facebook.com')) return 'facebook'
    return 'unknown'
  }

  const handleUrlChange = useCallback((value: string) => {
    setUrl(value)
    setPlatform(detectPlatform(value))
  }, [])

  const analyzeURL = useCallback(async () => {
    if (!url.trim()) {
      onError('Please enter a URL')
      return
    }

    setIsAnalyzing(true)

    try {
      const response = await fetch('/api/analyze-url', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url })
      })

      const data = await response.json()

      if (data.success && data.result) {
        onResult(data.result)
      } else if (data.error) {
        // Show helpful error message
        onError(data.error)
      } else {
        onError('Could not analyze the URL. Please try uploading the file directly.')
      }
    } catch (error) {
      onError('Network error. Please check your connection and try again.')
    } finally {
      setIsAnalyzing(false)
    }
  }, [url, onResult, onError])

  const handlePaste = useCallback(async () => {
    try {
      const text = await navigator.clipboard.readText()
      handleUrlChange(text)
    } catch {
      // Clipboard access denied
    }
  }, [handleUrlChange])

  const copyError = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(url)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch {
      // Copy failed
    }
  }, [url])

  return (
    <Card className="border-purple-500/20 overflow-hidden">
      <CardContent className="p-4">
        <div className="space-y-4">
          {/* Header */}
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Link2 className="h-4 w-4" />
            <span>Paste a TikTok, Instagram, or YouTube link</span>
          </div>

          {/* URL Input */}
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Input
                type="url"
                placeholder="https://www.tiktok.com/@user/video/..."
                value={url}
                onChange={(e) => handleUrlChange(e.target.value)}
                className="pr-20 h-12 text-base"
                disabled={isAnalyzing}
              />
              {platform && (
                <Badge 
                  className={`absolute right-2 top-1/2 -translate-y-1/2 ${PLATFORM_INFO[platform as keyof typeof PLATFORM_INFO]?.color || 'bg-gray-500'} text-white`}
                >
                  {PLATFORM_INFO[platform as keyof typeof PLATFORM_INFO]?.icon} {PLATFORM_INFO[platform as keyof typeof PLATFORM_INFO]?.name}
                </Badge>
              )}
            </div>
            <Button
              variant="outline"
              size="icon"
              onClick={handlePaste}
              disabled={isAnalyzing}
              className="h-12 w-12 shrink-0"
            >
              <Copy className="h-4 w-4" />
            </Button>
          </div>

          {/* Analyze Button */}
          <Button
            onClick={analyzeURL}
            disabled={isAnalyzing || !url.trim()}
            className="w-full h-12 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-base font-medium"
          >
            {isAnalyzing ? (
              <>
                <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                Analyzing...
              </>
            ) : (
              <>
                <ScanSearch className="h-5 w-5 mr-2" />
                Analyze URL
              </>
            )}
          </Button>

          {/* Help text */}
          <p className="text-xs text-muted-foreground text-center">
            ⚡ Instant analysis • No signup required • 100% private
          </p>

          {/* Supported platforms */}
          <div className="flex justify-center gap-3 pt-2">
            {Object.entries(PLATFORM_INFO).slice(0, 5).map(([key, info]) => (
              <div 
                key={key}
                className={`w-8 h-8 rounded-full ${info.color} flex items-center justify-center text-xs`}
                title={info.name}
              >
                {info.icon}
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
