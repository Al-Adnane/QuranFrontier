/**
 * Deepfake Detector Browser Extension
 * Popup Script
 */

// Elements
const elements = {
  tabs: document.querySelectorAll('.tab'),
  tabContents: document.querySelectorAll('.tab-content'),
  rateLimitValue: document.getElementById('rateLimitValue'),
  urlInput: document.getElementById('urlInput'),
  scanUrlBtn: document.getElementById('scanUrlBtn'),
  uploadArea: document.getElementById('uploadArea'),
  fileInput: document.getElementById('fileInput'),
  progressSection: document.getElementById('progressSection'),
  resultSection: document.getElementById('resultSection'),
  resultIcon: document.getElementById('resultIcon'),
  resultTitle: document.getElementById('resultTitle'),
  resultConfidence: document.getElementById('resultConfidence'),
  resultAnalysis: document.getElementById('resultAnalysis'),
  resultIndicators: document.getElementById('resultIndicators'),
  historyList: document.getElementById('historyList'),
  historyEmpty: document.getElementById('historyEmpty'),
  clearHistoryBtn: document.getElementById('clearHistoryBtn'),
  apiEndpoint: document.getElementById('apiEndpoint'),
  saveSettingsBtn: document.getElementById('saveSettingsBtn'),
  notificationsEnabled: document.getElementById('notificationsEnabled'),
  alertOnDeepfake: document.getElementById('alertOnDeepfake')
};

// State
let currentTab = 'scan';
let isScanning = false;

/**
 * Initialize popup
 */
async function init() {
  // Tab switching
  elements.tabs.forEach(tab => {
    tab.addEventListener('click', () => switchTab(tab.dataset.tab));
  });

  // URL scan
  elements.scanUrlBtn.addEventListener('click', scanFromUrl);
  elements.urlInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') scanFromUrl();
  });

  // File upload
  elements.uploadArea.addEventListener('click', () => elements.fileInput.click());
  elements.fileInput.addEventListener('change', handleFileUpload);

  // Drag and drop
  elements.uploadArea.addEventListener('dragover', (e) => {
    e.preventDefault();
    elements.uploadArea.classList.add('dragover');
  });
  elements.uploadArea.addEventListener('dragleave', () => {
    elements.uploadArea.classList.remove('dragover');
  });
  elements.uploadArea.addEventListener('drop', handleFileDrop);

  // History
  elements.clearHistoryBtn.addEventListener('click', clearHistory);

  // Settings
  elements.saveSettingsBtn.addEventListener('click', saveSettings);

  // Load initial data
  await Promise.all([
    loadRateLimit(),
    loadHistory(),
    loadSettings()
  ]);
}

/**
 * Switch tab
 */
function switchTab(tab) {
  currentTab = tab;

  elements.tabs.forEach(t => {
    t.classList.toggle('active', t.dataset.tab === tab);
  });

  elements.tabContents.forEach(content => {
    content.classList.toggle('active', content.id === `${tab}-tab`);
  });

  // Refresh data when switching tabs
  if (tab === 'history') loadHistory();
  if (tab === 'scan') loadRateLimit();
}

/**
 * Load rate limit status
 */
async function loadRateLimit() {
  try {
    const response = await chrome.runtime.sendMessage({ type: 'GET_RATE_LIMIT' });
    elements.rateLimitValue.textContent = response.remaining;
  } catch (error) {
    elements.rateLimitValue.textContent = '10';
  }
}

/**
 * Scan from URL
 */
async function scanFromUrl() {
  const url = elements.urlInput.value.trim();
  if (!url || isScanning) return;

  // Validate URL
  try {
    new URL(url);
  } catch {
    showError('Please enter a valid URL');
    return;
  }

  // Detect media type
  const mediaType = detectMediaType(url);

  await performScan(() => 
    chrome.runtime.sendMessage({
      type: 'SCAN_URL',
      url,
      mediaType
    })
  );
}

/**
 * Handle file upload
 */
async function handleFileUpload(e) {
  const file = e.target.files?.[0];
  if (!file || isScanning) return;

  await scanFromFile(file);
}

/**
 * Handle file drop
 */
async function handleFileDrop(e) {
  e.preventDefault();
  elements.uploadArea.classList.remove('dragover');

  const file = e.dataTransfer?.files?.[0];
  if (!file || isScanning) return;

  await scanFromFile(file);
}

/**
 * Scan from file
 */
async function scanFromFile(file) {
  // Validate file type
  const validTypes = ['image/', 'video/', 'audio/'];
  if (!validTypes.some(t => file.type.startsWith(t))) {
    showError('Invalid file type. Please upload an image, video, or audio file.');
    return;
  }

  // Validate file size (500MB max)
  if (file.size > 500 * 1024 * 1024) {
    showError('File too large. Maximum size is 500MB.');
    return;
  }

  showProgress();

  try {
    // Convert to data URL
    const dataUrl = await fileToDataUrl(file);

    // Send to background for scanning
    const mediaType = file.type.split('/')[0];
    const response = await chrome.runtime.sendMessage({
      type: 'SCAN_URL',
      url: dataUrl,
      mediaType
    });

    if (response.success) {
      showResult(response.result);
      loadRateLimit();
    } else {
      showError(response.error || 'Scan failed');
    }
  } catch (error) {
    showError(error.message || 'Scan failed');
  } finally {
    hideProgress();
    elements.fileInput.value = '';
  }
}

/**
 * Perform scan with progress UI
 */
async function performScan(scanFn) {
  isScanning = true;
  showProgress();

  try {
    const response = await scanFn();

    if (response.success) {
      showResult(response.result);
      loadRateLimit();
    } else {
      showError(response.error || 'Scan failed');
    }
  } catch (error) {
    showError(error.message || 'Scan failed');
  } finally {
    isScanning = false;
    hideProgress();
  }
}

/**
 * Show progress
 */
function showProgress() {
  elements.progressSection.classList.remove('hidden');
  elements.resultSection.classList.add('hidden');
  elements.scanUrlBtn.disabled = true;
}

/**
 * Hide progress
 */
function hideProgress() {
  elements.progressSection.classList.add('hidden');
  elements.scanUrlBtn.disabled = false;
}

/**
 * Show result
 */
function showResult(result) {
  const config = {
    authentic: { icon: '✅', title: 'Authentic', class: 'authentic' },
    deepfake: { icon: '⚠️', title: 'Deepfake Detected', class: 'deepfake' },
    uncertain: { icon: '❓', title: 'Uncertain', class: 'uncertain' }
  };

  const c = config[result.result] || config.uncertain;

  elements.resultIcon.textContent = c.icon;
  elements.resultTitle.textContent = c.title;
  elements.resultTitle.className = `result-title ${c.class}`;
  elements.resultConfidence.textContent = `Confidence: ${(result.confidence * 100).toFixed(1)}%`;
  elements.resultAnalysis.textContent = result.analysis;

  // Indicators
  let indicators = [];
  try {
    indicators = JSON.parse(result.indicators);
  } catch (e) {}

  elements.resultIndicators.innerHTML = indicators
    .map(i => `<span class="indicator">${i}</span>`)
    .join('');

  elements.resultSection.classList.remove('hidden');
}

/**
 * Show error
 */
function showError(message) {
  elements.resultIcon.textContent = '❌';
  elements.resultTitle.textContent = 'Error';
  elements.resultTitle.className = 'result-title deepfake';
  elements.resultConfidence.textContent = '';
  elements.resultAnalysis.textContent = message;
  elements.resultIndicators.innerHTML = '';
  elements.resultSection.classList.remove('hidden');
}

/**
 * Load history
 */
async function loadHistory() {
  try {
    const response = await chrome.runtime.sendMessage({ type: 'GET_HISTORY' });
    
    if (response.success && response.history.length > 0) {
      elements.historyEmpty.classList.add('hidden');
      elements.historyList.classList.remove('hidden');
      
      elements.historyList.innerHTML = response.history
        .slice(0, 10)
        .map(item => createHistoryItem(item))
        .join('');
    } else {
      elements.historyEmpty.classList.remove('hidden');
      elements.historyList.classList.add('hidden');
    }
  } catch (error) {
    elements.historyEmpty.classList.remove('hidden');
    elements.historyList.classList.add('hidden');
  }
}

/**
 * Create history item HTML
 */
function createHistoryItem(item) {
  const iconMap = {
    image: { icon: '🖼️', class: 'image' },
    video: { icon: '🎬', class: 'video' },
    audio: { icon: '🎵', class: 'audio' }
  };

  const ic = iconMap[item.mediaType] || iconMap.image;

  return `
    <div class="history-item">
      <div class="history-icon ${ic.class}">${ic.icon}</div>
      <div class="history-info">
        <div class="history-name">${item.fileName || 'Unknown'}</div>
        <div class="history-meta">${new Date(item.scannedAt || item.createdAt).toLocaleDateString()}</div>
      </div>
      <span class="history-result ${item.result}">${item.result}</span>
    </div>
  `;
}

/**
 * Clear history
 */
async function clearHistory() {
  if (!confirm('Clear all scan history?')) return;
  
  await chrome.runtime.sendMessage({ type: 'CLEAR_HISTORY' });
  loadHistory();
}

/**
 * Load settings
 */
async function loadSettings() {
  const settings = await chrome.storage.local.get([
    'apiEndpoint',
    'notificationsEnabled',
    'alertOnDeepfake'
  ]);

  if (settings.apiEndpoint) {
    elements.apiEndpoint.value = settings.apiEndpoint;
  }
  elements.notificationsEnabled.checked = settings.notificationsEnabled !== false;
  elements.alertOnDeepfake.checked = settings.alertOnDeepfake !== false;
}

/**
 * Save settings
 */
async function saveSettings() {
  await chrome.storage.local.set({
    apiEndpoint: elements.apiEndpoint.value,
    notificationsEnabled: elements.notificationsEnabled.checked,
    alertOnDeepfake: elements.alertOnDeepfake.checked
  });

  // Show confirmation
  elements.saveSettingsBtn.textContent = 'Saved!';
  setTimeout(() => {
    elements.saveSettingsBtn.textContent = 'Save Settings';
  }, 1500);
}

/**
 * Detect media type from URL
 */
function detectMediaType(url) {
  const extension = url.split('.').pop().toLowerCase().split('?')[0];
  
  const imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'];
  const videoExtensions = ['mp4', 'webm', 'mov', 'avi'];
  const audioExtensions = ['mp3', 'wav', 'ogg', 'm4a'];

  if (imageExtensions.includes(extension)) return 'image';
  if (videoExtensions.includes(extension)) return 'video';
  if (audioExtensions.includes(extension)) return 'audio';
  
  return 'image'; // Default
}

/**
 * Convert file to data URL
 */
function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', init);
