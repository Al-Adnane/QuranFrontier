/**
 * Deepfake Detector Browser Extension
 * Content Script - Runs on all pages
 */

// Injected UI for displaying scan results
let resultOverlay = null;

/**
 * Create result overlay element
 */
function createResultOverlay() {
  if (resultOverlay) return resultOverlay;

  const overlay = document.createElement('div');
  overlay.id = 'deepfake-detector-overlay';
  overlay.innerHTML = `
    <div class="df-overlay-content">
      <div class="df-header">
        <div class="df-logo">🛡️</div>
        <div class="df-title">Deepfake Detector</div>
        <button class="df-close">&times;</button>
      </div>
      <div class="df-result">
        <div class="df-result-icon"></div>
        <div class="df-result-title"></div>
        <div class="df-confidence"></div>
        <div class="df-analysis"></div>
        <div class="df-indicators"></div>
      </div>
      <div class="df-footer">
        <span class="df-timestamp"></span>
      </div>
    </div>
  `;

  document.body.appendChild(overlay);
  resultOverlay = overlay;

  // Close button handler
  overlay.querySelector('.df-close').addEventListener('click', () => {
    hideResultOverlay();
  });

  // Click outside to close
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) {
      hideResultOverlay();
    }
  });

  return overlay;
}

/**
 * Show result overlay
 */
function showResultOverlay(result) {
  const overlay = createResultOverlay();
  
  const resultConfig = {
    authentic: {
      icon: '✅',
      title: 'Authentic Media',
      class: 'df-authentic'
    },
    deepfake: {
      icon: '⚠️',
      title: 'Deepfake Detected',
      class: 'df-deepfake'
    },
    uncertain: {
      icon: '❓',
      title: 'Uncertain Result',
      class: 'df-uncertain'
    }
  };

  const config = resultConfig[result.result] || resultConfig.uncertain;

  // Update content
  overlay.querySelector('.df-result-icon').textContent = config.icon;
  overlay.querySelector('.df-result-title').textContent = config.title;
  overlay.querySelector('.df-result-title').className = `df-result-title ${config.class}`;
  overlay.querySelector('.df-confidence').textContent = `Confidence: ${(result.confidence * 100).toFixed(1)}%`;
  overlay.querySelector('.df-analysis').textContent = result.analysis;
  overlay.querySelector('.df-timestamp').textContent = new Date().toLocaleString();

  // Indicators
  let indicators = [];
  try {
    indicators = JSON.parse(result.indicators);
  } catch (e) {
    indicators = [];
  }

  const indicatorsEl = overlay.querySelector('.df-indicators');
  indicatorsEl.innerHTML = indicators
    .map(i => `<span class="df-indicator">${i}</span>`)
    .join('');

  // Show overlay
  overlay.classList.add('df-visible');
}

/**
 * Hide result overlay
 */
function hideResultOverlay() {
  if (resultOverlay) {
    resultOverlay.classList.remove('df-visible');
  }
}

/**
 * Add scan buttons to media elements
 */
function addScanButtons() {
  // Add scan button to images
  document.querySelectorAll('img:not([data-df-scannable])').forEach(img => {
    img.setAttribute('data-df-scannable', 'true');
    
    if (img.width < 100 || img.height < 100) return; // Skip small images
    
    img.addEventListener('mouseenter', () => {
      showScanButton(img, 'image');
    });
  });

  // Add scan button to videos
  document.querySelectorAll('video:not([data-df-scannable])').forEach(video => {
    video.setAttribute('data-df-scannable', 'true');
    
    video.addEventListener('mouseenter', () => {
      showScanButton(video, 'video');
    });
  });
}

/**
 * Show floating scan button on hover
 */
function showScanButton(element, mediaType) {
  // Remove any existing scan buttons
  document.querySelectorAll('.df-scan-btn').forEach(btn => btn.remove());

  const btn = document.createElement('button');
  btn.className = 'df-scan-btn';
  btn.innerHTML = '🔍 Scan';
  btn.title = 'Scan for deepfake';

  // Position button
  const rect = element.getBoundingClientRect();
  btn.style.top = `${rect.top + window.scrollY + 10}px`;
  btn.style.left = `${rect.left + window.scrollX + 10}px`;

  btn.addEventListener('click', async (e) => {
    e.stopPropagation();
    e.preventDefault();

    btn.innerHTML = '⏳ Scanning...';
    btn.disabled = true;

    try {
      // Send scan request to background
      const response = await chrome.runtime.sendMessage({
        type: 'SCAN_URL',
        url: element.src || element.currentSrc,
        mediaType: mediaType
      });

      if (response.success) {
        showResultOverlay(response.result);
      } else {
        alert(`Scan failed: ${response.error}`);
      }
    } catch (error) {
      alert(`Scan failed: ${error.message}`);
    }

    btn.remove();
  });

  document.body.appendChild(btn);

  // Remove button when mouse leaves element
  const removeBtn = () => {
    setTimeout(() => {
      if (!btn.matches(':hover')) {
        btn.remove();
      }
    }, 1000);
  };

  element.addEventListener('mouseleave', removeBtn);
  btn.addEventListener('mouseleave', removeBtn);
}

/**
 * Listen for messages from background script
 */
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.type) {
    case 'SCAN_RESULT':
      showResultOverlay(message.result);
      sendResponse({ received: true });
      break;
  }
});

/**
 * Initialize content script
 */
function init() {
  // Add scan buttons to existing elements
  addScanButtons();

  // Watch for dynamically added elements
  const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      if (mutation.addedNodes.length > 0) {
        addScanButtons();
      }
    });
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });

  console.log('Deepfake Detector content script initialized');
}

// Run when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
