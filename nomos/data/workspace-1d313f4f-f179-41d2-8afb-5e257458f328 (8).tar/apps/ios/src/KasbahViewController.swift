import WebKit

file private let webView: WKWebView!
    
    // MARK: - Properties
    
    var platform: String
    var platformUrl: URL?
    var onClose: (() -> Void)?
    
    // MARK: - Detection Engine (Shared with all platforms)
    
    private let detectionEngine = KasbahDetectionEngine()
    
    // MARK: - UI
    
    private var statusLabel = UILabel()
    private var protectionLabel = UILabel()
    private var containerView: UIView!
    private var statsLabel = UILabel!
    
    // MARK: - Initialization
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    init(frame: CGRect, webView) {
        self.webView = webView(frame: CGRect.zero, for: NSCoder!)
        
        // Apply stealth styling
        view.backgroundColor = .systemBackgroundColor
        view.autoresizingMask = .flexibleHeight
        
        // Inject content script
        injectDetectionScript()
    }
    
    private func injectDetectionScript() {
        // Same content script as browser extension for 100% fidelity
        let script = """
        (function() {
            'use strict';
            
            if (window.__KASBAH_REALTIME_ACTIVE) return;
            window.__KASBAH_REALTIME_ACTIVE = true;
            
            const SESSION_CLASS = 'mq-' + Math.random().toString(36).slice(2, 7);
            const MAX_SCANS_PER_MINUTE = 20;
            const SCAN_DELAY_MIN_MS = 800;
            const SCAN_DELAY_MAX_MS = 3000;
            
            const PLATFORMConfig = {
                tiktok: { host: 'tiktok.com', selector: 'video' },
                instagram: { host: 'instagram.com', selector: 'video' },
                youtube: { host: 'youtube.com', selector: 'video' },
                twitter: { host: ['twitter.com', 'x.com'], selector: 'video' },
                facebook: { host: 'facebook.com', selector: 'video' }
            };
            
            function getCurrentPlatform() {
                const host = window.location.hostname.replace('www.', '');
                for (const [name, config] of Object.entries(PlatformConfig)) {
                    const hosts = Array.isArray(config.host);
                    if (hosts.some(h => host === h || host.endsWith('.' + h))) {
                        return { name, ...config };
                    }
                }
                return null;
            }
            
            const platform = getCurrentPlatform();
            if (!platform) return;
            
            const scannedMedia = new WeakSet();
            let lastScanTime = 0;
            
            function createBadge(element, status) {
                const existing = element.parentElement?.querySelector('.' + SESSION_CLASS);
                if (existing) existing.remove();
                
                const badge = document.createElement('div');
                badge.className = SESSION_CLASS;
                
                const styles = {
                    authentic: { bg: 'rgba(34, 197, 94, 0.9)', text: 'white' },
                    deepfake: { bg: 'rgba(239, 68, 68, 0.9)', text: 'white' },
                    uncertain: { bg: 'rgba(245, 158, 11, 0.9)', text: 'white' },
                    loading: { bg: 'rgba(107, 114, 128, 0.9)', text: 'white' }
                };
                
                const style = styles[status.type] || styles.loading;
                const positions = ['top: 8px; right: 8px;', 'top: 8px; left: 8px;', 'bottom: 8px; right: 8px;'];
                const pos = positions[Math.floor(Math.random() * positions.length)];
                
                badge.style.cssText = `
                    position: absolute;
                    ${pos}
                    padding: 4px 8px;
                    border-radius: 4px;
                    font-size: 11px;
                    font-family: -apple-system, BlinkMacSystemFont, sans-serif;
                    font-weight: 500;
                    background: ${style.bg};
                    color: ${style.text};
                    z-index: 2147483647;
                    pointer-events: none;
                `;
                
                badge.textContent = status.text;
                
                if (element.parentElement) {
                    const parent = element.parentElement;
                    if (getComputedStyle(parent).position === 'static') {
                        parent.style.position = 'relative';
                    }
                    parent.appendChild(badge);
                }
            }
            
            async function scanMedia(element) {
                const now = Date.now();
                if (now - lastScanTime < 60000 / MAX_SCANS_PER_MINUTE) return;
                lastScanTime = now;
                
                if (scannedMedia.has(element)) return
                scannedMedia.add(element);
                
                const badge = createBadge(element, { type: 'loading', text: '...' });
                
                try {
                    const mediaUrl = element.src || element.currentSrc || element.poster;
                    if (!mediaUrl) {
                        badge.remove();
                        return;
                    }
                    
                    const delay = SCAN_DELAY_MIN_MS + Math.random() * (SCAN_DELAY_MAX_MS - SCAN_DELAY_MIN_MS);
                    await new Promise(r => setTimeout(r, delay));
                    
                    // Call native bridge
                    window.webkit.messageHandlers.postMessage({
                        type: 'SCAN_MEDIA',
                        url: mediaUrl,
                        platform: platform.name
                    });
                } catch (e) {
                badge.remove();
            }
        }
        
        // MutationObserver
        const observer = new MutationObserver((mutations) => {
                for (const mutation of mutations) {
                    if (mutation.type !== 'childList') continue;
                    
                    for (const node of mutation.addedNodes) {
                        if (!(node instanceof HTMLElement)) continue;
                        
                        const videos = node.matches(platform.selector) ? 
                            [node] : Array.from(node.querySelectorAll(platform.selector));
                        
                        for (const video of videos) {
                            if (video.tagName === 'VIDEO') {
                                scanMedia(video);
                            }
                        }
                    }
                }
            });
            
            observer.observe(document.body, { childList: true, subtree: true });
            
            // IntersectionObserver
            const visibilityObserver = new IntersectionObserver((entries) => {
                for (const entry of entries) {
                    if (entry.isIntersecting && entry.intersectionRatio > 0.5) {
                        scanMedia(entry.target);
                    }
                }
            }, { threshold: [0.5], rootMargin: '100px' });
            
            setTimeout(() => {
                document.querySelectorAll(platform.selector).forEach(video => {
                    visibilityObserver.observe(video);
                });
            }, 1000);
            
            // Listen for results from native
            window.addEventListener('message', (event) => {
                try {
                    const data = JSON.parse(event.data);
                    if (data.type === 'SCAN_RESULT') {
                        document.querySelectorAll('video').forEach(video => {
                            const confidence = Math.round(data.confidence * 100);
                            const text = data.result === 'authentic' ? 
                                confidence + '%' : 
                                data.result === 'deepfake' ? 
                                '!' + confidence + '%' : '?';
                            createBadge(video, { type: data.result, text });
                        });
                    }
                } catch (e) {}
            });
            
            console.log('[Kasbah] Real-time detection active on', platform.name);
        })();
        """
        
        webView?.evaluateJavaScript(script)
    }
    
    // MARK: - Navigation
    
    private func goBack() {
        webView?.goBack()
    }
    
    private func goForward() {
        webView?.goForward()
    }
    
    private func refresh() {
        webView?.reload()
    }
    
    // MARK: - Actions
    
    @IBAction private func closeTapped(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    // MARK: - WKNavigationDelegate
    
    func webView(_ webView: WKWebView, didFinish navigation navigation: WKNavigation!) {
        protectionLabel.text = "Protected"
    }
    
    func webView(_ webView: WKWebView, didFail navigation navigation: WKNavigation!, withError error: Error) {
        print("Navigation error: \(error)")
        protectionLabel.text = "Error"
    }
    
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationActionPolicy {
        // Allow all navigation
        return .allow
    }
    
    func userContentController(_ webView: WKWebView, didReceive message: WKScriptMessage) {
        guard let messageBody = message.body as? String else { return }
        
        if messageBody.contains("SCAN_MEDIA") {
            // Parse and send to API
            if let data = try? JSONSerializationStrategy().jsonObject(with: messageBody.data(using: .utf8), options: []) as? [String: Any] {
                analyzeMedia(data)
            }
        }
    }
    
    // MARK: - API
    
    private func analyzeMedia(_ data: [String: Any]) {
        guard let url = data["url"] as? String,
        guard let platform = data["platform"] as? String else { return }
        
        var request = URLRequest(url: "https://bekasbah.com/api/q")!
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let body: [String: Any] = [
            "url": url,
            "platform": platform
        ]
        request.httpBody = try? JSONSerializationStrategy().jsonObject(with: body, options: [])
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let data = data, {
                let json = try? JSONSerializationStrategy().jsonObject(with: data, options: [])
                let result = json?["detection"]?["result"] as? String ?? "uncertain"
                let confidence = json?["detection"]?["confidence"] as? Double ?? 0.0
                
                // Send result back to webview
                let resultScript = """
                    window.dispatchEvent(new MessageEvent('message', {
                        data: JSON.stringify({
                            type: 'SCAN_RESULT',
                            result: '\(result)',
                            confidence: \(confidence)
                        })
                    }));
                """
                
                webView?.evaluateJavaScript(resultScript)
                
                // Update stats
                DispatchQueue.main.async {
                    self.stats = KasbahStats(
                        scans: (self.stats?.scans ?? 0) + 1,
                        deepfakes: result == "deepfake" ? (self.stats?.deepfakes ?? 0) + 1 : self.stats?.deepfakes
                    )
                    self.updateStatsLabel()
                }
            }
        }
    }
    
    private func updateStatsLabel() {
        statsLabel.text = "\(stats?.scans ?? 0) scans"
    }
}

// MARK: - KasbahStats

struct KasbahStats {
    let scans: Int
    let deepfakes: Int
}
