package com.kasbah.detector.accessibility;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import com.kasbah.detector.R;

/**
 * Detection Overlay Service
 * 
 * Shows stealth badges over media content in other apps.
 * Uses the same badge styling as the browser extension.
 */
public class DetectionOverlayService extends Service {

    private WindowManager windowManager;
    private View overlayView;
    private TextView badgeText;
    private Handler handler;
    private static final int OVERLAY_TIMEOUT = 10000; // 10 seconds

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        handler = new Handler(Looper.getMainLooper());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        
        Rect bounds = intent.getParcelableExtra("bounds");
        String text = intent.getStringExtra("text");
        String type = intent.getStringExtra("type");
        
        if (bounds == null) return START_NOT_STICKY;
        
        showOverlay(bounds, text, type);
        
        return START_NOT_STICKY;
    }

    private void showOverlay(Rect bounds, String text, String type) {
        // Remove existing overlay
        removeOverlay();
        
        // Create badge view
        overlayView = new TextView(this);
        overlayView.setText(text);
        overlayView.setTextSize(11);
        overlayView.setPadding(12, 6, 12, 6);
        overlayView.setGravity(Gravity.CENTER);
        
        // Apply stealth styling based on type
        int bgColor;
        int textColor = 0xFFFFFFFF; // White
        
        switch (type) {
            case "authentic":
                bgColor = 0xFF22C55E; // Emerald green
                break;
            case "deepfake":
                bgColor = 0xFFEF4444; // Red
                break;
            case "uncertain":
                bgColor = 0xFFF59E0B; // Amber
                break;
            default:
                bgColor = 0xFF6B7280; // Gray for loading
                break;
        }
        
        overlayView.setBackgroundColor(bgColor);
        overlayView.setTextColor(textColor);
        
        // Position overlay - randomize for stealth (same as extension)
        int[] positions = {Gravity.TOP | Gravity.END, Gravity.TOP | Gravity.START, Gravity.BOTTOM | Gravity.END};
        int position = positions[(int) (Math.random() * positions.length)];
        
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            position,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        );
        
        // Position near the media element
        int offsetX = (int) (Math.random() * 16) + 8;
        int offsetY = (int) (Math.random() * 16) + 8;
        params.x = bounds.right - offsetX;
        params.y = bounds.top + offsetY;
        
        try {
            windowManager.addView(overlayView, params);
            
            // Auto-remove after timeout
            handler.postDelayed(this::removeOverlay, OVERLAY_TIMEOUT);
        } catch (Exception e) {
            // Window might already exist or permission denied
        }
    }

    private void removeOverlay() {
        if (overlayView != null && overlayView.isAttachedToWindow()) {
            try {
                windowManager.removeView(overlayView);
            } catch (Exception e) {
                // View might already be removed
            }
            overlayView = null;
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        removeOverlay();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
