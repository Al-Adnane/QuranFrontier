import React, { useRef, useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  Platform,
} from 'react-native';
import { WebView, WebViewNavigation } from 'react-native-webview';
import { SafeAreaView } from 'react-native-safe-area-context';
import Icon from 'react-native-vector-icons/Feather';

import { Colors } from '../constants/Colors';
import { KasbahRealtime } from '../services/KasbahRealtime';

interface SocialBrowserProps {
  platform: {
    id: string;
    name: string;
    url: string;
  };
  onClose: () => void;
}

// Content script - IDENTICAL to browser extension for 100% fidelity
const CONTENT_SCRIPT = `
(function() {
  'use strict';
  
  if (window.__KASBAH_REALTIME_ACTIVE) return;
  window.__KASBAH_REALTIME_ACTIVE = true;
  
  // Stealth session class (same as extension)
  const SESSION_CLASS = 'mq-' + Math.random().toString(36).slice(2, 7);
  
  // Platform detection
  const PLATFORMS = {
    tiktok: { host: 'tiktok.com', selector: '[data-e2e="recommend-list-item-container"] video, video' },
    instagram: { host: 'instagram.com', selector: 'article video, video' },
    youtube: { host: 'youtube.com', selector: 'ytd-player video, #shorts-container video, video' },
    twitter: { host: ['twitter.com', 'x.com'], selector: '[data-testid="videoPlayer"] video, video' },
    facebook: { host: 'facebook.com', selector: '[data-pagelet="FeedUnit"] video, video' }
  };
  
  function getCurrentPlatform() {
    const host = window.location.hostname.replace('www.', '');
    for (const [name, config] of Object.entries(PLATFORMS)) {
      const hosts = Array.isArray(config.host) ? config.host : [config.host];
      if (hosts.some(h => host === h || host.endsWith('.' + h))) {
        return { name, ...config };
      }
    }
    return null;
  }
  
  const platform = getCurrentPlatform();
  if (!platform) return;
  
  const scannedMedia = new WeakSet();
  let lastScanTime = 0;
  const MAX_SCANS_PER_MINUTE = 20;
  
  // Stealth badge creation - SAME AS EXTENSION
  function createBadge(element, status) {
    const existing = element.parentElement?.querySelector('.' + SESSION_CLASS);
    if (existing) existing.remove();
    
    const badge = document.createElement('div');
    badge.className = SESSION_CLASS;
    
    const colors = {
      authentic: { bg: 'rgba(34, 197, 94, 0.9)', text: 'white' },
      deepfake: { bg: 'rgba(239, 68, 68, 0.9)', text: 'white' },
      uncertain: { bg: 'rgba(245, 158, 11, 0.9)', text: 'white' },
      loading: { bg: 'rgba(107, 114, 128, 0.9)', text: 'white' }
    };
    
    const color = colors[status.type] || colors.loading;
    
    // Randomize position for stealth
    const positions = ['top: 8px; right: 8px;', 'top: 8px; left: 8px;', 'bottom: 8px; right: 8px;'];
    const pos = positions[Math.floor(Math.random() * positions.length)];
    
    badge.style.cssText = \`
      position: absolute;
      \${pos}
      padding: 4px 8px;
      border-radius: 4px;
      font-size: 11px;
      font-family: -apple-system, BlinkMacSystemFont, sans-serif;
      font-weight: 500;
      background: \${color.bg};
      color: \${color.text};
      z-index: 9999;
      pointer-events: none;
      opacity: 0.95;
    \`;
    
    badge.textContent = status.text;
    
    if (element.parentElement) {
      const parent = element.parentElement;
      if (getComputedStyle(parent).position === 'static') {
        parent.style.position = 'relative';
      }
      parent.appendChild(badge);
    }
    
    return badge;
  }
  
  async function scanMedia(element) {
    const now = Date.now();
    if (now - lastScanTime < 60000 / MAX_SCANS_PER_MINUTE) return;
    lastScanTime = now;
    
    if (scannedMedia.has(element)) return;
    scannedMedia.add(element);
    
    const badge = createBadge(element, { type: 'loading', text: '...' });
    
    try {
      const mediaUrl = element.src || element.currentSrc || element.poster;
      if (!mediaUrl) {
        badge.remove();
        return;
      }
      
      // Random delay for stealth (same as extension)
      const delay = 800 + Math.random() * 2200;
      await new Promise(r => setTimeout(r, delay));
      
      // Post message to React Native for API call
      window.ReactNativeWebView.postMessage(JSON.stringify({
        type: 'SCAN_MEDIA',
        url: mediaUrl,
        platform: platform.name
      }));
      
    } catch (error) {
      badge.remove();
    }
  }
  
  // MutationObserver for dynamic content
  const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== 'childList') continue;
      
      for (const node of mutation.addedNodes) {
        if (!(node instanceof HTMLElement)) continue;
        
        const videos = node.matches(platform.selector) ? 
          [node] : 
          Array.from(node.querySelectorAll(platform.selector));
        
        for (const video of videos) {
          if (video.tagName === 'VIDEO') {
            scanMedia(video);
          }
        }
      }
    }
  });
  
  observer.observe(document.body, { childList: true, subtree: true });
  
  // IntersectionObserver for visibility
  const visibilityObserver = new IntersectionObserver((entries) => {
    for (const entry of entries) {
      if (entry.isIntersecting && entry.intersectionRatio > 0.5) {
        scanMedia(entry.target);
      }
    }
  }, { threshold: [0.5], rootMargin: '100px' });
  
  // Initial scan
  setTimeout(() => {
    document.querySelectorAll(platform.selector).forEach(video => {
      visibilityObserver.observe(video);
    });
  }, 1000);
  
  // Listen for scan results from React Native
  window.addEventListener('message', (event) => {
    try {
      const data = JSON.parse(event.data);
      if (data.type === 'SCAN_RESULT') {
        // Find videos and update badges
        document.querySelectorAll('video').forEach(video => {
          const confidence = Math.round(data.confidence * 100);
          const text = data.result === 'authentic' ? 
            confidence + '%' : 
            data.result === 'deepfake' ? 
            '!' + confidence + '%' : '?';
            
          createBadge(video, { type: data.result, text });
        });
      }
    } catch (e) {}
  });
  
  console.log('[Kasbah] Real-time detection active on', platform.name);
})();
`;

export function SocialBrowser({ platform, onClose }: SocialBrowserProps) {
  const webViewRef = useRef<WebView>(null);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({ scans: 0, deepfakes: 0 });
  const [canGoBack, setCanGoBack] = useState(false);
  const [canGoForward, setCanGoForward] = useState(false);

  useEffect(() => {
    // Load stats
    KasbahRealtime.getStats().then(s => {
      setStats({ scans: s.scansToday, deepfakes: s.deepfakesFound });
    });
  }, []);

  const handleNavigationStateChange = (navState: WebViewNavigation) => {
    setCanGoBack(navState.canGoBack);
    setCanGoForward(navState.canGoForward);
  };

  const handleMessage = useCallback(async (event: any) => {
    try {
      const data = JSON.parse(event.nativeEvent.data);
      
      if (data.type === 'SCAN_MEDIA') {
        // Call detection API
        try {
          const response = await fetch('https://bekasbah.com/api/q', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ url: data.url, platform: data.platform }),
          });
          
          if (response.ok) {
            const result = await response.json();
            
            // Send result back to WebView
            webViewRef.current?.injectJavaScript(`
              window.postMessage(JSON.stringify({
                type: 'SCAN_RESULT',
                result: '${result.detection?.result || 'uncertain'}',
                confidence: ${result.detection?.confidence || 0.5}
              }));
            `);
            
            // Update stats
            setStats(prev => ({
              ...prev,
              scans: prev.scans + 1,
              deepfakes: result.detection?.result === 'deepfake' ? prev.deepfakes + 1 : prev.deepfakes,
            }));
          }
        } catch (error) {
          console.error('Scan failed:', error);
        }
      }
    } catch (e) {
      // Ignore non-JSON messages
    }
  }, []);

  const goBack = () => {
    webViewRef.current?.goBack();
  };

  const goForward = () => {
    webViewRef.current?.goForward();
  };

  const refresh = () => {
    webViewRef.current?.reload();
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={onClose} style={styles.closeButton}>
          <Icon name="x" size={24} color={Colors.text} />
        </TouchableOpacity>
        
        <View style={styles.headerInfo}>
          <Text style={styles.platformName}>{platform.name}</Text>
          <Text style={styles.protectionStatus}>
            <Icon name="shield" size={12} color={Colors.emerald} /> Protected
          </Text>
        </View>
        
        <View style={styles.headerStats}>
          <Text style={styles.statText}>{stats.scans} scans</Text>
          {stats.deepfakes > 0 && (
            <Text style={[styles.statText, { color: Colors.red }]}>
              {stats.deepfakes} found
            </Text>
          )}
        </View>
      </View>

      {/* Navigation */}
      <View style={styles.navBar}>
        <TouchableOpacity 
          onPress={goBack} 
          disabled={!canGoBack}
          style={[styles.navButton, !canGoBack && styles.navButtonDisabled]}
        >
          <Icon name="chevron-left" size={20} color={canGoBack ? Colors.text : Colors.muted} />
        </TouchableOpacity>
        
        <TouchableOpacity 
          onPress={goForward} 
          disabled={!canGoForward}
          style={[styles.navButton, !canGoForward && styles.navButtonDisabled]}
        >
          <Icon name="chevron-right" size={20} color={canGoForward ? Colors.text : Colors.muted} />
        </TouchableOpacity>
        
        <TouchableOpacity onPress={refresh} style={styles.navButton}>
          <Icon name="refresh-cw" size={18} color={Colors.text} />
        </TouchableOpacity>
      </View>

      {/* WebView */}
      <View style={styles.webViewContainer}>
        <WebView
          ref={webViewRef}
          source={{ uri: platform.url }}
          style={styles.webView}
          onNavigationStateChange={handleNavigationStateChange}
          onLoadStart={() => setLoading(true)}
          onLoadEnd={() => setLoading(false)}
          onMessage={handleMessage}
          injectedJavaScript={CONTENT_SCRIPT}
          javaScriptEnabled={true}
          domStorageEnabled={true}
          allowsInlineMediaPlayback={true}
          mediaPlaybackRequiresUserAction={false}
          sharedCookiesEnabled={true}
          thirdPartyCookiesEnabled={true}
          userAgent="Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        />
        
        {loading && (
          <View style={styles.loadingOverlay}>
            <ActivityIndicator size="large" color={Colors.violet} />
          </View>
        )}
      </View>

      {/* Footer */}
      <View style={styles.footer}>
        <View style={styles.footerInfo}>
          <Icon name="eye" size={14} color={Colors.emerald} />
          <Text style={styles.footerText}>Real-time detection active</Text>
        </View>
        <View style={styles.footerInfo}>
          <Icon name="lock" size={14} color={Colors.violet} />
          <Text style={styles.footerText}>Stealth mode</Text>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    backgroundColor: Colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  closeButton: {
    padding: 8,
  },
  headerInfo: {
    flex: 1,
    marginLeft: 8,
  },
  platformName: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.text,
  },
  protectionStatus: {
    fontSize: 12,
    color: Colors.emerald,
    marginTop: 2,
  },
  headerStats: {
    alignItems: 'flex-end',
  },
  statText: {
    fontSize: 12,
    color: Colors.muted,
  },
  navBar: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 8,
    backgroundColor: Colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
    gap: 8,
  },
  navButton: {
    padding: 8,
    borderRadius: 8,
    backgroundColor: Colors.surfaceLight,
  },
  navButtonDisabled: {
    opacity: 0.5,
  },
  webViewContainer: {
    flex: 1,
    position: 'relative',
  },
  webView: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  loadingOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: Colors.background + 'CC',
    alignItems: 'center',
    justifyContent: 'center',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    padding: 12,
    backgroundColor: Colors.surface,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
  },
  footerInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  footerText: {
    fontSize: 12,
    color: Colors.muted,
  },
});
