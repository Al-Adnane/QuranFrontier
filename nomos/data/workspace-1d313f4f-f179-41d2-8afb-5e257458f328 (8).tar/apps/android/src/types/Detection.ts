export interface DetectionResult {
  id: string;
  result: 'authentic' | 'deepfake' | 'uncertain';
  confidence: number;
  analysis: string;
  indicators: string[];
  metadata: {
    file_name: string;
    file_size: number;
    media_type: string;
    analyzed_at: string;
    dimensions?: [number, number];
  };
  threat_level: 'minimal' | 'low' | 'medium' | 'high' | 'critical';
  moats_passed: string[];
}

export interface SecretPattern {
  name: string;
  pattern: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
}

export interface ScanResult {
  hasSecret: boolean;
  patterns: string[];
  risk: 'none' | 'low' | 'medium' | 'high' | 'critical';
}

export interface AppStats {
  totalScans: number;
  deepfakesFound: number;
  secretsBlocked: number;
}

export interface AppSettings {
  notifications: boolean;
  autoScan: boolean;
  saveHistory: boolean;
  analytics: boolean;
}
