import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  ScrollView,
  Share,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { launchCamera, launchImageLibrary, ImagePickerResponse } from 'react-native-image-picker';
import Icon from 'react-native-vector-icons/Feather';

import { Colors } from '../constants/Colors';
import { DetectionService } from '../services/DetectionService';
import { DetectionResult } from '../types/Detection';

export default function ScanScreen(): React.JSX.Element {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<DetectionResult | null>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const handleCamera = useCallback(() => {
    launchCamera(
      {
        mediaType: 'photo',
        quality: 0.8,
        saveToPhotos: false,
      },
      handleImageResponse
    );
  }, []);

  const handleGallery = useCallback(() => {
    launchImageLibrary(
      {
        mediaType: 'photo',
        quality: 0.8,
        selectionLimit: 1,
      },
      handleImageResponse
    );
  }, []);

  const handleImageResponse = async (response: ImagePickerResponse) => {
    if (response.didCancel || response.errorCode) {
      return;
    }

    const asset = response.assets?.[0];
    if (!asset?.uri) return;

    setSelectedImage(asset.uri);
    setIsAnalyzing(true);
    setResult(null);

    try {
      const detectionResult = await DetectionService.analyzeImage(asset.uri);
      setResult(detectionResult);
    } catch (error) {
      Alert.alert('Error', 'Failed to analyze image. Please try again.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleShare = async () => {
    if (!result) return;

    try {
      await Share.share({
        message: `Kasbah Detection Result: ${result.result.toUpperCase()}\nConfidence: ${Math.round(result.confidence * 100)}%\n\n${result.analysis}`,
      });
    } catch (error) {
      // Ignore share errors
    }
  };

  const getResultColor = (r: string) => {
    switch (r) {
      case 'authentic': return Colors.emerald;
      case 'deepfake': return Colors.red;
      default: return Colors.amber;
    }
  };

  const getResultIcon = (r: string) => {
    switch (r) {
      case 'authentic': return 'check-circle';
      case 'deepfake': return 'alert-triangle';
      default: return 'help-circle';
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* Header */}
        <View style={styles.header}>
          <Icon name="shield" size={32} color={Colors.violet} />
          <Text style={styles.title}>Deepfake Detector</Text>
          <Text style={styles.subtitle}>Analyze images for AI manipulation</Text>
        </View>

        {/* Action Buttons */}
        <View style={styles.actions}>
          <TouchableOpacity style={styles.actionButton} onPress={handleCamera}>
            <Icon name="camera" size={28} color={Colors.text} />
            <Text style={styles.actionText}>Camera</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.actionButton} onPress={handleGallery}>
            <Icon name="image" size={28} color={Colors.text} />
            <Text style={styles.actionText}>Gallery</Text>
          </TouchableOpacity>
        </View>

        {/* Analyzing Indicator */}
        {isAnalyzing && (
          <View style={styles.analyzingContainer}>
            <ActivityIndicator size="large" color={Colors.violet} />
            <Text style={styles.analyzingText}>Analyzing...</Text>
          </View>
        )}

        {/* Result */}
        {result && !isAnalyzing && (
          <View style={[styles.resultCard, { borderColor: getResultColor(result.result) }]}>
            <View style={[styles.resultHeader, { backgroundColor: getResultColor(result.result) }]}>
              <Icon name={getResultIcon(result.result)} size={24} color="#fff" />
              <Text style={styles.resultTitle}>{result.result.toUpperCase()}</Text>
              <View style={styles.confidenceBadge}>
                <Text style={styles.confidenceText}>{Math.round(result.confidence * 100)}%</Text>
              </View>
            </View>

            <View style={styles.resultBody}>
              <Text style={styles.analysis}>{result.analysis}</Text>

              {result.indicators.length > 0 && (
                <View style={styles.indicatorsContainer}>
                  <Text style={styles.indicatorsTitle}>Indicators</Text>
                  {result.indicators.map((ind, i) => (
                    <View key={i} style={styles.indicatorItem}>
                      <Text style={styles.indicatorText}>• {ind}</Text>
                    </View>
                  ))}
                </View>
              )}

              <TouchableOpacity style={styles.shareButton} onPress={handleShare}>
                <Icon name="share-2" size={18} color={Colors.text} />
                <Text style={styles.shareButtonText}>Share Result</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* Info Section */}
        <View style={styles.infoSection}>
          <Text style={styles.infoTitle}>14 Security Moats</Text>
          <View style={styles.moatsGrid}>
            {['Frequency Analysis', 'Texture Check', 'Edge Detection', 'Color Analysis', 'Noise Patterns'].map((moat, i) => (
              <View key={i} style={styles.moatItem}>
                <Icon name="check" size={14} color={Colors.emerald} />
                <Text style={styles.moatText}>{moat}</Text>
              </View>
            ))}
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scrollContent: {
    padding: 20,
  },
  header: {
    alignItems: 'center',
    marginBottom: 30,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: Colors.text,
    marginTop: 10,
  },
  subtitle: {
    fontSize: 14,
    color: Colors.muted,
    marginTop: 5,
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 20,
    marginBottom: 30,
  },
  actionButton: {
    width: 120,
    height: 120,
    borderRadius: 16,
    backgroundColor: Colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: Colors.border,
  },
  actionText: {
    marginTop: 10,
    fontSize: 14,
    color: Colors.textSecondary,
  },
  analyzingContainer: {
    alignItems: 'center',
    padding: 30,
  },
  analyzingText: {
    marginTop: 15,
    fontSize: 16,
    color: Colors.violet,
  },
  resultCard: {
    borderRadius: 16,
    borderWidth: 2,
    overflow: 'hidden',
    marginBottom: 20,
  },
  resultHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    gap: 12,
  },
  resultTitle: {
    flex: 1,
    fontSize: 18,
    fontWeight: '700',
    color: '#fff',
  },
  confidenceBadge: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.2)',
  },
  confidenceText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#fff',
  },
  resultBody: {
    padding: 16,
    backgroundColor: Colors.surface,
  },
  analysis: {
    fontSize: 15,
    lineHeight: 22,
    color: Colors.text,
    marginBottom: 16,
  },
  indicatorsContainer: {
    marginBottom: 16,
  },
  indicatorsTitle: {
    fontSize: 12,
    color: Colors.muted,
    marginBottom: 8,
    textTransform: 'uppercase',
  },
  indicatorItem: {
    marginBottom: 4,
  },
  indicatorText: {
    fontSize: 13,
    color: Colors.textSecondary,
  },
  shareButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    padding: 12,
    borderRadius: 8,
    backgroundColor: Colors.surfaceLight,
  },
  shareButtonText: {
    fontSize: 14,
    color: Colors.text,
  },
  infoSection: {
    padding: 20,
    backgroundColor: Colors.surface,
    borderRadius: 16,
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 16,
  },
  moatsGrid: {
    gap: 10,
  },
  moatItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  moatText: {
    fontSize: 13,
    color: Colors.textSecondary,
  },
});
