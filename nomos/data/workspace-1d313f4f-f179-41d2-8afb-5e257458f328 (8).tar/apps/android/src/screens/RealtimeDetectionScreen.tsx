import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Alert,
  Switch,
  Linking,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Icon from 'react-native-vector-icons/Feather';

import { Colors } from '../constants/Colors';
import { KasbahRealtime, DetectionResult } from '../services/KasbahRealtime';
import { SocialBrowser } from '../components/SocialBrowser';

interface Platform {
  id: string;
  name: string;
  url: string;
  icon: string;
  color: string;
}

const PLATFORMS: Platform[] = [
  { id: 'tiktok', name: 'TikTok', url: 'https://www.tiktok.com', icon: 'music', color: '#FF0050' },
  { id: 'instagram', name: 'Instagram', url: 'https://www.instagram.com', icon: 'camera', color: '#E4405F' },
  { id: 'youtube', name: 'YouTube', url: 'https://www.youtube.com', icon: 'youtube', color: '#FF0000' },
  { id: 'twitter', name: 'Twitter/X', url: 'https://www.twitter.com', icon: 'twitter', color: '#1DA1F2' },
  { id: 'facebook', name: 'Facebook', url: 'https://www.facebook.com', icon: 'facebook', color: '#1877F2' },
  { id: 'linkedin', name: 'LinkedIn', url: 'https://www.linkedin.com', icon: 'linkedin', color: '#0A66C2' },
];

export function RealtimeDetectionScreen() {
  const [selectedPlatform, setSelectedPlatform] = useState<Platform | null>(null);
  const [accessibilityEnabled, setAccessibilityEnabled] = useState(false);
  const [stats, setStats] = useState({ scans: 0, deepfakes: 0, secrets: 0 });

  const loadStats = useCallback(async () => {
    const s = await KasbahRealtime.getStats();
    setStats({ scans: s.scansToday, deepfakes: s.deepfakesFound, secrets: s.secretsBlocked });
  }, []);

  React.useEffect(() => {
    let mounted = true;
    
    const init = async () => {
      const enabled = await KasbahRealtime.isAccessibilityEnabled();
      if (mounted) {
        setAccessibilityEnabled(enabled);
      }
      
      const s = await KasbahRealtime.getStats();
      if (mounted) {
        setStats({ scans: s.scansToday, deepfakes: s.deepfakesFound, secrets: s.secretsBlocked });
      }
    };
    
    init();
    
    return () => {
      mounted = false;
    };
  }, []);

  const openPlatform = async (platform: Platform) => {
    // Check if system-wide detection is available
    if (Platform.OS === 'android') {
      const enabled = await KasbahRealtime.isAccessibilityEnabled();
      
      if (!enabled) {
        Alert.alert(
          'Enable Real-Time Protection',
          'To detect deepfakes while scrolling, Kasbah needs accessibility access. This allows the app to:\n\n' +
          '• Scan videos and images as you scroll\n' +
          '• Show safety badges on content\n' +
          '• Protect your secrets from leaks\n\n' +
          'Your data never leaves your device.',
          [
            { text: 'Cancel', style: 'cancel' },
            { 
              text: 'Enable', 
              onPress: () => {
                KasbahRealtime.openAccessibilitySettings();
              }
            }
          ]
        );
        return;
      }
    }
    
    // Open the social browser with detection
    setSelectedPlatform(platform);
  };

  const closeBrowser = () => {
    setSelectedPlatform(null);
    loadStats();
  };

  // If browser is open, show it instead
  if (selectedPlatform) {
    return <SocialBrowser platform={selectedPlatform} onClose={closeBrowser} />;
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.headerIcon}>
            <Icon name="eye" size={28} color={Colors.violet} />
          </View>
          <Text style={styles.title}>Real-Time Detection</Text>
          <Text style={styles.subtitle}>
            Browse social media with automatic deepfake protection
          </Text>
        </View>

        {/* Status Banner */}
        <View style={[styles.statusBanner, accessibilityEnabled ? styles.enabled : styles.disabled]}>
          <Icon 
            name={accessibilityEnabled ? 'check-circle' : 'alert-circle'} 
            size={20} 
            color={accessibilityEnabled ? Colors.emerald : Colors.amber} 
          />
          <Text style={[styles.statusText, accessibilityEnabled ? styles.enabledText : styles.disabledText]}>
            {accessibilityEnabled ? 'System-Wide Protection Active' : 'Limited Protection - Enable Accessibility'}
          </Text>
        </View>

        {/* Stats */}
        <View style={styles.statsContainer}>
          <View style={styles.statItem}>
            <Text style={styles.statValue}>{stats.scans}</Text>
            <Text style={styles.statLabel}>Scans Today</Text>
          </View>
          <View style={styles.statItem}>
            <Text style={[styles.statValue, { color: Colors.red }]}>{stats.deepfakes}</Text>
            <Text style={styles.statLabel}>Deepfakes Found</Text>
          </View>
          <View style={styles.statItem}>
            <Text style={[styles.statValue, { color: Colors.amber }]}>{stats.secrets}</Text>
            <Text style={styles.statLabel}>Secrets Blocked</Text>
          </View>
        </View>

        {/* Platforms */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Protected Platforms</Text>
          <Text style={styles.sectionSubtitle}>Tap to open with real-time detection</Text>
          
          <View style={styles.platformsGrid}>
            {PLATFORMS.map((platform) => (
              <TouchableOpacity
                key={platform.id}
                style={styles.platformCard}
                onPress={() => openPlatform(platform)}
                activeOpacity={0.7}
              >
                <View style={[styles.platformIcon, { backgroundColor: platform.color }]}>
                  <Icon name={platform.icon as any} size={24} color="white" />
                </View>
                <Text style={styles.platformName}>{platform.name}</Text>
                <View style={styles.platformBadge}>
                  <Icon name="shield" size={12} color={Colors.emerald} />
                  <Text style={styles.platformBadgeText}>Protected</Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Features */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Active Protections</Text>
          
          <View style={styles.featuresList}>
            <View style={styles.featureItem}>
              <Icon name="eye" size={18} color={Colors.emerald} />
              <Text style={styles.featureText}>Real-time scanning while scrolling</Text>
            </View>
            <View style={styles.featureItem}>
              <Icon name="lock" size={18} color={Colors.violet} />
              <Text style={styles.featureText}>Stealth badges (looks like quality score)</Text>
            </View>
            <View style={styles.featureItem}>
              <Icon name="shield" size={18} color={Colors.amber} />
              <Text style={styles.featureText}>14 security moats active</Text>
            </View>
            <View style={styles.featureItem}>
              <Icon name="key" size={18} color={Colors.red} />
              <Text style={styles.featureText}>Secret exfiltration protection</Text>
            </View>
          </View>
        </View>

        {/* How It Works */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>How It Works</Text>
          
          <View style={styles.stepsList}>
            <View style={styles.stepItem}>
              <View style={styles.stepNumber}>
                <Text style={styles.stepNumberText}>1</Text>
              </View>
              <Text style={styles.stepText}>Open any platform above</Text>
            </View>
            <View style={styles.stepItem}>
              <View style={styles.stepNumber}>
                <Text style={styles.stepNumberText}>2</Text>
              </View>
              <Text style={styles.stepText}>Scroll through your feed normally</Text>
            </View>
            <View style={styles.stepItem}>
              <View style={styles.stepNumber}>
                <Text style={styles.stepNumberText}>3</Text>
              </View>
              <Text style={styles.stepText}>See badges: 87% = authentic, !72% = suspicious</Text>
            </View>
          </View>
        </View>

        {/* Enable Button */}
        {!accessibilityEnabled && (
          <TouchableOpacity 
            style={styles.enableButton}
            onPress={() => KasbahRealtime.openAccessibilitySettings()}
          >
            <Icon name="shield" size={20} color="white" />
            <Text style={styles.enableButtonText}>Enable System-Wide Protection</Text>
          </TouchableOpacity>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scrollContent: {
    padding: 20,
  },
  header: {
    alignItems: 'center',
    marginBottom: 24,
  },
  headerIcon: {
    width: 56,
    height: 56,
    borderRadius: 16,
    backgroundColor: Colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: Colors.text,
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 14,
    color: Colors.muted,
    textAlign: 'center',
  },
  statusBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderRadius: 12,
    marginBottom: 20,
    gap: 10,
  },
  enabled: {
    backgroundColor: 'rgba(34, 197, 94, 0.1)',
  },
  disabled: {
    backgroundColor: 'rgba(245, 158, 11, 0.1)',
  },
  statusText: {
    fontSize: 14,
    fontWeight: '500',
  },
  enabledText: {
    color: Colors.emerald,
  },
  disabledText: {
    color: Colors.amber,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: Colors.surface,
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
  },
  statItem: {
    alignItems: 'center',
  },
  statValue: {
    fontSize: 28,
    fontWeight: '700',
    color: Colors.violet,
  },
  statLabel: {
    fontSize: 11,
    color: Colors.muted,
    marginTop: 4,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 4,
  },
  sectionSubtitle: {
    fontSize: 13,
    color: Colors.muted,
    marginBottom: 12,
  },
  platformsGrid: {
    gap: 12,
  },
  platformCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.surface,
    borderRadius: 16,
    padding: 16,
    gap: 12,
  },
  platformIcon: {
    width: 48,
    height: 48,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  platformName: {
    flex: 1,
    fontSize: 16,
    fontWeight: '600',
    color: Colors.text,
  },
  platformBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    backgroundColor: 'rgba(34, 197, 94, 0.1)',
  },
  platformBadgeText: {
    fontSize: 11,
    color: Colors.emerald,
    fontWeight: '500',
  },
  featuresList: {
    gap: 12,
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 12,
    backgroundColor: Colors.surface,
    borderRadius: 12,
  },
  featureText: {
    fontSize: 14,
    color: Colors.text,
  },
  stepsList: {
    gap: 12,
  },
  stepItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  stepNumber: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: Colors.violet,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepNumberText: {
    fontSize: 14,
    fontWeight: '600',
    color: 'white',
  },
  stepText: {
    fontSize: 14,
    color: Colors.textSecondary,
  },
  enableButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    backgroundColor: Colors.violet,
    padding: 16,
    borderRadius: 16,
    marginTop: 8,
  },
  enableButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: 'white',
  },
});
