import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Switch,
  TouchableOpacity,
  Alert,
  Linking,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Icon from 'react-native-vector-icons/Feather';

import { Colors } from '../constants/Colors';
import { StorageService } from '../services/StorageService';

export default function SettingsScreen(): React.JSX.Element {
  const [settings, setSettings] = useState({
    notifications: true,
    autoScan: false,
    saveHistory: true,
    analytics: false,
  });

  const [stats, setStats] = useState({
    totalScans: 0,
    deepfakesFound: 0,
    secretsBlocked: 0,
  });

  useEffect(() => {
    let mounted = true;
    
    const loadData = async () => {
      const saved = await StorageService.getSettings();
      if (mounted) {
        setSettings(prev => ({ ...prev, ...saved }));
      }
      
      const s = await StorageService.getStats();
      if (mounted) {
        setStats(s);
      }
    };
    
    loadData();
    
    return () => {
      mounted = false;
    };
  }, []);

  const toggleSetting = async (key: keyof typeof settings) => {
    const newSettings = { ...settings, [key]: !settings[key] };
    setSettings(newSettings);
    await StorageService.saveSettings(newSettings);
  };

  const clearHistory = () => {
    Alert.alert(
      'Clear History',
      'Are you sure you want to clear all detection history?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Clear',
          style: 'destructive',
          onPress: async () => {
            await StorageService.clearHistory();
            Alert.alert('Success', 'History cleared successfully');
            const s = await StorageService.getStats();
            setStats(s);
          },
        },
      ]
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.content}>
        {/* Stats */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Statistics</Text>
          <View style={styles.statsGrid}>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{stats.totalScans}</Text>
              <Text style={styles.statLabel}>Total Scans</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={[styles.statValue, { color: Colors.red }]}>{stats.deepfakesFound}</Text>
              <Text style={styles.statLabel}>Deepfakes Found</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={[styles.statValue, { color: Colors.amber }]}>{stats.secretsBlocked}</Text>
              <Text style={styles.statLabel}>Secrets Blocked</Text>
            </View>
          </View>
        </View>

        {/* Settings */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Settings</Text>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Icon name="bell" size={20} color={Colors.text} />
              <Text style={styles.settingLabel}>Notifications</Text>
            </View>
            <Switch
              value={settings.notifications}
              onValueChange={() => toggleSetting('notifications')}
              trackColor={{ false: Colors.surfaceLight, true: Colors.violet }}
            />
          </View>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Icon name="smartphone" size={20} color={Colors.text} />
              <Text style={styles.settingLabel}>Auto-Scan Clipboard</Text>
            </View>
            <Switch
              value={settings.autoScan}
              onValueChange={() => toggleSetting('autoScan')}
              trackColor={{ false: Colors.surfaceLight, true: Colors.violet }}
            />
          </View>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Icon name="database" size={20} color={Colors.text} />
              <Text style={styles.settingLabel}>Save History</Text>
            </View>
            <Switch
              value={settings.saveHistory}
              onValueChange={() => toggleSetting('saveHistory')}
              trackColor={{ false: Colors.surfaceLight, true: Colors.violet }}
            />
          </View>

          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Icon name="bar-chart-2" size={20} color={Colors.text} />
              <Text style={styles.settingLabel}>Analytics</Text>
            </View>
            <Switch
              value={settings.analytics}
              onValueChange={() => toggleSetting('analytics')}
              trackColor={{ false: Colors.surfaceLight, true: Colors.violet }}
            />
          </View>
        </View>

        {/* Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Actions</Text>

          <TouchableOpacity style={styles.actionItem} onPress={clearHistory}>
            <Icon name="trash-2" size={20} color={Colors.red} />
            <Text style={[styles.actionLabel, { color: Colors.red }]}>Clear History</Text>
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.actionItem} 
            onPress={() => Linking.openURL('https://bekasbah.com')}
          >
            <Icon name="globe" size={20} color={Colors.text} />
            <Text style={styles.actionLabel}>Visit Website</Text>
          </TouchableOpacity>
        </View>

        {/* Footer */}
        <View style={styles.footer}>
          <Text style={styles.version}>Kasbah v2.0.0</Text>
          <Text style={styles.moats}>14 Security Moats Active</Text>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  content: {
    padding: 20,
  },
  section: {
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 12,
    fontWeight: '600',
    color: Colors.muted,
    textTransform: 'uppercase',
    marginBottom: 12,
  },
  statsGrid: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: Colors.surface,
    borderRadius: 12,
    padding: 20,
  },
  statItem: {
    alignItems: 'center',
  },
  statValue: {
    fontSize: 28,
    fontWeight: '700',
    color: Colors.violet,
  },
  statLabel: {
    fontSize: 12,
    color: Colors.muted,
    marginTop: 4,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: Colors.surface,
    padding: 16,
    borderRadius: 12,
    marginBottom: 8,
  },
  settingInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  settingLabel: {
    fontSize: 15,
    color: Colors.text,
  },
  actionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: Colors.surface,
    padding: 16,
    borderRadius: 12,
    marginBottom: 8,
  },
  actionLabel: {
    fontSize: 15,
    color: Colors.text,
  },
  footer: {
    alignItems: 'center',
    marginTop: 20,
    padding: 20,
  },
  version: {
    fontSize: 14,
    color: Colors.muted,
  },
  moats: {
    fontSize: 12,
    color: Colors.emerald,
    marginTop: 4,
  },
});
