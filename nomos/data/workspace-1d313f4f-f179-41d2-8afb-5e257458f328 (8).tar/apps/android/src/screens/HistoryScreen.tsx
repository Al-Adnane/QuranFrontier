import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  RefreshControl,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Icon from 'react-native-vector-icons/Feather';

import { Colors } from '../constants/Colors';
import { DetectionResult } from '../types/Detection';
import { StorageService } from '../services/StorageService';

export default function HistoryScreen(): React.JSX.Element {
  const [history, setHistory] = useState<DetectionResult[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    let mounted = true;
    
    const loadHistory = async () => {
      const data = await StorageService.getDetectionHistory();
      if (mounted) {
        setHistory(data);
      }
    };
    
    loadHistory();
    
    return () => {
      mounted = false;
    };
  }, []);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    const data = await StorageService.getDetectionHistory();
    setHistory(data);
    setRefreshing(false);
  }, []);

  const getResultColor = (r: string) => {
    switch (r) {
      case 'authentic': return Colors.emerald;
      case 'deepfake': return Colors.red;
      default: return Colors.amber;
    }
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const renderItem = ({ item }: { item: DetectionResult }) => (
    <View style={styles.historyItem}>
      <View style={[styles.resultBadge, { backgroundColor: getResultColor(item.result) + '20' }]}>
        <Icon 
          name={item.result === 'authentic' ? 'check-circle' : item.result === 'deepfake' ? 'alert-triangle' : 'help-circle'} 
          size={20} 
          color={getResultColor(item.result)} 
        />
      </View>
      <View style={styles.itemInfo}>
        <Text style={styles.itemFilename} numberOfLines={1}>{item.metadata.file_name}</Text>
        <Text style={styles.itemDate}>{formatDate(item.metadata.analyzed_at)}</Text>
      </View>
      <Text style={[styles.itemConfidence, { color: Colors.violet }]}>
        {Math.round(item.confidence * 100)}%
      </Text>
    </View>
  );

  const EmptyComponent = () => (
    <View style={styles.emptyState}>
      <Icon name="clock" size={48} color={Colors.muted} />
      <Text style={styles.emptyText}>No detection history yet</Text>
      <Text style={styles.emptySubtext}>Scan some images to see them here</Text>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <FlatList
        data={history}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        contentContainerStyle={styles.listContent}
        ListEmptyComponent={EmptyComponent}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={Colors.violet}
          />
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  listContent: {
    padding: 16,
    flexGrow: 1,
  },
  historyItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: Colors.surface,
    borderRadius: 12,
    marginBottom: 8,
    gap: 12,
  },
  resultBadge: {
    width: 40,
    height: 40,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  itemInfo: {
    flex: 1,
  },
  itemFilename: {
    fontSize: 14,
    fontWeight: '500',
    color: Colors.text,
  },
  itemDate: {
    fontSize: 12,
    color: Colors.muted,
    marginTop: 2,
  },
  itemConfidence: {
    fontSize: 14,
    fontWeight: '600',
  },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 100,
  },
  emptyText: {
    fontSize: 18,
    color: Colors.textSecondary,
    marginTop: 16,
  },
  emptySubtext: {
    fontSize: 14,
    color: Colors.muted,
    marginTop: 4,
  },
});
