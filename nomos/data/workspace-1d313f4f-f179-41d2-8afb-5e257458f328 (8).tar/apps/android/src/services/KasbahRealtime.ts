/**
 * Kasbah Real-Time Detection Module
 * 
 * React Native bridge to the native accessibility service
 * Provides 100% fidelity with browser extension and desktop
 */

import { NativeModules, NativeEventEmitter, Platform } from 'react-native';

const { KasbahRealtimeModule } = NativeModules;

export interface DetectionResult {
  mediaId: string;
  platform: string;
  result: 'authentic' | 'deepfake' | 'uncertain';
  confidence: number;
  badgeText: string;
  timestamp: number;
}

export interface ScanResult {
  hasSecret: boolean;
  patterns: string[];
  risk: 'none' | 'low' | 'medium' | 'high' | 'critical';
}

class KasbahRealtimeService {
  private eventEmitter: NativeEventEmitter | null = null;
  private listeners: Map<string, (data: any) => void> = new Map();

  constructor() {
    if (Platform.OS === 'android' && KasbahRealtimeModule) {
      this.eventEmitter = new NativeEventEmitter(KasbahRealtimeModule);
    }
  }

  /**
   * Check if accessibility service is enabled
   */
  async isAccessibilityEnabled(): Promise<boolean> {
    if (Platform.OS !== 'android' || !KasbahRealtimeModule) {
      return false;
    }
    return KasbahRealtimeModule.isAccessibilityEnabled();
  }

  /**
   * Open accessibility settings
   */
  async openAccessibilitySettings(): Promise<void> {
    if (Platform.OS === 'android' && KasbahRealtimeModule) {
      return KasbahRealtimeModule.openAccessibilitySettings();
    }
  }

  /**
   * Start real-time detection
   */
  async startDetection(): Promise<void> {
    if (Platform.OS === 'android' && KasbahRealtimeModule) {
      return KasbahRealtimeModule.startDetection();
    }
  }

  /**
   * Stop real-time detection
   */
  async stopDetection(): Promise<void> {
    if (Platform.OS === 'android' && KasbahRealtimeModule) {
      return KasbahRealtimeModule.stopDetection();
    }
  }

  /**
   * Get detection stats
   */
  async getStats(): Promise<{
    scansToday: number;
    deepfakesFound: number;
    secretsBlocked: number;
  }> {
    if (Platform.OS === 'android' && KasbahRealtimeModule) {
      return KasbahRealtimeModule.getStats();
    }
    return { scansToday: 0, deepfakesFound: 0, secretsBlocked: 0 };
  }

  /**
   * Scan text for secrets (same patterns as extension)
   */
  scanForSecrets(text: string): ScanResult {
    // Same patterns as browser extension
    const patterns = [
      { name: 'openai-project', regex: /sk-proj-[a-zA-Z0-9]{32,}/g },
      { name: 'openai-key', regex: /sk-[a-zA-Z0-9]{20}T3BlbkFJ[a-zA-Z0-9]{20}/g },
      { name: 'anthropic-key', regex: /sk-ant-api03-[a-zA-Z0-9\-]{80,}/g },
      { name: 'stripe-live', regex: /sk_live_[a-zA-Z0-9]{24,}/g },
      { name: 'stripe-test', regex: /sk_test_[a-zA-Z0-9]{24,}/g },
      { name: 'aws-key', regex: /AKIA[0-9A-Z]{16}/g },
      { name: 'github-token', regex: /ghp_[a-zA-Z0-9]{36}/g },
      { name: 'google-api-key', regex: /AIza[a-zA-Z0-9\-_]{35}/g },
      { name: 'slack-bot-token', regex: /xoxb-[0-9]{10,13}-[0-9]{10,13}-[a-zA-Z0-9]{24}/g },
      { name: 'private-key', regex: /-----BEGIN.*PRIVATE KEY-----/g },
    ];

    const found: string[] = [];

    for (const p of patterns) {
      if (p.regex.test(text)) {
        found.push(p.name);
      }
    }

    let risk: ScanResult['risk'] = 'none';
    if (found.length > 0) {
      risk = found.length > 2 ? 'critical' : found.length > 1 ? 'high' : 'medium';
    }

    return {
      hasSecret: found.length > 0,
      patterns: found,
      risk,
    };
  }

  /**
   * Listen for detection events
   */
  addDetectionListener(callback: (result: DetectionResult) => void): () => void {
    if (!this.eventEmitter) {
      return () => {};
    }

    const subscription = this.eventEmitter.addListener('onDetection', callback);
    return () => subscription.remove();
  }

  /**
   * Listen for secret detection events
   */
  addSecretListener(callback: (result: ScanResult) => void): () => void {
    if (!this.eventEmitter) {
      return () => {};
    }

    const subscription = this.eventEmitter.addListener('onSecretDetected', callback);
    return () => subscription.remove();
  }
}

export const KasbahRealtime = new KasbahRealtimeService();
