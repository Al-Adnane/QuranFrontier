import { DetectionResult } from '../types/Detection';

const API_URL = 'https://bekasbah.com/api';

export const DetectionService = {
  /**
   * Analyze an image for deepfakes
   */
  async analyzeImage(imageUri: string): Promise<DetectionResult> {
    const formData = new FormData();
    
    // Extract filename and type from URI
    const filename = imageUri.split('/').pop() || 'image.jpg';
    const match = /\.(\w+)$/.exec(filename);
    const type = match ? `image/${match[1]}` : 'image/jpeg';

    formData.append('file', {
      uri: imageUri,
      name: filename,
      type,
    } as any);

    const response = await fetch(`${API_URL}/detect`, {
      method: 'POST',
      body: formData,
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'multipart/form-data',
      },
    });

    if (!response.ok) {
      throw new Error('Analysis failed');
    }

    const data = await response.json();
    
    return {
      id: data.detection.id,
      result: data.detection.result,
      confidence: data.detection.confidence,
      analysis: data.detection.analysis,
      indicators: data.detection.indicators || [],
      metadata: {
        file_name: filename,
        file_size: 0,
        media_type: 'image',
        analyzed_at: new Date().toISOString(),
      },
      threat_level: data.detection.threat_level || 'minimal',
      moats_passed: [],
    };
  },

  /**
   * Analyze a URL for deepfakes
   */
  async analyzeUrl(url: string): Promise<DetectionResult> {
    const response = await fetch(`${API_URL}/analyze-url`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      body: JSON.stringify({ url }),
    });

    if (!response.ok) {
      throw new Error('URL analysis failed');
    }

    const data = await response.json();
    
    return {
      id: data.detection.id,
      result: data.detection.result,
      confidence: data.detection.confidence,
      analysis: data.detection.analysis,
      indicators: data.detection.indicators || [],
      metadata: {
        file_name: url.split('/').pop() || 'url',
        file_size: 0,
        media_type: 'video',
        analyzed_at: new Date().toISOString(),
      },
      threat_level: data.detection.threat_level || 'minimal',
      moats_passed: [],
    };
  },

  /**
   * Quick secret scan
   */
  scanForSecrets(text: string): { hasSecret: boolean; patterns: string[] } {
    const patterns = [
      { name: 'openai-project', regex: /sk-proj-[a-zA-Z0-9]{32,}/g },
      { name: 'openai-key', regex: /sk-[a-zA-Z0-9]{20}T3BlbkFJ[a-zA-Z0-9]{20}/g },
      { name: 'anthropic-key', regex: /sk-ant-api03-[a-zA-Z0-9\-]{80,}/g },
      { name: 'stripe-live', regex: /sk_live_[a-zA-Z0-9]{24,}/g },
      { name: 'aws-key', regex: /AKIA[0-9A-Z]{16}/g },
      { name: 'github-token', regex: /ghp_[a-zA-Z0-9]{36}/g },
      { name: 'private-key', regex: /-----BEGIN.*PRIVATE KEY-----/g },
    ];

    const found: string[] = [];
    
    for (const p of patterns) {
      if (p.regex.test(text)) {
        found.push(p.name);
      }
    }

    return {
      hasSecret: found.length > 0,
      patterns: found,
    };
  },
};
