import AsyncStorage from '@react-native-async-storage/async-storage';
import { DetectionResult, AppStats, AppSettings } from '../types/Detection';

const KEYS = {
  HISTORY: 'kasbah_history',
  STATS: 'kasbah_stats',
  SETTINGS: 'kasbah_settings',
};

export const StorageService = {
  /**
   * Save a detection result to history
   */
  async saveDetection(result: DetectionResult): Promise<void> {
    try {
      const history = await this.getDetectionHistory();
      history.unshift(result);
      
      // Keep only last 100 items
      if (history.length > 100) {
        history.pop();
      }
      
      await AsyncStorage.setItem(KEYS.HISTORY, JSON.stringify(history));
      
      // Update stats
      const stats = await this.getStats();
      stats.totalScans += 1;
      if (result.result === 'deepfake') {
        stats.deepfakesFound += 1;
      }
      await AsyncStorage.setItem(KEYS.STATS, JSON.stringify(stats));
    } catch (error) {
      console.error('Failed to save detection:', error);
    }
  },

  /**
   * Get detection history
   */
  async getDetectionHistory(): Promise<DetectionResult[]> {
    try {
      const data = await AsyncStorage.getItem(KEYS.HISTORY);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error('Failed to load history:', error);
      return [];
    }
  },

  /**
   * Get app statistics
   */
  async getStats(): Promise<AppStats> {
    try {
      const data = await AsyncStorage.getItem(KEYS.STATS);
      return data ? JSON.parse(data) : {
        totalScans: 0,
        deepfakesFound: 0,
        secretsBlocked: 0,
      };
    } catch (error) {
      console.error('Failed to load stats:', error);
      return {
        totalScans: 0,
        deepfakesFound: 0,
        secretsBlocked: 0,
      };
    }
  },

  /**
   * Increment secrets blocked counter
   */
  async incrementSecretsBlocked(): Promise<void> {
    try {
      const stats = await this.getStats();
      stats.secretsBlocked += 1;
      await AsyncStorage.setItem(KEYS.STATS, JSON.stringify(stats));
    } catch (error) {
      console.error('Failed to update stats:', error);
    }
  },

  /**
   * Get app settings
   */
  async getSettings(): Promise<AppSettings> {
    try {
      const data = await AsyncStorage.getItem(KEYS.SETTINGS);
      return data ? JSON.parse(data) : {
        notifications: true,
        autoScan: false,
        saveHistory: true,
        analytics: false,
      };
    } catch (error) {
      console.error('Failed to load settings:', error);
      return {
        notifications: true,
        autoScan: false,
        saveHistory: true,
        analytics: false,
      };
    }
  },

  /**
   * Save app settings
   */
  async saveSettings(settings: AppSettings): Promise<void> {
    try {
      await AsyncStorage.setItem(KEYS.SETTINGS, JSON.stringify(settings));
    } catch (error) {
      console.error('Failed to save settings:', error);
    }
  },

  /**
   * Clear all history
   */
  async clearHistory(): Promise<void> {
    try {
      await AsyncStorage.removeItem(KEYS.HISTORY);
      
      // Reset stats
      await AsyncStorage.setItem(KEYS.STATS, JSON.stringify({
        totalScans: 0,
        deepfakesFound: 0,
        secretsBlocked: 0,
      }));
    } catch (error) {
      console.error('Failed to clear history:', error);
    }
  },
};
