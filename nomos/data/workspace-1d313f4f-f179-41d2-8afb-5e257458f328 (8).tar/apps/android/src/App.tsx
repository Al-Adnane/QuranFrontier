import React from 'react';
import { StatusBar } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import ScanScreen from './screens/ScanScreen';
import HistoryScreen from './screens/HistoryScreen';
import SettingsScreen from './screens/SettingsScreen';
import { Colors } from './constants/Colors';

const Tab = createBottomTabNavigator();

import Icon from 'react-native-vector-icons/Feather';

function TabIcon({ name, color }: { name: string; color: string }) {
  return <Icon name={name} size={24} color={color} />;
}

function App(): React.JSX.Element {
  return (
    <SafeAreaProvider>
      <StatusBar barStyle="light-content" backgroundColor={Colors.primary} />
      <NavigationContainer>
        <Tab.Navigator
          screenOptions={{
            headerStyle: { backgroundColor: Colors.primary },
            headerTintColor: '#fff',
            tabBarStyle: { backgroundColor: Colors.surface },
            tabBarActiveTintColor: Colors.violet,
            tabBarInactiveTintColor: Colors.muted,
          }}>
          <Tab.Screen 
            name="Scan" 
            component={ScanScreen}
            options={{
              tabBarIcon: ({ color }) => <TabIcon name="shield" color={color} />,
            }}
          />
          <Tab.Screen 
            name="History" 
            component={HistoryScreen}
            options={{
              tabBarIcon: ({ color }) => <TabIcon name="clock" color={color} />,
            }}
          />
          <Tab.Screen 
            name="Settings" 
            component={SettingsScreen}
            options={{
              tabBarIcon: ({ color }) => <TabIcon name="settings" color={color} />,
            }}
          />
        </Tab.Navigator>
      </NavigationContainer>
    </SafeAreaProvider>
  );
}

export default App;
