# Kasbah Apps

Cross-platform deepfake detection with 100% fidelity across all platforms.

## Structure

```
apps/
├── shared/              # Shared detection core (100% identical behavior)
│   └── src/
│       └── detection-core.ts
│
├── tauri/              # Desktop app (Windows/Mac/Linux)
│   ├── src-tauri/
│   │   └── src/
│   │       ├── realtime/       # Real-time detection engine
│   │       ├── detection/      # Native analysis
│   │       └── ...
│   └── src/
│       └── components/
│           └── SocialBrowser.tsx
│
├── android/             # Android app
│   └── src/
│       ├── native/
│       │   ├── KasbahAccessibilityService.java   # System-wide detection
│       │   ├── DetectionOverlayService.java     # Badge overlays
│       │   └── KasbahRealtimeModule.kt           # React Native bridge
│       ├── services/
│       │   ├── KasbahRealtime.ts               # JS API
│       │   └── DetectionService.ts
│       └── screens/
│           └── RealtimeDetectionScreen.tsx
│
└── ios/                # iOS app (Swift + Safari extension)
    └── src/
        └── KasbahViewController.swift
```

## 100% Fidelity Guarantee

The Component | Browser | Desktop | Android | iOS |
|-----------|---------|---------|---------|-----|
| Content Script | ✅ | ✅ | ✅ | ✅ |
| Stealth Badges | ✅ | ✅ | ✅ | ✅ |
| Rate Limiting | ✅ | ✅ | ✅ | ✅ |
| Random Delays | ✅ | ✅ | ✅ | ✅ |
| Secret Patterns | ✅ | ✅ | ✅ | ✅ |
| WebSocket Guard | ✅ | ✅ | ⚠️ | ⚠️ |

## Building

### Desktop (Tauri)
```bash
cd apps/tauri
npm install
cargo tauri build
```

### Android
```bash
cd apps/android
npm install
npm run android
```

### iOS
```bash
cd apps/ios
pod install
npm run ios
```

## The MOAT

The real-time detection is your competitive advantage:

1. **Browser Extension** - Original implementation
2. **Desktop App** - WebView with same content script
3. **Android** - Accessibility Service with overlay badges
4. **iOS** - Safari extension with same detection logic

All platforms use identical:
- Badge styling (87% = authentic, !72% = suspicious)
- Rate limiting (20 scans/minute)
- Scan delays (800-3000ms random)
- Session class randomization
- Secret patterns (50+ types)

This makes your detection impossible to distinguish across platforms.
