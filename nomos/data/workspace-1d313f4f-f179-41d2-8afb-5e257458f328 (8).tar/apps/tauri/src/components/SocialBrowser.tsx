import { useState, useEffect } from 'react'
import { invoke } from '@tauri-apps/api/core'
import { 
  Shield, Globe, ExternalLink, RefreshCw, Check, AlertTriangle,
  Music, Camera, Play, Twitter, Facebook, Youtube, Lock, Eye
} from 'lucide-react'
import { Colors } from './constants/Colors'

interface Platform {
  id: string
  name: string
  url: string
  icon: string
}

export function SocialBrowser() {
  const [platforms, setPlatforms] = useState<Platform[]>([])
  const [loading, setLoading] = useState<string | null>(null)
  const [stats, setStats] = useState({
    scansToday: 0,
    deepfakesBlocked: 0,
    secretsProtected: 0,
  })

  useEffect(() => {
    loadPlatforms()
    loadStats()
  }, [])

  const loadPlatforms = async () => {
    try {
      const p = await invoke<Platform[]>('get_social_platforms')
      setPlatforms(p)
    } catch (e) {
      console.error('Failed to load platforms:', e)
    }
  }

  const loadStats = async () => {
    try {
      const s = await invoke<{ total_detections: number; deepfakes_found: number; secrets_blocked: number }>('get_stats')
      setStats({
        scansToday: s.total_detections,
        deepfakesBlocked: s.deepfakes_found,
        secretsProtected: s.secrets_blocked,
      })
    } catch (e) {
      console.error('Failed to load stats:', e)
    }
  }

  const openPlatform = async (platformId: string) => {
    setLoading(platformId)
    try {
      await invoke('open_social_browser', { platformId })
    } catch (e) {
      console.error('Failed to open browser:', e)
    } finally {
      setLoading(null)
    }
  }

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'music': return <Music className="w-6 h-6" />
      case 'camera': return <Camera className="w-6 h-6" />
      case 'play': return <Play className="w-6 h-6" />
      case 'twitter': return <Twitter className="w-6 h-6" />
      case 'facebook': return <Facebook className="w-6 h-6" />
      default: return <Globe className="w-6 h-6" />
    }
  }

  const platformColors: Record<string, string> = {
    tiktok: 'from-pink-500 to-cyan-500',
    instagram: 'from-orange-500 to-pink-500',
    youtube: 'from-red-500 to-red-600',
    twitter: 'from-blue-400 to-blue-500',
    facebook: 'from-blue-600 to-blue-700',
  }

  return (
    <div className="social-browser">
      {/* Header */}
      <div className="browser-header">
        <div className="header-icon">
          <Shield className="w-8 h-8" />
        </div>
        <div className="header-text">
          <h2>Real-Time Detection</h2>
          <p>Browse with automatic deepfake protection</p>
        </div>
      </div>

      {/* Stats */}
      <div className="browser-stats">
        <div className="stat-item">
          <span className="stat-value">{stats.scansToday}</span>
          <span className="stat-label">Scans Today</span>
        </div>
        <div className="stat-item">
          <span className="stat-value danger">{stats.deepfakesBlocked}</span>
          <span className="stat-label">Deepfakes Found</span>
        </div>
        <div className="stat-item">
          <span className="stat-value warning">{stats.secretsProtected}</span>
          <span className="stat-label">Secrets Protected</span>
        </div>
      </div>

      {/* Platforms Grid */}
      <div className="platforms-grid">
        {platforms.map((platform) => (
          <button
            key={platform.id}
            className={`platform-card ${loading === platform.id ? 'loading' : ''}`}
            onClick={() => openPlatform(platform.id)}
            disabled={loading !== null}
          >
            <div className={`platform-icon bg-gradient-to-br ${platformColors[platform.id] || 'from-gray-500 to-gray-600'}`}>
              {getIcon(platform.icon)}
            </div>
            <span className="platform-name">{platform.name}</span>
            {loading === platform.id && (
              <RefreshCw className="w-4 h-4 animate-spin absolute right-3" />
            )}
          </button>
        ))}
      </div>

      {/* Features */}
      <div className="features-section">
        <h3>Active Protections</h3>
        <div className="features-grid">
          <div className="feature-item">
            <Eye className="w-4 h-4" />
            <span>Real-time scanning</span>
          </div>
          <div className="feature-item">
            <Lock className="w-4 h-4" />
            <span>Secret protection</span>
          </div>
          <div className="feature-item">
            <Shield className="w-4 h-4" />
            <span>14 security moats</span>
          </div>
          <div className="feature-item">
            <Check className="w-4 h-4" />
            <span>Stealth mode active</span>
          </div>
        </div>
      </div>

      {/* Info */}
      <div className="info-banner">
        <AlertTriangle className="w-4 h-4" />
        <span>Click a platform to open with real-time detection</span>
      </div>
    </div>
  )
}
