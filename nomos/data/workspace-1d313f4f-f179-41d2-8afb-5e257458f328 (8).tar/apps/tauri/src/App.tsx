import { useState, useCallback, useEffect } from 'react'
import { invoke } from '@tauri-apps/api/core'
import { open } from '@tauri-apps/plugin-dialog'
import { 
  Shield, Upload, Link, CheckCircle, AlertTriangle, 
  HelpCircle, History, Settings, Eye, Lock, Zap,
  RefreshCw, Copy, Check, Menu, X
} from 'lucide-react'

interface DetectionResult {
  id: string
  result: 'authentic' | 'deepfake' | 'uncertain'
  confidence: number
  analysis: string
  indicators: string[]
  metadata: {
    file_name: string
    file_size: number
    media_type: string
    analyzed_at: string
  }
  threat_level: string
}

interface AppStats {
  total_detections: number
  deepfakes_found: number
  authentic_count: number
  secrets_blocked: number
  clipboard_scans: number
}

export default function App() {
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [result, setResult] = useState<DetectionResult | null>(null)
  const [stats, setStats] = useState<AppStats | null>(null)
  const [history, setHistory] = useState<DetectionResult[]>([])
  const [url, setUrl] = useState('')
  const [activeTab, setActiveTab] = useState<'upload' | 'url' | 'history'>('upload')
  const [copied, setCopied] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)

  // Load stats on mount
  useEffect(() => {
    loadStats()
    loadHistory()
  }, [])

  const loadStats = async () => {
    try {
      const s = await invoke<AppStats>('get_stats')
      setStats(s)
    } catch (e) {
      console.error('Failed to load stats:', e)
    }
  }

  const loadHistory = async () => {
    try {
      const h = await invoke<DetectionResult[]>('get_detection_history', { limit: 20 })
      setHistory(h)
    } catch (e) {
      console.error('Failed to load history:', e)
    }
  }

  const handleFileSelect = useCallback(async () => {
    try {
      const selected = await open({
        multiple: false,
        filters: [
          { name: 'Images', extensions: ['jpg', 'jpeg', 'png', 'gif', 'webp'] },
          { name: 'Videos', extensions: ['mp4', 'mov', 'avi', 'webm'] },
          { name: 'All Files', extensions: ['*'] }
        ]
      })

      if (selected) {
        setIsAnalyzing(true)
        setResult(null)
        
        const r = await invoke<DetectionResult>('analyze_file', { 
          path: typeof selected === 'string' ? selected : selected.path 
        })
        setResult(r)
        loadStats()
        loadHistory()
      }
    } catch (e) {
      console.error('Analysis failed:', e)
      setResult({
        id: 'error',
        result: 'uncertain',
        confidence: 0,
        analysis: String(e),
        indicators: [],
        metadata: { file_name: 'error', file_size: 0, media_type: 'image', analyzed_at: new Date().toISOString() },
        threat_level: 'minimal'
      })
    } finally {
      setIsAnalyzing(false)
    }
  }, [])

  const handleUrlAnalyze = useCallback(async () => {
    if (!url.trim()) return

    setIsAnalyzing(true)
    setResult(null)

    try {
      const r = await invoke<DetectionResult>('analyze_url', { url })
      setResult(r)
      loadStats()
      loadHistory()
    } catch (e) {
      console.error('URL analysis failed:', e)
    } finally {
      setIsAnalyzing(false)
    }
  }, [url])

  const getResultColor = (r: string) => {
    switch (r) {
      case 'authentic': return 'var(--emerald)'
      case 'deepfake': return 'var(--red)'
      default: return 'var(--amber)'
    }
  }

  const getResultIcon = (r: string) => {
    switch (r) {
      case 'authentic': return <CheckCircle className="w-6 h-6" />
      case 'deepfake': return <AlertTriangle className="w-6 h-6" />
      default: return <HelpCircle className="w-6 h-6" />
    }
  }

  const copyResult = async () => {
    if (!result) return
    await navigator.clipboard.writeText(JSON.stringify(result, null, 2))
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="app">
      {/* Header */}
      <header className="header">
        <div className="header-content">
          <div className="logo">
            <Shield className="w-8 h-8" />
            <span>Kasbah</span>
            <span className="badge">Desktop</span>
          </div>
          
          <button className="menu-btn" onClick={() => setMenuOpen(!menuOpen)}>
            {menuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
          
          <nav className={`nav ${menuOpen ? 'open' : ''}`}>
            <button onClick={() => { setActiveTab('upload'); setMenuOpen(false) }}>
              <Upload className="w-4 h-4" /> Upload
            </button>
            <button onClick={() => { setActiveTab('url'); setMenuOpen(false) }}>
              <Link className="w-4 h-4" /> URL
            </button>
            <button onClick={() => { setActiveTab('history'); setMenuOpen(false) }}>
              <History className="w-4 h-4" /> History
            </button>
          </nav>
        </div>
      </header>

      {/* Stats Bar */}
      {stats && (
        <div className="stats-bar">
          <div className="stat">
            <span className="stat-value">{stats.total_detections}</span>
            <span className="stat-label">Scans</span>
          </div>
          <div className="stat">
            <span className="stat-value text-red">{stats.deepfakes_found}</span>
            <span className="stat-label">Deepfakes</span>
          </div>
          <div className="stat">
            <span className="stat-value text-emerald">{stats.authentic_count}</span>
            <span className="stat-label">Authentic</span>
          </div>
          <div className="stat">
            <span className="stat-value text-amber">{stats.secrets_blocked}</span>
            <span className="stat-label">Secrets Blocked</span>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="main">
        {/* Upload Tab */}
        {activeTab === 'upload' && (
          <div className="upload-section">
            <div 
              className="dropzone"
              onClick={handleFileSelect}
            >
              {isAnalyzing ? (
                <div className="analyzing">
                  <RefreshCw className="w-12 h-12 animate-spin" />
                  <p>Analyzing...</p>
                </div>
              ) : (
                <>
                  <Upload className="w-12 h-12" />
                  <p className="title">Drop file or click to upload</p>
                  <p className="subtitle">Images, videos supported</p>
                </>
              )}
            </div>
          </div>
        )}

        {/* URL Tab */}
        {activeTab === 'url' && (
          <div className="url-section">
            <div className="input-group">
              <input
                type="url"
                placeholder="Paste image or video URL..."
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleUrlAnalyze()}
              />
              <button 
                onClick={handleUrlAnalyze}
                disabled={!url.trim() || isAnalyzing}
              >
                {isAnalyzing ? <RefreshCw className="w-5 h-5 animate-spin" /> : <Shield className="w-5 h-5" />}
                Scan
              </button>
            </div>
          </div>
        )}

        {/* History Tab */}
        {activeTab === 'history' && (
          <div className="history-section">
            {history.length === 0 ? (
              <div className="empty-state">
                <History className="w-12 h-12" />
                <p>No detection history yet</p>
              </div>
            ) : (
              <div className="history-list">
                {history.map((item) => (
                  <div key={item.id} className="history-item">
                    <div className={`result-badge ${item.result}`}>
                      {getResultIcon(item.result)}
                    </div>
                    <div className="history-info">
                      <p className="filename">{item.metadata.file_name}</p>
                      <p className="date">
                        {new Date(item.metadata.analyzed_at).toLocaleString()}
                      </p>
                    </div>
                    <div className="confidence">
                      {Math.round(item.confidence * 100)}%
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Result */}
        {result && !isAnalyzing && (
          <div className="result-section">
            <div className="result-card" style={{ borderColor: getResultColor(result.result) }}>
              <div className="result-header" style={{ backgroundColor: getResultColor(result.result) }}>
                {getResultIcon(result.result)}
                <h2>{result.result.toUpperCase()}</h2>
                <span className="confidence-badge">
                  {Math.round(result.confidence * 100)}% Confidence
                </span>
              </div>
              
              <div className="result-body">
                <p className="analysis">{result.analysis}</p>
                
                {result.indicators.length > 0 && (
                  <div className="indicators">
                    <h3>Indicators</h3>
                    <ul>
                      {result.indicators.map((ind, i) => (
                        <li key={i}>{ind}</li>
                      ))}
                    </ul>
                  </div>
                )}

                <div className="metadata">
                  <div><strong>File:</strong> {result.metadata.file_name}</div>
                  <div><strong>Type:</strong> {result.metadata.media_type}</div>
                  <div><strong>Size:</strong> {(result.metadata.file_size / 1024).toFixed(1)} KB</div>
                  <div><strong>Threat:</strong> {result.threat_level}</div>
                </div>

                <button className="copy-btn" onClick={copyResult}>
                  {copied ? <><Check className="w-4 h-4" /> Copied!</> : <><Copy className="w-4 h-4" /> Copy Result</>}
                </button>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="footer">
        <div className="footer-content">
          <div className="moats">
            <Lock className="w-4 h-4" />
            <span>14 Security Moats Active</span>
          </div>
          <div className="version">v2.0.0</div>
        </div>
      </footer>
    </div>
  )
}
