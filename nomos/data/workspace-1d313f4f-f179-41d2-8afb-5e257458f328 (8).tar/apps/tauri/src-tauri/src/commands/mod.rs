//! Tauri Commands
//! 
//! IPC commands exposed to the frontend

use crate::detection::{DetectionEngine, DetectionResult};
use crate::secret_guard::{self, get_stats as get_guard_stats};
use crate::database;
use serde::{Deserialize, Serialize};
use std::path::PathBuf;
use std::sync::Arc;
use tokio::sync::RwLock;

lazy_static::lazy_static! {
    static ref ENGINE: Arc<RwLock<DetectionEngine>> = 
        Arc::new(RwLock::new(DetectionEngine::new()));
}

#[derive(Debug, Serialize, Deserialize)]
pub struct AnalyzeFileRequest {
    pub path: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct AnalyzeUrlRequest {
    pub url: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct ScanSecretsRequest {
    pub text: String,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct CheckUrlRequest {
    pub url: String,
}

/// Analyze a local file for deepfakes
#[tauri::command]
pub async fn analyze_file(path: String) -> Result<DetectionResult, String> {
    let engine = ENGINE.read().await;
    let path_buf = PathBuf::from(&path);
    
    engine.analyze_file(&path_buf)
        .await
        .map_err(|e| e.to_string())
}

/// Analyze a URL for deepfakes
#[tauri::command]
pub async fn analyze_url(url: String) -> Result<DetectionResult, String> {
    let engine = ENGINE.read().await;
    
    engine.analyze_url(&url)
        .await
        .map_err(|e| e.to_string())
}

/// Analyze an image from clipboard
#[tauri::command]
pub async fn analyze_clipboard_image(base64_data: String) -> Result<DetectionResult, String> {
    let engine = ENGINE.read().await;
    
    engine.analyze_base64(&base64_data)
        .await
        .map_err(|e| e.to_string())
}

/// Get detection history
#[tauri::command]
pub async fn get_detection_history(limit: Option<usize>) -> Result<Vec<DetectionResult>, String> {
    database::get_detections(limit.unwrap_or(50))
        .await
        .map_err(|e| e.to_string())
}

/// Get app statistics
#[tauri::command]
pub async fn get_stats() -> Result<AppStats, String> {
    let guard_stats = get_guard_stats();
    let db_stats = database::get_stats()
        .await
        .map_err(|e| e.to_string())?;
    
    Ok(AppStats {
        total_detections: db_stats.total_detections,
        deepfakes_found: db_stats.deepfakes_found,
        authentic_count: db_stats.authentic_count,
        secrets_blocked: guard_stats.secrets_blocked,
        clipboard_scans: guard_stats.clipboard_scans,
    })
}

#[derive(Debug, Serialize)]
pub struct AppStats {
    pub total_detections: u64,
    pub deepfakes_found: u64,
    pub authentic_count: u64,
    pub secrets_blocked: u64,
    pub clipboard_scans: u64,
}

/// Scan text for secrets
#[tauri::command]
pub fn scan_secrets(text: String) -> Vec<String> {
    secret_guard::scan_for_secrets(&text)
}

/// Check URL safety
#[tauri::command]
pub fn check_url_safety(url: String) -> UrlSafetyResult {
    // Check for secrets in URL
    let secrets = secret_guard::scan_for_secrets(&url);
    
    // Check for suspicious patterns
    let suspicious = is_suspicious_url(&url);
    
    UrlSafetyResult {
        safe: secrets.is_empty() && !suspicious,
        secrets_found: secrets,
        warnings: if suspicious {
            vec!["URL contains suspicious patterns".to_string()]
        } else {
            vec![]
        },
    }
}

#[derive(Debug, Serialize)]
pub struct UrlSafetyResult {
    pub safe: bool,
    pub secrets_found: Vec<String>,
    pub warnings: Vec<String>,
}

fn is_suspicious_url(url: &str) -> bool {
    let suspicious_patterns = [
        "bit.ly",
        "tinyurl",
        "goo.gl",
        "t.co",
        "click.",
        "track.",
        "redirect",
    ];
    
    suspicious_patterns.iter().any(|p| url.contains(p))
}

/// Export detection results
#[tauri::command]
pub async fn export_results(format: String) -> Result<String, String> {
    let detections = database::get_detections(1000)
        .await
        .map_err(|e| e.to_string())?;
    
    match format.as_str() {
        "json" => {
            serde_json::to_string_pretty(&detections)
                .map_err(|e| e.to_string())
        }
        "csv" => {
            let mut csv = String::from("id,result,confidence,file_name,analyzed_at\n");
            for d in detections {
                csv.push_str(&format!(
                    "{},{},{},{},{}\n",
                    d.id,
                    serde_json::to_string(&d.result).unwrap_or_default(),
                    d.confidence,
                    d.metadata.file_name,
                    d.metadata.analyzed_at
                ));
            }
            Ok(csv)
        }
        _ => Err("Unsupported format. Use 'json' or 'csv'.".to_string()),
    }
}

/// Get current threat level
#[tauri::command]
pub async fn get_threat_level() -> ThreatLevelInfo {
    // Calculate based on recent activity
    let stats = database::get_stats()
        .await
        .unwrap_or_default();
    
    let recent_deepfakes = stats.recent_deepfakes.unwrap_or(0);
    
    let (level, description) = if recent_deepfakes > 5 {
        ("critical", "Multiple deepfakes detected recently. Exercise extreme caution.")
    } else if recent_deepfakes > 2 {
        ("high", "Several deepfakes detected. Be vigilant.")
    } else if recent_deepfakes > 0 {
        ("medium", "Some suspicious content detected. Stay alert.")
    } else {
        ("minimal", "No recent threats detected.")
    };
    
    ThreatLevelInfo {
        level: level.to_string(),
        description: description.to_string(),
        score: recent_deepfakes as f32 / 10.0,
    }
}

#[derive(Debug, Serialize)]
pub struct ThreatLevelInfo {
    pub level: String,
    pub description: String,
    pub score: f32,
}

/// Run stress test on detection system
#[tauri::command]
pub async fn run_stress_test() -> StressTestResult {
    let engine = ENGINE.read().await;
    let mut passed = 0;
    let mut failed = 0;
    let tests: Vec<String> = Vec::new();
    
    // Test 1: Detection engine responds
    let test_path = std::env::temp_dir().join("kasbah_test.png");
    if create_test_image(&test_path) {
        match engine.analyze_file(&test_path).await {
            Ok(_) => passed += 1,
            Err(_) => failed += 1,
        }
        let _ = std::fs::remove_file(&test_path);
    }
    
    // Test 2: Secret detection works
    let secrets = secret_guard::scan_for_secrets("sk-proj-test1234567890abcdefghijklmnopqrstuvwxyz");
    if !secrets.is_empty() {
        passed += 1;
    } else {
        failed += 1;
    }
    
    StressTestResult {
        passed,
        failed,
        tests,
        overall: failed == 0,
    }
}

fn create_test_image(path: &PathBuf) -> bool {
    // Create a simple test image
    let img = image::DynamicImage::new_rgb8(100, 100);
    img.save(path).is_ok()
}

#[derive(Debug, Serialize)]
pub struct StressTestResult {
    pub passed: u32,
    pub failed: u32,
    pub tests: Vec<String>,
    pub overall: bool,
}
