//! Deepfake Detection Module
//! 
//! Core detection engine with multiple analysis layers

pub mod image;
pub mod video;
pub mod audio;

use serde::{Deserialize, Serialize};
use std::path::PathBuf;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DetectionResult {
    pub id: String,
    pub result: DetectionVerdict,
    pub confidence: f32,
    pub analysis: String,
    pub indicators: Vec<String>,
    pub metadata: DetectionMetadata,
    pub moats_passed: Vec<String>,
    pub threat_level: ThreatLevel,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum DetectionVerdict {
    Authentic,
    Deepfake,
    Uncertain,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum ThreatLevel {
    Minimal,
    Low,
    Medium,
    High,
    Critical,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DetectionMetadata {
    pub file_name: String,
    pub file_size: u64,
    pub media_type: MediaType,
    pub dimensions: Option<(u32, u32)>,
    pub duration_ms: Option<u64>,
    pub analyzed_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum MediaType {
    Image,
    Video,
    Audio,
}

/// Main detection orchestrator
pub struct DetectionEngine {
    image_analyzer: image::ImageAnalyzer,
}

impl DetectionEngine {
    pub fn new() -> Self {
        Self {
            image_analyzer: image::ImageAnalyzer::new(),
        }
    }

    /// Analyze a file (image, video, or audio)
    pub async fn analyze_file(&self, path: &PathBuf) -> anyhow::Result<DetectionResult> {
        let file_name = path.file_name()
            .and_then(|n| n.to_str())
            .unwrap_or("unknown")
            .to_string();
        
        let file_size = std::fs::metadata(path)?.len();
        let extension = path.extension()
            .and_then(|e| e.to_str())
            .unwrap_or("")
            .to_lowercase();

        // Determine media type
        let media_type = if Self::is_image(&extension) {
            MediaType::Image
        } else if Self::is_video(&extension) {
            MediaType::Video
        } else if Self::is_audio(&extension) {
            MediaType::Audio
        } else {
            return Err(anyhow::anyhow!("Unsupported file type: {}", extension));
        };

        // Run analysis
        let analysis = self.image_analyzer.analyze(path).await?;

        let metadata = DetectionMetadata {
            file_name,
            file_size,
            media_type,
            dimensions: analysis.dimensions,
            duration_ms: None,
            analyzed_at: chrono::Utc::now().to_rfc3339(),
        };

        Ok(self.build_result(analysis, metadata))
    }

    /// Analyze from URL
    pub async fn analyze_url(&self, url: &str) -> anyhow::Result<DetectionResult> {
        let response = reqwest::get(url).await?;
        let bytes = response.bytes().await?;
        
        let temp_dir = std::env::temp_dir();
        let temp_path = temp_dir.join(format!("kasbah_temp_{}.jpg", uuid::Uuid::new_v4()));
        std::fs::write(&temp_path, &bytes)?;

        let result = self.analyze_file(&temp_path).await;
        let _ = std::fs::remove_file(&temp_path);
        result
    }

    /// Analyze base64 encoded image
    pub async fn analyze_base64(&self, base64_data: &str) -> anyhow::Result<DetectionResult> {
        let bytes = base64::decode(base64_data)?;
        
        let temp_dir = std::env::temp_dir();
        let temp_path = temp_dir.join(format!("kasbah_temp_{}.jpg", uuid::Uuid::new_v4()));
        std::fs::write(&temp_path, &bytes)?;

        let result = self.analyze_file(&temp_path).await;
        let _ = std::fs::remove_file(&temp_path);
        result
    }

    fn is_image(ext: &str) -> bool {
        matches!(ext, "jpg" | "jpeg" | "png" | "gif" | "bmp" | "webp" | "tiff")
    }

    fn is_video(ext: &str) -> bool {
        matches!(ext, "mp4" | "avi" | "mov" | "mkv" | "webm" | "flv" | "wmv")
    }

    fn is_audio(ext: &str) -> bool {
        matches!(ext, "mp3" | "wav" | "ogg" | "flac" | "aac" | "m4a")
    }

    fn build_result(&self, analysis: AnalysisOutput, metadata: DetectionMetadata) -> DetectionResult {
        let id = uuid::Uuid::new_v4().to_string();
        
        let threat_level = match analysis.confidence {
            c if c > 0.85 && matches!(analysis.verdict, DetectionVerdict::Deepfake) => ThreatLevel::Critical,
            c if c > 0.70 && matches!(analysis.verdict, DetectionVerdict::Deepfake) => ThreatLevel::High,
            c if c > 0.50 => ThreatLevel::Medium,
            c if c > 0.30 => ThreatLevel::Low,
            _ => ThreatLevel::Minimal,
        };

        DetectionResult {
            id,
            result: analysis.verdict,
            confidence: analysis.confidence,
            analysis: analysis.summary,
            indicators: analysis.indicators,
            metadata,
            moats_passed: analysis.moats_passed,
            threat_level,
        }
    }
}

pub struct AnalysisOutput {
    pub verdict: DetectionVerdict,
    pub confidence: f32,
    pub summary: String,
    pub indicators: Vec<String>,
    pub moats_passed: Vec<String>,
    pub dimensions: Option<(u32, u32)>,
}

impl Default for DetectionEngine {
    fn default() -> Self {
        Self::new()
    }
}
