//! Image Analysis Module
//! 
//! Deepfake detection for static images

use super::AnalysisOutput;
use super::DetectionVerdict;
use image::{DynamicImage, ImageReader, GenericImageView};
use std::path::PathBuf;
use regex::Regex;

pub struct ImageAnalyzer {
    // Detection patterns
    gan_artifact_patterns: Vec<Regex>,
}

impl ImageAnalyzer {
    pub fn new() -> Self {
        Self {
            gan_artifact_patterns: vec![
                // Common GAN fingerprint patterns in metadata
                Regex::new(r"stylegan|progan|stargan|deepfacelab").unwrap(),
                Regex::new(r"stable.?diffusion|midjourney|dall.?e").unwrap(),
            ],
        }
    }

    /// Analyze an image for deepfake indicators
    pub async fn analyze(&self, path: &PathBuf) -> anyhow::Result<AnalysisOutput> {
        // Load image
        let img = ImageReader::open(path)?
            .with_guessed_format()?
            .decode()?;

        let dimensions = (img.width(), img.height());
        
        // Run multiple detection passes
        let mut indicators = Vec::new();
        let mut scores: Vec<f32> = Vec::new();
        let mut moats_passed = Vec::new();

        // 1. Frequency domain analysis
        let freq_score = self.analyze_frequency_domain(&img);
        scores.push(freq_score);
        if freq_score > 0.3 {
            indicators.push(format!("Frequency anomalies detected (score: {:.2})", freq_score));
        }
        if freq_score < 0.2 {
            moats_passed.push("frequency_analysis".to_string());
        }

        // 2. Texture consistency
        let texture_score = self.analyze_texture_consistency(&img);
        scores.push(texture_score);
        if texture_score > 0.3 {
            indicators.push(format!("Texture inconsistencies (score: {:.2})", texture_score));
        }
        if texture_score < 0.2 {
            moats_passed.push("texture_analysis".to_string());
        }

        // 3. Edge artifacts
        let edge_score = self.analyze_edge_artifacts(&img);
        scores.push(edge_score);
        if edge_score > 0.3 {
            indicators.push(format!("Edge artifacts detected (score: {:.2})", edge_score));
        }
        if edge_score < 0.2 {
            moats_passed.push("edge_analysis".to_string());
        }

        // 4. Color histogram analysis
        let color_score = self.analyze_color_histogram(&img);
        scores.push(color_score);
        if color_score > 0.3 {
            indicators.push(format!("Color distribution anomalies (score: {:.2})", color_score));
        }
        if color_score < 0.2 {
            moats_passed.push("color_analysis".to_string());
        }

        // 5. Noise pattern analysis
        let noise_score = self.analyze_noise_patterns(&img);
        scores.push(noise_score);
        if noise_score > 0.3 {
            indicators.push(format!("Unusual noise patterns (score: {:.2})", noise_score));
        }
        if noise_score < 0.2 {
            moats_passed.push("noise_analysis".to_string());
        }

        // Calculate final score
        let avg_score = if !scores.is_empty() {
            scores.iter().sum::<f32>() / scores.len() as f32
        } else {
            0.0
        };

        // Determine verdict
        let (verdict, confidence) = if avg_score > 0.6 {
            (DetectionVerdict::Deepfake, avg_score)
        } else if avg_score > 0.3 {
            (DetectionVerdict::Uncertain, avg_score)
        } else {
            (DetectionVerdict::Authentic, 1.0 - avg_score)
        };

        // Generate summary
        let summary = match &verdict {
            DetectionVerdict::Deepfake => {
                format!("This image shows strong indicators of AI manipulation. {} issues detected.", indicators.len())
            }
            DetectionVerdict::Uncertain => {
                "Some unusual patterns detected, but results are inconclusive. Manual review recommended.".to_string()
            }
            DetectionVerdict::Authentic => {
                "No significant deepfake indicators detected. Image appears authentic.".to_string()
            }
        };

        Ok(AnalysisOutput {
            verdict,
            confidence,
            summary,
            indicators,
            moats_passed,
            dimensions: Some(dimensions),
        })
    }

    /// Analyze frequency domain for GAN artifacts
    fn analyze_frequency_domain(&self, img: &DynamicImage) -> f32 {
        // Simplified FFT analysis
        // GAN-generated images often have characteristic frequency patterns
        let gray = img.to_luma8();
        let (width, height) = gray.dimensions();
        
        // Calculate variance in different regions as a proxy for frequency analysis
        let mut region_variances = Vec::new();
        let region_size = 32;
        
        for y in (0..height).step_by(region_size) {
            for x in (0..width).step_by(region_size) {
                let mut values = Vec::new();
                for dy in 0..region_size.min(height - y) {
                    for dx in 0..region_size.min(width - x) {
                        values.push(gray.get_pixel(x + dx, y + dy).0[0] as f32);
                    }
                }
                if values.len() > 0 {
                    let mean = values.iter().sum::<f32>() / values.len() as f32;
                    let variance = values.iter().map(|v| (v - mean).powi(2)).sum::<f32>() / values.len() as f32;
                    region_variances.push(variance);
                }
            }
        }

        // GAN images often have more uniform variance across regions
        if region_variances.len() > 1 {
            let mean_var = region_variances.iter().sum::<f32>() / region_variances.len() as f32;
            let var_of_var = region_variances.iter()
                .map(|v| (v - mean_var).powi(2))
                .sum::<f32>() / region_variances.len() as f32;
            
            // Low variance of variance suggests AI generation
            if var_of_var < mean_var * 0.1 {
                0.4 + (0.1 - var_of_var / mean_var).min(0.4)
            } else {
                var_of_var / mean_var * 0.3
            }
        } else {
            0.0
        }
    }

    /// Analyze texture consistency
    fn analyze_texture_consistency(&self, img: &DynamicImage) -> f32 {
        // Check for texture inconsistencies common in deepfakes
        let rgba = img.to_rgba8();
        let (width, height) = rgba.dimensions();
        
        // Sample skin-like regions and check texture
        let mut skin_textures: Vec<f32> = Vec::new();
        let mut non_skin_textures: Vec<f32> = Vec::new();
        
        for y in (0..height.saturating_sub(8)).step_by(8) {
            for x in (0..width.saturating_sub(8)).step_by(8) {
                // Calculate local texture measure (gradient magnitude)
                let mut gradient_sum = 0.0;
                for dy in 0..8 {
                    for dx in 0..7 {
                        let p1 = rgba.get_pixel(x + dx, y + dy);
                        let p2 = rgba.get_pixel(x + dx + 1, y + dy);
                        let diff = (p1.0[0] as i32 - p2.0[0] as i32).abs() +
                                   (p1.0[1] as i32 - p2.0[1] as i32).abs() +
                                   (p1.0[2] as i32 - p2.0[2] as i32).abs();
                        gradient_sum += diff as f32;
                    }
                }
                
                let avg_gradient = gradient_sum / 56.0;
                
                // Check if this might be a skin region (simplified)
                let center = rgba.get_pixel(x + 4, y + 4);
                let is_skinish = center.0[0] > 100 && center.0[1] > 70 && center.0[2] > 50 &&
                                 center.0[0] as i32 - center.0[2] as i32 > 10;
                
                if is_skinish {
                    skin_textures.push(avg_gradient);
                } else {
                    non_skin_textures.push(avg_gradient);
                }
            }
        }

        // Check for texture mismatch
        if !skin_textures.is_empty() && !non_skin_textures.is_empty() {
            let skin_mean: f32 = skin_textures.iter().sum::<f32>() / skin_textures.len() as f32;
            let non_skin_mean: f32 = non_skin_textures.iter().sum::<f32>() / non_skin_textures.len() as f32;
            
            // Deepfakes often have smoother skin than surroundings
            if skin_mean < non_skin_mean * 0.7 {
                0.3 + (non_skin_mean / skin_mean - 1.0).min(0.4)
            } else {
                0.0
            }
        } else {
            0.0
        }
    }

    /// Analyze edge artifacts
    fn analyze_edge_artifacts(&self, img: &DynamicImage) -> f32 {
        // Check for unnatural edges around faces/objects
        let rgba = img.to_rgba8();
        let (width, height) = rgba.dimensions();
        
        // Sobel edge detection
        let mut edge_magnitudes = Vec::new();
        
        for y in 1..height.saturating_sub(1) {
            for x in 1..width.saturating_sub(1) {
                let gx = 
                    -1.0 * rgba.get_pixel(x - 1, y - 1).0[0] as f32 +
                     1.0 * rgba.get_pixel(x + 1, y - 1).0[0] as f32 +
                    -2.0 * rgba.get_pixel(x - 1, y).0[0] as f32 +
                     2.0 * rgba.get_pixel(x + 1, y).0[0] as f32 +
                    -1.0 * rgba.get_pixel(x - 1, y + 1).0[0] as f32 +
                     1.0 * rgba.get_pixel(x + 1, y + 1).0[0] as f32;
                
                let gy = 
                    -1.0 * rgba.get_pixel(x - 1, y - 1).0[0] as f32 +
                    -2.0 * rgba.get_pixel(x, y - 1).0[0] as f32 +
                    -1.0 * rgba.get_pixel(x + 1, y - 1).0[0] as f32 +
                     1.0 * rgba.get_pixel(x - 1, y + 1).0[0] as f32 +
                     2.0 * rgba.get_pixel(x, y + 1).0[0] as f32 +
                     1.0 * rgba.get_pixel(x + 1, y + 1).0[0] as f32;
                
                let magnitude = (gx.powi(2) + gy.powi(2)).sqrt();
                edge_magnitudes.push(magnitude);
            }
        }

        // Check for unusual edge patterns
        if edge_magnitudes.is_empty() {
            return 0.0;
        }

        edge_magnitudes.sort_by(|a, b| a.partial_cmp(b).unwrap());
        let median = edge_magnitudes[edge_magnitudes.len() / 2];
        let max = edge_magnitudes[edge_magnitudes.len() - 1];
        
        // Very high max/median ratio suggests sharp artificial edges
        let ratio = max / (median + 1.0);
        if ratio > 20.0 {
            0.4 + (ratio / 100.0).min(0.4)
        } else if ratio > 10.0 {
            0.2 + (ratio - 10.0) / 50.0
        } else {
            0.0
        }
    }

    /// Analyze color histogram
    fn analyze_color_histogram(&self, img: &DynamicImage) -> f32 {
        let rgba = img.to_rgba8();
        
        // Build color histograms
        let mut red_hist = [0u32; 256];
        let mut green_hist = [0u32; 256];
        let mut blue_hist = [0u32; 256];
        
        for pixel in rgba.pixels() {
            red_hist[pixel.0[0] as usize] += 1;
            green_hist[pixel.0[1] as usize] += 1;
            blue_hist[pixel.0[2] as usize] += 1;
        }
        
        // Calculate histogram entropy
        let total = rgba.width() * rgba.height();
        let calc_entropy = |hist: &[u32; 256]| -> f32 {
            let mut entropy = 0.0;
            for &count in hist {
                if count > 0 {
                    let p = count as f32 / total as f32;
                    entropy -= p * p.log2();
                }
            }
            entropy
        };
        
        let r_entropy = calc_entropy(&red_hist);
        let g_entropy = calc_entropy(&green_hist);
        let b_entropy = calc_entropy(&blue_hist);
        
        let avg_entropy = (r_entropy + g_entropy + b_entropy) / 3.0;
        
        // GAN images often have lower entropy (more uniform color distribution)
        if avg_entropy < 5.0 {
            0.3 + (5.0 - avg_entropy) / 10.0
        } else {
            0.0
        }
    }

    /// Analyze noise patterns
    fn analyze_noise_patterns(&self, img: &DynamicImage) -> f32 {
        let gray = img.to_luma8();
        let (width, height) = gray.dimensions();
        
        // Calculate noise level using high-pass filter
        let mut noise_values = Vec::new();
        
        for y in 1..height.saturating_sub(1) {
            for x in 1..width.saturating_sub(1) {
                let center = gray.get_pixel(x, y).0[0] as i32;
                let neighbors = [
                    gray.get_pixel(x - 1, y).0[0] as i32,
                    gray.get_pixel(x + 1, y).0[0] as i32,
                    gray.get_pixel(x, y - 1).0[0] as i32,
                    gray.get_pixel(x, y + 1).0[0] as i32,
                ];
                let avg_neighbor: i32 = neighbors.iter().sum::<i32>() / 4;
                noise_values.push((center - avg_neighbor).abs() as f32);
            }
        }

        if noise_values.is_empty() {
            return 0.0;
        }

        // Calculate noise statistics
        let mean: f32 = noise_values.iter().sum::<f32>() / noise_values.len() as f32;
        let variance: f32 = noise_values.iter()
            .map(|v| (v - mean).powi(2))
            .sum::<f32>() / noise_values.len() as f32;
        let std_dev = variance.sqrt();
        
        // GAN images often have unnatural noise patterns
        // Either too uniform (low std dev) or inconsistent (very high std dev in specific regions)
        if std_dev < 2.0 {
            0.2 + (2.0 - std_dev) / 10.0
        } else if std_dev > 15.0 {
            0.1 + (std_dev - 15.0) / 50.0
        } else {
            0.0
        }
    }
}

impl Default for ImageAnalyzer {
    fn default() -> Self {
        Self::new()
    }
}
