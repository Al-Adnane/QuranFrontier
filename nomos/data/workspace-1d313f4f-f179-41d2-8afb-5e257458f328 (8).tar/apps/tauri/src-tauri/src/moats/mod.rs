//! Security Moats Module
//! 
//! 14 Security Moats for deepfake detection

pub mod dynamic_thresholds;
pub mod brittleness;

pub use dynamic_thresholds::*;
pub use brittleness::*;
