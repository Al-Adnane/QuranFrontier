//! Brittleness Detection (Moat 3)
//! 
//! B(r) = usage/Σusage - Identifies over-relied-upon indicators

use std::collections::HashMap;
use std::sync::Mutex;

lazy_static::lazy_static! {
    static ref INDICATOR_USAGE: Mutex<HashMap<String, u64>> = Mutex::new(HashMap::new());
    static ref TOTAL_USAGE: Mutex<u64> = Mutex::new(0);
}

pub fn record_usage(indicator: &str) {
    let mut usage = INDICATOR_USAGE.lock().unwrap();
    *usage.entry(indicator.to_string()).or_insert(0) += 1;
    
    let mut total = TOTAL_USAGE.lock().unwrap();
    *total += 1;
}

pub fn get_brittleness(indicator: &str) -> f32 {
    let usage = INDICATOR_USAGE.lock().unwrap();
    let total = TOTAL_USAGE.lock().unwrap();
    
    if *total == 0 {
        return 0.0;
    }
    
    let count = usage.get(indicator).copied().unwrap_or(0);
    count as f32 / *total as f32
}

pub fn get_system_brittleness() -> f32 {
    let usage = INDICATOR_USAGE.lock().unwrap();
    let total = TOTAL_USAGE.lock().unwrap();
    
    if *total == 0 || usage.is_empty() {
        return 0.0;
    }
    
    // Calculate Shannon entropy
    let mut entropy = 0.0;
    for &count in usage.values() {
        let p = count as f32 / *total as f32;
        if p > 0.0 {
            entropy -= p * p.log2();
        }
    }
    
    // Normalize by max entropy
    let max_entropy = (usage.len() as f32).log2();
    if max_entropy > 0.0 {
        1.0 - (entropy / max_entropy)
    } else {
        0.0
    }
}
