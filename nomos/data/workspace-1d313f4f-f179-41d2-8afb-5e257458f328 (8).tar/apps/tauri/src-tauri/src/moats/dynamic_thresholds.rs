//! Dynamic Thresholds (Moat 5)
//! 
//! Risk thresholds adjust based on threat environment

use std::sync::atomic::{AtomicU64, Ordering};

static THREAT_SCORE: AtomicU64 = AtomicU64::new(0);

pub fn record_threat(score: u64) {
    THREAT_SCORE.fetch_add(score, Ordering::SeqCst);
}

pub fn get_threat_score() -> u64 {
    THREAT_SCORE.load(Ordering::SeqCst)
}

pub fn get_adjusted_threshold() -> f32 {
    let score = get_threat_score();
    if score > 80 {
        0.3 // High threat - very sensitive
    } else if score > 60 {
        0.5
    } else if score > 40 {
        0.65
    } else if score > 20 {
        0.75
    } else {
        0.8 // Low threat - normal threshold
    }
}

pub fn decay_threat() {
    let current = THREAT_SCORE.load(Ordering::SeqCst);
    if current > 0 {
        let _ = THREAT_SCORE.compare_exchange(
            current,
            current.saturating_sub(1),
            Ordering::SeqCst,
            Ordering::SeqCst,
        );
    }
}
