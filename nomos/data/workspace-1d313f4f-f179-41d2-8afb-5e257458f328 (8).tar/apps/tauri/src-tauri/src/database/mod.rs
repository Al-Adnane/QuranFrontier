//! Database Module
//! 
//! SQLite storage for detection history and settings

use crate::detection::{DetectionResult, DetectionVerdict, MediaType};
use rusqlite::{Connection, params};
use std::path::PathBuf;
use std::sync::Arc;
use tokio::sync::Mutex;
use tauri::Manager;

lazy_static::lazy_static! {
    static ref DB: Arc<Mutex<Option<Connection>>> = Arc::new(Mutex::new(None));
}

/// Initialize database
pub fn init(app_handle: &tauri::AppHandle) -> anyhow::Result<()> {
    let app_dir = app_handle.path().app_data_dir()?;
    std::fs::create_dir_all(&app_dir)?;
    
    let db_path = app_dir.join("kasbah.db");
    let conn = Connection::open(&db_path)?;
    
    // Create tables
    conn.execute_batch("
        CREATE TABLE IF NOT EXISTS detections (
            id TEXT PRIMARY KEY,
            result TEXT NOT NULL,
            confidence REAL NOT NULL,
            analysis TEXT,
            indicators TEXT,
            file_name TEXT,
            file_size INTEGER,
            media_type TEXT,
            threat_level TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        );
        
        CREATE INDEX IF NOT EXISTS idx_detections_created ON detections(created_at);
        CREATE INDEX IF NOT EXISTS idx_detections_result ON detections(result);
    ")?;
    
    // Store connection
    let mut db = DB.blocking_lock();
    *db = Some(conn);
    
    Ok(())
}

/// Save a detection result
pub async fn save_detection(result: &DetectionResult) -> anyhow::Result<()> {
    let db = DB.lock().await;
    let conn = db.as_ref().ok_or_else(|| anyhow::anyhow!("Database not initialized"))?;
    
    let indicators_json = serde_json::to_string(&result.indicators)?;
    let media_type = match result.metadata.media_type {
        MediaType::Image => "image",
        MediaType::Video => "video",
        MediaType::Audio => "audio",
    };
    
    conn.execute(
        "INSERT INTO detections (id, result, confidence, analysis, indicators, file_name, file_size, media_type, threat_level, created_at)
         VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10)",
        params![
            result.id,
            serde_json::to_string(&result.result)?,
            result.confidence,
            result.analysis,
            indicators_json,
            result.metadata.file_name,
            result.metadata.file_size,
            media_type,
            serde_json::to_string(&result.threat_level)?,
            result.metadata.analyzed_at,
        ],
    )?;
    
    Ok(())
}

/// Get detection history
pub async fn get_detections(limit: usize) -> anyhow::Result<Vec<DetectionResult>> {
    let db = DB.lock().await;
    let conn = db.as_ref().ok_or_else(|| anyhow::anyhow!("Database not initialized"))?;
    
    let mut stmt = conn.prepare(
        "SELECT id, result, confidence, analysis, indicators, file_name, file_size, media_type, threat_level, created_at
         FROM detections 
         ORDER BY created_at DESC 
         LIMIT ?1"
    )?;
    
    let results = stmt.query_map(params![limit], |row| {
        let result_str: String = row.get(1)?;
        let result: DetectionVerdict = serde_json::from_str(&result_str).unwrap_or(DetectionVerdict::Uncertain);
        
        let indicators_json: String = row.get(4)?;
        let indicators: Vec<String> = serde_json::from_str(&indicators_json).unwrap_or_default();
        
        let media_type_str: String = row.get(7)?;
        let media_type = match media_type_str.as_str() {
            "video" => MediaType::Video,
            "audio" => MediaType::Audio,
            _ => MediaType::Image,
        };
        
        let threat_level_str: String = row.get(8)?;
        let threat_level = serde_json::from_str(&threat_level_str).unwrap_or_default();
        
        Ok(DetectionResult {
            id: row.get(0)?,
            result,
            confidence: row.get(2)?,
            analysis: row.get(3)?,
            indicators,
            metadata: crate::detection::DetectionMetadata {
                file_name: row.get(5)?,
                file_size: row.get(6)?,
                media_type,
                dimensions: None,
                duration_ms: None,
                analyzed_at: row.get(9)?,
            },
            moats_passed: vec![],
            threat_level,
        })
    })?;
    
    let mut detections = Vec::new();
    for r in results {
        detections.push(r?);
    }
    
    Ok(detections)
}

#[derive(Debug, Default)]
pub struct DbStats {
    pub total_detections: u64,
    pub deepfakes_found: u64,
    pub authentic_count: u64,
    pub recent_deepfakes: Option<u64>,
}

/// Get database statistics
pub async fn get_stats() -> anyhow::Result<DbStats> {
    let db = DB.lock().await;
    let conn = db.as_ref().ok_or_else(|| anyhow::anyhow!("Database not initialized"))?;
    
    let total: u64 = conn.query_row(
        "SELECT COUNT(*) FROM detections",
        [],
        |row| row.get(0)
    )?;
    
    let deepfakes: u64 = conn.query_row(
        "SELECT COUNT(*) FROM detections WHERE result = '\"deepfake\"'",
        [],
        |row| row.get(0)
    )?;
    
    let authentic: u64 = conn.query_row(
        "SELECT COUNT(*) FROM detections WHERE result = '\"authentic\"'",
        [],
        |row| row.get(0)
    )?;
    
    let recent_deepfakes: u64 = conn.query_row(
        "SELECT COUNT(*) FROM detections WHERE result = '\"deepfake\"' AND created_at > datetime('now', '-1 day')",
        [],
        |row| row.get(0)
    )?;
    
    Ok(DbStats {
        total_detections: total,
        deepfakes_found: deepfakes,
        authentic_count: authentic,
        recent_deepfakes: Some(recent_deepfakes),
    })
}

/// Clear all detection history
pub async fn clear_history() -> anyhow::Result<()> {
    let db = DB.lock().await;
    let conn = db.as_ref().ok_or_else(|| anyhow::anyhow!("Database not initialized"))?;
    
    conn.execute("DELETE FROM detections", [])?;
    
    Ok(())
}

/// Get a setting value
pub async fn get_setting(key: &str) -> anyhow::Result<Option<String>> {
    let db = DB.lock().await;
    let conn = db.as_ref().ok_or_else(|| anyhow::anyhow!("Database not initialized"))?;
    
    let result = conn.query_row(
        "SELECT value FROM settings WHERE key = ?1",
        [key],
        |row| row.get(0)
    );
    
    match result {
        Ok(v) => Ok(Some(v)),
        Err(rusqlite::Error::QueryReturnedNoRows) => Ok(None),
        Err(e) => Err(e.into()),
    }
}

/// Set a setting value
pub async fn set_setting(key: &str, value: &str) -> anyhow::Result<()> {
    let db = DB.lock().await;
    let conn = db.as_ref().ok_or_else(|| anyhow::anyhow!("Database not initialized"))?;
    
    conn.execute(
        "INSERT OR REPLACE INTO settings (key, value) VALUES (?1, ?2)",
        [key, value],
    )?;
    
    Ok(())
}
