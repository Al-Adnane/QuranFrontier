//! Social Media Browser Module
//! 
//! Built-in browser with real-time detection for desktop app

use tauri::{WebviewUrl, WebviewWindowBuilder, Manager, AppHandle};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SocialPlatform {
    pub id: String,
    pub name: String,
    pub url: String,
    pub icon: String,
}

pub const SOCIAL_PLATFORMS: &[SocialPlatform] = &[
    SocialPlatform { id: "tiktok", name: "TikTok", url: "https://www.tiktok.com", icon: "music" },
    SocialPlatform { id: "instagram", name: "Instagram", url: "https://www.instagram.com", icon: "camera" },
    SocialPlatform { id: "youtube", name: "YouTube", url: "https://www.youtube.com", icon: "play" },
    SocialPlatform { id: "twitter", name: "Twitter/X", url: "https://www.twitter.com", icon: "twitter" },
    SocialPlatform { id: "facebook", name: "Facebook", url: "https://www.facebook.com", icon: "facebook" },
];

/// Content script for injection (from realtime module)
pub fn get_content_script() -> String {
    super::CONTENT_SCRIPT.to_string()
}

/// Open a social media browser window
#[tauri::command]
pub async fn open_social_browser(
    app: AppHandle,
    platform_id: String,
) -> Result<(), String> {
    let platform = SOCIAL_PLATFORMS
        .iter()
        .find(|p| p.id == platform_id)
        .ok_or_else(|| format!("Platform not found: {}", platform_id))?;
    
    let window_label = format!("browser_{}", platform.id);
    
    // Check if window already exists
    if app.get_webview_window(&window_label).is_some() {
        if let Some(window) = app.get_webview_window(&window_label) {
            window.set_focus().map_err(|e| e.to_string())?;
        }
        return Ok(());
    }
    
    let script = get_content_script();
    
    let _window = WebviewWindowBuilder::new(
        &app,
        &window_label,
        WebviewUrl::External(platform.url.parse().unwrap())
    )
    .title(format!("Kasbah - {}", platform.name))
    .inner_size(1200.0, 800.0)
    .min_inner_size(800.0, 600.0)
    .resizable(true)
    .initialization_script(&script)
    .build()
    .map_err(|e| e.to_string())?;
    
    Ok(())
}

/// Get list of supported platforms
#[tauri::command]
pub fn get_social_platforms() -> Vec<SocialPlatform> {
    SOCIAL_PLATFORMS.to_vec()
}

/// Inject detection script into current page
#[tauri::command]
pub async fn inject_detection_script(
    app: AppHandle,
    window_label: String,
) -> Result<(), String> {
    let window = app.get_webview_window(&window_label)
        .ok_or_else(|| "Window not found".to_string())?;
    
    let script = get_content_script();
    
    window.eval(&script).map_err(|e| e.to_string())?;
    
    Ok(())
}
