//! Kasbah Desktop - Tauri Backend
//! 
//! Native deepfake detection with real-time capabilities

mod detection;
mod secret_guard;
mod moats;
mod commands;
mod database;
mod utils;
mod realtime;

use tauri::Manager;
use tauri_plugin_notification::NotificationExt;

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_shell::init())
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_fs::init())
        .plugin(tauri_plugin_notification::init())
        .plugin(tauri_plugin_clipboard::init())
        .setup(|app| {
            // Initialize database
            let app_handle = app.handle();
            database::init(&app_handle)?;
            
            // Setup system tray with realtime options
            #[cfg(desktop)]
            {
                use tauri::menu::{Menu, MenuItem, Submenu};
                use tauri::tray::TrayIconBuilder;
                
                let quit = MenuItem::with_id(app, "quit", "Quit", true, None::<&str>)?;
                let scan_clipboard = MenuItem::with_id(app, "scan_clipboard", "Scan Clipboard", true, None::<&str>)?;
                
                // Platform submenu
                let tiktok = MenuItem::with_id(app, "open_tiktok", "TikTok", true, None::<&str>)?;
                let instagram = MenuItem::with_id(app, "open_instagram", "Instagram", true, None::<&str>)?;
                let youtube = MenuItem::with_id(app, "open_youtube", "YouTube", true, None::<&str>)?;
                let twitter = MenuItem::with_id(app, "open_twitter", "Twitter/X", true, None::<&str>)?;
                
                let platforms_menu = Submenu::with_items(app, "Open Platform", true, &[
                    &tiktok, &instagram, &youtube, &twitter
                ])?;
                
                let menu = Menu::with_items(app, &[
                    &scan_clipboard,
                    &platforms_menu,
                    &quit
                ])?;
                
                let _tray = TrayIconBuilder::new()
                    .menu(&menu)
                    .tooltip("Kasbah - Real-time Deepfake Detection")
                    .on_menu_event(|app, event| {
                        match event.id.as_ref() {
                            "quit" => app.exit(0),
                            "scan_clipboard" => {
                                // Trigger clipboard scan
                                let _ = app.emit("scan-clipboard", ());
                            }
                            "open_tiktok" => {
                                let _ = tauri::async_runtime::block_on(
                                    realtime::browser::open_social_browser(app.clone(), "tiktok".to_string())
                                );
                            }
                            "open_instagram" => {
                                let _ = tauri::async_runtime::block_on(
                                    realtime::browser::open_social_browser(app.clone(), "instagram".to_string())
                                );
                            }
                            "open_youtube" => {
                                let _ = tauri::async_runtime::block_on(
                                    realtime::browser::open_social_browser(app.clone(), "youtube".to_string())
                                );
                            }
                            "open_twitter" => {
                                let _ = tauri::async_runtime::block_on(
                                    realtime::browser::open_social_browser(app.clone(), "twitter".to_string())
                                );
                            }
                            _ => {}
                        }
                    })
                    .build(app)?;
            }
            
            // Spawn background secret guard
            let guard_handle = app_handle.clone();
            tokio::spawn(async move {
                secret_guard::start_clipboard_guard(guard_handle).await;
            });
            
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            commands::analyze_file,
            commands::analyze_url,
            commands::analyze_clipboard_image,
            commands::get_detection_history,
            commands::get_stats,
            commands::scan_secrets,
            commands::check_url_safety,
            commands::export_results,
            commands::get_threat_level,
            commands::run_stress_test,
            // Real-time detection commands
            realtime::browser::open_social_browser,
            realtime::browser::get_social_platforms,
            realtime::browser::inject_detection_script,
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
