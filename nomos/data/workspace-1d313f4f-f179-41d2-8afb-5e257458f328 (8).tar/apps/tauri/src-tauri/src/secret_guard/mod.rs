//! Secret Guard Module
//! 
//! Monitors clipboard and protects against secret exfiltration

use regex::Regex;
use std::sync::Arc;
use tauri::{AppHandle, Manager};
use tokio::sync::RwLock;
use parking_lot::Mutex;

lazy_static::lazy_static! {
    static ref SECRET_PATTERNS: Vec<SecretPattern> = vec![
        SecretPattern::new("openai-key", r"sk-[a-zA-Z0-9]{20}T3BlbkFJ[a-zA-Z0-9]{20}"),
        SecretPattern::new("openai-project", r"sk-proj-[a-zA-Z0-9]{32,}"),
        SecretPattern::new("anthropic-key", r"sk-ant-api03-[a-zA-Z0-9\-]{80,}"),
        SecretPattern::new("stripe-live", r"sk_live_[a-zA-Z0-9]{24,}"),
        SecretPattern::new("stripe-test", r"sk_test_[a-zA-Z0-9]{24,}"),
        SecretPattern::new("aws-key", r"AKIA[0-9A-Z]{16}"),
        SecretPattern::new("github-token", r"ghp_[a-zA-Z0-9]{36}"),
        SecretPattern::new("google-api", r"AIza[a-zA-Z0-9\-_]{35}"),
        SecretPattern::new("slack-bot", r"xoxb-[0-9]{10,13}-[0-9]{10,13}-[a-zA-Z0-9]{24}"),
        SecretPattern::new("private-key", r"-----BEGIN (RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----"),
        SecretPattern::new("postgres-url", r"postgres(ql)?:\/\/[^:]+:[^@]+@[a-zA-Z0-9.\-]+"),
        SecretPattern::new("mongodb-url", r"mongodb(\+srv)?:\/\/[^:]+:[^@]+@[a-zA-Z0-9.\-]+"),
    ];
    
    static ref STATS: Arc<Mutex<GuardStats>> = Arc::new(Mutex::new(GuardStats::default()));
}

struct SecretPattern {
    name: &'static str,
    regex: Regex,
}

impl SecretPattern {
    fn new(name: &'static str, pattern: &str) -> Self {
        Self {
            name,
            regex: Regex::new(pattern).unwrap(),
        }
    }
    
    fn check(&self, text: &str) -> bool {
        self.regex.is_match(text)
    }
}

#[derive(Default, serde::Serialize)]
pub struct GuardStats {
    pub secrets_blocked: u64,
    pub clipboard_scans: u64,
    pub last_secret_type: Option<String>,
}

/// Check if text contains any secrets
pub fn contains_secret(text: &str) -> Option<String> {
    for pattern in SECRET_PATTERNS.iter() {
        if pattern.check(text) {
            return Some(pattern.name.to_string());
        }
    }
    None
}

/// Start clipboard guard background task
pub async fn start_clipboard_guard(app_handle: AppHandle) {
    let mut last_content = String::new();
    
    loop {
        tokio::time::sleep(tokio::time::Duration::from_millis(500)).await;
        
        // Try to get clipboard content
        if let Some(clipboard) = app_handle.try_state::<tauri_plugin_clipboard::Clipboard>() {
            match clipboard.read_text() {
                Ok(content) => {
                    if content != last_content && !content.is_empty() {
                        last_content = content.clone();
                        
                        // Update stats
                        {
                            let mut stats = STATS.lock();
                            stats.clipboard_scans += 1;
                        }
                        
                        // Check for secrets
                        if let Some(secret_type) = contains_secret(&content) {
                            // Update stats
                            {
                                let mut stats = STATS.lock();
                                stats.secrets_blocked += 1;
                                stats.last_secret_type = Some(secret_type.clone());
                            }
                            
                            // Show notification
                            let _ = app_handle.notification()
                                .builder()
                                .title("Kasbah: Secret Detected")
                                .body(&format!("A {} was detected in your clipboard. Be careful when pasting!", secret_type))
                                .show();
                        }
                    }
                }
                Err(_) => continue,
            }
        }
    }
}

/// Get guard statistics
pub fn get_stats() -> GuardStats {
    STATS.lock().clone()
}

/// Scan text for secrets (used by commands)
pub fn scan_for_secrets(text: &str) -> Vec<String> {
    SECRET_PATTERNS
        .iter()
        .filter(|p| p.check(text))
        .map(|p| p.name.to_string())
        .collect()
}

/// Redact secrets from text
pub fn redact_secrets(text: &str) -> String {
    let mut result = text.to_string();
    for pattern in SECRET_PATTERNS.iter() {
        result = pattern.regex.replace_all(&result, format!("[{}_REDACTED]", pattern.name.to_uppercase())).to_string();
    }
    result
}
