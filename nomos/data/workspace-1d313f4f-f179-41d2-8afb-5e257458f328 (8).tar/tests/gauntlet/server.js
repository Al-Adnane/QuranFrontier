/**
 * Kasbah Gauntlet Test Server
 * Stress test for secret detection and blocking
 * 
 * Run: node tests/gauntlet/server.js
 * Open: http://localhost:8789/gauntlet.html
 */

import http from 'http'
import { readFileSync, existsSync } from 'fs'
import { fileURLToPath } from 'url'
import { dirname, join } from 'path'

const __dirname = dirname(fileURLToPath(import.meta.url))

const PORT = 8789

// Test log
const testLog = []
let secretFound = false

// Test secret pattern
const TEST_SECRET = 'sk-proj-1234567890abcdefghijklmnopqrstuvwxyz'

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`)
  
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type')
  
  if (req.method === 'OPTIONS') {
    res.writeHead(200)
    res.end()
    return
  }
  
  // Collect endpoint - receives test attempts
  if (url.pathname === '/collect') {
    let body = ''
    req.on('data', chunk => body += chunk)
    req.on('end', () => {
      const timestamp = new Date().toISOString()
      
      // Check for secret in body
      if (body.includes(TEST_SECRET)) {
        secretFound = true
        testLog.push({
          timestamp,
          method: req.method,
          path: url.pathname,
          status: 'FAIL',
          reason: 'SECRET FOUND',
          body: body.slice(0, 200)
        })
        console.log(`[${timestamp}] ${req.method} ${url.pathname} 🚨 FAIL — SECRET FOUND`)
        console.log(`  Body: ${body.slice(0, 200)}`)
      } else if (url.search.includes(TEST_SECRET)) {
        secretFound = true
        testLog.push({
          timestamp,
          method: req.method,
          path: url.pathname + url.search,
          status: 'FAIL',
          reason: 'SECRET IN URL'
        })
        console.log(`[${timestamp}] ${req.method} ${url.pathname} 🚨 FAIL — SECRET IN URL`)
      } else {
        testLog.push({
          timestamp,
          method: req.method,
          path: url.pathname,
          status: 'PASS',
          body: body.slice(0, 100)
        })
        console.log(`[${timestamp}] ${req.method} ${url.pathname} ✓ clean`)
      }
      
      res.writeHead(200, { 'Content-Type': 'application/json' })
      res.end(JSON.stringify({ received: true }))
    })
    return
  }
  
  // WebSocket upgrade
  if (url.pathname === '/ws') {
    // Handle WebSocket upgrade
    res.writeHead(426, { 'Content-Type': 'text/plain' })
    res.end('Upgrade Required')
    return
  }
  
  // Results endpoint
  if (url.pathname === '/results') {
    res.writeHead(200, { 'Content-Type': 'application/json' })
    res.end(JSON.stringify({
      secretFound,
      totalTests: testLog.length,
      passed: testLog.filter(t => t.status === 'PASS').length,
      failed: testLog.filter(t => t.status === 'FAIL').length,
      log: testLog
    }, null, 2))
    return
  }
  
  // Serve gauntlet.html
  if (url.pathname === '/gauntlet.html' || url.pathname === '/') {
    const htmlPath = join(__dirname, 'gauntlet.html')
    if (existsSync(htmlPath)) {
      res.writeHead(200, { 'Content-Type': 'text/html' })
      res.end(readFileSync(htmlPath))
    } else {
      res.writeHead(404)
      res.end('gauntlet.html not found')
    }
    return
  }
  
  // 404
  res.writeHead(404)
  res.end('Not found')
})

// WebSocket server for testing
import { WebSocketServer } from 'ws'
const wss = new WebSocketServer({ port: 8790 })

wss.on('connection', (ws) => {
  ws.on('message', (data) => {
    const timestamp = new Date().toISOString()
    const message = data.toString()
    
    if (message.includes(TEST_SECRET)) {
      secretFound = true
      testLog.push({
        timestamp,
        method: 'WS',
        status: 'FAIL',
        reason: 'SECRET IN WS'
      })
      console.log(`[${timestamp}] WS message 🚨 FAIL — SECRET FOUND IN WS`)
    } else {
      testLog.push({
        timestamp,
        method: 'WS',
        status: 'PASS'
      })
      console.log(`[${timestamp}] WS message ✓ clean`)
    }
    
    ws.send(JSON.stringify({ received: true }))
  })
})

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\n')
  console.log('━'.repeat(45))
  console.log('  GAUNTLET VERDICT')
  console.log('━'.repeat(45))
  
  if (secretFound) {
    console.log('  🚨 FAIL — Secret was exfiltrated!')
    console.log(`  ${testLog.filter(t => t.status === 'FAIL').length} vectors leaked the secret`)
  } else {
    console.log('  ✅ PASS — No secrets leaked')
  }
  
  console.log(`\n  Total tests: ${testLog.length}`)
  console.log(`  Passed: ${testLog.filter(t => t.status === 'PASS').length}`)
  console.log(`  Failed: ${testLog.filter(t => t.status === 'FAIL').length}`)
  console.log('━'.repeat(45))
  
  process.exit(secretFound ? 1 : 0)
})

server.listen(PORT, () => {
  console.log('━'.repeat(45))
  console.log('  Kasbah Gauntlet Server')
  console.log(`  http://localhost:${PORT}/gauntlet.html`)
  console.log('  Open with Kasbah extension active.')
  console.log('  Ctrl+C to stop and see full verdict.')
  console.log('━'.repeat(45))
})
