import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';
import path from 'path';

const SIZES = [72, 96, 128, 144, 152, 192, 384, 512];

async function generateIcons() {
  const zai = await ZAI.create();
  const outputDir = './public/icons';
  
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }

  const prompt = `App icon for "Deepfake Detector" - a security app with a shield emblem, purple and pink gradient colors, minimalist modern design, clean professional look, no text, centered composition, simple geometric shapes`;

  console.log('Generating main icon (1024x1024)...');
  
  const response = await zai.images.generations.create({
    prompt,
    size: '1024x1024'
  });

  const imageBase64 = response.data[0].base64;
  const mainBuffer = Buffer.from(imageBase64, 'base64');
  
  // Save the main high-res version
  fs.writeFileSync(path.join(outputDir, 'icon-original.png'), mainBuffer);
  
  // For simplicity in this demo, we'll copy the same image for all sizes
  // In production, you'd use sharp or similar to resize
  for (const size of SIZES) {
    const filename = `icon-${size}.png`;
    fs.writeFileSync(path.join(outputDir, filename), mainBuffer);
    console.log(`✓ Generated: ${filename}`);
  }

  console.log('\n✅ All icons generated successfully!');
}

generateIcons().catch(console.error);
