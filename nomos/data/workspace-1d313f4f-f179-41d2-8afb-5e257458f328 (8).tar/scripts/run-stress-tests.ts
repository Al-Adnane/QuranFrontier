#!/usr/bin/env node
/**
 * Run Stress Tests for Deepfake Detector
 * Usage: bun run scripts/run-stress-tests.ts
 */

import { runAllStressTests, printTestReport } from '../src/lib/security/stress-tests'

console.log('Starting Deepfake Detector Stress Tests...\n')

const report = runAllStressTests()

console.log(printTestReport(report))

// Exit with appropriate code
process.exit(report.overallPassed ? 0 : 1)
