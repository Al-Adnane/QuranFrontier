/**
 * Explainable AI Frontier Module
 * 
 * Transparent, interpretable deepfake detection decisions.
 * Provides human-understandable explanations for every detection.
 * 
 * @module frontier/explainable-ai
 * @version 1.0.0
 * 
 * Capabilities:
 * - Feature Attribution (Why this was flagged)
 * - Decision Path Visualization
 * - Confidence Breakdown
 * - Counterfactual Explanations
 * - Natural Language Explanations
 * - Evidence Highlighting
 * - Uncertainty Quantification
 * - Model Behavior Insights
 */

// ============================================================================
// TYPES
// ============================================================================

/**
 * Explanation type
 */
export type ExplanationType = 
  | 'feature_attribution'
  | 'decision_path'
  | 'counterfactual'
  | 'natural_language'
  | 'evidence_highlight'
  | 'uncertainty';

/**
 * Feature importance
 */
export interface FeatureImportance {
  featureId: string;
  featureName: string;
  importance: number;
  direction: 'positive' | 'negative';
  description: string;
  evidence: string[];
}

/**
 * Detection explanation
 */
export interface DetectionExplanation {
  id: string;
  detectionId: string;
  summary: string;
  detailedExplanation: string;
  featureImportances: FeatureImportance[];
  decisionPath: DecisionStep[];
  counterfactuals: CounterfactualExplanation[];
  evidenceHighlights: EvidenceHighlight[];
  confidenceBreakdown: ConfidenceBreakdown;
  uncertaintyAnalysis: UncertaintyAnalysis;
  naturalLanguageSummary: string;
  timestamp: number;
}

/**
 * Decision step in the detection path
 */
export interface DecisionStep {
  stepId: number;
  name: string;
  description: string;
  input: string;
  output: string;
  confidenceContribution: number;
  featureUsed: string;
  threshold: number;
  actualValue: number;
  passed: boolean;
}

/**
 * Counterfactual explanation
 */
export interface CounterfactualExplanation {
  id: string;
  originalResult: 'authentic' | 'deepfake';
  counterfactualResult: 'authentic' | 'deepfake';
  changesRequired: FeatureChange[];
  distance: number;
  plausibility: number;
  description: string;
}

/**
 * Feature change for counterfactual
 */
export interface FeatureChange {
  featureId: string;
  featureName: string;
  originalValue: number;
  requiredValue: number;
  changeMagnitude: number;
  feasibility: 'easy' | 'moderate' | 'difficult' | 'impossible';
}

/**
 * Evidence highlight
 */
export interface EvidenceHighlight {
  id: string;
  type: 'region' | 'temporal' | 'frequency' | 'artifact';
  location: {
    x?: number;
    y?: number;
    width?: number;
    height?: number;
    startTime?: number;
    endTime?: number;
    frequencyRange?: [number, number];
  };
  description: string;
  severity: number;
  visualIndicator: string;
}

/**
 * Confidence breakdown
 */
export interface ConfidenceBreakdown {
  overall: number;
  byModel: Map<string, number>;
  byFeature: Map<string, number>;
  byRegion: Map<string, number>;
  temporalStability: number;
  modelAgreement: number;
  featureConsensus: number;
}

/**
 * Uncertainty analysis
 */
export interface UncertaintyAnalysis {
  epistemicUncertainty: number; // Model uncertainty
  aleatoricUncertainty: number; // Data uncertainty
  totalUncertainty: number;
  uncertaintySources: UncertaintySource[];
  confidenceInterval: [number, number];
  predictionReliability: number;
}

/**
 * Uncertainty source
 */
export interface UncertaintySource {
  source: string;
  contribution: number;
  description: string;
  mitigation: string;
}

/**
 * Model behavior insight
 */
export interface ModelBehaviorInsight {
  modelId: string;
  strengthAreas: string[];
  weaknessAreas: string[];
  biasDetected: string[];
  typicalErrors: string[];
  recommendedUsage: string[];
}

/**
 * Explanation configuration
 */
export interface ExplanationConfig {
  includeFeatureImportance: boolean;
  includeDecisionPath: boolean;
  includeCounterfactuals: boolean;
  includeEvidenceHighlights: boolean;
  includeUncertaintyAnalysis: boolean;
  maxFeaturesToShow: number;
  naturalLanguageDetail: 'brief' | 'standard' | 'detailed';
  targetAudience: 'technical' | 'general' | 'expert';
}

// ============================================================================
// STORAGE
// ============================================================================

const explanations = new Map<string, DetectionExplanation>();
const modelInsights = new Map<string, ModelBehaviorInsight>();

const DEFAULT_CONFIG: ExplanationConfig = {
  includeFeatureImportance: true,
  includeDecisionPath: true,
  includeCounterfactuals: true,
  includeEvidenceHighlights: true,
  includeUncertaintyAnalysis: true,
  maxFeaturesToShow: 10,
  naturalLanguageDetail: 'standard',
  targetAudience: 'general'
};

// ============================================================================
// EXPLANATION GENERATION
// ============================================================================

/**
 * Generate comprehensive explanation for detection
 */
export function generateExplanation(
  detectionId: string,
  features: Map<string, number>,
  modelOutputs: Map<string, number>,
  detectionResult: 'authentic' | 'deepfake' | 'uncertain',
  confidence: number,
  config: Partial<ExplanationConfig> = {}
): DetectionExplanation {
  const cfg = { ...DEFAULT_CONFIG, ...config };
  const id = `explain_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  
  // Generate feature importances
  const featureImportances = cfg.includeFeatureImportance
    ? generateFeatureImportances(features, detectionResult, cfg.maxFeaturesToShow)
    : [];
  
  // Generate decision path
  const decisionPath = cfg.includeDecisionPath
    ? generateDecisionPath(features, modelOutputs, detectionResult)
    : [];
  
  // Generate counterfactuals
  const counterfactuals = cfg.includeCounterfactuals
    ? generateCounterfactuals(features, detectionResult, confidence)
    : [];
  
  // Generate evidence highlights
  const evidenceHighlights = cfg.includeEvidenceHighlights
    ? generateEvidenceHighlights(features, detectionResult)
    : [];
  
  // Generate confidence breakdown
  const confidenceBreakdown = generateConfidenceBreakdown(
    features,
    modelOutputs,
    confidence
  );
  
  // Generate uncertainty analysis
  const uncertaintyAnalysis = cfg.includeUncertaintyAnalysis
    ? generateUncertaintyAnalysis(features, modelOutputs, confidence)
    : generateDefaultUncertainty();
  
  // Generate natural language summary
  const naturalLanguageSummary = generateNaturalLanguageSummary(
    detectionResult,
    confidence,
    featureImportances,
    decisionPath,
    cfg
  );
  
  // Generate summary and detailed explanation
  const summary = generateSummary(detectionResult, confidence, featureImportances);
  const detailedExplanation = generateDetailedExplanation(
    detectionResult,
    confidence,
    featureImportances,
    decisionPath,
    counterfactuals,
    uncertaintyAnalysis,
    cfg
  );
  
  const explanation: DetectionExplanation = {
    id,
    detectionId,
    summary,
    detailedExplanation,
    featureImportances,
    decisionPath,
    counterfactuals,
    evidenceHighlights,
    confidenceBreakdown,
    uncertaintyAnalysis,
    naturalLanguageSummary,
    timestamp: Date.now()
  };
  
  explanations.set(id, explanation);
  
  return explanation;
}

/**
 * Generate feature importances
 */
function generateFeatureImportances(
  features: Map<string, number>,
  result: 'authentic' | 'deepfake' | 'uncertain',
  maxFeatures: number
): FeatureImportance[] {
  const importances: FeatureImportance[] = [];
  
  // Calculate importance for each feature
  for (const [featureId, value] of features) {
    const importance = calculateFeatureImportance(featureId, value, result);
    
    importances.push({
      featureId,
      featureName: getFeatureDisplayName(featureId),
      importance: Math.abs(importance),
      direction: importance > 0 ? 'positive' : 'negative',
      description: getFeatureDescription(featureId, value),
      evidence: generateFeatureEvidence(featureId, value, result)
    });
  }
  
  // Sort by importance and limit
  return importances
    .sort((a, b) => b.importance - a.importance)
    .slice(0, maxFeatures);
}

/**
 * Calculate feature importance
 */
function calculateFeatureImportance(
  featureId: string,
  value: number,
  result: 'authentic' | 'deepfake' | 'uncertain'
): number {
  // Feature importance weights based on domain knowledge
  const weights: Record<string, number> = {
    'facial_landmarks_deviation': 0.3,
    'temporal_consistency': 0.25,
    'frequency_artifacts': 0.2,
    'edge_consistency': 0.15,
    'color_distribution': 0.1,
    'noise_pattern': 0.15,
    'blink_rate': 0.1,
    'lip_sync_score': 0.2,
    'skin_texture': 0.15,
    'lighting_consistency': 0.1
  };
  
  const weight = weights[featureId] || 0.05;
  const normalizedValue = Math.abs(value - 0.5) * 2;
  
  // Direction based on result
  const direction = result === 'deepfake' ? -1 : 1;
  
  return weight * normalizedValue * direction;
}

/**
 * Get display name for feature
 */
function getFeatureDisplayName(featureId: string): string {
  const names: Record<string, string> = {
    'facial_landmarks_deviation': 'Facial Landmark Deviation',
    'temporal_consistency': 'Temporal Consistency',
    'frequency_artifacts': 'Frequency Artifacts',
    'edge_consistency': 'Edge Consistency',
    'color_distribution': 'Color Distribution',
    'noise_pattern': 'Noise Pattern',
    'blink_rate': 'Blink Rate',
    'lip_sync_score': 'Lip Sync Score',
    'skin_texture': 'Skin Texture Analysis',
    'lighting_consistency': 'Lighting Consistency'
  };
  
  return names[featureId] || featureId.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
}

/**
 * Get feature description
 */
function getFeatureDescription(featureId: string, value: number): string {
  const descriptions: Record<string, (v: number) => string> = {
    'facial_landmarks_deviation': (v) => v > 0.5 
      ? 'Facial landmarks show expected alignment' 
      : 'Facial landmarks deviate from natural patterns',
    'temporal_consistency': (v) => v > 0.5
      ? 'Frame-to-frame transitions appear natural'
      : 'Temporal inconsistencies detected between frames',
    'frequency_artifacts': (v) => v > 0.5
      ? 'Frequency spectrum shows natural distribution'
      : 'Unusual frequency artifacts detected',
    'edge_consistency': (v) => v > 0.5
      ? 'Edges are consistent with natural imagery'
      : 'Edge patterns show manipulation indicators',
    'noise_pattern': (v) => v > 0.5
      ? 'Noise distribution appears natural'
      : 'Noise patterns inconsistent with camera capture'
  };
  
  const desc = descriptions[featureId];
  return desc ? desc(value) : `Feature value: ${value.toFixed(2)}`;
}

/**
 * Generate evidence for feature
 */
function generateFeatureEvidence(
  featureId: string,
  value: number,
  result: 'authentic' | 'deepfake' | 'uncertain'
): string[] {
  const evidence: string[] = [];
  
  if (result === 'deepfake') {
    if (value < 0.3) {
      evidence.push(`Strong indicator: ${getFeatureDisplayName(featureId)} significantly deviates from normal`);
    } else if (value < 0.5) {
      evidence.push(`Moderate indicator: ${getFeatureDisplayName(featureId)} shows some deviation`);
    }
  } else if (result === 'authentic') {
    if (value > 0.7) {
      evidence.push(`Strong support: ${getFeatureDisplayName(featureId)} is within normal range`);
    } else if (value > 0.5) {
      evidence.push(`Moderate support: ${getFeatureDisplayName(featureId)} is acceptable`);
    }
  }
  
  return evidence;
}

/**
 * Generate decision path
 */
function generateDecisionPath(
  features: Map<string, number>,
  modelOutputs: Map<string, number>,
  result: 'authentic' | 'deepfake' | 'uncertain'
): DecisionStep[] {
  const steps: DecisionStep[] = [];
  let stepId = 0;
  
  // Step 1: Initial feature extraction
  steps.push({
    stepId: stepId++,
    name: 'Feature Extraction',
    description: 'Extract relevant features from input media',
    input: 'Raw media data',
    output: `${features.size} features extracted`,
    confidenceContribution: 0,
    featureUsed: 'all',
    threshold: 0,
    actualValue: features.size,
    passed: true
  });
  
  // Step 2: Primary detection
  const primaryFeatures = ['facial_landmarks_deviation', 'temporal_consistency'];
  for (const feat of primaryFeatures) {
    const value = features.get(feat) || 0.5;
    const threshold = 0.4;
    
    steps.push({
      stepId: stepId++,
      name: `Primary Check: ${getFeatureDisplayName(feat)}`,
      description: getFeatureDescription(feat, value),
      input: `Feature value: ${value.toFixed(3)}`,
      output: value > threshold ? 'Pass' : 'Flagged',
      confidenceContribution: value > threshold ? 0.1 : -0.15,
      featureUsed: feat,
      threshold,
      actualValue: value,
      passed: value > threshold
    });
  }
  
  // Step 3: Model ensemble evaluation
  let ensembleContribution = 0;
  for (const [modelId, output] of modelOutputs) {
    const threshold = 0.5;
    const passed = result === 'authentic' ? output > threshold : output <= threshold;
    
    steps.push({
      stepId: stepId++,
      name: `Model: ${modelId}`,
      description: `Evaluation by ${modelId} detection model`,
      input: 'Extracted features',
      output: `Score: ${output.toFixed(3)}`,
      confidenceContribution: passed ? 0.1 : -0.05,
      featureUsed: 'all',
      threshold,
      actualValue: output,
      passed
    });
    
    ensembleContribution += passed ? 0.05 : -0.025;
  }
  
  // Step 4: Final aggregation
  steps.push({
    stepId: stepId++,
    name: 'Final Decision',
    description: `Aggregate all signals to determine final result: ${result}`,
    input: 'All feature and model outputs',
    output: result.toUpperCase(),
    confidenceContribution: 0,
    featureUsed: 'all',
    threshold: 0.5,
    actualValue: modelOutputs.size > 0 
      ? Array.from(modelOutputs.values()).reduce((a, b) => a + b, 0) / modelOutputs.size 
      : 0.5,
    passed: result === 'authentic'
  });
  
  return steps;
}

/**
 * Generate counterfactual explanations
 */
function generateCounterfactuals(
  features: Map<string, number>,
  result: 'authentic' | 'deepfake' | 'uncertain',
  confidence: number
): CounterfactualExplanation[] {
  if (result === 'uncertain') {
    return []; // No clear counterfactual for uncertain
  }
  
  const counterfactualResult = result === 'authentic' ? 'deepfake' : 'authentic';
  const changes: FeatureChange[] = [];
  
  // Find features that could change the result
  const sortedFeatures = Array.from(features.entries())
    .sort((a, b) => Math.abs(b[1] - 0.5) - Math.abs(a[1] - 0.5));
  
  for (const [featureId, value] of sortedFeatures.slice(0, 3)) {
    const requiredValue = result === 'authentic' ? Math.max(0, value - 0.3) : Math.min(1, value + 0.3);
    const changeMagnitude = Math.abs(requiredValue - value);
    
    let feasibility: FeatureChange['feasibility'];
    if (changeMagnitude < 0.1) feasibility = 'easy';
    else if (changeMagnitude < 0.2) feasibility = 'moderate';
    else if (changeMagnitude < 0.4) feasibility = 'difficult';
    else feasibility = 'impossible';
    
    changes.push({
      featureId,
      featureName: getFeatureDisplayName(featureId),
      originalValue: value,
      requiredValue,
      changeMagnitude,
      feasibility
    });
  }
  
  // Calculate distance and plausibility
  const distance = changes.reduce((sum, c) => sum + c.changeMagnitude, 0) / changes.length;
  const plausibility = Math.max(0, 1 - distance);
  
  return [{
    id: `cf_${Date.now()}`,
    originalResult: result,
    counterfactualResult,
    changesRequired: changes,
    distance,
    plausibility,
    description: `To be classified as ${counterfactualResult}, the following changes would be needed: ${changes.map(c => c.featureName).join(', ')}`
  }];
}

/**
 * Generate evidence highlights
 */
function generateEvidenceHighlights(
  features: Map<string, number>,
  result: 'authentic' | 'deepfake' | 'uncertain'
): EvidenceHighlight[] {
  const highlights: EvidenceHighlight[] = [];
  
  if (result === 'deepfake') {
    // Highlight facial region
    if ((features.get('facial_landmarks_deviation') || 0.5) < 0.4) {
      highlights.push({
        id: `highlight_${Date.now()}_0`,
        type: 'region',
        location: { x: 0.3, y: 0.2, width: 0.4, height: 0.5 },
        description: 'Facial region showing manipulation indicators',
        severity: 0.8,
        visualIndicator: 'red_rectangle'
      });
    }
    
    // Highlight temporal issues
    if ((features.get('temporal_consistency') || 0.5) < 0.5) {
      highlights.push({
        id: `highlight_${Date.now()}_1`,
        type: 'temporal',
        location: { startTime: 0, endTime: 1 },
        description: 'Temporal inconsistencies detected throughout video',
        severity: 0.6,
        visualIndicator: 'timeline_marker'
      });
    }
    
    // Highlight frequency artifacts
    if ((features.get('frequency_artifacts') || 0.5) < 0.5) {
      highlights.push({
        id: `highlight_${Date.now()}_2`,
        type: 'frequency',
        location: { frequencyRange: [4000, 8000] },
        description: 'High frequency artifacts detected',
        severity: 0.5,
        visualIndicator: 'spectrum_highlight'
      });
    }
  }
  
  return highlights;
}

/**
 * Generate confidence breakdown
 */
function generateConfidenceBreakdown(
  features: Map<string, number>,
  modelOutputs: Map<string, number>,
  overall: number
): ConfidenceBreakdown {
  const byModel = new Map<string, number>();
  const byFeature = new Map<string, number>();
  const byRegion = new Map<string, number>();
  
  // Model contributions
  for (const [modelId, output] of modelOutputs) {
    byModel.set(modelId, output);
  }
  
  // Feature contributions
  for (const [featureId, value] of features) {
    byFeature.set(featureId, Math.abs(value - 0.5) * 2);
  }
  
  // Regional contributions (simplified)
  byRegion.set('face', overall * 0.4);
  byRegion.set('background', overall * 0.2);
  byRegion.set('edges', overall * 0.2);
  byRegion.set('texture', overall * 0.2);
  
  // Calculate agreement
  const modelValues = Array.from(modelOutputs.values());
  const modelAgreement = modelValues.length > 1
    ? 1 - (Math.max(...modelValues) - Math.min(...modelValues))
    : 1;
  
  const featureValues = Array.from(features.values());
  const featureConsensus = featureValues.length > 1
    ? 1 - (Math.max(...featureValues) - Math.min(...featureValues)) / 2
    : 1;
  
  return {
    overall,
    byModel,
    byFeature,
    byRegion,
    temporalStability: 0.85,
    modelAgreement,
    featureConsensus
  };
}

/**
 * Generate uncertainty analysis
 */
function generateUncertaintyAnalysis(
  features: Map<string, number>,
  modelOutputs: Map<string, number>,
  confidence: number
): UncertaintyAnalysis {
  // Epistemic uncertainty (model uncertainty)
  const modelVariance = calculateVariance(Array.from(modelOutputs.values()));
  const epistemicUncertainty = Math.min(0.5, modelVariance);
  
  // Aleatoric uncertainty (data uncertainty)
  const featureVariance = calculateVariance(Array.from(features.values()));
  const aleatoricUncertainty = Math.min(0.5, featureVariance);
  
  const totalUncertainty = epistemicUncertainty + aleatoricUncertainty;
  
  // Confidence interval
  const margin = totalUncertainty * 0.5;
  const confidenceInterval: [number, number] = [
    Math.max(0, confidence - margin),
    Math.min(1, confidence + margin)
  ];
  
  // Uncertainty sources
  const uncertaintySources: UncertaintySource[] = [];
  
  if (epistemicUncertainty > 0.1) {
    uncertaintySources.push({
      source: 'Model Disagreement',
      contribution: epistemicUncertainty / totalUncertainty,
      description: 'Different models provide conflicting predictions',
      mitigation: 'Consider using ensemble voting or higher confidence threshold'
    });
  }
  
  if (aleatoricUncertainty > 0.1) {
    uncertaintySources.push({
      source: 'Input Quality',
      contribution: aleatoricUncertainty / totalUncertainty,
      description: 'Input media quality affects detection reliability',
      mitigation: 'Use higher quality input or additional verification methods'
    });
  }
  
  return {
    epistemicUncertainty,
    aleatoricUncertainty,
    totalUncertainty,
    uncertaintySources,
    confidenceInterval,
    predictionReliability: 1 - totalUncertainty
  };
}

/**
 * Generate default uncertainty
 */
function generateDefaultUncertainty(): UncertaintyAnalysis {
  return {
    epistemicUncertainty: 0.1,
    aleatoricUncertainty: 0.1,
    totalUncertainty: 0.2,
    uncertaintySources: [],
    confidenceInterval: [0.4, 0.6],
    predictionReliability: 0.8
  };
}

/**
 * Calculate variance
 */
function calculateVariance(values: number[]): number {
  if (values.length === 0) return 0;
  const mean = values.reduce((sum, v) => sum + v, 0) / values.length;
  return values.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / values.length;
}

/**
 * Generate natural language summary
 */
function generateNaturalLanguageSummary(
  result: 'authentic' | 'deepfake' | 'uncertain',
  confidence: number,
  features: FeatureImportance[],
  decisionPath: DecisionStep[],
  config: ExplanationConfig
): string {
  const detailLevel = config.naturalLanguageDetail;
  const audience = config.targetAudience;
  
  let summary = '';
  
  // Result statement
  if (result === 'authentic') {
    summary = `This media appears to be authentic with ${(confidence * 100).toFixed(0)}% confidence. `;
  } else if (result === 'deepfake') {
    summary = `This media shows strong indicators of being a deepfake with ${((1 - confidence) * 100).toFixed(0)}% confidence. `;
  } else {
    summary = `The analysis results are inconclusive. `;
  }
  
  // Key findings
  if (features.length > 0 && detailLevel !== 'brief') {
    const topFeatures = features.slice(0, 3);
    summary += `Key factors: ${topFeatures.map(f => f.featureName.toLowerCase()).join(', ')}. `;
  }
  
  // Confidence interpretation
  if (audience === 'technical') {
    summary += `Confidence interval: ${(confidence - 0.1).toFixed(2)} - ${(confidence + 0.1).toFixed(2)}.`;
  } else {
    if (confidence > 0.8) {
      summary += 'The system is highly confident in this assessment.';
    } else if (confidence > 0.6) {
      summary += 'The system is moderately confident in this assessment.';
    } else {
      summary += 'The system has low confidence. Manual review recommended.';
    }
  }
  
  return summary;
}

/**
 * Generate summary
 */
function generateSummary(
  result: 'authentic' | 'deepfake' | 'uncertain',
  confidence: number,
  features: FeatureImportance[]
): string {
  const confidenceStr = (confidence * 100).toFixed(0);
  
  if (result === 'authentic') {
    return `Authentic (${confidenceStr}% confidence) - No significant manipulation indicators detected.`;
  } else if (result === 'deepfake') {
    return `Deepfake Detected (${(100 - parseFloat(confidenceStr))}% confidence) - Multiple manipulation indicators found.`;
  }
  return `Inconclusive - Analysis results are ambiguous. Manual review recommended.`;
}

/**
 * Generate detailed explanation
 */
function generateDetailedExplanation(
  result: 'authentic' | 'deepfake' | 'uncertain',
  confidence: number,
  features: FeatureImportance[],
  decisionPath: DecisionStep[],
  counterfactuals: CounterfactualExplanation[],
  uncertainty: UncertaintyAnalysis,
  config: ExplanationConfig
): string {
  const sections: string[] = [];
  
  // Result section
  sections.push(`## Detection Result: ${result.toUpperCase()}`);
  sections.push(`**Confidence:** ${(confidence * 100).toFixed(1)}%`);
  sections.push('');
  
  // Feature analysis
  if (features.length > 0) {
    sections.push('## Feature Analysis');
    for (const feature of features.slice(0, 5)) {
      sections.push(`- **${feature.featureName}**: ${feature.description} (Importance: ${(feature.importance * 100).toFixed(0)}%)`);
    }
    sections.push('');
  }
  
  // Decision process
  if (decisionPath.length > 0 && config.targetAudience === 'technical') {
    sections.push('## Decision Process');
    for (const step of decisionPath) {
      sections.push(`${step.stepId + 1}. **${step.name}**: ${step.output} (${step.passed ? '✓' : '✗'})`);
    }
    sections.push('');
  }
  
  // Counterfactuals
  if (counterfactuals.length > 0) {
    sections.push('## What Would Change the Result?');
    for (const cf of counterfactuals) {
      sections.push(`To be classified as ${cf.counterfactualResult}:`);
      for (const change of cf.changesRequired) {
        sections.push(`- ${change.featureName}: ${change.feasibility} to change`);
      }
    }
    sections.push('');
  }
  
  // Uncertainty
  if (uncertainty.uncertaintySources.length > 0) {
    sections.push('## Uncertainty Analysis');
    sections.push(`Total uncertainty: ${(uncertainty.totalUncertainty * 100).toFixed(0)}%`);
    for (const source of uncertainty.uncertaintySources) {
      sections.push(`- ${source.source}: ${source.description}`);
    }
  }
  
  return sections.join('\n');
}

// ============================================================================
// MODEL BEHAVIOR INSIGHTS
// ============================================================================

/**
 * Record model behavior for insights
 */
export function recordModelBehavior(
  modelId: string,
  result: 'authentic' | 'deepfake' | 'uncertain',
  wasCorrect: boolean,
  features: Map<string, number>
): void {
  let insight = modelInsights.get(modelId);
  
  if (!insight) {
    insight = {
      modelId,
      strengthAreas: [],
      weaknessAreas: [],
      biasDetected: [],
      typicalErrors: [],
      recommendedUsage: []
    };
  }
  
  // Analyze strengths and weaknesses
  for (const [featureId, value] of features) {
    const featureName = getFeatureDisplayName(featureId);
    
    if (wasCorrect) {
      if (!insight.strengthAreas.includes(featureName)) {
        insight.strengthAreas.push(featureName);
      }
    } else {
      if (!insight.weaknessAreas.includes(featureName)) {
        insight.weaknessAreas.push(featureName);
      }
    }
  }
  
  // Track typical errors
  if (!wasCorrect && !insight.typicalErrors.includes(result)) {
    insight.typicalErrors.push(result);
  }
  
  modelInsights.set(modelId, insight);
}

/**
 * Get model insights
 */
export function getModelInsights(modelId: string): ModelBehaviorInsight | undefined {
  return modelInsights.get(modelId);
}

// ============================================================================
// STATUS & EXPORT
// ============================================================================

/**
 * Get explanation for detection
 */
export function getExplanation(detectionId: string): DetectionExplanation | undefined {
  return explanations.get(detectionId);
}

/**
 * Get explainable AI status
 */
export function getExplainableAIStatus(): {
  explanationsGenerated: number;
  modelInsightsCount: number;
  averageFeaturesAnalyzed: number;
} {
  let totalFeatures = 0;
  for (const explanation of explanations.values()) {
    totalFeatures += explanation.featureImportances.length;
  }
  
  return {
    explanationsGenerated: explanations.size,
    modelInsightsCount: modelInsights.size,
    averageFeaturesAnalyzed: explanations.size > 0 ? totalFeatures / explanations.size : 0
  };
}

/**
 * Run explainable AI tests
 */
export function runExplainableAITests(): {
  passed: boolean;
  tests: { total: number; passed: number; failed: number };
  results: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const results: Array<{ name: string; passed: boolean; error?: string }> = [];
  
  // Test 1: Feature importance generation
  try {
    const features = new Map([
      ['facial_landmarks_deviation', 0.3],
      ['temporal_consistency', 0.6],
      ['frequency_artifacts', 0.4]
    ]);
    const importances = generateFeatureImportances(features, 'deepfake', 5);
    if (importances.length === 0) {
      throw new Error('No feature importances generated');
    }
    results.push({ name: 'Feature Importance', passed: true });
  } catch (e) {
    results.push({ name: 'Feature Importance', passed: false, error: String(e) });
  }
  
  // Test 2: Decision path generation
  try {
    const features = new Map([['test_feature', 0.5]]);
    const models = new Map([['model_a', 0.7], ['model_b', 0.6]]);
    const path = generateDecisionPath(features, models, 'authentic');
    if (path.length === 0) {
      throw new Error('No decision path generated');
    }
    results.push({ name: 'Decision Path', passed: true });
  } catch (e) {
    results.push({ name: 'Decision Path', passed: false, error: String(e) });
  }
  
  // Test 3: Full explanation generation
  try {
    const features = new Map([
      ['facial_landmarks_deviation', 0.3],
      ['temporal_consistency', 0.7]
    ]);
    const models = new Map([['ensemble', 0.65]]);
    
    const explanation = generateExplanation(
      'test_detection',
      features,
      models,
      'authentic',
      0.75
    );
    
    if (!explanation.id || !explanation.naturalLanguageSummary) {
      throw new Error('Full explanation generation failed');
    }
    results.push({ name: 'Full Explanation', passed: true });
  } catch (e) {
    results.push({ name: 'Full Explanation', passed: false, error: String(e) });
  }
  
  // Test 4: Counterfactual generation
  try {
    const features = new Map([
      ['facial_landmarks_deviation', 0.3],
      ['temporal_consistency', 0.7]
    ]);
    const counterfactuals = generateCounterfactuals(features, 'deepfake', 0.3);
    if (counterfactuals.length === 0) {
      throw new Error('No counterfactuals generated');
    }
    results.push({ name: 'Counterfactual Generation', passed: true });
  } catch (e) {
    results.push({ name: 'Counterfactual Generation', passed: false, error: String(e) });
  }
  
  // Test 5: Uncertainty analysis
  try {
    const features = new Map([['feature', 0.5]]);
    const models = new Map([['model', 0.5]]);
    const uncertainty = generateUncertaintyAnalysis(features, models, 0.5);
    if (uncertainty.totalUncertainty < 0 || uncertainty.totalUncertainty > 1) {
      throw new Error('Invalid uncertainty analysis');
    }
    results.push({ name: 'Uncertainty Analysis', passed: true });
  } catch (e) {
    results.push({ name: 'Uncertainty Analysis', passed: false, error: String(e) });
  }
  
  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;
  
  return {
    passed: failed === 0,
    tests: { total: results.length, passed, failed },
    results
  };
}

// Default export
const explainableAIModule = {
  // Main functions
  generateExplanation,
  getExplanation,
  
  // Model insights
  recordModelBehavior,
  getModelInsights,
  
  // Status
  getExplainableAIStatus,
  
  // Tests
  runExplainableAITests
};

export default explainableAIModule;
