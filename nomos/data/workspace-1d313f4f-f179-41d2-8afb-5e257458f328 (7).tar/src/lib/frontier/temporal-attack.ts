/**
 * Temporal Attack Detection Module
 * 
 * Detect time-series adversarial patterns and temporal anomalies.
 * Protects against attacks that unfold over time.
 * 
 * @module frontier/temporal-attack
 * @version 1.0.0
 * 
 * Capabilities:
 * - Temporal Anomaly Detection
 * - Time-Series Pattern Analysis
 * - Adaptive Attack Recognition
 * - Behavioral Drift Detection
 * - Sequential Pattern Mining
 * - Temporal Consistency Verification
 * - Dynamic Threshold Adjustment
 * - Time-Warping Detection
 */

// ============================================================================
// TYPES
// ============================================================================

/**
 * Temporal attack types
 */
export type TemporalAttackType = 
  | 'slow-drift'
  | 'burst-attack'
  | 'periodic-attack'
  | 'escalation'
  | 'time-warping'
  | 'replay'
  | 'timing-manipulation';

/**
 * Time-series data point
 */
export interface TimeSeriesPoint {
  timestamp: number;
  value: number;
  features: number[];
  metadata?: Record<string, unknown>;
}

/**
 * Temporal window
 */
export interface TemporalWindow {
  start: number;
  end: number;
  points: TimeSeriesPoint[];
  statistics: WindowStatistics;
  anomalies: TemporalAnomaly[];
}

/**
 * Window statistics
 */
export interface WindowStatistics {
  mean: number;
  std: number;
  min: number;
  max: number;
  trend: number; // Slope
  autocorrelation: number;
  entropy: number;
}

/**
 * Temporal anomaly
 */
export interface TemporalAnomaly {
  id: string;
  type: TemporalAttackType;
  timestamp: number;
  severity: 'low' | 'medium' | 'high' | 'critical';
  score: number;
  description: string;
  affectedPoints: number[];
  pattern: string;
  confidence: number;
}

/**
 * Attack pattern definition
 */
export interface AttackPattern {
  id: string;
  name: string;
  type: TemporalAttackType;
  description: string;
  indicators: PatternIndicator[];
  timeScale: 'millisecond' | 'second' | 'minute' | 'hour' | 'day';
  severity: 'low' | 'medium' | 'high' | 'critical';
  falsePositiveRate: number;
}

/**
 * Pattern indicator
 */
export interface PatternIndicator {
  metric: string;
  condition: 'above' | 'below' | 'increasing' | 'decreasing' | 'oscillating' | 'stable';
  threshold: number;
  weight: number;
  windowSize: number;
}

/**
 * Temporal detection result
 */
export interface TemporalDetectionResult {
  id: string;
  contentId: string;
  attacks: TemporalAnomaly[];
  riskScore: number;
  riskLevel: 'safe' | 'low' | 'medium' | 'high' | 'critical';
  recommendations: string[];
  confidence: number;
  processingTimeMs: number;
  analyzedPoints: number;
  timeRange: { start: number; end: number };
}

/**
 * Behavioral baseline
 */
export interface BehavioralBaseline {
  id: string;
  contentId: string;
  metric: string;
  mean: number;
  std: number;
  min: number;
  max: number;
  percentiles: { p5: number; p25: number; p50: number; p75: number; p95: number };
  sampleSize: number;
  createdAt: number;
  lastUpdated: number;
}

/**
 * Drift detection result
 */
export interface DriftResult {
  id: string;
  metric: string;
  driftDetected: boolean;
  driftType: 'sudden' | 'gradual' | 'incremental' | 'recurring';
  magnitude: number;
  startTime: number;
  confidence: number;
  affectedWindow: TemporalWindow;
}

/**
 * Temporal configuration
 */
export interface TemporalConfig {
  windowSize: number;
  stepSize: number;
  anomalyThreshold: number;
  driftThreshold: number;
  minPointsForDetection: number;
  enableAdaptiveThresholds: boolean;
}

// ============================================================================
// STORAGE
// ============================================================================

const timeSeries = new Map<string, TimeSeriesPoint[]>();
const baselines = new Map<string, BehavioralBaseline>();
const attackPatterns = new Map<string, AttackPattern>();
const detectedAttacks = new Map<string, TemporalAnomaly[]>();

// Default configuration
const DEFAULT_CONFIG: TemporalConfig = {
  windowSize: 100,
  stepSize: 10,
  anomalyThreshold: 3, // Standard deviations
  driftThreshold: 0.1,
  minPointsForDetection: 10,
  enableAdaptiveThresholds: true
};

// Initialize default attack patterns
function initializeAttackPatterns(): void {
  const patterns: AttackPattern[] = [
    {
      id: 'slow_drift_1',
      name: 'Slow Credential Drift',
      type: 'slow-drift',
      description: 'Gradual change in behavior over extended period',
      indicators: [
        { metric: 'confidence', condition: 'decreasing', threshold: 0.01, weight: 0.5, windowSize: 1000 }
      ],
      timeScale: 'hour',
      severity: 'high',
      falsePositiveRate: 0.05
    },
    {
      id: 'burst_attack_1',
      name: 'Burst Attack Pattern',
      type: 'burst-attack',
      description: 'Sudden spike in activity followed by return to normal',
      indicators: [
        { metric: 'request_rate', condition: 'above', threshold: 10, weight: 0.7, windowSize: 10 }
      ],
      timeScale: 'second',
      severity: 'critical',
      falsePositiveRate: 0.02
    },
    {
      id: 'periodic_attack_1',
      name: 'Periodic Attack',
      type: 'periodic-attack',
      description: 'Regular intervals of suspicious activity',
      indicators: [
        { metric: 'error_rate', condition: 'oscillating', threshold: 0.5, weight: 0.6, windowSize: 100 }
      ],
      timeScale: 'minute',
      severity: 'medium',
      falsePositiveRate: 0.08
    },
    {
      id: 'escalation_1',
      name: 'Escalation Attack',
      type: 'escalation',
      description: 'Progressively increasing attack intensity',
      indicators: [
        { metric: 'risk_score', condition: 'increasing', threshold: 0.1, weight: 0.8, windowSize: 50 }
      ],
      timeScale: 'minute',
      severity: 'high',
      falsePositiveRate: 0.03
    },
    {
      id: 'time_warp_1',
      name: 'Time Warping Attack',
      type: 'time-warping',
      description: 'Manipulation of temporal patterns',
      indicators: [
        { metric: 'timing_variance', condition: 'above', threshold: 0.3, weight: 0.6, windowSize: 20 }
      ],
      timeScale: 'millisecond',
      severity: 'medium',
      falsePositiveRate: 0.1
    },
    {
      id: 'replay_1',
      name: 'Replay Attack',
      type: 'replay',
      description: 'Repetition of previous legitimate patterns',
      indicators: [
        { metric: 'pattern_similarity', condition: 'above', threshold: 0.95, weight: 0.9, windowSize: 30 }
      ],
      timeScale: 'second',
      severity: 'high',
      falsePositiveRate: 0.02
    }
  ];
  
  patterns.forEach(p => attackPatterns.set(p.id, p));
}

initializeAttackPatterns();

// ============================================================================
// TIME-SERIES MANAGEMENT
// ============================================================================

/**
 * Add time-series point
 */
export function addTimeSeriesPoint(
  contentId: string,
  value: number,
  features: number[] = [],
  metadata?: Record<string, unknown>
): TimeSeriesPoint {
  const point: TimeSeriesPoint = {
    timestamp: Date.now(),
    value,
    features,
    metadata
  };
  
  const series = timeSeries.get(contentId) || [];
  series.push(point);
  timeSeries.set(contentId, series);
  
  return point;
}

/**
 * Get time series
 */
export function getTimeSeries(contentId: string): TimeSeriesPoint[] {
  return timeSeries.get(contentId) || [];
}

/**
 * Clear time series
 */
export function clearTimeSeries(contentId: string): void {
  timeSeries.delete(contentId);
}

// ============================================================================
// TEMPORAL ANALYSIS
// ============================================================================

/**
 * Calculate window statistics
 */
export function calculateWindowStatistics(points: TimeSeriesPoint[]): WindowStatistics {
  if (points.length === 0) {
    return {
      mean: 0,
      std: 0,
      min: 0,
      max: 0,
      trend: 0,
      autocorrelation: 0,
      entropy: 0
    };
  }
  
  const values = points.map(p => p.value);
  
  // Mean
  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  
  // Standard deviation
  const variance = values.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / values.length;
  const std = Math.sqrt(variance);
  
  // Min/Max
  const min = Math.min(...values);
  const max = Math.max(...values);
  
  // Trend (linear regression slope)
  let trend = 0;
  if (points.length > 1) {
    const n = points.length;
    const sumX = (n * (n - 1)) / 2;
    const sumY = values.reduce((a, b) => a + b, 0);
    let sumXY = 0;
    let sumX2 = 0;
    
    for (let i = 0; i < n; i++) {
      sumXY += i * values[i];
      sumX2 += i * i;
    }
    
    trend = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
  }
  
  // Autocorrelation (lag 1)
  let autocorrelation = 0;
  if (points.length > 2) {
    let sum = 0;
    for (let i = 1; i < values.length; i++) {
      sum += (values[i] - mean) * (values[i - 1] - mean);
    }
    autocorrelation = sum / ((values.length - 1) * variance);
  }
  
  // Entropy (discretized)
  let entropy = 0;
  const bins = 10;
  const binWidth = (max - min) / bins || 1;
  const histogram = new Array(bins).fill(0);
  
  for (const v of values) {
    const bin = Math.min(bins - 1, Math.floor((v - min) / binWidth));
    histogram[bin]++;
  }
  
  for (const count of histogram) {
    if (count > 0) {
      const p = count / values.length;
      entropy -= p * Math.log2(p);
    }
  }
  
  return { mean, std, min, max, trend, autocorrelation, entropy };
}

/**
 * Create temporal windows
 */
export function createTemporalWindows(
  points: TimeSeriesPoint[],
  windowSize: number,
  stepSize: number
): TemporalWindow[] {
  if (points.length < windowSize) {
    return [{
      start: points[0]?.timestamp || 0,
      end: points[points.length - 1]?.timestamp || 0,
      points,
      statistics: calculateWindowStatistics(points),
      anomalies: []
    }];
  }
  
  const windows: TemporalWindow[] = [];
  
  for (let i = 0; i <= points.length - windowSize; i += stepSize) {
    const windowPoints = points.slice(i, i + windowSize);
    const stats = calculateWindowStatistics(windowPoints);
    
    windows.push({
      start: windowPoints[0].timestamp,
      end: windowPoints[windowPoints.length - 1].timestamp,
      points: windowPoints,
      statistics: stats,
      anomalies: []
    });
  }
  
  return windows;
}

// ============================================================================
// ANOMALY DETECTION
// ============================================================================

/**
 * Detect point anomalies
 */
export function detectPointAnomalies(
  points: TimeSeriesPoint[],
  threshold: number = DEFAULT_CONFIG.anomalyThreshold
): TemporalAnomaly[] {
  const anomalies: TemporalAnomaly[] = [];
  
  if (points.length < 3) return anomalies;
  
  const stats = calculateWindowStatistics(points);
  
  for (let i = 0; i < points.length; i++) {
    const point = points[i];
    const zScore = stats.std > 0 
      ? Math.abs(point.value - stats.mean) / stats.std 
      : 0;
    
    if (zScore > threshold) {
      anomalies.push({
        id: `anomaly_${Date.now()}_${i}`,
        type: 'burst-attack',
        timestamp: point.timestamp,
        severity: zScore > threshold * 2 ? 'critical' : zScore > threshold * 1.5 ? 'high' : 'medium',
        score: zScore,
        description: `Point anomaly detected: z-score ${zScore.toFixed(2)}`,
        affectedPoints: [i],
        pattern: 'statistical_outlier',
        confidence: Math.min(1, zScore / (threshold * 3))
      });
    }
  }
  
  return anomalies;
}

/**
 * Detect slow drift attacks
 */
export function detectSlowDrift(
  windows: TemporalWindow[],
  threshold: number = DEFAULT_CONFIG.driftThreshold
): TemporalAnomaly[] {
  const anomalies: TemporalAnomaly[] = [];
  
  if (windows.length < 3) return anomalies;
  
  // Check for consistent trend across windows
  let totalTrend = 0;
  for (const window of windows) {
    totalTrend += window.statistics.trend;
  }
  
  const avgTrend = totalTrend / windows.length;
  
  // Check if trend is significant and consistent
  const trendVariance = windows.reduce(
    (sum, w) => sum + Math.pow(w.statistics.trend - avgTrend, 2), 
    0
  ) / windows.length;
  
  if (Math.abs(avgTrend) > threshold && trendVariance < 0.1) {
    anomalies.push({
      id: `drift_${Date.now()}`,
      type: 'slow-drift',
      timestamp: windows[0].start,
      severity: Math.abs(avgTrend) > threshold * 3 ? 'critical' : 'high',
      score: Math.abs(avgTrend) / threshold,
      description: `Slow drift detected: average trend ${avgTrend.toFixed(4)}`,
      affectedPoints: windows.flatMap(w => w.points.map((_, i) => i)),
      pattern: 'consistent_drift',
      confidence: Math.min(1, Math.abs(avgTrend) / (threshold * 5))
    });
  }
  
  return anomalies;
}

/**
 * Detect burst attacks
 */
export function detectBurstAttack(
  windows: TemporalWindow[],
  multiplier: number = 3
): TemporalAnomaly[] {
  const anomalies: TemporalAnomaly[] = [];
  
  if (windows.length < 2) return anomalies;
  
  // Calculate baseline
  const means = windows.map(w => w.statistics.mean);
  const baselineMean = means.reduce((a, b) => a + b, 0) / means.length;
  const baselineStd = Math.sqrt(
    means.reduce((sum, m) => sum + Math.pow(m - baselineMean, 2), 0) / means.length
  );
  
  // Find bursts
  for (let i = 0; i < windows.length; i++) {
    const window = windows[i];
    if (baselineStd > 0) {
      const zScore = (window.statistics.mean - baselineMean) / baselineStd;
      
      if (zScore > multiplier) {
        anomalies.push({
          id: `burst_${Date.now()}_${i}`,
          type: 'burst-attack',
          timestamp: window.start,
          severity: zScore > multiplier * 2 ? 'critical' : 'high',
          score: zScore,
          description: `Burst attack detected: ${zScore.toFixed(2)}x normal`,
          affectedPoints: window.points.map((_, j) => j),
          pattern: 'sudden_spike',
          confidence: Math.min(1, zScore / (multiplier * 3))
        });
      }
    }
  }
  
  return anomalies;
}

/**
 * Detect periodic attacks
 */
export function detectPeriodicAttack(
  points: TimeSeriesPoint[]
): TemporalAnomaly[] {
  const anomalies: TemporalAnomaly[] = [];
  
  if (points.length < 10) return anomalies;
  
  // FFT for periodicity detection (simplified)
  const values = points.map(p => p.value);
  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  const centered = values.map(v => v - mean);
  
  // Check autocorrelation at different lags
  const maxLag = Math.min(50, Math.floor(points.length / 2));
  const autocorrelations: number[] = [];
  
  for (let lag = 1; lag <= maxLag; lag++) {
    let sum = 0;
    for (let i = lag; i < centered.length; i++) {
      sum += centered[i] * centered[i - lag];
    }
    autocorrelations.push(sum / centered.length);
  }
  
  // Find peaks in autocorrelation
  const peaks: number[] = [];
  for (let i = 1; i < autocorrelations.length - 1; i++) {
    if (autocorrelations[i] > autocorrelations[i - 1] && 
        autocorrelations[i] > autocorrelations[i + 1] &&
        autocorrelations[i] > 0.3) {
      peaks.push(i + 1);
    }
  }
  
  if (peaks.length > 0) {
    anomalies.push({
      id: `periodic_${Date.now()}`,
      type: 'periodic-attack',
      timestamp: points[0].timestamp,
      severity: 'medium',
      score: Math.max(...autocorrelations),
      description: `Periodic pattern detected with periods: ${peaks.join(', ')}`,
      affectedPoints: [],
      pattern: 'periodic_oscillation',
      confidence: Math.min(1, Math.max(...autocorrelations))
    });
  }
  
  return anomalies;
}

/**
 * Detect replay attacks
 */
export function detectReplayAttack(
  points: TimeSeriesPoint[],
  historicalPatterns: number[][]
): TemporalAnomaly[] {
  const anomalies: TemporalAnomaly[] = [];
  
  if (points.length < 5 || historicalPatterns.length === 0) return anomalies;
  
  const values = points.map(p => p.value);
  
  for (let i = 0; i < historicalPatterns.length; i++) {
    const pattern = historicalPatterns[i];
    
    if (pattern.length !== values.length) continue;
    
    // Calculate similarity
    let similarity = 0;
    for (let j = 0; j < values.length; j++) {
      const diff = Math.abs(values[j] - pattern[j]);
      similarity += 1 - Math.min(1, diff);
    }
    similarity /= values.length;
    
    if (similarity > 0.95) {
      anomalies.push({
        id: `replay_${Date.now()}`,
        type: 'replay',
        timestamp: points[0].timestamp,
        severity: 'high',
        score: similarity,
        description: `Replay attack detected: ${similarity.toFixed(2)} similarity to historical pattern`,
        affectedPoints: points.map((_, i) => i),
        pattern: 'exact_replay',
        confidence: similarity
      });
      break;
    }
  }
  
  return anomalies;
}

// ============================================================================
// COMPREHENSIVE DETECTION
// ============================================================================

/**
 * Perform comprehensive temporal attack detection
 */
export function detectTemporalAttacks(
  contentId: string,
  config: Partial<TemporalConfig> = {}
): TemporalDetectionResult {
  const cfg = { ...DEFAULT_CONFIG, ...config };
  const startTime = Date.now();
  
  const points = timeSeries.get(contentId) || [];
  
  if (points.length < cfg.minPointsForDetection) {
    return {
      id: `temporal_${Date.now()}`,
      contentId,
      attacks: [],
      riskScore: 0,
      riskLevel: 'safe',
      recommendations: ['Insufficient data for analysis'],
      confidence: 0,
      processingTimeMs: Date.now() - startTime,
      analyzedPoints: points.length,
      timeRange: { 
        start: points[0]?.timestamp || 0, 
        end: points[points.length - 1]?.timestamp || 0 
      }
    };
  }
  
  const attacks: TemporalAnomaly[] = [];
  
  // Create windows
  const windows = createTemporalWindows(points, cfg.windowSize, cfg.stepSize);
  
  // Run all detectors
  attacks.push(...detectPointAnomalies(points, cfg.anomalyThreshold));
  attacks.push(...detectSlowDrift(windows, cfg.driftThreshold));
  attacks.push(...detectBurstAttack(windows));
  attacks.push(...detectPeriodicAttack(points));
  
  // Store detected attacks
  detectedAttacks.set(contentId, attacks);
  
  // Calculate risk score
  const riskScore = calculateRiskScore(attacks);
  const riskLevel = getRiskLevel(riskScore);
  
  // Generate recommendations
  const recommendations = generateRecommendations(attacks, riskLevel);
  
  // Calculate confidence
  const confidence = attacks.length > 0 
    ? attacks.reduce((sum, a) => sum + a.confidence, 0) / attacks.length
    : 0.5;
  
  return {
    id: `temporal_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    contentId,
    attacks,
    riskScore,
    riskLevel,
    recommendations,
    confidence,
    processingTimeMs: Date.now() - startTime,
    analyzedPoints: points.length,
    timeRange: { 
      start: points[0].timestamp, 
      end: points[points.length - 1].timestamp 
    }
  };
}

/**
 * Calculate overall risk score
 */
function calculateRiskScore(attacks: TemporalAnomaly[]): number {
  if (attacks.length === 0) return 0;
  
  const severityWeights = {
    low: 1,
    medium: 2,
    high: 3,
    critical: 5
  };
  
  const weightedSum = attacks.reduce(
    (sum, a) => sum + a.score * severityWeights[a.severity],
    0
  );
  
  const maxPossible = attacks.length * 5; // All critical
  
  return Math.min(1, weightedSum / maxPossible);
}

/**
 * Get risk level from score
 */
function getRiskLevel(score: number): TemporalDetectionResult['riskLevel'] {
  if (score < 0.1) return 'safe';
  if (score < 0.3) return 'low';
  if (score < 0.5) return 'medium';
  if (score < 0.8) return 'high';
  return 'critical';
}

/**
 * Generate recommendations based on detected attacks
 */
function generateRecommendations(
  attacks: TemporalAnomaly[],
  riskLevel: string
): string[] {
  const recommendations: string[] = [];
  
  if (attacks.length === 0) {
    recommendations.push('No temporal attacks detected. Continue monitoring.');
    return recommendations;
  }
  
  // Attack-type specific recommendations
  const attackTypes = new Set(attacks.map(a => a.type));
  
  if (attackTypes.has('slow-drift')) {
    recommendations.push('Implement model retraining to counter drift');
    recommendations.push('Increase monitoring frequency');
  }
  
  if (attackTypes.has('burst-attack')) {
    recommendations.push('Enable rate limiting');
    recommendations.push('Implement request throttling');
  }
  
  if (attackTypes.has('periodic-attack')) {
    recommendations.push('Analyze timing patterns for attack source');
    recommendations.push('Implement time-based blocking rules');
  }
  
  if (attackTypes.has('replay')) {
    recommendations.push('Add nonce/timestamp validation');
    recommendations.push('Implement request deduplication');
  }
  
  if (riskLevel === 'critical') {
    recommendations.unshift('CRITICAL: Immediate investigation required');
    recommendations.push('Consider temporarily blocking the source');
  }
  
  return recommendations;
}

// ============================================================================
// BEHAVIORAL BASELINE
// ============================================================================

/**
 * Create behavioral baseline
 */
export function createBaseline(
  contentId: string,
  metric: string,
  points: TimeSeriesPoint[]
): BehavioralBaseline {
  const values = points.map(p => p.value);
  const sorted = [...values].sort((a, b) => a - b);
  
  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  const variance = values.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / values.length;
  const std = Math.sqrt(variance);
  
  const baseline: BehavioralBaseline = {
    id: `baseline_${contentId}_${metric}`,
    contentId,
    metric,
    mean,
    std,
    min: sorted[0],
    max: sorted[sorted.length - 1],
    percentiles: {
      p5: sorted[Math.floor(sorted.length * 0.05)],
      p25: sorted[Math.floor(sorted.length * 0.25)],
      p50: sorted[Math.floor(sorted.length * 0.5)],
      p75: sorted[Math.floor(sorted.length * 0.75)],
      p95: sorted[Math.floor(sorted.length * 0.95)]
    },
    sampleSize: points.length,
    createdAt: Date.now(),
    lastUpdated: Date.now()
  };
  
  baselines.set(baseline.id, baseline);
  
  return baseline;
}

/**
 * Detect behavioral drift
 */
export function detectDrift(
  baseline: BehavioralBaseline,
  currentPoints: TimeSeriesPoint[]
): DriftResult | null {
  if (currentPoints.length < 10) return null;
  
  const currentMean = currentPoints.reduce((sum, p) => sum + p.value, 0) / currentPoints.length;
  
  // Check for significant deviation
  const deviation = Math.abs(currentMean - baseline.mean) / (baseline.std || 1);
  
  if (deviation > 2) {
    // Determine drift type
    const driftType: DriftResult['driftType'] = deviation > 5 ? 'sudden' : 'gradual';
    
    return {
      id: `drift_${Date.now()}`,
      metric: baseline.metric,
      driftDetected: true,
      driftType,
      magnitude: deviation,
      startTime: currentPoints[0].timestamp,
      confidence: Math.min(1, deviation / 5),
      affectedWindow: {
        start: currentPoints[0].timestamp,
        end: currentPoints[currentPoints.length - 1].timestamp,
        points: currentPoints,
        statistics: calculateWindowStatistics(currentPoints),
        anomalies: []
      }
    };
  }
  
  return null;
}

// ============================================================================
// STATUS
// ============================================================================

/**
 * Get temporal attack module status
 */
export function getTemporalStatus(): {
  trackedContent: number;
  totalDataPoints: number;
  baselinesCreated: number;
  attacksDetected: number;
  attackPatterns: number;
  attackBreakdown: Record<TemporalAttackType, number>;
} {
  const breakdown: Record<TemporalAttackType, number> = {
    'slow-drift': 0,
    'burst-attack': 0,
    'periodic-attack': 0,
    'escalation': 0,
    'time-warping': 0,
    'replay': 0,
    'timing-manipulation': 0
  };
  
  for (const [, attacks] of detectedAttacks) {
    for (const attack of attacks) {
      breakdown[attack.type]++;
    }
  }
  
  return {
    trackedContent: timeSeries.size,
    totalDataPoints: Array.from(timeSeries.values()).reduce((sum, arr) => sum + arr.length, 0),
    baselinesCreated: baselines.size,
    attacksDetected: Array.from(detectedAttacks.values()).flat().length,
    attackPatterns: attackPatterns.size,
    attackBreakdown: breakdown
  };
}

/**
 * Get attack patterns
 */
export function getAttackPatterns(): AttackPattern[] {
  return Array.from(attackPatterns.values());
}

// ============================================================================
// TESTS
// ============================================================================

/**
 * Run temporal attack detection tests
 */
export function runTemporalTests(): {
  passed: boolean;
  tests: { total: number; passed: number; failed: number };
  results: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const results: Array<{ name: string; passed: boolean; error?: string }> = [];
  
  // Test 1: Time series management
  try {
    const contentId = 'test_content';
    addTimeSeriesPoint(contentId, 0.5, [1, 2, 3]);
    addTimeSeriesPoint(contentId, 0.6, [1, 2, 3]);
    const series = getTimeSeries(contentId);
    if (series.length !== 2) {
      throw new Error('Time series management failed');
    }
    clearTimeSeries(contentId);
    results.push({ name: 'Time Series Management', passed: true });
  } catch (e) {
    results.push({ name: 'Time Series Management', passed: false, error: String(e) });
  }
  
  // Test 2: Window statistics
  try {
    const points: TimeSeriesPoint[] = [
      { timestamp: 1, value: 1, features: [] },
      { timestamp: 2, value: 2, features: [] },
      { timestamp: 3, value: 3, features: [] },
      { timestamp: 4, value: 4, features: [] },
      { timestamp: 5, value: 5, features: [] }
    ];
    const stats = calculateWindowStatistics(points);
    if (stats.mean !== 3) {
      throw new Error('Window statistics failed');
    }
    results.push({ name: 'Window Statistics', passed: true });
  } catch (e) {
    results.push({ name: 'Window Statistics', passed: false, error: String(e) });
  }
  
  // Test 3: Point anomaly detection
  try {
    const points: TimeSeriesPoint[] = [
      { timestamp: 1, value: 1, features: [] },
      { timestamp: 2, value: 1, features: [] },
      { timestamp: 3, value: 1, features: [] },
      { timestamp: 4, value: 100, features: [] }, // Anomaly
      { timestamp: 5, value: 1, features: [] }
    ];
    const anomalies = detectPointAnomalies(points, 2);
    if (anomalies.length === 0) {
      throw new Error('Point anomaly detection failed');
    }
    results.push({ name: 'Point Anomaly Detection', passed: true });
  } catch (e) {
    results.push({ name: 'Point Anomaly Detection', passed: false, error: String(e) });
  }
  
  // Test 4: Burst attack detection
  try {
    const windows = [
      { start: 1, end: 10, points: [], statistics: { mean: 10, std: 1, min: 8, max: 12, trend: 0, autocorrelation: 0, entropy: 1 }, anomalies: [] },
      { start: 11, end: 20, points: [], statistics: { mean: 10, std: 1, min: 8, max: 12, trend: 0, autocorrelation: 0, entropy: 1 }, anomalies: [] },
      { start: 21, end: 30, points: [], statistics: { mean: 100, std: 5, min: 90, max: 110, trend: 0, autocorrelation: 0, entropy: 1 }, anomalies: [] } // Burst
    ] as TemporalWindow[];
    const attacks = detectBurstAttack(windows, 2);
    if (attacks.length === 0) {
      throw new Error('Burst attack detection failed');
    }
    results.push({ name: 'Burst Attack Detection', passed: true });
  } catch (e) {
    results.push({ name: 'Burst Attack Detection', passed: false, error: String(e) });
  }
  
  // Test 5: Behavioral baseline
  try {
    const points: TimeSeriesPoint[] = Array(100).fill(0).map((_, i) => ({
      timestamp: i,
      value: 50 + Math.random() * 10,
      features: []
    }));
    const baseline = createBaseline('test', 'value', points);
    if (baseline.mean < 45 || baseline.mean > 65) {
      throw new Error('Baseline creation failed');
    }
    results.push({ name: 'Behavioral Baseline', passed: true });
  } catch (e) {
    results.push({ name: 'Behavioral Baseline', passed: false, error: String(e) });
  }
  
  // Test 6: Comprehensive detection
  try {
    const contentId = 'test_comprehensive';
    // Add normal data
    for (let i = 0; i < 50; i++) {
      addTimeSeriesPoint(contentId, 50 + Math.random() * 10, []);
    }
    // Add anomaly
    addTimeSeriesPoint(contentId, 500, []);
    
    const result = detectTemporalAttacks(contentId);
    if (result.analyzedPoints !== 51) {
      throw new Error('Comprehensive detection failed');
    }
    clearTimeSeries(contentId);
    results.push({ name: 'Comprehensive Detection', passed: true });
  } catch (e) {
    results.push({ name: 'Comprehensive Detection', passed: false, error: String(e) });
  }
  
  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;
  
  return {
    passed: failed === 0,
    tests: { total: results.length, passed, failed },
    results
  };
}

// Default export
const temporalAttackModule = {
  // Time series management
  addTimeSeriesPoint,
  getTimeSeries,
  clearTimeSeries,
  
  // Analysis
  calculateWindowStatistics,
  createTemporalWindows,
  
  // Detection
  detectPointAnomalies,
  detectSlowDrift,
  detectBurstAttack,
  detectPeriodicAttack,
  detectReplayAttack,
  detectTemporalAttacks,
  
  // Baseline
  createBaseline,
  detectDrift,
  
  // Status
  getTemporalStatus,
  getAttackPatterns,
  
  // Tests
  runTemporalTests
};

export default temporalAttackModule;
