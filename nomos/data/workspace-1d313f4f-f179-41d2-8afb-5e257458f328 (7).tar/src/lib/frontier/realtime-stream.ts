/**
 * Real-Time Stream Analysis Module
 * 
 * Live deepfake detection for streaming video and audio.
 * Sub-second latency with continuous analysis and alert generation.
 * 
 * @module frontier/realtime-stream
 * @version 1.0.0
 * 
 * Capabilities:
 * - Live Video Stream Analysis
 * - Live Audio Stream Analysis
 * - Rolling Window Detection
 * - Adaptive Quality Control
 * - Latency Optimization
 * - Alert Generation
 * - Stream Health Monitoring
 * - Multi-Stream Parallel Processing
 */

// ============================================================================
// TYPES
// ============================================================================

/**
 * Stream configuration
 */
export interface StreamConfig {
  streamId: string;
  type: 'video' | 'audio' | 'mixed';
  sampleRate: number;
  frameRate: number;
  resolution?: [number, number];
  bufferSize: number;
  analysisWindow: number; // ms
  alertThreshold: number;
  latencyTarget: number; // ms
}

/**
 * Stream session
 */
export interface StreamSession {
  id: string;
  config: StreamConfig;
  status: 'active' | 'paused' | 'ended' | 'error';
  startTime: number;
  framesProcessed: number;
  audioProcessed: number; // seconds
  alertsGenerated: number;
  averageLatency: number;
  currentBuffer: number;
  healthScore: number;
}

/**
 * Analysis window result
 */
export interface WindowAnalysisResult {
  windowId: string;
  streamId: string;
  startTime: number;
  endTime: number;
  frameCount: number;
  audioDuration: number;
  result: 'authentic' | 'deepfake' | 'uncertain';
  confidence: number;
  confidenceTrend: 'stable' | 'increasing' | 'decreasing' | 'volatile';
  indicators: string[];
  processingLatency: number;
  alertGenerated: boolean;
}

/**
 * Stream alert
 */
export interface StreamAlert {
  id: string;
  streamId: string;
  type: 'deepfake_detected' | 'confidence_drop' | 'processing_error' | 'stream_issue' | 'pattern_change';
  severity: 'low' | 'medium' | 'high' | 'critical';
  confidence: number;
  windowId: string;
  timestamp: number;
  description: string;
  evidence: string[];
  recommendedAction: string;
  acknowledged: boolean;
}

/**
 * Rolling analysis state
 */
export interface RollingAnalysisState {
  windowResults: WindowAnalysisResult[];
  confidenceHistory: number[];
  trendAnalysis: TrendResult;
  anomalyDetected: boolean;
  anomalyType: string | null;
}

/**
 * Trend analysis result
 */
export interface TrendResult {
  direction: 'improving' | 'degrading' | 'stable' | 'volatile';
  rate: number;
  predictedConfidence: number;
  timeToThreshold: number | null;
  patternDetected: string | null;
}

/**
 * Stream health metrics
 */
export interface StreamHealthMetrics {
  streamId: string;
  fps: number;
  bitrate: number;
  packetLoss: number;
  jitter: number;
  latency: number;
  bufferHealth: number;
  cpuUsage: number;
  memoryUsage: number;
  timestamp: number;
}

/**
 * Adaptive quality settings
 */
export interface AdaptiveQualitySettings {
  resolution: [number, number];
  frameRate: number;
  analysisDepth: 'quick' | 'standard' | 'thorough';
  modelComplexity: 'light' | 'medium' | 'heavy';
  parallelWorkers: number;
}

// ============================================================================
// STORAGE
// ============================================================================

const sessions = new Map<string, StreamSession>();
const alerts = new Map<string, StreamAlert[]>();
const windowResults = new Map<string, WindowAnalysisResult[]>();
const healthMetrics = new Map<string, StreamHealthMetrics[]>();
const rollingStates = new Map<string, RollingAnalysisState>();

// Performance tracking
let totalFramesProcessed = 0;
let totalAudioProcessed = 0;
let totalAlertsGenerated = 0;

// ============================================================================
// STREAM SESSION MANAGEMENT
// ============================================================================

/**
 * Start a new stream session
 */
export function startStreamSession(config: StreamConfig): StreamSession {
  const id = `stream_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  
  const session: StreamSession = {
    id,
    config,
    status: 'active',
    startTime: Date.now(),
    framesProcessed: 0,
    audioProcessed: 0,
    alertsGenerated: 0,
    averageLatency: config.latencyTarget,
    currentBuffer: 0,
    healthScore: 100
  };
  
  sessions.set(id, session);
  alerts.set(id, []);
  windowResults.set(id, []);
  healthMetrics.set(id, []);
  
  // Initialize rolling state
  rollingStates.set(id, {
    windowResults: [],
    confidenceHistory: [],
    trendAnalysis: {
      direction: 'stable',
      rate: 0,
      predictedConfidence: 0.5,
      timeToThreshold: null,
      patternDetected: null
    },
    anomalyDetected: false,
    anomalyType: null
  });
  
  return session;
}

/**
 * Get stream session
 */
export function getStreamSession(streamId: string): StreamSession | undefined {
  return sessions.get(streamId);
}

/**
 * List all active sessions
 */
export function listActiveSessions(): StreamSession[] {
  return Array.from(sessions.values()).filter(s => s.status === 'active');
}

/**
 * Pause stream session
 */
export function pauseStreamSession(streamId: string): boolean {
  const session = sessions.get(streamId);
  if (!session) return false;
  
  session.status = 'paused';
  return true;
}

/**
 * Resume stream session
 */
export function resumeStreamSession(streamId: string): boolean {
  const session = sessions.get(streamId);
  if (!session) return false;
  
  session.status = 'active';
  return true;
}

/**
 * End stream session
 */
export function endStreamSession(streamId: string): StreamSession | null {
  const session = sessions.get(streamId);
  if (!session) return null;
  
  session.status = 'ended';
  
  // Generate summary
  const sessionAlerts = alerts.get(streamId) || [];
  const criticalAlerts = sessionAlerts.filter(a => a.severity === 'critical').length;
  
  // Update global stats
  totalFramesProcessed += session.framesProcessed;
  totalAudioProcessed += session.audioProcessed;
  totalAlertsGenerated += session.alertsGenerated;
  
  return session;
}

// ============================================================================
// WINDOW ANALYSIS
// ============================================================================

/**
 * Process analysis window
 */
export function processWindow(
  streamId: string,
  frames: number[][],
  audioSegments: number[][],
  metadata?: Record<string, unknown>
): WindowAnalysisResult {
  const session = sessions.get(streamId);
  if (!session || session.status !== 'active') {
    throw new Error(`Stream session not active: ${streamId}`);
  }
  
  const startTime = Date.now() - session.config.analysisWindow;
  const endTime = Date.now();
  const windowId = `window_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
  
  // Perform detection analysis
  const detectionStart = performance.now();
  
  // Aggregate analysis across frames
  const frameResults = frames.map(frame => analyzeFrame(frame, session.config));
  const audioResults = audioSegments.map(segment => analyzeAudioSegment(segment, session.config));
  
  // Calculate overall confidence
  const avgFrameConfidence = frameResults.reduce((sum, r) => sum + r.confidence, 0) / (frameResults.length || 1);
  const avgAudioConfidence = audioResults.reduce((sum, r) => sum + r.confidence, 0) / (audioResults.length || 1);
  
  // Weighted combination (video typically has more signals)
  const overallConfidence = session.config.type === 'mixed'
    ? avgFrameConfidence * 0.6 + avgAudioConfidence * 0.4
    : session.config.type === 'video' ? avgFrameConfidence : avgAudioConfidence;
  
  // Determine result
  let result: 'authentic' | 'deepfake' | 'uncertain';
  if (overallConfidence > 0.7) {
    result = 'authentic';
  } else if (overallConfidence < 0.3) {
    result = 'deepfake';
  } else {
    result = 'uncertain';
  }
  
  // Collect indicators
  const indicators = [
    ...frameResults.flatMap(r => r.indicators).slice(0, 5),
    ...audioResults.flatMap(r => r.indicators).slice(0, 3)
  ];
  
  const processingLatency = performance.now() - detectionStart;
  
  // Update session stats
  session.framesProcessed += frames.length;
  session.audioProcessed += audioSegments.reduce((sum, s) => sum + s.length, 0) / session.config.sampleRate;
  session.averageLatency = (session.averageLatency * 0.9) + (processingLatency * 0.1);
  session.currentBuffer = frames.length;
  
  // Analyze confidence trend
  const trend = analyzeConfidenceTrend(streamId, overallConfidence);
  
  // Determine if alert should be generated
  const alertGenerated = shouldGenerateAlert(
    result,
    overallConfidence,
    trend,
    session.config.alertThreshold,
    session.alertsGenerated
  );
  
  const windowResult: WindowAnalysisResult = {
    windowId,
    streamId,
    startTime,
    endTime,
    frameCount: frames.length,
    audioDuration: audioSegments.reduce((sum, s) => sum + s.length, 0) / session.config.sampleRate,
    result,
    confidence: overallConfidence,
    confidenceTrend: trend.direction === 'stable' ? 'stable' : 
                     trend.direction === 'improving' ? 'increasing' : 
                     trend.direction === 'degrading' ? 'decreasing' : 'volatile',
    indicators,
    processingLatency,
    alertGenerated
  };
  
  // Store result
  const results = windowResults.get(streamId) || [];
  results.push(windowResult);
  // Keep last 100 windows
  if (results.length > 100) results.shift();
  windowResults.set(streamId, results);
  
  // Update rolling state
  updateRollingState(streamId, windowResult);
  
  // Generate alert if needed
  if (alertGenerated) {
    const alert = createStreamAlert(streamId, windowResult, trend);
    const sessionAlerts = alerts.get(streamId) || [];
    sessionAlerts.push(alert);
    alerts.set(streamId, sessionAlerts);
    session.alertsGenerated++;
  }
  
  return windowResult;
}

/**
 * Analyze single frame
 */
function analyzeFrame(
  frame: number[],
  config: StreamConfig
): { confidence: number; indicators: string[] } {
  // Simplified frame analysis
  // In production, would use actual ML model
  
  const indicators: string[] = [];
  let confidence = 0.5;
  
  // Check for common deepfake artifacts
  const noiseLevel = calculateNoiseLevel(frame);
  if (noiseLevel > 0.3) {
    indicators.push('high_frequency_noise');
    confidence -= 0.1;
  }
  
  const edgeConsistency = calculateEdgeConsistency(frame);
  if (edgeConsistency < 0.7) {
    indicators.push('edge_inconsistency');
    confidence -= 0.15;
  }
  
  const colorDistribution = analyzeColorDistribution(frame);
  if (colorDistribution.anomalous) {
    indicators.push('color_anomaly');
    confidence -= 0.1;
  }
  
  // Ensure confidence is bounded
  confidence = Math.max(0, Math.min(1, confidence + 0.5));
  
  return { confidence, indicators };
}

/**
 * Analyze audio segment
 */
function analyzeAudioSegment(
  segment: number[],
  config: StreamConfig
): { confidence: number; indicators: string[] } {
  const indicators: string[] = [];
  let confidence = 0.5;
  
  // Check for synthetic audio artifacts
  const spectralFlatness = calculateSpectralFlatness(segment);
  if (spectralFlatness > 0.8) {
    indicators.push('synthetic_spectrum');
    confidence -= 0.2;
  }
  
  const voiceConsistency = calculateVoiceConsistency(segment);
  if (voiceConsistency < 0.6) {
    indicators.push('voice_inconsistency');
    confidence -= 0.15;
  }
  
  confidence = Math.max(0, Math.min(1, confidence + 0.3));
  
  return { confidence, indicators };
}

/**
 * Calculate noise level
 */
function calculateNoiseLevel(frame: number[]): number {
  // High-frequency energy ratio
  let hfEnergy = 0;
  let totalEnergy = 0;
  
  for (let i = 1; i < frame.length; i++) {
    const diff = Math.abs(frame[i] - frame[i - 1]);
    hfEnergy += diff;
    totalEnergy += Math.abs(frame[i]);
  }
  
  return totalEnergy > 0 ? hfEnergy / totalEnergy : 0;
}

/**
 * Calculate edge consistency
 */
function calculateEdgeConsistency(frame: number[]): number {
  // Simplified edge detection consistency
  const edges: number[] = [];
  
  for (let i = 1; i < frame.length - 1; i++) {
    const gradient = Math.abs(frame[i + 1] - frame[i - 1]);
    edges.push(gradient);
  }
  
  const mean = edges.reduce((sum, e) => sum + e, 0) / edges.length;
  const variance = edges.reduce((sum, e) => sum + Math.pow(e - mean, 2), 0) / edges.length;
  
  // Lower variance = more consistent edges
  return Math.max(0, 1 - Math.sqrt(variance) / (mean + 0.01));
}

/**
 * Analyze color distribution
 */
function analyzeColorDistribution(frame: number[]): { anomalous: boolean; score: number } {
  // Check for unnatural color clustering
  const histogram = new Map<number, number>();
  
  for (const value of frame) {
    const bucket = Math.floor(value * 10);
    histogram.set(bucket, (histogram.get(bucket) || 0) + 1);
  }
  
  const counts = Array.from(histogram.values());
  const maxCount = Math.max(...counts);
  const totalCount = frame.length;
  
  // Anomalous if too concentrated
  const concentration = maxCount / totalCount;
  return {
    anomalous: concentration > 0.5,
    score: concentration
  };
}

/**
 * Calculate spectral flatness
 */
function calculateSpectralFlatness(segment: number[]): number {
  // Simplified spectral analysis
  const windowSize = 256;
  const flatnesses: number[] = [];
  
  for (let i = 0; i < segment.length - windowSize; i += windowSize) {
    const window = segment.slice(i, i + windowSize);
    
    // Simple spectral estimation via autocorrelation
    let geometricMean = 1;
    let arithmeticMean = 0;
    
    for (const value of window) {
      const absValue = Math.abs(value) + 0.001;
      geometricMean *= Math.pow(absValue, 1 / window.length);
      arithmeticMean += absValue / window.length;
    }
    
    flatnesses.push(geometricMean / (arithmeticMean + 0.001));
  }
  
  return flatnesses.reduce((sum, f) => sum + f, 0) / flatnesses.length;
}

/**
 * Calculate voice consistency
 */
function calculateVoiceConsistency(segment: number[]): number {
  // Simplified voice analysis
  const zeroCrossings = countZeroCrossings(segment);
  const expectedRange = [10, 100]; // Typical voice zero crossing rate
  
  if (zeroCrossings >= expectedRange[0] && zeroCrossings <= expectedRange[1]) {
    return 0.8;
  }
  return 0.4;
}

/**
 * Count zero crossings
 */
function countZeroCrossings(segment: number[]): number {
  let count = 0;
  for (let i = 1; i < segment.length; i++) {
    if ((segment[i] >= 0 && segment[i - 1] < 0) || (segment[i] < 0 && segment[i - 1] >= 0)) {
      count++;
    }
  }
  return count;
}

// ============================================================================
// TREND & ANOMALY ANALYSIS
// ============================================================================

/**
 * Analyze confidence trend
 */
function analyzeConfidenceTrend(streamId: string, currentConfidence: number): TrendResult {
  const state = rollingStates.get(streamId);
  if (!state) {
    return {
      direction: 'stable',
      rate: 0,
      predictedConfidence: currentConfidence,
      timeToThreshold: null,
      patternDetected: null
    };
  }
  
  // Add to history
  state.confidenceHistory.push(currentConfidence);
  if (state.confidenceHistory.length > 50) {
    state.confidenceHistory.shift();
  }
  
  const history = state.confidenceHistory;
  
  if (history.length < 5) {
    return {
      direction: 'stable',
      rate: 0,
      predictedConfidence: currentConfidence,
      timeToThreshold: null,
      patternDetected: null
    };
  }
  
  // Calculate trend using linear regression
  const trend = calculateLinearTrend(history);
  
  // Detect patterns
  const pattern = detectPattern(history);
  
  // Predict future confidence
  const predictedConfidence = currentConfidence + trend.rate * 10;
  
  // Calculate time to threshold
  let timeToThreshold: number | null = null;
  if (trend.rate !== 0) {
    const threshold = 0.3; // Deepfake threshold
    const diff = threshold - currentConfidence;
    if ((trend.rate > 0 && diff < 0) || (trend.rate < 0 && diff > 0)) {
      timeToThreshold = Math.abs(diff / trend.rate);
    }
  }
  
  return {
    direction: trend.direction,
    rate: trend.rate,
    predictedConfidence: Math.max(0, Math.min(1, predictedConfidence)),
    timeToThreshold,
    patternDetected: pattern
  };
}

/**
 * Calculate linear trend
 */
function calculateLinearTrend(values: number[]): { direction: TrendResult['direction']; rate: number } {
  const n = values.length;
  let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
  
  for (let i = 0; i < n; i++) {
    sumX += i;
    sumY += values[i];
    sumXY += i * values[i];
    sumX2 += i * i;
  }
  
  const denominator = n * sumX2 - sumX * sumX;
  if (denominator === 0) {
    return { direction: 'stable', rate: 0 };
  }
  
  const slope = (n * sumXY - sumX * sumY) / denominator;
  
  let direction: TrendResult['direction'];
  if (Math.abs(slope) < 0.001) {
    direction = 'stable';
  } else if (slope > 0) {
    direction = 'improving';
  } else {
    direction = 'degrading';
  }
  
  // Check volatility
  const mean = sumY / n;
  let variance = 0;
  for (const v of values) {
    variance += Math.pow(v - mean, 2);
  }
  const stdDev = Math.sqrt(variance / n);
  
  if (stdDev > 0.2) {
    direction = 'volatile';
  }
  
  return { direction, rate: slope };
}

/**
 * Detect patterns in confidence history
 */
function detectPattern(values: number[]): string | null {
  if (values.length < 10) return null;
  
  // Check for oscillation
  let signChanges = 0;
  for (let i = 1; i < values.length - 1; i++) {
    const prev = values[i - 1] - values[i - 2];
    const curr = values[i] - values[i - 1];
    if ((prev > 0 && curr < 0) || (prev < 0 && curr > 0)) {
      signChanges++;
    }
  }
  
  if (signChanges > values.length * 0.4) {
    return 'oscillating';
  }
  
  // Check for sudden drop
  const last = values[values.length - 1];
  const prev = values[values.length - 5];
  if (prev - last > 0.3) {
    return 'sudden_drop';
  }
  
  // Check for gradual decline
  const first = values[0];
  const lastTen = values.slice(-10);
  const avgLastTen = lastTen.reduce((sum, v) => sum + v, 0) / 10;
  if (first - avgLastTen > 0.2) {
    return 'gradual_decline';
  }
  
  return null;
}

/**
 * Update rolling state
 */
function updateRollingState(streamId: string, result: WindowAnalysisResult): void {
  const state = rollingStates.get(streamId);
  if (!state) return;
  
  state.windowResults.push(result);
  if (state.windowResults.length > 20) {
    state.windowResults.shift();
  }
  
  // Check for anomalies
  if (result.confidence < 0.4) {
    state.anomalyDetected = true;
    state.anomalyType = 'low_confidence';
  } else if (result.confidenceTrend === 'volatile') {
    state.anomalyDetected = true;
    state.anomalyType = 'volatile_confidence';
  } else {
    state.anomalyDetected = false;
    state.anomalyType = null;
  }
}

/**
 * Determine if alert should be generated
 */
function shouldGenerateAlert(
  result: 'authentic' | 'deepfake' | 'uncertain',
  confidence: number,
  trend: TrendResult,
  threshold: number,
  recentAlerts: number
): boolean {
  // Always alert on deepfake detection
  if (result === 'deepfake' && confidence < threshold) {
    return true;
  }
  
  // Alert on degrading trend approaching threshold
  if (trend.direction === 'degrading' && trend.timeToThreshold && trend.timeToThreshold < 10) {
    return true;
  }
  
  // Alert on sudden drop pattern
  if (trend.patternDetected === 'sudden_drop') {
    return true;
  }
  
  // Rate limit alerts (max 5 per session)
  if (recentAlerts >= 5) {
    return false;
  }
  
  return false;
}

/**
 * Create stream alert
 */
function createStreamAlert(
  streamId: string,
  windowResult: WindowAnalysisResult,
  trend: TrendResult
): StreamAlert {
  const id = `alert_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
  
  let type: StreamAlert['type'];
  let severity: StreamAlert['severity'];
  let description: string;
  let recommendedAction: string;
  
  if (windowResult.result === 'deepfake') {
    type = 'deepfake_detected';
    severity = windowResult.confidence < 0.2 ? 'critical' : 'high';
    description = `Potential deepfake detected with ${(1 - windowResult.confidence) * 100}% confidence`;
    recommendedAction = 'Review content immediately and consider flagging';
  } else if (trend.patternDetected === 'sudden_drop') {
    type = 'pattern_change';
    severity = 'medium';
    description = 'Sudden confidence drop detected in stream analysis';
    recommendedAction = 'Monitor closely for additional indicators';
  } else {
    type = 'confidence_drop';
    severity = 'low';
    description = 'Confidence trending downward';
    recommendedAction = 'Continue monitoring';
  }
  
  return {
    id,
    streamId,
    type,
    severity,
    confidence: windowResult.confidence,
    windowId: windowResult.windowId,
    timestamp: Date.now(),
    description,
    evidence: windowResult.indicators,
    recommendedAction,
    acknowledged: false
  };
}

// ============================================================================
// HEALTH MONITORING
// ============================================================================

/**
 * Update stream health metrics
 */
export function updateHealthMetrics(
  streamId: string,
  metrics: Partial<StreamHealthMetrics>
): StreamHealthMetrics {
  const session = sessions.get(streamId);
  if (!session) {
    throw new Error(`Stream not found: ${streamId}`);
  }
  
  const fullMetrics: StreamHealthMetrics = {
    streamId,
    fps: metrics.fps ?? session.config.frameRate,
    bitrate: metrics.bitrate ?? 1000,
    packetLoss: metrics.packetLoss ?? 0,
    jitter: metrics.jitter ?? 0,
    latency: metrics.latency ?? session.averageLatency,
    bufferHealth: metrics.bufferHealth ?? session.currentBuffer / session.config.bufferSize,
    cpuUsage: metrics.cpuUsage ?? 50,
    memoryUsage: metrics.memoryUsage ?? 50,
    timestamp: Date.now()
  };
  
  const history = healthMetrics.get(streamId) || [];
  history.push(fullMetrics);
  if (history.length > 100) history.shift();
  healthMetrics.set(streamId, history);
  
  // Calculate health score
  session.healthScore = calculateHealthScore(fullMetrics);
  
  return fullMetrics;
}

/**
 * Calculate health score
 */
function calculateHealthScore(metrics: StreamHealthMetrics): number {
  let score = 100;
  
  // Deduct for issues
  if (metrics.fps < 20) score -= 20;
  else if (metrics.fps < 25) score -= 10;
  
  if (metrics.packetLoss > 0.05) score -= 30;
  else if (metrics.packetLoss > 0.01) score -= 15;
  
  if (metrics.jitter > 50) score -= 20;
  else if (metrics.jitter > 20) score -= 10;
  
  if (metrics.latency > 500) score -= 20;
  else if (metrics.latency > 200) score -= 10;
  
  if (metrics.bufferHealth < 0.3) score -= 20;
  else if (metrics.bufferHealth < 0.5) score -= 10;
  
  if (metrics.cpuUsage > 90) score -= 15;
  if (metrics.memoryUsage > 90) score -= 15;
  
  return Math.max(0, score);
}

// ============================================================================
// ADAPTIVE QUALITY
// ============================================================================

/**
 * Get adaptive quality settings
 */
export function getAdaptiveQuality(streamId: string): AdaptiveQualitySettings {
  const session = sessions.get(streamId);
  if (!session) {
    return {
      resolution: [640, 480],
      frameRate: 30,
      analysisDepth: 'standard',
      modelComplexity: 'medium',
      parallelWorkers: 2
    };
  }
  
  const healthScore = session.healthScore;
  const avgLatency = session.averageLatency;
  
  let resolution: [number, number];
  let frameRate: number;
  let analysisDepth: AdaptiveQualitySettings['analysisDepth'];
  let modelComplexity: AdaptiveQualitySettings['modelComplexity'];
  let parallelWorkers: number;
  
  if (healthScore > 80 && avgLatency < 100) {
    // High quality
    resolution = [1920, 1080];
    frameRate = 60;
    analysisDepth = 'thorough';
    modelComplexity = 'heavy';
    parallelWorkers = 4;
  } else if (healthScore > 60 && avgLatency < 200) {
    // Standard quality
    resolution = [1280, 720];
    frameRate = 30;
    analysisDepth = 'standard';
    modelComplexity = 'medium';
    parallelWorkers = 2;
  } else {
    // Low quality (conserve resources)
    resolution = [640, 480];
    frameRate = 15;
    analysisDepth = 'quick';
    modelComplexity = 'light';
    parallelWorkers = 1;
  }
  
  return {
    resolution,
    frameRate,
    analysisDepth,
    modelComplexity,
    parallelWorkers
  };
}

// ============================================================================
// ALERT MANAGEMENT
// ============================================================================

/**
 * Get alerts for stream
 */
export function getStreamAlerts(streamId: string): StreamAlert[] {
  return alerts.get(streamId) || [];
}

/**
 * Acknowledge alert
 */
export function acknowledgeAlert(streamId: string, alertId: string): boolean {
  const sessionAlerts = alerts.get(streamId);
  if (!sessionAlerts) return false;
  
  const alert = sessionAlerts.find(a => a.id === alertId);
  if (!alert) return false;
  
  alert.acknowledged = true;
  return true;
}

/**
 * Get unacknowledged alerts
 */
export function getUnacknowledgedAlerts(): StreamAlert[] {
  const all: StreamAlert[] = [];
  for (const sessionAlerts of alerts.values()) {
    all.push(...sessionAlerts.filter(a => !a.acknowledged));
  }
  return all.sort((a, b) => b.timestamp - a.timestamp);
}

// ============================================================================
// STATUS & EXPORT
// ============================================================================

/**
 * Get stream analysis status
 */
export function getStreamAnalysisStatus(): {
  activeSessions: number;
  totalFramesProcessed: number;
  totalAudioProcessed: number;
  totalAlertsGenerated: number;
  averageHealthScore: number;
  averageLatency: number;
} {
  const activeList = listActiveSessions();
  
  return {
    activeSessions: activeList.length,
    totalFramesProcessed,
    totalAudioProcessed,
    totalAlertsGenerated,
    averageHealthScore: activeList.reduce((sum, s) => sum + s.healthScore, 0) / (activeList.length || 1),
    averageLatency: activeList.reduce((sum, s) => sum + s.averageLatency, 0) / (activeList.length || 1)
  };
}

/**
 * Run stream analysis tests
 */
export function runStreamAnalysisTests(): {
  passed: boolean;
  tests: { total: number; passed: number; failed: number };
  results: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const results: Array<{ name: string; passed: boolean; error?: string }> = [];
  
  // Test 1: Session management
  try {
    const config: StreamConfig = {
      streamId: 'test',
      type: 'video',
      sampleRate: 16000,
      frameRate: 30,
      bufferSize: 100,
      analysisWindow: 1000,
      alertThreshold: 0.3,
      latencyTarget: 100
    };
    const session = startStreamSession(config);
    if (!session.id || session.status !== 'active') {
      throw new Error('Session creation failed');
    }
    results.push({ name: 'Session Management', passed: true });
  } catch (e) {
    results.push({ name: 'Session Management', passed: false, error: String(e) });
  }
  
  // Test 2: Window processing
  try {
    const config: StreamConfig = {
      streamId: 'test2',
      type: 'mixed',
      sampleRate: 16000,
      frameRate: 30,
      resolution: [640, 480],
      bufferSize: 100,
      analysisWindow: 1000,
      alertThreshold: 0.3,
      latencyTarget: 100
    };
    const session = startStreamSession(config);
    const frames = [Array(100).fill(0).map(() => Math.random())];
    const audio = [Array(16000).fill(0).map(() => Math.random() * 2 - 1)];
    
    const result = processWindow(session.id, frames, audio);
    if (!result.windowId) {
      throw new Error('Window processing failed');
    }
    results.push({ name: 'Window Processing', passed: true });
  } catch (e) {
    results.push({ name: 'Window Processing', passed: false, error: String(e) });
  }
  
  // Test 3: Trend analysis
  try {
    const config: StreamConfig = {
      streamId: 'test3',
      type: 'video',
      sampleRate: 16000,
      frameRate: 30,
      bufferSize: 100,
      analysisWindow: 1000,
      alertThreshold: 0.3,
      latencyTarget: 100
    };
    const session = startStreamSession(config);
    
    // Process multiple windows
    for (let i = 0; i < 10; i++) {
      const frames = [Array(100).fill(0).map(() => Math.random())];
      processWindow(session.id, frames, []);
    }
    
    const state = rollingStates.get(session.id);
    if (!state || state.confidenceHistory.length < 10) {
      throw new Error('Trend analysis failed');
    }
    results.push({ name: 'Trend Analysis', passed: true });
  } catch (e) {
    results.push({ name: 'Trend Analysis', passed: false, error: String(e) });
  }
  
  // Test 4: Health monitoring
  try {
    const config: StreamConfig = {
      streamId: 'test4',
      type: 'video',
      sampleRate: 16000,
      frameRate: 30,
      bufferSize: 100,
      analysisWindow: 1000,
      alertThreshold: 0.3,
      latencyTarget: 100
    };
    const session = startStreamSession(config);
    
    const metrics = updateHealthMetrics(session.id, {
      fps: 25,
      packetLoss: 0.01,
      latency: 150
    });
    
    if (!metrics.timestamp) {
      throw new Error('Health monitoring failed');
    }
    results.push({ name: 'Health Monitoring', passed: true });
  } catch (e) {
    results.push({ name: 'Health Monitoring', passed: false, error: String(e) });
  }
  
  // Test 5: Adaptive quality
  try {
    const config: StreamConfig = {
      streamId: 'test5',
      type: 'video',
      sampleRate: 16000,
      frameRate: 30,
      bufferSize: 100,
      analysisWindow: 1000,
      alertThreshold: 0.3,
      latencyTarget: 100
    };
    const session = startStreamSession(config);
    
    const quality = getAdaptiveQuality(session.id);
    if (!quality.resolution || quality.frameRate < 1) {
      throw new Error('Adaptive quality failed');
    }
    results.push({ name: 'Adaptive Quality', passed: true });
  } catch (e) {
    results.push({ name: 'Adaptive Quality', passed: false, error: String(e) });
  }
  
  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;
  
  return {
    passed: failed === 0,
    tests: { total: results.length, passed, failed },
    results
  };
}

// Default export
const realtimeStreamModule = {
  // Session management
  startStreamSession,
  getStreamSession,
  listActiveSessions,
  pauseStreamSession,
  resumeStreamSession,
  endStreamSession,
  
  // Processing
  processWindow,
  
  // Health monitoring
  updateHealthMetrics,
  
  // Adaptive quality
  getAdaptiveQuality,
  
  // Alerts
  getStreamAlerts,
  acknowledgeAlert,
  getUnacknowledgedAlerts,
  
  // Status
  getStreamAnalysisStatus,
  
  // Tests
  runStreamAnalysisTests
};

export default realtimeStreamModule;
