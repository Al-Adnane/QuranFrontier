/**
 * Kasbah Predictive Threat Intelligence
 * Attack forecasting, threat actor profiling, and campaign prediction
 * 
 * @module predictive-threat-intelligence
 * @version 1.0.0
 * @disruption-score +2.5/10
 * 
 * Capabilities:
 * - Emerging Attack Prediction
 * - Threat Actor Profiling
 * - Campaign Forecasting
 * - Vulnerability Prediction
 * - Attack Surface Analysis
 * - Risk Score Forecasting
 * - Proactive Defense Recommendations
 * - Threat Trend Analysis
 */

// ============================================
// TYPE DEFINITIONS
// ============================================

export interface ThreatPrediction {
  id: string;
  timestamp: Date;
  predictionType: ThreatPredictionType;
  threat: Threat;
  probability: number;
  confidence: number;
  timeframe: TimeFrame;
  indicators: Indicator[];
  mitigationStrategies: string[];
  sources: string[];
}

export type ThreatPredictionType = 
  | 'attack_likelihood'
  | 'vulnerability_exploitation'
  | 'campaign_emergence'
  | 'threat_actor_activity'
  | 'zero_day_probability'
  | 'supply_chain_risk';

export interface Threat {
  id: string;
  name: string;
  category: ThreatCategory;
  severity: 'low' | 'medium' | 'high' | 'critical';
  description: string;
  mitreId?: string;
  cveIds?: string[];
}

export type ThreatCategory = 
  | 'malware'
  | 'phishing'
  | 'ransomware'
  | 'ddos'
  | 'apt'
  | 'insider_threat'
  | 'supply_chain'
  | 'zero_day'
  | 'social_engineering'
  | 'cryptojacking';

export interface TimeFrame {
  start: Date;
  end: Date;
  granularity: 'hours' | 'days' | 'weeks' | 'months';
}

export interface Indicator {
  id: string;
  type: IndicatorType;
  value: string;
  confidence: number;
  firstSeen: Date;
  lastSeen: Date;
  occurrences: number;
  relatedThreats: string[];
}

export type IndicatorType = 
  | 'ip'
  | 'domain'
  | 'url'
  | 'hash'
  | 'email'
  | 'pattern'
  | 'behavior';

export interface ThreatActor {
  id: string;
  name: string;
  aliases: string[];
  country?: string;
  motivation: Motivation[];
  capabilities: Capability[];
  ttps: TTP[];
  targetSectors: string[];
  targetCountries: string[];
  sophistication: 'novice' | 'intermediate' | 'advanced' | 'expert';
  activityLevel: 'inactive' | 'dormant' | 'active' | 'surging';
  firstSeen: Date;
  lastSeen: Date;
  attribution: Attribution[];
}

export type Motivation = 
  | 'financial'
  | 'espionage'
  | 'hacktivism'
  | 'sabotage'
  | 'cybercrime'
  | 'political';

export interface Capability {
  name: string;
  level: number; // 1-10
  evidence: string[];
}

export interface TTP {
  mitreId: string;
  name: string;
  frequency: number;
  lastUsed: Date;
}

export interface Attribution {
  source: string;
  confidence: number;
  evidence: string[];
}

export interface Campaign {
  id: string;
  name: string;
  threatActor: string;
  startDate?: Date;
  endDate?: Date;
  status: 'planning' | 'active' | 'paused' | 'completed';
  objectives: string[];
  targets: string[];
  indicators: Indicator[];
  predictedEvolution: CampaignEvolution[];
}

export interface CampaignEvolution {
  scenario: string;
  probability: number;
  timeframe: TimeFrame;
  indicators: Indicator[];
}

export interface VulnerabilityPrediction {
  id: string;
  cve?: string;
  software: string;
  version: string;
  exploitProbability: number;
  timeframe: TimeFrame;
  factors: VulnerabilityFactor[];
  recommendations: string[];
}

export interface VulnerabilityFactor {
  name: string;
  weight: number;
  value: number;
  description: string;
}

export interface RiskForecast {
  id: string;
  timestamp: Date;
  timeframe: TimeFrame;
  overallRisk: number;
  riskByCategory: Map<ThreatCategory, number>;
  riskTrend: 'increasing' | 'stable' | 'decreasing';
  topThreats: Threat[];
  emergingThreats: Threat[];
  decliningThreats: Threat[];
}

// ============================================
// THREAT PREDICTION ENGINE
// ============================================

export class ThreatPredictionEngine {
  private predictions: Map<string, ThreatPrediction[]> = new Map();
  private historicalData: Map<string, { timestamp: Date; value: number }[]> = new Map();

  /**
   * Predict attack likelihood
   */
  async predictAttackLikelihood(
    target: string,
    timeframe: TimeFrame
  ): Promise<ThreatPrediction> {
    // Analyze historical data
    const historicalTrends = this.analyzeHistoricalTrends(target, timeframe);
    
    // Identify patterns
    const patterns = this.identifyPatterns(historicalTrends);
    
    // Calculate probability
    const probability = this.calculateProbability(patterns, timeframe);
    
    // Generate threat
    const threat: Threat = {
      id: `threat-${Date.now()}`,
      name: `Predicted attack on ${target}`,
      category: this.inferCategory(patterns),
      severity: this.calculateSeverity(probability),
      description: `Predicted attack based on pattern analysis`
    };

    // Generate indicators
    const indicators = this.generateIndicators(patterns);

    // Generate mitigations
    const mitigationStrategies = this.generateMitigations(threat);

    const prediction: ThreatPrediction = {
      id: `pred-${Date.now()}`,
      timestamp: new Date(),
      predictionType: 'attack_likelihood',
      threat,
      probability,
      confidence: this.calculateConfidence(patterns),
      timeframe,
      indicators,
      mitigationStrategies,
      sources: ['historical_analysis', 'pattern_matching', 'threat_intelligence']
    };

    // Store prediction
    const existing = this.predictions.get(target) || [];
    existing.push(prediction);
    this.predictions.set(target, existing);

    return prediction;
  }

  /**
   * Predict vulnerability exploitation
   */
  async predictVulnerabilityExploitation(
    cve: string,
    software: string,
    version: string
  ): Promise<VulnerabilityPrediction> {
    // Calculate exploit probability based on multiple factors
    const factors: VulnerabilityFactor[] = [
      {
        name: 'cvss_score',
        weight: 0.3,
        value: await this.getCVSSScore(cve),
        description: 'Base CVSS score'
      },
      {
        name: 'time_since_disclosure',
        weight: 0.2,
        value: this.getTimeSinceDisclosure(cve),
        description: 'Time since public disclosure'
      },
      {
        name: 'exploit_availability',
        weight: 0.25,
        value: await this.checkExploitAvailability(cve),
        description: 'Known exploit availability'
      },
      {
        name: 'software_popularity',
        weight: 0.15,
        value: await this.getSoftwarePopularity(software),
        description: 'Software deployment prevalence'
      },
      {
        name: 'threat_actor_interest',
        weight: 0.1,
        value: await this.getThreatActorInterest(cve),
        description: 'Known threat actor interest'
      }
    ];

    // Calculate overall probability
    let exploitProbability = 0;
    for (const factor of factors) {
      exploitProbability += factor.weight * factor.value;
    }

    // Generate recommendations
    const recommendations = this.generateVulnerabilityRecommendations(factors);

    return {
      id: `vuln-pred-${Date.now()}`,
      cve,
      software,
      version,
      exploitProbability,
      timeframe: {
        start: new Date(),
        end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
        granularity: 'days'
      },
      factors,
      recommendations
    };
  }

  private analyzeHistoricalTrends(
    target: string,
    timeframe: TimeFrame
  ): number[] {
    // Simulate historical trend analysis
    const days = Math.ceil((timeframe.end.getTime() - timeframe.start.getTime()) / (24 * 60 * 60 * 1000));
    
    return Array(days).fill(0).map((_, i) => {
      const baseValue = 0.3 + Math.random() * 0.2;
      const trend = i * 0.01;
      const noise = (Math.random() - 0.5) * 0.1;
      return Math.max(0, Math.min(1, baseValue + trend + noise));
    });
  }

  private identifyPatterns(trends: number[]): Pattern[] {
    const patterns: Pattern[] = [];
    
    // Trend detection
    const avgFirst = trends.slice(0, Math.floor(trends.length / 3));
    const avgLast = trends.slice(-Math.floor(trends.length / 3));
    
    const firstAvg = avgFirst.reduce((a, b) => a + b, 0) / avgFirst.length;
    const lastAvg = avgLast.reduce((a, b) => a + b, 0) / avgLast.length;
    
    if (lastAvg > firstAvg * 1.2) {
      patterns.push({
        type: 'increasing_trend',
        strength: (lastAvg - firstAvg) / firstAvg,
        confidence: 0.8
      });
    } else if (lastAvg < firstAvg * 0.8) {
      patterns.push({
        type: 'decreasing_trend',
        strength: (firstAvg - lastAvg) / firstAvg,
        confidence: 0.8
      });
    }

    // Seasonality detection
    const period = this.detectSeasonality(trends);
    if (period > 0) {
      patterns.push({
        type: 'seasonal',
        strength: 0.3,
        confidence: 0.6,
        period
      });
    }

    // Anomaly detection
    const mean = trends.reduce((a, b) => a + b, 0) / trends.length;
    const std = Math.sqrt(trends.reduce((acc, v) => acc + Math.pow(v - mean, 2), 0) / trends.length);
    const anomalies = trends.filter(v => Math.abs(v - mean) > 2 * std);
    
    if (anomalies.length > trends.length * 0.05) {
      patterns.push({
        type: 'anomalous',
        strength: anomalies.length / trends.length,
        confidence: 0.7
      });
    }

    return patterns;
  }

  private detectSeasonality(data: number[]): number {
    // Simple seasonality detection using autocorrelation
    if (data.length < 14) return 0;

    const mean = data.reduce((a, b) => a + b, 0) / data.length;
    const normalized = data.map(v => v - mean);

    for (let period = 7; period <= Math.min(30, data.length / 2); period++) {
      let correlation = 0;
      for (let i = 0; i < data.length - period; i++) {
        correlation += normalized[i] * normalized[i + period];
      }
      
      if (correlation / (data.length - period) > 0.5) {
        return period;
      }
    }

    return 0;
  }

  private calculateProbability(patterns: Pattern[], timeframe: TimeFrame): number {
    let probability = 0.3; // Base probability
    
    for (const pattern of patterns) {
      switch (pattern.type) {
        case 'increasing_trend':
          probability += pattern.strength * 0.3;
          break;
        case 'decreasing_trend':
          probability -= pattern.strength * 0.2;
          break;
        case 'anomalous':
          probability += pattern.strength * 0.2;
          break;
        case 'seasonal':
          probability += 0.1;
          break;
      }
    }

    return Math.max(0, Math.min(1, probability));
  }

  private calculateConfidence(patterns: Pattern[]): number {
    if (patterns.length === 0) return 0.3;
    
    return patterns.reduce((sum, p) => sum + p.confidence, 0) / patterns.length;
  }

  private inferCategory(patterns: Pattern[]): ThreatCategory {
    // Simplified category inference
    const hasTrend = patterns.some(p => p.type === 'increasing_trend');
    const hasAnomaly = patterns.some(p => p.type === 'anomalous');
    
    if (hasAnomaly && hasTrend) return 'apt';
    if (hasTrend) return 'ransomware';
    return 'malware';
  }

  private calculateSeverity(probability: number): 'low' | 'medium' | 'high' | 'critical' {
    if (probability > 0.8) return 'critical';
    if (probability > 0.6) return 'high';
    if (probability > 0.4) return 'medium';
    return 'low';
  }

  private generateIndicators(patterns: Pattern[]): Indicator[] {
    const indicators: Indicator[] = [];
    
    for (const pattern of patterns) {
      indicators.push({
        id: `ind-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        type: 'pattern',
        value: pattern.type,
        confidence: pattern.confidence,
        firstSeen: new Date(),
        lastSeen: new Date(),
        occurrences: 1,
        relatedThreats: []
      });
    }

    return indicators;
  }

  private generateMitigations(threat: Threat): string[] {
    const mitigations: string[] = [];
    
    switch (threat.category) {
      case 'ransomware':
        mitigations.push('Implement and test backup procedures');
        mitigations.push('Deploy EDR solutions');
        mitigations.push('Segment network to limit lateral movement');
        break;
      case 'phishing':
        mitigations.push('Implement email filtering');
        mitigations.push('Conduct security awareness training');
        mitigations.push('Enable MFA');
        break;
      case 'apt':
        mitigations.push('Enhance monitoring and detection capabilities');
        mitigations.push('Implement threat hunting program');
        mitigations.push('Review and harden network segmentation');
        break;
      default:
        mitigations.push('Maintain up-to-date security controls');
        mitigations.push('Monitor for suspicious activity');
        mitigations.push('Have incident response plan ready');
    }

    return mitigations;
  }

  private async getCVSSScore(cve: string): Promise<number> {
    // Simulate CVSS lookup
    return 0.7 + Math.random() * 0.3;
  }

  private getTimeSinceDisclosure(cve: string): number {
    // Simulate time calculation
    return Math.random();
  }

  private async checkExploitAvailability(cve: string): Promise<number> {
    return Math.random();
  }

  private async getSoftwarePopularity(software: string): Promise<number> {
    return Math.random();
  }

  private async getThreatActorInterest(cve: string): Promise<number> {
    return Math.random();
  }

  private generateVulnerabilityRecommendations(factors: VulnerabilityFactor[]): string[] {
    const recommendations: string[] = [];
    
    const highRiskFactors = factors.filter(f => f.value > 0.7);
    
    for (const factor of highRiskFactors) {
      switch (factor.name) {
        case 'exploit_availability':
          recommendations.push('Apply patch immediately - exploit is publicly available');
          break;
        case 'threat_actor_interest':
          recommendations.push('Priority patching recommended - threat actors showing interest');
          break;
        case 'cvss_score':
          recommendations.push('Critical vulnerability - prioritize remediation');
          break;
      }
    }

    if (recommendations.length === 0) {
      recommendations.push('Monitor for exploit development');
      recommendations.push('Plan patching within standard SLA');
    }

    return recommendations;
  }
}

interface Pattern {
  type: string;
  strength: number;
  confidence: number;
  period?: number;
}

// ============================================
// THREAT ACTOR PROFILER
// ============================================

export class ThreatActorProfiler {
  private actors: Map<string, ThreatActor> = new Map();
  private observations: Map<string, Observation[]> = new Map();

  /**
   * Profile threat actor
   */
  async profileActor(
    indicators: Indicator[],
    observedTTPs: TTP[]
  ): Promise<ThreatActor> {
    // Match against known actors
    const matches = this.matchKnownActors(indicators, observedTTPs);
    
    if (matches.length > 0 && matches[0].confidence > 0.7) {
      return matches[0].actor;
    }

    // Create new actor profile
    const actor: ThreatActor = {
      id: `actor-${Date.now()}`,
      name: `UNC-${Math.floor(Math.random() * 10000)}`,
      aliases: [],
      motivation: this.inferMotivation(observedTTPs),
      capabilities: this.inferCapabilities(observedTTPs),
      ttps: observedTTPs,
      targetSectors: this.inferTargetSectors(indicators),
      targetCountries: [],
      sophistication: this.inferSophistication(observedTTPs),
      activityLevel: 'active',
      firstSeen: new Date(),
      lastSeen: new Date(),
      attribution: []
    };

    this.actors.set(actor.id, actor);
    
    return actor;
  }

  /**
   * Update actor profile
   */
  updateProfile(
    actorId: string,
    newIndicators: Indicator[],
    newTTPs: TTP[]
  ): ThreatActor {
    const actor = this.actors.get(actorId);
    if (!actor) {
      throw new Error(`Actor ${actorId} not found`);
    }

    // Update TTPs
    for (const ttp of newTTPs) {
      const existing = actor.ttps.find(t => t.mitreId === ttp.mitreId);
      if (existing) {
        existing.frequency++;
        existing.lastUsed = new Date();
      } else {
        actor.ttps.push(ttp);
      }
    }

    // Update capabilities
    for (const ttp of newTTPs) {
      this.updateCapability(actor, ttp);
    }

    actor.lastSeen = new Date();
    
    return actor;
  }

  /**
   * Predict actor behavior
   */
  async predictBehavior(
    actor: ThreatActor,
    timeframe: TimeFrame
  ): Promise<{
    predictedTTPs: TTP[];
    predictedTargets: string[];
    activityForecast: number[];
  }> {
    // Analyze historical TTP usage
    const predictedTTPs = this.predictTTPUsage(actor);
    
    // Predict targets
    const predictedTargets = this.predictTargets(actor);
    
    // Forecast activity
    const activityForecast = this.forecastActivity(actor, timeframe);

    return {
      predictedTTPs,
      predictedTargets,
      activityForecast
    };
  }

  private matchKnownActors(
    indicators: Indicator[],
    ttps: TTP[]
  ): Array<{ actor: ThreatActor; confidence: number }> {
    const matches: Array<{ actor: ThreatActor; confidence: number }> = [];

    for (const [id, actor] of this.actors) {
      let confidence = 0;
      
      // TTP overlap
      const ttpOverlap = ttps.filter(t => 
        actor.ttps.some(at => at.mitreId === t.mitreId)
      ).length / ttps.length;
      
      confidence += ttpOverlap * 0.5;

      // Indicator overlap
      const indicatorOverlap = indicators.filter(i =>
        actor.targetSectors.some(s => i.value.includes(s))
      ).length / indicators.length;
      
      confidence += indicatorOverlap * 0.3;

      // Activity timing
      const recentActivity = (Date.now() - actor.lastSeen.getTime()) < 30 * 24 * 60 * 60 * 1000;
      if (recentActivity) confidence += 0.2;

      if (confidence > 0.5) {
        matches.push({ actor, confidence });
      }
    }

    return matches.sort((a, b) => b.confidence - a.confidence);
  }

  private inferMotivation(ttps: TTP[]): Motivation[] {
    const motivations: Motivation[] = [];
    
    // Simple inference based on TTPs
    const hasCollection = ttps.some(t => t.mitreId.startsWith('T1'));
    const hasExfiltration = ttps.some(t => t.mitreId.startsWith('T10'));
    const hasImpact = ttps.some(t => t.mitreId.startsWith('T14'));

    if (hasExfiltration) motivations.push('espionage');
    if (hasImpact) motivations.push('sabotage');
    if (!hasExfiltration && !hasImpact) motivations.push('financial');

    return motivations;
  }

  private inferCapabilities(ttps: TTP[]): Capability[] {
    const capabilities: Capability[] = [];
    
    const hasSpearPhishing = ttps.some(t => t.mitreId === 'T1566');
    const hasExploitation = ttps.some(t => t.mitreId.startsWith('T11'));
    const hasPersistence = ttps.some(t => t.mitreId.startsWith('T10'));

    if (hasSpearPhishing) {
      capabilities.push({
        name: 'Spear Phishing',
        level: 7,
        evidence: ['T1566 observed']
      });
    }

    if (hasExploitation) {
      capabilities.push({
        name: 'Exploitation',
        level: 8,
        evidence: ['Exploit usage observed']
      });
    }

    if (hasPersistence) {
      capabilities.push({
        name: 'Persistence',
        level: 6,
        evidence: ['Persistence mechanisms observed']
      });
    }

    return capabilities;
  }

  private inferTargetSectors(indicators: Indicator[]): string[] {
    // Simplified inference
    return ['technology', 'finance', 'healthcare'];
  }

  private inferSophistication(ttps: TTP[]): 'novice' | 'intermediate' | 'advanced' | 'expert' {
    const uniqueTTPs = new Set(ttps.map(t => t.mitreId)).size;
    
    if (uniqueTTPs > 20) return 'expert';
    if (uniqueTTPs > 10) return 'advanced';
    if (uniqueTTPs > 5) return 'intermediate';
    return 'novice';
  }

  private updateCapability(actor: ThreatActor, ttp: TTP): void {
    const capabilityName = this.ttpToCapability(ttp.mitreId);
    let capability = actor.capabilities.find(c => c.name === capabilityName);
    
    if (capability) {
      capability.level = Math.min(10, capability.level + 0.5);
      capability.evidence.push(`TTP ${ttp.mitreId} observed`);
    } else {
      actor.capabilities.push({
        name: capabilityName,
        level: 5,
        evidence: [`TTP ${ttp.mitreId} observed`]
      });
    }
  }

  private ttpToCapability(mitreId: string): string {
    const prefix = mitreId.substring(0, 2);
    
    const mapping: Record<string, string> = {
      'T1': 'Initial Access',
      'T2': 'Execution',
      'T3': 'Persistence',
      'T4': 'Privilege Escalation',
      'T5': 'Defense Evasion',
      'T6': 'Credential Access',
      'T7': 'Discovery',
      'T8': 'Lateral Movement',
      'T9': 'Collection',
      'TA': 'Command and Control',
      'TB': 'Exfiltration',
      'TC': 'Impact'
    };

    return mapping[prefix] || 'Unknown';
  }

  private predictTTPs(actor: ThreatActor): TTP[] {
    // Predict based on historical TTP frequency
    return actor.ttps
      .sort((a, b) => b.frequency - a.frequency)
      .slice(0, 5);
  }

  private predictTargets(actor: ThreatActor): string[] {
    return actor.targetSectors;
  }

  private forecastActivity(
    actor: ThreatActor,
    timeframe: TimeFrame
  ): number[] {
    const days = Math.ceil(
      (timeframe.end.getTime() - timeframe.start.getTime()) / (24 * 60 * 60 * 1000)
    );

    // Simple forecast based on activity level
    const baseActivity = actor.activityLevel === 'surging' ? 0.8 :
                        actor.activityLevel === 'active' ? 0.5 :
                        actor.activityLevel === 'dormant' ? 0.2 : 0.1;

    return Array(days).fill(0).map((_, i) => {
      const trend = i * 0.01;
      const noise = (Math.random() - 0.5) * 0.1;
      return Math.max(0, Math.min(1, baseActivity + trend + noise));
    });
  }
}

interface Observation {
  timestamp: Date;
  type: string;
  data: unknown;
}

// ============================================
// CAMPAIGN FORECASTER
// ============================================

export class CampaignForecaster {
  private campaigns: Map<string, Campaign> = new Map();

  /**
   * Forecast campaign evolution
   */
  async forecastCampaign(
    campaign: Campaign,
    timeframe: TimeFrame
  ): Promise<CampaignEvolution[]> {
    const evolutions: CampaignEvolution[] = [];

    // Scenario 1: Continuation
    evolutions.push({
      scenario: 'Continuation',
      probability: 0.4,
      timeframe,
      indicators: campaign.indicators
    });

    // Scenario 2: Escalation
    evolutions.push({
      scenario: 'Escalation',
      probability: 0.25,
      timeframe,
      indicators: this.generateEscalationIndicators(campaign)
    });

    // Scenario 3: Pivot
    evolutions.push({
      scenario: 'Pivot to new targets',
      probability: 0.2,
      timeframe,
      indicators: this.generatePivotIndicators(campaign)
    });

    // Scenario 4: Wind-down
    evolutions.push({
      scenario: 'Campaign wind-down',
      probability: 0.15,
      timeframe,
      indicators: []
    });

    return evolutions;
  }

  private generateEscalationIndicators(campaign: Campaign): Indicator[] {
    return campaign.indicators.map(ind => ({
      ...ind,
      id: `esc-${ind.id}`,
      confidence: ind.confidence * 1.2
    }));
  }

  private generatePivotIndicators(campaign: Campaign): Indicator[] {
    // Generate indicators for new target sectors
    return [{
      id: `pivot-${Date.now()}`,
      type: 'pattern',
      value: 'new_target_sector',
      confidence: 0.6,
      firstSeen: new Date(),
      lastSeen: new Date(),
      occurrences: 1,
      relatedThreats: []
    }];
  }

  /**
   * Detect emerging campaign
   */
  async detectEmergingCampaign(
    indicators: Indicator[],
    timeframe: TimeFrame
  ): Promise<Campaign | null> {
    // Cluster indicators
    const clusters = this.clusterIndicators(indicators);
    
    if (clusters.length === 0) {
      return null;
    }

    // Create campaign from largest cluster
    const largestCluster = clusters.sort((a, b) => b.length - a.length)[0];

    const campaign: Campaign = {
      id: `campaign-${Date.now()}`,
      name: `Emerging Campaign ${new Date().toISOString().split('T')[0]}`,
      threatActor: 'Unknown',
      status: 'active',
      objectives: ['Unknown'],
      targets: [],
      indicators: largestCluster,
      predictedEvolution: []
    };

    this.campaigns.set(campaign.id, campaign);

    return campaign;
  }

  private clusterIndicators(indicators: Indicator[]): Indicator[][] {
    // Simple clustering based on indicator type and time proximity
    const clusters: Indicator[][] = [];
    const used = new Set<string>();

    for (const indicator of indicators) {
      if (used.has(indicator.id)) continue;

      const cluster: Indicator[] = [indicator];
      used.add(indicator.id);

      for (const other of indicators) {
        if (used.has(other.id)) continue;

        // Same type and within 24 hours
        if (
          other.type === indicator.type &&
          Math.abs(other.firstSeen.getTime() - indicator.firstSeen.getTime()) < 24 * 60 * 60 * 1000
        ) {
          cluster.push(other);
          used.add(other.id);
        }
      }

      if (cluster.length > 1) {
        clusters.push(cluster);
      }
    }

    return clusters;
  }
}

// ============================================
// RISK FORECASTER
// ============================================

export class RiskForecaster {
  private predictionEngine: ThreatPredictionEngine;
  private actorProfiler: ThreatActorProfiler;
  private campaignForecaster: CampaignForecaster;

  constructor() {
    this.predictionEngine = new ThreatPredictionEngine();
    this.actorProfiler = new ThreatActorProfiler();
    this.campaignForecaster = new CampaignForecaster();
  }

  /**
   * Generate risk forecast
   */
  async generateForecast(timeframe: TimeFrame): Promise<RiskForecast> {
    // Calculate overall risk
    const overallRisk = await this.calculateOverallRisk(timeframe);
    
    // Risk by category
    const riskByCategory = await this.calculateRiskByCategory(timeframe);
    
    // Identify top threats
    const topThreats = await this.identifyTopThreats(5);
    
    // Identify emerging threats
    const emergingThreats = await this.identifyEmergingThreats();
    
    // Identify declining threats
    const decliningThreats = await this.identifyDecliningThreats();

    // Determine trend
    const riskTrend = this.determineTrend(overallRisk);

    return {
      id: `risk-${Date.now()}`,
      timestamp: new Date(),
      timeframe,
      overallRisk,
      riskByCategory,
      riskTrend,
      topThreats,
      emergingThreats,
      decliningThreats
    };
  }

  private async calculateOverallRisk(timeframe: TimeFrame): Promise<number> {
    // Multi-factor risk calculation
    const factors = [
      { weight: 0.3, value: await this.getThreatLandscapeRisk() },
      { weight: 0.25, value: await this.getVulnerabilityRisk() },
      { weight: 0.2, value: await this.getActorActivityRisk() },
      { weight: 0.15, value: await this.getCampaignRisk() },
      { weight: 0.1, value: await this.getInfrastructureRisk() }
    ];

    return factors.reduce((risk, f) => risk + f.weight * f.value, 0);
  }

  private async calculateRiskByCategory(timeframe: TimeFrame): Promise<Map<ThreatCategory, number>> {
    const risk = new Map<ThreatCategory, number>();
    
    const categories: ThreatCategory[] = [
      'malware', 'phishing', 'ransomware', 'ddos', 'apt', 
      'insider_threat', 'supply_chain', 'zero_day', 'social_engineering', 'cryptojacking'
    ];

    for (const category of categories) {
      risk.set(category, 0.1 + Math.random() * 0.6);
    }

    return risk;
  }

  private async identifyTopThreats(count: number): Promise<Threat[]> {
    const threats: Threat[] = [];
    
    for (let i = 0; i < count; i++) {
      threats.push({
        id: `threat-${i}`,
        name: `Top Threat ${i + 1}`,
        category: ['ransomware', 'phishing', 'apt', 'supply_chain', 'zero_day'][i] as ThreatCategory,
        severity: 'high',
        description: 'High probability threat'
      });
    }

    return threats;
  }

  private async identifyEmergingThreats(): Promise<Threat[]> {
    return [
      {
        id: 'emerging-1',
        name: 'AI-powered phishing',
        category: 'phishing',
        severity: 'high',
        description: 'Increasing use of AI for personalized phishing'
      }
    ];
  }

  private async identifyDecliningThreats(): Promise<Threat[]> {
    return [
      {
        id: 'declining-1',
        name: 'Legacy malware',
        category: 'malware',
        severity: 'low',
        description: 'Legacy malware variants declining'
      }
    ];
  }

  private determineTrend(risk: number): 'increasing' | 'stable' | 'decreasing' {
    // Simplified trend determination
    if (risk > 0.6) return 'increasing';
    if (risk < 0.4) return 'decreasing';
    return 'stable';
  }

  private async getThreatLandscapeRisk(): Promise<number> {
    return 0.5 + Math.random() * 0.3;
  }

  private async getVulnerabilityRisk(): Promise<number> {
    return 0.4 + Math.random() * 0.4;
  }

  private async getActorActivityRisk(): Promise<number> {
    return 0.3 + Math.random() * 0.5;
  }

  private async getCampaignRisk(): Promise<number> {
    return 0.2 + Math.random() * 0.4;
  }

  private async getInfrastructureRisk(): Promise<number> {
    return 0.3 + Math.random() * 0.3;
  }
}

// ============================================
// PREDICTIVE INTELLIGENCE SUITE
// ============================================

export class PredictiveIntelligenceSuite {
  private predictionEngine: ThreatPredictionEngine;
  private actorProfiler: ThreatActorProfiler;
  private campaignForecaster: CampaignForecaster;
  private riskForecaster: RiskForecaster;

  constructor() {
    this.predictionEngine = new ThreatPredictionEngine();
    this.actorProfiler = new ThreatActorProfiler();
    this.campaignForecaster = new CampaignForecaster();
    this.riskForecaster = new RiskForecaster();
  }

  /**
   * Run comprehensive threat prediction
   */
  async predict(
    target: string,
    timeframe: TimeFrame
  ): Promise<{
    attackPrediction: ThreatPrediction;
    riskForecast: RiskForecast;
    recommendations: string[];
  }> {
    const attackPrediction = await this.predictionEngine.predictAttackLikelihood(target, timeframe);
    const riskForecast = await this.riskForecaster.generateForecast(timeframe);
    
    const recommendations = this.generateRecommendations(attackPrediction, riskForecast);

    return {
      attackPrediction,
      riskForecast,
      recommendations
    };
  }

  /**
   * Get suite status
   */
  getStatus(): {
    capabilities: string[];
    models: string[];
    version: string;
  } {
    return {
      capabilities: [
        'Attack Likelihood Prediction',
        'Vulnerability Exploitation Prediction',
        'Threat Actor Profiling',
        'Campaign Forecasting',
        'Risk Forecasting',
        'Emerging Threat Detection',
        'Behavioral Prediction',
        'Proactive Recommendations'
      ],
      models: [
        'Time Series Analysis',
        'Pattern Recognition',
        'Actor Behavior Modeling',
        'Campaign Evolution Model',
        'Risk Aggregation'
      ],
      version: '1.0.0'
    };
  }

  private generateRecommendations(
    prediction: ThreatPrediction,
    forecast: RiskForecast
  ): string[] {
    const recommendations: string[] = [];

    if (prediction.probability > 0.7) {
      recommendations.push('HIGH ALERT: Elevated attack probability - enhance monitoring');
    }

    if (forecast.riskTrend === 'increasing') {
      recommendations.push('Risk trend increasing - review security posture');
    }

    for (const threat of forecast.emergingThreats) {
      recommendations.push(`Monitor for: ${threat.name}`);
    }

    recommendations.push(...prediction.mitigationStrategies);

    return recommendations;
  }
}

// ============================================
// EXPORTS
// ============================================

export const predictiveIntelligence = {
  ThreatPredictionEngine,
  ThreatActorProfiler,
  CampaignForecaster,
  RiskForecaster,
  PredictiveIntelligenceSuite
};

export default predictiveIntelligence;
