/**
 * Validation Module Stress Test
 * Tests edge cases and security boundaries in file validation
 */

import {
  verifyMagicBytes,
  detectMimeType,
  validateFileExtension,
  validateFileSize,
  sanitizeFilename,
  BLOCKED_EXTENSIONS,
  MIN_FILE_SIZE,
  MAX_FILE_SIZE
} from '../validation'

// Test runner
interface TestResult {
  category: string
  name: string
  passed: boolean
  error?: string
}

const results: TestResult[] = []

function test(category: string, name: string, fn: () => boolean): void {
  try {
    const passed = fn()
    results.push({ category, name, passed })
  } catch (error) {
    results.push({ 
      category, 
      name, 
      passed: false, 
      error: error instanceof Error ? error.message : String(error) 
    })
  }
}

// ========================================
// RUN ALL TESTS
// ========================================

console.log('\n🔬 Running Validation Module Stress Tests...\n')

// 1. MAGIC BYTES VERIFICATION TESTS
test('Magic Bytes', 'Valid PNG magic bytes should pass', () => {
  const pngHeader = Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A])
  const result = verifyMagicBytes(pngHeader, 'image/png')
  return result.valid === true
})

test('Magic Bytes', 'Valid JPEG magic bytes should pass', () => {
  const jpegHeader = Buffer.from([0xFF, 0xD8, 0xFF, 0xE0])
  const result = verifyMagicBytes(jpegHeader, 'image/jpeg')
  return result.valid === true
})

test('Magic Bytes', 'Spoofed file (JPEG claiming to be PNG) should fail', () => {
  const jpegHeader = Buffer.from([0xFF, 0xD8, 0xFF, 0xE0])
  const result = verifyMagicBytes(jpegHeader, 'image/png')
  return result.valid === false && result.code === 'INVALID_SIGNATURE'
})

test('Magic Bytes', 'Empty buffer should fail', () => {
  const emptyBuffer = Buffer.alloc(0)
  const result = verifyMagicBytes(emptyBuffer, 'image/png')
  return result.valid === false && result.code === 'FILE_TOO_SMALL'
})

test('Magic Bytes', 'Truncated header should fail', () => {
  const truncatedPng = Buffer.from([0x89, 0x50])
  const result = verifyMagicBytes(truncatedPng, 'image/png')
  return result.valid === false
})

test('Magic Bytes', 'Random bytes should fail', () => {
  const randomBytes = Buffer.from([0xDE, 0xAD, 0xBE, 0xEF])
  const result = verifyMagicBytes(randomBytes, 'image/png')
  return result.valid === false
})

// 2. MIME TYPE DETECTION TESTS
test('MIME Detection', 'Detect PNG from magic bytes', () => {
  const pngHeader = Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A])
  return detectMimeType(pngHeader) === 'image/png'
})

test('MIME Detection', 'Detect GIF from magic bytes', () => {
  const gifHeader = Buffer.from([0x47, 0x49, 0x46, 0x38])
  return detectMimeType(gifHeader) === 'image/gif'
})

test('MIME Detection', 'Return null for unrecognized bytes', () => {
  const randomBytes = Buffer.from([0xDE, 0xAD, 0xBE, 0xEF])
  return detectMimeType(randomBytes) === null
})

// 3. FILE EXTENSION VALIDATION TESTS
test('Extension', 'Valid PNG extension should pass', () => {
  const result = validateFileExtension('test.png', 'image/png')
  return result.valid === true
})

test('Extension', 'Extension mismatch should fail', () => {
  const result = validateFileExtension('test.png', 'image/jpeg')
  return result.valid === false && result.code === 'EXTENSION_MISMATCH'
})

test('Extension', 'Blocked extension .exe should fail', () => {
  const result = validateFileExtension('malware.exe', 'application/octet-stream')
  return result.valid === false && result.code === 'BLOCKED_EXTENSION'
})

test('Extension', 'Missing extension should fail', () => {
  const result = validateFileExtension('noextension', 'image/png')
  return result.valid === false && result.code === 'MISSING_EXTENSION'
})

test('Extension', 'Multiple blocked extensions should all fail', () => {
  const blocked = ['.exe', '.bat', '.sh', '.php', '.js']
  return blocked.every(ext => {
    const result = validateFileExtension(`test${ext}`, 'application/octet-stream')
    return result.code === 'BLOCKED_EXTENSION'
  })
})

// 4. FILE SIZE VALIDATION TESTS
test('Size', 'Valid file size should pass', () => {
  const result = validateFileSize(1024 * 1024, 'image/png')
  return result.valid === true
})

test('Size', 'File too small should fail', () => {
  const result = validateFileSize(50, 'image/png')
  return result.valid === false && result.code === 'FILE_TOO_SMALL'
})

test('Size', 'File exceeding max size should fail', () => {
  const result = validateFileSize(MAX_FILE_SIZE + 1, 'image/png')
  return result.valid === false && result.code === 'FILE_TOO_LARGE'
})

test('Size', 'File at exact limit should pass', () => {
  const result = validateFileSize(MAX_FILE_SIZE, 'image/png')
  return result.valid === true
})

test('Size', 'Minimum valid file size should pass', () => {
  const result = validateFileSize(MIN_FILE_SIZE, 'image/png')
  return result.valid === true
})

test('Size', 'Just below minimum file size should fail', () => {
  const result = validateFileSize(MIN_FILE_SIZE - 1, 'image/png')
  return result.valid === false
})

// 5. FILENAME SANITIZATION TESTS
test('Sanitization', 'Path traversal with ../ should be sanitized', () => {
  const result = sanitizeFilename('../../../etc/passwd.png')
  return !result.includes('..') && !result.includes('/')
})

test('Sanitization', 'Backslash path traversal should be sanitized', () => {
  const result = sanitizeFilename('..\\..\\windows\\system32\\config.png')
  return !result.includes('..') && !result.includes('\\')
})

test('Sanitization', 'Null bytes should be removed', () => {
  const result = sanitizeFilename('test\x00file.png')
  return !result.includes('\x00')
})

test('Sanitization', 'Control characters should be removed', () => {
  const result = sanitizeFilename('test\x01\x02\x03file.png')
  return !result.includes('\x01') && !result.includes('\x02')
})

test('Sanitization', 'Leading dots should be removed', () => {
  const result = sanitizeFilename('...hidden.png')
  return !result.startsWith('.')
})

test('Sanitization', 'Very long filenames should be truncated', () => {
  const longName = 'a'.repeat(300) + '.png'
  const result = sanitizeFilename(longName)
  return result.length <= 255
})

test('Sanitization', 'Extension should be preserved in truncation', () => {
  const longName = 'a'.repeat(300) + '.png'
  const result = sanitizeFilename(longName)
  return result.endsWith('.png')
})

test('Sanitization', 'Unicode filename should be handled', () => {
  const result = sanitizeFilename('测试文件.png')
  return typeof result === 'string' && result.length > 0
})

test('Sanitization', 'Empty filename should return empty string', () => {
  const result = sanitizeFilename('')
  return result === ''
})

// ========================================
// PRINT RESULTS
// ========================================

console.log('\n' + '='.repeat(60))
console.log('📊 VALIDATION MODULE TEST RESULTS')
console.log('='.repeat(60) + '\n')

// Group by category
const categories = [...new Set(results.map(r => r.category))]

categories.forEach(category => {
  const categoryResults = results.filter(r => r.category === category)
  const passed = categoryResults.filter(r => r.passed).length
  
  console.log(`\n📁 ${category} (${passed}/${categoryResults.length} passed)`)
  
  categoryResults.forEach(r => {
    const icon = r.passed ? '  ✅' : '  ❌'
    console.log(`${icon} ${r.name}`)
    if (!r.passed && r.error) {
      console.log(`     Error: ${r.error}`)
    }
  })
})

const totalPassed = results.filter(r => r.passed).length
const totalFailed = results.filter(r => !r.passed).length

console.log('\n' + '-'.repeat(60))
console.log(`\n📈 Summary: ${totalPassed}/${results.length} tests passed`)

if (totalFailed > 0) {
  console.log(`❌ ${totalFailed} test(s) failed`)
} else {
  console.log('✅ All tests passed!')
}

console.log('\n' + '='.repeat(60))

export { results }
