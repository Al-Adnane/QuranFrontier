/**
 * Viral & Share Features
 * Make results shareable and incentivize sharing
 */

export interface ShareableResult {
  id: string
  shortUrl: string
  result: 'authentic' | 'deepfake' | 'uncertain'
  confidence: number
  platform: string
  createdAt: string
  views: number
}

// In-memory store (use database in production)
const sharedResults = new Map<string, ShareableResult>()

/**
 * Generate a short shareable ID
 */
function generateShareId(): string {
  return Math.random().toString(36).substring(2, 8)
}

/**
 * Create a shareable result
 */
export function createShareableResult(params: {
  result: 'authentic' | 'deepfake' | 'uncertain'
  confidence: number
  platform: string
}): ShareableResult {
  const id = generateShareId()
  
  const shareable: ShareableResult = {
    id,
    shortUrl: `https://deepfake-detector.app/r/${id}`,
    result: params.result,
    confidence: params.confidence,
    platform: params.platform,
    createdAt: new Date().toISOString(),
    views: 0
  }
  
  sharedResults.set(id, shareable)
  
  // Clean up old results after 24 hours
  setTimeout(() => {
    sharedResults.delete(id)
  }, 24 * 60 * 60 * 1000)
  
  return shareable
}

/**
 * Get a shared result by ID
 */
export function getSharedResult(id: string): ShareableResult | null {
  const result = sharedResults.get(id)
  if (result) {
    result.views++
  }
  return result || null
}

/**
 * Generate social share text
 */
export function generateShareText(result: 'authentic' | 'deepfake' | 'uncertain', confidence: number): {
  twitter: string
  facebook: string
  whatsapp: string
  generic: string
} {
  const confidencePercent = Math.round(confidence * 100)
  
  const messages = {
    authentic: {
      twitter: `✅ This media is AUTHENTIC (${confidencePercent}% confidence)\n\nI just verified it with Deepfake Detector - try it yourself!\n\n#DeepfakeDetector #AI`,
      facebook: `✅ Just verified this media - it's authentic! (${confidencePercent}% confidence)\n\nCheck your own media at Deepfake Detector`,
      whatsapp: `✅ This media is authentic! I verified it with Deepfake Detector (${confidencePercent}% confidence). Check it out: deepfake-detector.app`,
      generic: `This media has been verified as authentic with ${confidencePercent}% confidence. Verified by Deepfake Detector.`
    },
    deepfake: {
      twitter: `⚠️ DEEPFAKE DETECTED! (${confidencePercent}% confidence)\n\nThis content appears to be AI-generated. Stay safe!\n\nI used Deepfake Detector to check.\n\n#Deepfake #AI`,
      facebook: `⚠️ WARNING: This appears to be a deepfake! (${confidencePercent}% confidence)\n\nStay vigilant - verify media before sharing. I used Deepfake Detector.`,
      whatsapp: `⚠️ WARNING: This appears to be a deepfake! (${confidencePercent}% confidence)\n\nI just checked it with Deepfake Detector. Stay safe!`,
      generic: `This media has been flagged as potentially AI-generated with ${confidencePercent}% confidence. Verified by Deepfake Detector.`
    },
    uncertain: {
      twitter: `❓ Results inconclusive (${confidencePercent}% confidence)\n\nI couldn't determine if this is real or fake. Manual review recommended.\n\nCheck it yourself: #DeepfakeDetector`,
      facebook: `❓ I couldn't determine if this media is real or fake (${confidencePercent}% confidence).\n\nUse Deepfake Detector to get a second opinion!`,
      whatsapp: `❓ I checked this media but results were inconclusive (${confidencePercent}% confidence). Get a second opinion at deepfake-detector.app`,
      generic: `This media requires manual review. ${confidencePercent}% detection confidence. Analyzed by Deepfake Detector.`
    }
  }
  
  return messages[result]
}

/**
 * Generate Open Graph meta tags for shared result
 */
export function generateOGTags(result: ShareableResult): {
  title: string
  description: string
  image: string
} {
  const confidencePercent = Math.round(result.confidence * 100)
  
  const titles = {
    authentic: `✅ Authentic Media (${confidencePercent}%)`,
    deepfake: `⚠️ Deepfake Detected (${confidencePercent}%)`,
    uncertain: `❓ Uncertain Result (${confidencePercent}%)`
  }
  
  const descriptions = {
    authentic: `This media was verified as authentic with ${confidencePercent}% confidence. Checked by Deepfake Detector.`,
    deepfake: `This media was flagged as a deepfake with ${confidencePercent}% confidence. Stay safe!`,
    uncertain: `This media requires review. Analysis confidence: ${confidencePercent}%.`
  }
  
  return {
    title: titles[result.result],
    description: descriptions[result.result],
    image: `/api/share/${result.id}/card`
  }
}
