# Deepfake Detector - Core Moat Analysis

## Executive Summary

This document identifies the **Core Moat Code** - the unique, hard-to-replicate technical differentiators that provide competitive advantage and make the application difficult to copy.

---

## 🔐 THE MOAT: Multi-Layer Enterprise Security Stack

The primary moat is not just the VLM-based detection (which competitors could access), but the **enterprise-grade security infrastructure** that took significant engineering effort to build correctly. This security stack consists of 5 interconnected layers:

### Layer 1: File Type Spoofing Prevention (Magic Bytes Verification)

**Location**: `src/lib/validation.ts` - Lines 7-257

**What It Does**:
- Verifies file contents against claimed MIME types using binary signatures
- Detects file type spoofing attempts (e.g., malicious.exe renamed to image.png)
- Uses primary and secondary signature verification for accurate detection

**Why It's Hard To Copy**:
```typescript
// Magic bytes signatures with masks and offsets
export const MAGIC_BYTES: Record<string, { bytes: number[]; offset: number; mask?: number[] }> = {
  'image/jpeg': { bytes: [0xFF, 0xD8, 0xFF], offset: 0 },
  'image/png': { bytes: [0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A], offset: 0 },
  'audio/mpeg': { bytes: [0xFF], offset: 0, mask: [0xE0] }, // MP3 frame sync with mask
  // ... more signatures
}

// Secondary signatures for disambiguation
const SECONDARY_SIGNATURES: Record<string, { bytes: number[]; offset: number }[]> = {
  'image/webp': [{ bytes: [0x57, 0x45, 0x42, 0x50], offset: 8 }], // WEBP marker
  'video/mp4': [
    { bytes: [0x66, 0x74, 0x79, 0x70], offset: 4 }, // ftyp
    { bytes: [0x6D, 0x70, 0x34, 0x32], offset: 8 }, // mp42
  ],
}
```

**Moat Value**: Requires deep knowledge of file format specifications and edge cases. Each file type has unique signature patterns, offsets, and verification requirements. Without this, an application is vulnerable to file upload attacks.

---

### Layer 2: Sliding Window Rate Limiting

**Location**: `src/lib/rate-limiter.ts` - Lines 1-317

**What It Does**:
- Implements memory-efficient sliding window rate limiting
- Different limits for different endpoints (detection vs read)
- Automatic memory cleanup to prevent leaks
- Client identification from multiple headers

**Why It's Hard To Copy**:
```typescript
// Configurable rate limits per endpoint type
export const RATE_LIMITS = {
  DETECTION: {
    windowMs: 60 * 1000,         // 1 minute
    maxRequests: 10,             // 10 requests per minute
    blockDurationMs: 10 * 60 * 1000, // 10 minute block
  },
  READ: {
    windowMs: 60 * 1000,         // 1 minute
    maxRequests: 60,             // 60 requests per minute
    blockDurationMs: 60 * 1000,  // 1 minute block
  },
}

// Client identification from multiple sources
export function getClientIdentifier(request: Request): string {
  const identifiers = [
    headers.get('x-forwarded-for'),
    headers.get('x-real-ip'),
    headers.get('cf-connecting-ip'), // Cloudflare
    headers.get('true-client-ip'),   // Akamai
    headers.get('x-client-ip'),
  ]
  // Falls back to UA hash if no IP available
}
```

**Moat Value**: Proper rate limiting requires handling edge cases (distributed clients, proxy headers, memory management). A naive implementation would leak memory or be easily bypassed.

---

### Layer 3: Circuit Breaker Pattern

**Location**: `src/lib/retry.ts` - Lines 128-242

**What It Does**:
- Prevents cascade failures when external services (VLM, Database) fail
- Implements half-open state for recovery testing
- Exponential backoff with jitter to prevent thundering herd

**Why It's Hard To Copy**:
```typescript
export class CircuitBreaker {
  private state: CircuitBreakerState
  private halfOpenAttempts: number = 0

  async execute<T>(fn: () => Promise<T>): Promise<T> {
    // Check if circuit is open
    if (this.state.isOpen) {
      const now = Date.now()
      
      // Half-open state allows limited recovery attempts
      if (now >= this.state.nextAttemptTime) {
        if (this.halfOpenAttempts >= this.config.halfOpenMaxAttempts) {
          throw new Error(`Circuit breaker '${this.name}' is open.`)
        }
        this.halfOpenAttempts++
      } else {
        throw new Error(`Circuit breaker open. Next attempt in ${...} seconds.`)
      }
    }

    try {
      const result = await fn()
      this.onSuccess()  // Reset failure count
      return result
    } catch (error) {
      this.onFailure()  // Increment failure count, possibly open circuit
      throw error
    }
  }
}

// Pre-configured circuit breakers
export const vlmCircuitBreaker = new CircuitBreaker('vlm-api', {
  failureThreshold: 5,
  resetTimeoutMs: 60000,
  halfOpenMaxAttempts: 2
})
```

**Moat Value**: The circuit breaker pattern is well-known, but implementing it correctly with half-open state, proper state management, and integration with retry logic requires significant engineering effort.

---

### Layer 4: Structured Logging with Sensitive Data Redaction

**Location**: `src/lib/logger.ts` (referenced in API routes)

**What It Does**:
- Multi-level logging (debug, info, warn, error, critical)
- Automatic sensitive data redaction
- Request tracking with unique IDs
- Response timing for performance monitoring

**Why It's Hard To Copy**:
- Requires careful identification of what data is sensitive
- Must balance debugging needs with security requirements
- Needs proper integration with error handling

---

### Layer 5: Hierarchical Error Types

**Location**: `src/lib/errors.ts` - Lines 1-314

**What It Does**:
- Custom error classes with proper inheritance
- Operational vs programming error distinction
- Error codes for programmatic handling
- Proper serialization for API responses

**Why It's Hard To Copy**:
```typescript
export class AppError extends Error {
  public readonly code: string
  public readonly statusCode: number
  public readonly isOperational: boolean  // Distinguishes expected vs unexpected
  
  constructor(
    message: string,
    code: string,
    statusCode: number = 500,
    isOperational: boolean = true,
    context?: Record<string, unknown>
  ) {
    super(message)
    this.name = this.constructor.name
    // ... proper stack trace capture
  }
}

// Specialized error types
export class FileSignatureError extends FileValidationError { ... }
export class CircuitBreakerError extends AppError { ... }
export class RateLimitError extends AppError { ... }
```

**Moat Value**: Proper error handling taxonomy makes the application debuggable and secure. Each error type carries contextual information for proper handling.

---

## 🎯 CORE MOAT CODE IDENTIFICATION

### Tier 1: Extremely Hard to Replicate (Primary Moat)

1. **`verifyMagicBytes()` + `detectMimeType()`** (validation.ts)
   - Requires deep file format knowledge
   - Handles edge cases (WebP RIFF format, MP4 atom structure, MP3 frame sync)
   - ~200 lines of carefully crafted logic

2. **`CircuitBreaker` class** (retry.ts)
   - Full implementation with half-open state
   - Proper state management and recovery
   - Integration with timeout and retry

3. **Rate Limit Store with Memory Management** (rate-limiter.ts)
   - Sliding window implementation
   - Automatic cleanup to prevent memory leaks
   - Multi-header client identification

### Tier 2: Moderately Hard to Replicate (Secondary Moat)

4. **Detection Prompts** (api/detect/route.ts)
   - Expert-crafted prompts for deepfake detection
   - Specific indicators for different media types
   - JSON parsing with validation

5. **Error Type Hierarchy** (errors.ts)
   - Proper inheritance chain
   - Context preservation
   - Operational distinction

### Tier 3: Standard Best Practices (Not Moat)

- Standard file upload handling
- Basic TypeScript types
- UI components (using shadcn/ui)
- Database schema

---

## 📊 MOAT STRENGTH METRICS

| Component | Lines of Code | Complexity | Time to Replicate |
|-----------|--------------|------------|-------------------|
| Magic Bytes Verification | ~200 | High | 2-3 weeks |
| Circuit Breaker | ~100 | Medium-High | 1 week |
| Rate Limiter | ~150 | Medium-High | 1-2 weeks |
| Error Hierarchy | ~100 | Medium | 3-5 days |
| Detection Prompts | ~60 | High | 1-2 weeks |
| **Total** | **~610** | **Very High** | **6-9 weeks** |

---

## 🛡️ DEFENSIVE MOAT STRATEGIES

### 1. Continuous Improvement
- Add more file type signatures
- Improve detection prompt accuracy
- Enhance rate limiting with distributed store

### 2. Monitoring Integration
- Add metrics for circuit breaker state
- Track rate limit thresholds
- Log file validation failures for analysis

### 3. Security Updates
- Regular updates to blocked extensions
- New magic byte signatures for emerging formats
- Enhanced client identification

---

## 📝 COMPETITOR ANALYSIS

### What Competitors Could Easily Copy:
- VLM integration (same SDK available)
- Basic UI/UX (shadcn/ui is open source)
- Database schema (standard Prisma)
- API structure (standard Next.js)

### What Would Take Significant Effort:
- File type spoofing prevention (~3 weeks)
- Rate limiting system (~2 weeks)
- Circuit breaker implementation (~1 week)
- Error handling taxonomy (~1 week)

### What Cannot Be Copied:
- The accumulated knowledge of edge cases
- The specific detection prompts tuned for accuracy
- The integration of all security layers

---

## 🔥 STRESS TEST RESULTS

The stress test validates the moat by demonstrating:

1. **Rate Limiting Works**: Requests are properly throttled
2. **File Spoofing Blocked**: Invalid signatures rejected
3. **Circuit Breaker Protects**: External failures don't cascade
4. **Error Handling Correct**: Proper HTTP status codes returned

See stress test output for detailed metrics.

---

## Conclusion

The core moat is the **enterprise security infrastructure** - specifically the interconnected layers of file validation, rate limiting, circuit breaking, and error handling. While each component individually is documented, the combination and integration requires significant engineering effort to replicate correctly.

**Estimated replication effort**: 6-9 weeks for a skilled team
**Maintenance overhead**: Ongoing (security updates, new file types, edge cases)

This moat is sustainable because security infrastructure requires continuous investment to maintain and improve.
