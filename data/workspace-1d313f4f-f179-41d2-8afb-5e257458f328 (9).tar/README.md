# Deepfake Detector

A media authentication tool for detecting AI-generated and manipulated content.

## Features

- **Image Analysis**: Detect manipulated and AI-generated images
- **Video Analysis**: Analyze videos for deepfake indicators
- **Audio Analysis**: Identify synthetic voice recordings
- **Browser Extension**: Real-time detection while browsing social media
- **Mobile Apps**: Android and iOS native applications
- **Desktop App**: Cross-platform desktop application

## Technology Stack

- **Framework**: Next.js 16 with App Router
- **Language**: TypeScript 5
- **Styling**: Tailwind CSS 4 with shadcn/ui components
- **Database**: Prisma ORM with SQLite
- **Analysis**: Vision Language Model (VLM) integration

## Quick Start

```bash
# Install dependencies
bun install

# Start development server
bun run dev

# Run linting
bun run lint
```

## Project Structure

```
src/
├── app/                 # Next.js App Router pages
├── components/          # React components
├── lib/                 # Core libraries
│   ├── frontier/        # Detection modules
│   ├── moats/           # Security layers
│   ├── security/        # Security utilities
│   └── kasbah-guard/    # Protection system
browser-extension/       # Chrome/Firefox extension
extension/               # Stealth extension
apps/
├── android/            # React Native Android app
├── ios/                # Swift iOS app
└── tauri/              # Rust desktop app
```

## Security Features

- Cryptographic audit trails
- HMAC-SHA256 execution tickets
- Rate limiting protection
- File type validation (magic bytes)
- Dynamic threat thresholds

## Self-Hosting

All external API endpoints are configurable. Default to localhost for self-hosted deployments:

```javascript
// Browser extension
window.__KASBAH_API_URL = 'http://your-server:3000/api/q';

// Android/iOS
// Set via environment variables or Info.plist
```

## License

MIT
