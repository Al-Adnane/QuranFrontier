/**
 * Deepfake Detector Browser Extension
 * Background Service Worker
 */

// Configuration - These will be configurable via extension settings
// For local development, the extension communicates with the local detector
// For production, set these to your deployed instance via chrome.storage.local.set({apiEndpoint: '...'})
const CONFIG = {
  // Default to local development - can be overridden via storage
  apiEndpoint: 'http://localhost:3000/api/detect',
  historyEndpoint: 'http://localhost:3000/api/detections',
  maxFileSize: 500 * 1024 * 1024, // 500MB
  timeout: 60000, // 60 seconds
  rateLimitPerMinute: 10
};

// Load configuration from storage on startup
chrome.storage?.local?.get(['apiEndpoint', 'historyEndpoint'], (result) => {
  if (result.apiEndpoint) CONFIG.apiEndpoint = result.apiEndpoint;
  if (result.historyEndpoint) CONFIG.historyEndpoint = result.historyEndpoint;
  console.log('[Deepfake Detector] API endpoint:', CONFIG.apiEndpoint);
});

// Listen for configuration updates
chrome.storage?.onChanged?.addListener((changes) => {
  if (changes.apiEndpoint) CONFIG.apiEndpoint = changes.apiEndpoint.newValue;
  if (changes.historyEndpoint) CONFIG.historyEndpoint = changes.historyEndpoint.newValue;
});

// Rate limiting state
const rateLimitState = {
  requests: [],
  maxRequests: 10,
  windowMs: 60000
};

/**
 * Check rate limit
 */
function checkRateLimit() {
  const now = Date.now();
  rateLimitState.requests = rateLimitState.requests.filter(
    time => now - time < rateLimitState.windowMs
  );
  
  if (rateLimitState.requests.length >= rateLimitState.maxRequests) {
    const oldestRequest = Math.min(...rateLimitState.requests);
    const retryAfter = Math.ceil((oldestRequest + rateLimitState.windowMs - now) / 1000);
    return { allowed: false, retryAfter };
  }
  
  rateLimitState.requests.push(now);
  return { allowed: true };
}

/**
 * Create context menu on installation
 */
chrome.runtime.onInstalled.addListener(() => {
  // Context menu for images
  chrome.contextMenus.create({
    id: 'scan-image',
    title: '🔍 Scan for Deepfake',
    contexts: ['image']
  });

  // Context menu for videos
  chrome.contextMenus.create({
    id: 'scan-video',
    title: '🔍 Scan for Deepfake',
    contexts: ['video']
  });

  // Context menu for audio
  chrome.contextMenus.create({
    id: 'scan-audio',
    title: '🔍 Scan for Deepfake',
    contexts: ['audio']
  });

  // Context menu for links (to scan linked media)
  chrome.contextMenus.create({
    id: 'scan-link',
    title: '🔍 Scan Linked Media',
    contexts: ['link']
  });

  console.log('Deepfake Detector extension installed');
});

/**
 * Handle context menu clicks
 */
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const rateCheck = checkRateLimit();
  if (!rateCheck.allowed) {
    showNotification({
      type: 'error',
      title: 'Rate Limit Exceeded',
      message: `Please wait ${rateCheck.retryAfter} seconds before scanning again.`
    });
    return;
  }

  let mediaUrl = null;
  let mediaType = null;

  switch (info.menuItemId) {
    case 'scan-image':
      mediaUrl = info.srcUrl;
      mediaType = 'image';
      break;
    case 'scan-video':
      mediaUrl = info.srcUrl;
      mediaType = 'video';
      break;
    case 'scan-audio':
      mediaUrl = info.srcUrl;
      mediaType = 'audio';
      break;
    case 'scan-link':
      mediaUrl = info.linkUrl;
      mediaType = detectMediaTypeFromUrl(info.linkUrl);
      break;
  }

  if (!mediaUrl) {
    showNotification({
      type: 'error',
      title: 'Scan Failed',
      message: 'Could not detect media URL'
    });
    return;
  }

  // Show scanning notification
  showNotification({
    type: 'progress',
    title: 'Scanning Media...',
    message: 'Analyzing for deepfake signatures'
  });

  try {
    const result = await scanMedia(mediaUrl, mediaType);
    
    // Store result in history
    await storeResult(result);

    // Show result notification
    showResultNotification(result);

    // Send result to content script for in-page display
    chrome.tabs.sendMessage(tab.id, {
      type: 'SCAN_RESULT',
      result: result
    });

  } catch (error) {
    showNotification({
      type: 'error',
      title: 'Scan Failed',
      message: error.message || 'An error occurred during scanning'
    });
  }
});

/**
 * Scan media via API
 */
async function scanMedia(url, mediaType) {
  // For data URLs, we can send directly
  // For external URLs, we need to fetch first
  let blob;
  let filename = 'media';

  if (url.startsWith('data:')) {
    // Data URL - convert to blob
    const response = await fetch(url);
    blob = await response.blob();
  } else {
    // External URL - fetch with CORS handling
    filename = url.split('/').pop().split('?')[0] || 'media';
    
    const response = await fetch(url, {
      mode: 'cors',
      credentials: 'omit'
    });
    
    if (!response.ok) {
      throw new Error(`Failed to fetch media: ${response.status}`);
    }
    
    blob = await response.blob();
  }

  // Validate file size
  if (blob.size > CONFIG.maxFileSize) {
    throw new Error(`File too large: ${(blob.size / (1024 * 1024)).toFixed(1)}MB (max: 500MB)`);
  }

  // Create form data
  const formData = new FormData();
  formData.append('file', blob, filename);

  // Send to API with timeout
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), CONFIG.timeout);

  try {
    const response = await fetch(CONFIG.apiEndpoint, {
      method: 'POST',
      body: formData,
      signal: controller.signal
    });

    clearTimeout(timeoutId);

    const data = await response.json();

    if (!response.ok || !data.success) {
      throw new Error(data.error || `API error: ${response.status}`);
    }

    return data.detection;
  } catch (error) {
    clearTimeout(timeoutId);
    if (error.name === 'AbortError') {
      throw new Error('Scan timed out. Please try again.');
    }
    throw error;
  }
}

/**
 * Detect media type from URL
 */
function detectMediaTypeFromUrl(url) {
  const extension = url.split('.').pop().toLowerCase().split('?')[0];
  
  const imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'];
  const videoExtensions = ['mp4', 'webm', 'mov', 'avi', 'mkv'];
  const audioExtensions = ['mp3', 'wav', 'ogg', 'm4a', 'flac'];

  if (imageExtensions.includes(extension)) return 'image';
  if (videoExtensions.includes(extension)) return 'video';
  if (audioExtensions.includes(extension)) return 'audio';
  
  return 'unknown';
}

/**
 * Show notification
 */
function showNotification({ type, title, message }) {
  const iconMap = {
    progress: 'icons/icon-128.png',
    success: 'icons/icon-success.png',
    error: 'icons/icon-error.png',
    warning: 'icons/icon-warning.png'
  };

  chrome.notifications.create({
    type: 'basic',
    iconUrl: iconMap[type] || 'icons/icon-128.png',
    title: title,
    message: message,
    priority: type === 'error' ? 2 : 1
  });
}

/**
 * Show result notification with appropriate styling
 */
function showResultNotification(result) {
  const resultConfig = {
    authentic: {
      title: '✅ Authentic Media',
      icon: 'icons/icon-success.png'
    },
    deepfake: {
      title: '⚠️ Deepfake Detected',
      icon: 'icons/icon-warning.png'
    },
    uncertain: {
      title: '❓ Uncertain Result',
      icon: 'icons/icon-error.png'
    }
  };

  const config = resultConfig[result.result] || resultConfig.uncertain;

  chrome.notifications.create({
    type: 'basic',
    iconUrl: config.icon,
    title: config.title,
    message: `Confidence: ${(result.confidence * 100).toFixed(1)}%\n${result.analysis.slice(0, 100)}...`,
    priority: result.result === 'deepfake' ? 2 : 1
  });
}

/**
 * Store result in local history
 */
async function storeResult(result) {
  const { history = [] } = await chrome.storage.local.get('history');
  
  history.unshift({
    ...result,
    scannedAt: new Date().toISOString()
  });

  // Keep only last 100 results
  const trimmedHistory = history.slice(0, 100);

  await chrome.storage.local.set({ history: trimmedHistory });
}

/**
 * Handle messages from popup and content scripts
 */
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.type) {
    case 'GET_HISTORY':
      chrome.storage.local.get('history').then(data => {
        sendResponse({ success: true, history: data.history || [] });
      });
      return true; // Keep channel open for async response

    case 'CLEAR_HISTORY':
      chrome.storage.local.set({ history: [] }).then(() => {
        sendResponse({ success: true });
      });
      return true;

    case 'SCAN_URL':
      (async () => {
        try {
          const rateCheck = checkRateLimit();
          if (!rateCheck.allowed) {
            sendResponse({ 
              success: false, 
              error: `Rate limit exceeded. Wait ${rateCheck.retryAfter}s` 
            });
            return;
          }

          const result = await scanMedia(message.url, message.mediaType);
          await storeResult(result);
          sendResponse({ success: true, result });
        } catch (error) {
          sendResponse({ success: false, error: error.message });
        }
      })();
      return true;

    case 'GET_RATE_LIMIT':
      const now = Date.now();
      const recentRequests = rateLimitState.requests.filter(
        time => now - time < rateLimitState.windowMs
      );
      sendResponse({
        remaining: rateLimitState.maxRequests - recentRequests.length,
        resetIn: recentRequests.length > 0 
          ? Math.ceil((Math.min(...recentRequests) + rateLimitState.windowMs - now) / 1000)
          : 0
      });
      return true;
  }
});

// Log startup
console.log('Deepfake Detector service worker started');
