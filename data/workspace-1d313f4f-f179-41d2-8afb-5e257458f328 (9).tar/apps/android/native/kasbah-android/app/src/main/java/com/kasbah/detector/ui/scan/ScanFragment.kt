package com.kasbah.detector.ui.scan

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.kasbah.detector.R
import com.kasbah.detector.detection.DetectionEngine
import com.kasbah.detector.detection.DetectionResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ScanFragment : Fragment() {
    private lateinit var detectionEngine: DetectionEngine
    private var binding: View? = null
    
    private val cameraLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        if (success) Toast.makeText(requireContext(), "Image captured", Toast.LENGTH_SHORT).show()
    }
    
    private val galleryLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { analyzeImage(it) }
    }
    
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { perms ->
        if (perms[Manifest.permission.CAMERA] == true) openCamera()
        else if (perms[Manifest.permission.READ_MEDIA_IMAGES] == true) openGallery()
    }
    
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.fragment_scan, container, false)
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        detectionEngine = DetectionEngine()
        binding = view
        
        view.findViewById<View>(R.id.btn_camera)?.setOnClickListener { checkPermissions() }
        view.findViewById<View>(R.id.btn_gallery)?.setOnClickListener { openGallery() }
    }
    
    private fun checkPermissions() {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            openCamera()
        } else {
            permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA))
        }
    }
    
    private fun openCamera() {
        // Camera implementation
    }
    
    private fun openGallery() {
        galleryLauncher.launch("image/*")
    }
    
    private fun analyzeImage(uri: Uri) {
        lifecycleScope.launch {
            try {
                val bitmap = withContext(Dispatchers.IO) {
                    requireContext().contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                }
                bitmap?.let {
                    val result = withContext(Dispatchers.IO) { detectionEngine.analyzeImage(it) }
                    displayResult(result)
                }
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    private fun displayResult(result: DetectionResult) {
        Toast.makeText(requireContext(), "${result.result.name} (${(result.confidence * 100).toInt()}%)", Toast.LENGTH_LONG).show()
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        binding = null
    }
}
