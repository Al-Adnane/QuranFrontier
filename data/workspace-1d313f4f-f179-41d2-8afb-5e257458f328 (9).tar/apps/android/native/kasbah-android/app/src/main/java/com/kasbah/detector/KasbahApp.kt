package com.kasbah.detector

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager

class KasbahApp : Application() {
    companion object {
        const val CHANNEL_ID = "kasbah_channel"
        lateinit var instance: KasbahApp
    }
    
    override fun onCreate() {
        super.onCreate()
        instance = this
        createNotificationChannel()
    }
    
    private fun createNotificationChannel() {
        val channel = NotificationChannel(CHANNEL_ID, "Kasbah Alerts", NotificationManager.IMPORTANCE_HIGH)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }
}
