package com.kasbah.detector.ui.history

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.kasbah.detector.R

data class HistoryItem(val id: String, val fileName: String, val result: String, val confidence: Double, val timestamp: Long)

class HistoryFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        return RecyclerView(requireContext()).apply {
            layoutManager = LinearLayoutManager(context)
            adapter = HistoryAdapter(emptyList())
        }
    }
}

class HistoryAdapter(private val items: List<HistoryItem>) : RecyclerView.Adapter<HistoryViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = HistoryViewHolder(
        LayoutInflater.from(parent.context).inflate(R.layout.item_history, parent, false)
    )
    override fun onBindViewHolder(holder: HistoryViewHolder, position: Int) {}
    override fun getItemCount() = items.size
}

class HistoryViewHolder(view: View) : RecyclerView.ViewHolder(view)
