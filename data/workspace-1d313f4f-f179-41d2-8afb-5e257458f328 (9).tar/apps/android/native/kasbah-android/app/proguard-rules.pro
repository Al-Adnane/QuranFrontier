# Keep Kasbah classes
-keep class com.kasbah.** { *; }
# Keep native methods
-keepclasseswithmembernames class * { native <methods>; }
