# Kasbah Android APK

Native Android application for deepfake detection with 14 Security Moats.

## Quick Start

### Build APK with Android Studio
1. Open this project in Android Studio
2. Wait for Gradle sync to complete
3. Build > Build Bundle(s) / APK(s) > Build APK(s)
4. APK location: `app/build/outputs/apk/debug/app-debug.apk`

### Build APK via Command Line
```bash
# Linux/macOS
./gradlew assembleDebug

# Windows
gradlew.bat assembleDebug
```

## Project Structure

```
kasbah-android/
├── app/
│   ├── src/main/
│   │   ├── java/com/kasbah/detector/
│   │   │   ├── MainActivity.kt          # Main entry point
│   │   │   ├── KasbahApp.kt             # Application class
│   │   │   ├── detection/
│   │   │   │   └── DetectionEngine.kt   # 14 Moats engine
│   │   │   ├── ui/
│   │   │   │   ├── scan/ScanFragment.kt
│   │   │   │   ├── history/HistoryFragment.kt
│   │   │   │   ├── realtime/RealtimeFragment.kt
│   │   │   │   └── settings/SettingsFragment.kt
│   │   │   └── service/
│   │   │       └── KasbahAccessibilityService.kt
│   │   ├── res/
│   │   │   ├── layout/                  # UI layouts
│   │   │   ├── drawable/                # Icons and shapes
│   │   │   ├── values/                  # Colors, strings, styles
│   │   │   ├── menu/                    # Bottom navigation menu
│   │   │   ├── navigation/              # Navigation graph
│   │   │   └── xml/                     # Accessibility config
│   │   └── AndroidManifest.xml
│   ├── build.gradle.kts
│   └── proguard-rules.pro
├── build.gradle.kts
├── settings.gradle.kts
└── gradle.properties
```

## Features

### 4 Main Tabs

| Tab | Description |
|-----|-------------|
| **Scan** | Camera/gallery image analysis |
| **History** | Past detection results |
| **Realtime** | Accessibility service for social media |
| **Settings** | App preferences |

### 14 Security Moats

The DetectionEngine implements all 14 moats:

1. **Frequency Analysis** - DCT frequency patterns
2. **Texture Check** - Local variance analysis
3. **Edge Detection** - Sobel edge artifacts
4. **Color Analysis** - RGB variance
5. **Noise Patterns** - Sensor noise consistency
6. **GAN Fingerprint** - Generator artifacts
7. **Attention Forensics** - Spatial attention maps
8. **Lip Sync** - Audio-video sync detection
9. **Temporal** - Frame consistency
10. **Cross Modal** - Multi-modal coherence
11. **Model Attribution** - AI generator identification
12. **Diffusion Detection** - Diffusion model artifacts
13. **Neural Fingerprint** - Neural network signatures
14. **Steganography** - LSB analysis

## Requirements

- Android SDK 34
- Kotlin 1.9.22
- Gradle 8.3
- Min SDK 24 (Android 7.0)

## Permissions

```xml
<uses-permission android:name="android.permission.CAMERA"/>
<uses-permission android:name="android.permission.READ_MEDIA_IMAGES"/>
<uses-permission android:name="android.permission.READ_MEDIA_VIDEO"/>
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW"/>
<uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
```

## Dependencies

```kotlin
// AndroidX
implementation("androidx.core:core-ktx:1.12.0")
implementation("androidx.appcompat:appcompat:1.6.1")
implementation("androidx.navigation:navigation-fragment-ktx:2.7.6")

// Material Design
implementation("com.google.android.material:material:1.11.0")

// CameraX
implementation("androidx.camera:camera-core:1.3.1")

// Coroutines
implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")

// Network
implementation("com.squareup.okhttp3:okhttp:4.12.0")
implementation("com.google.code.gson:gson:2.10.1")
```

## Code Verification

- ✅ No dead code
- ✅ All imports used
- ✅ No circular dependencies
- ✅ Material Design 3 compliance
- ✅ Kotlin best practices

## Installation

### Via ADB
```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

### Via Transfer
Copy APK to device and tap to install.

## License

MIT License
