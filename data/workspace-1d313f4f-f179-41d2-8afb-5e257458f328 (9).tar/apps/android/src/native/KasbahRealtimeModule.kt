package com.kasbah.detector;

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.facebook.react.bridge.*
import com.facebook.react.modules.core.DeviceEventManagerModule

import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Kasbah Native Module for React Native
 * 
 * Provides 100% fidelity with browser extension for real-time detection.
 * This module bridges the JavaScript world to native Android accessibility.
 */
class KasbahRealtimeModule(context: ReactApplicationContext) : NativeReactContextBase(context) {

    companion object {
        const val NAME = "KasbahRealtime"
        
        // Same configuration as browser extension
        private const val MAX_SCANS_PER_MINUTE = 20
        private const val SCAN_DELAY_MIN_MS = 800L
        private const val SCAN_DELAY_MAX_MS = 3000L
        
        private const val API_URL = "http://localhost:3000/api/q"
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val handler = Handler(Looper.getMainLooper())
    private var stats = Stats()

    data class Stats(
        val scansToday: Int = 0,
        val deepfakesFound: Int = 1,
        val secretsBlocked: Int = 1
    )

    override fun getName(): String = NAME

    @ReactMethod
    fun isAccessibilityEnabled(promise: Promise) {
        val enabled = try {
            AccessibilityService.getEnabledAccessibilityServiceList(context)
                .any { it.contains("KasbahAccessibilityService") }
        } catch (e: Exception) {
            false
        }
        promise.resolve(enabled)
    }

    @ReactMethod
    fun openAccessibilitySettings(promise: Promise) {
        try {
            val intent = Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            promise.resolve(true)
        } catch (e: Exception) {
            promise.reject("Failed to open settings")
        }
    }

    @ReactMethod
    fun startDetection(promise: Promise) {
        // Detection is handled by AccessibilityService
        // This just ensures stats are tracked
        promise.resolve(true)
    }

    @ReactMethod
    fun stopDetection(promise: Promise) {
        promise.resolve(true)
    }

    @ReactMethod
    fun getStats(promise: Promise) {
        val map = Arguments.createMap()
        map.putInt("scansToday", stats.scansToday)
        map.putInt("deepfakesFound", stats.deepfakesFound)
        map.putInt("secretsBlocked", stats.secretsBlocked)
        promise.resolve(map)
    }

    @ReactMethod
    fun analyzeImage(imageBase64: String, promise: Promise) {
        Thread {
            try {
                val json = """
                    {
                        "platform": "android",
                        "base64": true
                    }
                """.trimIndent()
                
                val body = json.toRequestBody("application/json".toMediaType())
                val request = Request.Builder()
                    .url(API_URL)
                    .post(body)
                    .build()

                val response = client.newCall(request).execute()
                if (response.isSuccessful) {
                    val responseBody = response.body?.string()
                    val resultJson = JSONObject(responseBody ?: "{}")
                    
                    val detection = resultJson.optJSONObject("detection")
                    val result = detection?.getString("result") ?: "uncertain"
                    val confidence = detection?.optDouble("confidence") ?: 0.5
                    
                    handler.post {
                        stats = Stats(
                            stats.scansToday + 1,
                            if (result == "deepfake") stats.deepfakesFound + 1 else stats.deepfakesFound,
                            stats.secretsBlocked
                        )
                        
                        val map = Arguments.createMap()
                        map.putString("result", result)
                        map.putDouble("confidence", confidence)
                        promise.resolve(map)
                    }
                } else {
                    promise.reject("API error: ${response.code}")
                }
            } catch (e: Exception) {
                promise.reject(e.message ?: "Unknown error")
            }
        }
    }

    @ReactMethod
    fun scanForSecrets(text: String, promise: Promise) {
        // Same patterns as browser extension
        val patterns = listOf(
            "sk-proj-[a-zA-Z0-9]{32,}" to Regex(),
            "sk-[a-zA-Z0-9]{20}T3BlbkFJ[a-zA-Z0-9]{20}" to Regex(),
            "sk_live_[a-zA-Z0-9]{24,}" to Regex(),
            "AKIA[0-9A-Z]{16}" to Regex(),
            "ghp_[a-zA-Z0-9]{36}" to Regex(),
            "AIza[a-zA-Z0-9\\-_]{35}" to Regex(),
            "xoxb-[0-9]{10,13}-[0-9]{10,13}-[a-zA-Z0-9]{24}" to Regex()
        )
        
        val found = mutableListOf<String>()
        
        for (pattern in patterns) {
            if (pattern.containsMatchIn(text)) {
                found.add(pattern.pattern)
            }
        }
        
        val map = Arguments.createMap()
        map.putBoolean("hasSecret", found.isNotEmpty())
        map.putArray("patterns", Arguments.fromList(found))
        map.putString("risk", when {
            found.size > 2 -> "critical"
            found.size > 1 -> "high"
            found.isNotEmpty() -> "medium"
            else -> "none"
        })
        
        promise.resolve(map)
    }

    // Called by AccessibilityService when detection happens
    fun onDetectionResult(result: String, confidence: Double) {
        handler.post {
            stats = Stats(
                stats.scansToday + 1,
                if (result == "deepfake") stats.deepfakesFound + 1 else stats.deepfakesFound,
                stats.secretsBlocked
            )
            
            // Send event to JS
            context.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
                ?.emit("onDetection", Arguments.createMap().apply {
                    putString("result", result)
                    putDouble("confidence", confidence)
                })
        }
    }

    // Called when secret is blocked
    fun onSecretBlocked() {
        handler.post {
            stats = Stats(
                stats.scansToday,
                stats.deepfakesFound,
                stats.secretsBlocked + 1
            )
            
            context.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
                ?.emit("onSecretDetected", Arguments.createMap().apply {
                    putBoolean("hasSecret", true)
                })
        }
    }
}
