package com.kasbah.detector.accessibility;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Kasbah Accessibility Service
 * 
 * Provides real-time deepfake detection across all apps on Android.
 * Monitors screen content and detects media in social apps.
 * 
 * This is the MOAT - same real-time detection as browser extension and desktop.
 */
public class KasbahAccessibilityService extends AccessibilityService {

    private static final String TAG = "KasbahAccessibility";
    private static final String API_URL = "http://localhost:3000/api/q";
    
    // Rate limiting - same as extension
    private static final int MAX_SCANS_PER_MINUTE = 20;
    private static final long SCAN_DELAY_MIN_MS = 800;
    private static final long SCAN_DELAY_MAX_MS = 3000;
    
    // Stealth: Random session class
    private final String sessionClass = "mq-" + generateRandomSuffix();
    
    private final OkHttpClient client = new OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build();
    
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Set<String> scannedMedia = new HashSet<>();
    private int scanCount = 0;
    private long lastScanTime = 0;
    
    // Platform configurations - same as extension
    private static final String[] PLATFORM_PACKAGES = {
        "com.zhiliaoapp.musically",      // TikTok
        "com.instagram.android",          // Instagram
        "com.google.android.youtube",     // YouTube
        "com.twitter.android",            // Twitter
        "com.facebook.katana",           // Facebook
        "com.facebook.orca",             // Messenger
        "com.snapchat.android",          // Snapchat
        "com.reddit.frontpage",          // Reddit
        "com.linkedin.android",          // LinkedIn
    };

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "Kasbah Accessibility Service started");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;
        
        String packageName = event.getPackageName() != null ? 
            event.getPackageName().toString() : "";
        
        // Only process social media apps
        if (!isSocialMediaApp(packageName)) return;
        
        int eventType = event.getEventType();
        
        // Handle content changes and scrolling
        if (eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ||
            eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED ||
            eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            
            // Rate limiting
            if (!canScan()) return;
            
            // Scan for media
            scanForMedia();
        }
    }

    @Override
    public void onInterrupt() {
        Log.d(TAG, "Accessibility service interrupted");
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        
        AccessibilityServiceInfo info = new AccessibilityServiceInfo();
        info.eventTypes = AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED |
                         AccessibilityEvent.TYPE_VIEW_SCROLLED |
                         AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED;
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS |
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS |
                    AccessibilityServiceInfo.FLAG_REQUEST_TOUCH_EXPLORATION_MODE;
        info.notificationTimeout = 100;
        info.packageNames = PLATFORM_PACKAGES;
        
        setServiceInfo(info);
        
        Log.d(TAG, "Service connected with stealth configuration");
    }

    private boolean isSocialMediaApp(String packageName) {
        for (String pkg : PLATFORM_PACKAGES) {
            if (pkg.equals(packageName)) return true;
        }
        return false;
    }

    private boolean canScan() {
        long now = System.currentTimeMillis();
        if (now - lastScanTime < 60000 / MAX_SCANS_PER_MINUTE) {
            return false;
        }
        lastScanTime = now;
        scanCount++;
        return true;
    }

    private void scanForMedia() {
        AccessibilityNodeInfo rootNode = getRootInActiveWindow();
        if (rootNode == null) return;
        
        try {
            // Find image and video nodes
            findMediaNodes(rootNode);
        } finally {
            rootNode.recycle();
        }
    }

    private void findMediaNodes(AccessibilityNodeInfo node) {
        if (node == null) return;
        
        // Check for image content description or view ID
        String contentDesc = node.getContentDescription() != null ? 
            node.getContentDescription().toString() : "";
        String viewId = node.getViewIdResourceName() != null ? 
            node.getViewIdResourceName() : "";
        String className = node.getClassName() != null ? 
            node.getClassName().toString() : "";
        
        // Detect image/video containers
        boolean isMediaContainer = 
            className.contains("ImageView") ||
            className.contains("VideoView") ||
            viewId.contains("image") ||
            viewId.contains("video") ||
            viewId.contains("media") ||
            viewId.contains("content") ||
            contentDesc.contains("image") ||
            contentDesc.contains("video");
        
        if (isMediaContainer) {
            // Get unique identifier
            String mediaId = node.hashCode() + "_" + viewId;
            
            if (!scannedMedia.contains(mediaId)) {
                scannedMedia.add(mediaId);
                
                // Capture and analyze
                Rect bounds = new Rect();
                node.getBoundsInScreen(bounds);
                
                if (bounds.width() > 100 && bounds.height() > 100) {
                    analyzeRegion(bounds, mediaId);
                }
            }
        }
        
        // Recursively check children
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                findMediaNodes(child);
                child.recycle();
            }
        }
    }

    private void analyzeRegion(Rect bounds, String mediaId) {
        // Random delay for stealth (same as extension)
        long delay = SCAN_DELAY_MIN_MS + 
            (long) (Math.random() * (SCAN_DELAY_MAX_MS - SCAN_DELAY_MIN_MS));
        
        handler.postDelayed(() -> {
            // Take screenshot (requires SCREENSHOT capability in manifest)
            // For now, we'll analyze via content description
            
            // Show detection overlay
            showDetectionOverlay(bounds, "...");
            
            // Call detection API
            new Thread(() -> {
                try {
                    JSONObject payload = new JSONObject();
                    payload.put("platform", "android");
                    payload.put("bounds", bounds.toString());
                    payload.put("mediaId", mediaId);
                    
                    RequestBody body = RequestBody.create(
                        payload.toString(), 
                        MediaType.parse("application/json")
                    );
                    
                    Request request = new Request.Builder()
                        .url(API_URL)
                        .post(body)
                        .build();
                    
                    Response response = client.newCall(request).execute();
                    
                    if (response.isSuccessful() && response.body() != null) {
                        String responseBody = response.body().string();
                        JSONObject result = new JSONObject(responseBody);
                        
                        if (result.has("detection")) {
                            JSONObject detection = result.getJSONObject("detection");
                            String verdict = detection.getString("result");
                            double confidence = detection.getDouble("confidence");
                            
                            // Update overlay with result (stealth badges)
                            String badgeText = formatBadgeText(verdict, confidence);
                            handler.post(() -> updateDetectionOverlay(bounds, badgeText, verdict));
                        }
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Detection API error", e);
                }
            }).start();
            
        }, delay);
    }

    private String formatBadgeText(String verdict, double confidence) {
        int percentage = (int) (confidence * 100);
        
        // Stealth format - same as extension
        switch (verdict) {
            case "authentic":
                return percentage + "%";  // Shows as quality score
            case "deepfake":
                return "!" + percentage + "%";  // Subtle warning
            default:
                return "?";
        }
    }

    private void showDetectionOverlay(Rect bounds, String text) {
        Intent intent = new Intent(this, DetectionOverlayService.class);
        intent.putExtra("bounds", bounds);
        intent.putExtra("text", text);
        intent.putExtra("type", "loading");
        startService(intent);
    }

    private void updateDetectionOverlay(Rect bounds, String text, String type) {
        Intent intent = new Intent(this, DetectionOverlayService.class);
        intent.putExtra("bounds", bounds);
        intent.putExtra("text", text);
        intent.putExtra("type", type);
        startService(intent);
    }

    private String generateRandomSuffix() {
        String chars = "abcdefghijklmnopqrstuvwxyz";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 5; i++) {
            sb.append(chars.charAt((int) (Math.random() * chars.length())));
        }
        return sb.toString();
    }
}
