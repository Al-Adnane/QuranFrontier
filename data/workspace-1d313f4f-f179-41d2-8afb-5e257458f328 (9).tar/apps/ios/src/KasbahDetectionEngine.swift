import UIKit
import WebKit
import Vision
import CoreML

/// Kasbah Real-Time Detection Engine for iOS
/// Provides 100% fidelity with browser extension and Android
class KasbahDetectionEngine {
    
    // MARK: - Configuration (Same as all platforms)
    
    private let maxScansPerMinute = 20
    private let scanDelayMinMs: UInt64 = 800
    private let scanDelayMaxMs: UInt64 = 3000
    private let badgePrefix = "mq-"
    
    /// API Configuration - SELF-HOSTED: Change this to your server URL
    /// Set via Info.plist key "KasbahAPIURL" or environment variable
    private lazy var apiURL: URL = {
        if let customURL = Bundle.main.object(forInfoDictionaryKey: "KasbahAPIURL") as? String {
            return URL(string: customURL)!
        }
        // Default to local development server
        return URL(string: "http://localhost:3000/api/q")!
    }()
    
    // Stealth session class (randomized per session)
    private lazy var sessionClass: String = {
        let chars = "abcdefghijklmnopqrstuvwxyz"
        var suffix = ""
        for _ in 0..<5 {
            suffix += String(chars.randomElement()!)
        }
        return "\(badgePrefix)\(suffix)"
    }()
    
    // MARK: - Detection State
    
    private var scanCount = 0
    private var lastScanTime: Date?
    private var scannedMediaUrls = Set<String>()
    
    // MARK: - Secret Patterns (Same as other platforms)
    
    private let secretPatterns: [(name: String, pattern: NSRegularExpression, severity: String)] = {
        let patterns = [
            ("openai-api-key", "sk-[a-zA-Z0-9]{20}T3BlbkFJ[a-zA-Z0-9]{20}", "critical"),
            ("openai-project-key", "sk-proj-[a-zA-Z0-9]{32,}", "critical"),
            ("anthropic-key", "sk-ant-api03-[a-zA-Z0-9\\-]{80,}", "critical"),
            ("stripe-live-key", "sk_live_[a-zA-Z0-9]{24,}", "critical"),
            ("aws-access-key", "AKIA[0-9A-Z]{16}", "critical"),
            ("github-token", "ghp_[a-zA-Z0-9]{36}", "critical"),
            ("google-api-key", "AIza[a-zA-Z0-9\\-_]{35}", "critical"),
            ("slack-bot-token", "xoxb-[0-9]{10,13}-[0-9]{10,13}-[a-zA-Z0-9]{24}", "critical"),
            ("private-key", "-----BEGIN (RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----", "critical"),
        ]
        
        return patterns.compactMap { name, pattern, severity in
            guard let regex = try? NSRegularExpression(pattern: pattern) else { return nil }
            return (name, regex, severity)
        }
    }()
    
    // MARK: - Platform Detection
    
    private let platformConfigs: [String: (hosts: [String], selectors: [String])] = [
        "tiktok": (["tiktok.com", "www.tiktok.com"], ["video"]),
        "instagram": (["instagram.com", "www.instagram.com"], ["video"]),
        "youtube": (["youtube.com", "www.youtube.com", "youtu.be"], ["video", "#shorts-container video"]),
        "twitter": (["twitter.com", "x.com"], ["video"]),
        "facebook": (["facebook.com", "www.facebook.com"], ["video"]),
    ]
    
    // MARK: - Detection Methods
    
    /// Detect platform from URL
    func detectPlatform(from url: URL) -> String? {
        guard let host = url.host?.replacingOccurrences(of: "www.", with: "") else { return nil }
        
        for (platform, config) in platformConfigs {
            if config.hosts.contains(where: { host == $0 || host.hasSuffix(".\($0)") }) {
                return platform
            }
        }
        
        return nil
    }
    
    /// Get random scan delay (stealth - same as all platforms)
    func getRandomScanDelay() -> UInt64 {
        return scanDelayMinMs + UInt64.random(in: 0...(scanDelayMaxMs - scanDelayMinMs))
    }
    
    /// Format badge text (stealth - same as all platforms)
    func formatBadgeText(result: String, confidence: Double) -> String {
        let percentage = Int(confidence * 100)
        
        switch result {
        case "authentic":
            return "\(percentage)%"
        case "deepfake":
            return "!\(percentage)%"
        default:
            return "?"
        }
    }
    
    /// Scan text for secrets
    func scanForSecrets(text: String) -> [(name: String, severity: String, match: String)] {
        let range = NSRange(text.startIndex..., in: text)
        var findings: [(name: String, severity: String, match: String)] = []
        
        for (name, pattern, severity) in secretPatterns {
            let matches = pattern.matches(in: text, range: range)
            for match in matches {
                if let matchRange = Range(match.range, in: text) {
                    let matchText = String(text[matchRange].prefix(50))
                    findings.append((name, severity, matchText))
                }
            }
        }
        
        return findings
    }
    
    /// Check if text contains secrets
    func hasSecret(text: String) -> Bool {
        let range = NSRange(text.startIndex..., in: text)
        
        for (_, pattern, _) in secretPatterns {
            if pattern.firstMatch(in: text, range: range) != nil {
                return true
            }
        }
        
        return false
    }
    
    /// Can perform scan (rate limiting)
    func canScan() -> Bool {
        guard let lastScan = lastScanTime else { return true }
        
        let elapsed = Date().timeIntervalSince(lastScan)
        let minInterval = 60.0 / Double(maxScansPerMinute)
        
        return elapsed >= minInterval
    }
    
    /// Analyze media URL
    func analyzeMedia(url: URL, platform: String) async throws -> DetectionResult {
        // Rate limiting
        guard canScan() else {
            throw DetectionError.rateLimited
        }
        
        lastScanTime = Date()
        scanCount += 1
        
        // Stealth delay
        let delayMs = getRandomScanDelay()
        try await Task.sleep(nanoseconds: delayMs * 1_000_000)
        
        // Check if already scanned
        let urlKey = url.absoluteString
        if scannedMediaUrls.contains(urlKey) {
            throw DetectionError.alreadyScanned
        }
        scannedMediaUrls.insert(urlKey)
        
        // Call detection API
        var request = URLRequest(url: apiURL)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let body: [String: Any] = [
            "url": url.absoluteString,
            "platform": platform
        ]
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse,
              httpResponse.statusCode == 200 else {
            throw DetectionError.apiError
        }
        
        let json = try JSONSerialization.jsonObject(with: data) as? [String: Any]
        guard let detection = json?["detection"] as? [String: Any] else {
            throw DetectionError.invalidResponse
        }
        
        let result = detection["result"] as? String ?? "uncertain"
        let confidence = detection["confidence"] as? Double ?? 0.5
        
        return DetectionResult(
            result: result,
            confidence: confidence,
            badgeText: formatBadgeText(result: result, confidence: confidence),
            threatLevel: getThreatLevel(result: result, confidence: confidence)
        )
    }
    
    private func getThreatLevel(result: String, confidence: Double) -> String {
        if result == "deepfake" {
            if confidence > 0.85 { return "critical" }
            if confidence > 0.70 { return "high" }
            return "medium"
        }
        return "minimal"
    }
    
    /// Get content script for WebView injection (100% identical to other platforms)
    func getContentScript() -> String {
        return """
        (function() {
            'use strict';
            
            if (window.__KASBAH_REALTIME_ACTIVE) return;
            window.__KASBAH_REALTIME_ACTIVE = true;
            
            const SESSION_CLASS = '\(sessionClass)';
            const MAX_SCANS_PER_MINUTE = \(maxScansPerMinute);
            const SCAN_DELAY_MIN_MS = \(scanDelayMinMs);
            const SCAN_DELAY_MAX_MS = \(scanDelayMaxMs);
            
            // Platform detection
            const PLATFORMS = {
                tiktok: { host: 'tiktok.com', selector: 'video' },
                instagram: { host: 'instagram.com', selector: 'video' },
                youtube: { host: 'youtube.com', selector: 'video' },
                twitter: { host: ['twitter.com', 'x.com'], selector: 'video' },
                facebook: { host: 'facebook.com', selector: 'video' }
            };
            
            function getCurrentPlatform() {
                const host = window.location.hostname.replace('www.', '');
                for (const [name, config] of Object.entries(PLATFORMS)) {
                    const hosts = Array.isArray(config.host) ? config.host : [config.host];
                    if (hosts.some(h => host === h || host.endsWith('.' + h))) {
                        return { name, selector: config.selector };
                    }
                }
                return null;
            }
            
            const platform = getCurrentPlatform();
            if (!platform) return;
            
            const scannedMedia = new WeakSet();
            let lastScanTime = 0;
            
            function createBadge(element, status) {
                const existing = element.parentElement?.querySelector('.' + SESSION_CLASS);
                if (existing) existing.remove();
                
                const badge = document.createElement('div');
                badge.className = SESSION_CLASS;
                
                const colors = {
                    authentic: { bg: 'rgba(34, 197, 94, 0.9)', text: 'white' },
                    deepfake: { bg: 'rgba(239, 68, 68, 0.9)', text: 'white' },
                    uncertain: { bg: 'rgba(245, 158, 11, 0.9)', text: 'white' },
                    loading: { bg: 'rgba(107, 114, 128, 0.9)', text: 'white' }
                };
                
                const color = colors[status.type] || colors.loading;
                const positions = ['top: 8px; right: 8px;', 'top: 8px; left: 8px;', 'bottom: 8px; right: 8px;'];
                const pos = positions[Math.floor(Math.random() * positions.length)];
                
                badge.style.cssText = `
                    position: absolute; ${pos}
                    padding: 4px 8px; border-radius: 4px;
                    font-size: 11px; font-family: -apple-system, BlinkMacSystemFont, sans-serif;
                    font-weight: 500; background: \\${color.bg}; color: \\${color.text};
                    z-index: 2147483647; pointer-events: none; opacity: 0.95;
                `;
                
                badge.textContent = status.text;
                
                if (element.parentElement) {
                    const parent = element.parentElement;
                    if (getComputedStyle(parent).position === 'static') parent.style.position = 'relative';
                    parent.appendChild(badge);
                }
                
                return badge;
            }
            
            async function scanMedia(element) {
                const now = Date.now();
                if (now - lastScanTime < 60000 / MAX_SCANS_PER_MINUTE) return;
                lastScanTime = now;
                
                if (scannedMedia.has(element)) return;
                scannedMedia.add(element);
                
                const badge = createBadge(element, { type: 'loading', text: '...' });
                
                try {
                    const mediaUrl = element.src || element.currentSrc || element.poster;
                    if (!mediaUrl) { badge.remove(); return; }
                    
                    const delay = SCAN_DELAY_MIN_MS + Math.random() * (SCAN_DELAY_MAX_MS - SCAN_DELAY_MIN_MS);
                    await new Promise(r => setTimeout(r, delay));
                    
                    // Bridge to native iOS
                    window.webkit?.messageHandlers?.kasbah?.postMessage({
                        type: 'SCAN_MEDIA',
                        url: mediaUrl,
                        platform: platform.name
                    });
                    
                } catch (e) { badge.remove(); }
            }
            
            // MutationObserver
            const observer = new MutationObserver((mutations) => {
                for (const mutation of mutations) {
                    if (mutation.type !== 'childList') continue;
                    for (const node of mutation.addedNodes) {
                        if (!(node instanceof HTMLElement)) continue;
                        const videos = node.matches(platform.selector) ? [node] : Array.from(node.querySelectorAll(platform.selector));
                        for (const video of videos) {
                            if (video.tagName === 'VIDEO') scanMedia(video);
                        }
                    }
                }
            });
            
            observer.observe(document.body, { childList: true, subtree: true });
            
            // IntersectionObserver
            const visibilityObserver = new IntersectionObserver((entries) => {
                for (const entry of entries) {
                    if (entry.isIntersecting && entry.intersectionRatio > 0.5) {
                        scanMedia(entry.target);
                    }
                }
            }, { threshold: [0.5], rootMargin: '100px' });
            
            setTimeout(() => {
                document.querySelectorAll(platform.selector).forEach(v => visibilityObserver.observe(v));
            }, 1000);
            
            // Listen for results from native
            window.addEventListener('kasbahResult', (event) => {
                const data = event.detail;
                document.querySelectorAll('video').forEach(video => {
                    const text = data.result === 'authentic' ? data.confidence + '%' :
                                data.result === 'deepfake' ? '!' + data.confidence + '%' : '?';
                    createBadge(video, { type: data.result, text });
                });
            });
            
            console.log('[Kasbah] Real-time detection active on', platform.name);
        })();
        """
    }
}

// MARK: - Supporting Types

struct DetectionResult {
    let result: String
    let confidence: Double
    let badgeText: String
    let threatLevel: String
}

enum DetectionError: Error {
    case rateLimited
    case alreadyScanned
    case apiError
    case invalidResponse
}

// MARK: - Badge View

class KasbahBadgeView: UIView {
    private let label = UILabel()
    
    init(text: String, type: String) {
        super.init(frame: .zero)
        
        // Apply stealth styling (same as other platforms)
        let bgColor: UIColor
        switch type {
        case "authentic":
            bgColor = UIColor(red: 34/255, green: 197/255, blue: 94/255, alpha: 0.9)
        case "deepfake":
            bgColor = UIColor(red: 239/255, green: 68/255, blue: 68/255, alpha: 0.9)
        case "uncertain":
            bgColor = UIColor(red: 245/255, green: 158/255, blue: 11/255, alpha: 0.9)
        default:
            bgColor = UIColor(white: 107/255, alpha: 0.9)
        }
        
        backgroundColor = bgColor
        layer.cornerRadius = 4
        
        label.text = text
        label.font = .systemFont(ofSize: 11, weight: .medium)
        label.textColor = .white
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        
        addSubview(label)
        
        NSLayoutConstraint.activate([
            label.topAnchor.constraint(equalTo: topAnchor, constant: 4),
            label.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -4),
            label.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 8),
            label.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -8),
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func update(text: String, type: String) {
        label.text = text
        
        let bgColor: UIColor
        switch type {
        case "authentic":
            bgColor = UIColor(red: 34/255, green: 197/255, blue: 94/255, alpha: 0.9)
        case "deepfake":
            bgColor = UIColor(red: 239/255, green: 68/255, blue: 68/255, alpha: 0.9)
        case "uncertain":
            bgColor = UIColor(red: 245/255, green: 158/255, blue: 11/255, alpha: 0.9)
        default:
            bgColor = UIColor(white: 107/255, alpha: 0.9)
        }
        
        backgroundColor = bgColor
    }
}
