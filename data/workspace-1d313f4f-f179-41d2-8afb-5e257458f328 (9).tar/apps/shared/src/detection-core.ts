/**
 * Kasbah Shared Detection Core
 * 
 * 100% identical behavior across ALL platforms
 * - Browser Extension
 * - Desktop (Tauri)
 * - Android
 * - iOS
 * 
 * This is the MOAT - single source of truth for detection
 * 
 * SELF-HOSTED: Set window.__KASBAH_API_URL to your server URL
 * ENTERPRISE: All external calls removed - uses your infrastructure only
 */

// TypeScript declarations for custom window properties
declare global {
  interface Window {
    __KASBAH_API_URL?: string;
    __KASBAH_SCAN_MEDIA?: (url: string, platform: string) => Promise<Response>;
    __KASBAH_REALTIME_ACTIVE?: boolean;
  }
}

// ============================================
// PLATFORM CONFIGURATION - Same everywhere
// ============================================

export const PLATFORM_CONFIG = {
  // Rate limiting
  maxScansPerMinute: 20,
  
  // Delays for stealth (mimic human behavior)
  scanDelayMinMs: 800,
  scanDelayMaxMs: 3000,
  
  // Stealth mode settings
  badgePrefix: 'mq-',
  stealthMode: true,
  
  // Badge styles - identical across platforms
  badgeStyles: {
    authentic: {
      background: 'rgba(34, 197, 94, 0.9)',
      text: 'white',
      format: (confidence: number) => `${Math.round(confidence * 100)}%`,
    },
    deepfake: {
      background: 'rgba(239, 68, 68, 0.9)',
      text: 'white',
      format: (confidence: number) => `!${Math.round(confidence * 100)}%`,
    },
    uncertain: {
      background: 'rgba(245, 158, 11, 0.9)',
      text: 'white',
      format: () => '?',
    },
    loading: {
      background: 'rgba(107, 114, 128, 0.9)',
      text: 'white',
      format: () => '...',
    },
  },
  
  // Supported platforms
  platforms: {
    tiktok: {
      name: 'TikTok',
      hosts: ['tiktok.com', 'www.tiktok.com'],
      selectors: ['[data-e2e="recommend-list-item-container"] video', 'video'],
    },
    instagram: {
      name: 'Instagram',
      hosts: ['instagram.com', 'www.instagram.com'],
      selectors: ['article video', 'video'],
    },
    youtube: {
      name: 'YouTube',
      hosts: ['youtube.com', 'www.youtube.com', 'youtu.be'],
      selectors: ['ytd-player video', '#shorts-container video', 'video'],
    },
    twitter: {
      name: 'Twitter/X',
      hosts: ['twitter.com', 'x.com', 'www.twitter.com', 'www.x.com'],
      selectors: ['[data-testid="videoPlayer"] video', 'video'],
    },
    facebook: {
      name: 'Facebook',
      hosts: ['facebook.com', 'www.facebook.com', 'm.facebook.com'],
      selectors: ['[data-pagelet="FeedUnit"] video', 'video'],
    },
    linkedin: {
      name: 'LinkedIn',
      hosts: ['linkedin.com', 'www.linkedin.com'],
      selectors: ['.feed-shared-video__container video', '.video-js video', 'video'],
    },
  },
} as const;

// ============================================
// SECRET PATTERNS - Same everywhere
// ============================================

export const SECRET_PATTERNS = [
  // OpenAI
  { name: 'openai-api-key', pattern: /sk-[a-zA-Z0-9]{20}T3BlbkFJ[a-zA-Z0-9]{20}/g, severity: 'critical' },
  { name: 'openai-project-key', pattern: /sk-proj-[a-zA-Z0-9]{32,}/g, severity: 'critical' },
  { name: 'openai-service-key', pattern: /sk-svcacct-[a-zA-Z0-9]{32,}/g, severity: 'critical' },
  
  // Anthropic
  { name: 'anthropic-key', pattern: /sk-ant-api03-[a-zA-Z0-9\-]{80,}/g, severity: 'critical' },
  
  // Stripe
  { name: 'stripe-live-key', pattern: /sk_live_[a-zA-Z0-9]{24,}/g, severity: 'critical' },
  { name: 'stripe-test-key', pattern: /sk_test_[a-zA-Z0-9]{24,}/g, severity: 'high' },
  { name: 'stripe-restricted-key', pattern: /rk_live_[a-zA-Z0-9]{24,}/g, severity: 'critical' },
  
  // AWS
  { name: 'aws-access-key', pattern: /AKIA[0-9A-Z]{16}/g, severity: 'critical' },
  { name: 'aws-secret-key', pattern: /aws(.{0,20})?['\"][0-9a-zA-Z\/+=]{40}['\"]/gi, severity: 'critical' },
  
  // GitHub
  { name: 'github-token', pattern: /ghp_[a-zA-Z0-9]{36}/g, severity: 'critical' },
  { name: 'github-oauth', pattern: /gho_[a-zA-Z0-9]{36}/g, severity: 'critical' },
  { name: 'github-user-token', pattern: /ghu_[a-zA-Z0-9]{36}/g, severity: 'critical' },
  { name: 'github-server-token', pattern: /ghs_[a-zA-Z0-9]{36}/g, severity: 'critical' },
  
  // Google
  { name: 'google-api-key', pattern: /AIza[a-zA-Z0-9\-_]{35}/g, severity: 'critical' },
  
  // Slack
  { name: 'slack-bot-token', pattern: /xoxb-[0-9]{10,13}-[0-9]{10,13}-[a-zA-Z0-9]{24}/g, severity: 'critical' },
  { name: 'slack-user-token', pattern: /xoxp-[0-9]{10,13}-[0-9]{10,13}-[0-9]{10,13}-[a-f0-9]{32}/g, severity: 'critical' },
  
  // Private Keys
  { name: 'rsa-private-key', pattern: /-----BEGIN (RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----/g, severity: 'critical' },
  { name: 'pgp-private-key', pattern: /-----BEGIN PGP PRIVATE KEY BLOCK-----/g, severity: 'critical' },
  
  // Database URLs
  { name: 'postgres-url', pattern: /postgres(ql)?:\/\/[^:]+:[^@]+@[a-zA-Z0-9.\-]+/gi, severity: 'critical' },
  { name: 'mongodb-url', pattern: /mongodb(\+srv)?:\/\/[^:]+:[^@]+@[a-zA-Z0-9.\-]+/gi, severity: 'critical' },
  { name: 'mysql-url', pattern: /mysql:\/\/[^:]+:[^@]+@[a-zA-Z0-9.\-]+/gi, severity: 'critical' },
  { name: 'redis-url', pattern: /redis:\/\/[^:]*:[^@]+@[a-zA-Z0-9.\-]+/gi, severity: 'critical' },
] as const;

// ============================================
// OBFUSCATION DETECTION - Same everywhere
// ============================================

export const OBFUSCATION_PATTERNS = {
  // Base64 detection
  base64: /[A-Za-z0-9+\/_=]{40,}/g,
  
  // URL encoding
  urlEncoded: /(?:%[0-9a-fA-F]{2}){10,}/g,
  
  // Unicode escapes
  unicodeEscape: /(?:\\u[0-9a-fA-F]{4}){5,}/g,
  
  // Hex escapes
  hexEscape: /(?:\\x[0-9a-fA-F]{2}){5,}/g,
  
  // Zero-width characters
  zeroWidth: /[\u200B-\u200D\uFEFF\u00AD]/g,
  
  // HTML entities
  htmlEntity: /(?:&(?:#x?[0-9a-fA-F]+|[a-zA-Z]+);){5,}/g,
};

// ============================================
// DETECTION FUNCTIONS - Same everywhere
// ============================================

/**
 * Detect platform from URL
 */
export function detectPlatform(url: string): string | null {
  try {
    const hostname = new URL(url).hostname.replace('www.', '');
    
    for (const [id, config] of Object.entries(PLATFORM_CONFIG.platforms)) {
      if (config.hosts.some(h => hostname === h || hostname.endsWith('.' + h))) {
        return id;
      }
    }
  } catch {}
  
  return null;
}

/**
 * Generate stealth session class
 */
export function generateSessionClass(): string {
  const chars = 'abcdefghijklmnopqrstuvwxyz';
  let suffix = '';
  for (let i = 0; i < 5; i++) {
    suffix += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `${PLATFORM_CONFIG.badgePrefix}${suffix}`;
}

/**
 * Get random scan delay (stealth)
 */
export function getRandomScanDelay(): number {
  const { scanDelayMinMs, scanDelayMaxMs } = PLATFORM_CONFIG;
  return scanDelayMinMs + Math.random() * (scanDelayMaxMs - scanDelayMinMs);
}

/**
 * Format badge text (stealth)
 */
export function formatBadgeText(result: string, confidence: number): string {
  const style = PLATFORM_CONFIG.badgeStyles[result as keyof typeof PLATFORM_CONFIG.badgeStyles];
  return style ? style.format(confidence) : '?';
}

/**
 * Scan text for secrets
 */
export function scanForSecrets(text: string): Array<{
  name: string;
  severity: string;
  match: string;
}> {
  const findings: Array<{ name: string; severity: string; match: string }> = [];
  
  for (const { name, pattern, severity } of SECRET_PATTERNS) {
    // Reset lastIndex for global regex
    pattern.lastIndex = 0;
    
    const matches = text.matchAll(pattern);
    for (const match of matches) {
      findings.push({
        name,
        severity,
        match: match[0].slice(0, 50),
      });
    }
  }
  
  return findings;
}

/**
 * Check if text contains secrets
 */
export function hasSecret(text: string): boolean {
  for (const { pattern } of SECRET_PATTERNS) {
    pattern.lastIndex = 0;
    if (pattern.test(text)) {
      return true;
    }
  }
  return false;
}

/**
 * Redact secrets from text
 */
export function redactSecrets(text: string): string {
  let result = text;
  
  for (const { name, pattern } of SECRET_PATTERNS) {
    pattern.lastIndex = 0;
    result = result.replace(pattern, `[${name.toUpperCase()}_REDACTED]`);
  }
  
  return result;
}

/**
 * Decode obfuscation layers
 */
export function decodeObfuscation(text: string): string[] {
  const layers: string[] = [text];
  
  // Base64
  try {
    const decoded = atob(text.replace(/\s/g, ''));
    if (decoded !== text) layers.push(decoded);
  } catch {}
  
  // URL encoding
  try {
    const decoded = decodeURIComponent(text);
    if (decoded !== text) layers.push(decoded);
  } catch {}
  
  // Remove zero-width
  const noZeroWidth = text.replace(OBFUSCATION_PATTERNS.zeroWidth, '');
  if (noZeroWidth !== text) layers.push(noZeroWidth);
  
  // Unicode escapes
  const unicodeDecoded = text.replace(/\\u([0-9a-fA-F]{4})/g, (_, code) => 
    String.fromCharCode(parseInt(code, 16))
  );
  if (unicodeDecoded !== text) layers.push(unicodeDecoded);
  
  return layers;
}

/**
 * Deep scan for secrets (handles obfuscation)
 */
export function deepScanForSecrets(text: string): Array<{
  name: string;
  severity: string;
  match: string;
  layer: string;
}> {
  const findings: Array<{ name: string; severity: string; match: string; layer: string }> = [];
  const layers = decodeObfuscation(text);
  
  for (let i = 0; i < layers.length; i++) {
    const layerFindings = scanForSecrets(layers[i]);
    for (const finding of layerFindings) {
      findings.push({
        ...finding,
        layer: i === 0 ? 'original' : `decoded_${i}`,
      });
    }
  }
  
  // Deduplicate
  const seen = new Set<string>();
  return findings.filter(f => {
    const key = `${f.name}:${f.match}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

// ============================================
// CONTENT SCRIPT - Same everywhere
// ============================================

export const CONTENT_SCRIPT = `
(function() {
  'use strict';
  
  if (window.__KASBAH_REALTIME_ACTIVE) return;
  window.__KASBAH_REALTIME_ACTIVE = true;
  
  // Configuration from shared core
  const MAX_SCANS_PER_MINUTE = ${PLATFORM_CONFIG.maxScansPerMinute};
  const SCAN_DELAY_MIN_MS = ${PLATFORM_CONFIG.scanDelayMinMs};
  const SCAN_DELAY_MAX_MS = ${PLATFORM_CONFIG.scanDelayMaxMs};
  
  // Stealth session class
  const SESSION_CLASS = '${PLATFORM_CONFIG.badgePrefix}' + Math.random().toString(36).slice(2, 7);
  
  // Platform detection
  const PLATFORMS = ${JSON.stringify(PLATFORM_CONFIG.platforms)};
  
  function getCurrentPlatform() {
    const host = window.location.hostname.replace('www.', '');
    for (const [name, config] of Object.entries(PLATFORMS)) {
      if (config.hosts.some(h => host === h || host.endsWith('.' + h))) {
        return { name, selectors: config.selectors };
      }
    }
    return null;
  }
  
  const platform = getCurrentPlatform();
  if (!platform) return;
  
  const scannedMedia = new WeakSet();
  let lastScanTime = 0;
  
  // Badge creation - IDENTICAL across platforms
  function createBadge(element, status) {
    const existing = element.parentElement?.querySelector('.' + SESSION_CLASS);
    if (existing) existing.remove();
    
    const badge = document.createElement('div');
    badge.className = SESSION_CLASS;
    
    const styles = ${JSON.stringify(PLATFORM_CONFIG.badgeStyles)};
    const style = styles[status.type] || styles.loading;
    
    const positions = ['top: 8px; right: 8px;', 'top: 8px; left: 8px;', 'bottom: 8px; right: 8px;'];
    const pos = positions[Math.floor(Math.random() * positions.length)];
    
    badge.style.cssText = \`
      position: absolute;
      \${pos}
      padding: 4px 8px;
      border-radius: 4px;
      font-size: 11px;
      font-family: -apple-system, BlinkMacSystemFont, sans-serif;
      font-weight: 500;
      background: \${style.background};
      color: \${style.text};
      z-index: 2147483647;
      pointer-events: none;
      opacity: 0.95;
    \`;
    
    badge.textContent = status.text;
    
    if (element.parentElement) {
      const parent = element.parentElement;
      if (getComputedStyle(parent).position === 'static') {
        parent.style.position = 'relative';
      }
      parent.appendChild(badge);
    }
    
    return badge;
  }
  
  async function scanMedia(element) {
    const now = Date.now();
    if (now - lastScanTime < 60000 / MAX_SCANS_PER_MINUTE) return;
    lastScanTime = now;
    
    if (scannedMedia.has(element)) return;
    scannedMedia.add(element);
    
    const badge = createBadge(element, { type: 'loading', text: '...' });
    
    try {
      const mediaUrl = element.src || element.currentSrc || element.poster;
      if (!mediaUrl) {
        badge.remove();
        return;
      }
      
      // Random delay for stealth
      const delay = SCAN_DELAY_MIN_MS + Math.random() * (SCAN_DELAY_MAX_MS - SCAN_DELAY_MIN_MS);
      await new Promise(r => setTimeout(r, delay));
      
      // Send for analysis (platform-specific)
      // Uses configurable API endpoint - defaults to local for self-hosted deployments
      const API_URL = window.__KASBAH_API_URL || 'http://localhost:3000/api/q';
      
      (window.__KASBAH_SCAN_MEDIA?.(mediaUrl, platform.name) ||
      fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: mediaUrl, platform: platform.name })
      })).then(r => r.json()).then(data => {
        if (data.detection) {
          const c = Math.round(data.detection.confidence * 100);
          const text = data.detection.result === 'authentic' ? c + '%' :
                       data.detection.result === 'deepfake' ? '!' + c + '%' : '?';
          createBadge(element, { type: data.detection.result, text });
        }
      });
    } catch (e) {
      badge.remove();
    }
  }
  
  // MutationObserver
  const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== 'childList') continue;
      for (const node of mutation.addedNodes) {
        if (!(node instanceof HTMLElement)) continue;
        const videos = node.matches(platform.selectors.join(',')) ? 
          [node] : Array.from(node.querySelectorAll(platform.selectors.join(',')));
        for (const video of videos) {
          if (video.tagName === 'VIDEO') scanMedia(video);
        }
      }
    }
  });
  
  observer.observe(document.body, { childList: true, subtree: true });
  
  // IntersectionObserver
  const visibilityObserver = new IntersectionObserver((entries) => {
    for (const entry of entries) {
      if (entry.isIntersecting && entry.intersectionRatio > 0.5) {
        scanMedia(entry.target);
      }
    }
  }, { threshold: [0.5], rootMargin: '100px' });
  
  setTimeout(() => {
    document.querySelectorAll(platform.selectors.join(',')).forEach(v => visibilityObserver.observe(v));
  }, 1000);
  
  console.log('[Kasbah] Real-time detection active on', platform.name);
})();
`;

// Export for all platforms
export default {
  PLATFORM_CONFIG,
  SECRET_PATTERNS,
  OBFUSCATION_PATTERNS,
  CONTENT_SCRIPT,
  detectPlatform,
  generateSessionClass,
  getRandomScanDelay,
  formatBadgeText,
  scanForSecrets,
  hasSecret,
  redactSecrets,
  decodeObfuscation,
  deepScanForSecrets,
};
