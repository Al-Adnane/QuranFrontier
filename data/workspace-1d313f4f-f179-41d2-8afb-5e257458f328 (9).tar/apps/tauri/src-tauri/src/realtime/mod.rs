//! Real-Time Detection Module
//! 
//! Core detection engine shared across all platforms
//! Provides 100% fidelity between web, desktop, and mobile

pub mod browser;

use serde::{Deserialize, Serialize};
use regex::Regex;

lazy_static::lazy_static! {
    // Detection patterns - identical to browser extension
    static ref CRITICAL_PATTERNS: Vec<SecretPattern> = vec![
        SecretPattern::new("openai-api-key", r"sk-[a-zA-Z0-9]{20}T3BlbkFJ[a-zA-Z0-9]{20}", "critical"),
        SecretPattern::new("openai-project-key", r"sk-proj-[a-zA-Z0-9]{32,}", "critical"),
        SecretPattern::new("anthropic-key", r"sk-ant-api03-[a-zA-Z0-9\-]{80,}", "critical"),
        SecretPattern::new("stripe-live", r"sk_live_[a-zA-Z0-9]{24,}", "critical"),
        SecretPattern::new("stripe-test", r"sk_test_[a-zA-Z0-9]{24,}", "high"),
        SecretPattern::new("aws-key", r"AKIA[0-9A-Z]{16}", "critical"),
        SecretPattern::new("github-token", r"ghp_[a-zA-Z0-9]{36}", "critical"),
        SecretPattern::new("google-api-key", r"AIza[a-zA-Z0-9\-_]{35}", "critical"),
        SecretPattern::new("slack-bot-token", r"xoxb-[0-9]{10,13}-[0-9]{10,13}-[a-zA-Z0-9]{24}", "critical"),
        SecretPattern::new("private-key", r"-----BEGIN (RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----", "critical"),
    ];
}

#[derive(Debug, Clone)]
struct SecretPattern {
    name: &'static str,
    regex: Regex,
    severity: &'static str,
}

impl SecretPattern {
    fn new(name: &'static str, pattern: &str, severity: &'static str) -> Self {
        Self {
            name,
            regex: Regex::new(pattern).unwrap(),
            severity,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RealtimeDetectionResult {
    pub media_url: String,
    pub platform: String,
    pub result: DetectionVerdict,
    pub confidence: f32,
    pub badge_text: String,
    pub badge_style: BadgeStyle,
    pub timestamp: i64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum DetectionVerdict {
    Authentic,
    Deepfake,
    Uncertain,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BadgeStyle {
    pub background: String,
    pub text_color: String,
}

/// Content script for injection - IDENTICAL across all platforms
pub const CONTENT_SCRIPT: &str = r#"
(function() {
    'use strict';
    
    if (window.__KASBAH_REALTIME_ACTIVE) return;
    window.__KASBAH_REALTIME_ACTIVE = true;
    
    // Stealth: Random session class
    const SESSION_CLASS = 'mq-' + Math.random().toString(36).slice(2, 7);
    
    // Platform configurations - same as browser extension
    const PLATFORMS = {
        tiktok: { host: 'tiktok.com', selector: '[data-e2e="recommend-list-item-container"] video, video' },
        instagram: { host: 'instagram.com', selector: 'article video, video' },
        youtube: { host: 'youtube.com', selector: 'ytd-player video, #shorts-container video, video' },
        twitter: { host: ['twitter.com', 'x.com'], selector: '[data-testid="videoPlayer"] video, video' },
        facebook: { host: 'facebook.com', selector: '[data-pagelet="FeedUnit"] video, video' }
    };
    
    function getCurrentPlatform() {
        const host = window.location.hostname.replace('www.', '');
        for (const [name, config] of Object.entries(PLATFORMS)) {
            const hosts = Array.isArray(config.host) ? config.host : [config.host];
            if (hosts.some(h => host === h || host.endsWith('.' + h))) {
                return { name, ...config };
            }
        }
        return null;
    }
    
    const platform = getCurrentPlatform();
    if (!platform) return;
    
    const scannedMedia = new WeakSet();
    let scanCount = 0;
    let lastScanTime = 0;
    const MAX_SCANS_PER_MINUTE = 20;
    
    // Stealth badge creation - same styling as extension
    function createBadge(element, status) {
        const existing = element.parentElement?.querySelector('.' + SESSION_CLASS);
        if (existing) existing.remove();
        
        const badge = document.createElement('div');
        badge.className = SESSION_CLASS;
        
        const colors = {
            authentic: { bg: 'rgba(34, 197, 94, 0.9)', text: 'white' },
            deepfake: { bg: 'rgba(239, 68, 68, 0.9)', text: 'white' },
            uncertain: { bg: 'rgba(245, 158, 11, 0.9)', text: 'white' },
            loading: { bg: 'rgba(107, 114, 128, 0.9)', text: 'white' }
        };
        
        const color = colors[status.type] || colors.loading;
        
        // Randomize position for stealth
        const positions = ['top: 8px; right: 8px;', 'top: 8px; left: 8px;', 'bottom: 8px; right: 8px;'];
        const pos = positions[Math.floor(Math.random() * positions.length)];
        
        badge.style.cssText = `
            position: absolute;
            ${pos}
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 11px;
            font-family: -apple-system, BlinkMacSystemFont, sans-serif;
            font-weight: 500;
            background: ${color.bg};
            color: ${color.text};
            z-index: 2147483647;
            pointer-events: none;
        `;
        
        // Stealth text - quality score, not "DEEPFAKE"
        badge.textContent = status.text;
        
        if (element.parentElement) {
            const parent = element.parentElement;
            if (getComputedStyle(parent).position === 'static') {
                parent.style.position = 'relative';
            }
            parent.appendChild(badge);
        }
        
        return badge;
    }
    
    async function scanMedia(element) {
        const now = Date.now();
        if (now - lastScanTime < 60000 / MAX_SCANS_PER_MINUTE) return;
        lastScanTime = now;
        scanCount++;
        
        if (scannedMedia.has(element)) return;
        scannedMedia.add(element);
        
        const badge = createBadge(element, { type: 'loading', text: '...' });
        
        try {
            const mediaUrl = element.src || element.currentSrc || element.poster;
            if (!mediaUrl) {
                badge.remove();
                return;
            }
            
            // Random delay (800-3000ms) for stealth
            const delay = 800 + Math.random() * 2200;
            await new Promise(r => setTimeout(r, delay));
            
            // Call detection API
            const response = await fetch('http://localhost:3000/api/q', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ url: mediaUrl, platform: platform.name })
            });
            
            if (!response.ok) {
                createBadge(element, { type: 'uncertain', text: '?' });
                return;
            }
            
            const data = await response.json();
            
            if (data.detection) {
                const confidence = Math.round(data.detection.confidence * 100);
                // Stealth badges: 87% = authentic, !62% = suspicious
                const text = data.detection.result === 'authentic' ? 
                    `${confidence}%` : 
                    data.detection.result === 'deepfake' ? 
                    `!${confidence}%` : '?';
                    
                createBadge(element, { type: data.detection.result, text });
            }
        } catch (error) {
            badge.remove();
        }
    }
    
    // MutationObserver for dynamic content
    const observer = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
            if (mutation.type !== 'childList') continue;
            
            for (const node of mutation.addedNodes) {
                if (!(node instanceof HTMLElement)) continue;
                
                const videos = node.matches(platform.selector) ? 
                    [node] : 
                    Array.from(node.querySelectorAll(platform.selector));
                
                for (const video of videos) {
                    if (video.tagName === 'VIDEO') {
                        scanMedia(video);
                    }
                }
            }
        }
    });
    
    observer.observe(document.body, { childList: true, subtree: true });
    
    // IntersectionObserver for visibility
    const visibilityObserver = new IntersectionObserver((entries) => {
        for (const entry of entries) {
            if (entry.isIntersecting && entry.intersectionRatio > 0.5) {
                scanMedia(entry.target);
            }
        }
    }, { threshold: [0.5], rootMargin: '100px' });
    
    // Initial scan
    setTimeout(() => {
        document.querySelectorAll(platform.selector).forEach(video => {
            visibilityObserver.observe(video);
        });
    }, 1000);
    
    // WebSocket protection
    const OriginalWebSocket = window.WebSocket;
    window.WebSocket = class extends OriginalWebSocket {
        constructor(url, protocols) {
            super(url, protocols);
            this.addEventListener('message', (event) => {
                // Scan WebSocket messages for secrets
                if (typeof event.data === 'string') {
                    // Secret patterns check
                    const patterns = [
                        /sk-proj-[a-zA-Z0-9]{32,}/g,
                        /sk_live_[a-zA-Z0-9]{24,}/g,
                        /ghp_[a-zA-Z0-9]{36}/g,
                    ];
                    for (const p of patterns) {
                        if (p.test(event.data)) {
                            event.stopImmediatePropagation();
                            console.warn('[Kasbah] Blocked secret in WebSocket');
                        }
                    }
                }
            });
        }
        
        send(data) {
            // Check outgoing data
            const patterns = [/sk-proj-[a-zA-Z0-9]{32,}/g, /ghp_[a-zA-Z0-9]{36}/g];
            for (const p of patterns) {
                if (typeof data === 'string' && p.test(data)) {
                    console.warn('[Kasbah] Blocked secret in WebSocket.send()');
                    return;
                }
            }
            super.send(data);
        }
    };
    
    console.log('[Kasbah] Real-time detection active on', platform.name);
})();
"#;

/// Scan text for secrets
pub fn scan_for_secrets(text: &str) -> Vec<SecretFinding> {
    let mut findings = Vec::new();
    
    for pattern in CRITICAL_PATTERNS.iter() {
        for cap in pattern.regex.find_iter(text) {
            findings.push(SecretFinding {
                pattern_name: pattern.name.to_string(),
                severity: pattern.severity.to_string(),
                match_text: cap.as_str().chars().take(50).collect(),
            });
        }
    }
    
    findings
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SecretFinding {
    pub pattern_name: String,
    pub severity: String,
    pub match_text: String,
}
