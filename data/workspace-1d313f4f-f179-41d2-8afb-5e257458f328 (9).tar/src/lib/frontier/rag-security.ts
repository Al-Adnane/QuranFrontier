/**
 * RAG Security - Secure retrieval-augmented generation
 * @module frontier/rag-security
 */
export type AccessLevel = 'public' | 'internal' | 'restricted' | 'confidential';

export interface DocumentRecord {
  id: string; title: string; content: string; source: string;
  classification: AccessLevel; embedding?: number[];
  sanitized: boolean; checksum: string;
  createdAt: number;
}

export interface RetrievalQuery {
  id: string; query: string; agentId: string;
  results: RetrievalResult[]; sanitized: boolean;
  timestamp: number;
}

export interface RetrievalResult {
  documentId: string; relevance: number;
  snippet: string; accessGranted: boolean;
}

export interface AccessPolicy {
  id: string; agentId: string; documentPattern: string;
  accessLevel: AccessLevel[]; grantedBy: string;
  createdAt: number;
}

const documents = new Map<string, DocumentRecord>();
const queries = new Map<string, RetrievalQuery>();
const policies = new Map<string, AccessPolicy>();

export function ingestDocument(config: {title: string; content: string; source: string; classification?: AccessLevel}): DocumentRecord {
  const sanitized = sanitizeContent(config.content);
  const doc: DocumentRecord = {
    id: `doc_${Date.now()}_${Math.random().toString(36).substr(2,6)}`,
    title: config.title, content: sanitized, source: config.source,
    classification: config.classification || 'internal',
    sanitized: true, checksum: generateChecksum(sanitized),
    createdAt: Date.now()
  };
  documents.set(doc.id, doc);
  return doc;
}

export function sanitizeContent(content: string): string {
  return content
    .replace(/<script[^>]*>.*?<\/script>/gis, '')
    .replace(/javascript:/gi, '')
    .replace(/on\w+\s*=/gi, '')
    .replace(/\b(password|api.key|secret|token)\s*[:=]\s*\S+/gi, '[REDACTED]');
}

export function grantAccess(agentId: string, documentPattern: string, accessLevels: AccessLevel[], grantedBy: string): AccessPolicy {
  const policy: AccessPolicy = {
    id: `policy_${Date.now()}`, agentId, documentPattern,
    accessLevel: accessLevels, grantedBy, createdAt: Date.now()
  };
  policies.set(policy.id, policy);
  return policy;
}

export function checkAccess(agentId: string, document: DocumentRecord): boolean {
  const agentPolicies = Array.from(policies.values()).filter(p => p.agentId === agentId);
  for (const policy of agentPolicies) {
    if (policy.accessLevel.includes(document.classification)) {
      return true;
    }
  }
  return document.classification === 'public';
}

export function retrieve(query: string, agentId: string, topK: number = 5): RetrievalQuery {
  const results: RetrievalResult[] = [];
  
  for (const doc of documents.values()) {
    const accessGranted = checkAccess(agentId, doc);
    if (accessGranted) {
      const relevance = Math.random(); // Simulate relevance scoring
      results.push({
        documentId: doc.id, relevance,
        snippet: doc.content.substring(0, 200),
        accessGranted
      });
    }
  }
  
  results.sort((a,b) => b.relevance - a.relevance);
  
  const rq: RetrievalQuery = {
    id: `query_${Date.now()}`, query, agentId,
    results: results.slice(0, topK), sanitized: true,
    timestamp: Date.now()
  };
  
  queries.set(rq.id, rq);
  return rq;
}

export function getDocument(id: string): DocumentRecord | undefined { return documents.get(id); }
export function getQuery(id: string): RetrievalQuery | undefined { return queries.get(id); }

function generateChecksum(content: string): string {
  let hash = 0;
  for (let i = 0; i < content.length; i++) {
    hash = ((hash << 5) - hash) + content.charCodeAt(i);
  }
  return Math.abs(hash).toString(16);
}

export function getRAGStats() {
  return {
    documents: documents.size,
    queries: queries.size,
    policies: policies.size,
    byClassification: Object.groupBy(Array.from(documents.values()), d => d.classification)
  };
}

export function runRAGSecurityTests() {
  const results: {name: string; passed: boolean}[] = [];
  try { const d = ingestDocument({title:'Test',content:'Hello world',source:'test'}); results.push({name:'Ingest',passed:!!d.id}); } catch { results.push({name:'Ingest',passed:false}); }
  try { const s = sanitizeContent('<script>alert(1)</script>Hello'); results.push({name:'Sanitize',passed:!s.includes('<script>')}); } catch { results.push({name:'Sanitize',passed:false}); }
  try { const q = retrieve('test','agent1'); results.push({name:'Retrieve',passed:!!q.id}); } catch { results.push({name:'Retrieve',passed:false}); }
  try { const s = getRAGStats(); results.push({name:'Stats',passed:s.documents>0}); } catch { results.push({name:'Stats',passed:false}); }
  const passed = results.filter(r=>r.passed).length, failed = results.filter(r=>!r.passed).length;
  return {passed: failed===0, tests:{total:results.length,passed,failed}, results};
}

export default {ingestDocument,sanitizeContent,grantAccess,checkAccess,retrieve,getDocument,getQuery,getRAGStats,runRAGSecurityTests};
