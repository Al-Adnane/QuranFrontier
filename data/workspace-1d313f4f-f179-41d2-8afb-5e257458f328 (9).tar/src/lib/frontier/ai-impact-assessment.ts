/**
 * AI Impact Assessment - Environmental and social impact tracking
 * @module frontier/ai-impact-assessment
 */
export type ImpactCategory = 'environmental' | 'social' | 'economic';

export interface ImpactAssessment {
  id: string; systemId: string; name: string;
  environmental: EnvironmentalImpact; social: SocialImpact;
  economic: EconomicImpact; overallScore: number;
  recommendations: string[]; createdAt: number;
}

export interface EnvironmentalImpact {
  carbonFootprintKg: number; energyConsumedKWh: number;
  waterUsageLiters: number; eWasteKg: number;
  sustainabilityScore: number; offsetsPurchased: number;
}

export interface SocialImpact {
  jobsAffected: number; communitiesImpacted: number;
  privacyRiskLevel: 'low' | 'medium' | 'high';
  biasRiskLevel: 'low' | 'medium' | 'high';
  accessibilityScore: number; socialScore: number;
}

export interface EconomicImpact {
  costSavings: number; revenueImpact: number;
  jobsCreated: number; jobsDisplaced: number;
  productivityGain: number; economicScore: number;
}

export interface ImpactGoal {
  id: string; category: ImpactCategory; target: number;
  current: number; deadline: number; status: 'on_track' | 'at_risk' | 'achieved';
}

const assessments = new Map<string, ImpactAssessment>();
const goals = new Map<string, ImpactGoal>();

export function createAssessment(config: {systemId: string; name: string}): ImpactAssessment {
  const assessment: ImpactAssessment = {
    id: `impact_${Date.now()}_${Math.random().toString(36).substr(2,6)}`,
    ...config,
    environmental: {carbonFootprintKg:0,energyConsumedKWh:0,waterUsageLiters:0,eWasteKg:0,sustainabilityScore:0,offsetsPurchased:0},
    social: {jobsAffected:0,communitiesImpacted:0,privacyRiskLevel:'low',biasRiskLevel:'low',accessibilityScore:0,socialScore:0},
    economic: {costSavings:0,revenueImpact:0,jobsCreated:0,jobsDisplaced:0,productivityGain:0,economicScore:0},
    overallScore: 0, recommendations: [], createdAt: Date.now()
  };
  assessments.set(assessment.id, assessment);
  return assessment;
}

export function recordEnvironmental(id: string, data: Partial<EnvironmentalImpact>): boolean {
  const a = assessments.get(id);
  if (!a) return false;
  Object.assign(a.environmental, data);
  a.environmental.sustainabilityScore = calculateSustainability(a.environmental);
  updateOverallScore(a);
  return true;
}

export function recordSocial(id: string, data: Partial<SocialImpact>): boolean {
  const a = assessments.get(id);
  if (!a) return false;
  Object.assign(a.social, data);
  a.social.socialScore = calculateSocialScore(a.social);
  updateOverallScore(a);
  return true;
}

export function recordEconomic(id: string, data: Partial<EconomicImpact>): boolean {
  const a = assessments.get(id);
  if (!a) return false;
  Object.assign(a.economic, data);
  a.economic.economicScore = calculateEconomicScore(a.economic);
  updateOverallScore(a);
  return true;
}

export function setGoal(category: ImpactCategory, target: number, deadline: number): ImpactGoal {
  const goal: ImpactGoal = {
    id: `goal_${Date.now()}`, category, target, current: 0, deadline, status: 'on_track'
  };
  goals.set(goal.id, goal);
  return goal;
}

export function getAssessment(id: string): ImpactAssessment | undefined { return assessments.get(id); }

function calculateSustainability(e: EnvironmentalImpact): number {
  const carbonScore = Math.max(0, 1 - (e.carbonFootprintKg / 1000));
  const energyScore = Math.max(0, 1 - (e.energyConsumedKWh / 10000));
  return (carbonScore + energyScore) / 2;
}

function calculateSocialScore(s: SocialImpact): number {
  const privacyScore = s.privacyRiskLevel === 'low' ? 1 : s.privacyRiskLevel === 'medium' ? 0.6 : 0.3;
  const biasScore = s.biasRiskLevel === 'low' ? 1 : s.biasRiskLevel === 'medium' ? 0.6 : 0.3;
  return (privacyScore + biasScore + s.accessibilityScore) / 3;
}

function calculateEconomicScore(e: EconomicImpact): number {
  const jobScore = e.jobsCreated > e.jobsDisplaced ? 0.8 : 0.4;
  return (jobScore + Math.min(1, e.productivityGain / 100)) / 2;
}

function updateOverallScore(a: ImpactAssessment): void {
  a.overallScore = (a.environmental.sustainabilityScore + a.social.socialScore + a.economic.economicScore) / 3;
  if (a.overallScore < 0.5) {
    a.recommendations.push('Consider carbon offset programs');
    a.recommendations.push('Implement bias mitigation measures');
  }
}

export function getImpactStats() {
  const all = Array.from(assessments.values());
  return {
    total: assessments.size, goals: goals.size,
    avgScore: all.reduce((s,a) => s + a.overallScore, 0) / Math.max(1, all.length) || 0,
    totalCarbon: all.reduce((s,a) => s + a.environmental.carbonFootprintKg, 0)
  };
}

export function runAIImpactAssessmentTests() {
  const results: {name: string; passed: boolean}[] = [];
  try { const a = createAssessment({systemId:'sys1',name:'Test'}); results.push({name:'Create',passed:!!a.id}); } catch { results.push({name:'Create',passed:false}); }
  try { const a = Array.from(assessments.values())[0]; recordEnvironmental(a.id,{carbonFootprintKg:500,energyConsumedKWh:2000}); results.push({name:'Environmental',passed:a.environmental.sustainabilityScore>0}); } catch { results.push({name:'Environmental',passed:false}); }
  try { const g = setGoal('environmental',100,Date.now()+86400000); results.push({name:'Goal',passed:!!g.id}); } catch { results.push({name:'Goal',passed:false}); }
  try { const s = getImpactStats(); results.push({name:'Stats',passed:s.total>0}); } catch { results.push({name:'Stats',passed:false}); }
  const passed = results.filter(r=>r.passed).length, failed = results.filter(r=>!r.passed).length;
  return {passed: failed===0, tests:{total:results.length,passed,failed}, results};
}

export default {createAssessment,recordEnvironmental,recordSocial,recordEconomic,setGoal,getAssessment,getImpactStats,runAIImpactAssessmentTests};
