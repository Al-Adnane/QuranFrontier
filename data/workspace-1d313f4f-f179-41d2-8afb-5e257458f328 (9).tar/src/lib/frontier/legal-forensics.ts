/**
 * Legal Forensics Module
 *
 * Legal discovery and evidence chain management with CAIL.
 * Hash-chained audit trail for legal defensibility.
 *
 * @module frontier/legal-forensics
 * @version 9.1.0
 *
 * Capabilities:
 * - Evidence chain of custody
 * - Document hash verification
 * - Legal discovery management
 * - Court-admissible audit trails
 * - Evidence integrity verification
 * - Case management
 * - Witness tracking
 * - Timeline reconstruction
 * - Expert report generation
 * - Regulatory compliance
 */

import { generateUUID, sha256Hash, sha512Hash, hmacSign } from '../crypto-utils';

// ============================================================================
// TYPES
// ============================================================================

/**
 * Evidence item
 */
export interface EvidenceItem {
  /** Evidence ID */
  id: string;
  /** Case ID */
  caseId: string;
  /** Evidence number */
  evidenceNumber: string;
  /** Evidence type */
  type: 'document' | 'image' | 'video' | 'audio' | 'digital' | 'physical' | 'testimony';
  /** Title */
  title: string;
  /** Description */
  description: string;
  /** Original hash */
  originalHash: string;
  /** Current hash */
  currentHash: string;
  /** Hash chain */
  hashChain: HashChainEntry[];
  /** Custody chain */
  custodyChain: CustodyEntry[];
  /** Collection info */
  collection: CollectionInfo;
  /** Analysis reports */
  analysisReports: AnalysisReport[];
  /** Status */
  status: 'collected' | 'analyzing' | 'verified' | 'admitted' | 'excluded' | 'sealed';
  /** Authenticity verified */
  authenticityVerified: boolean;
  /** Chain integrity */
  chainIntegrity: 'intact' | 'broken' | 'suspect' | 'unverified';
  /** Metadata */
  metadata: Record<string, unknown>;
  /** Created timestamp */
  createdAt: number;
  /** Last updated */
  updatedAt: number;
}

/**
 * Hash chain entry
 */
export interface HashChainEntry {
  /** Entry ID */
  id: string;
  /** Hash value */
  hash: string;
  /** Previous hash */
  previousHash: string;
  /** Operation */
  operation: 'created' | 'modified' | 'accessed' | 'copied' | 'verified' | 'sealed';
  /** Actor */
  actor: string;
  /** Timestamp */
  timestamp: number;
  /** Signature */
  signature: string;
  /** Notes */
  notes?: string;
}

/**
 * Custody entry
 */
export interface CustodyEntry {
  /** Entry ID */
  id: string;
  /** Custodian ID */
  custodianId: string;
  /** Custodian name */
  custodianName: string;
  /** Custodian role */
  role: 'collector' | 'analyst' | 'storage' | 'transporter' | 'court_officer' | 'expert';
  /** Organization */
  organization: string;
  /** Action */
  action: 'collected' | 'received' | 'transferred' | 'analyzed' | 'stored' | 'retrieved' | 'presented' | 'returned';
  /** Location */
  location: string;
  /** Timestamp */
  timestamp: number;
  /** Signature */
  signature: string;
  /** Conditions */
  conditions?: {
    temperature?: number;
    humidity?: number;
    sealed: boolean;
    containerId?: string;
  };
  /** Notes */
  notes?: string;
}

/**
 * Collection info
 */
export interface CollectionInfo {
  /** Collector ID */
  collectorId: string;
  /** Collector name */
  collectorName: string;
  /** Organization */
  organization: string;
  /** Location */
  location: string;
  /** Method */
  method: 'search_warrant' | 'subpoena' | 'consent' | 'incident_response' | 'routine_discovery';
  /** Legal authority */
  legalAuthority?: string;
  /** Warrant number */
  warrantNumber?: string;
  /** Timestamp */
  timestamp: number;
  /** Witnesses */
  witnesses: Witness[];
}

/**
 * Witness
 */
export interface Witness {
  /** Witness ID */
  id: string;
  /** Name */
  name: string;
  /** Role */
  role: string;
  /** Contact */
  contact?: string;
  /** Present during */
  presentDuring: 'collection' | 'analysis' | 'both';
  /** Signature */
  signature?: string;
}

/**
 * Analysis report
 */
export interface AnalysisReport {
  /** Report ID */
  id: string;
  /** Evidence ID */
  evidenceId: string;
  /** Analyst ID */
  analystId: string;
  /** Analyst name */
  analystName: string;
  /** Analyst credentials */
  credentials: string;
  /** Report type */
  type: 'forensic' | 'expert' | 'technical' | 'authentication' | 'chain_verification';
  /** Findings */
  findings: string;
  /** Conclusions */
  conclusions: string;
  /** Confidence level */
  confidence: 'preliminary' | 'probable' | 'conclusive';
  /** Hash of report */
  reportHash: string;
  /** Timestamp */
  timestamp: number;
  /** Signature */
  signature: string;
  /** Attachments */
  attachments?: string[];
}

/**
 * Legal case
 */
export interface LegalCase {
  /** Case ID */
  id: string;
  /** Case number */
  caseNumber: string;
  /** Case name */
  name: string;
  /** Case type */
  type: 'civil' | 'criminal' | 'administrative' | 'arbitration' | 'regulatory';
  /** Status */
  status: 'active' | 'pending' | 'settled' | 'dismissed' | 'adjudicated' | 'appealed';
  /** Parties */
  parties: CaseParty[];
  /** Evidence items */
  evidenceIds: string[];
  /** Timeline events */
  timeline: TimelineEvent[];
  /** Court info */
  court?: {
    name: string;
    jurisdiction: string;
    judge?: string;
    docketNumber?: string;
  };
  /** Key dates */
  keyDates: {
    filed?: number;
    discoveryStart?: number;
    discoveryEnd?: number;
    trialStart?: number;
    trialEnd?: number;
    disposition?: number;
  };
  /** Created timestamp */
  createdAt: number;
  /** Updated timestamp */
  updatedAt: number;
}

/**
 * Case party
 */
export interface CaseParty {
  /** Party ID */
  id: string;
  /** Name */
  name: string;
  /** Role */
  role: 'plaintiff' | 'defendant' | 'respondent' | 'petitioner' | 'intervenor' | 'witness' | 'expert';
  /** Organization */
  organization?: string;
  /** Counsel */
  counsel?: {
    name: string;
    firm: string;
    barNumber?: string;
  };
  /** Contact */
  contact?: {
    email?: string;
    phone?: string;
    address?: string;
  };
}

/**
 * Timeline event
 */
export interface TimelineEvent {
  /** Event ID */
  id: string;
  /** Timestamp */
  timestamp: number;
  /** Event type */
  type: 'filing' | 'hearing' | 'discovery' | 'motion' | 'order' | 'evidence' | 'testimony' | 'ruling' | 'other';
  /** Title */
  title: string;
  /** Description */
  description: string;
  /** Actor */
  actor: string;
  /** Related evidence */
  relatedEvidence?: string[];
  /** Related documents */
  relatedDocuments?: string[];
  /** Importance */
  importance: 'critical' | 'high' | 'medium' | 'low';
}

/**
 * Discovery request
 */
export interface DiscoveryRequest {
  /** Request ID */
  id: string;
  /** Case ID */
  caseId: string;
  /** Request type */
  type: 'interrogatory' | 'document_request' | 'deposition' | 'admission' | 'subpoena' | 'preservation';
  /** Requesting party */
  requestingParty: string;
  /** Responding party */
  respondingParty: string;
  /** Request number */
  requestNumber: string;
  /** Request text */
  requestText: string;
  /** Response deadline */
  responseDeadline: number;
  /** Status */
  status: 'pending' | 'responded' | 'objected' | 'compelled' | 'withdrawn';
  /** Response */
  response?: {
    text: string;
    timestamp: number;
    objections?: string[];
    producedDocuments?: string[];
  };
  /** Created timestamp */
  createdAt: number;
}

/**
 * Forensic configuration
 */
export interface ForensicConfig {
  /** Hash algorithm */
  hashAlgorithm: 'SHA256' | 'SHA512';
  /** Enable automatic verification */
  enableAutoVerification: boolean;
  /** Verification interval (hours) */
  verificationInterval: number;
  /** Max custody entries */
  maxCustodyEntries: number;
  /** Enable expert report signing */
  enableReportSigning: boolean;
  /** Retention period (days) */
  retentionPeriod: number;
}

// ============================================================================
// STORAGE
// ============================================================================

const evidence = new Map<string, EvidenceItem>();
const cases = new Map<string, LegalCase>();
const discoveryRequests = new Map<string, DiscoveryRequest>();
const auditTrail = new Map<string, HashChainEntry[]>();

// Configuration
let forensicConfig: ForensicConfig = {
  hashAlgorithm: 'SHA256',
  enableAutoVerification: true,
  verificationInterval: 24,
  maxCustodyEntries: 1000,
  enableReportSigning: true,
  retentionPeriod: 365 * 7 // 7 years
};

// Platform secret
const PLATFORM_SECRET = 'legal_forensics_secret_v1';

// ============================================================================
// CONFIGURATION
// ============================================================================

/**
 * Update forensic configuration
 */
export function updateForensicConfig(newConfig: Partial<ForensicConfig>): ForensicConfig {
  forensicConfig = { ...forensicConfig, ...newConfig };
  return forensicConfig;
}

/**
 * Get forensic configuration
 */
export function getForensicConfig(): ForensicConfig {
  return { ...forensicConfig };
}

// ============================================================================
// CASE MANAGEMENT
// ============================================================================

/**
 * Create legal case
 */
export function createCase(params: {
  caseNumber: string;
  name: string;
  type: LegalCase['type'];
  parties: Omit<CaseParty, 'id'>[];
  court?: LegalCase['court'];
}): LegalCase {
  const id = `case_${generateUUID()}`;
  const now = Date.now();

  const legalCase: LegalCase = {
    id,
    caseNumber: params.caseNumber,
    name: params.name,
    type: params.type,
    status: 'active',
    parties: params.parties.map(p => ({ ...p, id: `party_${generateUUID()}` })),
    evidenceIds: [],
    timeline: [],
    court: params.court,
    keyDates: {},
    createdAt: now,
    updatedAt: now
  };

  cases.set(id, legalCase);
  addTimelineEvent(id, {
    type: 'filing',
    title: 'Case Created',
    description: `Case ${params.caseNumber} - ${params.name}`,
    actor: 'system',
    importance: 'high'
  });

  return legalCase;
}

/**
 * Get case
 */
export function getCase(caseId: string): LegalCase | undefined {
  return cases.get(caseId);
}

/**
 * List cases
 */
export function listCases(status?: LegalCase['status']): LegalCase[] {
  let result = Array.from(cases.values());
  if (status) {
    result = result.filter(c => c.status === status);
  }
  return result.sort((a, b) => b.updatedAt - a.updatedAt);
}

/**
 * Add timeline event
 */
export function addTimelineEvent(caseId: string, event: Omit<TimelineEvent, 'id' | 'timestamp'>): TimelineEvent | null {
  const legalCase = cases.get(caseId);
  if (!legalCase) return null;

  const timelineEvent: TimelineEvent = {
    ...event,
    id: `event_${generateUUID()}`,
    timestamp: Date.now()
  };

  legalCase.timeline.push(timelineEvent);
  legalCase.timeline.sort((a, b) => a.timestamp - b.timestamp);
  legalCase.updatedAt = Date.now();
  cases.set(caseId, legalCase);

  return timelineEvent;
}

// ============================================================================
// EVIDENCE MANAGEMENT
// ============================================================================

/**
 * Collect evidence
 */
export function collectEvidence(params: {
  caseId: string;
  type: EvidenceItem['type'];
  title: string;
  description: string;
  data: string | Buffer;
  collection: Omit<CollectionInfo, 'timestamp'>;
}): EvidenceItem {
  const legalCase = cases.get(params.caseId);
  if (!legalCase) {
    throw new Error('Case not found');
  }

  const id = `evidence_${generateUUID()}`;
  const now = Date.now();

  // Calculate original hash
  const dataString = typeof params.data === 'string' ? params.data : params.data.toString('base64');
  const originalHash = forensicConfig.hashAlgorithm === 'SHA512' 
    ? sha512Hash(dataString) 
    : sha256Hash(dataString);

  // Create genesis hash chain entry
  const genesisEntry = createHashChainEntry(id, 'created', originalHash, '0', params.collection.collectorId);

  // Create initial custody entry
  const custodyEntry = createCustodyEntry(
    id,
    params.collection.collectorId,
    params.collection.collectorName,
    'collector',
    params.collection.organization,
    'collected',
    params.collection.location
  );

  const evidenceItem: EvidenceItem = {
    id,
    caseId: params.caseId,
    evidenceNumber: `${legalCase.caseNumber}-E${String(legalCase.evidenceIds.length + 1).padStart(3, '0')}`,
    type: params.type,
    title: params.title,
    description: params.description,
    originalHash,
    currentHash: originalHash,
    hashChain: [genesisEntry],
    custodyChain: [custodyEntry],
    collection: {
      ...params.collection,
      timestamp: now
    },
    analysisReports: [],
    status: 'collected',
    authenticityVerified: false,
    chainIntegrity: 'intact',
    metadata: {},
    createdAt: now,
    updatedAt: now
  };

  evidence.set(id, evidenceItem);
  legalCase.evidenceIds.push(id);
  legalCase.updatedAt = now;
  cases.set(params.caseId, legalCase);

  // Add timeline event
  addTimelineEvent(params.caseId, {
    type: 'evidence',
    title: 'Evidence Collected',
    description: `${params.title} (${evidenceItem.evidenceNumber})`,
    actor: params.collection.collectorName,
    relatedEvidence: [id],
    importance: 'high'
  });

  return evidenceItem;
}

/**
 * Get evidence
 */
export function getEvidence(evidenceId: string): EvidenceItem | undefined {
  return evidence.get(evidenceId);
}

/**
 * List evidence by case
 */
export function listEvidenceByCase(caseId: string): EvidenceItem[] {
  return Array.from(evidence.values())
    .filter(e => e.caseId === caseId)
    .sort((a, b) => a.createdAt - b.createdAt);
}

/**
 * Transfer custody
 */
export function transferCustody(params: {
  evidenceId: string;
  fromCustodianId: string;
  toCustodianId: string;
  toCustodianName: string;
  toRole: CustodyEntry['role'];
  organization: string;
  location: string;
  conditions?: CustodyEntry['conditions'];
  notes?: string;
}): EvidenceItem | null {
  const evidenceItem = evidence.get(params.evidenceId);
  if (!evidenceItem) return null;

  // Verify current custodian
  const lastCustody = evidenceItem.custodyChain[evidenceItem.custodyChain.length - 1];
  if (lastCustody.custodianId !== params.fromCustodianId) {
    throw new Error('Invalid custodian - not current holder');
  }

  // Create custody entry
  const custodyEntry = createCustodyEntry(
    params.evidenceId,
    params.toCustodianId,
    params.toCustodianName,
    params.toRole,
    params.organization,
    'transferred',
    params.location,
    params.conditions,
    params.notes
  );

  // Add to hash chain
  const hashEntry = createHashChainEntry(
    params.evidenceId,
    'accessed',
    evidenceItem.currentHash,
    evidenceItem.hashChain[evidenceItem.hashChain.length - 1].hash,
    params.toCustodianId,
    `Custody transferred to ${params.toCustodianName}`
  );

  evidenceItem.custodyChain.push(custodyEntry);
  evidenceItem.hashChain.push(hashEntry);
  evidenceItem.updatedAt = Date.now();

  // Limit custody chain length
  if (evidenceItem.custodyChain.length > forensicConfig.maxCustodyEntries) {
    evidenceItem.custodyChain = evidenceItem.custodyChain.slice(-forensicConfig.maxCustodyEntries);
  }

  evidence.set(params.evidenceId, evidenceItem);

  return evidenceItem;
}

/**
 * Verify evidence integrity
 */
export function verifyEvidenceIntegrity(evidenceId: string, data?: string | Buffer): {
  valid: boolean;
  originalHash: string;
  currentHash: string;
  chainIntact: boolean;
  custodyComplete: boolean;
  issues: string[];
} {
  const evidenceItem = evidence.get(evidenceId);
  if (!evidenceItem) {
    return {
      valid: false,
      originalHash: '',
      currentHash: '',
      chainIntact: false,
      custodyComplete: false,
      issues: ['Evidence not found']
    };
  }

  const issues: string[] = [];

  // Verify hash chain
  let chainIntact = true;
  for (let i = 1; i < evidenceItem.hashChain.length; i++) {
    if (evidenceItem.hashChain[i].previousHash !== evidenceItem.hashChain[i - 1].hash) {
      chainIntact = false;
      issues.push(`Hash chain broken at position ${i}`);
    }
  }

  // Verify custody chain signatures
  let custodyComplete = true;
  for (const entry of evidenceItem.custodyChain) {
    if (!entry.signature) {
      custodyComplete = false;
      issues.push(`Missing signature for custody entry ${entry.id}`);
    }
  }

  // Verify current data hash if provided
  if (data) {
    const dataString = typeof data === 'string' ? data : data.toString('base64');
    const calculatedHash = forensicConfig.hashAlgorithm === 'SHA512'
      ? sha512Hash(dataString)
      : sha256Hash(dataString);

    if (calculatedHash !== evidenceItem.currentHash) {
      issues.push('Current data hash does not match stored hash');
    }
  }

  // Update chain integrity status
  evidenceItem.chainIntegrity = chainIntact && custodyComplete ? 'intact' : 'broken';
  evidence.set(evidenceId, evidenceItem);

  return {
    valid: issues.length === 0,
    originalHash: evidenceItem.originalHash,
    currentHash: evidenceItem.currentHash,
    chainIntact,
    custodyComplete,
    issues
  };
}

/**
 * Add analysis report
 */
export function addAnalysisReport(params: {
  evidenceId: string;
  analystId: string;
  analystName: string;
  credentials: string;
  type: AnalysisReport['type'];
  findings: string;
  conclusions: string;
  confidence: AnalysisReport['confidence'];
}): AnalysisReport | null {
  const evidenceItem = evidence.get(params.evidenceId);
  if (!evidenceItem) return null;

  const reportId = `report_${generateUUID()}`;
  const reportText = `${params.findings}\n\n${params.conclusions}`;
  const reportHash = sha256Hash(reportText);

  const report: AnalysisReport = {
    id: reportId,
    evidenceId: params.evidenceId,
    analystId: params.analystId,
    analystName: params.analystName,
    credentials: params.credentials,
    type: params.type,
    findings: params.findings,
    conclusions: params.conclusions,
    confidence: params.confidence,
    reportHash,
    timestamp: Date.now(),
    signature: hmacSign(reportHash, PLATFORM_SECRET)
  };

  evidenceItem.analysisReports.push(report);
  evidenceItem.status = 'analyzing';
  evidenceItem.updatedAt = Date.now();
  evidence.set(params.evidenceId, evidenceItem);

  // Add to hash chain
  const hashEntry = createHashChainEntry(
    params.evidenceId,
    'modified',
    sha256Hash(evidenceItem.currentHash + reportHash),
    evidenceItem.hashChain[evidenceItem.hashChain.length - 1].hash,
    params.analystId,
    `Analysis report added: ${params.type}`
  );
  evidenceItem.hashChain.push(hashEntry);

  return report;
}

/**
 * Seal evidence
 */
export function sealEvidence(evidenceId: string, sealedBy: string): EvidenceItem | null {
  const evidenceItem = evidence.get(evidenceId);
  if (!evidenceItem) return null;

  // Verify integrity before sealing
  const verification = verifyEvidenceIntegrity(evidenceId);
  if (!verification.valid) {
    throw new Error('Cannot seal evidence with integrity issues');
  }

  evidenceItem.status = 'sealed';

  // Add seal entry to hash chain
  const hashEntry = createHashChainEntry(
    evidenceId,
    'sealed',
    evidenceItem.currentHash,
    evidenceItem.hashChain[evidenceItem.hashChain.length - 1].hash,
    sealedBy,
    'Evidence sealed'
  );
  evidenceItem.hashChain.push(hashEntry);
  evidenceItem.updatedAt = Date.now();

  evidence.set(evidenceId, evidenceItem);

  return evidenceItem;
}

// ============================================================================
// DISCOVERY MANAGEMENT
// ============================================================================

/**
 * Create discovery request
 */
export function createDiscoveryRequest(params: {
  caseId: string;
  type: DiscoveryRequest['type'];
  requestingParty: string;
  respondingParty: string;
  requestNumber: string;
  requestText: string;
  responseDeadline: number;
}): DiscoveryRequest {
  const request: DiscoveryRequest = {
    id: `discovery_${generateUUID()}`,
    caseId: params.caseId,
    type: params.type,
    requestingParty: params.requestingParty,
    respondingParty: params.respondingParty,
    requestNumber: params.requestNumber,
    requestText: params.requestText,
    responseDeadline: params.responseDeadline,
    status: 'pending',
    createdAt: Date.now()
  };

  discoveryRequests.set(request.id, request);

  // Add timeline event
  addTimelineEvent(params.caseId, {
    type: 'discovery',
    title: `${params.type} Request`,
    description: `${params.requestNumber}: ${params.requestText.substring(0, 100)}...`,
    actor: params.requestingParty,
    importance: 'medium'
  });

  return request;
}

/**
 * Respond to discovery request
 */
export function respondToDiscoveryRequest(params: {
  requestId: string;
  responseText: string;
  objections?: string[];
  producedDocuments?: string[];
}): DiscoveryRequest | null {
  const request = discoveryRequests.get(params.requestId);
  if (!request) return null;

  request.response = {
    text: params.responseText,
    timestamp: Date.now(),
    objections: params.objections,
    producedDocuments: params.producedDocuments
  };
  request.status = params.objections && params.objections.length > 0 ? 'objected' : 'responded';

  discoveryRequests.set(params.requestId, request);

  return request;
}

/**
 * Get discovery requests
 */
export function getDiscoveryRequests(caseId: string): DiscoveryRequest[] {
  return Array.from(discoveryRequests.values())
    .filter(r => r.caseId === caseId)
    .sort((a, b) => a.createdAt - b.createdAt);
}

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Create hash chain entry
 */
function createHashChainEntry(
  evidenceId: string,
  operation: HashChainEntry['operation'],
  hash: string,
  previousHash: string,
  actor: string,
  notes?: string
): HashChainEntry {
  const entry: HashChainEntry = {
    id: `hash_${generateUUID()}`,
    hash,
    previousHash,
    operation,
    actor,
    timestamp: Date.now(),
    signature: hmacSign(`${hash}${previousHash}${actor}`, PLATFORM_SECRET),
    notes
  };

  return entry;
}

/**
 * Create custody entry
 */
function createCustodyEntry(
  evidenceId: string,
  custodianId: string,
  custodianName: string,
  role: CustodyEntry['role'],
  organization: string,
  action: CustodyEntry['action'],
  location: string,
  conditions?: CustodyEntry['conditions'],
  notes?: string
): CustodyEntry {
  const entry: CustodyEntry = {
    id: `custody_${generateUUID()}`,
    custodianId,
    custodianName,
    role,
    organization,
    action,
    location,
    timestamp: Date.now(),
    signature: hmacSign(`${custodianId}${action}${location}`, PLATFORM_SECRET),
    conditions,
    notes
  };

  return entry;
}

// ============================================================================
// AUDIT AND REPORTING
// ============================================================================

/**
 * Generate chain of custody report
 */
export function generateCustodyReport(evidenceId: string): {
  evidence: EvidenceItem;
  custodyChain: CustodyEntry[];
  hashChain: HashChainEntry[];
  integrityCheck: ReturnType<typeof verifyEvidenceIntegrity>;
  generatedAt: number;
} | null {
  const evidenceItem = evidence.get(evidenceId);
  if (!evidenceItem) return null;

  return {
    evidence: evidenceItem,
    custodyChain: evidenceItem.custodyChain,
    hashChain: evidenceItem.hashChain,
    integrityCheck: verifyEvidenceIntegrity(evidenceId),
    generatedAt: Date.now()
  };
}

/**
 * Generate case summary report
 */
export function generateCaseSummary(caseId: string): {
  case: LegalCase;
  evidence: EvidenceItem[];
  discovery: DiscoveryRequest[];
  timeline: TimelineEvent[];
  generatedAt: number;
} | null {
  const legalCase = cases.get(caseId);
  if (!legalCase) return null;

  const caseEvidence = listEvidenceByCase(caseId);
  const caseDiscovery = getDiscoveryRequests(caseId);

  return {
    case: legalCase,
    evidence: caseEvidence,
    discovery: caseDiscovery,
    timeline: legalCase.timeline,
    generatedAt: Date.now()
  };
}

// ============================================================================
// STATISTICS
// ============================================================================

/**
 * Get system statistics
 */
export function getSystemStats(): {
  cases: { total: number; byStatus: Record<string, number>; byType: Record<string, number> };
  evidence: { total: number; byStatus: Record<string, number>; byIntegrity: Record<string, number> };
  discovery: { total: number; pending: number; overdue: number };
} {
  const allCases = Array.from(cases.values());
  const allEvidence = Array.from(evidence.values());
  const allDiscovery = Array.from(discoveryRequests.values());

  const caseByStatus: Record<string, number> = {};
  const caseByType: Record<string, number> = {};
  const evidenceByStatus: Record<string, number> = {};
  const evidenceByIntegrity: Record<string, number> = {};

  for (const c of allCases) {
    caseByStatus[c.status] = (caseByStatus[c.status] || 0) + 1;
    caseByType[c.type] = (caseByType[c.type] || 0) + 1;
  }

  for (const e of allEvidence) {
    evidenceByStatus[e.status] = (evidenceByStatus[e.status] || 0) + 1;
    evidenceByIntegrity[e.chainIntegrity] = (evidenceByIntegrity[e.chainIntegrity] || 0) + 1;
  }

  const now = Date.now();
  const overdue = allDiscovery.filter(d => d.status === 'pending' && d.responseDeadline < now).length;

  return {
    cases: { total: allCases.length, byStatus: caseByStatus, byType: caseByType },
    evidence: { total: allEvidence.length, byStatus: evidenceByStatus, byIntegrity: evidenceByIntegrity },
    discovery: { total: allDiscovery.length, pending: allDiscovery.filter(d => d.status === 'pending').length, overdue }
  };
}

// ============================================================================
// TEST SUITE
// ============================================================================

/**
 * Run legal forensics tests
 */
export function runLegalForensicsTests(): {
  passed: boolean;
  tests: { total: number; passed: number; failed: number };
  results: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const results: Array<{ name: string; passed: boolean; error?: string }> = [];

  try {
    // Test 1: Create case
    const legalCase = createCase({
      caseNumber: '2024-CV-001',
      name: 'Test Case v. Defendant',
      type: 'civil',
      parties: [
        { name: 'Plaintiff Inc.', role: 'plaintiff' },
        { name: 'Defendant Corp.', role: 'defendant' }
      ]
    });
    results.push({ name: 'Create Case', passed: !!legalCase.id && legalCase.status === 'active' });

    // Test 2: Collect evidence
    const evidenceItem = collectEvidence({
      caseId: legalCase.id,
      type: 'document',
      title: 'Test Document',
      description: 'Test evidence document',
      data: 'Test evidence content',
      collection: {
        collectorId: 'collector_1',
        collectorName: 'John Collector',
        organization: 'Law Firm LLC',
        location: '123 Main St',
        method: 'subpoena',
        witnesses: []
      }
    });
    results.push({ name: 'Collect Evidence', passed: !!evidenceItem.id && evidenceItem.chainIntegrity === 'intact' });

    // Test 3: Transfer custody
    const transferred = transferCustody({
      evidenceId: evidenceItem.id,
      fromCustodianId: 'collector_1',
      toCustodianId: 'analyst_1',
      toCustodianName: 'Jane Analyst',
      toRole: 'analyst',
      organization: 'Forensics Lab',
      location: '456 Lab Ave'
    });
    results.push({ name: 'Transfer Custody', passed: (transferred?.custodyChain.length || 0) === 2 });

    // Test 4: Add analysis report
    const report = addAnalysisReport({
      evidenceId: evidenceItem.id,
      analystId: 'analyst_1',
      analystName: 'Jane Analyst',
      credentials: 'Certified Forensic Examiner',
      type: 'forensic',
      findings: 'Document appears authentic',
      conclusions: 'No signs of tampering',
      confidence: 'conclusive'
    });
    results.push({ name: 'Add Analysis Report', passed: !!report?.id });

    // Test 5: Verify integrity
    const verification = verifyEvidenceIntegrity(evidenceItem.id);
    results.push({ name: 'Verify Integrity', passed: verification.valid && verification.chainIntact });

    // Test 6: Create discovery request
    const discovery = createDiscoveryRequest({
      caseId: legalCase.id,
      type: 'document_request',
      requestingParty: 'Plaintiff Inc.',
      respondingParty: 'Defendant Corp.',
      requestNumber: 'RFP-001',
      requestText: 'Produce all emails related to the transaction',
      responseDeadline: Date.now() + 30 * 24 * 60 * 60 * 1000
    });
    results.push({ name: 'Create Discovery Request', passed: !!discovery.id && discovery.status === 'pending' });

    // Test 7: Respond to discovery
    const responded = respondToDiscoveryRequest({
      requestId: discovery.id,
      responseText: 'Documents attached',
      producedDocuments: ['doc1.pdf', 'doc2.pdf']
    });
    results.push({ name: 'Respond to Discovery', passed: responded?.status === 'responded' });

    // Test 8: Add timeline event
    const event = addTimelineEvent(legalCase.id, {
      type: 'hearing',
      title: 'Initial Hearing',
      description: 'Case management conference',
      actor: 'Judge Smith',
      importance: 'high'
    });
    results.push({ name: 'Add Timeline Event', passed: !!event?.id });

    // Test 9: Generate custody report
    const custodyReport = generateCustodyReport(evidenceItem.id);
    results.push({ name: 'Generate Custody Report', passed: !!custodyReport && custodyReport.custodyChain.length >= 2 });

    // Test 10: Generate case summary
    const summary = generateCaseSummary(legalCase.id);
    results.push({ name: 'Generate Case Summary', passed: !!summary && summary.evidence.length >= 1 });

    // Test 11: Seal evidence
    const sealed = sealEvidence(evidenceItem.id, 'analyst_1');
    results.push({ name: 'Seal Evidence', passed: sealed?.status === 'sealed' });

    // Test 12: Statistics
    const stats = getSystemStats();
    results.push({ name: 'System Statistics', passed: stats.cases.total >= 1 && stats.evidence.total >= 1 });

  } catch (error) {
    results.push({ name: 'Test execution', passed: false, error: String(error) });
  }

  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;

  return {
    passed: failed === 0,
    tests: { total: results.length, passed, failed },
    results
  };
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

const legalForensics = {
  // Configuration
  updateForensicConfig,
  getForensicConfig,
  // Case management
  createCase,
  getCase,
  listCases,
  addTimelineEvent,
  // Evidence management
  collectEvidence,
  getEvidence,
  listEvidenceByCase,
  transferCustody,
  verifyEvidenceIntegrity,
  addAnalysisReport,
  sealEvidence,
  // Discovery management
  createDiscoveryRequest,
  respondToDiscoveryRequest,
  getDiscoveryRequests,
  // Reporting
  generateCustodyReport,
  generateCaseSummary,
  // Statistics
  getSystemStats,
  // Tests
  runLegalForensicsTests
};

export default legalForensics;
