/**
 * Configuration Management Module
 *
 * Dynamic module configuration with A/B testing for thresholds and feature flags.
 * Supports environment-based configs, versioning, and rollbacks.
 *
 * @module frontier/configuration-management
 * @version 8.1.0
 *
 * Capabilities:
 * - Dynamic configuration
 * - A/B testing for thresholds
 * - Feature flags per module
 * - Configuration versioning
 * - Environment-based configs
 * - Rollback support
 * - Configuration validation
 * - Audit trail
 */

import { generateUUID, sha256Hash } from '../crypto-utils';

// ============================================================================
// TYPES
// ============================================================================

/**
 * Configuration value types
 */
export type ConfigValue = string | number | boolean | null | object | ConfigValue[];

/**
 * Configuration entry
 */
export interface ConfigEntry {
  /** Entry ID */
  id: string;
  /** Configuration key */
  key: string;
  /** Configuration value */
  value: ConfigValue;
  /** Value type */
  type: 'string' | 'number' | 'boolean' | 'object' | 'array';
  /** Default value */
  defaultValue: ConfigValue;
  /** Description */
  description: string;
  /** Module this config belongs to */
  module: string;
  /** Category */
  category: string;
  /** Tags */
  tags: string[];
  /** Is secret */
  isSecret: boolean;
  /** Is required */
  isRequired: boolean;
  /** Validation rules */
  validation?: ConfigValidation;
  /** Environment overrides */
  environments: Record<string, ConfigValue>;
  /** Current environment */
  currentEnvironment: string;
  /** Version */
  version: number;
  /** Created timestamp */
  createdAt: number;
  /** Updated timestamp */
  updatedAt: number;
  /** Updated by */
  updatedBy: string;
  /** Enabled */
  enabled: boolean;
}

/**
 * Configuration validation
 */
export interface ConfigValidation {
  /** Min value (for numbers) */
  min?: number;
  /** Max value (for numbers) */
  max?: number;
  /** Min length (for strings) */
  minLength?: number;
  /** Max length (for strings) */
  maxLength?: number;
  /** Pattern (for strings) */
  pattern?: string;
  /** Allowed values */
  allowedValues?: ConfigValue[];
  /** Custom validation function name */
  customValidator?: string;
}

/**
 * Configuration change
 */
export interface ConfigChange {
  /** Change ID */
  id: string;
  /** Configuration key */
  key: string;
  /** Old value */
  oldValue: ConfigValue;
  /** New value */
  newValue: ConfigValue;
  /** Changed by */
  changedBy: string;
  /** Changed timestamp */
  changedAt: number;
  /** Reason */
  reason: string;
  /** Version from */
  versionFrom: number;
  /** Version to */
  versionTo: number;
  /** Rollback info */
  rollback?: {
    available: boolean;
    rollbackId?: string;
  };
}

/**
 * Feature flag
 */
export interface FeatureFlag {
  /** Flag ID */
  id: string;
  /** Flag name */
  name: string;
  /** Flag key */
  key: string;
  /** Description */
  description: string;
  /** Enabled status */
  enabled: boolean;
  /** Targeting rules */
  targeting: TargetingRule[];
  /** Variants */
  variants: FlagVariant[];
  /** Default variant */
  defaultVariant: string;
  /** Module */
  module: string;
  /** Created timestamp */
  createdAt: number;
  /** Updated timestamp */
  updatedAt: number;
  /** Created by */
  createdBy: string;
}

/**
 * Targeting rule
 */
export interface TargetingRule {
  /** Rule ID */
  id: string;
  /** Rule name */
  name: string;
  /** Conditions */
  conditions: TargetingCondition[];
  /** Variant to serve */
  variant: string;
  /** Rollout percentage */
  rolloutPercentage: number;
  /** Priority */
  priority: number;
}

/**
 * Targeting condition
 */
export interface TargetingCondition {
  /** Attribute to check */
  attribute: string;
  /** Operator */
  operator: 'eq' | 'neq' | 'contains' | 'matches' | 'in' | 'gt' | 'lt' | 'gte' | 'lte';
  /** Value */
  value: ConfigValue;
}

/**
 * Flag variant
 */
export interface FlagVariant {
  /** Variant ID */
  id: string;
  /** Variant name */
  name: string;
  /** Variant key */
  key: string;
  /** Variant value */
  value: ConfigValue;
  /** Description */
  description: string;
}

/**
 * A/B test
 */
export interface ABTest {
  /** Test ID */
  id: string;
  /** Test name */
  name: string;
  /** Test key */
  key: string;
  /** Description */
  description: string;
  /** Configuration key being tested */
  configKey: string;
  /** Module */
  module: string;
  /** Variants */
  variants: ABTestVariant[];
  /** Control variant */
  controlVariant: string;
  /** Traffic allocation */
  trafficAllocation: number;
  /** Status */
  status: 'draft' | 'running' | 'paused' | 'completed' | 'archived';
  /** Start timestamp */
  startedAt?: number;
  /** End timestamp */
  endedAt?: number;
  /** Results */
  results?: ABTestResult;
  /** Targeting */
  targeting: TargetingRule[];
  /** Created timestamp */
  createdAt: number;
  /** Updated timestamp */
  updatedAt: number;
  /** Created by */
  createdBy: string;
}

/**
 * A/B test variant
 */
export interface ABTestVariant {
  /** Variant ID */
  id: string;
  /** Variant name */
  name: string;
  /** Variant key */
  key: string;
  /** Configuration value */
  value: ConfigValue;
  /** Traffic percentage */
  trafficPercentage: number;
  /** Is control */
  isControl: boolean;
}

/**
 * A/B test result
 */
export interface ABTestResult {
  /** Total exposures */
  totalExposures: number;
  /** Variant results */
  variants: Record<string, {
    exposures: number;
    conversions: number;
    conversionRate: number;
    confidence: number;
    isWinner: boolean;
  }>;
  /** Winner variant */
  winner?: string;
  /** Statistical significance */
  statisticalSignificance: number;
  /** Test conclusion */
  conclusion?: string;
}

/**
 * A/B test exposure
 */
export interface ABTestExposure {
  /** Exposure ID */
  id: string;
  /** Test ID */
  testId: string;
  /** Variant key */
  variantKey: string;
  /** Entity ID (user/session) */
  entityId: string;
  /** Entity attributes */
  entityAttributes: Record<string, ConfigValue>;
  /** Exposed timestamp */
  exposedAt: number;
  /** Converted */
  converted: boolean;
  /** Converted timestamp */
  convertedAt?: number;
}

/**
 * Configuration snapshot
 */
export interface ConfigSnapshot {
  /** Snapshot ID */
  id: string;
  /** Snapshot name */
  name: string;
  /** Description */
  description: string;
  /** Snapshot data */
  data: Record<string, ConfigValue>;
  /** Module configs included */
  modules: string[];
  /** Created timestamp */
  createdAt: number;
  /** Created by */
  createdBy: string;
  /** Environment */
  environment: string;
}

/**
 * Environment
 */
export interface Environment {
  /** Environment ID */
  id: string;
  /** Environment name */
  name: string;
  /** Environment key */
  key: string;
  /** Description */
  description: string;
  /** Is production */
  isProduction: boolean;
  /** Parent environment */
  parentEnvironment?: string;
  /** Created timestamp */
  createdAt: number;
}

// ============================================================================
// STORAGE
// ============================================================================

const configs = new Map<string, ConfigEntry>();
const changes = new Map<string, ConfigChange>();
const featureFlags = new Map<string, FeatureFlag>();
const abTests = new Map<string, ABTest>();
const exposures = new Map<string, ABTestExposure>();
const snapshots = new Map<string, ConfigSnapshot>();
const environments = new Map<string, Environment>();

// Current environment
let currentEnvironment = 'development';

// Platform secret for hashing
const PLATFORM_SECRET = 'config_management_secret_v1';

// Initialize default environments
function initializeEnvironments(): void {
  const defaultEnvironments: Environment[] = [
    { id: 'env_dev', name: 'Development', key: 'development', description: 'Development environment', isProduction: false, createdAt: Date.now() },
    { id: 'env_staging', name: 'Staging', key: 'staging', description: 'Staging environment', isProduction: false, createdAt: Date.now() },
    { id: 'env_prod', name: 'Production', key: 'production', description: 'Production environment', isProduction: true, createdAt: Date.now() }
  ];

  for (const env of defaultEnvironments) {
    environments.set(env.id, env);
  }
}

// Initialize on load
initializeEnvironments();

// ============================================================================
// CONFIGURATION MANAGEMENT
// ============================================================================

/**
 * Set configuration
 */
export function setConfig(config: {
  key: string;
  value: ConfigValue;
  module: string;
  category?: string;
  description?: string;
  defaultValue?: ConfigValue;
  isSecret?: boolean;
  isRequired?: boolean;
  validation?: ConfigValidation;
  tags?: string[];
  changedBy: string;
  reason?: string;
}): ConfigEntry {
  const existing = Array.from(configs.values()).find(c => c.key === config.key);
  const now = Date.now();

  let entry: ConfigEntry;

  if (existing) {
    // Record change
    const change: ConfigChange = {
      id: `change_${generateUUID()}`,
      key: config.key,
      oldValue: existing.value,
      newValue: config.value,
      changedBy: config.changedBy,
      changedAt: now,
      reason: config.reason || 'Configuration updated',
      versionFrom: existing.version,
      versionTo: existing.version + 1,
      rollback: { available: true, rollbackId: `rollback_${generateUUID()}` }
    };
    changes.set(change.id, change);

    // Update entry
    entry = {
      ...existing,
      value: config.value,
      description: config.description || existing.description,
      version: existing.version + 1,
      updatedAt: now,
      updatedBy: config.changedBy
    };
  } else {
    // Create new entry
    entry = {
      id: `config_${generateUUID()}`,
      key: config.key,
      value: config.value,
      type: getValueType(config.value),
      defaultValue: config.defaultValue ?? config.value,
      description: config.description || '',
      module: config.module,
      category: config.category || 'general',
      tags: config.tags || [],
      isSecret: config.isSecret ?? false,
      isRequired: config.isRequired ?? false,
      validation: config.validation,
      environments: {},
      currentEnvironment,
      version: 1,
      createdAt: now,
      updatedAt: now,
      updatedBy: config.changedBy,
      enabled: true
    };
  }

  // Validate
  if (entry.validation) {
    const validationError = validateValue(entry.value, entry.validation);
    if (validationError) {
      throw new Error(`Validation failed: ${validationError}`);
    }
  }

  configs.set(entry.id, entry);
  return entry;
}

/**
 * Get configuration
 */
export function getConfig<T extends ConfigValue = ConfigValue>(key: string, defaultValue?: T): T {
  const entry = Array.from(configs.values()).find(c => c.key === key);
  
  if (!entry || !entry.enabled) {
    return defaultValue as T;
  }

  // Check environment override
  const envValue = entry.environments[currentEnvironment];
  return (envValue !== undefined ? envValue : entry.value) as T;
}

/**
 * Get configuration entry
 */
export function getConfigEntry(key: string): ConfigEntry | undefined {
  return Array.from(configs.values()).find(c => c.key === key);
}

/**
 * Get all configurations for module
 */
export function getModuleConfigs(module: string): ConfigEntry[] {
  return Array.from(configs.values()).filter(c => c.module === module);
}

/**
 * Delete configuration
 */
export function deleteConfig(key: string, deletedBy: string): boolean {
  const entry = Array.from(configs.values()).find(c => c.key === key);
  if (!entry) return false;

  // Record change
  const change: ConfigChange = {
    id: `change_${generateUUID()}`,
    key,
    oldValue: entry.value,
    newValue: null,
    changedBy: deletedBy,
    changedAt: Date.now(),
    reason: 'Configuration deleted',
    versionFrom: entry.version,
    versionTo: 0
  };
  changes.set(change.id, change);

  return configs.delete(entry.id);
}

/**
 * Rollback configuration
 */
export function rollbackConfig(changeId: string, rolledBackBy: string): ConfigEntry | null {
  const change = changes.get(changeId);
  if (!change || !change.rollback?.available) return null;

  const entry = Array.from(configs.values()).find(c => c.key === change.key);
  if (!entry) return null;

  // Record rollback
  const rollbackChange: ConfigChange = {
    id: `change_${generateUUID()}`,
    key: change.key,
    oldValue: entry.value,
    newValue: change.oldValue,
    changedBy: rolledBackBy,
    changedAt: Date.now(),
    reason: `Rollback to version ${change.versionFrom}`,
    versionFrom: entry.version,
    versionTo: entry.version + 1
  };
  changes.set(rollbackChange.id, rollbackChange);

  // Apply rollback
  entry.value = change.oldValue;
  entry.version++;
  entry.updatedAt = Date.now();
  entry.updatedBy = rolledBackBy;
  configs.set(entry.id, entry);

  return entry;
}

/**
 * Set environment value
 */
export function setEnvironmentValue(key: string, environment: string, value: ConfigValue, changedBy: string): ConfigEntry | null {
  const entry = Array.from(configs.values()).find(c => c.key === key);
  if (!entry) return null;

  entry.environments[environment] = value;
  entry.updatedAt = Date.now();
  entry.updatedBy = changedBy;
  configs.set(entry.id, entry);

  return entry;
}

/**
 * Set current environment
 */
export function setCurrentEnvironment(environment: string): void {
  currentEnvironment = environment;
}

/**
 * Get current environment
 */
export function getCurrentEnvironment(): string {
  return currentEnvironment;
}

// ============================================================================
// VALIDATION
// ============================================================================

/**
 * Validate value
 */
function validateValue(value: ConfigValue, validation: ConfigValidation): string | null {
  if (validation.allowedValues && !validation.allowedValues.includes(value)) {
    return `Value not in allowed values: ${validation.allowedValues.join(', ')}`;
  }

  if (typeof value === 'number') {
    if (validation.min !== undefined && value < validation.min) {
      return `Value ${value} is less than minimum ${validation.min}`;
    }
    if (validation.max !== undefined && value > validation.max) {
      return `Value ${value} is greater than maximum ${validation.max}`;
    }
  }

  if (typeof value === 'string') {
    if (validation.minLength !== undefined && value.length < validation.minLength) {
      return `String length ${value.length} is less than minimum ${validation.minLength}`;
    }
    if (validation.maxLength !== undefined && value.length > validation.maxLength) {
      return `String length ${value.length} is greater than maximum ${validation.maxLength}`;
    }
    if (validation.pattern && !new RegExp(validation.pattern).test(value)) {
      return `Value does not match pattern: ${validation.pattern}`;
    }
  }

  return null;
}

/**
 * Get value type
 */
function getValueType(value: ConfigValue): ConfigEntry['type'] {
  if (value === null) return 'string';
  if (Array.isArray(value)) return 'array';
  if (typeof value === 'object') return 'object';
  return typeof value as ConfigEntry['type'];
}

// ============================================================================
// FEATURE FLAGS
// ============================================================================

/**
 * Create feature flag
 */
export function createFeatureFlag(config: {
  name: string;
  key: string;
  description: string;
  module: string;
  variants: Omit<FlagVariant, 'id'>[];
  defaultVariant: string;
  createdBy: string;
}): FeatureFlag {
  const now = Date.now();

  const flag: FeatureFlag = {
    id: `flag_${generateUUID()}`,
    name: config.name,
    key: config.key,
    description: config.description,
    enabled: false,
    targeting: [],
    variants: config.variants.map(v => ({
      id: `variant_${generateUUID()}`,
      ...v
    })),
    defaultVariant: config.defaultVariant,
    module: config.module,
    createdAt: now,
    updatedAt: now,
    createdBy: config.createdBy
  };

  featureFlags.set(flag.id, flag);
  return flag;
}

/**
 * Get feature flag
 */
export function getFeatureFlag(key: string): FeatureFlag | undefined {
  return Array.from(featureFlags.values()).find(f => f.key === key);
}

/**
 * Evaluate feature flag
 */
export function evaluateFeatureFlag(key: string, context?: Record<string, ConfigValue>): {
  enabled: boolean;
  variant: FlagVariant;
  reason: string;
} {
  const flag = Array.from(featureFlags.values()).find(f => f.key === key);

  if (!flag) {
    return {
      enabled: false,
      variant: { id: 'default', name: 'Default', key: 'default', value: false, description: 'Default variant' },
      reason: 'Flag not found'
    };
  }

  if (!flag.enabled) {
    const defaultVariant = flag.variants.find(v => v.key === flag.defaultVariant) || flag.variants[0];
    return {
      enabled: false,
      variant: defaultVariant,
      reason: 'Flag is disabled'
    };
  }

  // Check targeting rules
  const sortedRules = [...flag.targeting].sort((a, b) => b.priority - a.priority);

  for (const rule of sortedRules) {
    if (evaluateTargeting(rule.conditions, context || {})) {
      // Check rollout percentage
      const hash = sha256Hash(`${key}-${context?.userId || 'anonymous'}`);
      const hashNum = parseInt(hash.substring(0, 8), 16);
      const percentage = (hashNum % 100) + 1;

      if (percentage <= rule.rolloutPercentage) {
        const variant = flag.variants.find(v => v.key === rule.variant);
        if (variant) {
          return {
            enabled: true,
            variant,
            reason: `Matched targeting rule: ${rule.name}`
          };
        }
      }
    }
  }

  // Return default variant
  const defaultVariant = flag.variants.find(v => v.key === flag.defaultVariant) || flag.variants[0];
  return {
    enabled: true,
    variant: defaultVariant,
    reason: 'Default variant'
  };
}

/**
 * Evaluate targeting conditions
 */
function evaluateTargeting(conditions: TargetingCondition[], context: Record<string, ConfigValue>): boolean {
  for (const condition of conditions) {
    const contextValue = context[condition.attribute];

    switch (condition.operator) {
      case 'eq':
        if (contextValue !== condition.value) return false;
        break;
      case 'neq':
        if (contextValue === condition.value) return false;
        break;
      case 'contains':
        if (typeof contextValue !== 'string' || !contextValue.includes(condition.value as string)) return false;
        break;
      case 'matches':
        if (typeof contextValue !== 'string' || !new RegExp(condition.value as string).test(contextValue)) return false;
        break;
      case 'in':
        if (!Array.isArray(condition.value) || !condition.value.includes(contextValue)) return false;
        break;
      case 'gt':
        if (typeof contextValue !== 'number' || contextValue <= (condition.value as number)) return false;
        break;
      case 'lt':
        if (typeof contextValue !== 'number' || contextValue >= (condition.value as number)) return false;
        break;
      case 'gte':
        if (typeof contextValue !== 'number' || contextValue < (condition.value as number)) return false;
        break;
      case 'lte':
        if (typeof contextValue !== 'number' || contextValue > (condition.value as number)) return false;
        break;
    }
  }

  return true;
}

/**
 * Add targeting rule to flag
 */
export function addTargetingRule(flagKey: string, rule: Omit<TargetingRule, 'id'>): TargetingRule | null {
  const flag = getFeatureFlag(flagKey);
  if (!flag) return null;

  const newRule: TargetingRule = {
    id: `rule_${generateUUID()}`,
    ...rule
  };

  flag.targeting.push(newRule);
  flag.updatedAt = Date.now();
  featureFlags.set(flag.id, flag);

  return newRule;
}

/**
 * Enable/disable feature flag
 */
export function setFeatureFlagEnabled(key: string, enabled: boolean): FeatureFlag | null {
  const flag = getFeatureFlag(key);
  if (!flag) return null;

  flag.enabled = enabled;
  flag.updatedAt = Date.now();
  featureFlags.set(flag.id, flag);

  return flag;
}

/**
 * List feature flags
 */
export function listFeatureFlags(module?: string): FeatureFlag[] {
  const all = Array.from(featureFlags.values());
  return module ? all.filter(f => f.module === module) : all;
}

/**
 * Delete feature flag
 */
export function deleteFeatureFlag(key: string): boolean {
  const flag = Array.from(featureFlags.values()).find(f => f.key === key);
  return flag ? featureFlags.delete(flag.id) : false;
}

// ============================================================================
// A/B TESTING
// ============================================================================

/**
 * Create A/B test
 */
export function createABTest(config: {
  name: string;
  key: string;
  description: string;
  configKey: string;
  module: string;
  variants: Omit<ABTestVariant, 'id'>[];
  controlVariant: string;
  trafficAllocation?: number;
  targeting?: TargetingRule[];
  createdBy: string;
}): ABTest {
  const now = Date.now();

  const test: ABTest = {
    id: `test_${generateUUID()}`,
    name: config.name,
    key: config.key,
    description: config.description,
    configKey: config.configKey,
    module: config.module,
    variants: config.variants.map(v => ({
      id: `variant_${generateUUID()}`,
      ...v
    })),
    controlVariant: config.controlVariant,
    trafficAllocation: config.trafficAllocation ?? 100,
    status: 'draft',
    targeting: config.targeting || [],
    createdAt: now,
    updatedAt: now,
    createdBy: config.createdBy
  };

  abTests.set(test.id, test);
  return test;
}

/**
 * Start A/B test
 */
export function startABTest(testKey: string): ABTest | null {
  const test = Array.from(abTests.values()).find(t => t.key === testKey);
  if (!test || test.status !== 'draft') return null;

  test.status = 'running';
  test.startedAt = Date.now();
  test.updatedAt = Date.now();
  abTests.set(test.id, test);

  return test;
}

/**
 * Stop A/B test
 */
export function stopABTest(testKey: string): ABTest | null {
  const test = Array.from(abTests.values()).find(t => t.key === testKey);
  if (!test || test.status !== 'running') return null;

  test.status = 'completed';
  test.endedAt = Date.now();
  test.updatedAt = Date.now();
  abTests.set(test.id, test);

  return test;
}

/**
 * Get variant for A/B test
 */
export function getABTestVariant(testKey: string, entityId: string, context?: Record<string, ConfigValue>): ABTestVariant | null {
  const test = Array.from(abTests.values()).find(t => t.key === testKey);

  if (!test || test.status !== 'running') return null;

  // Check targeting
  if (test.targeting.length > 0) {
    const sortedRules = [...test.targeting].sort((a, b) => b.priority - a.priority);
    let matched = false;
    for (const rule of sortedRules) {
      if (evaluateTargeting(rule.conditions, context || {})) {
        matched = true;
        break;
      }
    }
    if (!matched) return null;
  }

  // Check traffic allocation
  const hash = sha256Hash(`${testKey}-${entityId}`);
  const hashNum = parseInt(hash.substring(0, 8), 16);
  const percentage = (hashNum % 100) + 1;

  if (percentage > test.trafficAllocation) {
    return null;
  }

  // Determine variant based on traffic percentages
  let cumulative = 0;
  for (const variant of test.variants) {
    cumulative += variant.trafficPercentage;
    if (percentage <= cumulative) {
      // Record exposure
      recordExposure(test.id, variant.key, entityId, context);
      return variant;
    }
  }

  // Return control
  const control = test.variants.find(v => v.key === test.controlVariant);
  if (control) {
    recordExposure(test.id, control.key, entityId, context);
  }
  return control || null;
}

/**
 * Record exposure
 */
function recordExposure(testId: string, variantKey: string, entityId: string, context?: Record<string, ConfigValue>): void {
  const exposure: ABTestExposure = {
    id: `exposure_${generateUUID()}`,
    testId,
    variantKey,
    entityId,
    entityAttributes: context || {},
    exposedAt: Date.now(),
    converted: false
  };

  exposures.set(exposure.id, exposure);
}

/**
 * Record conversion
 */
export function recordConversion(testKey: string, entityId: string): boolean {
  const test = Array.from(abTests.values()).find(t => t.key === testKey);
  if (!test) return false;

  // Find exposure for this entity
  const exposure = Array.from(exposures.values()).find(
    e => e.testId === test.id && e.entityId === entityId && !e.converted
  );

  if (!exposure) return false;

  exposure.converted = true;
  exposure.convertedAt = Date.now();
  exposures.set(exposure.id, exposure);

  return true;
}

/**
 * Get A/B test results
 */
export function getABTestResults(testKey: string): ABTestResult | null {
  const test = Array.from(abTests.values()).find(t => t.key === testKey);
  if (!test) return null;

  const testExposures = Array.from(exposures.values()).filter(e => e.testId === test.id);
  const totalExposures = testExposures.length;

  const variantResults: ABTestResult['variants'] = {};

  for (const variant of test.variants) {
    const variantExposures = testExposures.filter(e => e.variantKey === variant.key);
    const conversions = variantExposures.filter(e => e.converted).length;
    const conversionRate = variantExposures.length > 0 ? conversions / variantExposures.length : 0;

    variantResults[variant.key] = {
      exposures: variantExposures.length,
      conversions,
      conversionRate,
      confidence: calculateConfidence(variantExposures.length, conversions),
      isWinner: false
    };
  }

  // Find winner (highest conversion rate with statistical significance)
  let winner: string | undefined;
  let highestRate = 0;
  for (const [key, result] of Object.entries(variantResults)) {
    if (result.conversionRate > highestRate && result.confidence > 0.95) {
      highestRate = result.conversionRate;
      winner = key;
    }
  }

  if (winner) {
    variantResults[winner].isWinner = true;
  }

  const result: ABTestResult = {
    totalExposures,
    variants: variantResults,
    winner,
    statisticalSignificance: calculateOverallSignificance(variantResults)
  };

  // Store results
  test.results = result;
  abTests.set(test.id, test);

  return result;
}

/**
 * Calculate confidence (simplified)
 */
function calculateConfidence(exposures: number, conversions: number): number {
  if (exposures < 30) return 0;
  // Simplified confidence calculation
  const rate = conversions / exposures;
  const stdErr = Math.sqrt(rate * (1 - rate) / exposures);
  return Math.min(0.99, rate / (stdErr + 0.01));
}

/**
 * Calculate overall statistical significance
 */
function calculateOverallSignificance(variantResults: ABTestResult['variants']): number {
  const rates = Object.values(variantResults).map(v => v.conversionRate);
  if (rates.length < 2) return 0;
  
  const maxRate = Math.max(...rates);
  const minRate = Math.min(...rates);
  
  return Math.min(0.99, (maxRate - minRate) * 2);
}

/**
 * Get A/B test
 */
export function getABTest(key: string): ABTest | undefined {
  return Array.from(abTests.values()).find(t => t.key === key);
}

/**
 * List A/B tests
 */
export function listABTests(module?: string): ABTest[] {
  const all = Array.from(abTests.values());
  return module ? all.filter(t => t.module === module) : all;
}

/**
 * Delete A/B test
 */
export function deleteABTest(key: string): boolean {
  const test = Array.from(abTests.values()).find(t => t.key === key);
  return test ? abTests.delete(test.id) : false;
}

// ============================================================================
// SNAPSHOTS
// ============================================================================

/**
 * Create configuration snapshot
 */
export function createSnapshot(config: {
  name: string;
  description: string;
  modules?: string[];
  createdBy: string;
}): ConfigSnapshot {
  const modulesToInclude = config.modules || Array.from(new Set(Array.from(configs.values()).map(c => c.module)));

  const data: Record<string, ConfigValue> = {};
  for (const entry of configs.values()) {
    if (modulesToInclude.includes(entry.module)) {
      data[entry.key] = entry.environments[currentEnvironment] ?? entry.value;
    }
  }

  const snapshot: ConfigSnapshot = {
    id: `snapshot_${generateUUID()}`,
    name: config.name,
    description: config.description,
    data,
    modules: modulesToInclude,
    createdAt: Date.now(),
    createdBy: config.createdBy,
    environment: currentEnvironment
  };

  snapshots.set(snapshot.id, snapshot);
  return snapshot;
}

/**
 * Restore from snapshot
 */
export function restoreSnapshot(snapshotId: string, restoredBy: string): boolean {
  const snapshot = snapshots.get(snapshotId);
  if (!snapshot) return false;

  for (const [key, value] of Object.entries(snapshot.data)) {
    const entry = Array.from(configs.values()).find(c => c.key === key);
    if (entry) {
      entry.value = value;
      entry.version++;
      entry.updatedAt = Date.now();
      entry.updatedBy = restoredBy;
      configs.set(entry.id, entry);
    }
  }

  return true;
}

/**
 * Get snapshot
 */
export function getSnapshot(snapshotId: string): ConfigSnapshot | undefined {
  return snapshots.get(snapshotId);
}

/**
 * List snapshots
 */
export function listSnapshots(): ConfigSnapshot[] {
  return Array.from(snapshots.values());
}

// ============================================================================
// ENVIRONMENT MANAGEMENT
// ============================================================================

/**
 * Create environment
 */
export function createEnvironment(config: {
  name: string;
  key: string;
  description: string;
  isProduction?: boolean;
  parentEnvironment?: string;
}): Environment {
  const environment: Environment = {
    id: `env_${generateUUID()}`,
    name: config.name,
    key: config.key,
    description: config.description,
    isProduction: config.isProduction ?? false,
    parentEnvironment: config.parentEnvironment,
    createdAt: Date.now()
  };

  environments.set(environment.id, environment);
  return environment;
}

/**
 * List environments
 */
export function listEnvironments(): Environment[] {
  return Array.from(environments.values());
}

/**
 * Delete environment
 */
export function deleteEnvironment(key: string): boolean {
  const env = Array.from(environments.values()).find(e => e.key === key);
  if (!env || env.isProduction) return false;
  return environments.delete(env.id);
}

// ============================================================================
// STATISTICS
// ============================================================================

/**
 * Get configuration statistics
 */
export function getConfigStats(): {
  totalConfigs: number;
  totalFeatureFlags: number;
  totalABTests: number;
  runningABTests: number;
  totalSnapshots: number;
  configsByModule: Record<string, number>;
  configsByEnvironment: Record<string, number>;
} {
  const allConfigs = Array.from(configs.values());
  const allTests = Array.from(abTests.values());

  const configsByModule: Record<string, number> = {};
  const configsByEnvironment: Record<string, number> = {};

  for (const config of allConfigs) {
    configsByModule[config.module] = (configsByModule[config.module] || 0) + 1;
    for (const env of Object.keys(config.environments)) {
      configsByEnvironment[env] = (configsByEnvironment[env] || 0) + 1;
    }
  }

  return {
    totalConfigs: allConfigs.length,
    totalFeatureFlags: featureFlags.size,
    totalABTests: allTests.length,
    runningABTests: allTests.filter(t => t.status === 'running').length,
    totalSnapshots: snapshots.size,
    configsByModule,
    configsByEnvironment
  };
}

// ============================================================================
// TEST SUITE
// ============================================================================

/**
 * Run configuration management tests
 */
export function runConfigurationManagementTests(): {
  passed: boolean;
  tests: { total: number; passed: number; failed: number };
  results: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const results: Array<{ name: string; passed: boolean; error?: string }> = [];

  try {
    // Test 1: Set configuration
    const config = setConfig({
      key: 'test.threshold',
      value: 0.85,
      module: 'test',
      category: 'thresholds',
      description: 'Test threshold',
      validation: { min: 0, max: 1 },
      changedBy: 'tester'
    });
    results.push({ name: 'Set Configuration', passed: !!config.id && config.value === 0.85 });

    // Test 2: Get configuration
    const retrieved = getConfig<number>('test.threshold');
    results.push({ name: 'Get Configuration', passed: retrieved === 0.85 });

    // Test 3: Update configuration
    const updated = setConfig({
      key: 'test.threshold',
      value: 0.90,
      module: 'test',
      changedBy: 'tester',
      reason: 'Updated for testing'
    });
    results.push({ name: 'Update Configuration', passed: updated.version === 2 && updated.value === 0.90 });

    // Test 4: Create feature flag
    const flag = createFeatureFlag({
      name: 'Test Flag',
      key: 'test.flag',
      description: 'Test feature flag',
      module: 'test',
      variants: [
        { name: 'Enabled', key: 'enabled', value: true, description: 'Enabled state' },
        { name: 'Disabled', key: 'disabled', value: false, description: 'Disabled state' }
      ],
      defaultVariant: 'disabled',
      createdBy: 'tester'
    });
    results.push({ name: 'Create Feature Flag', passed: !!flag.id && flag.variants.length === 2 });

    // Test 5: Evaluate feature flag (disabled)
    const evalDisabled = evaluateFeatureFlag('test.flag', { userId: 'user1' });
    results.push({ name: 'Evaluate Feature Flag (Disabled)', passed: !evalDisabled.enabled });

    // Test 6: Enable and evaluate feature flag
    setFeatureFlagEnabled('test.flag', true);
    const evalEnabled = evaluateFeatureFlag('test.flag', { userId: 'user1' });
    results.push({ name: 'Evaluate Feature Flag (Enabled)', passed: evalEnabled.enabled });

    // Test 7: Create A/B test
    const abTest = createABTest({
      name: 'Test A/B',
      key: 'test.ab',
      description: 'Test A/B test',
      configKey: 'test.threshold',
      module: 'test',
      variants: [
        { name: 'Control', key: 'control', value: 0.85, trafficPercentage: 50, isControl: true },
        { name: 'Variant A', key: 'variant_a', value: 0.90, trafficPercentage: 50, isControl: false }
      ],
      controlVariant: 'control',
      createdBy: 'tester'
    });
    results.push({ name: 'Create A/B Test', passed: !!abTest.id && abTest.status === 'draft' });

    // Test 8: Start A/B test
    startABTest('test.ab');
    const started = getABTest('test.ab');
    results.push({ name: 'Start A/B Test', passed: started?.status === 'running' });

    // Test 9: Get A/B test variant
    const variant = getABTestVariant('test.ab', 'user1');
    results.push({ name: 'Get A/B Test Variant', passed: variant !== null });

    // Test 10: Create snapshot
    const snapshot = createSnapshot({
      name: 'Test Snapshot',
      description: 'Test configuration snapshot',
      modules: ['test'],
      createdBy: 'tester'
    });
    results.push({ name: 'Create Snapshot', passed: !!snapshot.id && 'test.threshold' in snapshot.data });

    // Test 11: List environments
    const envList = listEnvironments();
    results.push({ name: 'List Environments', passed: envList.length >= 3 });

    // Test 12: Get statistics
    const stats = getConfigStats();
    results.push({ name: 'Get Statistics', passed: stats.totalConfigs >= 1 && stats.totalFeatureFlags >= 1 });

  } catch (error) {
    results.push({ name: 'Test Execution', passed: false, error: String(error) });
  }

  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;

  return {
    passed: failed === 0,
    tests: { total: results.length, passed, failed },
    results
  };
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

export default {
  setConfig,
  getConfig,
  getConfigEntry,
  getModuleConfigs,
  deleteConfig,
  rollbackConfig,
  setEnvironmentValue,
  setCurrentEnvironment,
  getCurrentEnvironment,
  createFeatureFlag,
  getFeatureFlag,
  evaluateFeatureFlag,
  addTargetingRule,
  setFeatureFlagEnabled,
  listFeatureFlags,
  deleteFeatureFlag,
  createABTest,
  startABTest,
  stopABTest,
  getABTestVariant,
  recordConversion,
  getABTestResults,
  getABTest,
  listABTests,
  deleteABTest,
  createSnapshot,
  restoreSnapshot,
  getSnapshot,
  listSnapshots,
  createEnvironment,
  listEnvironments,
  deleteEnvironment,
  getConfigStats,
  runConfigurationManagementTests
};
