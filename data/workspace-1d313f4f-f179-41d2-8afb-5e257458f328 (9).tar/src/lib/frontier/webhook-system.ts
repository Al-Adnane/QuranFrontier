/**
 * Webhook System Module
 *
 * Real-time alerts for frontier events with external system integration.
 * Event-driven architecture with retry logic and delivery tracking.
 *
 * @module frontier/webhook-system
 * @version 8.1.0
 *
 * Capabilities:
 * - Real-time event webhooks
 * - Multiple endpoint support
 * - Retry with exponential backoff
 * - Event filtering and routing
 * - Delivery tracking
 * - Signature verification
 * - Batch webhooks
 * - Custom payloads
 */

import { generateUUID, sha256Hash, hmacSign } from '../crypto-utils';

// ============================================================================
// TYPES
// ============================================================================

/**
 * Webhook endpoint
 */
export interface WebhookEndpoint {
  /** Endpoint ID */
  id: string;
  /** Endpoint name */
  name: string;
  /** Endpoint URL */
  url: string;
  /** HTTP method */
  method: 'POST' | 'PUT' | 'GET';
  /** Content type */
  contentType: 'json' | 'xml' | 'form';
  /** Secret for signature */
  secret: string;
  /** Enabled status */
  enabled: boolean;
  /** Events to subscribe */
  events: string[];
  /** Event filters */
  filters: WebhookFilter[];
  /** Headers to include */
  headers: Record<string, string>;
  /** Authentication */
  auth?: {
    type: 'basic' | 'bearer' | 'api_key' | 'oauth2';
    credentials: Record<string, string>;
  };
  /** Retry configuration */
  retryConfig: {
    maxRetries: number;
    initialDelayMs: number;
    maxDelayMs: number;
    backoffMultiplier: number;
  };
  /** Timeout in ms */
  timeoutMs: number;
  /** Created timestamp */
  createdAt: number;
  /** Updated timestamp */
  updatedAt: number;
  /** Owner */
  ownerId: string;
  /** Status */
  status: 'active' | 'disabled' | 'failed' | 'pending_verification';
  /** Verification token */
  verificationToken?: string;
}

/**
 * Webhook filter
 */
export interface WebhookFilter {
  /** Field to filter on */
  field: string;
  /** Operator */
  operator: 'eq' | 'neq' | 'contains' | 'matches' | 'gt' | 'lt' | 'in';
  /** Value */
  value: string | number | string[];
}

/**
 * Webhook event
 */
export interface WebhookEvent {
  /** Event ID */
  id: string;
  /** Event type */
  type: string;
  /** Event category */
  category: 'detection' | 'alert' | 'system' | 'compliance' | 'security' | 'custom';
  /** Event source module */
  source: string;
  /** Event payload */
  payload: Record<string, unknown>;
  /** Event timestamp */
  timestamp: number;
  /** Severity */
  severity: 'info' | 'warning' | 'error' | 'critical';
  /** Correlation ID */
  correlationId?: string;
  /** Metadata */
  metadata: Record<string, unknown>;
}

/**
 * Webhook delivery
 */
export interface WebhookDelivery {
  /** Delivery ID */
  id: string;
  /** Webhook endpoint ID */
  endpointId: string;
  /** Event ID */
  eventId: string;
  /** Delivery status */
  status: 'pending' | 'sent' | 'failed' | 'retrying' | 'delivered';
  /** Attempt count */
  attemptCount: number;
  /** Last attempt timestamp */
  lastAttemptAt?: number;
  /** Next retry timestamp */
  nextRetryAt?: number;
  /** Response status code */
  responseStatusCode?: number;
  /** Response body */
  responseBody?: string;
  /** Response headers */
  responseHeaders?: Record<string, string>;
  /** Error message */
  error?: string;
  /** Request duration ms */
  durationMs?: number;
  /** Created timestamp */
  createdAt: number;
  /** Delivered timestamp */
  deliveredAt?: number;
  /** Request signature */
  requestSignature: string;
  /** Request body */
  requestBody: string;
}

/**
 * Webhook batch
 */
export interface WebhookBatch {
  /** Batch ID */
  id: string;
  /** Endpoint ID */
  endpointId: string;
  /** Event IDs in batch */
  eventIds: string[];
  /** Batch status */
  status: 'pending' | 'processing' | 'completed' | 'failed';
  /** Created timestamp */
  createdAt: number;
  /** Processed timestamp */
  processedAt?: number;
  /** Delivery count */
  deliveryCount: number;
}

/**
 * Webhook statistics
 */
export interface WebhookStats {
  /** Total events */
  totalEvents: number;
  /** Total deliveries */
  totalDeliveries: number;
  /** Successful deliveries */
  successfulDeliveries: number;
  /** Failed deliveries */
  failedDeliveries: number;
  /** Pending deliveries */
  pendingDeliveries: number;
  /** Average delivery time ms */
  avgDeliveryTimeMs: number;
  /** Success rate */
  successRate: number;
  /** By endpoint */
  byEndpoint: Record<string, {
    total: number;
    successful: number;
    failed: number;
    avgTimeMs: number;
  }>;
  /** By event type */
  byEventType: Record<string, number>;
  /** Last 24 hours */
  last24h: {
    events: number;
    deliveries: number;
    successRate: number;
  };
}

/**
 * Event subscription
 */
export interface EventSubscription {
  /** Subscription ID */
  id: string;
  /** Endpoint ID */
  endpointId: string;
  /** Event type pattern */
  eventType: string;
  /** Filter conditions */
  filters: WebhookFilter[];
  /** Transform template */
  transformTemplate?: string;
  /** Enabled */
  enabled: boolean;
  /** Priority */
  priority: number;
  /** Created timestamp */
  createdAt: number;
}

// ============================================================================
// STORAGE
// ============================================================================

const endpoints = new Map<string, WebhookEndpoint>();
const events = new Map<string, WebhookEvent>();
const deliveries = new Map<string, WebhookDelivery>();
const batches = new Map<string, WebhookBatch>();
const subscriptions = new Map<string, EventSubscription>();

// Delivery queue
const deliveryQueue: string[] = [];

// Stats tracking
let stats: WebhookStats = {
  totalEvents: 0,
  totalDeliveries: 0,
  successfulDeliveries: 0,
  failedDeliveries: 0,
  pendingDeliveries: 0,
  avgDeliveryTimeMs: 0,
  successRate: 0,
  byEndpoint: {},
  byEventType: {},
  last24h: { events: 0, deliveries: 0, successRate: 0 }
};

// Platform secret
const PLATFORM_SECRET = 'webhook_system_secret_v1';

// ============================================================================
// ENDPOINT MANAGEMENT
// ============================================================================

/**
 * Create webhook endpoint
 */
export function createEndpoint(config: {
  name: string;
  url: string;
  method?: 'POST' | 'PUT' | 'GET';
  contentType?: 'json' | 'xml' | 'form';
  events: string[];
  secret?: string;
  headers?: Record<string, string>;
  auth?: WebhookEndpoint['auth'];
  retryConfig?: Partial<WebhookEndpoint['retryConfig']>;
  timeoutMs?: number;
  ownerId: string;
}): WebhookEndpoint {
  const id = `endpoint_${generateUUID()}`;
  const now = Date.now();

  const endpoint: WebhookEndpoint = {
    id,
    name: config.name,
    url: config.url,
    method: config.method || 'POST',
    contentType: config.contentType || 'json',
    secret: config.secret || generateUUID(),
    enabled: true,
    events: config.events,
    filters: [],
    headers: config.headers || {},
    auth: config.auth,
    retryConfig: {
      maxRetries: config.retryConfig?.maxRetries ?? 3,
      initialDelayMs: config.retryConfig?.initialDelayMs ?? 1000,
      maxDelayMs: config.retryConfig?.maxDelayMs ?? 30000,
      backoffMultiplier: config.retryConfig?.backoffMultiplier ?? 2
    },
    timeoutMs: config.timeoutMs || 30000,
    createdAt: now,
    updatedAt: now,
    ownerId: config.ownerId,
    status: 'pending_verification',
    verificationToken: generateUUID()
  };

  endpoints.set(id, endpoint);
  return endpoint;
}

/**
 * Get endpoint
 */
export function getEndpoint(endpointId: string): WebhookEndpoint | undefined {
  return endpoints.get(endpointId);
}

/**
 * List endpoints
 */
export function listEndpoints(ownerId?: string): WebhookEndpoint[] {
  const all = Array.from(endpoints.values());
  return ownerId ? all.filter(e => e.ownerId === ownerId) : all;
}

/**
 * Update endpoint
 */
export function updateEndpoint(
  endpointId: string,
  updates: Partial<WebhookEndpoint>
): WebhookEndpoint | null {
  const endpoint = endpoints.get(endpointId);
  if (!endpoint) return null;

  const protectedFields = ['id', 'createdAt', 'secret', 'verificationToken'];
  for (const key of Object.keys(updates)) {
    if (!protectedFields.includes(key)) {
      (endpoint as Record<string, unknown>)[key] = updates[key as keyof WebhookEndpoint];
    }
  }

  endpoint.updatedAt = Date.now();
  endpoints.set(endpointId, endpoint);
  return endpoint;
}

/**
 * Delete endpoint
 */
export function deleteEndpoint(endpointId: string): boolean {
  return endpoints.delete(endpointId);
}

/**
 * Verify endpoint
 */
export function verifyEndpoint(endpointId: string, token: string): boolean {
  const endpoint = endpoints.get(endpointId);
  if (!endpoint) return false;

  if (endpoint.verificationToken === token) {
    endpoint.status = 'active';
    endpoint.verificationToken = undefined;
    endpoints.set(endpointId, endpoint);
    return true;
  }

  return false;
}

/**
 * Enable/disable endpoint
 */
export function setEndpointEnabled(endpointId: string, enabled: boolean): WebhookEndpoint | null {
  const endpoint = endpoints.get(endpointId);
  if (!endpoint) return null;

  endpoint.enabled = enabled;
  endpoint.status = enabled ? 'active' : 'disabled';
  endpoint.updatedAt = Date.now();
  endpoints.set(endpointId, endpoint);
  return endpoint;
}

// ============================================================================
// EVENT MANAGEMENT
// ============================================================================

/**
 * Emit event
 */
export function emitEvent(config: {
  type: string;
  category: WebhookEvent['category'];
  source: string;
  payload: Record<string, unknown>;
  severity?: WebhookEvent['severity'];
  correlationId?: string;
  metadata?: Record<string, unknown>;
}): WebhookEvent {
  const event: WebhookEvent = {
    id: `event_${generateUUID()}`,
    type: config.type,
    category: config.category,
    source: config.source,
    payload: config.payload,
    timestamp: Date.now(),
    severity: config.severity || 'info',
    correlationId: config.correlationId,
    metadata: config.metadata || {}
  };

  events.set(event.id, event);

  // Update stats
  stats.totalEvents++;
  stats.byEventType[config.type] = (stats.byEventType[config.type] || 0) + 1;
  stats.last24h.events++;

  // Trigger webhooks
  triggerWebhooks(event);

  return event;
}

/**
 * Get event
 */
export function getEvent(eventId: string): WebhookEvent | undefined {
  return events.get(eventId);
}

/**
 * List events
 */
export function listEvents(filters?: {
  type?: string;
  category?: WebhookEvent['category'];
  source?: string;
  severity?: WebhookEvent['severity'];
  since?: number;
  limit?: number;
}): WebhookEvent[] {
  let result = Array.from(events.values());

  if (filters) {
    if (filters.type) result = result.filter(e => e.type === filters.type);
    if (filters.category) result = result.filter(e => e.category === filters.category);
    if (filters.source) result = result.filter(e => e.source === filters.source);
    if (filters.severity) result = result.filter(e => e.severity === filters.severity);
    if (filters.since) result = result.filter(e => e.timestamp >= filters.since!);
  }

  result.sort((a, b) => b.timestamp - a.timestamp);

  if (filters?.limit) {
    result = result.slice(0, filters.limit);
  }

  return result;
}

// ============================================================================
// WEBHOOK TRIGGERING
// ============================================================================

/**
 * Trigger webhooks for event
 */
function triggerWebhooks(event: WebhookEvent): void {
  for (const endpoint of endpoints.values()) {
    if (!endpoint.enabled || endpoint.status !== 'active') continue;

    // Check if endpoint subscribes to this event type
    const matches = endpoint.events.some(pattern => {
      if (pattern === '*') return true;
      if (pattern.endsWith('*')) {
        return event.type.startsWith(pattern.slice(0, -1));
      }
      return pattern === event.type;
    });

    if (!matches) continue;

    // Check filters
    if (!matchesFilters(event, endpoint.filters)) continue;

    // Create delivery
    createDelivery(endpoint, event);
  }
}

/**
 * Check if event matches filters
 */
function matchesFilters(event: WebhookEvent, filters: WebhookFilter[]): boolean {
  if (filters.length === 0) return true;

  for (const filter of filters) {
    const value = getNestedValue(event, filter.field);

    let matches = false;
    switch (filter.operator) {
      case 'eq':
        matches = value === filter.value;
        break;
      case 'neq':
        matches = value !== filter.value;
        break;
      case 'contains':
        matches = typeof value === 'string' && value.includes(filter.value as string);
        break;
      case 'matches':
        matches = typeof value === 'string' && new RegExp(filter.value as string).test(value);
        break;
      case 'gt':
        matches = typeof value === 'number' && value > (filter.value as number);
        break;
      case 'lt':
        matches = typeof value === 'number' && value < (filter.value as number);
        break;
      case 'in':
        matches = Array.isArray(filter.value) && filter.value.includes(value);
        break;
    }

    if (!matches) return false;
  }

  return true;
}

/**
 * Get nested value from object
 */
function getNestedValue(obj: unknown, path: string): unknown {
  const parts = path.split('.');
  let current: unknown = obj;

  for (const part of parts) {
    if (current && typeof current === 'object') {
      current = (current as Record<string, unknown>)[part];
    } else {
      return undefined;
    }
  }

  return current;
}

/**
 * Create delivery
 */
function createDelivery(endpoint: WebhookEndpoint, event: WebhookEvent): WebhookDelivery {
  const id = `delivery_${generateUUID()}`;
  const now = Date.now();

  // Build request body
  const requestBody = buildRequestBody(endpoint, event);
  const requestSignature = signPayload(requestBody, endpoint.secret);

  const delivery: WebhookDelivery = {
    id,
    endpointId: endpoint.id,
    eventId: event.id,
    status: 'pending',
    attemptCount: 0,
    createdAt: now,
    requestSignature,
    requestBody
  };

  deliveries.set(id, delivery);

  // Update stats
  stats.totalDeliveries++;
  stats.pendingDeliveries++;

  if (!stats.byEndpoint[endpoint.id]) {
    stats.byEndpoint[endpoint.id] = { total: 0, successful: 0, failed: 0, avgTimeMs: 0 };
  }
  stats.byEndpoint[endpoint.id].total++;

  // Add to queue
  deliveryQueue.push(id);

  // Process delivery (async simulation)
  processDelivery(delivery.id);

  return delivery;
}

/**
 * Build request body
 */
function buildRequestBody(endpoint: WebhookEndpoint, event: WebhookEvent): string {
  const payload = {
    id: event.id,
    type: event.type,
    category: event.category,
    source: event.source,
    timestamp: event.timestamp,
    severity: event.severity,
    correlationId: event.correlationId,
    data: event.payload,
    metadata: event.metadata
  };

  switch (endpoint.contentType) {
    case 'json':
      return JSON.stringify(payload);
    case 'xml':
      return jsonToXml(payload);
    case 'form':
      return new URLSearchParams(flattenObject(payload)).toString();
    default:
      return JSON.stringify(payload);
  }
}

/**
 * Sign payload
 */
function signPayload(payload: string, secret: string): string {
  return hmacSign(payload, secret);
}

/**
 * Flatten object for form encoding
 */
function flattenObject(obj: unknown, prefix = ''): Record<string, string> {
  const result: Record<string, string> = {};

  if (obj && typeof obj === 'object') {
    for (const [key, value] of Object.entries(obj as Record<string, unknown>)) {
      const newKey = prefix ? `${prefix}.${key}` : key;
      if (value && typeof value === 'object' && !Array.isArray(value)) {
        Object.assign(result, flattenObject(value, newKey));
      } else {
        result[newKey] = String(value);
      }
    }
  }

  return result;
}

/**
 * Convert JSON to XML
 */
function jsonToXml(obj: unknown, rootName = 'webhook'): string {
  let xml = `<?xml version="1.0" encoding="UTF-8"?><${rootName}>`;

  function toXml(value: unknown, name: string): string {
    if (value === null || value === undefined) {
      return `<${name}/>`;
    } else if (typeof value === 'object') {
      if (Array.isArray(value)) {
        return value.map(item => toXml(item, name)).join('');
      } else {
        let inner = '';
        for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
          inner += toXml(v, k);
        }
        return `<${name}>${inner}</${name}>`;
      }
    } else {
      return `<${name}>${String(value)}</${name}>`;
    }
  }

  if (obj && typeof obj === 'object') {
    for (const [key, value] of Object.entries(obj as Record<string, unknown>)) {
      xml += toXml(value, key);
    }
  }

  xml += `</${rootName}>`;
  return xml;
}

// ============================================================================
// DELIVERY PROCESSING
// ============================================================================

/**
 * Process delivery (simulated)
 */
async function processDelivery(deliveryId: string): Promise<void> {
  const delivery = deliveries.get(deliveryId);
  if (!delivery) return;

  const endpoint = endpoints.get(delivery.endpointId);
  if (!endpoint || !endpoint.enabled) {
    delivery.status = 'failed';
    delivery.error = 'Endpoint not found or disabled';
    deliveries.set(deliveryId, delivery);
    return;
  }

  delivery.status = 'retrying';
  delivery.attemptCount++;
  delivery.lastAttemptAt = Date.now();
  deliveries.set(deliveryId, delivery);

  // Simulate HTTP request (in production, use fetch)
  const startTime = Date.now();
  
  // Simulated delivery result
  const success = simulateDelivery(endpoint);
  const durationMs = Date.now() - startTime;

  if (success) {
    delivery.status = 'delivered';
    delivery.responseStatusCode = 200;
    delivery.responseBody = '{"status":"received"}';
    delivery.durationMs = durationMs;
    delivery.deliveredAt = Date.now();

    stats.successfulDeliveries++;
    stats.pendingDeliveries--;
    stats.byEndpoint[endpoint.id].successful++;
  } else {
    delivery.error = 'Connection refused';
    delivery.responseStatusCode = 500;
    delivery.durationMs = durationMs;

    // Check retry
    if (delivery.attemptCount < endpoint.retryConfig.maxRetries) {
      const delay = Math.min(
        endpoint.retryConfig.initialDelayMs * 
        Math.pow(endpoint.retryConfig.backoffMultiplier, delivery.attemptCount - 1),
        endpoint.retryConfig.maxDelayMs
      );
      delivery.nextRetryAt = Date.now() + delay;
      delivery.status = 'retrying';

      // Schedule retry
      setTimeout(() => processDelivery(deliveryId), delay);
    } else {
      delivery.status = 'failed';
      stats.failedDeliveries++;
      stats.pendingDeliveries--;
      stats.byEndpoint[endpoint.id].failed++;

      // Mark endpoint as failed if too many failures
      const recentFailures = Array.from(deliveries.values())
        .filter(d => d.endpointId === endpoint.id && 
                     d.status === 'failed' && 
                     d.createdAt > Date.now() - 3600000)
        .length;
      
      if (recentFailures > 10) {
        endpoint.status = 'failed';
        endpoints.set(endpoint.id, endpoint);
      }
    }
  }

  deliveries.set(deliveryId, delivery);

  // Update average delivery time
  updateAvgDeliveryTime(durationMs);
}

/**
 * Simulate delivery (for testing)
 */
function simulateDelivery(endpoint: WebhookEndpoint): boolean {
  // Simulate 95% success rate
  return Math.random() < 0.95;
}

/**
 * Update average delivery time
 */
function updateAvgDeliveryTime(durationMs: number): void {
  const total = stats.totalDeliveries;
  stats.avgDeliveryTimeMs = ((stats.avgDeliveryTimeMs * (total - 1)) + durationMs) / total;
  stats.successRate = stats.totalDeliveries > 0 
    ? stats.successfulDeliveries / stats.totalDeliveries 
    : 0;
}

/**
 * Get delivery
 */
export function getDelivery(deliveryId: string): WebhookDelivery | undefined {
  return deliveries.get(deliveryId);
}

/**
 * List deliveries
 */
export function listDeliveries(filters?: {
  endpointId?: string;
  eventId?: string;
  status?: WebhookDelivery['status'];
  since?: number;
  limit?: number;
}): WebhookDelivery[] {
  let result = Array.from(deliveries.values());

  if (filters) {
    if (filters.endpointId) result = result.filter(d => d.endpointId === filters.endpointId);
    if (filters.eventId) result = result.filter(d => d.eventId === filters.eventId);
    if (filters.status) result = result.filter(d => d.status === filters.status);
    if (filters.since) result = result.filter(d => d.createdAt >= filters.since!);
  }

  result.sort((a, b) => b.createdAt - a.createdAt);

  if (filters?.limit) {
    result = result.slice(0, filters.limit);
  }

  return result;
}

/**
 * Retry delivery
 */
export function retryDelivery(deliveryId: string): WebhookDelivery | null {
  const delivery = deliveries.get(deliveryId);
  if (!delivery) return null;

  delivery.attemptCount = 0;
  delivery.status = 'pending';
  delivery.error = undefined;
  deliveries.set(deliveryId, delivery);

  processDelivery(deliveryId);
  return delivery;
}

// ============================================================================
// BATCH OPERATIONS
// ============================================================================

/**
 * Create batch
 */
export function createBatch(config: {
  endpointId: string;
  eventIds: string[];
}): WebhookBatch {
  const batch: WebhookBatch = {
    id: `batch_${generateUUID()}`,
    endpointId: config.endpointId,
    eventIds: config.eventIds,
    status: 'pending',
    createdAt: Date.now(),
    deliveryCount: 0
  };

  batches.set(batch.id, batch);
  return batch;
}

/**
 * Process batch
 */
export function processBatch(batchId: string): WebhookBatch | null {
  const batch = batches.get(batchId);
  if (!batch) return null;

  batch.status = 'processing';
  batches.set(batchId, batch);

  const endpoint = endpoints.get(batch.endpointId);
  if (!endpoint) {
    batch.status = 'failed';
    batches.set(batchId, batch);
    return batch;
  }

  // Build batch payload
  const eventsList = batch.eventIds
    .map(id => events.get(id))
    .filter(e => e !== undefined);

  const payload = {
    batchId: batch.id,
    count: eventsList.length,
    events: eventsList.map(e => ({
      id: e!.id,
      type: e!.type,
      timestamp: e!.timestamp,
      data: e!.payload
    }))
  };

  // Create single delivery for batch
  const delivery: WebhookDelivery = {
    id: `delivery_${generateUUID()}`,
    endpointId: endpoint.id,
    eventId: batch.id,
    status: 'pending',
    attemptCount: 0,
    createdAt: Date.now(),
    requestSignature: signPayload(JSON.stringify(payload), endpoint.secret),
    requestBody: JSON.stringify(payload)
  };

  deliveries.set(delivery.id, delivery);
  batch.deliveryCount = 1;
  batch.status = 'completed';
  batch.processedAt = Date.now();
  batches.set(batchId, batch);

  processDelivery(delivery.id);

  return batch;
}

/**
 * Get batch
 */
export function getBatch(batchId: string): WebhookBatch | undefined {
  return batches.get(batchId);
}

// ============================================================================
// SUBSCRIPTIONS
// ============================================================================

/**
 * Create subscription
 */
export function createSubscription(config: {
  endpointId: string;
  eventType: string;
  filters?: WebhookFilter[];
  transformTemplate?: string;
  priority?: number;
}): EventSubscription {
  const subscription: EventSubscription = {
    id: `sub_${generateUUID()}`,
    endpointId: config.endpointId,
    eventType: config.eventType,
    filters: config.filters || [],
    transformTemplate: config.transformTemplate,
    enabled: true,
    priority: config.priority || 0,
    createdAt: Date.now()
  };

  subscriptions.set(subscription.id, subscription);

  // Add event type to endpoint
  const endpoint = endpoints.get(config.endpointId);
  if (endpoint && !endpoint.events.includes(config.eventType)) {
    endpoint.events.push(config.eventType);
    endpoints.set(endpoint.id, endpoint);
  }

  return subscription;
}

/**
 * Get subscription
 */
export function getSubscription(subscriptionId: string): EventSubscription | undefined {
  return subscriptions.get(subscriptionId);
}

/**
 * List subscriptions
 */
export function listSubscriptions(endpointId?: string): EventSubscription[] {
  const all = Array.from(subscriptions.values());
  return endpointId ? all.filter(s => s.endpointId === endpointId) : all;
}

/**
 * Delete subscription
 */
export function deleteSubscription(subscriptionId: string): boolean {
  return subscriptions.delete(subscriptionId);
}

// ============================================================================
// VERIFICATION
// ============================================================================

/**
 * Verify webhook signature
 */
export function verifySignature(payload: string, signature: string, secret: string): boolean {
  const expected = signPayload(payload, secret);
  return signature === expected;
}

/**
 * Verify incoming webhook request
 */
export function verifyIncomingWebhook(config: {
  payload: string;
  signature: string;
  endpointId: string;
}): boolean {
  const endpoint = endpoints.get(config.endpointId);
  if (!endpoint) return false;

  return verifySignature(config.payload, config.signature, endpoint.secret);
}

// ============================================================================
// STATISTICS
// ============================================================================

/**
 * Get webhook statistics
 */
export function getWebhookStats(): WebhookStats {
  return { ...stats };
}

/**
 * Reset statistics
 */
export function resetStats(): void {
  stats = {
    totalEvents: 0,
    totalDeliveries: 0,
    successfulDeliveries: 0,
    failedDeliveries: 0,
    pendingDeliveries: 0,
    avgDeliveryTimeMs: 0,
    successRate: 0,
    byEndpoint: {},
    byEventType: {},
    last24h: { events: 0, deliveries: 0, successRate: 0 }
  };
}

// ============================================================================
// TEST SUITE
// ============================================================================

/**
 * Run webhook system tests
 */
export function runWebhookSystemTests(): {
  passed: boolean;
  tests: { total: number; passed: number; failed: number };
  results: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const results: Array<{ name: string; passed: boolean; error?: string }> = [];

  try {
    // Test 1: Create endpoint
    const endpoint = createEndpoint({
      name: 'Test Endpoint',
      url: 'https://example.com/webhook',
      events: ['detection.*', 'alert.critical'],
      ownerId: 'user_1'
    });
    results.push({ name: 'Create Endpoint', passed: !!endpoint.id && endpoint.status === 'pending_verification' });

    // Test 2: Verify endpoint
    const verified = verifyEndpoint(endpoint.id, endpoint.verificationToken!);
    results.push({ name: 'Verify Endpoint', passed: verified });

    // Test 3: Emit event
    const event = emitEvent({
      type: 'detection.completed',
      category: 'detection',
      source: 'deepfake-detector',
      payload: { result: 'authentic', confidence: 0.95 }
    });
    results.push({ name: 'Emit Event', passed: !!event.id && stats.totalEvents === 1 });

    // Test 4: Check delivery created
    const eventDeliveries = listDeliveries({ eventId: event.id });
    results.push({ name: 'Delivery Created', passed: eventDeliveries.length > 0 });

    // Test 5: Get endpoint
    const retrieved = getEndpoint(endpoint.id);
    results.push({ name: 'Get Endpoint', passed: retrieved?.id === endpoint.id });

    // Test 6: List endpoints
    const endpointList = listEndpoints('user_1');
    results.push({ name: 'List Endpoints', passed: endpointList.length === 1 });

    // Test 7: Update endpoint
    const updated = updateEndpoint(endpoint.id, { name: 'Updated Endpoint' });
    results.push({ name: 'Update Endpoint', passed: updated?.name === 'Updated Endpoint' });

    // Test 8: Create subscription
    const subscription = createSubscription({
      endpointId: endpoint.id,
      eventType: 'alert.*',
      filters: [{ field: 'severity', operator: 'eq', value: 'critical' }]
    });
    results.push({ name: 'Create Subscription', passed: !!subscription.id });

    // Test 9: Verify signature
    const testPayload = JSON.stringify({ test: 'data' });
    const testSignature = signPayload(testPayload, endpoint.secret);
    const signatureValid = verifySignature(testPayload, testSignature, endpoint.secret);
    results.push({ name: 'Verify Signature', passed: signatureValid });

    // Test 10: Create batch
    const batch = createBatch({
      endpointId: endpoint.id,
      eventIds: [event.id]
    });
    results.push({ name: 'Create Batch', passed: !!batch.id });

    // Test 11: List events
    const eventList = listEvents({ category: 'detection' });
    results.push({ name: 'List Events', passed: eventList.length === 1 });

    // Test 12: Get statistics
    const webhookStats = getWebhookStats();
    results.push({ name: 'Get Statistics', passed: webhookStats.totalEvents === 1 });

  } catch (error) {
    results.push({ name: 'Test Execution', passed: false, error: String(error) });
  }

  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;

  return {
    passed: failed === 0,
    tests: { total: results.length, passed, failed },
    results
  };
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

export default {
  createEndpoint,
  getEndpoint,
  listEndpoints,
  updateEndpoint,
  deleteEndpoint,
  verifyEndpoint,
  setEndpointEnabled,
  emitEvent,
  getEvent,
  listEvents,
  getDelivery,
  listDeliveries,
  retryDelivery,
  createBatch,
  processBatch,
  getBatch,
  createSubscription,
  getSubscription,
  listSubscriptions,
  deleteSubscription,
  verifySignature,
  verifyIncomingWebhook,
  getWebhookStats,
  resetStats,
  runWebhookSystemTests
};
