/**
 * Inference Security - Protect ML inference endpoints
 * @module frontier/inference-security
 */
export type SecurityLevel = 'standard' | 'elevated' | 'high';

export interface InferenceEndpoint {
  id: string; name: string; modelId: string; endpoint: string;
  securityLevel: SecurityLevel; rateLimit: number; enabled: boolean;
  stats: {requests: number; blocked: number; avgLatency: number};
  createdAt: number;
}

export interface InferenceRequest {
  id: string; endpointId: string; agentId?: string;
  input: Record<string,unknown>; output?: Record<string,unknown>;
  status: 'pending'|'approved'|'denied'|'error';
  riskScore: number; processedAt?: number;
  createdAt: number;
}

export interface APIKey {
  id: string; key: string; agentId: string; permissions: string[];
  rateLimit: number; usage: number; expiresAt?: number;
  createdAt: number;
}

const endpoints = new Map<string, InferenceEndpoint>();
const requests = new Map<string, InferenceRequest>();
const apiKeys = new Map<string, APIKey>();

export function registerEndpoint(config: {name: string; modelId: string; endpoint: string; securityLevel?: SecurityLevel; rateLimit?: number}): InferenceEndpoint {
  const ep: InferenceEndpoint = {
    id: `ep_${Date.now()}_${Math.random().toString(36).substr(2,6)}`,
    ...config, securityLevel: config.securityLevel||'standard',
    rateLimit: config.rateLimit||1000, enabled: true,
    stats: {requests:0, blocked:0, avgLatency:0}, createdAt: Date.now()
  };
  endpoints.set(ep.id, ep);
  return ep;
}

export function createAPIKey(agentId: string, permissions: string[], rateLimit?: number): APIKey {
  const key: APIKey = {
    id: `key_${Date.now()}`, key: `sk_${Math.random().toString(36).substr(2,32)}`,
    agentId, permissions, rateLimit: rateLimit||1000, usage: 0, createdAt: Date.now()
  };
  apiKeys.set(key.id, key);
  return key;
}

export function validateRequest(endpointId: string, input: Record<string,unknown>, apiKey?: string): {valid: boolean; sanitized: Record<string,unknown>; riskScore: number} {
  const ep = endpoints.get(endpointId);
  if (!ep || !ep.enabled) return {valid: false, sanitized: {}, riskScore: 1};
  
  let riskScore = 0;
  const sanitized: Record<string,unknown> = {};
  
  for (const [k,v] of Object.entries(input)) {
    if (typeof v === 'string') {
      if (v.includes('<script>') || v.includes('javascript:')) riskScore += 0.3;
      sanitized[k] = v.replace(/<[^>]*>/g, '');
    } else {
      sanitized[k] = v;
    }
  }
  
  return {valid: riskScore < 0.5, sanitized, riskScore};
}

export function processRequest(endpointId: string, input: Record<string,unknown>, agentId?: string): InferenceRequest {
  const validation = validateRequest(endpointId, input);
  const req: InferenceRequest = {
    id: `req_${Date.now()}`, endpointId, agentId, input: validation.sanitized,
    status: validation.valid ? 'approved' : 'denied',
    riskScore: validation.riskScore, createdAt: Date.now()
  };
  requests.set(req.id, req);
  
  const ep = endpoints.get(endpointId);
  if (ep) {
    ep.stats.requests++;
    if (!validation.valid) ep.stats.blocked++;
  }
  
  return req;
}

export function getEndpoint(id: string): InferenceEndpoint | undefined { return endpoints.get(id); }
export function getInferenceStats() { return {endpoints: endpoints.size, requests: requests.size, apiKeys: apiKeys.size}; }

export function runInferenceSecurityTests() {
  const results: {name: string; passed: boolean}[] = [];
  try { const e = registerEndpoint({name:'Test',modelId:'m1',endpoint:'/api/infer'}); results.push({name:'Endpoint',passed:!!e.id}); } catch { results.push({name:'Endpoint',passed:false}); }
  try { const k = createAPIKey('agent1',['read']); results.push({name:'APIKey',passed:!!k.key}); } catch { results.push({name:'APIKey',passed:false}); }
  try { const v = validateRequest(Array.from(endpoints.values())[0].id,{prompt:'test'}); results.push({name:'Validate',passed:v.riskScore>=0}); } catch { results.push({name:'Validate',passed:false}); }
  try { const s = getInferenceStats(); results.push({name:'Stats',passed:s.endpoints>0}); } catch { results.push({name:'Stats',passed:false}); }
  const passed = results.filter(r=>r.passed).length, failed = results.filter(r=>!r.passed).length;
  return {passed: failed===0, tests:{total:results.length,passed,failed}, results};
}

export default {registerEndpoint,createAPIKey,validateRequest,processRequest,getEndpoint,getInferenceStats,runInferenceSecurityTests};
