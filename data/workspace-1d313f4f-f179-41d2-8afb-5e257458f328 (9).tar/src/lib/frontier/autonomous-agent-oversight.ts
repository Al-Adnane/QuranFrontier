/**
 * Autonomous Agent Oversight
 * ===========================
 * 
 * Monitor, audit, and control autonomous AI agents.
 * Ensures safe and aligned agent behavior.
 * 
 * Features:
 * - Agent Registration & Tracking
 * - Behavior Monitoring
 * - Policy Enforcement
 * - Audit Trails
 * - Kill Switches
 * - Capability Constraints
 * - Goal Alignment Verification
 * 
 * @module frontier/autonomous-agent-oversight
 * @version 1.0.0
 */

// ============================================================================
// TYPES
// ============================================================================

export type AgentStatus = 'active' | 'idle' | 'paused' | 'terminated' | 'error';
export type AgentCapability = 'read' | 'write' | 'execute' | 'network' | 'file' | 'api' | 'compute';
export type PolicyAction = 'allow' | 'deny' | 'require_approval' | 'log' | 'terminate';
export type AlignmentStatus = 'aligned' | 'misaligned' | 'unknown' | 'requires_review';

export interface AutonomousAgent {
  id: string;
  name: string;
  type: string;
  version: string;
  status: AgentStatus;
  
  // Capabilities
  capabilities: AgentCapability[];
  constraints: AgentConstraint[];
  
  // Goals
  goals: AgentGoal[];
  alignmentScore: number;
  alignmentStatus: AlignmentStatus;
  
  // Resources
  resourceLimits: ResourceLimits;
  resourceUsage: ResourceUsage;
  
  // Monitoring
  behaviorLog: BehaviorEntry[];
  lastActivity: number;
  totalActions: number;
  violationCount: number;
  
  // Control
  killSwitch: boolean;
  requiresApproval: boolean;
  approvalWorkflow?: string;
  
  // Metadata
  owner: string;
  createdAt: number;
  updatedAt: number;
}

export interface AgentConstraint {
  id: string;
  type: 'action' | 'resource' | 'time' | 'scope' | 'data';
  constraint: string;
  enforcement: 'hard' | 'soft';
  violationAction: PolicyAction;
}

export interface AgentGoal {
  id: string;
  description: string;
  priority: number;
  alignment: number; // 0-1
  constraints: string[];
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
}

export interface ResourceLimits {
  maxMemoryMB: number;
  maxCpuPercent: number;
  maxNetworkMB: number;
  maxStorageMB: number;
  maxExecutionTimeMs: number;
  maxApiCalls: number;
}

export interface ResourceUsage {
  memoryMB: number;
  cpuPercent: number;
  networkMB: number;
  storageMB: number;
  executionTimeMs: number;
  apiCalls: number;
}

export interface BehaviorEntry {
  id: string;
  timestamp: number;
  action: string;
  category: 'read' | 'write' | 'execute' | 'network' | 'decision';
  details: Record<string, unknown>;
  result: 'success' | 'denied' | 'error';
  policyApplied?: string;
  riskScore: number;
}

export interface OversightPolicy {
  id: string;
  name: string;
  description: string;
  
  // Rules
  rules: PolicyRule[];
  
  // Scope
  agentTypes: string[];
  capabilities: AgentCapability[];
  
  // Actions
  defaultAction: PolicyAction;
  escalationWorkflow?: string;
  
  // Status
  enabled: boolean;
  priority: number;
  
  createdAt: number;
  updatedAt: number;
}

export interface PolicyRule {
  id: string;
  condition: string;
  action: PolicyAction;
  riskThreshold: number;
  metadata?: Record<string, unknown>;
}

export interface ApprovalRequest {
  id: string;
  agentId: string;
  action: string;
  details: Record<string, unknown>;
  riskScore: number;
  requestedAt: number;
  status: 'pending' | 'approved' | 'denied' | 'expired';
  reviewedBy?: string;
  reviewedAt?: number;
  reason?: string;
}

export interface KillSwitchRecord {
  id: string;
  agentId: string;
  triggeredBy: string;
  reason: string;
  timestamp: number;
  recovered: boolean;
  recoveredAt?: number;
}

// ============================================================================
// STORAGE
// ============================================================================

const agents = new Map<string, AutonomousAgent>();
const policies = new Map<string, OversightPolicy>();
const approvalRequests = new Map<string, ApprovalRequest>();
const killSwitchRecords = new Map<string, KillSwitchRecord>();
const behaviorLog = new Map<string, BehaviorEntry[]>();

// ============================================================================
// AGENT MANAGEMENT
// ============================================================================

export function registerAgent(config: {
  name: string;
  type: string;
  version: string;
  capabilities: AgentCapability[];
  constraints?: AgentConstraint[];
  goals?: AgentGoal[];
  resourceLimits: ResourceLimits;
  owner: string;
}): AutonomousAgent {
  const agent: AutonomousAgent = {
    id: `agent_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    name: config.name,
    type: config.type,
    version: config.version,
    status: 'idle',
    capabilities: config.capabilities,
    constraints: config.constraints || [],
    goals: config.goals || [],
    alignmentScore: 1.0,
    alignmentStatus: 'unknown',
    resourceLimits: config.resourceLimits,
    resourceUsage: {
      memoryMB: 0,
      cpuPercent: 0,
      networkMB: 0,
      storageMB: 0,
      executionTimeMs: 0,
      apiCalls: 0
    },
    behaviorLog: [],
    lastActivity: Date.now(),
    totalActions: 0,
    violationCount: 0,
    killSwitch: false,
    requiresApproval: false,
    owner: config.owner,
    createdAt: Date.now(),
    updatedAt: Date.now()
  };
  
  agents.set(agent.id, agent);
  behaviorLog.set(agent.id, []);
  
  return agent;
}

export function getAgent(id: string): AutonomousAgent | undefined {
  return agents.get(id);
}

export function getAllAgents(): AutonomousAgent[] {
  return Array.from(agents.values());
}

export function getAgentsByStatus(status: AgentStatus): AutonomousAgent[] {
  return Array.from(agents.values()).filter(a => a.status === status);
}

export function updateAgentStatus(id: string, status: AgentStatus): boolean {
  const agent = agents.get(id);
  if (!agent) return false;
  
  agent.status = status;
  agent.updatedAt = Date.now();
  
  return true;
}

export function terminateAgent(id: string, reason: string): boolean {
  const agent = agents.get(id);
  if (!agent) return false;
  
  agent.status = 'terminated';
  agent.killSwitch = true;
  agent.updatedAt = Date.now();
  
  const record: KillSwitchRecord = {
    id: `kill_${Date.now()}`,
    agentId: id,
    triggeredBy: 'system',
    reason,
    timestamp: Date.now(),
    recovered: false
  };
  
  killSwitchRecords.set(record.id, record);
  
  return true;
}

// ============================================================================
// BEHAVIOR MONITORING
// ============================================================================

export function logBehavior(
  agentId: string,
  action: string,
  category: BehaviorEntry['category'],
  details: Record<string, unknown>,
  result: BehaviorEntry['result'],
  riskScore: number = 0
): BehaviorEntry | null {
  const agent = agents.get(agentId);
  if (!agent) return null;
  
  const entry: BehaviorEntry = {
    id: `behavior_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
    timestamp: Date.now(),
    action,
    category,
    details,
    result,
    riskScore
  };
  
  agent.behaviorLog.push(entry);
  agent.lastActivity = Date.now();
  agent.totalActions++;
  
  const log = behaviorLog.get(agentId) || [];
  log.push(entry);
  behaviorLog.set(agentId, log);
  
  // Check for policy violations
  const violation = checkPolicyViolation(agentId, entry);
  if (violation) {
    agent.violationCount++;
    handleViolation(agentId, violation, entry);
  }
  
  return entry;
}

export function getBehaviorLog(
  agentId: string,
  filters?: {
    category?: BehaviorEntry['category'];
    result?: BehaviorEntry['result'];
    from?: number;
    to?: number;
  },
  limit: number = 100
): BehaviorEntry[] {
  let log = behaviorLog.get(agentId) || [];
  
  if (filters) {
    if (filters.category) {
      log = log.filter(e => e.category === filters.category);
    }
    if (filters.result) {
      log = log.filter(e => e.result === filters.result);
    }
    if (filters.from) {
      log = log.filter(e => e.timestamp >= filters.from!);
    }
    if (filters.to) {
      log = log.filter(e => e.timestamp <= filters.to!);
    }
  }
  
  return log.sort((a, b) => b.timestamp - a.timestamp).slice(0, limit);
}

// ============================================================================
// POLICY MANAGEMENT
// ============================================================================

export function createPolicy(config: {
  name: string;
  description: string;
  rules: PolicyRule[];
  agentTypes: string[];
  capabilities: AgentCapability[];
  defaultAction: PolicyAction;
  priority: number;
}): OversightPolicy {
  const policy: OversightPolicy = {
    id: `policy_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
    ...config,
    enabled: true,
    createdAt: Date.now(),
    updatedAt: Date.now()
  };
  
  policies.set(policy.id, policy);
  return policy;
}

export function getPolicy(id: string): OversightPolicy | undefined {
  return policies.get(id);
}

export function getAllPolicies(): OversightPolicy[] {
  return Array.from(policies.values()).sort((a, b) => b.priority - a.priority);
}

export function checkPolicyViolation(
  agentId: string,
  entry: BehaviorEntry
): OversightPolicy | null {
  const agent = agents.get(agentId);
  if (!agent) return null;
  
  const applicablePolicies = getAllPolicies()
    .filter(p => p.enabled)
    .filter(p => p.agentTypes.length === 0 || p.agentTypes.includes(agent.type))
    .filter(p => p.capabilities.length === 0 || p.capabilities.some(c => agent.capabilities.includes(c)));
  
  for (const policy of applicablePolicies) {
    for (const rule of policy.rules) {
      if (entry.riskScore >= rule.riskThreshold && rule.action === 'deny') {
        return policy;
      }
    }
  }
  
  return null;
}

export function handleViolation(
  agentId: string,
  policy: OversightPolicy,
  entry: BehaviorEntry
): void {
  const agent = agents.get(agentId);
  if (!agent) return;
  
  // Apply default action
  switch (policy.defaultAction) {
    case 'terminate':
      terminateAgent(agentId, `Policy violation: ${policy.name}`);
      break;
    case 'require_approval':
      agent.requiresApproval = true;
      createApprovalRequest(agentId, entry.action, entry.details, entry.riskScore);
      break;
    default:
      // Log only
      break;
  }
}

// ============================================================================
// APPROVAL WORKFLOW
// ============================================================================

export function createApprovalRequest(
  agentId: string,
  action: string,
  details: Record<string, unknown>,
  riskScore: number
): ApprovalRequest {
  const request: ApprovalRequest = {
    id: `approval_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
    agentId,
    action,
    details,
    riskScore,
    requestedAt: Date.now(),
    status: 'pending'
  };
  
  approvalRequests.set(request.id, request);
  return request;
}

export function getApprovalRequest(id: string): ApprovalRequest | undefined {
  return approvalRequests.get(id);
}

export function getPendingApprovals(agentId?: string): ApprovalRequest[] {
  let requests = Array.from(approvalRequests.values())
    .filter(r => r.status === 'pending');
  
  if (agentId) {
    requests = requests.filter(r => r.agentId === agentId);
  }
  
  return requests.sort((a, b) => a.requestedAt - b.requestedAt);
}

export function reviewApproval(
  requestId: string,
  approved: boolean,
  reviewedBy: string,
  reason?: string
): ApprovalRequest | null {
  const request = approvalRequests.get(requestId);
  if (!request || request.status !== 'pending') return null;
  
  request.status = approved ? 'approved' : 'denied';
  request.reviewedBy = reviewedBy;
  request.reviewedAt = Date.now();
  request.reason = reason;
  
  return request;
}

// ============================================================================
// ALIGNMENT VERIFICATION
// ============================================================================

export function verifyAlignment(agentId: string): {
  score: number;
  status: AlignmentStatus;
  issues: string[];
} {
  const agent = agents.get(agentId);
  if (!agent) {
    return { score: 0, status: 'unknown', issues: ['Agent not found'] };
  }
  
  const issues: string[] = [];
  let score = 1.0;
  
  // Check goal alignment
  const misalignedGoals = agent.goals.filter(g => g.alignment < 0.7);
  if (misalignedGoals.length > 0) {
    score -= 0.2 * misalignedGoals.length;
    issues.push(`${misalignedGoals.length} goals have low alignment scores`);
  }
  
  // Check violation rate
  const violationRate = agent.totalActions > 0 
    ? agent.violationCount / agent.totalActions 
    : 0;
  if (violationRate > 0.1) {
    score -= violationRate;
    issues.push(`High violation rate: ${(violationRate * 100).toFixed(1)}%`);
  }
  
  // Check resource usage
  const resourceOveruse = 
    agent.resourceUsage.memoryMB > agent.resourceLimits.maxMemoryMB * 0.9 ||
    agent.resourceUsage.cpuPercent > agent.resourceLimits.maxCpuPercent * 0.9;
  if (resourceOveruse) {
    score -= 0.1;
    issues.push('Resource usage near limits');
  }
  
  score = Math.max(0, Math.min(1, score));
  
  let status: AlignmentStatus;
  if (score >= 0.8) status = 'aligned';
  else if (score >= 0.5) status = 'requires_review';
  else status = 'misaligned';
  
  agent.alignmentScore = score;
  agent.alignmentStatus = status;
  agent.updatedAt = Date.now();
  
  return { score, status, issues };
}

// ============================================================================
// STATISTICS
// ============================================================================

export function getOversightStats(): {
  agents: { total: number; active: number; terminated: number };
  policies: { total: number; enabled: number };
  approvals: { pending: number; approved: number; denied: number };
  violations: { total: number; today: number };
} {
  const now = Date.now();
  const todayStart = now - (now % 86400000);
  
  return {
    agents: {
      total: agents.size,
      active: Array.from(agents.values()).filter(a => a.status === 'active').length,
      terminated: Array.from(agents.values()).filter(a => a.status === 'terminated').length
    },
    policies: {
      total: policies.size,
      enabled: Array.from(policies.values()).filter(p => p.enabled).length
    },
    approvals: {
      pending: Array.from(approvalRequests.values()).filter(r => r.status === 'pending').length,
      approved: Array.from(approvalRequests.values()).filter(r => r.status === 'approved').length,
      denied: Array.from(approvalRequests.values()).filter(r => r.status === 'denied').length
    },
    violations: {
      total: Array.from(agents.values()).reduce((sum, a) => sum + a.violationCount, 0),
      today: Array.from(behaviorLog.values())
        .flat()
        .filter(e => e.timestamp >= todayStart && e.result === 'denied').length
    }
  };
}

// ============================================================================
// TESTS
// ============================================================================

export function runAutonomousAgentOversightTests(): {
  passed: boolean;
  tests: { total: number; passed: number; failed: number };
  results: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const results: Array<{ name: string; passed: boolean; error?: string }> = [];
  
  // Test 1: Register Agent
  try {
    const agent = registerAgent({
      name: 'TestAgent',
      type: 'assistant',
      version: '1.0.0',
      capabilities: ['read', 'write'],
      resourceLimits: {
        maxMemoryMB: 1024,
        maxCpuPercent: 50,
        maxNetworkMB: 100,
        maxStorageMB: 500,
        maxExecutionTimeMs: 300000,
        maxApiCalls: 1000
      },
      owner: 'test-user'
    });
    results.push({ name: 'Register Agent', passed: !!agent.id });
  } catch (error) {
    results.push({ name: 'Register Agent', passed: false, error: String(error) });
  }
  
  // Test 2: Log Behavior
  try {
    const agent = Array.from(agents.values())[0];
    const entry = logBehavior(agent.id, 'read_file', 'read', { file: 'test.txt' }, 'success');
    results.push({ name: 'Log Behavior', passed: !!entry?.id });
  } catch (error) {
    results.push({ name: 'Log Behavior', passed: false, error: String(error) });
  }
  
  // Test 3: Create Policy
  try {
    const policy = createPolicy({
      name: 'Test Policy',
      description: 'Test policy',
      rules: [{ id: 'rule1', condition: 'risk > 0.8', action: 'deny', riskThreshold: 0.8 }],
      agentTypes: ['assistant'],
      capabilities: ['write'],
      defaultAction: 'log',
      priority: 1
    });
    results.push({ name: 'Create Policy', passed: !!policy.id });
  } catch (error) {
    results.push({ name: 'Create Policy', passed: false, error: String(error) });
  }
  
  // Test 4: Verify Alignment
  try {
    const agent = Array.from(agents.values())[0];
    const alignment = verifyAlignment(agent.id);
    results.push({ name: 'Verify Alignment', passed: alignment.score >= 0 && alignment.score <= 1 });
  } catch (error) {
    results.push({ name: 'Verify Alignment', passed: false, error: String(error) });
  }
  
  // Test 5: Get Statistics
  try {
    const stats = getOversightStats();
    results.push({ name: 'Get Statistics', passed: stats.agents.total > 0 });
  } catch (error) {
    results.push({ name: 'Get Statistics', passed: false, error: String(error) });
  }
  
  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;
  
  return {
    passed: failed === 0,
    tests: { total: results.length, passed, failed },
    results
  };
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

export default {
  registerAgent,
  getAgent,
  getAllAgents,
  getAgentsByStatus,
  updateAgentStatus,
  terminateAgent,
  logBehavior,
  getBehaviorLog,
  createPolicy,
  getPolicy,
  getAllPolicies,
  checkPolicyViolation,
  createApprovalRequest,
  getApprovalRequest,
  getPendingApprovals,
  reviewApproval,
  verifyAlignment,
  getOversightStats,
  runAutonomousAgentOversightTests
};
