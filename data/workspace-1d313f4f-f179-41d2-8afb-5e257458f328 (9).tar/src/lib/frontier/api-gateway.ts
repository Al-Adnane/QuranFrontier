/**
 * API Gateway Control Layer
 * =========================
 * 
 * Unified control layer for both internal and external APIs.
 * Controls what agents can consume, from which APIs, with what limits.
 * 
 * Features:
 * - External API Provider Registry (OpenAI, Anthropic, Google, etc.)
 * - API Key Management with rotation
 * - Request/Response interceptors
 * - Spending controls per API provider
 * - Rate limiting per provider
 * - Request signing and authentication
 * - Circuit breaker pattern
 * - Retry with exponential backoff
 * - Response caching
 * - Audit logging
 * - Cost tracking per provider
 * 
 * @module frontier/api-gateway
 * @version 1.0.0
 */

// ============================================================================
// TYPES
// ============================================================================

/**
 * External API Provider
 */
export type APIProvider = 
  | 'openai'
  | 'anthropic'
  | 'google_ai'
  | 'azure_openai'
  | 'aws_bedrock'
  | 'huggingface'
  | 'replicate'
  | 'stability_ai'
  | 'elevenlabs'
  | 'deepgram'
  | 'assemblyai'
  | 'cohere'
  | 'mistral'
  | 'groq'
  | 'perplexity'
  | 'together_ai'
  | 'internal_vlm'
  | 'internal_llm'
  | 'internal_tts'
  | 'internal_asr'
  | 'internal_detection'
  | 'internal_forensics'
  | 'custom';

/**
 * API Authentication type
 */
export type APIAuthType = 
  | 'api_key'
  | 'bearer_token'
  | 'oauth2'
  | 'aws_signature_v4'
  | 'hmac'
  | 'mtls'
  | 'custom';

/**
 * API Provider Configuration
 */
export interface APIProviderConfig {
  id: string;
  provider: APIProvider;
  name: string;
  description?: string;
  
  // Authentication
  authType: APIAuthType;
  authConfig: {
    apiKey?: string;
    apiSecret?: string;
    bearerToken?: string;
    oauthClientId?: string;
    oauthClientSecret?: string;
    oauthTokenUrl?: string;
    awsAccessKeyId?: string;
    awsSecretAccessKey?: string;
    awsRegion?: string;
    hmacKey?: string;
    customHeaders?: Record<string, string>;
  };
  
  // Endpoints
  baseUrl: string;
  endpoints: Record<string, {
    path: string;
    method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
    costPerRequest?: number;
    costPerToken?: number;
    rateLimit?: {
      requestsPerMinute?: number;
      requestsPerHour?: number;
      tokensPerMinute?: number;
    };
  }>;
  
  // Features
  features: {
    streaming: boolean;
    batching: boolean;
    async: boolean;
    webhooks: boolean;
  };
  
  // Health check
  healthCheck: {
    endpoint?: string;
    intervalMs: number;
    timeoutMs: number;
  };
  
  // Status
  status: 'active' | 'paused' | 'error' | 'disabled';
  lastHealthCheck?: number;
  lastError?: string;
  
  // Metadata
  metadata?: Record<string, unknown>;
  createdAt: number;
  updatedAt: number;
}

/**
 * API Key (stored securely)
 */
export interface APIKey {
  id: string;
  providerId: string;
  name: string;
  keyReference: string; // Reference to secure storage
  keyPrefix: string; // First 4 chars for identification
  permissions: string[];
  scopes: string[];
  
  // Rotation
  rotationEnabled: boolean;
  rotationDays?: number;
  lastRotated?: number;
  nextRotation?: number;
  
  // Constraints
  ipWhitelist?: string[];
  referrerWhitelist?: string[];
  
  // Status
  status: 'active' | 'expired' | 'revoked';
  expiresAt?: number;
  
  // Audit
  createdAt: number;
  createdBy: string;
  lastUsed?: number;
  usageCount: number;
}

/**
 * API Request
 */
export interface APIRequest {
  id: string;
  agentId: string;
  principalId: string;
  providerId: string;
  endpoint: string;
  
  // Request details
  method: string;
  path: string;
  headers: Record<string, string>;
  body?: unknown;
  queryParams?: Record<string, string>;
  
  // Authorization
  authorizationId: string;
  delegationId?: string;
  
  // Context
  purpose?: string;
  parentRequestId?: string;
  
  // Timing
  createdAt: number;
  sentAt?: number;
  completedAt?: number;
  
  // Retry
  retryCount: number;
  maxRetries: number;
  
  // Priority
  priority: 'low' | 'normal' | 'high' | 'critical';
  
  // Metadata
  metadata?: Record<string, unknown>;
}

/**
 * API Response
 */
export interface APIResponse {
  id: string;
  requestId: string;
  
  // Response details
  statusCode: number;
  headers: Record<string, string>;
  body?: unknown;
  
  // Timing
  latencyMs: number;
  
  // Tokens (if applicable)
  promptTokens?: number;
  completionTokens?: number;
  totalTokens?: number;
  
  // Cost
  costCents: number;
  
  // Status
  success: boolean;
  errorMessage?: string;
  errorCode?: string;
  
  // Caching
  cached: boolean;
  cacheKey?: string;
  cacheTTL?: number;
  
  // Metadata
  metadata?: Record<string, unknown>;
}

/**
 * Circuit Breaker State
 */
export interface CircuitBreakerState {
  providerId: string;
  state: 'closed' | 'open' | 'half_open';
  failures: number;
  successes: number;
  lastFailure?: number;
  lastSuccess?: number;
  lastStateChange: number;
  nextRetryTime?: number;
  config: {
    failureThreshold: number;
    successThreshold: number;
    timeout: number;
    resetTimeout: number;
  };
}

/**
 * Rate Limit State
 */
export interface RateLimitState {
  providerId: string;
  endpoint?: string;
  
  // Counters
  minuteCount: number;
  minuteResetAt: number;
  hourCount: number;
  hourResetAt: number;
  dayCount: number;
  dayResetAt: number;
  
  // Token tracking
  minuteTokens: number;
  hourTokens: number;
  
  // Limits
  limits: {
    requestsPerMinute?: number;
    requestsPerHour?: number;
    requestsPerDay?: number;
    tokensPerMinute?: number;
    tokensPerHour?: number;
  };
}

/**
 * Cache Entry
 */
export interface CacheEntry {
  key: string;
  response: APIResponse;
  createdAt: number;
  expiresAt: number;
  hits: number;
  ttl: number;
  tags: string[];
}

/**
 * Spending Allocation per Provider
 */
export interface ProviderSpendingAllocation {
  id: string;
  agentId: string;
  principalId: string;
  providerId: string;
  
  // Budget
  dailyBudgetCents: number;
  monthlyBudgetCents: number;
  
  // Usage
  dailySpentCents: number;
  monthlySpentCents: number;
  
  // Limits
  maxRequestsPerDay: number;
  maxTokensPerDay: number;
  
  // Usage tracking
  dailyRequests: number;
  dailyTokens: number;
  
  // Reset tracking
  lastDailyReset: number;
  lastMonthlyReset: number;
  
  // Status
  status: 'active' | 'paused' | 'exhausted' | 'over_budget';
  
  // Alerts
  alertThresholds: number[];
  alertsTriggered: string[];
  
  // Audit
  createdAt: number;
  updatedAt: number;
}

/**
 * Audit Log Entry
 */
export interface AuditLogEntry {
  id: string;
  timestamp: number;
  
  // Actor
  agentId: string;
  principalId: string;
  
  // Action
  action: 'request' | 'response' | 'error' | 'cache_hit' | 'cache_miss' | 'rate_limited' | 'circuit_open' | 'retry' | 'key_rotation';
  
  // Target
  providerId: string;
  endpoint?: string;
  requestId?: string;
  
  // Details
  details: {
    statusCode?: number;
    latencyMs?: number;
    costCents?: number;
    tokens?: number;
    errorMessage?: string;
    retryCount?: number;
  };
  
  // Metadata
  metadata?: Record<string, unknown>;
}

/**
 * Gateway Configuration
 */
export interface GatewayConfig {
  // Global settings
  defaultTimeoutMs: number;
  defaultMaxRetries: number;
  defaultRetryBackoffMs: number;
  defaultCacheTTL: number;
  
  // Circuit breaker defaults
  circuitBreaker: {
    failureThreshold: number;
    successThreshold: number;
    timeout: number;
    resetTimeout: number;
  };
  
  // Logging
  auditLogEnabled: boolean;
  requestLogging: boolean;
  responseLogging: boolean;
  
  // Caching
  cachingEnabled: boolean;
  maxCacheSize: number;
  defaultCacheTTLSeconds: number;
}

// ============================================================================
// STORAGE
// ============================================================================

const providers = new Map<string, APIProviderConfig>();
const apiKeys = new Map<string, APIKey>();
const requests = new Map<string, APIRequest>();
const responses = new Map<string, APIResponse>();
const circuitBreakers = new Map<string, CircuitBreakerState>();
const rateLimits = new Map<string, RateLimitState>();
const cache = new Map<string, CacheEntry>();
const spendingAllocations = new Map<string, ProviderSpendingAllocation>();
const auditLog = new Map<string, AuditLogEntry>();

// Default gateway configuration
let gatewayConfig: GatewayConfig = {
  defaultTimeoutMs: 30000,
  defaultMaxRetries: 3,
  defaultRetryBackoffMs: 1000,
  defaultCacheTTL: 300000, // 5 minutes
  
  circuitBreaker: {
    failureThreshold: 5,
    successThreshold: 3,
    timeout: 30000,
    resetTimeout: 60000
  },
  
  auditLogEnabled: true,
  requestLogging: true,
  responseLogging: false,
  
  cachingEnabled: true,
  maxCacheSize: 10000,
  defaultCacheTTLSeconds: 300
};

// ============================================================================
// PROVIDER MANAGEMENT
// ============================================================================

/**
 * Register an API provider
 */
export function registerProvider(config: Omit<APIProviderConfig, 'id' | 'createdAt' | 'updatedAt' | 'status'>): APIProviderConfig {
  const provider: APIProviderConfig = {
    ...config,
    id: `provider_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    status: 'active',
    createdAt: Date.now(),
    updatedAt: Date.now()
  };
  
  providers.set(provider.id, provider);
  
  // Initialize circuit breaker
  circuitBreakers.set(provider.id, {
    providerId: provider.id,
    state: 'closed',
    failures: 0,
    successes: 0,
    lastStateChange: Date.now(),
    config: gatewayConfig.circuitBreaker
  });
  
  // Initialize rate limit state
  rateLimits.set(provider.id, {
    providerId: provider.id,
    minuteCount: 0,
    minuteResetAt: Date.now() + 60000,
    hourCount: 0,
    hourResetAt: Date.now() + 3600000,
    dayCount: 0,
    dayResetAt: Date.now() + 86400000,
    minuteTokens: 0,
    hourTokens: 0,
    limits: {}
  });
  
  return provider;
}

/**
 * Get provider by ID
 */
export function getProvider(id: string): APIProviderConfig | undefined {
  return providers.get(id);
}

/**
 * Get provider by type
 */
export function getProvidersByType(type: APIProvider): APIProviderConfig[] {
  return Array.from(providers.values()).filter(p => p.provider === type);
}

/**
 * Get all active providers
 */
export function getActiveProviders(): APIProviderConfig[] {
  return Array.from(providers.values()).filter(p => p.status === 'active');
}

/**
 * Update provider status
 */
export function updateProviderStatus(
  providerId: string,
  status: APIProviderConfig['status'],
  error?: string
): boolean {
  const provider = providers.get(providerId);
  if (!provider) return false;
  
  provider.status = status;
  provider.lastError = error;
  provider.updatedAt = Date.now();
  
  return true;
}

/**
 * Perform health check on provider
 */
export async function checkProviderHealth(providerId: string): Promise<{
  healthy: boolean;
  latencyMs?: number;
  error?: string;
}> {
  const provider = providers.get(providerId);
  if (!provider) {
    return { healthy: false, error: 'Provider not found' };
  }
  
  const startTime = Date.now();
  
  try {
    const healthEndpoint = provider.healthCheck.endpoint || provider.baseUrl;
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), provider.healthCheck.timeoutMs);
    
    const response = await fetch(healthEndpoint, {
      method: 'GET',
      signal: controller.signal
    });
    
    clearTimeout(timeoutId);
    
    const latencyMs = Date.now() - startTime;
    
    if (response.ok) {
      provider.status = 'active';
      provider.lastHealthCheck = Date.now();
      provider.lastError = undefined;
      
      return { healthy: true, latencyMs };
    } else {
      provider.status = 'error';
      provider.lastError = `Health check failed: ${response.status}`;
      
      return { healthy: false, latencyMs, error: provider.lastError };
    }
  } catch (error) {
    provider.status = 'error';
    provider.lastError = error instanceof Error ? error.message : 'Unknown error';
    
    return { healthy: false, error: provider.lastError };
  } finally {
    provider.updatedAt = Date.now();
  }
}

// ============================================================================
// API KEY MANAGEMENT
// ============================================================================

/**
 * Store API key securely
 */
export function storeAPIKey(
  providerId: string,
  name: string,
  key: string,
  options?: {
    permissions?: string[];
    scopes?: string[];
    rotationDays?: number;
    expiresAt?: number;
    ipWhitelist?: string[];
  }
): APIKey | null {
  const provider = providers.get(providerId);
  if (!provider) return null;
  
  const keyPrefix = key.substring(0, 4);
  
  const apiKey: APIKey = {
    id: `key_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    providerId,
    name,
    keyReference: `secure://keys/${providerId}/${Date.now()}`, // In production, store in secure vault
    keyPrefix,
    permissions: options?.permissions || ['*'],
    scopes: options?.scopes || ['*'],
    rotationEnabled: !!options?.rotationDays,
    rotationDays: options?.rotationDays,
    lastRotated: Date.now(),
    nextRotation: options?.rotationDays ? Date.now() + (options.rotationDays * 86400000) : undefined,
    ipWhitelist: options?.ipWhitelist,
    status: 'active',
    expiresAt: options?.expiresAt,
    createdAt: Date.now(),
    createdBy: 'system',
    usageCount: 0
  };
  
  apiKeys.set(apiKey.id, apiKey);
  return apiKey;
}

/**
 * Get API key for provider
 */
export function getAPIKeyForProvider(providerId: string): APIKey | undefined {
  return Array.from(apiKeys.values()).find(
    k => k.providerId === providerId && k.status === 'active'
  );
}

/**
 * Rotate API key
 */
export function rotateAPIKey(keyId: string, newKey: string): APIKey | null {
  const apiKey = apiKeys.get(keyId);
  if (!apiKey) return null;
  
  // Mark old key as expired
  apiKey.status = 'expired';
  
  // Create new key
  const newApiKey = storeAPIKey(
    apiKey.providerId,
    apiKey.name + '_rotated',
    newKey,
    {
      permissions: apiKey.permissions,
      scopes: apiKey.scopes,
      rotationDays: apiKey.rotationDays,
      ipWhitelist: apiKey.ipWhitelist
    }
  );
  
  return newApiKey;
}

// ============================================================================
// SPENDING ALLOCATION
// ============================================================================

/**
 * Create spending allocation for provider
 */
export function createSpendingAllocation(
  agentId: string,
  principalId: string,
  providerId: string,
  config: {
    dailyBudgetCents?: number;
    monthlyBudgetCents?: number;
    maxRequestsPerDay?: number;
    maxTokensPerDay?: number;
  }
): ProviderSpendingAllocation | null {
  const provider = providers.get(providerId);
  if (!provider) return null;
  
  const allocation: ProviderSpendingAllocation = {
    id: `spend_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    agentId,
    principalId,
    providerId,
    dailyBudgetCents: config.dailyBudgetCents || 1000, // $10 default
    monthlyBudgetCents: config.monthlyBudgetCents || 30000, // $300 default
    dailySpentCents: 0,
    monthlySpentCents: 0,
    maxRequestsPerDay: config.maxRequestsPerDay || 1000,
    maxTokensPerDay: config.maxTokensPerDay || 1000000,
    dailyRequests: 0,
    dailyTokens: 0,
    lastDailyReset: Date.now(),
    lastMonthlyReset: Date.now(),
    status: 'active',
    alertThresholds: [50, 75, 90, 95],
    alertsTriggered: [],
    createdAt: Date.now(),
    updatedAt: Date.now()
  };
  
  spendingAllocations.set(allocation.id, allocation);
  return allocation;
}

/**
 * Get spending allocation
 */
export function getSpendingAllocation(
  agentId: string,
  providerId: string
): ProviderSpendingAllocation | undefined {
  return Array.from(spendingAllocations.values()).find(
    a => a.agentId === agentId && a.providerId === providerId
  );
}

/**
 * Check if spending is allowed
 */
export function checkSpendingAllowed(
  agentId: string,
  providerId: string,
  estimatedCostCents: number,
  estimatedTokens: number
): { allowed: boolean; reason?: string; allocationId?: string } {
  const allocation = getSpendingAllocation(agentId, providerId);
  
  if (!allocation) {
    return { allowed: false, reason: 'No spending allocation found for this provider' };
  }
  
  if (allocation.status !== 'active') {
    return { allowed: false, reason: `Spending allocation status: ${allocation.status}` };
  }
  
  // Reset daily counters if needed
  const now = Date.now();
  if (now - allocation.lastDailyReset > 86400000) {
    allocation.dailySpentCents = 0;
    allocation.dailyRequests = 0;
    allocation.dailyTokens = 0;
    allocation.lastDailyReset = now;
    allocation.alertsTriggered = allocation.alertsTriggered.filter(a => !a.startsWith('daily_'));
  }
  
  // Reset monthly counters if needed
  if (now - allocation.lastMonthlyReset > 30 * 86400000) {
    allocation.monthlySpentCents = 0;
    allocation.lastMonthlyReset = now;
    allocation.alertsTriggered = allocation.alertsTriggered.filter(a => !a.startsWith('monthly_'));
  }
  
  // Check daily budget
  if (allocation.dailySpentCents + estimatedCostCents > allocation.dailyBudgetCents) {
    return { allowed: false, reason: 'Daily budget exceeded' };
  }
  
  // Check monthly budget
  if (allocation.monthlySpentCents + estimatedCostCents > allocation.monthlyBudgetCents) {
    return { allowed: false, reason: 'Monthly budget exceeded' };
  }
  
  // Check request limits
  if (allocation.dailyRequests >= allocation.maxRequestsPerDay) {
    return { allowed: false, reason: 'Daily request limit exceeded' };
  }
  
  // Check token limits
  if (allocation.dailyTokens + estimatedTokens > allocation.maxTokensPerDay) {
    return { allowed: false, reason: 'Daily token limit exceeded' };
  }
  
  return { allowed: true, allocationId: allocation.id };
}

/**
 * Record spending
 */
export function recordSpending(
  allocationId: string,
  costCents: number,
  tokens: number
): boolean {
  const allocation = Array.from(spendingAllocations.values()).find(a => a.id === allocationId);
  if (!allocation) return false;
  
  allocation.dailySpentCents += costCents;
  allocation.monthlySpentCents += costCents;
  allocation.dailyRequests++;
  allocation.dailyTokens += tokens;
  allocation.updatedAt = Date.now();
  
  // Check thresholds and create alerts
  const dailyPercentUsed = (allocation.dailySpentCents / allocation.dailyBudgetCents) * 100;
  const monthlyPercentUsed = (allocation.monthlySpentCents / allocation.monthlyBudgetCents) * 100;
  
  for (const threshold of allocation.alertThresholds) {
    if (dailyPercentUsed >= threshold && !allocation.alertsTriggered.includes(`daily_${threshold}`)) {
      allocation.alertsTriggered.push(`daily_${threshold}`);
      logAudit({
        agentId: allocation.agentId,
        principalId: allocation.principalId,
        action: 'error',
        providerId: allocation.providerId,
        details: {
          errorMessage: `Daily spending reached ${dailyPercentUsed.toFixed(1)}% (${threshold}% threshold)`
        }
      });
    }
  }
  
  // Check for over budget
  if (allocation.dailySpentCents >= allocation.dailyBudgetCents) {
    allocation.status = 'over_budget';
  }
  
  return true;
}

// ============================================================================
// CIRCUIT BREAKER
// ============================================================================

/**
 * Check circuit breaker state
 */
export function checkCircuitBreaker(providerId: string): {
  closed: boolean;
  state: CircuitBreakerState['state'];
  retryAfter?: number;
} {
  const cb = circuitBreakers.get(providerId);
  if (!cb) {
    return { closed: false, state: 'open', retryAfter: 60000 };
  }
  
  const now = Date.now();
  
  // Check if circuit should transition from open to half-open
  if (cb.state === 'open') {
    if (cb.nextRetryTime && now >= cb.nextRetryTime) {
      cb.state = 'half_open';
      cb.lastStateChange = now;
    } else {
      return {
        closed: false,
        state: 'open',
        retryAfter: cb.nextRetryTime ? cb.nextRetryTime - now : 60000
      };
    }
  }
  
  return { closed: true, state: cb.state };
}

/**
 * Record success for circuit breaker
 */
export function recordCircuitSuccess(providerId: string): void {
  const cb = circuitBreakers.get(providerId);
  if (!cb) return;
  
  cb.successes++;
  cb.failures = 0;
  cb.lastSuccess = Date.now();
  
  if (cb.state === 'half_open' && cb.successes >= cb.config.successThreshold) {
    cb.state = 'closed';
    cb.lastStateChange = Date.now();
    cb.successes = 0;
  }
}

/**
 * Record failure for circuit breaker
 */
export function recordCircuitFailure(providerId: string): void {
  const cb = circuitBreakers.get(providerId);
  if (!cb) return;
  
  cb.failures++;
  cb.successes = 0;
  cb.lastFailure = Date.now();
  
  if (cb.failures >= cb.config.failureThreshold) {
    cb.state = 'open';
    cb.lastStateChange = Date.now();
    cb.nextRetryTime = Date.now() + cb.config.resetTimeout;
  }
}

// ============================================================================
// RATE LIMITING
// ============================================================================

/**
 * Check rate limit
 */
export function checkRateLimit(
  providerId: string,
  endpoint?: string,
  tokens?: number
): { allowed: boolean; reason?: string; retryAfter?: number } {
  const rl = rateLimits.get(providerId);
  if (!rl) return { allowed: true };
  
  const now = Date.now();
  
  // Reset counters if needed
  if (now > rl.minuteResetAt) {
    rl.minuteCount = 0;
    rl.minuteTokens = 0;
    rl.minuteResetAt = now + 60000;
  }
  if (now > rl.hourResetAt) {
    rl.hourCount = 0;
    rl.hourTokens = 0;
    rl.hourResetAt = now + 3600000;
  }
  if (now > rl.dayResetAt) {
    rl.dayCount = 0;
    rl.dayResetAt = now + 86400000;
  }
  
  // Check limits
  if (rl.limits.requestsPerMinute && rl.minuteCount >= rl.limits.requestsPerMinute) {
    return {
      allowed: false,
      reason: `Rate limit exceeded: ${rl.limits.requestsPerMinute} requests per minute`,
      retryAfter: rl.minuteResetAt - now
    };
  }
  
  if (rl.limits.requestsPerHour && rl.hourCount >= rl.limits.requestsPerHour) {
    return {
      allowed: false,
      reason: `Rate limit exceeded: ${rl.limits.requestsPerHour} requests per hour`,
      retryAfter: rl.hourResetAt - now
    };
  }
  
  if (rl.limits.requestsPerDay && rl.dayCount >= rl.limits.requestsPerDay) {
    return {
      allowed: false,
      reason: `Rate limit exceeded: ${rl.limits.requestsPerDay} requests per day`,
      retryAfter: rl.dayResetAt - now
    };
  }
  
  if (tokens && rl.limits.tokensPerMinute && rl.minuteTokens + tokens > rl.limits.tokensPerMinute) {
    return {
      allowed: false,
      reason: `Token rate limit exceeded: ${rl.limits.tokensPerMinute} tokens per minute`,
      retryAfter: rl.minuteResetAt - now
    };
  }
  
  return { allowed: true };
}

/**
 * Record rate limit usage
 */
export function recordRateLimitUsage(
  providerId: string,
  tokens?: number
): void {
  const rl = rateLimits.get(providerId);
  if (!rl) return;
  
  rl.minuteCount++;
  rl.hourCount++;
  rl.dayCount++;
  
  if (tokens) {
    rl.minuteTokens += tokens;
    rl.hourTokens += tokens;
  }
}

// ============================================================================
// CACHING
// ============================================================================

/**
 * Generate cache key
 */
export function generateCacheKey(
  providerId: string,
  endpoint: string,
  body?: unknown
): string {
  const bodyHash = body ? JSON.stringify(body) : '';
  return `${providerId}:${endpoint}:${bodyHash}`;
}

/**
 * Get cached response
 */
export function getCachedResponse(cacheKey: string): APIResponse | null {
  if (!gatewayConfig.cachingEnabled) return null;
  
  const entry = cache.get(cacheKey);
  if (!entry) return null;
  
  if (Date.now() > entry.expiresAt) {
    cache.delete(cacheKey);
    return null;
  }
  
  entry.hits++;
  return entry.response;
}

/**
 * Cache response
 */
export function cacheResponse(
  cacheKey: string,
  response: APIResponse,
  ttl?: number,
  tags?: string[]
): void {
  if (!gatewayConfig.cachingEnabled) return;
  
  // Check cache size limit
  if (cache.size >= gatewayConfig.maxCacheSize) {
    // Evict oldest entries
    const entries = Array.from(cache.entries())
      .sort((a, b) => a[1].createdAt - b[1].createdAt);
    
    for (let i = 0; i < Math.floor(gatewayConfig.maxCacheSize * 0.1); i++) {
      cache.delete(entries[i][0]);
    }
  }
  
  const entryTTL = ttl || gatewayConfig.defaultCacheTTL;
  
  cache.set(cacheKey, {
    key: cacheKey,
    response: {
      ...response,
      cached: true,
      cacheKey
    },
    createdAt: Date.now(),
    expiresAt: Date.now() + entryTTL,
    hits: 0,
    ttl: entryTTL,
    tags: tags || []
  });
}

/**
 * Invalidate cache by tags
 */
export function invalidateCacheByTags(tags: string[]): number {
  let invalidated = 0;
  
  for (const [key, entry] of cache.entries()) {
    if (entry.tags.some(t => tags.includes(t))) {
      cache.delete(key);
      invalidated++;
    }
  }
  
  return invalidated;
}

// ============================================================================
// AUDIT LOGGING
// ============================================================================

/**
 * Log audit entry
 */
export function logAudit(entry: Omit<AuditLogEntry, 'id' | 'timestamp'>): AuditLogEntry {
  const auditEntry: AuditLogEntry = {
    ...entry,
    id: `audit_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    timestamp: Date.now()
  };
  
  auditLog.set(auditEntry.id, auditEntry);
  return auditEntry;
}

/**
 * Get audit log entries
 */
export function getAuditLog(
  filters?: {
    agentId?: string;
    principalId?: string;
    providerId?: string;
    action?: AuditLogEntry['action'];
    from?: number;
    to?: number;
  },
  limit: number = 100
): AuditLogEntry[] {
  let entries = Array.from(auditLog.values());
  
  if (filters) {
    if (filters.agentId) {
      entries = entries.filter(e => e.agentId === filters.agentId);
    }
    if (filters.principalId) {
      entries = entries.filter(e => e.principalId === filters.principalId);
    }
    if (filters.providerId) {
      entries = entries.filter(e => e.providerId === filters.providerId);
    }
    if (filters.action) {
      entries = entries.filter(e => e.action === filters.action);
    }
    if (filters.from) {
      entries = entries.filter(e => e.timestamp >= filters.from);
    }
    if (filters.to) {
      entries = entries.filter(e => e.timestamp <= filters.to);
    }
  }
  
  return entries
    .sort((a, b) => b.timestamp - a.timestamp)
    .slice(0, limit);
}

// ============================================================================
// REQUEST EXECUTION
// ============================================================================

/**
 * Execute API request
 */
export async function executeRequest(
  agentId: string,
  principalId: string,
  providerId: string,
  endpoint: string,
  options: {
    method?: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
    body?: unknown;
    headers?: Record<string, string>;
    queryParams?: Record<string, string>;
    timeout?: number;
    maxRetries?: number;
    skipCache?: boolean;
    purpose?: string;
    authorizationId: string;
    delegationId?: string;
    estimatedCostCents?: number;
    estimatedTokens?: number;
  }
): Promise<APIResponse> {
  const provider = providers.get(providerId);
  if (!provider) {
    return createErrorResponse('unknown', 400, 'Provider not found');
  }
  
  const requestId = `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  
  // Check circuit breaker
  const circuitCheck = checkCircuitBreaker(providerId);
  if (!circuitCheck.closed) {
    logAudit({
      agentId,
      principalId,
      action: 'circuit_open',
      providerId,
      endpoint,
      details: { errorMessage: `Circuit breaker ${circuitCheck.state}` }
    });
    
    return createErrorResponse(requestId, 503, `Service unavailable - circuit breaker ${circuitCheck.state}`);
  }
  
  // Check spending
  const spendingCheck = checkSpendingAllowed(
    agentId,
    providerId,
    options.estimatedCostCents || 1,
    options.estimatedTokens || 0
  );
  if (!spendingCheck.allowed) {
    logAudit({
      agentId,
      principalId,
      action: 'error',
      providerId,
      endpoint,
      details: { errorMessage: spendingCheck.reason || 'Spending not allowed' }
    });
    
    return createErrorResponse(requestId, 402, spendingCheck.reason || 'Spending not allowed');
  }
  
  // Check rate limit
  const rateLimitCheck = checkRateLimit(providerId, endpoint, options.estimatedTokens);
  if (!rateLimitCheck.allowed) {
    logAudit({
      agentId,
      principalId,
      action: 'rate_limited',
      providerId,
      endpoint,
      details: { errorMessage: rateLimitCheck.reason || 'Rate limited' }
    });
    
    return createErrorResponse(requestId, 429, rateLimitCheck.reason || 'Rate limited');
  }
  
  // Check cache
  const cacheKey = generateCacheKey(providerId, endpoint, options.body);
  if (!options.skipCache && options.method !== 'POST') {
    const cached = getCachedResponse(cacheKey);
    if (cached) {
      logAudit({
        agentId,
        principalId,
        action: 'cache_hit',
        providerId,
        endpoint,
        requestId: cached.requestId,
        details: { latencyMs: 0, costCents: 0 }
      });
      
      return { ...cached, cached: true };
    }
  }
  
  // Create request record
  const request: APIRequest = {
    id: requestId,
    agentId,
    principalId,
    providerId,
    endpoint,
    method: options.method || 'POST',
    path: endpoint,
    headers: options.headers || {},
    body: options.body,
    queryParams: options.queryParams,
    authorizationId: options.authorizationId,
    delegationId: options.delegationId,
    purpose: options.purpose,
    createdAt: Date.now(),
    retryCount: 0,
    maxRetries: options.maxRetries ?? gatewayConfig.defaultMaxRetries,
    priority: 'normal'
  };
  
  requests.set(requestId, request);
  
  // Get API key
  const apiKey = getAPIKeyForProvider(providerId);
  
  // Build headers
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...options.headers
  };
  
  // Add authentication
  switch (provider.authType) {
    case 'api_key':
      if (provider.authConfig.apiKey) {
        headers['X-API-Key'] = provider.authConfig.apiKey;
      }
      break;
    case 'bearer_token':
      if (provider.authConfig.bearerToken) {
        headers['Authorization'] = `Bearer ${provider.authConfig.bearerToken}`;
      }
      break;
    // Add other auth types as needed
  }
  
  // Build URL
  const endpointConfig = provider.endpoints[endpoint];
  const url = endpointConfig 
    ? `${provider.baseUrl}${endpointConfig.path}`
    : `${provider.baseUrl}${endpoint}`;
  
  // Execute request with retry
  const startTime = Date.now();
  let lastError: Error | null = null;
  let retryCount = 0;
  const maxRetries = options.maxRetries ?? gatewayConfig.defaultMaxRetries;
  
  while (retryCount <= maxRetries) {
    try {
      const controller = new AbortController();
      const timeout = setTimeout(
        () => controller.abort(),
        options.timeout || gatewayConfig.defaultTimeoutMs
      );
      
      request.sentAt = Date.now();
      
      const response = await fetch(url, {
        method: options.method || 'POST',
        headers,
        body: options.body ? JSON.stringify(options.body) : undefined,
        signal: controller.signal
      });
      
      clearTimeout(timeout);
      
      const latencyMs = Date.now() - startTime;
      const responseBody = await response.json().catch(() => null);
      
      // Record rate limit usage
      recordRateLimitUsage(providerId, options.estimatedTokens);
      
      if (!response.ok) {
        recordCircuitFailure(providerId);
        
        // Retry on 5xx errors
        if (response.status >= 500 && retryCount < maxRetries) {
          retryCount++;
          request.retryCount = retryCount;
          
          logAudit({
            agentId,
            principalId,
            action: 'retry',
            providerId,
            endpoint,
            requestId,
            details: {
              statusCode: response.status,
              retryCount,
              errorMessage: `Server error, retrying (${retryCount}/${maxRetries})`
            }
          });
          
          // Exponential backoff
          await new Promise(resolve => 
            setTimeout(resolve, gatewayConfig.defaultRetryBackoffMs * Math.pow(2, retryCount - 1))
          );
          
          continue;
        }
        
        // Record spending (partial cost for failed requests)
        if (spendingCheck.allocationId) {
          recordSpending(spendingCheck.allocationId, options.estimatedCostCents || 1, 0);
        }
        
        logAudit({
          agentId,
          principalId,
          action: 'error',
          providerId,
          endpoint,
          requestId,
          details: {
            statusCode: response.status,
            latencyMs,
            costCents: options.estimatedCostCents || 0,
            errorMessage: JSON.stringify(responseBody)
          }
        });
        
        return createErrorResponse(requestId, response.status, JSON.stringify(responseBody));
      }
      
      // Success
      recordCircuitSuccess(providerId);
      
      const apiResponse: APIResponse = {
        id: `resp_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        requestId,
        statusCode: response.status,
        headers: Object.fromEntries(response.headers.entries()),
        body: responseBody,
        latencyMs,
        promptTokens: responseBody?.usage?.prompt_tokens,
        completionTokens: responseBody?.usage?.completion_tokens,
        totalTokens: responseBody?.usage?.total_tokens,
        costCents: options.estimatedCostCents || 1,
        success: true,
        cached: false,
        cacheKey
      };
      
      responses.set(apiResponse.id, apiResponse);
      request.completedAt = Date.now();
      
      // Record spending
      if (spendingCheck.allocationId) {
        recordSpending(
          spendingCheck.allocationId,
          apiResponse.costCents,
          apiResponse.totalTokens || 0
        );
      }
      
      // Cache response
      if (!options.skipCache && options.method !== 'POST') {
        cacheResponse(cacheKey, apiResponse);
      }
      
      logAudit({
        agentId,
        principalId,
        action: 'response',
        providerId,
        endpoint,
        requestId,
        details: {
          statusCode: response.status,
          latencyMs,
          costCents: apiResponse.costCents,
          tokens: apiResponse.totalTokens
        }
      });
      
      return apiResponse;
      
    } catch (error) {
      lastError = error instanceof Error ? error : new Error('Unknown error');
      retryCount++;
      request.retryCount = retryCount;
      
      recordCircuitFailure(providerId);
      
      if (retryCount <= maxRetries) {
        logAudit({
          agentId,
          principalId,
          action: 'retry',
          providerId,
          endpoint,
          requestId,
          details: {
            retryCount,
            errorMessage: lastError.message
          }
        });
        
        await new Promise(resolve => 
          setTimeout(resolve, gatewayConfig.defaultRetryBackoffMs * Math.pow(2, retryCount - 1))
        );
      }
    }
  }
  
  // All retries exhausted
  logAudit({
    agentId,
    principalId,
    action: 'error',
    providerId,
    endpoint,
    requestId,
    details: {
      errorMessage: lastError?.message || 'Request failed after retries',
      retryCount
    }
  });
  
  return createErrorResponse(requestId, 500, lastError?.message || 'Request failed');
}

/**
 * Create error response
 */
function createErrorResponse(requestId: string, statusCode: number, errorMessage: string): APIResponse {
  return {
    id: `resp_err_${Date.now()}`,
    requestId,
    statusCode,
    headers: {},
    body: { error: errorMessage },
    latencyMs: 0,
    costCents: 0,
    success: false,
    errorMessage,
    cached: false
  };
}

// ============================================================================
// GATEWAY CONFIGURATION
// ============================================================================

/**
 * Update gateway configuration
 */
export function updateGatewayConfig(config: Partial<GatewayConfig>): GatewayConfig {
  gatewayConfig = { ...gatewayConfig, ...config };
  return gatewayConfig;
}

/**
 * Get gateway configuration
 */
export function getGatewayConfig(): GatewayConfig {
  return { ...gatewayConfig };
}

// ============================================================================
// STATISTICS
// ============================================================================

/**
 * Get gateway statistics
 */
export function getGatewayStatistics(): {
  providers: number;
  activeProviders: number;
  totalRequests: number;
  totalResponses: number;
  cacheSize: number;
  cacheHitRate: number;
  auditLogSize: number;
  circuitBreakers: {
    closed: number;
    open: number;
    halfOpen: number;
  };
} {
  let totalCacheHits = 0;
  let totalCacheLookups = 0;
  
  for (const entry of cache.values()) {
    totalCacheHits += entry.hits;
  }
  
  for (const audit of auditLog.values()) {
    if (audit.action === 'cache_hit') totalCacheLookups++;
    if (audit.action === 'cache_miss') totalCacheLookups++;
  }
  
  const circuitStates = Array.from(circuitBreakers.values());
  
  return {
    providers: providers.size,
    activeProviders: getActiveProviders().length,
    totalRequests: requests.size,
    totalResponses: responses.size,
    cacheSize: cache.size,
    cacheHitRate: totalCacheLookups > 0 ? totalCacheHits / totalCacheLookups : 0,
    auditLogSize: auditLog.size,
    circuitBreakers: {
      closed: circuitStates.filter(cb => cb.state === 'closed').length,
      open: circuitStates.filter(cb => cb.state === 'open').length,
      halfOpen: circuitStates.filter(cb => cb.state === 'half_open').length
    }
  };
}

// ============================================================================
// TESTS
// ============================================================================

/**
 * Run API Gateway tests
 */
export function runAPIGatewayTests(): {
  passed: boolean;
  tests: { total: number; passed: number; failed: number };
  results: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const results: Array<{ name: string; passed: boolean; error?: string }> = [];
  let passed = 0;
  let failed = 0;
  
  // Test 1: Provider registration
  try {
    const provider = registerProvider({
      provider: 'openai',
      name: 'Test OpenAI',
      authType: 'api_key',
      authConfig: { apiKey: 'test-key' },
      baseUrl: 'https://api.openai.com/v1',
      endpoints: {
        chat: { path: '/chat/completions', method: 'POST' }
      },
      features: { streaming: true, batching: false, async: false, webhooks: false },
      healthCheck: { intervalMs: 60000, timeoutMs: 5000 }
    });
    
    if (provider && providers.has(provider.id)) {
      results.push({ name: 'Provider Registration', passed: true });
      passed++;
    } else {
      results.push({ name: 'Provider Registration', passed: false, error: 'Provider not stored' });
      failed++;
    }
  } catch (error) {
    results.push({ name: 'Provider Registration', passed: false, error: String(error) });
    failed++;
  }
  
  // Test 2: API Key storage
  try {
    const providersList = Array.from(providers.values());
    if (providersList.length > 0) {
      const key = storeAPIKey(providersList[0].id, 'Test Key', 'sk-test-12345');
      if (key && key.keyPrefix === 'sk-t') {
        results.push({ name: 'API Key Storage', passed: true });
        passed++;
      } else {
        results.push({ name: 'API Key Storage', passed: false, error: 'Key prefix mismatch' });
        failed++;
      }
    } else {
      results.push({ name: 'API Key Storage', passed: false, error: 'No provider available' });
      failed++;
    }
  } catch (error) {
    results.push({ name: 'API Key Storage', passed: false, error: String(error) });
    failed++;
  }
  
  // Test 3: Spending allocation
  try {
    const providersList = Array.from(providers.values());
    if (providersList.length > 0) {
      const allocation = createSpendingAllocation(
        'agent-test',
        'principal-test',
        providersList[0].id,
        { dailyBudgetCents: 1000 }
      );
      if (allocation && allocation.dailyBudgetCents === 1000) {
        results.push({ name: 'Spending Allocation', passed: true });
        passed++;
      } else {
        results.push({ name: 'Spending Allocation', passed: false, error: 'Allocation mismatch' });
        failed++;
      }
    } else {
      results.push({ name: 'Spending Allocation', passed: false, error: 'No provider available' });
      failed++;
    }
  } catch (error) {
    results.push({ name: 'Spending Allocation', passed: false, error: String(error) });
    failed++;
  }
  
  // Test 4: Circuit breaker
  try {
    const providersList = Array.from(providers.values());
    if (providersList.length > 0) {
      const check = checkCircuitBreaker(providersList[0].id);
      if (check.closed && check.state === 'closed') {
        results.push({ name: 'Circuit Breaker', passed: true });
        passed++;
      } else {
        results.push({ name: 'Circuit Breaker', passed: false, error: `Unexpected state: ${check.state}` });
        failed++;
      }
    } else {
      results.push({ name: 'Circuit Breaker', passed: false, error: 'No provider available' });
      failed++;
    }
  } catch (error) {
    results.push({ name: 'Circuit Breaker', passed: false, error: String(error) });
    failed++;
  }
  
  // Test 5: Rate limiting
  try {
    const providersList = Array.from(providers.values());
    if (providersList.length > 0) {
      const check = checkRateLimit(providersList[0].id);
      if (check.allowed) {
        results.push({ name: 'Rate Limiting', passed: true });
        passed++;
      } else {
        results.push({ name: 'Rate Limiting', passed: false, error: check.reason });
        failed++;
      }
    } else {
      results.push({ name: 'Rate Limiting', passed: false, error: 'No provider available' });
      failed++;
    }
  } catch (error) {
    results.push({ name: 'Rate Limiting', passed: false, error: String(error) });
    failed++;
  }
  
  // Test 6: Cache operations
  try {
    const cacheKey = generateCacheKey('test-provider', 'test-endpoint', { test: 'data' });
    const mockResponse: APIResponse = {
      id: 'test-response',
      requestId: 'test-request',
      statusCode: 200,
      headers: {},
      body: { result: 'success' },
      latencyMs: 100,
      costCents: 1,
      success: true,
      cached: false
    };
    
    cacheResponse(cacheKey, mockResponse);
    const retrieved = getCachedResponse(cacheKey);
    
    if (retrieved && retrieved.cached) {
      results.push({ name: 'Cache Operations', passed: true });
      passed++;
    } else {
      results.push({ name: 'Cache Operations', passed: false, error: 'Cache retrieval failed' });
      failed++;
    }
  } catch (error) {
    results.push({ name: 'Cache Operations', passed: false, error: String(error) });
    failed++;
  }
  
  // Test 7: Audit logging
  try {
    const entry = logAudit({
      agentId: 'test-agent',
      principalId: 'test-principal',
      action: 'request',
      providerId: 'test-provider',
      details: {}
    });
    
    if (entry && auditLog.has(entry.id)) {
      results.push({ name: 'Audit Logging', passed: true });
      passed++;
    } else {
      results.push({ name: 'Audit Logging', passed: false, error: 'Audit entry not stored' });
      failed++;
    }
  } catch (error) {
    results.push({ name: 'Audit Logging', passed: false, error: String(error) });
    failed++;
  }
  
  // Test 8: Statistics
  try {
    const stats = getGatewayStatistics();
    if (typeof stats.providers === 'number' && typeof stats.cacheHitRate === 'number') {
      results.push({ name: 'Statistics', passed: true });
      passed++;
    } else {
      results.push({ name: 'Statistics', passed: false, error: 'Invalid statistics' });
      failed++;
    }
  } catch (error) {
    results.push({ name: 'Statistics', passed: false, error: String(error) });
    failed++;
  }
  
  return {
    passed: failed === 0,
    tests: { total: passed + failed, passed, failed },
    results
  };
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

export default {
  // Provider Management
  registerProvider,
  getProvider,
  getProvidersByType,
  getActiveProviders,
  updateProviderStatus,
  checkProviderHealth,
  
  // API Key Management
  storeAPIKey,
  getAPIKeyForProvider,
  rotateAPIKey,
  
  // Spending Allocation
  createSpendingAllocation,
  getSpendingAllocation,
  checkSpendingAllowed,
  recordSpending,
  
  // Circuit Breaker
  checkCircuitBreaker,
  recordCircuitSuccess,
  recordCircuitFailure,
  
  // Rate Limiting
  checkRateLimit,
  recordRateLimitUsage,
  
  // Caching
  generateCacheKey,
  getCachedResponse,
  cacheResponse,
  invalidateCacheByTags,
  
  // Audit Logging
  logAudit,
  getAuditLog,
  
  // Request Execution
  executeRequest,
  
  // Configuration
  updateGatewayConfig,
  getGatewayConfig,
  
  // Statistics
  getGatewayStatistics,
  
  // Tests
  runAPIGatewayTests
};
