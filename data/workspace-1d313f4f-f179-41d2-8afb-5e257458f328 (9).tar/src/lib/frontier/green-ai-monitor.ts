/**
 * Green AI Monitor - Carbon footprint and energy optimization
 * @module frontier/green-ai-monitor
 */
export type EnergySource = 'grid' | 'solar' | 'wind' | 'hydro' | 'mixed';
export type OptimizationGoal = 'carbon' | 'energy' | 'cost' | 'balanced';

export interface EnergyProfile {
  id: string; systemId: string; region: string;
  energySource: EnergySource; carbonIntensity: number; // gCO2/kWh
  pue: number; // Power Usage Effectiveness
  efficiency: number; createdAt: number;
}

export interface EnergyMeasurement {
  id: string; systemId: string; timestamp: number;
  energyKWh: number; carbonKg: number; cost: number;
  inferenceCount: number; trainingJobs: number;
}

export interface CarbonFootprint {
  id: string; systemId: string; period: {start: number; end: number};
  operationalKg: number; embodiedKg: number; totalKg: number;
  offsetsKg: number; netKg: number;
}

export interface OptimizationRecommendation {
  id: string; systemId: string; type: 'model' | 'hardware' | 'scheduling' | 'renewable';
  description: string; potentialSavingsKg: number;
  potentialSavingsPercent: number; priority: number;
}

export interface SustainabilityGoal {
  id: string; systemId: string; targetCarbonKg: number;
  targetDate: number; currentProgress: number;
  status: 'on_track' | 'at_risk' | 'achieved';
}

const profiles = new Map<string, EnergyProfile>();
const measurements = new Map<string, EnergyMeasurement>();
const footprints = new Map<string, CarbonFootprint>();
const recommendations = new Map<string, OptimizationRecommendation>();
const goals = new Map<string, SustainabilityGoal>();

// Regional carbon intensity (gCO2/kWh)
const carbonIntensity: Record<string, number> = {
  'us-east': 400, 'us-west': 300, 'eu-west': 250,
  'eu-central': 350, 'asia-east': 500, 'default': 400
};

export function createProfile(config: {systemId: string; region: string; energySource?: EnergySource; pue?: number}): EnergyProfile {
  const ci = carbonIntensity[config.region] || carbonIntensity['default'];
  const profile: EnergyProfile = {
    id: `ep_${Date.now()}_${Math.random().toString(36).substr(2,6)}`,
    ...config, energySource: config.energySource || 'grid',
    carbonIntensity: ci, pue: config.pue || 1.5,
    efficiency: 1 / (config.pue || 1.5), createdAt: Date.now()
  };
  profiles.set(profile.id, profile);
  return profile;
}

export function recordMeasurement(systemId: string, data: {
  energyKWh: number; inferenceCount: number; trainingJobs: number;
}): EnergyMeasurement {
  const profile = Array.from(profiles.values()).find(p => p.systemId === systemId);
  const ci = profile?.carbonIntensity || 400;
  const costPerKWh = 0.12; // Average cost
  
  const measurement: EnergyMeasurement = {
    id: `em_${Date.now()}`, systemId, timestamp: Date.now(),
    energyKWh: data.energyKWh, carbonKg: data.energyKWh * ci / 1000,
    cost: data.energyKWh * costPerKWh,
    inferenceCount: data.inferenceCount, trainingJobs: data.trainingJobs
  };
  measurements.set(measurement.id, measurement);
  return measurement;
}

export function calculateFootprint(systemId: string, start: number, end: number): CarbonFootprint {
  const systemMeasurements = Array.from(measurements.values())
    .filter(m => m.systemId === systemId && m.timestamp >= start && m.timestamp <= end);
  
  const operationalKg = systemMeasurements.reduce((s, m) => s + m.carbonKg, 0);
  const embodiedKg = operationalKg * 0.2; // ~20% embodied carbon
  
  const footprint: CarbonFootprint = {
    id: `cf_${Date.now()}`, systemId, period: {start, end},
    operationalKg, embodiedKg, totalKg: operationalKg + embodiedKg,
    offsetsKg: 0, netKg: operationalKg + embodiedKg
  };
  footprints.set(footprint.id, footprint);
  return footprint;
}

export function purchaseOffsets(systemId: string, kg: number): number {
  // Calculate net carbon after offsets
  const systemFootprints = Array.from(footprints.values()).filter(f => f.systemId === systemId);
  const total = systemFootprints.reduce((s, f) => s + f.totalKg, 0);
  const currentOffsets = systemFootprints.reduce((s, f) => s + f.offsetsKg, 0);
  const newOffsets = Math.min(kg, total - currentOffsets);
  
  for (const f of systemFootprints) {
    if (f.offsetsKg < f.totalKg) {
      const toAdd = Math.min(newOffsets, f.totalKg - f.offsetsKg);
      f.offsetsKg += toAdd;
      f.netKg = f.totalKg - f.offsetsKg;
    }
  }
  return newOffsets;
}

export function generateRecommendations(systemId: string): OptimizationRecommendation[] {
  const recs: OptimizationRecommendation[] = [];
  const profile = Array.from(profiles.values()).find(p => p.systemId === systemId);
  
  recs.push({
    id: `rec_${Date.now()}_1`, systemId, type: 'model',
    description: 'Use model quantization to reduce inference energy by 40%',
    potentialSavingsKg: profile ? profile.carbonIntensity * 10 / 1000 : 4,
    potentialSavingsPercent: 40, priority: 1
  });
  
  recs.push({
    id: `rec_${Date.now()}_2`, systemId, type: 'scheduling',
    description: 'Schedule training during low carbon intensity periods',
    potentialSavingsKg: profile ? profile.carbonIntensity * 5 / 1000 : 2,
    potentialSavingsPercent: 20, priority: 2
  });
  
  recs.push({
    id: `rec_${Date.now()}_3`, systemId, type: 'hardware',
    description: 'Use energy-efficient accelerators (TPU/GPU)',
    potentialSavingsKg: profile ? profile.carbonIntensity * 8 / 1000 : 3.2,
    potentialSavingsPercent: 30, priority: 3
  });
  
  recs.forEach(r => recommendations.set(r.id, r));
  return recs;
}

export function setGoal(systemId: string, targetKg: number, targetDate: number): SustainabilityGoal {
  const current = calculateFootprint(systemId, Date.now() - 86400000 * 30, Date.now());
  const goal: SustainabilityGoal = {
    id: `goal_${Date.now()}`, systemId, targetCarbonKg: targetKg, targetDate,
    currentProgress: current.totalKg, status: 'on_track'
  };
  goals.set(goal.id, goal);
  return goal;
}

export function getProfile(id: string): EnergyProfile | undefined { return profiles.get(id); }
export function getMeasurement(id: string): EnergyMeasurement | undefined { return measurements.get(id); }

export function getGreenAIStats() {
  const allMeasurements = Array.from(measurements.values());
  return {
    profiles: profiles.size, measurements: measurements.size,
    totalEnergyKWh: allMeasurements.reduce((s,m) => s + m.energyKWh, 0),
    totalCarbonKg: allMeasurements.reduce((s,m) => s + m.carbonKg, 0),
    totalCost: allMeasurements.reduce((s,m) => s + m.cost, 0),
    goals: goals.size, recommendations: recommendations.size
  };
}

export function runGreenAIMonitorTests() {
  const results: {name: string; passed: boolean}[] = [];
  try { const p = createProfile({systemId:'sys1',region:'us-west'}); results.push({name:'Profile',passed:!!p.carbonIntensity}); } catch { results.push({name:'Profile',passed:false}); }
  try { const m = recordMeasurement('sys1',{energyKWh:10,inferenceCount:100,trainingJobs:1}); results.push({name:'Measure',passed:m.carbonKg>0}); } catch { results.push({name:'Measure',passed:false}); }
  try { const f = calculateFootprint('sys1',Date.now()-86400000,Date.now()); results.push({name:'Footprint',passed:f.totalKg>=0}); } catch { results.push({name:'Footprint',passed:false}); }
  try { const r = generateRecommendations('sys1'); results.push({name:'Recommend',passed:r.length>0}); } catch { results.push({name:'Recommend',passed:false}); }
  try { const s = getGreenAIStats(); results.push({name:'Stats',passed:s.profiles>0}); } catch { results.push({name:'Stats',passed:false}); }
  const passed = results.filter(r=>r.passed).length, failed = results.filter(r=>!r.passed).length;
  return {passed: failed===0, tests:{total:results.length,passed,failed}, results};
}

export default {createProfile,recordMeasurement,calculateFootprint,purchaseOffsets,generateRecommendations,setGoal,getProfile,getMeasurement,getGreenAIStats,runGreenAIMonitorTests};
