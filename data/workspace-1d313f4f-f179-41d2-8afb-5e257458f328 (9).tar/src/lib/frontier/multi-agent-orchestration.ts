/**
 * Multi-Agent Orchestration System
 * =================================
 * 
 * Coordinates multiple AI agents for collaborative detection and analysis.
 * Enables sophisticated multi-agent workflows with consensus, specialization,
 * and hierarchical task delegation.
 * 
 * Features:
 * - Agent registry with capability mapping
 * - Task decomposition and distribution
 * - Consensus-based decision making
 * - Hierarchical agent coordination
 * - Inter-agent communication protocol
 * - Workload balancing
 * - Result aggregation and conflict resolution
 * - Agent health monitoring
 * - Fallback and recovery mechanisms
 * - Performance optimization
 * 
 * @module frontier/multi-agent-orchestration
 * @version 1.0.0
 */

// ============================================================================
// TYPES
// ============================================================================

/**
 * Agent status
 */
export type AgentStatus = 
  | 'idle'
  | 'busy'
  | 'error'
  | 'offline'
  | 'maintenance';

/**
 * Task priority
 */
export type TaskPriority = 'low' | 'normal' | 'high' | 'critical' | 'urgent';

/**
 * Task status
 */
export type TaskStatus = 
  | 'pending'
  | 'assigned'
  | 'running'
  | 'completed'
  | 'failed'
  | 'cancelled'
  | 'timeout';

/**
 * Consensus strategy
 */
export type ConsensusStrategy = 
  | 'majority'          // Simple majority vote
  | 'unanimous'         // All agents must agree
  | 'weighted'          // Weight by agent confidence/expertise
  | 'expert'            // Defer to highest expertise agent
  | 'cascade'           // Sequential refinement
  | 'ensemble'          // Average/combine all outputs
  | 'voting_committee'; // Selected committee votes

/**
 * Agent capability
 */
export interface AgentCapability {
  id: string;
  name: string;
  description: string;
  inputTypes: string[];
  outputTypes: string[];
  requiredResources: string[];
  estimatedTimeMs: number;
  accuracy: number;
  costUnits: number;
}

/**
 * Registered agent
 */
export interface RegisteredAgent {
  id: string;
  name: string;
  type: 'detector' | 'analyzer' | 'validator' | 'coordinator' | 'specialist' | 'hybrid';
  capabilities: AgentCapability[];
  
  // Status
  status: AgentStatus;
  currentTasks: string[];
  maxConcurrentTasks: number;
  
  // Performance
  metrics: {
    totalTasksCompleted: number;
    successfulTasks: number;
    failedTasks: number;
    averageLatencyMs: number;
    averageAccuracy: number;
    lastTaskTime?: number;
  };
  
  // Resources
  resources: {
    cpu: number;      // Percentage
    memory: number;   // MB
    gpu?: number;     // Percentage
    custom?: Record<string, number>;
  };
  
  // Communication
  endpoint?: string;
  protocol: 'http' | 'websocket' | 'grpc' | 'internal';
  
  // Trust and permissions
  trustLevel: number; // 0-100
  permissions: string[];
  
  // Metadata
  metadata?: Record<string, unknown>;
  registeredAt: number;
  lastHeartbeat: number;
}

/**
 * Orchestration task
 */
export interface OrchestrationTask {
  id: string;
  type: string;
  description: string;
  priority: TaskPriority;
  status: TaskStatus;
  
  // Input/Output
  input: unknown;
  output?: unknown;
  result?: TaskResult;
  
  // Assignment
  assignedAgents: string[];
  primaryAgent?: string;
  
  // Dependencies
  dependencies: string[];
  dependents: string[];
  
  // Timing
  createdAt: number;
  assignedAt?: number;
  startedAt?: number;
  completedAt?: number;
  deadline?: number;
  timeoutMs: number;
  
  // Retry
  retryCount: number;
  maxRetries: number;
  
  // Consensus
  requiresConsensus: boolean;
  consensusStrategy?: ConsensusStrategy;
  consensusThreshold?: number;
  agentResults?: Map<string, TaskResult>;
  
  // Parent/Child
  parentTaskId?: string;
  childTaskIds: string[];
  
  // Context
  sessionId?: string;
  metadata?: Record<string, unknown>;
}

/**
 * Task result
 */
export interface TaskResult {
  taskId: string;
  agentId: string;
  success: boolean;
  
  // Output
  output: unknown;
  confidence: number;
  
  // Timing
  startTime: number;
  endTime: number;
  durationMs: number;
  
  // Details
  method: string;
  resources: Record<string, number>;
  warnings?: string[];
  errors?: string[];
  
  // Evidence
  evidence?: {
    type: string;
    data: unknown;
    hash: string;
  }[];
}

/**
 * Consensus result
 */
export interface ConsensusResult {
  taskId: string;
  strategy: ConsensusStrategy;
  
  // Votes
  votes: Array<{
    agentId: string;
    output: unknown;
    confidence: number;
    weight: number;
  }>;
  
  // Outcome
  consensus: boolean;
  agreedOutput: unknown;
  confidence: number;
  agreementRatio: number;
  
  // Details
  dissentingAgents: string[];
  conflictResolution?: string;
  processingTimeMs: number;
}

/**
 * Agent message
 */
export interface AgentMessage {
  id: string;
  from: string;
  to: string | 'broadcast' | 'coordinator';
  type: 'task' | 'result' | 'query' | 'response' | 'alert' | 'heartbeat' | 'status';
  payload: unknown;
  priority: TaskPriority;
  timestamp: number;
  expiresAt?: number;
  requiresAck: boolean;
  acked: boolean;
}

/**
 * Orchestration workflow
 */
export interface OrchestrationWorkflow {
  id: string;
  name: string;
  description: string;
  
  // Steps
  steps: Array<{
    id: string;
    name: string;
    type: 'task' | 'parallel' | 'sequential' | 'conditional' | 'loop';
    taskSpec?: Partial<OrchestrationTask>;
    parallelSteps?: string[];
    sequentialSteps?: string[];
    condition?: {
      field: string;
      operator: 'eq' | 'neq' | 'gt' | 'gte' | 'lt' | 'lte' | 'contains';
      value: unknown;
    };
    loopConfig?: {
      over: string;
      maxIterations: number;
    };
  }>;
  
  // Flow
  entryPoint: string;
  transitions: Record<string, string[]>;
  
  // Error handling
  onError: 'fail' | 'retry' | 'skip' | 'fallback';
  fallbackSteps?: string[];
  
  // Status
  status: 'idle' | 'running' | 'completed' | 'failed' | 'paused';
  currentStep?: string;
  
  // Metadata
  createdAt: number;
  updatedAt: number;
}

/**
 * Workflow execution
 */
export interface WorkflowExecution {
  id: string;
  workflowId: string;
  status: 'pending' | 'running' | 'completed' | 'failed' | 'cancelled';
  
  // Context
  input: unknown;
  output?: unknown;
  
  // Progress
  currentStep: string;
  completedSteps: string[];
  stepResults: Record<string, TaskResult>;
  
  // Timing
  startedAt: number;
  completedAt?: number;
  
  // Tasks
  tasks: string[];
}

/**
 * Orchestration configuration
 */
export interface OrchestrationConfig {
  // Task management
  maxQueueSize: number;
  defaultTimeout: number;
  defaultMaxRetries: number;
  
  // Agent selection
  agentSelectionStrategy: 'first_available' | 'least_loaded' | 'highest_accuracy' | 'round_robin' | 'specialized';
  
  // Consensus
  defaultConsensusStrategy: ConsensusStrategy;
  defaultConsensusThreshold: number;
  minAgentsForConsensus: number;
  
  // Load balancing
  loadBalancingEnabled: boolean;
  healthCheckIntervalMs: number;
  
  // Communication
  messageTimeoutMs: number;
  heartbeatIntervalMs: number;
  heartbeatTimeoutMs: number;
  
  // Performance
  maxConcurrentWorkflows: number;
  taskBatchSize: number;
}

// ============================================================================
// STORAGE
// ============================================================================

const agents = new Map<string, RegisteredAgent>();
const tasks = new Map<string, OrchestrationTask>();
const messages = new Map<string, AgentMessage[]>();
const workflows = new Map<string, OrchestrationWorkflow>();
const executions = new Map<string, WorkflowExecution>();

// Task queue
let taskQueue: string[] = [];

// Configuration
let orchestrationConfig: OrchestrationConfig = {
  maxQueueSize: 10000,
  defaultTimeout: 60000,
  defaultMaxRetries: 3,
  agentSelectionStrategy: 'specialized',
  defaultConsensusStrategy: 'weighted',
  defaultConsensusThreshold: 0.6,
  minAgentsForConsensus: 3,
  loadBalancingEnabled: true,
  healthCheckIntervalMs: 30000,
  messageTimeoutMs: 30000,
  heartbeatIntervalMs: 10000,
  heartbeatTimeoutMs: 30000,
  maxConcurrentWorkflows: 10,
  taskBatchSize: 10
};

// ============================================================================
// AGENT REGISTRATION
// ============================================================================

/**
 * Register an agent
 */
export function registerAgent(
  name: string,
  type: RegisteredAgent['type'],
  capabilities: AgentCapability[],
  options?: {
    maxConcurrentTasks?: number;
    endpoint?: string;
    protocol?: RegisteredAgent['protocol'];
    trustLevel?: number;
    permissions?: string[];
    resources?: RegisteredAgent['resources'];
    metadata?: Record<string, unknown>;
  }
): RegisteredAgent {
  const id = `agent_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  
  const agent: RegisteredAgent = {
    id,
    name,
    type,
    capabilities,
    status: 'idle',
    currentTasks: [],
    maxConcurrentTasks: options?.maxConcurrentTasks ?? 5,
    metrics: {
      totalTasksCompleted: 0,
      successfulTasks: 0,
      failedTasks: 0,
      averageLatencyMs: 0,
      averageAccuracy: 0
    },
    resources: options?.resources ?? { cpu: 0, memory: 0 },
    endpoint: options?.endpoint,
    protocol: options?.protocol ?? 'internal',
    trustLevel: options?.trustLevel ?? 50,
    permissions: options?.permissions ?? [],
    metadata: options?.metadata,
    registeredAt: Date.now(),
    lastHeartbeat: Date.now()
  };
  
  agents.set(id, agent);
  return agent;
}

/**
 * Get agent by ID
 */
export function getAgent(id: string): RegisteredAgent | undefined {
  return agents.get(id);
}

/**
 * Get all agents
 */
export function getAllAgents(): RegisteredAgent[] {
  return Array.from(agents.values());
}

/**
 * Get available agents
 */
export function getAvailableAgents(capability?: string): RegisteredAgent[] {
  return Array.from(agents.values()).filter(agent => {
    if (agent.status !== 'idle') return false;
    if (agent.currentTasks.length >= agent.maxConcurrentTasks) return false;
    if (capability && !agent.capabilities.some(c => c.id === capability || c.name === capability)) return false;
    return true;
  });
}

/**
 * Update agent heartbeat
 */
export function updateHeartbeat(agentId: string): boolean {
  const agent = agents.get(agentId);
  if (!agent) return false;
  
  agent.lastHeartbeat = Date.now();
  
  // Update status if was offline
  if (agent.status === 'offline') {
    agent.status = 'idle';
  }
  
  return true;
}

/**
 * Update agent status
 */
export function updateAgentStatus(agentId: string, status: AgentStatus): boolean {
  const agent = agents.get(agentId);
  if (!agent) return false;
  
  agent.status = status;
  return true;
}

// ============================================================================
// TASK MANAGEMENT
// ============================================================================

/**
 * Create a new task
 */
export function createTask(
  type: string,
  input: unknown,
  options?: {
    description?: string;
    priority?: TaskPriority;
    timeoutMs?: number;
    maxRetries?: number;
    requiresConsensus?: boolean;
    consensusStrategy?: ConsensusStrategy;
    consensusThreshold?: number;
    dependencies?: string[];
    deadline?: number;
    sessionId?: string;
    metadata?: Record<string, unknown>;
  }
): OrchestrationTask {
  const id = `task_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  
  const task: OrchestrationTask = {
    id,
    type,
    description: options?.description ?? `Task of type ${type}`,
    priority: options?.priority ?? 'normal',
    status: 'pending',
    input,
    assignedAgents: [],
    dependencies: options?.dependencies ?? [],
    dependents: [],
    createdAt: Date.now(),
    timeoutMs: options?.timeoutMs ?? orchestrationConfig.defaultTimeout,
    retryCount: 0,
    maxRetries: options?.maxRetries ?? orchestrationConfig.defaultMaxRetries,
    requiresConsensus: options?.requiresConsensus ?? false,
    consensusStrategy: options?.consensusStrategy ?? orchestrationConfig.defaultConsensusStrategy,
    consensusThreshold: options?.consensusThreshold ?? orchestrationConfig.defaultConsensusThreshold,
    agentResults: new Map(),
    childTaskIds: [],
    sessionId: options?.sessionId,
    metadata: options?.metadata
  };
  
  tasks.set(id, task);
  
  // Add to queue
  taskQueue.push(id);
  prioritizeQueue();
  
  // Update dependency tracking
  for (const depId of task.dependencies) {
    const depTask = tasks.get(depId);
    if (depTask) {
      depTask.dependents.push(id);
    }
  }
  
  return task;
}

/**
 * Get task by ID
 */
export function getTask(id: string): OrchestrationTask | undefined {
  return tasks.get(id);
}

/**
 * Assign task to agent
 */
export function assignTask(taskId: string, agentId?: string): boolean {
  const task = tasks.get(taskId);
  if (!task || task.status !== 'pending') return false;
  
  // Check dependencies
  const pendingDeps = task.dependencies.filter(depId => {
    const dep = tasks.get(depId);
    return dep && dep.status !== 'completed';
  });
  
  if (pendingDeps.length > 0) return false;
  
  // Select agent if not specified
  let selectedAgentId = agentId;
  if (!selectedAgentId) {
    const selected = selectAgent(task);
    if (!selected) return false;
    selectedAgentId = selected.id;
  }
  
  const agent = agents.get(selectedAgentId);
  if (!agent || agent.status !== 'idle') return false;
  if (agent.currentTasks.length >= agent.maxConcurrentTasks) return false;
  
  // Assign
  task.assignedAgents.push(selectedAgentId);
  task.primaryAgent = selectedAgentId;
  task.status = 'assigned';
  task.assignedAt = Date.now();
  
  agent.currentTasks.push(taskId);
  if (agent.currentTasks.length >= agent.maxConcurrentTasks) {
    agent.status = 'busy';
  }
  
  return true;
}

/**
 * Select best agent for task
 */
function selectAgent(task: OrchestrationTask): RegisteredAgent | null {
  const availableAgents = getAvailableAgents(task.type);
  
  if (availableAgents.length === 0) return null;
  
  switch (orchestrationConfig.agentSelectionStrategy) {
    case 'first_available':
      return availableAgents[0];
    
    case 'least_loaded':
      return availableAgents.sort((a, b) => 
        a.currentTasks.length - b.currentTasks.length
      )[0];
    
    case 'highest_accuracy':
      return availableAgents.sort((a, b) => 
        b.metrics.averageAccuracy - a.metrics.averageAccuracy
      )[0];
    
    case 'round_robin':
      // Simple round robin
      const lastAgentIdx = availableAgents.findIndex(a => 
        a.id === task.assignedAgents[task.assignedAgents.length - 1]
      );
      return availableAgents[(lastAgentIdx + 1) % availableAgents.length];
    
    case 'specialized':
      // Find agent with matching capability
      const specialized = availableAgents.filter(agent =>
        agent.capabilities.some(cap => 
          cap.id === task.type || 
          cap.inputTypes.includes(task.type) ||
          task.type.includes(cap.id)
        )
      );
      
      if (specialized.length > 0) {
        return specialized.sort((a, b) => 
          b.metrics.averageAccuracy - a.metrics.averageAccuracy
        )[0];
      }
      return availableAgents[0];
    
    default:
      return availableAgents[0];
  }
}

/**
 * Start task execution
 */
export function startTask(taskId: string): boolean {
  const task = tasks.get(taskId);
  if (!task || task.status !== 'assigned') return false;
  
  task.status = 'running';
  task.startedAt = Date.now();
  
  return true;
}

/**
 * Complete task with result
 */
export function completeTask(
  taskId: string,
  result: TaskResult
): boolean {
  const task = tasks.get(taskId);
  if (!task || task.status !== 'running') return false;
  
  task.result = result;
  task.output = result.output;
  task.status = result.success ? 'completed' : 'failed';
  task.completedAt = Date.now();
  
  // Update agent metrics
  const agent = agents.get(result.agentId);
  if (agent) {
    agent.metrics.totalTasksCompleted++;
    if (result.success) {
      agent.metrics.successfulTasks++;
    } else {
      agent.metrics.failedTasks++;
    }
    
    // Update running averages
    const n = agent.metrics.totalTasksCompleted;
    agent.metrics.averageLatencyMs = 
      (agent.metrics.averageLatencyMs * (n - 1) + result.durationMs) / n;
    agent.metrics.averageAccuracy = 
      (agent.metrics.averageAccuracy * (n - 1) + result.confidence) / n;
    
    // Remove from current tasks
    agent.currentTasks = agent.currentTasks.filter(id => id !== taskId);
    if (agent.currentTasks.length < agent.maxConcurrentTasks) {
      agent.status = 'idle';
    }
  }
  
  // Handle consensus
  if (task.requiresConsensus && task.agentResults) {
    task.agentResults.set(result.agentId, result);
    // Consensus handling would continue here
  }
  
  // Trigger dependents
  for (const dependentId of task.dependents) {
    const dependent = tasks.get(dependentId);
    if (dependent && dependent.status === 'pending') {
      assignTask(dependentId);
    }
  }
  
  return true;
}

/**
 * Prioritize task queue
 */
function prioritizeQueue(): void {
  const priorityOrder: Record<TaskPriority, number> = {
    'urgent': 0,
    'critical': 1,
    'high': 2,
    'normal': 3,
    'low': 4
  };
  
  taskQueue.sort((a, b) => {
    const taskA = tasks.get(a);
    const taskB = tasks.get(b);
    if (!taskA || !taskB) return 0;
    return priorityOrder[taskA.priority] - priorityOrder[taskB.priority];
  });
}

// ============================================================================
// CONSENSUS
// ============================================================================

/**
 * Perform consensus on task results
 */
export function performConsensus(
  taskId: string,
  results: TaskResult[]
): ConsensusResult {
  const task = tasks.get(taskId);
  const strategy = task?.consensusStrategy ?? orchestrationConfig.defaultConsensusStrategy;
  const threshold = task?.consensusThreshold ?? orchestrationConfig.defaultConsensusThreshold;
  
  const startTime = Date.now();
  
  // Prepare votes
  const votes = results.map(r => ({
    agentId: r.agentId,
    output: r.output,
    confidence: r.confidence,
    weight: getAgentWeight(r.agentId)
  }));
  
  let consensus = false;
  let agreedOutput: unknown = null;
  let confidence = 0;
  let agreementRatio = 0;
  const dissentingAgents: string[] = [];
  
  switch (strategy) {
    case 'majority':
      // Count outputs
      const outputCounts = new Map<string, { output: unknown; count: number; confidences: number[] }>();
      for (const vote of votes) {
        const key = JSON.stringify(vote.output);
        const existing = outputCounts.get(key);
        if (existing) {
          existing.count++;
          existing.confidences.push(vote.confidence);
        } else {
          outputCounts.set(key, { output: vote.output, count: 1, confidences: [vote.confidence] });
        }
      }
      
      // Find majority
      let maxCount = 0;
      for (const [key, value] of outputCounts) {
        if (value.count > maxCount) {
          maxCount = value.count;
          agreedOutput = value.output;
          agreementRatio = value.count / votes.length;
          confidence = value.confidences.reduce((a, b) => a + b, 0) / value.confidences.length;
        }
      }
      
      consensus = agreementRatio > 0.5;
      dissentingAgents.push(...votes.filter(v => JSON.stringify(v.output) !== JSON.stringify(agreedOutput)).map(v => v.agentId));
      break;
    
    case 'unanimous':
      const firstOutput = JSON.stringify(votes[0]?.output);
      consensus = votes.every(v => JSON.stringify(v.output) === firstOutput);
      if (consensus) {
        agreedOutput = votes[0].output;
        confidence = votes.reduce((sum, v) => sum + v.confidence, 0) / votes.length;
        agreementRatio = 1;
      }
      break;
    
    case 'weighted':
      const weightedOutputs = new Map<string, { output: unknown; weight: number; confidence: number }>();
      
      for (const vote of votes) {
        const key = JSON.stringify(vote.output);
        const existing = weightedOutputs.get(key);
        if (existing) {
          existing.weight += vote.weight;
          existing.confidence += vote.confidence * vote.weight;
        } else {
          weightedOutputs.set(key, { 
            output: vote.output, 
            weight: vote.weight,
            confidence: vote.confidence * vote.weight 
          });
        }
      }
      
      let maxWeight = 0;
      for (const [key, value] of weightedOutputs) {
        if (value.weight > maxWeight) {
          maxWeight = value.weight;
          agreedOutput = value.output;
          confidence = value.confidence / value.weight;
          agreementRatio = value.weight / votes.reduce((sum, v) => sum + v.weight, 0);
        }
      }
      
      consensus = agreementRatio >= threshold;
      break;
    
    case 'expert':
      // Sort by agent trust level and pick highest
      const sortedVotes = [...votes].sort((a, b) => getAgentWeight(b.agentId) - getAgentWeight(a.agentId));
      agreedOutput = sortedVotes[0].output;
      confidence = sortedVotes[0].confidence;
      consensus = true;
      agreementRatio = 1;
      dissentingAgents.push(...sortedVotes.slice(1).map(v => v.agentId));
      break;
    
    case 'ensemble':
      // Combine outputs (for numerical results)
      if (typeof votes[0]?.output === 'number') {
        const totalWeight = votes.reduce((sum, v) => sum + v.weight, 0);
        agreedOutput = votes.reduce((sum, v) => sum + (v.output as number) * v.weight, 0) / totalWeight;
        confidence = votes.reduce((sum, v) => sum + v.confidence * v.weight, 0) / totalWeight;
        consensus = true;
        agreementRatio = 1;
      } else {
        // Fall back to majority for non-numeric
        return performConsensus(taskId, results);
      }
      break;
    
    default:
      // Default to majority
      return performConsensus(taskId, results);
  }
  
  return {
    taskId,
    strategy,
    votes,
    consensus,
    agreedOutput,
    confidence,
    agreementRatio,
    dissentingAgents,
    processingTimeMs: Date.now() - startTime
  };
}

/**
 * Get agent weight for consensus
 */
function getAgentWeight(agentId: string): number {
  const agent = agents.get(agentId);
  if (!agent) return 1;
  
  return (agent.trustLevel / 100) * (agent.metrics.averageAccuracy / 100);
}

// ============================================================================
// WORKFLOW MANAGEMENT
// ============================================================================

/**
 * Create workflow
 */
export function createWorkflow(
  name: string,
  description: string,
  steps: OrchestrationWorkflow['steps'],
  options?: {
    onError?: OrchestrationWorkflow['onError'];
    fallbackSteps?: string[];
  }
): OrchestrationWorkflow {
  const id = `workflow_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  
  const workflow: OrchestrationWorkflow = {
    id,
    name,
    description,
    steps,
    entryPoint: steps[0]?.id ?? '',
    transitions: {},
    onError: options?.onError ?? 'fail',
    fallbackSteps: options?.fallbackSteps,
    status: 'idle',
    createdAt: Date.now(),
    updatedAt: Date.now()
  };
  
  // Build transitions from step dependencies
  for (const step of steps) {
    workflow.transitions[step.id] = [];
  }
  
  workflows.set(id, workflow);
  return workflow;
}

/**
 * Execute workflow
 */
export function executeWorkflow(
  workflowId: string,
  input: unknown
): WorkflowExecution {
  const workflow = workflows.get(workflowId);
  if (!workflow) {
    throw new Error(`Workflow ${workflowId} not found`);
  }
  
  const executionId = `exec_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  
  const execution: WorkflowExecution = {
    id: executionId,
    workflowId,
    status: 'running',
    input,
    currentStep: workflow.entryPoint,
    completedSteps: [],
    stepResults: {},
    startedAt: Date.now(),
    tasks: []
  };
  
  workflow.status = 'running';
  executions.set(executionId, execution);
  
  // Start first step
  executeStep(executionId, workflow.entryPoint, input);
  
  return execution;
}

/**
 * Execute a workflow step
 */
function executeStep(
  executionId: string,
  stepId: string,
  input: unknown
): void {
  const execution = executions.get(executionId);
  const workflow = workflows.get(execution?.workflowId ?? '');
  
  if (!execution || !workflow) return;
  
  const step = workflow.steps.find(s => s.id === stepId);
  if (!step) return;
  
  execution.currentStep = stepId;
  
  switch (step.type) {
    case 'task':
      if (step.taskSpec) {
        const task = createTask(
          step.taskSpec.type ?? stepId,
          input,
          step.taskSpec
        );
        execution.tasks.push(task.id);
        assignTask(task.id);
      }
      break;
    
    case 'parallel':
      if (step.parallelSteps) {
        for (const subStepId of step.parallelSteps) {
          executeStep(executionId, subStepId, input);
        }
      }
      break;
    
    case 'sequential':
      if (step.sequentialSteps && step.sequentialSteps.length > 0) {
        executeStep(executionId, step.sequentialSteps[0], input);
      }
      break;
    
    default:
      // Handle other step types
      break;
  }
}

/**
 * Get execution status
 */
export function getExecution(executionId: string): WorkflowExecution | undefined {
  return executions.get(executionId);
}

// ============================================================================
// AGENT COMMUNICATION
// ============================================================================

/**
 * Send message between agents
 */
export function sendMessage(
  from: string,
  to: string | 'broadcast' | 'coordinator',
  type: AgentMessage['type'],
  payload: unknown,
  options?: {
    priority?: TaskPriority;
    expiresAt?: number;
    requiresAck?: boolean;
  }
): AgentMessage {
  const id = `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  
  const message: AgentMessage = {
    id,
    from,
    to,
    type,
    payload,
    priority: options?.priority ?? 'normal',
    timestamp: Date.now(),
    expiresAt: options?.expiresAt ?? Date.now() + orchestrationConfig.messageTimeoutMs,
    requiresAck: options?.requiresAck ?? false,
    acked: false
  };
  
  // Store message
  const agentMessages = messages.get(to) || [];
  agentMessages.push(message);
  messages.set(to, agentMessages);
  
  return message;
}

/**
 * Get messages for agent
 */
export function getMessages(agentId: string): AgentMessage[] {
  return messages.get(agentId) || [];
}

/**
 * Acknowledge message
 */
export function acknowledgeMessage(messageId: string, agentId: string): boolean {
  const agentMessages = messages.get(agentId);
  if (!agentMessages) return false;
  
  const message = agentMessages.find(m => m.id === messageId);
  if (!message) return false;
  
  message.acked = true;
  return true;
}

// ============================================================================
// HEALTH MONITORING
// ============================================================================

/**
 * Check agent health
 */
export function checkAgentHealth(): {
  healthy: number;
  unhealthy: number;
  offline: number;
  details: Array<{ agentId: string; status: string; lastHeartbeat: number }>;
} {
  const now = Date.now();
  let healthy = 0;
  let unhealthy = 0;
  let offline = 0;
  const details: Array<{ agentId: string; status: string; lastHeartbeat: number }> = [];
  
  for (const agent of agents.values()) {
    const timeSinceHeartbeat = now - agent.lastHeartbeat;
    
    if (timeSinceHeartbeat > orchestrationConfig.heartbeatTimeoutMs) {
      agent.status = 'offline';
      offline++;
    } else if (agent.status === 'error') {
      unhealthy++;
    } else {
      healthy++;
    }
    
    details.push({
      agentId: agent.id,
      status: agent.status,
      lastHeartbeat: agent.lastHeartbeat
    });
  }
  
  return { healthy, unhealthy, offline, details };
}

/**
 * Get orchestration statistics
 */
export function getOrchestrationStatistics(): {
  agents: {
    total: number;
    active: number;
    idle: number;
    busy: number;
    offline: number;
  };
  tasks: {
    total: number;
    pending: number;
    running: number;
    completed: number;
    failed: number;
  };
  workflows: {
    total: number;
    running: number;
    completed: number;
  };
  queueSize: number;
} {
  const agentList = Array.from(agents.values());
  const taskList = Array.from(tasks.values());
  const workflowList = Array.from(workflows.values());
  
  return {
    agents: {
      total: agents.size,
      active: agentList.filter(a => a.status !== 'offline').length,
      idle: agentList.filter(a => a.status === 'idle').length,
      busy: agentList.filter(a => a.status === 'busy').length,
      offline: agentList.filter(a => a.status === 'offline').length
    },
    tasks: {
      total: tasks.size,
      pending: taskList.filter(t => t.status === 'pending').length,
      running: taskList.filter(t => t.status === 'running').length,
      completed: taskList.filter(t => t.status === 'completed').length,
      failed: taskList.filter(t => t.status === 'failed').length
    },
    workflows: {
      total: workflows.size,
      running: workflowList.filter(w => w.status === 'running').length,
      completed: workflowList.filter(w => w.status === 'completed').length
    },
    queueSize: taskQueue.length
  };
}

// ============================================================================
// CONFIGURATION
// ============================================================================

/**
 * Update orchestration configuration
 */
export function updateOrchestrationConfig(config: Partial<OrchestrationConfig>): OrchestrationConfig {
  orchestrationConfig = { ...orchestrationConfig, ...config };
  return orchestrationConfig;
}

/**
 * Get orchestration configuration
 */
export function getOrchestrationConfig(): OrchestrationConfig {
  return { ...orchestrationConfig };
}

// ============================================================================
// TESTS
// ============================================================================

/**
 * Run orchestration tests
 */
export function runOrchestrationTests(): {
  passed: boolean;
  tests: { total: number; passed: number; failed: number };
  results: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const results: Array<{ name: string; passed: boolean; error?: string }> = [];
  let passed = 0;
  let failed = 0;
  
  // Test 1: Agent registration
  try {
    const agent = registerAgent(
      'Test Agent',
      'detector',
      [{ id: 'test_cap', name: 'Test', description: 'Test capability', inputTypes: ['text'], outputTypes: ['result'], requiredResources: [], estimatedTimeMs: 100, accuracy: 0.9, costUnits: 1 }],
      { trustLevel: 80 }
    );
    if (agent && agents.has(agent.id)) {
      results.push({ name: 'Agent Registration', passed: true });
      passed++;
    } else {
      results.push({ name: 'Agent Registration', passed: false, error: 'Agent not registered' });
      failed++;
    }
  } catch (error) {
    results.push({ name: 'Agent Registration', passed: false, error: String(error) });
    failed++;
  }
  
  // Test 2: Task creation
  try {
    const task = createTask('detection', { content: 'test' });
    if (task && tasks.has(task.id)) {
      results.push({ name: 'Task Creation', passed: true });
      passed++;
    } else {
      results.push({ name: 'Task Creation', passed: false, error: 'Task not created' });
      failed++;
    }
  } catch (error) {
    results.push({ name: 'Task Creation', passed: false, error: String(error) });
    failed++;
  }
  
  // Test 3: Agent selection
  try {
    const task = createTask('test_cap', { content: 'test' });
    const available = getAvailableAgents('test_cap');
    if (available.length > 0 || agents.size === 0) {
      results.push({ name: 'Agent Selection', passed: true });
      passed++;
    } else {
      results.push({ name: 'Agent Selection', passed: false, error: 'No available agents' });
      failed++;
    }
  } catch (error) {
    results.push({ name: 'Agent Selection', passed: false, error: String(error) });
    failed++;
  }
  
  // Test 4: Consensus
  try {
    const consensus = performConsensus('test', [
      { taskId: 'test', agentId: 'agent1', success: true, output: { result: 'yes' }, confidence: 0.9, startTime: 0, endTime: 100, durationMs: 100, method: 'test', resources: {} },
      { taskId: 'test', agentId: 'agent2', success: true, output: { result: 'yes' }, confidence: 0.85, startTime: 0, endTime: 100, durationMs: 100, method: 'test', resources: {} },
      { taskId: 'test', agentId: 'agent3', success: true, output: { result: 'no' }, confidence: 0.7, startTime: 0, endTime: 100, durationMs: 100, method: 'test', resources: {} }
    ]);
    if (consensus && typeof consensus.agreementRatio === 'number') {
      results.push({ name: 'Consensus', passed: true });
      passed++;
    } else {
      results.push({ name: 'Consensus', passed: false, error: 'Consensus failed' });
      failed++;
    }
  } catch (error) {
    results.push({ name: 'Consensus', passed: false, error: String(error) });
    failed++;
  }
  
  // Test 5: Message passing
  try {
    const agentList = Array.from(agents.values());
    if (agentList.length >= 2) {
      const msg = sendMessage(agentList[0].id, agentList[1].id, 'query', { test: true });
      if (msg && msg.id) {
        results.push({ name: 'Message Passing', passed: true });
        passed++;
      } else {
        results.push({ name: 'Message Passing', passed: false, error: 'Message not sent' });
        failed++;
      }
    } else {
      results.push({ name: 'Message Passing', passed: true }); // Skip if not enough agents
      passed++;
    }
  } catch (error) {
    results.push({ name: 'Message Passing', passed: false, error: String(error) });
    failed++;
  }
  
  // Test 6: Health monitoring
  try {
    const health = checkAgentHealth();
    if (typeof health.healthy === 'number') {
      results.push({ name: 'Health Monitoring', passed: true });
      passed++;
    } else {
      results.push({ name: 'Health Monitoring', passed: false, error: 'Health check failed' });
      failed++;
    }
  } catch (error) {
    results.push({ name: 'Health Monitoring', passed: false, error: String(error) });
    failed++;
  }
  
  // Test 7: Statistics
  try {
    const stats = getOrchestrationStatistics();
    if (typeof stats.agents.total === 'number' && typeof stats.tasks.total === 'number') {
      results.push({ name: 'Statistics', passed: true });
      passed++;
    } else {
      results.push({ name: 'Statistics', passed: false, error: 'Invalid statistics' });
      failed++;
    }
  } catch (error) {
    results.push({ name: 'Statistics', passed: false, error: String(error) });
    failed++;
  }
  
  // Test 8: Configuration
  try {
    const newConfig = updateOrchestrationConfig({ defaultTimeout: 120000 });
    if (newConfig.defaultTimeout === 120000) {
      results.push({ name: 'Configuration', passed: true });
      passed++;
    } else {
      results.push({ name: 'Configuration', passed: false, error: 'Config not updated' });
      failed++;
    }
  } catch (error) {
    results.push({ name: 'Configuration', passed: false, error: String(error) });
    failed++;
  }
  
  return {
    passed: failed === 0,
    tests: { total: passed + failed, passed, failed },
    results
  };
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

export default {
  // Agent management
  registerAgent,
  getAgent,
  getAllAgents,
  getAvailableAgents,
  updateHeartbeat,
  updateAgentStatus,
  
  // Task management
  createTask,
  getTask,
  assignTask,
  startTask,
  completeTask,
  
  // Consensus
  performConsensus,
  
  // Workflow management
  createWorkflow,
  executeWorkflow,
  getExecution,
  
  // Communication
  sendMessage,
  getMessages,
  acknowledgeMessage,
  
  // Health monitoring
  checkAgentHealth,
  getOrchestrationStatistics,
  
  // Configuration
  updateOrchestrationConfig,
  getOrchestrationConfig,
  
  // Tests
  runOrchestrationTests
};
