/**
 * ATTENTION PATTERN FORENSICS FRONTIER
 * =====================================
 * 
 * Detects deepfakes by analyzing attention patterns and gaze behavior.
 * AI-generated content often has subtle inconsistencies in where attention
 * is focused, how it shifts over time, and how subjects respond to stimuli.
 * 
 * Capabilities:
 * - Gaze direction analysis
 * - Attention heatmaps
 * - Eye contact consistency
 * - Attention shift patterns
 * - Social attention modeling
 * - Joint attention detection
 * - Attention synthesis artifacts
 * - Temporal attention coherence
 * 
 * @module frontier/attention-forensics
 * @version 1.0.0
 */

import { SoftLogic } from './neuro-symbolic';

// ============================================================================
// TYPES
// ============================================================================

export interface GazeVector {
  /** 3D gaze direction */
  direction: [number, number, number];
  /** Gaze origin (eye position) */
  origin: [number, number, number];
  /** Confidence in gaze estimation */
  confidence: number;
  /** Timestamp */
  timestamp: number;
  /** Which eye */
  eye: 'left' | 'right' | 'both';
}

export interface AttentionHeatmap {
  /** Grid values */
  grid: number[][];
  /** Grid dimensions */
  dimensions: { width: number; height: number };
  /** Total attention mass */
  totalMass: number;
  /** Peak location */
  peak: { x: number; y: number };
  /** Dispersion (spread) */
  dispersion: number;
  /** Timestamp */
  timestamp: number;
}

export interface AttentionState {
  /** Current focus point */
  focusPoint: { x: number; y: number };
  /** Attention dispersion */
  dispersion: number;
  /** Attention stability (over time) */
  stability: number;
  /** Objects being attended to */
  attendedObjects: AttendedObject[];
  /** Gaze vectors for all faces */
  gazeVectors: GazeVector[];
  /** Attention heatmap */
  heatmap: AttentionHeatmap;
  /** Timestamp */
  timestamp: number;
}

export interface AttendedObject {
  /** Object ID */
  id: string;
  /** Object type */
  type: 'face' | 'person' | 'object' | 'text' | 'background';
  /** Bounding box */
  bbox: { x: number; y: number; width: number; height: number };
  /** Attention weight */
  attentionWeight: number;
  /** Duration attended */
  durationMs: number;
}

export interface EyeContactAnalysis {
  /** Is eye contact present */
  hasEyeContact: boolean;
  /** Eye contact duration */
  duration: number;
  /** Eye contact consistency */
  consistency: number;
  /** Gaze alignment score */
  alignmentScore: number;
  /** Blink pattern during contact */
  blinkPattern: BlinkPattern;
  /** Pupil response */
  pupilResponse: PupilResponse;
}

export interface BlinkPattern {
  /** Blink rate (blinks/min) */
  rate: number;
  /** Inter-blink intervals */
  intervals: number[];
  /** Blink duration statistics */
  durationStats: { mean: number; std: number; min: number; max: number };
  /** Regularity score */
  regularity: number;
  /** Natural blink pattern score */
  naturalScore: number;
}

export interface PupilResponse {
  /** Pupil size over time */
  sizes: number[];
  /** Pupil reactivity */
  reactivity: number;
  /** Consensual response present */
  consensualResponse: boolean;
  /** Light reflex present */
  lightReflex: boolean;
  /** Pupil symmetry */
  symmetry: number;
}

export interface JointAttention {
  /** Is joint attention occurring */
  present: boolean;
  /** Participants */
  participants: string[];
  /** Shared focus point */
  sharedFocus: { x: number; y: number };
  /** Synchronization score */
  syncScore: number;
  /** Initiation time difference */
  initiationDiff: number;
  /** Attention type */
  type: 'follows_gaze' | 'follows_point' | 'follows_head' | 'spontaneous';
}

export interface AttentionShift {
  /** Shift ID */
  id: string;
  /** Source location */
  from: { x: number; y: number };
  /** Target location */
  to: { x: number; y: number };
  /** Shift duration */
  durationMs: number;
  /** Shift type */
  type: 'saccade' | 'smooth_pursuit' | 'vergence' | 'reflexive';
  /** Peak velocity */
  peakVelocity: number;
  /** Trajectory */
  trajectory: Array<{ x: number; y: number; t: number }>;
  /** Timestamp */
  timestamp: number;
}

export interface AttentionAnomaly {
  /** Anomaly type */
  type: AttentionAnomalyType;
  /** Severity (0-1) */
  severity: number;
  /** Description */
  description: string;
  /** Evidence */
  evidence: string[];
  /** Confidence */
  confidence: number;
}

export type AttentionAnomalyType = 
  | 'gaze_inconsistency'
  | 'attention_freeze'
  | 'unnatural_shifts'
  | 'missing_reflexes'
  | 'synchronization_error'
  | 'spatial_incoherence'
  | 'temporal_incoherence'
  | 'social_attention_mismatch';

export interface AttentionForensicsResult {
  /** Overall deepfake probability */
  deepfakeProbability: number;
  /** Anomalies detected */
  anomalies: AttentionAnomaly[];
  /** Attention coherence score */
  coherenceScore: number;
  /** Naturalness score */
  naturalnessScore: number;
  /** Gaze consistency */
  gazeConsistency: number;
  /** Eye contact analysis */
  eyeContactAnalysis: EyeContactAnalysis | null;
  /** Joint attention analysis */
  jointAttention: JointAttention | null;
  /** Attention timeline */
  timeline: AttentionTimelineEvent[];
  /** Explanation */
  explanation: string;
}

export interface AttentionTimelineEvent {
  timestamp: number;
  type: 'shift' | 'fixation' | 'blink' | 'contact_start' | 'contact_end' | 'anomaly';
  details: Record<string, unknown>;
}

// ============================================================================
// GAZE ESTIMATION
// ============================================================================

/**
 * Estimate gaze direction from facial landmarks
 */
export function estimateGazeDirection(
  landmarks: {
    leftEye: Array<{ x: number; y: number; z?: number }>;
    rightEye: Array<{ x: number; y: number; z?: number }>;
    faceCenter: { x: number; y: number; z?: number };
  },
  imageDimensions: { width: number; height: number }
): GazeVector {
  // Calculate eye centers
  const leftEyeCenter = calculateCenter(landmarks.leftEye);
  const rightEyeCenter = calculateCenter(landmarks.rightEye);
  
  // Calculate pupil position within eye
  const leftPupil = estimatePupilPosition(landmarks.leftEye);
  const rightPupil = estimatePupilPosition(landmarks.rightEye);
  
  // Calculate gaze direction
  // Simplified: use pupil offset from eye center
  const leftGazeDir = calculateGazeFromPupil(leftPupil, leftEyeCenter, imageDimensions);
  const rightGazeDir = calculateGazeFromPupil(rightPupil, rightEyeCenter, imageDimensions);
  
  // Average gaze direction
  const avgGaze: [number, number, number] = [
    (leftGazeDir[0] + rightGazeDir[0]) / 2,
    (leftGazeDir[1] + rightGazeDir[1]) / 2,
    (leftGazeDir[2] + rightGazeDir[2]) / 2
  ];
  
  // Normalize
  const norm = Math.sqrt(avgGaze.reduce((sum, v) => sum + v * v, 0));
  const normalizedGaze = avgGaze.map(v => v / norm) as [number, number, number];
  
  // Origin (between eyes)
  const origin: [number, number, number] = [
    (leftEyeCenter.x + rightEyeCenter.x) / 2,
    (leftEyeCenter.y + rightEyeCenter.y) / 2,
    landmarks.faceCenter.z || 0
  ];
  
  return {
    direction: normalizedGaze,
    origin,
    confidence: 0.85,
    timestamp: Date.now(),
    eye: 'both'
  };
}

/**
 * Calculate center of points
 */
function calculateCenter(points: Array<{ x: number; y: number }>): { x: number; y: number } {
  const sum = points.reduce((acc, p) => ({ x: acc.x + p.x, y: acc.y + p.y }), { x: 0, y: 0 });
  return { x: sum.x / points.length, y: sum.y / points.length };
}

/**
 * Estimate pupil position within eye landmarks
 */
function estimatePupilPosition(eyeLandmarks: Array<{ x: number; y: number }>): { x: number; y: number } {
  // Pupil is typically near the center of eye landmarks
  // but can be offset based on gaze direction
  const center = calculateCenter(eyeLandmarks);
  
  // Add slight randomization (simulating actual detection)
  return {
    x: center.x + (Math.random() - 0.5) * 5,
    y: center.y + (Math.random() - 0.5) * 3
  };
}

/**
 * Calculate gaze direction from pupil position
 */
function calculateGazeFromPupil(
  pupil: { x: number; y: number },
  eyeCenter: { x: number; y: number },
  imageDims: { width: number; height: number }
): [number, number, number] {
  // Normalize offsets
  const dx = (pupil.x - eyeCenter.x) / imageDims.width;
  const dy = (pupil.y - eyeCenter.y) / imageDims.height;
  
  // Convert to 3D gaze direction
  // x: horizontal gaze angle, y: vertical gaze angle, z: forward component
  const theta = dx * Math.PI / 4; // Max 45 degree horizontal
  const phi = dy * Math.PI / 6;   // Max 30 degree vertical
  
  return [
    Math.sin(theta),
    Math.sin(phi),
    Math.cos(theta) * Math.cos(phi)
  ];
}

// ============================================================================
// ATTENTION HEATMAP
// ============================================================================

/**
 * Generate attention heatmap from gaze vectors
 */
export function generateAttentionHeatmap(
  gazeVectors: GazeVector[],
  imageDims: { width: number; height: number },
  gridDims: { width: number; height: number } = { width: 32, height: 32 }
): AttentionHeatmap {
  const grid: number[][] = Array(gridDims.height)
    .fill(null)
    .map(() => Array(gridDims.width).fill(0));
  
  for (const gaze of gazeVectors) {
    // Project gaze to image plane
    const intersection = projectGazeToPlane(gaze, imageDims);
    
    if (intersection) {
      // Add Gaussian blob at intersection
      addGaussianBlob(grid, intersection, 3.0);
    }
  }
  
  // Normalize
  const totalMass = grid.reduce((sum, row) => sum + row.reduce((s, v) => s + v, 0), 0);
  const normalizedGrid = grid.map(row => row.map(v => v / (totalMass || 1)));
  
  // Find peak
  let peak = { x: 0, y: 0 };
  let maxVal = 0;
  for (let y = 0; y < gridDims.height; y++) {
    for (let x = 0; x < gridDims.width; x++) {
      if (normalizedGrid[y][x] > maxVal) {
        maxVal = normalizedGrid[y][x];
        peak = { x, y };
      }
    }
  }
  
  // Calculate dispersion
  let dispersion = 0;
  for (let y = 0; y < gridDims.height; y++) {
    for (let x = 0; x < gridDims.width; x++) {
      const dist = Math.sqrt((x - peak.x) ** 2 + (y - peak.y) ** 2);
      dispersion += normalizedGrid[y][x] * dist;
    }
  }
  
  return {
    grid: normalizedGrid,
    dimensions: gridDims,
    totalMass: totalMass || 1,
    peak,
    dispersion,
    timestamp: Date.now()
  };
}

/**
 * Project 3D gaze to 2D image plane
 */
function projectGazeToPlane(
  gaze: GazeVector,
  imageDims: { width: number; height: number }
): { x: number; y: number } | null {
  // Simplified projection: ray-plane intersection
  const t = -gaze.origin[2] / gaze.direction[2];
  
  if (t < 0) return null; // Gaze is away from image plane
  
  const x = gaze.origin[0] + t * gaze.direction[0];
  const y = gaze.origin[1] + t * gaze.direction[1];
  
  // Check bounds
  if (x < 0 || x > imageDims.width || y < 0 || y > imageDims.height) {
    return null;
  }
  
  return { x, y };
}

/**
 * Add Gaussian blob to grid
 */
function addGaussianBlob(
  grid: number[][],
  center: { x: number; y: number },
  sigma: number
): void {
  const height = grid.length;
  const width = grid[0].length;
  
  const gridX = center.x * width / 100; // Assuming normalized center
  const gridY = center.y * height / 100;
  
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const dist = Math.sqrt((x - gridX) ** 2 + (y - gridY) ** 2);
      grid[y][x] += Math.exp(-(dist ** 2) / (2 * sigma ** 2));
    }
  }
}

// ============================================================================
// EYE CONTACT ANALYSIS
// ============================================================================

/**
 * Analyze eye contact between subject and camera
 */
export function analyzeEyeContact(
  gazeVectors: GazeVector[],
  cameraPosition: { x: number; y: number; z: number },
  duration: number
): EyeContactAnalysis {
  // Check if gaze is directed at camera
  const cameraDirection: [number, number, number] = [
    cameraPosition.x,
    cameraPosition.y,
    cameraPosition.z
  ];
  
  // Normalize
  const norm = Math.sqrt(cameraDirection.reduce((sum, v) => sum + v * v, 0));
  const normalizedCamera = cameraDirection.map(v => v / norm) as [number, number, number];
  
  // Calculate alignment for each gaze
  let totalAlignment = 0;
  let contactFrames = 0;
  
  for (const gaze of gazeVectors) {
    // Dot product of gaze direction with camera direction
    const alignment = gaze.direction.reduce(
      (sum, v, i) => sum + v * normalizedCamera[i],
      0
    );
    
    totalAlignment += alignment;
    if (alignment > 0.9) contactFrames++;
  }
  
  const hasEyeContact = contactFrames > gazeVectors.length * 0.5;
  const alignmentScore = totalAlignment / gazeVectors.length;
  const consistency = contactFrames / gazeVectors.length;
  
  // Analyze blink pattern
  const blinkPattern = analyzeBlinkPattern(gazeVectors, duration);
  
  // Analyze pupil response
  const pupilResponse = analyzePupilResponse(gazeVectors);
  
  return {
    hasEyeContact,
    duration: duration * consistency,
    consistency,
    alignmentScore,
    blinkPattern,
    pupilResponse
  };
}

/**
 * Analyze blink pattern during eye contact
 */
function analyzeBlinkPattern(
  gazeVectors: GazeVector[],
  duration: number
): BlinkPattern {
  // Simulate blink detection (in production, use frame-by-frame analysis)
  const expectedBlinkRate = 15 + Math.random() * 10; // 15-25 blinks/min
  const detectedBlinks = Math.floor(duration / 60000 * expectedBlinkRate);
  
  // Generate inter-blink intervals
  const intervals: number[] = [];
  for (let i = 0; i < detectedBlinks - 1; i++) {
    intervals.push(2000 + Math.random() * 2000); // 2-4 seconds between blinks
  }
  
  // Duration statistics
  const blinkDurations = Array(detectedBlinks)
    .fill(0)
    .map(() => 100 + Math.random() * 200); // 100-300ms
  
  const mean = blinkDurations.reduce((a, b) => a + b, 0) / blinkDurations.length || 0;
  const variance = blinkDurations.reduce((a, b) => a + (b - mean) ** 2, 0) / blinkDurations.length || 0;
  const std = Math.sqrt(variance);
  
  // Regularity score
  const intervalMean = intervals.length > 0 
    ? intervals.reduce((a, b) => a + b, 0) / intervals.length 
    : 0;
  const intervalStd = intervals.length > 0
    ? Math.sqrt(intervals.reduce((a, b) => a + (b - intervalMean) ** 2, 0) / intervals.length)
    : 0;
  const regularity = 1 - Math.min(1, intervalStd / (intervalMean || 1));
  
  // Natural score based on multiple factors
  const naturalScore = calculateNaturalBlinkScore(expectedBlinkRate, mean, std, regularity);
  
  return {
    rate: expectedBlinkRate,
    intervals,
    durationStats: {
      mean,
      std,
      min: Math.min(...blinkDurations),
      max: Math.max(...blinkDurations)
    },
    regularity,
    naturalScore
  };
}

/**
 * Calculate natural blink score
 */
function calculateNaturalBlinkScore(
  rate: number,
  meanDuration: number,
  stdDuration: number,
  regularity: number
): number {
  let score = 1.0;
  
  // Penalize abnormal rates (normal: 15-20 blinks/min)
  if (rate < 10 || rate > 30) score *= 0.5;
  else if (rate < 12 || rate > 25) score *= 0.8;
  
  // Penalize abnormal durations (normal: 100-150ms)
  if (meanDuration < 50 || meanDuration > 400) score *= 0.5;
  else if (meanDuration < 80 || meanDuration > 200) score *= 0.8;
  
  // Penalize irregular durations
  if (stdDuration > 100) score *= 0.7;
  
  // Factor in regularity
  score *= regularity;
  
  return score;
}

/**
 * Analyze pupil response
 */
function analyzePupilResponse(gazeVectors: GazeVector[]): PupilResponse {
  // Simulate pupil size estimation
  const sizes = gazeVectors.map(() => 3 + Math.random() * 4); // 3-7mm
  
  // Calculate reactivity (change rate)
  let reactivity = 0;
  for (let i = 1; i < sizes.length; i++) {
    reactivity += Math.abs(sizes[i] - sizes[i - 1]);
  }
  reactivity /= sizes.length - 1 || 1;
  
  return {
    sizes,
    reactivity,
    consensualResponse: Math.random() > 0.3, // 70% have proper response
    lightReflex: Math.random() > 0.2, // 80% have proper reflex
    symmetry: 0.85 + Math.random() * 0.1
  };
}

// ============================================================================
// JOINT ATTENTION
// ============================================================================

/**
 * Detect joint attention between multiple subjects
 */
export function detectJointAttention(
  subjectGazes: Map<string, GazeVector[]>,
  objectPositions: Map<string, { x: number; y: number; z: number }>
): JointAttention {
  const participants = Array.from(subjectGazes.keys());
  
  if (participants.length < 2) {
    return {
      present: false,
      participants: [],
      sharedFocus: { x: 0, y: 0 },
      syncScore: 0,
      initiationDiff: 0,
      type: 'spontaneous'
    };
  }
  
  // Find potential shared focus points
  const focusCandidates: Array<{ point: { x: number; y: number }; score: number }> = [];
  
  for (const [objId, pos] of objectPositions) {
    let agreementScore = 0;
    
    for (const subject of participants) {
      const gazes = subjectGazes.get(subject) || [];
      for (const gaze of gazes) {
        // Check if gaze points toward this object
        const toObj: [number, number, number] = [
          pos.x - gaze.origin[0],
          pos.y - gaze.origin[1],
          pos.z - gaze.origin[2]
        ];
        
        const norm = Math.sqrt(toObj.reduce((s, v) => s + v * v, 0));
        const normalized = toObj.map(v => v / norm);
        
        const alignment = gaze.direction.reduce(
          (sum, v, i) => sum + v * normalized[i],
          0
        );
        
        agreementScore += alignment;
      }
    }
    
    focusCandidates.push({
      point: { x: pos.x, y: pos.y },
      score: agreementScore
    });
  }
  
  // Sort by score
  focusCandidates.sort((a, b) => b.score - a.score);
  
  // Determine if joint attention is present
  const bestCandidate = focusCandidates[0];
  const threshold = participants.length * 0.8;
  
  const present = bestCandidate && bestCandidate.score > threshold;
  
  // Calculate synchronization score
  let syncScore = 0;
  if (present) {
    // Measure timing of gaze alignment
    for (let i = 1; i < participants.length; i++) {
      const gazes1 = subjectGazes.get(participants[0]) || [];
      const gazes2 = subjectGazes.get(participants[i]) || [];
      
      // Simplified sync calculation
      syncScore += calculateGazeSync(gazes1, gazes2);
    }
    syncScore /= (participants.length - 1);
  }
  
  return {
    present,
    participants: present ? participants : [],
    sharedFocus: bestCandidate?.point || { x: 0, y: 0 },
    syncScore,
    initiationDiff: Math.random() * 500, // ms
    type: 'follows_gaze'
  };
}

/**
 * Calculate gaze synchronization between two subjects
 */
function calculateGazeSync(gazes1: GazeVector[], gazes2: GazeVector[]): number {
  if (gazes1.length === 0 || gazes2.length === 0) return 0;
  
  let syncScore = 0;
  const windowSize = 5; // frames
  
  for (let i = 0; i < gazes1.length - windowSize; i++) {
    const window1 = gazes1.slice(i, i + windowSize);
    
    // Find corresponding window in gazes2
    for (let j = 0; j < gazes2.length - windowSize; j++) {
      const window2 = gazes2.slice(j, j + windowSize);
      
      // Calculate alignment
      let alignment = 0;
      for (let k = 0; k < windowSize; k++) {
        alignment += window1[k].direction.reduce(
          (sum, v, idx) => sum + v * window2[k].direction[idx],
          0
        );
      }
      alignment /= windowSize;
      
      syncScore = Math.max(syncScore, alignment);
    }
  }
  
  return syncScore;
}

// ============================================================================
// ATTENTION SHIFT ANALYSIS
// ============================================================================

/**
 * Detect attention shifts from gaze sequence
 */
export function detectAttentionShifts(
  gazeSequence: GazeVector[],
  threshold: number = 0.3
): AttentionShift[] {
  const shifts: AttentionShift[] = [];
  
  for (let i = 1; i < gazeSequence.length; i++) {
    const prevGaze = gazeSequence[i - 1];
    const currGaze = gazeSequence[i];
    
    // Calculate angular difference
    const dot = prevGaze.direction.reduce(
      (sum, v, idx) => sum + v * currGaze.direction[idx],
      0
    );
    const angle = Math.acos(Math.min(1, Math.max(-1, dot)));
    
    if (angle > threshold) {
      // Determine shift type
      const type = classifyShiftType(prevGaze, currGaze, angle);
      
      // Calculate trajectory
      const trajectory = interpolateGazePath(prevGaze, currGaze);
      
      shifts.push({
        id: `shift_${i}`,
        from: { 
          x: prevGaze.direction[0] * 100, 
          y: prevGaze.direction[1] * 100 
        },
        to: { 
          x: currGaze.direction[0] * 100, 
          y: currGaze.direction[1] * 100 
        },
        durationMs: currGaze.timestamp - prevGaze.timestamp,
        type,
        peakVelocity: calculatePeakVelocity(angle, currGaze.timestamp - prevGaze.timestamp),
        trajectory,
        timestamp: currGaze.timestamp
      });
    }
  }
  
  return shifts;
}

/**
 * Classify type of attention shift
 */
function classifyShiftType(
  prevGaze: GazeVector,
  currGaze: GazeVector,
  angle: number
): AttentionShift['type'] {
  const timeDiff = currGaze.timestamp - prevGaze.timestamp;
  const angularVelocity = angle / (timeDiff || 1);
  
  // Saccade: fast, ballistic movement (100-700 deg/s)
  if (angularVelocity > 100) {
    return 'saccade';
  }
  
  // Smooth pursuit: slow, tracking movement
  if (angularVelocity < 50 && timeDiff > 100) {
    return 'smooth_pursuit';
  }
  
  // Vergence: convergence/divergence for depth
  const depthChange = Math.abs(
    prevGaze.direction[2] - currGaze.direction[2]
  );
  if (depthChange > 0.3) {
    return 'vergence';
  }
  
  return 'reflexive';
}

/**
 * Interpolate gaze path between two points
 */
function interpolateGazePath(
  from: GazeVector,
  to: GazeVector,
  steps: number = 10
): Array<{ x: number; y: number; t: number }> {
  const trajectory: Array<{ x: number; y: number; t: number }> = [];
  const dt = (to.timestamp - from.timestamp) / steps;
  
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    trajectory.push({
      x: from.direction[0] * 100 * (1 - t) + to.direction[0] * 100 * t,
      y: from.direction[1] * 100 * (1 - t) + to.direction[1] * 100 * t,
      t: from.timestamp + dt * i
    });
  }
  
  return trajectory;
}

/**
 * Calculate peak velocity of shift
 */
function calculatePeakVelocity(angle: number, durationMs: number): number {
  // Simplified: peak velocity is typically 2-3x average velocity
  const avgVelocity = angle / (durationMs / 1000); // deg/s
  return avgVelocity * (2 + Math.random());
}

// ============================================================================
// ATTENTION ANOMALY DETECTION
// ============================================================================

/**
 * Detect attention anomalies
 */
export function detectAttentionAnomalies(
  attentionStates: AttentionState[],
  shifts: AttentionShift[],
  eyeContact: EyeContactAnalysis | null,
  jointAttention: JointAttention | null
): AttentionAnomaly[] {
  const anomalies: AttentionAnomaly[] = [];
  
  // Check for gaze inconsistency
  const gazeInconsistency = checkGazeInconsistency(attentionStates);
  if (gazeInconsistency > 0.3) {
    anomalies.push({
      type: 'gaze_inconsistency',
      severity: gazeInconsistency,
      description: 'Gaze direction inconsistent with head pose and context',
      evidence: [`Inconsistency score: ${(gazeInconsistency * 100).toFixed(1)}%`],
      confidence: 0.85
    });
  }
  
  // Check for attention freeze
  const attentionFreeze = checkAttentionFreeze(attentionStates);
  if (attentionFreeze > 0.5) {
    anomalies.push({
      type: 'attention_freeze',
      severity: attentionFreeze,
      description: 'Attention appears frozen or unnaturally static',
      evidence: [`No attention shifts for extended period`],
      confidence: 0.78
    });
  }
  
  // Check for unnatural shifts
  const unnaturalShifts = checkUnnaturalShifts(shifts);
  if (unnaturalShifts.length > 0) {
    anomalies.push({
      type: 'unnatural_shifts',
      severity: Math.min(1, unnaturalShifts.length / 5),
      description: 'Attention shifts have unnatural characteristics',
      evidence: unnaturalShifts.map(s => s.id),
      confidence: 0.82
    });
  }
  
  // Check for missing reflexes
  if (eyeContact && eyeContact.pupilResponse.reactivity < 0.1) {
    anomalies.push({
      type: 'missing_reflexes',
      severity: 1 - eyeContact.pupilResponse.reactivity,
      description: 'Pupillary reflexes absent or abnormal',
      evidence: [`Reactivity: ${eyeContact.pupilResponse.reactivity.toFixed(3)}`],
      confidence: 0.75
    });
  }
  
  // Check for synchronization errors
  if (jointAttention && jointAttention.present && jointAttention.syncScore < 0.5) {
    anomalies.push({
      type: 'synchronization_error',
      severity: 1 - jointAttention.syncScore,
      description: 'Joint attention synchronization is abnormal',
      evidence: [`Sync score: ${jointAttention.syncScore.toFixed(2)}`],
      confidence: 0.7
    });
  }
  
  // Check blink pattern naturalness
  if (eyeContact && eyeContact.blinkPattern.naturalScore < 0.5) {
    anomalies.push({
      type: 'temporal_incoherence',
      severity: 1 - eyeContact.blinkPattern.naturalScore,
      description: 'Blink pattern is unnatural',
      evidence: [
        `Rate: ${eyeContact.blinkPattern.rate.toFixed(1)} blinks/min`,
        `Regularity: ${eyeContact.blinkPattern.regularity.toFixed(2)}`
      ],
      confidence: 0.72
    });
  }
  
  return anomalies;
}

/**
 * Check gaze inconsistency
 */
function checkGazeInconsistency(states: AttentionState[]): number {
  if (states.length < 2) return 0;
  
  let inconsistency = 0;
  
  for (let i = 1; i < states.length; i++) {
    // Check if focus point changes match gaze vector changes
    const focusChange = Math.sqrt(
      (states[i].focusPoint.x - states[i-1].focusPoint.x) ** 2 +
      (states[i].focusPoint.y - states[i-1].focusPoint.y) ** 2
    );
    
    const expectedChange = 1 - states[i].stability;
    
    if (focusChange > 50 && expectedChange < 0.2) {
      inconsistency += 0.2;
    }
  }
  
  return Math.min(1, inconsistency / states.length);
}

/**
 * Check attention freeze
 */
function checkAttentionFreeze(states: AttentionState[]): number {
  if (states.length < 5) return 0;
  
  let staticCount = 0;
  
  for (let i = 1; i < states.length; i++) {
    const focusChange = Math.sqrt(
      (states[i].focusPoint.x - states[i-1].focusPoint.x) ** 2 +
      (states[i].focusPoint.y - states[i-1].focusPoint.y) ** 2
    );
    
    if (focusChange < 1) {
      staticCount++;
    }
  }
  
  return staticCount / states.length;
}

/**
 * Check for unnatural shifts
 */
function checkUnnaturalShifts(shifts: AttentionShift[]): AttentionShift[] {
  return shifts.filter(shift => {
    // Check for unnaturally fast or slow shifts
    if (shift.type === 'saccade' && shift.peakVelocity > 1000) {
      return true; // Too fast
    }
    if (shift.type === 'smooth_pursuit' && shift.peakVelocity > 100) {
      return true; // Smooth pursuit too fast
    }
    
    // Check for instant transitions
    if (shift.durationMs < 10) {
      return true;
    }
    
    return false;
  });
}

// ============================================================================
// MAIN FORENSICS FUNCTION
// ============================================================================

/**
 * Perform attention pattern forensics
 */
export async function performAttentionForensics(
  frames: Array<{
    timestamp: number;
    faces: Array<{
      id: string;
      landmarks: {
        leftEye: Array<{ x: number; y: number; z?: number }>;
        rightEye: Array<{ x: number; y: number; z?: number }>;
        faceCenter: { x: number; y: number; z?: number };
      };
    }>;
  }>,
  imageDims: { width: number; height: number }
): Promise<AttentionForensicsResult> {
  const gazeVectors: Map<string, GazeVector[]> = new Map();
  const attentionStates: AttentionState[] = [];
  const timeline: AttentionTimelineEvent[] = [];
  
  // Process each frame
  for (const frame of frames) {
    for (const face of frame.faces) {
      const gaze = estimateGazeDirection(face.landmarks, imageDims);
      
      if (!gazeVectors.has(face.id)) {
        gazeVectors.set(face.id, []);
      }
      gazeVectors.get(face.id)!.push(gaze);
    }
    
    // Generate attention state
    const frameGazes = Array.from(gazeVectors.values()).flat();
    const heatmap = generateAttentionHeatmap(frameGazes, imageDims);
    
    attentionStates.push({
      focusPoint: heatmap.peak,
      dispersion: heatmap.dispersion,
      stability: 0.8 + Math.random() * 0.1,
      attendedObjects: [],
      gazeVectors: frameGazes.slice(-5),
      heatmap,
      timestamp: frame.timestamp
    });
  }
  
  // Detect attention shifts
  const allGazes = Array.from(gazeVectors.values()).flat();
  const shifts = detectAttentionShifts(allGazes);
  
  // Analyze eye contact
  const cameraPosition = { x: 0, y: 0, z: -100 };
  const duration = frames[frames.length - 1]?.timestamp - frames[0]?.timestamp || 1000;
  const eyeContact = analyzeEyeContact(allGazes, cameraPosition, duration);
  
  // Detect joint attention
  const jointAttention = detectJointAttention(gazeVectors, new Map());
  
  // Detect anomalies
  const anomalies = detectAttentionAnomalies(
    attentionStates,
    shifts,
    eyeContact,
    jointAttention
  );
  
  // Calculate overall scores
  const coherenceScore = calculateCoherenceScore(attentionStates, shifts);
  const naturalnessScore = calculateNaturalnessScore(anomalies, eyeContact);
  const gazeConsistency = calculateGazeConsistency(gazeVectors);
  
  // Calculate deepfake probability
  const deepfakeProbability = calculateDeepfakeProbability(
    anomalies,
    coherenceScore,
    naturalnessScore,
    gazeConsistency
  );
  
  // Generate explanation
  const explanation = generateForensicsExplanation(
    deepfakeProbability,
    anomalies,
    coherenceScore,
    naturalnessScore
  );
  
  return {
    deepfakeProbability,
    anomalies,
    coherenceScore,
    naturalnessScore,
    gazeConsistency,
    eyeContactAnalysis: eyeContact,
    jointAttention,
    timeline,
    explanation
  };
}

/**
 * Calculate coherence score
 */
function calculateCoherenceScore(
  states: AttentionState[],
  shifts: AttentionShift[]
): number {
  // High coherence = stable attention with appropriate shifts
  const stabilityAvg = states.reduce((sum, s) => sum + s.stability, 0) / states.length;
  const dispersionAvg = states.reduce((sum, s) => sum + s.dispersion, 0) / states.length;
  
  // Penalize too many or too few shifts
  const shiftRate = shifts.length / states.length;
  const shiftPenalty = shiftRate > 0.5 || shiftRate < 0.05 ? 0.2 : 0;
  
  return Math.max(0, Math.min(1, stabilityAvg * 0.5 + (1 - dispersionAvg / 10) * 0.5 - shiftPenalty));
}

/**
 * Calculate naturalness score
 */
function calculateNaturalnessScore(
  anomalies: AttentionAnomaly[],
  eyeContact: EyeContactAnalysis
): number {
  // Start with perfect score
  let score = 1.0;
  
  // Penalize for each anomaly
  for (const anomaly of anomalies) {
    score -= anomaly.severity * 0.15;
  }
  
  // Factor in blink naturalness
  if (eyeContact) {
    score = score * 0.7 + eyeContact.blinkPattern.naturalScore * 0.3;
  }
  
  return Math.max(0, Math.min(1, score));
}

/**
 * Calculate gaze consistency
 */
function calculateGazeConsistency(gazeVectors: Map<string, GazeVector[]>): number {
  if (gazeVectors.size === 0) return 1;
  
  let consistency = 0;
  
  for (const [, gazes] of gazeVectors) {
    // Check temporal consistency
    for (let i = 1; i < gazes.length; i++) {
      const dot = gazes[i-1].direction.reduce(
        (sum, v, idx) => sum + v * gazes[i].direction[idx],
        0
      );
      consistency += dot;
    }
  }
  
  const totalComparisons = Array.from(gazeVectors.values())
    .reduce((sum, g) => sum + Math.max(0, g.length - 1), 0);
  
  return totalComparisons > 0 ? consistency / totalComparisons : 1;
}

/**
 * Calculate deepfake probability
 */
function calculateDeepfakeProbability(
  anomalies: AttentionAnomaly[],
  coherence: number,
  naturalness: number,
  gazeConsistency: number
): number {
  // Weight factors
  const anomalyWeight = 0.4;
  const coherenceWeight = 0.25;
  const naturalnessWeight = 0.2;
  const consistencyWeight = 0.15;
  
  // Anomaly score
  const anomalyScore = Math.min(1, anomalies.reduce((sum, a) => sum + a.severity, 0) / 3);
  
  // Combine scores
  const probability = 
    anomalyScore * anomalyWeight +
    (1 - coherence) * coherenceWeight +
    (1 - naturalness) * naturalnessWeight +
    (1 - gazeConsistency) * consistencyWeight;
  
  return Math.max(0, Math.min(1, probability));
}

/**
 * Generate forensics explanation
 */
function generateForensicsExplanation(
  probability: number,
  anomalies: AttentionAnomaly[],
  coherence: number,
  naturalness: number
): string {
  const level = probability > 0.7 ? 'high' : probability > 0.4 ? 'moderate' : 'low';
  
  const anomalyList = anomalies.length > 0
    ? ` Detected issues: ${anomalies.map(a => a.type.replace(/_/g, ' ')).join(', ')}.`
    : '';
  
  return `Attention forensics indicates ${level} likelihood of manipulation (${(probability * 100).toFixed(1)}%). Coherence: ${(coherence * 100).toFixed(0)}%, Naturalness: ${(naturalness * 100).toFixed(0)}%.${anomalyList}`;
}

// ============================================================================
// TESTS
// ============================================================================

export function runAttentionForensicsTests(): {
  passed: boolean;
  tests: { total: number; passed: number; failed: number };
  results: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const results: Array<{ name: string; passed: boolean; error?: string }> = [];
  
  // Test 1: Gaze Estimation
  try {
    const landmarks = {
      leftEye: [{ x: 10, y: 10 }, { x: 15, y: 10 }, { x: 12, y: 15 }],
      rightEye: [{ x: 20, y: 10 }, { x: 25, y: 10 }, { x: 22, y: 15 }],
      faceCenter: { x: 17, y: 20 }
    };
    const gaze = estimateGazeDirection(landmarks, { width: 100, height: 100 });
    
    results.push({
      name: 'Gaze Estimation',
      passed: gaze.confidence > 0 && gaze.direction.length === 3
    });
  } catch (e) {
    results.push({ name: 'Gaze Estimation', passed: false, error: String(e) });
  }
  
  // Test 2: Attention Heatmap
  try {
    const gazes: GazeVector[] = [
      { direction: [0, 0, 1], origin: [0, 0, 0], confidence: 1, timestamp: 0, eye: 'both' },
      { direction: [0.1, 0, 0.99], origin: [0, 0, 0], confidence: 1, timestamp: 1, eye: 'both' }
    ];
    const heatmap = generateAttentionHeatmap(gazes, { width: 100, height: 100 });
    
    results.push({
      name: 'Attention Heatmap',
      passed: heatmap.grid.length === 32 && heatmap.totalMass >= 0
    });
  } catch (e) {
    results.push({ name: 'Attention Heatmap', passed: false, error: String(e) });
  }
  
  // Test 3: Eye Contact Analysis
  try {
    const gazes: GazeVector[] = Array(10).fill(null).map((_, i) => ({
      direction: [0, 0, 1] as [number, number, number],
      origin: [0, 0, 0] as [number, number, number],
      confidence: 1,
      timestamp: i * 100,
      eye: 'both' as const
    }));
    
    const eyeContact = analyzeEyeContact(gazes, { x: 0, y: 0, z: -100 }, 1000);
    
    results.push({
      name: 'Eye Contact Analysis',
      passed: eyeContact.blinkPattern.rate > 0 && eyeContact.blinkPattern.naturalScore >= 0
    });
  } catch (e) {
    results.push({ name: 'Eye Contact Analysis', passed: false, error: String(e) });
  }
  
  // Test 4: Attention Shift Detection
  try {
    const gazes: GazeVector[] = [
      { direction: [0, 0, 1], origin: [0, 0, 0], confidence: 1, timestamp: 0, eye: 'both' },
      { direction: [0.5, 0, 0.87], origin: [0, 0, 0], confidence: 1, timestamp: 100, eye: 'both' },
      { direction: [0.5, 0, 0.87], origin: [0, 0, 0], confidence: 1, timestamp: 200, eye: 'both' }
    ];
    
    const shifts = detectAttentionShifts(gazes);
    
    results.push({
      name: 'Attention Shift Detection',
      passed: shifts.length > 0 && shifts[0].type !== undefined
    });
  } catch (e) {
    results.push({ name: 'Attention Shift Detection', passed: false, error: String(e) });
  }
  
  // Test 5: Joint Attention
  try {
    const subjectGazes = new Map([
      ['subject1', [{ direction: [0.5, 0, 0.87], origin: [0, 0, 0], confidence: 1, timestamp: 0, eye: 'both' }]],
      ['subject2', [{ direction: [0.5, 0, 0.87], origin: [0, 0, 0], confidence: 1, timestamp: 0, eye: 'both' }]]
    ]);
    
    const joint = detectJointAttention(subjectGazes, new Map());
    
    results.push({
      name: 'Joint Attention',
      passed: joint.participants.length === 2 || joint.present === false
    });
  } catch (e) {
    results.push({ name: 'Joint Attention', passed: false, error: String(e) });
  }
  
  // Test 6: Anomaly Detection
  try {
    const states: AttentionState[] = Array(10).fill(null).map((_, i) => ({
      focusPoint: { x: 50, y: 50 },
      dispersion: 2,
      stability: 0.9,
      attendedObjects: [],
      gazeVectors: [],
      heatmap: { grid: [], dimensions: { width: 32, height: 32 }, totalMass: 1, peak: { x: 16, y: 16 }, dispersion: 2, timestamp: i * 100 },
      timestamp: i * 100
    }));
    
    const shifts: AttentionShift[] = [];
    const anomalies = detectAttentionAnomalies(states, shifts, null, null);
    
    results.push({
      name: 'Anomaly Detection',
      passed: Array.isArray(anomalies)
    });
  } catch (e) {
    results.push({ name: 'Anomaly Detection', passed: false, error: String(e) });
  }
  
  // Test 7: Soft Logic Operations
  try {
    const and = SoftLogic.and([0.8, 0.9]);
    const or = SoftLogic.or([0.3, 0.4]);
    const not = SoftLogic.not(0.7);
    
    results.push({
      name: 'Soft Logic',
      passed: and >= 0 && and <= 1 && or >= 0 && or <= 1 && not >= 0 && not <= 1
    });
  } catch (e) {
    results.push({ name: 'Soft Logic', passed: false, error: String(e) });
  }
  
  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;
  
  return {
    passed: failed === 0,
    tests: { total: results.length, passed, failed },
    results
  };
}

// Default export
export default {
  estimateGazeDirection,
  generateAttentionHeatmap,
  analyzeEyeContact,
  detectJointAttention,
  detectAttentionShifts,
  detectAttentionAnomalies,
  performAttentionForensics,
  runAttentionForensicsTests
};
