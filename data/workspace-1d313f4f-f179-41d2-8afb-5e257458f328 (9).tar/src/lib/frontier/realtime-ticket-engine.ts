/**
 * Real-Time Ticket Engine Module
 *
 * Sub-100ms cryptographic ticket generation for decision validation.
 * One-time-use tickets with HMAC-SHA256 signatures.
 *
 * @module frontier/realtime-ticket-engine
 * @version 9.0.0
 *
 * Capabilities:
 * - Sub-100ms ticket generation
 * - Cryptographic signing (HMAC-SHA256)
 * - One-time-use enforcement
 * - Replay attack prevention
 * - Multi-context tickets
 * - Batch ticket generation
 * - Ticket verification
 * - Expiration handling
 * - Audit trail
 * - Performance metrics
 */

import { generateUUID, sha256Hash, hmacSign } from '../crypto-utils';

// ============================================================================
// TYPES
// ============================================================================

/**
 * Ticket context
 */
export type TicketContext = 
  | 'transaction' | 'authentication' | 'authorization' | 'gaming' | 'voting' 
  | 'payment' | 'signing' | 'access' | 'verification' | 'audit' | 'custom';

/**
 * Decision ticket
 */
export interface DecisionTicket {
  /** Ticket ID */
  id: string;
  /** Ticket hash */
  ticketHash: string;
  /** Context type */
  context: TicketContext;
  /** Decision data (encrypted) */
  decisionData: Record<string, unknown>;
  /** Signature */
  signature: string;
  /** Timestamp */
  timestamp: number;
  /** Expiration timestamp */
  expiresAt: number;
  /** Time-to-live (milliseconds) */
  ttl: number;
  /** Issuer */
  issuer: {
    id: string;
    type: 'system' | 'user' | 'service' | 'device';
  };
  /** Subject (who/what the ticket is for) */
  subject: {
    id: string;
    type: 'user' | 'device' | 'transaction' | 'session' | 'resource';
  };
  /** Claims */
  claims: TicketClaim[];
  /** Status */
  status: 'pending' | 'valid' | 'used' | 'expired' | 'revoked';
  /** Used timestamp */
  usedAt?: number;
  /** Used by */
  usedBy?: string;
  /** Verification count */
  verificationCount: number;
  /** Generation time (milliseconds) */
  generationTimeMs: number;
  /** Metadata */
  metadata: Record<string, unknown>;
}

/**
 * Ticket claim
 */
export interface TicketClaim {
  /** Claim name */
  name: string;
  /** Claim value */
  value: string | number | boolean | string[];
  /** Claim type */
  type: 'identity' | 'permission' | 'constraint' | 'attribute' | 'proof';
  /** Required */
  required: boolean;
}

/**
 * Ticket verification result
 */
export interface TicketVerificationResult {
  /** Verification ID */
  id: string;
  /** Ticket ID */
  ticketId: string;
  /** Valid */
  valid: boolean;
  /** Verification status */
  status: 'valid' | 'invalid' | 'expired' | 'already_used' | 'signature_invalid' | 'revoked';
  /** Verification time (milliseconds) */
  verificationTimeMs: number;
  /** Verified claims */
  verifiedClaims: TicketClaim[];
  /** Rejection reason */
  rejectionReason?: string;
  /** Timestamp */
  timestamp: number;
}

/**
 * Ticket batch
 */
export interface TicketBatch {
  /** Batch ID */
  id: string;
  /** Tickets in batch */
  tickets: DecisionTicket[];
  /** Batch hash */
  batchHash: string;
  /** Context */
  context: TicketContext;
  /** Created timestamp */
  createdAt: number;
  /** Total generation time */
  totalGenerationTimeMs: number;
  /** Average generation time */
  avgGenerationTimeMs: number;
  /** All within SLA (< 100ms) */
  withinSla: boolean;
}

/**
 * Ticket configuration
 */
export interface TicketConfig {
  /** Default TTL (milliseconds) */
  defaultTtl: number;
  /** Maximum TTL */
  maxTtl: number;
  /** Minimum TTL */
  minTtl: number;
  /** Enable one-time-use enforcement */
  enforceOneTimeUse: boolean;
  /** Allowed contexts */
  allowedContexts: TicketContext[];
  /** Performance SLA (milliseconds) */
  performanceSla: number;
  /** Signature algorithm */
  signatureAlgorithm: 'HMAC-SHA256' | 'HMAC-SHA512';
  /** Ticket ID format */
  idFormat: 'uuid' | 'base64' | 'hex' | 'custom';
}

/**
 * Ticket audit entry
 */
export interface TicketAuditEntry {
  /** Entry ID */
  id: string;
  /** Ticket ID */
  ticketId: string;
  /** Action */
  action: 'generated' | 'verified' | 'used' | 'expired' | 'revoked';
  /** Actor */
  actor: string;
  /** Timestamp */
  timestamp: number;
  /** Context */
  context: TicketContext;
  /** Generation time (if generated) */
  generationTimeMs?: number;
  /** Verification time (if verified) */
  verificationTimeMs?: number;
  /** Status */
  status: string;
  /** Additional details */
  details: Record<string, unknown>;
}

/**
 * Performance metrics
 */
export interface TicketPerformanceMetrics {
  /** Total tickets generated */
  totalGenerated: number;
  /** Total tickets verified */
  totalVerified: number;
  /** Total tickets used */
  totalUsed: number;
  /** Total tickets expired */
  totalExpired: number;
  /** Total tickets revoked */
  totalRevoked: number;
  /** Average generation time (milliseconds) */
  avgGenerationTimeMs: number;
  /** Average verification time (milliseconds) */
  avgVerificationTimeMs: number;
  /** P50 generation time */
  p50GenerationTimeMs: number;
  /** P95 generation time */
  p95GenerationTimeMs: number;
  /** P99 generation time */
  p99GenerationTimeMs: number;
  /** Percentage within SLA */
  percentWithinSla: number;
  /** Tickets by context */
  ticketsByContext: Record<TicketContext, number>;
  /** Last updated */
  updatedAt: number;
}

/**
 * Ticket policy
 */
export interface TicketPolicy {
  /** Policy ID */
  id: string;
  /** Policy name */
  name: string;
  /** Applicable contexts */
  contexts: TicketContext[];
  /** Default TTL override */
  ttlOverride?: number;
  /** Required claims */
  requiredClaims: string[];
  /** Max verifications per ticket */
  maxVerifications: number;
  /** Enable batch generation */
  enableBatchGeneration: boolean;
  /** Max batch size */
  maxBatchSize: number;
  /** Custom validation rules */
  customRules: TicketValidationRule[];
  /** Enabled */
  enabled: boolean;
}

/**
 * Ticket validation rule
 */
export interface TicketValidationRule {
  /** Rule ID */
  id: string;
  /** Rule name */
  name: string;
  /** Rule type */
  type: 'claim_required' | 'claim_value' | 'time_constraint' | 'issuer_constraint' | 'subject_constraint';
  /** Condition */
  condition: {
    field: string;
    operator: 'eq' | 'neq' | 'gt' | 'lt' | 'in' | 'not_in' | 'exists';
    value: unknown;
  };
  /** Error message */
  errorMessage: string;
}

// ============================================================================
// STORAGE
// ============================================================================

const tickets = new Map<string, DecisionTicket>();
const batches = new Map<string, TicketBatch>();
const auditLog = new Map<string, TicketAuditEntry>();
const policies = new Map<string, TicketPolicy>();

// Configuration
let config: TicketConfig = {
  defaultTtl: 300000, // 5 minutes
  maxTtl: 3600000, // 1 hour
  minTtl: 1000, // 1 second
  enforceOneTimeUse: true,
  allowedContexts: ['transaction', 'authentication', 'authorization', 'gaming', 'voting', 'payment', 'signing', 'access', 'verification', 'audit', 'custom'],
  performanceSla: 100, // 100ms
  signatureAlgorithm: 'HMAC-SHA256',
  idFormat: 'uuid'
};

// Performance tracking
const performanceData: {
  generationTimes: number[];
  verificationTimes: number[];
  totalGenerated: number;
  totalVerified: number;
  totalUsed: number;
  totalExpired: number;
  totalRevoked: number;
  ticketsByContext: Record<string, number>;
} = {
  generationTimes: [],
  verificationTimes: [],
  totalGenerated: 0,
  totalVerified: 0,
  totalUsed: 0,
  totalExpired: 0,
  totalRevoked: 0,
  ticketsByContext: {}
};

// Platform secret
const PLATFORM_SECRET = 'realtime_ticket_engine_secret_v1';

// ============================================================================
// CONFIGURATION
// ============================================================================

/**
 * Update configuration
 */
export function updateConfig(newConfig: Partial<TicketConfig>): TicketConfig {
  config = { ...config, ...newConfig };
  return config;
}

/**
 * Get configuration
 */
export function getConfig(): TicketConfig {
  return { ...config };
}

// ============================================================================
// TICKET GENERATION
// ============================================================================

/**
 * Generate a single decision ticket
 * 
 * Performance target: < 100ms
 */
export function generateTicket(params: {
  context: TicketContext;
  decisionData: Record<string, unknown>;
  issuer: DecisionTicket['issuer'];
  subject: DecisionTicket['subject'];
  claims?: TicketClaim[];
  ttl?: number;
  metadata?: Record<string, unknown>;
}): DecisionTicket {
  const startTime = performance.now();

  // Validate context
  if (!config.allowedContexts.includes(params.context)) {
    throw new Error(`Context '${params.context}' is not allowed`);
  }

  // Calculate TTL
  const ttl = Math.min(
    config.maxTtl,
    Math.max(config.minTtl, params.ttl || config.defaultTtl)
  );

  // Generate ticket ID
  const id = generateTicketId();

  // Generate ticket hash
  const ticketHash = generateTicketHash(id, params);

  // Generate signature
  const signature = signTicket(id, ticketHash, params.decisionData);

  const now = Date.now();
  const generationTimeMs = performance.now() - startTime;

  const ticket: DecisionTicket = {
    id,
    ticketHash,
    context: params.context,
    decisionData: params.decisionData,
    signature,
    timestamp: now,
    expiresAt: now + ttl,
    ttl,
    issuer: params.issuer,
    subject: params.subject,
    claims: params.claims || [],
    status: 'valid',
    verificationCount: 0,
    generationTimeMs,
    metadata: params.metadata || {}
  };

  // Store ticket
  tickets.set(id, ticket);

  // Track performance
  trackPerformance(generationTimeMs, 'generation', params.context);

  // Create audit entry
  createAuditEntry({
    ticketId: id,
    action: 'generated',
    actor: params.issuer.id,
    context: params.context,
    generationTimeMs,
    status: 'valid',
    details: { issuer: params.issuer, subject: params.subject }
  });

  return ticket;
}

/**
 * Generate batch of tickets
 * 
 * Optimized for batch generation within SLA
 */
export function generateTicketBatch(params: {
  context: TicketContext;
  count: number;
  issuer: DecisionTicket['issuer'];
  baseSubject: DecisionTicket['subject'];
  baseDecisionData: Record<string, unknown>;
  baseClaims?: TicketClaim[];
  ttl?: number;
}): TicketBatch {
  const startTime = performance.now();

  if (params.count > 1000) {
    throw new Error('Maximum batch size is 1000 tickets');
  }

  const ticketsInBatch: DecisionTicket[] = [];
  const generationTimes: number[] = [];

  for (let i = 0; i < params.count; i++) {
    const ticket = generateTicket({
      context: params.context,
      decisionData: { ...params.baseDecisionData, index: i },
      issuer: params.issuer,
      subject: { ...params.baseSubject, id: `${params.baseSubject.id}_${i}` },
      claims: params.baseClaims,
      ttl: params.ttl
    });
    ticketsInBatch.push(ticket);
    generationTimes.push(ticket.generationTimeMs);
  }

  const totalGenerationTimeMs = performance.now() - startTime;
  const avgGenerationTimeMs = generationTimes.reduce((a, b) => a + b, 0) / generationTimes.length;
  const withinSla = generationTimes.every(t => t < config.performanceSla);

  const batch: TicketBatch = {
    id: `batch_${generateUUID()}`,
    tickets: ticketsInBatch,
    batchHash: sha256Hash(ticketsInBatch.map(t => t.ticketHash).join('')),
    context: params.context,
    createdAt: Date.now(),
    totalGenerationTimeMs,
    avgGenerationTimeMs,
    withinSla
  };

  batches.set(batch.id, batch);
  return batch;
}

/**
 * Generate ticket ID
 */
function generateTicketId(): string {
  switch (config.idFormat) {
    case 'base64':
      return Buffer.from(generateUUID()).toString('base64');
    case 'hex':
      return sha256Hash(generateUUID()).slice(0, 32);
    case 'uuid':
    default:
      return `ticket_${generateUUID()}`;
  }
}

/**
 * Generate ticket hash
 */
function generateTicketHash(id: string, params: { context: TicketContext; issuer: DecisionTicket['issuer']; subject: DecisionTicket['subject'] }): string {
  const data = JSON.stringify({
    id,
    context: params.context,
    issuer: params.issuer.id,
    subject: params.subject.id,
    timestamp: Date.now()
  });
  return sha256Hash(data);
}

/**
 * Sign ticket
 */
function signTicket(id: string, ticketHash: string, decisionData: Record<string, unknown>): string {
  const payload = JSON.stringify({ id, ticketHash, decisionData });
  return hmacSign(payload, PLATFORM_SECRET);
}

// ============================================================================
// TICKET VERIFICATION
// ============================================================================

/**
 * Verify a ticket
 * 
 * Performance target: < 50ms
 */
export function verifyTicket(ticketId: string, verifier: string): TicketVerificationResult {
  const startTime = performance.now();

  const ticket = tickets.get(ticketId);

  if (!ticket) {
    return createVerificationResult(ticketId, false, 'invalid', 'Ticket not found', startTime);
  }

  // Check expiration
  if (Date.now() > ticket.expiresAt) {
    ticket.status = 'expired';
    tickets.set(ticketId, ticket);
    trackEvent('expired');
    return createVerificationResult(ticketId, false, 'expired', 'Ticket has expired', startTime);
  }

  // Check if already used (one-time-use enforcement)
  if (config.enforceOneTimeUse && ticket.status === 'used') {
    return createVerificationResult(ticketId, false, 'already_used', 'Ticket has already been used', startTime);
  }

  // Check if revoked
  if (ticket.status === 'revoked') {
    return createVerificationResult(ticketId, false, 'revoked', 'Ticket has been revoked', startTime);
  }

  // Verify signature
  const expectedSignature = signTicket(ticket.id, ticket.ticketHash, ticket.decisionData);
  if (ticket.signature !== expectedSignature) {
    return createVerificationResult(ticketId, false, 'signature_invalid', 'Signature verification failed', startTime);
  }

  // Apply policy validation
  const policyResult = applyPolicyValidation(ticket);
  if (!policyResult.valid) {
    return createVerificationResult(ticketId, false, 'invalid', policyResult.reason || 'Policy validation failed', startTime);
  }

  // Ticket is valid
  ticket.verificationCount++;
  tickets.set(ticketId, ticket);

  const verificationTimeMs = performance.now() - startTime;
  trackPerformance(verificationTimeMs, 'verification', ticket.context);
  trackEvent('verified');

  // Create audit entry
  createAuditEntry({
    ticketId,
    action: 'verified',
    actor: verifier,
    context: ticket.context,
    verificationTimeMs,
    status: 'valid',
    details: { verificationCount: ticket.verificationCount }
  });

  return {
    id: `verify_${generateUUID()}`,
    ticketId,
    valid: true,
    status: 'valid',
    verificationTimeMs,
    verifiedClaims: ticket.claims,
    timestamp: Date.now()
  };
}

/**
 * Create verification result
 */
function createVerificationResult(
  ticketId: string,
  valid: boolean,
  status: TicketVerificationResult['status'],
  rejectionReason: string,
  startTime: number
): TicketVerificationResult {
  const verificationTimeMs = performance.now() - startTime;
  
  trackPerformance(verificationTimeMs, 'verification', 'unknown');

  return {
    id: `verify_${generateUUID()}`,
    ticketId,
    valid,
    status,
    verificationTimeMs,
    verifiedClaims: [],
    rejectionReason,
    timestamp: Date.now()
  };
}

/**
 * Apply policy validation
 */
function applyPolicyValidation(ticket: DecisionTicket): { valid: boolean; reason?: string } {
  // Find applicable policies
  const applicablePolicies = Array.from(policies.values())
    .filter(p => p.enabled && p.contexts.includes(ticket.context));

  for (const policy of applicablePolicies) {
    // Check required claims
    for (const requiredClaim of policy.requiredClaims) {
      const hasClaim = ticket.claims.some(c => c.name === requiredClaim && c.required);
      if (!hasClaim) {
        return { valid: false, reason: `Missing required claim: ${requiredClaim}` };
      }
    }

    // Check max verifications
    if (ticket.verificationCount >= policy.maxVerifications) {
      return { valid: false, reason: `Maximum verifications (${policy.maxVerifications}) exceeded` };
    }

    // Apply custom rules
    for (const rule of policy.customRules) {
      const ruleResult = evaluateValidationRule(rule, ticket);
      if (!ruleResult.valid) {
        return { valid: false, reason: ruleResult.reason || rule.errorMessage };
      }
    }
  }

  return { valid: true };
}

/**
 * Evaluate validation rule
 */
function evaluateValidationRule(rule: TicketValidationRule, ticket: DecisionTicket): { valid: boolean; reason?: string } {
  const fieldValue = getFieldValue(rule.condition.field, ticket);
  const expectedValue = rule.condition.value;

  switch (rule.condition.operator) {
    case 'eq':
      return { valid: fieldValue === expectedValue };
    case 'neq':
      return { valid: fieldValue !== expectedValue };
    case 'gt':
      return { valid: typeof fieldValue === 'number' && fieldValue > (expectedValue as number) };
    case 'lt':
      return { valid: typeof fieldValue === 'number' && fieldValue < (expectedValue as number) };
    case 'in':
      return { valid: Array.isArray(expectedValue) && expectedValue.includes(fieldValue) };
    case 'not_in':
      return { valid: Array.isArray(expectedValue) && !expectedValue.includes(fieldValue) };
    case 'exists':
      return { valid: fieldValue !== undefined && fieldValue !== null };
    default:
      return { valid: true };
  }
}

/**
 * Get field value from ticket
 */
function getFieldValue(field: string, ticket: DecisionTicket): unknown {
  const parts = field.split('.');
  let value: unknown = ticket;

  for (const part of parts) {
    if (value && typeof value === 'object') {
      value = (value as Record<string, unknown>)[part];
    } else {
      return undefined;
    }
  }

  return value;
}

// ============================================================================
// TICKET USAGE
// ============================================================================

/**
 * Use a ticket (mark as consumed)
 */
export function consumeTicket(ticketId: string, usedBy: string): DecisionTicket | null {
  const ticket = tickets.get(ticketId);
  if (!ticket) return null;

  if (ticket.status !== 'valid') {
    return null;
  }

  // Verify ticket first
  const verification = verifyTicket(ticketId, usedBy);
  if (!verification.valid) {
    return null;
  }

  ticket.status = 'used';
  ticket.usedAt = Date.now();
  ticket.usedBy = usedBy;
  tickets.set(ticketId, ticket);

  trackEvent('used');

  // Create audit entry
  createAuditEntry({
    ticketId,
    action: 'used',
    actor: usedBy,
    context: ticket.context,
    status: 'used',
    details: { usedAt: ticket.usedAt }
  });

  return ticket;
}

/**
 * Revoke a ticket
 */
export function revokeTicket(ticketId: string, reason: string, revokedBy: string): DecisionTicket | null {
  const ticket = tickets.get(ticketId);
  if (!ticket) return null;

  ticket.status = 'revoked';
  tickets.set(ticketId, ticket);

  trackEvent('revoked');

  // Create audit entry
  createAuditEntry({
    ticketId,
    action: 'revoked',
    actor: revokedBy,
    context: ticket.context,
    status: 'revoked',
    details: { reason }
  });

  return ticket;
}

// ============================================================================
// TICKET QUERIES
// ============================================================================

/**
 * Get ticket
 */
export function getTicket(ticketId: string): DecisionTicket | undefined {
  return tickets.get(ticketId);
}

/**
 * Get ticket by hash
 */
export function getTicketByHash(ticketHash: string): DecisionTicket | undefined {
  return Array.from(tickets.values()).find(t => t.ticketHash === ticketHash);
}

/**
 * List tickets by context
 */
export function listTicketsByContext(context: TicketContext, limit: number = 100): DecisionTicket[] {
  return Array.from(tickets.values())
    .filter(t => t.context === context)
    .sort((a, b) => b.timestamp - a.timestamp)
    .slice(0, limit);
}

/**
 * List tickets by issuer
 */
export function listTicketsByIssuer(issuerId: string, limit: number = 100): DecisionTicket[] {
  return Array.from(tickets.values())
    .filter(t => t.issuer.id === issuerId)
    .sort((a, b) => b.timestamp - a.timestamp)
    .slice(0, limit);
}

/**
 * List tickets by subject
 */
export function listTicketsBySubject(subjectId: string, limit: number = 100): DecisionTicket[] {
  return Array.from(tickets.values())
    .filter(t => t.subject.id === subjectId)
    .sort((a, b) => b.timestamp - a.timestamp)
    .slice(0, limit);
}

// ============================================================================
// POLICY MANAGEMENT
// ============================================================================

/**
 * Create policy
 */
export function createPolicy(params: Omit<TicketPolicy, 'id'>): TicketPolicy {
  const policy: TicketPolicy = {
    ...params,
    id: `policy_${generateUUID()}`
  };

  policies.set(policy.id, policy);
  return policy;
}

/**
 * Get policy
 */
export function getPolicy(policyId: string): TicketPolicy | undefined {
  return policies.get(policyId);
}

/**
 * Update policy
 */
export function updatePolicy(policyId: string, updates: Partial<TicketPolicy>): TicketPolicy | null {
  const policy = policies.get(policyId);
  if (!policy) return null;

  Object.assign(policy, updates);
  policies.set(policyId, policy);
  return policy;
}

// ============================================================================
// PERFORMANCE TRACKING
// ============================================================================

/**
 * Track performance
 */
function trackPerformance(timeMs: number, type: 'generation' | 'verification', context: string): void {
  if (type === 'generation') {
    performanceData.generationTimes.push(timeMs);
    performanceData.totalGenerated++;
  } else {
    performanceData.verificationTimes.push(timeMs);
    performanceData.totalVerified++;
  }

  performanceData.ticketsByContext[context] = (performanceData.ticketsByContext[context] || 0) + 1;

  // Keep only last 10000 entries
  if (performanceData.generationTimes.length > 10000) {
    performanceData.generationTimes = performanceData.generationTimes.slice(-10000);
  }
  if (performanceData.verificationTimes.length > 10000) {
    performanceData.verificationTimes = performanceData.verificationTimes.slice(-10000);
  }
}

/**
 * Track event
 */
function trackEvent(event: 'used' | 'expired' | 'revoked' | 'verified'): void {
  switch (event) {
    case 'used':
      performanceData.totalUsed++;
      break;
    case 'expired':
      performanceData.totalExpired++;
      break;
    case 'revoked':
      performanceData.totalRevoked++;
      break;
  }
}

/**
 * Get performance metrics
 */
export function getPerformanceMetrics(): TicketPerformanceMetrics {
  const genTimes = performanceData.generationTimes;
  const verTimes = performanceData.verificationTimes;

  const avgGen = genTimes.length > 0 ? genTimes.reduce((a, b) => a + b, 0) / genTimes.length : 0;
  const avgVer = verTimes.length > 0 ? verTimes.reduce((a, b) => a + b, 0) / verTimes.length : 0;

  const sortedGenTimes = [...genTimes].sort((a, b) => a - b);
  const p50 = sortedGenTimes[Math.floor(sortedGenTimes.length * 0.5)] || 0;
  const p95 = sortedGenTimes[Math.floor(sortedGenTimes.length * 0.95)] || 0;
  const p99 = sortedGenTimes[Math.floor(sortedGenTimes.length * 0.99)] || 0;

  const withinSla = genTimes.filter(t => t < config.performanceSla).length;
  const percentWithinSla = genTimes.length > 0 ? (withinSla / genTimes.length) * 100 : 100;

  return {
    totalGenerated: performanceData.totalGenerated,
    totalVerified: performanceData.totalVerified,
    totalUsed: performanceData.totalUsed,
    totalExpired: performanceData.totalExpired,
    totalRevoked: performanceData.totalRevoked,
    avgGenerationTimeMs: avgGen,
    avgVerificationTimeMs: avgVer,
    p50GenerationTimeMs: p50,
    p95GenerationTimeMs: p95,
    p99GenerationTimeMs: p99,
    percentWithinSla,
    ticketsByContext: { ...performanceData.ticketsByContext } as Record<TicketContext, number>,
    updatedAt: Date.now()
  };
}

// ============================================================================
// AUDIT LOG
// ============================================================================

/**
 * Create audit entry
 */
function createAuditEntry(params: Omit<TicketAuditEntry, 'id' | 'timestamp'>): TicketAuditEntry {
  const entry: TicketAuditEntry = {
    id: `audit_${generateUUID()}`,
    ...params,
    timestamp: Date.now()
  };

  auditLog.set(entry.id, entry);
  return entry;
}

/**
 * Get audit log for ticket
 */
export function getTicketAuditLog(ticketId: string): TicketAuditEntry[] {
  return Array.from(auditLog.values())
    .filter(e => e.ticketId === ticketId)
    .sort((a, b) => a.timestamp - b.timestamp);
}

/**
 * Get audit log by context
 */
export function getAuditLogByContext(context: TicketContext, limit: number = 100): TicketAuditEntry[] {
  return Array.from(auditLog.values())
    .filter(e => e.context === context)
    .sort((a, b) => b.timestamp - a.timestamp)
    .slice(0, limit);
}

// ============================================================================
// BATCH QUERIES
// ============================================================================

/**
 * Get batch
 */
export function getBatch(batchId: string): TicketBatch | undefined {
  return batches.get(batchId);
}

// ============================================================================
// TEST SUITE
// ============================================================================

/**
 * Run ticket engine tests
 */
export function runRealtimeTicketEngineTests(): {
  passed: boolean;
  tests: { total: number; passed: number; failed: number };
  results: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const results: Array<{ name: string; passed: boolean; error?: string }> = [];

  try {
    // Test 1: Generate ticket
    const ticket = generateTicket({
      context: 'transaction',
      decisionData: { amount: 100, currency: 'USD' },
      issuer: { id: 'system_1', type: 'system' },
      subject: { id: 'txn_123', type: 'transaction' },
      claims: [
        { name: 'amount', value: 100, type: 'attribute', required: true }
      ]
    });
    results.push({ name: 'Generate Ticket', passed: !!ticket.id && ticket.status === 'valid' });

    // Test 2: Generation time within SLA
    results.push({ name: 'Generation Time < 100ms', passed: ticket.generationTimeMs < 100 });

    // Test 3: Verify ticket
    const verification = verifyTicket(ticket.id, 'verifier_1');
    results.push({ name: 'Verify Ticket', passed: verification.valid === true });

    // Test 4: Verification time
    results.push({ name: 'Verification Time < 50ms', passed: verification.verificationTimeMs < 50 });

    // Test 5: Use ticket
    const usedTicket = consumeTicket(ticket.id, 'user_1');
    results.push({ name: 'Use Ticket', passed: usedTicket?.status === 'used' });

    // Test 6: Prevent reuse (one-time-use)
    const reuseAttempt = verifyTicket(ticket.id, 'verifier_2');
    results.push({ name: 'Prevent Reuse', passed: reuseAttempt.valid === false && reuseAttempt.status === 'already_used' });

    // Test 7: Generate batch
    const batch = generateTicketBatch({
      context: 'gaming',
      count: 50,
      issuer: { id: 'game_server', type: 'service' },
      baseSubject: { id: 'player', type: 'user' },
      baseDecisionData: { action: 'move' }
    });
    results.push({ name: 'Generate Batch', passed: batch.tickets.length === 50 });

    // Test 8: Batch within SLA
    results.push({ name: 'Batch Within SLA', passed: batch.withinSla });

    // Test 9: Create policy
    const policy = createPolicy({
      name: 'Transaction Policy',
      contexts: ['transaction'],
      requiredClaims: ['amount'],
      maxVerifications: 10,
      enableBatchGeneration: true,
      maxBatchSize: 100,
      customRules: [],
      enabled: true
    });
    results.push({ name: 'Create Policy', passed: !!policy.id });

    // Test 10: Revoke ticket
    const ticket2 = generateTicket({
      context: 'authorization',
      decisionData: { permission: 'read' },
      issuer: { id: 'auth_service', type: 'service' },
      subject: { id: 'user_1', type: 'user' }
    });
    const revoked = revokeTicket(ticket2.id, 'Security concern', 'admin');
    results.push({ name: 'Revoke Ticket', passed: revoked?.status === 'revoked' });

    // Test 11: Performance metrics
    const metrics = getPerformanceMetrics();
    results.push({ name: 'Performance Metrics', passed: metrics.totalGenerated >= 50 });

    // Test 12: Audit log
    const auditLog = getTicketAuditLog(ticket.id);
    results.push({ name: 'Audit Log', passed: auditLog.length >= 2 }); // generated + used

  } catch (error) {
    results.push({ name: 'Test execution', passed: false, error: String(error) });
  }

  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;

  return {
    passed: failed === 0,
    tests: { total: results.length, passed, failed },
    results
  };
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

const realtimeTicketEngine = {
  // Configuration
  updateConfig,
  getConfig,
  // Ticket generation
  generateTicket,
  generateTicketBatch,
  // Ticket verification
  verifyTicket,
  // Ticket usage
  consumeTicket,
  revokeTicket,
  // Ticket queries
  getTicket,
  getTicketByHash,
  listTicketsByContext,
  listTicketsByIssuer,
  listTicketsBySubject,
  // Policy management
  createPolicy,
  getPolicy,
  updatePolicy,
  // Performance
  getPerformanceMetrics,
  // Audit
  getTicketAuditLog,
  getAuditLogByContext,
  // Batch
  getBatch,
  // Tests
  runRealtimeTicketEngineTests
};

export default realtimeTicketEngine;
