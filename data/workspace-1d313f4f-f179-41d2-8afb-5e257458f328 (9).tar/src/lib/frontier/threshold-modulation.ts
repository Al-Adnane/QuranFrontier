/**
 * Threshold Modulation Module
 *
 * Dynamic threshold adjustment based on threat environment.
 * Higher threat = lower tolerance = more blocks.
 * Context-aware threshold management.
 *
 * @module frontier/threshold-modulation
 * @version 9.1.0
 *
 * Capabilities:
 * - Dynamic threshold adjustment
 * - Threat level assessment
 * - Context-aware thresholds
 * - Time-based modulation
 * - Seasonal adaptation
 * - Event-driven adjustments
 * - Threshold history tracking
 * - Predictive threshold setting
 * - Multi-factor threshold calculation
 * - Threshold optimization
 */

import { generateUUID, sha256Hash } from '../crypto-utils';

// ============================================================================
// TYPES
// ============================================================================

/**
 * Threshold type
 */
export type ThresholdType = 
  | 'security' | 'fraud' | 'spam' | 'risk' | 'quality' 
  | 'performance' | 'compliance' | 'access' | 'alert' | 'custom';

/**
 * Threat level
 */
export type ThreatLevel = 'minimal' | 'low' | 'moderate' | 'high' | 'critical' | 'extreme';

/**
 * Threshold configuration
 */
export interface ThresholdConfig {
  /** Config ID */
  id: string;
  /** Threshold name */
  name: string;
  /** Threshold type */
  type: ThresholdType;
  /** Context/domain */
  context: string;
  /** Base threshold value */
  baseThreshold: number;
  /** Minimum threshold */
  minThreshold: number;
  /** Maximum threshold */
  maxThreshold: number;
  /** Current threshold */
  currentThreshold: number;
  /** Threat level */
  threatLevel: ThreatLevel;
  /** Threat score (0-100) */
  threatScore: number;
  /** Adjustment sensitivity */
  sensitivity: number;
  /** Adjustment mode */
  adjustmentMode: 'automatic' | 'manual' | 'hybrid';
  /** Time-based rules */
  timeRules: TimeRule[];
  /** Event triggers */
  eventTriggers: EventTrigger[];
  /** Threat factors */
  threatFactors: ThreatFactor[];
  /** History */
  history: ThresholdHistoryEntry[];
  /** Created timestamp */
  createdAt: number;
  /** Updated timestamp */
  updatedAt: number;
  /** Enabled */
  enabled: boolean;
}

/**
 * Time-based rule
 */
export interface TimeRule {
  /** Rule ID */
  id: string;
  /** Rule name */
  name: string;
  /** Rule type */
  type: 'time_of_day' | 'day_of_week' | 'seasonal' | 'custom';
  /** Condition */
  condition: {
    start?: string; // e.g., "09:00" or "2024-01-01"
    end?: string;
    days?: number[]; // 0-6 for day of week
    months?: number[]; // 0-11 for month
  };
  /** Threshold adjustment */
  adjustment: number; // Multiplier or fixed adjustment
  /** Adjustment type */
  adjustmentType: 'multiplier' | 'additive' | 'fixed';
  /** Priority */
  priority: number;
  /** Enabled */
  enabled: boolean;
}

/**
 * Event trigger
 */
export interface EventTrigger {
  /** Trigger ID */
  id: string;
  /** Trigger name */
  name: string;
  /** Event type */
  eventType: string;
  /** Condition */
  condition: {
    field: string;
    operator: 'eq' | 'gt' | 'lt' | 'gte' | 'lte' | 'contains';
    value: unknown;
  };
  /** Threshold adjustment */
  adjustment: number;
  /** Duration (ms) */
  duration: number;
  /** Cooldown (ms) */
  cooldown: number;
  /** Last triggered */
  lastTriggered?: number;
  /** Enabled */
  enabled: boolean;
}

/**
 * Threat factor
 */
export interface ThreatFactor {
  /** Factor ID */
  id: string;
  /** Factor name */
  name: string;
  /** Factor category */
  category: 'external' | 'internal' | 'historical' | 'realtime' | 'predictive';
  /** Weight (0-1) */
  weight: number;
  /** Current value */
  currentValue: number;
  /** Normalized value */
  normalizedValue: number;
  /** Contribution to threat score */
  contribution: number;
  /** Data source */
  source: string;
  /** Last updated */
  updatedAt: number;
}

/**
 * Threshold history entry
 */
export interface ThresholdHistoryEntry {
  /** Entry ID */
  id: string;
  /** Timestamp */
  timestamp: number;
  /** Old threshold */
  oldThreshold: number;
  /** New threshold */
  newThreshold: number;
  /** Old threat level */
  oldThreatLevel: ThreatLevel;
  /** New threat level */
  newThreatLevel: ThreatLevel;
  /** Reason */
  reason: string;
  /** Trigger */
  trigger: 'time_rule' | 'event' | 'threat_change' | 'manual' | 'automatic';
  /** Trigger ID */
  triggerId?: string;
}

/**
 * Threat assessment
 */
export interface ThreatAssessment {
  /** Assessment ID */
  id: string;
  /** Context */
  context: string;
  /** Timestamp */
  timestamp: number;
  /** Overall threat score */
  threatScore: number;
  /** Threat level */
  threatLevel: ThreatLevel;
  /** Factor breakdown */
  factors: ThreatFactor[];
  /** Recommended threshold */
  recommendedThreshold: number;
  /** Confidence */
  confidence: number;
  /** Trends */
  trends: {
    scoreTrend: 'increasing' | 'stable' | 'decreasing';
    levelTrend: 'escalating' | 'stable' | 'de-escalating';
  };
  /** Predictions */
  predictions?: {
    scoreIn1Hour: number;
    scoreIn24Hours: number;
    probabilityOfEscalation: number;
  };
}

/**
 * Threshold adjustment request
 */
export interface ThresholdAdjustmentRequest {
  /** Request ID */
  id: string;
  /** Config ID */
  configId: string;
  /** Requested threshold */
  requestedThreshold: number;
  /** Reason */
  reason: string;
  /** Requester */
  requester: string;
  /** Timestamp */
  timestamp: number;
  /** Status */
  status: 'pending' | 'approved' | 'rejected' | 'applied';
  /** Auto-approve eligible */
  autoApproveEligible: boolean;
}

/**
 * Modulation configuration
 */
export interface ModulationConfig {
  /** Default adjustment sensitivity */
  defaultSensitivity: number;
  /** Threat score calculation mode */
  calculationMode: 'weighted_sum' | 'geometric_mean' | 'max' | 'custom';
  /** Enable time-based rules */
  enableTimeRules: boolean;
  /** Enable event triggers */
  enableEventTriggers: boolean;
  /** Enable predictive adjustments */
  enablePredictive: boolean;
  /** History retention (days) */
  historyRetentionDays: number;
  /** Min adjustment interval (ms) */
  minAdjustmentInterval: number;
}

// ============================================================================
// STORAGE
// ============================================================================

const configs = new Map<string, ThresholdConfig>();
const assessments = new Map<string, ThreatAssessment>();
const adjustmentRequests = new Map<string, ThresholdAdjustmentRequest>();
const threatFactors = new Map<string, ThreatFactor[]>();

// Configuration
let modulationConfig: ModulationConfig = {
  defaultSensitivity: 0.5,
  calculationMode: 'weighted_sum',
  enableTimeRules: true,
  enableEventTriggers: true,
  enablePredictive: true,
  historyRetentionDays: 90,
  minAdjustmentInterval: 60000 // 1 minute
};

// Threat level thresholds
const THREAT_LEVEL_THRESHOLDS: Record<ThreatLevel, { min: number; max: number }> = {
  'minimal': { min: 0, max: 10 },
  'low': { min: 10, max: 25 },
  'moderate': { min: 25, max: 50 },
  'high': { min: 50, max: 75 },
  'critical': { min: 75, max: 90 },
  'extreme': { min: 90, max: 100 }
};

// Threat level multipliers for threshold adjustment
const THREAT_MULTIPLIERS: Record<ThreatLevel, number> = {
  'minimal': 1.0,
  'low': 0.95,
  'moderate': 0.85,
  'high': 0.70,
  'critical': 0.50,
  'extreme': 0.30
};

// ============================================================================
// CONFIGURATION MANAGEMENT
// ============================================================================

/**
 * Update modulation configuration
 */
export function updateModulationConfig(newConfig: Partial<ModulationConfig>): ModulationConfig {
  modulationConfig = { ...modulationConfig, ...newConfig };
  return modulationConfig;
}

/**
 * Get modulation configuration
 */
export function getModulationConfig(): ModulationConfig {
  return { ...modulationConfig };
}

// ============================================================================
// THRESHOLD CONFIG MANAGEMENT
// ============================================================================

/**
 * Create threshold configuration
 */
export function createThresholdConfig(params: {
  name: string;
  type: ThresholdType;
  context: string;
  baseThreshold: number;
  minThreshold?: number;
  maxThreshold?: number;
  sensitivity?: number;
  adjustmentMode?: 'automatic' | 'manual' | 'hybrid';
}): ThresholdConfig {
  const id = `thresh_${generateUUID()}`;
  const now = Date.now();

  const config: ThresholdConfig = {
    id,
    name: params.name,
    type: params.type,
    context: params.context,
    baseThreshold: params.baseThreshold,
    minThreshold: params.minThreshold ?? Math.max(0, params.baseThreshold * 0.1),
    maxThreshold: params.maxThreshold ?? params.baseThreshold * 2,
    currentThreshold: params.baseThreshold,
    threatLevel: 'minimal',
    threatScore: 0,
    sensitivity: params.sensitivity ?? modulationConfig.defaultSensitivity,
    adjustmentMode: params.adjustmentMode ?? 'automatic',
    timeRules: [],
    eventTriggers: [],
    threatFactors: [],
    history: [],
    createdAt: now,
    updatedAt: now,
    enabled: true
  };

  configs.set(id, config);
  return config;
}

/**
 * Get threshold configuration
 */
export function getThresholdConfig(configId: string): ThresholdConfig | undefined {
  return configs.get(configId);
}

/**
 * List threshold configurations
 */
export function listThresholdConfigs(type?: ThresholdType, context?: string): ThresholdConfig[] {
  let result = Array.from(configs.values());
  if (type) {
    result = result.filter(c => c.type === type);
  }
  if (context) {
    result = result.filter(c => c.context === context);
  }
  return result;
}

/**
 * Update threshold configuration
 */
export function updateThresholdConfig(configId: string, updates: Partial<ThresholdConfig>): ThresholdConfig | null {
  const config = configs.get(configId);
  if (!config) return null;

  Object.assign(config, updates, { updatedAt: Date.now() });
  configs.set(configId, config);
  return config;
}

// ============================================================================
// TIME RULES
// ============================================================================

/**
 * Add time rule
 */
export function addTimeRule(configId: string, rule: Omit<TimeRule, 'id'>): TimeRule | null {
  const config = configs.get(configId);
  if (!config) return null;

  const timeRule: TimeRule = {
    ...rule,
    id: `rule_${generateUUID()}`
  };

  config.timeRules.push(timeRule);
  config.timeRules.sort((a, b) => b.priority - a.priority);
  config.updatedAt = Date.now();
  configs.set(configId, config);

  return timeRule;
}

/**
 * Evaluate time rules
 */
function evaluateTimeRules(config: ThresholdConfig): { adjustment: number; matchedRule?: TimeRule } {
  if (!modulationConfig.enableTimeRules) {
    return { adjustment: 1.0 };
  }

  const now = new Date();
  const currentHour = now.getHours();
  const currentDay = now.getDay();
  const currentMonth = now.getMonth();

  for (const rule of config.timeRules.filter(r => r.enabled)) {
    let matches = false;

    switch (rule.type) {
      case 'time_of_day':
        const [startHour, startMin] = (rule.condition.start || '00:00').split(':').map(Number);
        const [endHour, endMin] = (rule.condition.end || '23:59').split(':').map(Number);
        const currentMinutes = currentHour * 60 + currentMin;
        const startMinutes = startHour * 60 + startMin;
        const endMinutes = endHour * 60 + endMin;
        matches = currentMinutes >= startMinutes && currentMinutes <= endMinutes;
        break;

      case 'day_of_week':
        matches = rule.condition.days?.includes(currentDay) ?? false;
        break;

      case 'seasonal':
        matches = rule.condition.months?.includes(currentMonth) ?? false;
        break;
    }

    if (matches) {
      const adjustment = rule.adjustmentType === 'multiplier' ? rule.adjustment :
                        rule.adjustmentType === 'additive' ? 1 + rule.adjustment / config.baseThreshold :
                        rule.adjustment / config.baseThreshold;
      return { adjustment, matchedRule: rule };
    }
  }

  return { adjustment: 1.0 };
}

// ============================================================================
// EVENT TRIGGERS
// ============================================================================

/**
 * Add event trigger
 */
export function addEventTrigger(configId: string, trigger: Omit<EventTrigger, 'id' | 'lastTriggered'>): EventTrigger | null {
  const config = configs.get(configId);
  if (!config) return null;

  const eventTrigger: EventTrigger = {
    ...trigger,
    id: `trigger_${generateUUID()}`
  };

  config.eventTriggers.push(eventTrigger);
  config.updatedAt = Date.now();
  configs.set(configId, config);

  return eventTrigger;
}

/**
 * Process event for triggers
 */
export function processEvent(configId: string, eventType: string, eventData: Record<string, unknown>): {
  triggered: boolean;
  triggers: EventTrigger[];
  adjustment: number;
} {
  const config = configs.get(configId);
  if (!config || !modulationConfig.enableEventTriggers) {
    return { triggered: false, triggers: [], adjustment: 1.0 };
  }

  const triggeredTriggers: EventTrigger[] = [];
  let totalAdjustment = 1.0;
  const now = Date.now();

  for (const trigger of config.eventTriggers.filter(t => t.enabled)) {
    // Check cooldown
    if (trigger.lastTriggered && now - trigger.lastTriggered < trigger.cooldown) {
      continue;
    }

    // Check event type
    if (trigger.eventType !== eventType) {
      continue;
    }

    // Check condition
    const fieldValue = eventData[trigger.condition.field];
    let conditionMet = false;

    switch (trigger.condition.operator) {
      case 'eq':
        conditionMet = fieldValue === trigger.condition.value;
        break;
      case 'gt':
        conditionMet = typeof fieldValue === 'number' && fieldValue > (trigger.condition.value as number);
        break;
      case 'lt':
        conditionMet = typeof fieldValue === 'number' && fieldValue < (trigger.condition.value as number);
        break;
      case 'gte':
        conditionMet = typeof fieldValue === 'number' && fieldValue >= (trigger.condition.value as number);
        break;
      case 'lte':
        conditionMet = typeof fieldValue === 'number' && fieldValue <= (trigger.condition.value as number);
        break;
      case 'contains':
        conditionMet = typeof fieldValue === 'string' && fieldValue.includes(trigger.condition.value as string);
        break;
    }

    if (conditionMet) {
      triggeredTriggers.push(trigger);
      totalAdjustment *= trigger.adjustment;
      trigger.lastTriggered = now;
    }
  }

  // Update config with trigger states
  if (triggeredTriggers.length > 0) {
    config.updatedAt = now;
    configs.set(configId, config);
  }

  return {
    triggered: triggeredTriggers.length > 0,
    triggers: triggeredTriggers,
    adjustment: totalAdjustment
  };
}

// ============================================================================
// THREAT FACTORS
// ============================================================================

/**
 * Update threat factor
 */
export function updateThreatFactor(configId: string, factor: Omit<ThreatFactor, 'id' | 'normalizedValue' | 'contribution' | 'updatedAt'>): ThreatFactor | null {
  const config = configs.get(configId);
  if (!config) return null;

  const existingIndex = config.threatFactors.findIndex(f => f.name === factor.name);
  const normalizedValue = factor.currentValue / 100; // Assuming values are 0-100

  const fullFactor: ThreatFactor = {
    id: existingIndex >= 0 ? config.threatFactors[existingIndex].id : `factor_${generateUUID()}`,
    name: factor.name,
    category: factor.category,
    weight: factor.weight,
    currentValue: factor.currentValue,
    normalizedValue,
    contribution: normalizedValue * factor.weight,
    source: factor.source,
    updatedAt: Date.now()
  };

  if (existingIndex >= 0) {
    config.threatFactors[existingIndex] = fullFactor;
  } else {
    config.threatFactors.push(fullFactor);
  }

  config.updatedAt = Date.now();
  configs.set(configId, config);

  return fullFactor;
}

/**
 * Calculate threat score
 */
function calculateThreatScore(config: ThresholdConfig): number {
  if (config.threatFactors.length === 0) {
    return 0;
  }

  switch (modulationConfig.calculationMode) {
    case 'weighted_sum':
      const totalWeight = config.threatFactors.reduce((sum, f) => sum + f.weight, 0);
      const weightedSum = config.threatFactors.reduce((sum, f) => sum + f.contribution, 0);
      return totalWeight > 0 ? (weightedSum / totalWeight) * 100 : 0;

    case 'geometric_mean':
      const product = config.threatFactors.reduce((prod, f) => prod * Math.max(0.001, f.normalizedValue), 1);
      return Math.pow(product, 1 / config.threatFactors.length) * 100;

    case 'max':
      return Math.max(...config.threatFactors.map(f => f.currentValue));

    default:
      return config.threatFactors.reduce((sum, f) => sum + f.contribution, 0);
  }
}

/**
 * Determine threat level from score
 */
function determineThreatLevel(score: number): ThreatLevel {
  for (const [level, range] of Object.entries(THREAT_LEVEL_THRESHOLDS)) {
    if (score >= range.min && score < range.max) {
      return level as ThreatLevel;
    }
  }
  return 'extreme';
}

// ============================================================================
// THRESHOLD ADJUSTMENT
// ============================================================================

/**
 * Calculate adjusted threshold
 */
export function calculateAdjustedThreshold(configId: string): {
  threshold: number;
  threatScore: number;
  threatLevel: ThreatLevel;
  factors: {
    base: number;
    threat: number;
    time: number;
    events: number;
  };
} {
  const config = configs.get(configId);
  if (!config) {
    throw new Error('Config not found');
  }

  // Calculate threat score
  const threatScore = calculateThreatScore(config);
  const threatLevel = determineThreatLevel(threatScore);

  // Get threat multiplier
  const threatMultiplier = THREAT_MULTIPLIERS[threatLevel];

  // Evaluate time rules
  const { adjustment: timeAdjustment } = evaluateTimeRules(config);

  // Get active event adjustments
  const activeEvents = config.eventTriggers.filter(t => 
    t.lastTriggered && 
    Date.now() - t.lastTriggered < t.duration
  );
  const eventAdjustment = activeEvents.reduce((prod, t) => prod * t.adjustment, 1.0);

  // Calculate final threshold
  let threshold = config.baseThreshold;
  threshold *= threatMultiplier * config.sensitivity;
  threshold *= timeAdjustment;
  threshold *= eventAdjustment;

  // Clamp to bounds
  threshold = Math.max(config.minThreshold, Math.min(config.maxThreshold, threshold));

  return {
    threshold: Math.round(threshold * 100) / 100,
    threatScore: Math.round(threatScore * 100) / 100,
    threatLevel,
    factors: {
      base: config.baseThreshold,
      threat: threatMultiplier,
      time: timeAdjustment,
      events: eventAdjustment
    }
  };
}

/**
 * Apply threshold adjustment
 */
export function applyThresholdAdjustment(configId: string, reason: string): ThresholdConfig | null {
  const config = configs.get(configId);
  if (!config) return null;

  const oldThreshold = config.currentThreshold;
  const oldThreatLevel = config.threatLevel;

  const result = calculateAdjustedThreshold(configId);

  config.currentThreshold = result.threshold;
  config.threatScore = result.threatScore;
  config.threatLevel = result.threatLevel;

  // Add history entry
  const historyEntry: ThresholdHistoryEntry = {
    id: `hist_${generateUUID()}`,
    timestamp: Date.now(),
    oldThreshold,
    newThreshold: result.threshold,
    oldThreatLevel,
    newThreatLevel: result.threatLevel,
    reason,
    trigger: 'automatic'
  };

  config.history.push(historyEntry);

  // Clean old history
  const retentionMs = modulationConfig.historyRetentionDays * 24 * 60 * 60 * 1000;
  config.history = config.history.filter(h => h.timestamp > Date.now() - retentionMs);

  config.updatedAt = Date.now();
  configs.set(configId, config);

  return config;
}

/**
 * Manual threshold adjustment
 */
export function manualThresholdAdjustment(configId: string, newThreshold: number, reason: string, requester: string): ThresholdConfig | null {
  const config = configs.get(configId);
  if (!config) return null;

  const oldThreshold = config.currentThreshold;
  const oldThreatLevel = config.threatLevel;

  // Clamp to bounds
  newThreshold = Math.max(config.minThreshold, Math.min(config.maxThreshold, newThreshold));

  config.currentThreshold = newThreshold;

  // Add history entry
  config.history.push({
    id: `hist_${generateUUID()}`,
    timestamp: Date.now(),
    oldThreshold,
    newThreshold,
    oldThreatLevel,
    newThreatLevel: config.threatLevel,
    reason,
    trigger: 'manual'
  });

  config.updatedAt = Date.now();
  configs.set(configId, config);

  return config;
}

// ============================================================================
// THREAT ASSESSMENT
// ============================================================================

/**
 * Generate threat assessment
 */
export function generateThreatAssessment(context: string): ThreatAssessment {
  const contextConfigs = Array.from(configs.values()).filter(c => c.context === context);

  // Aggregate threat factors
  const aggregatedFactors = new Map<string, ThreatFactor>();
  for (const config of contextConfigs) {
    for (const factor of config.threatFactors) {
      const existing = aggregatedFactors.get(factor.name);
      if (existing) {
        existing.currentValue = (existing.currentValue + factor.currentValue) / 2;
        existing.normalizedValue = existing.currentValue / 100;
        existing.contribution = existing.normalizedValue * existing.weight;
      } else {
        aggregatedFactors.set(factor.name, { ...factor });
      }
    }
  }

  const factors = Array.from(aggregatedFactors.values());

  // Calculate overall threat score
  let threatScore = 0;
  if (factors.length > 0) {
    const totalWeight = factors.reduce((sum, f) => sum + f.weight, 0);
    threatScore = (factors.reduce((sum, f) => sum + f.contribution, 0) / totalWeight) * 100;
  }

  const threatLevel = determineThreatLevel(threatScore);

  // Calculate recommended threshold
  const recommendedThreshold = config.baseThreshold * THREAT_MULTIPLIERS[threatLevel];

  // Determine trends
  const recentHistory = contextConfigs.flatMap(c => c.history.slice(-5));
  const scoreTrend: 'increasing' | 'stable' | 'decreasing' = 
    threatScore > 50 ? 'increasing' : threatScore < 30 ? 'decreasing' : 'stable';
  const levelTrend: 'escalating' | 'stable' | 'de-escalating' =
    threatScore > 60 ? 'escalating' : threatScore < 40 ? 'de-escalating' : 'stable';

  // Generate predictions if enabled
  let predictions: ThreatAssessment['predictions'] | undefined;
  if (modulationConfig.enablePredictive) {
    predictions = {
      scoreIn1Hour: Math.min(100, threatScore * 1.05),
      scoreIn24Hours: Math.min(100, threatScore * 1.1),
      probabilityOfEscalation: threatScore > 50 ? 0.6 : threatScore > 30 ? 0.3 : 0.1
    };
  }

  const assessment: ThreatAssessment = {
    id: `assess_${generateUUID()}`,
    context,
    timestamp: Date.now(),
    threatScore: Math.round(threatScore * 100) / 100,
    threatLevel,
    factors,
    recommendedThreshold: Math.round(recommendedThreshold * 100) / 100,
    confidence: factors.length > 0 ? Math.min(1, factors.length / 5) : 0,
    trends: { scoreTrend, levelTrend },
    predictions
  };

  assessments.set(assessment.id, assessment);
  return assessment;
}

/**
 * Get threat assessment
 */
export function getThreatAssessment(assessmentId: string): ThreatAssessment | undefined {
  return assessments.get(assessmentId);
}

// ============================================================================
// QUERIES
// ============================================================================

/**
 * Get threshold history
 */
export function getThresholdHistory(configId: string, limit: number = 100): ThresholdHistoryEntry[] {
  const config = configs.get(configId);
  if (!config) return [];
  return config.history.slice(-limit);
}

/**
 * Get current thresholds by context
 */
export function getThresholdsByContext(context: string): Array<{ name: string; threshold: number; threatLevel: ThreatLevel }> {
  return Array.from(configs.values())
    .filter(c => c.context === context && c.enabled)
    .map(c => ({
      name: c.name,
      threshold: c.currentThreshold,
      threatLevel: c.threatLevel
    }));
}

// ============================================================================
// STATISTICS
// ============================================================================

/**
 * Get system statistics
 */
export function getSystemStats(): {
  configs: { total: number; byType: Record<string, number>; byThreatLevel: Record<string, number> };
  assessments: { total: number; avgThreatScore: number };
  triggers: { total: number; active: number };
} {
  const allConfigs = Array.from(configs.values());
  const allAssessments = Array.from(assessments.values());

  const byType: Record<string, number> = {};
  const byThreatLevel: Record<string, number> = {};

  for (const c of allConfigs) {
    byType[c.type] = (byType[c.type] || 0) + 1;
    byThreatLevel[c.threatLevel] = (byThreatLevel[c.threatLevel] || 0) + 1;
  }

  const avgThreatScore = allAssessments.length > 0
    ? allAssessments.reduce((sum, a) => sum + a.threatScore, 0) / allAssessments.length
    : 0;

  const allTriggers = allConfigs.flatMap(c => c.eventTriggers);
  const activeTriggers = allTriggers.filter(t => t.lastTriggered && Date.now() - t.lastTriggered < t.duration);

  return {
    configs: { total: allConfigs.length, byType, byThreatLevel },
    assessments: {
      total: allAssessments.length,
      avgThreatScore: Math.round(avgThreatScore * 10) / 10
    },
    triggers: { total: allTriggers.length, active: activeTriggers.length }
  };
}

// ============================================================================
// TEST SUITE
// ============================================================================

/**
 * Run threshold modulation tests
 */
export function runThresholdModulationTests(): {
  passed: boolean;
  tests: { total: number; passed: number; failed: number };
  results: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const results: Array<{ name: string; passed: boolean; error?: string }> = [];

  try {
    // Test 1: Create threshold config
    const config = createThresholdConfig({
      name: 'Test Threshold',
      type: 'security',
      context: 'test',
      baseThreshold: 50
    });
    results.push({ name: 'Create Threshold Config', passed: !!config.id && config.currentThreshold === 50 });

    // Test 2: Add time rule
    const timeRule = addTimeRule(config.id, {
      name: 'Business Hours',
      type: 'time_of_day',
      condition: { start: '09:00', end: '17:00' },
      adjustment: 0.9,
      adjustmentType: 'multiplier',
      priority: 1,
      enabled: true
    });
    results.push({ name: 'Add Time Rule', passed: !!timeRule?.id });

    // Test 3: Add event trigger
    const eventTrigger = addEventTrigger(config.id, {
      name: 'Attack Detected',
      eventType: 'security_incident',
      condition: { field: 'severity', operator: 'gte', value: 7 },
      adjustment: 0.5,
      duration: 3600000,
      cooldown: 1800000,
      enabled: true
    });
    results.push({ name: 'Add Event Trigger', passed: !!eventTrigger?.id });

    // Test 4: Update threat factor
    const factor = updateThreatFactor(config.id, {
      name: 'External Threats',
      category: 'external',
      weight: 0.5,
      currentValue: 60,
      source: 'threat_intelligence'
    });
    results.push({ name: 'Update Threat Factor', passed: !!factor && factor.currentValue === 60 });

    // Test 5: Calculate adjusted threshold
    const adjusted = calculateAdjustedThreshold(config.id);
    results.push({ name: 'Calculate Adjusted Threshold', passed: adjusted.threshold > 0 && adjusted.threshold <= 100 });

    // Test 6: Apply threshold adjustment
    const updatedConfig = applyThresholdAdjustment(config.id, 'Test adjustment');
    results.push({ name: 'Apply Threshold Adjustment', passed: !!updatedConfig && updatedConfig.history.length > 0 });

    // Test 7: Process event
    const eventResult = processEvent(config.id, 'security_incident', { severity: 8 });
    results.push({ name: 'Process Event', passed: eventResult.triggered });

    // Test 8: Generate threat assessment
    const assessment = generateThreatAssessment('test');
    results.push({ name: 'Generate Threat Assessment', passed: !!assessment.id && assessment.threatScore >= 0 });

    // Test 9: Manual adjustment
    const manualConfig = manualThresholdAdjustment(config.id, 30, 'Manual test', 'admin');
    results.push({ name: 'Manual Threshold Adjustment', passed: manualConfig?.currentThreshold === 30 });

    // Test 10: Get history
    const history = getThresholdHistory(config.id);
    results.push({ name: 'Get Threshold History', passed: history.length >= 2 });

    // Test 11: List configs
    const configs = listThresholdConfigs('security');
    results.push({ name: 'List Threshold Configs', passed: configs.length > 0 });

    // Test 12: Statistics
    const stats = getSystemStats();
    results.push({ name: 'System Statistics', passed: stats.configs.total > 0 });

  } catch (error) {
    results.push({ name: 'Test execution', passed: false, error: String(error) });
  }

  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;

  return {
    passed: failed === 0,
    tests: { total: results.length, passed, failed },
    results
  };
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

const thresholdModulation = {
  // Configuration
  updateModulationConfig,
  getModulationConfig,
  // Threshold config management
  createThresholdConfig,
  getThresholdConfig,
  listThresholdConfigs,
  updateThresholdConfig,
  // Time rules
  addTimeRule,
  // Event triggers
  addEventTrigger,
  processEvent,
  // Threat factors
  updateThreatFactor,
  // Threshold adjustment
  calculateAdjustedThreshold,
  applyThresholdAdjustment,
  manualThresholdAdjustment,
  // Threat assessment
  generateThreatAssessment,
  getThreatAssessment,
  // Queries
  getThresholdHistory,
  getThresholdsByContext,
  // Statistics
  getSystemStats,
  // Tests
  runThresholdModulationTests
};

export default thresholdModulation;
