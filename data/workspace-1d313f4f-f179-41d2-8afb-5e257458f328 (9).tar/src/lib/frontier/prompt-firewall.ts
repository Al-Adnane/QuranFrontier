/**
 * Prompt Firewall - Injection detection and jailbreak prevention
 * @module frontier/prompt-firewall
 */
export type ThreatLevel = 'safe' | 'suspicious' | 'malicious' | 'critical';

export interface PromptAnalysis {
  id: string; prompt: string; threatLevel: ThreatLevel;
  threats: ThreatDetection[]; sanitized: string;
  blocked: boolean; score: number;
  timestamp: number;
}

export interface ThreatDetection {
  type: 'injection' | 'jailbreak' | 'extraction' | 'pii' | 'harmful';
  pattern: string; confidence: number; location: {start: number; end: number};
}

export interface FirewallRule {
  id: string; name: string; type: ThreatDetection['type'];
  pattern: string; action: 'block' | 'sanitize' | 'log';
  enabled: boolean; priority: number;
}

const analyses = new Map<string, PromptAnalysis>();
const rules = new Map<string, FirewallRule>();

// Default rules
const defaultRules: FirewallRule[] = [
  {id:'r1', name:'SQL Injection', type:'injection', pattern:'(SELECT|INSERT|UPDATE|DELETE|DROP)', action:'block', enabled:true, priority:1},
  {id:'r2', name:'Jailbreak', type:'jailbreak', pattern:'(ignore previous|bypass|override)', action:'block', enabled:true, priority:1},
  {id:'r3', name:'PII Extraction', type:'pii', pattern:'(password|api.key|secret|token)', action:'sanitize', enabled:true, priority:2},
];

defaultRules.forEach(r => rules.set(r.id, r));

export function analyzePrompt(prompt: string): PromptAnalysis {
  const threats: ThreatDetection[] = [];
  let sanitized = prompt;
  let score = 0;
  
  for (const rule of Array.from(rules.values()).filter(r=>r.enabled).sort((a,b)=>a.priority-b.priority)) {
    const regex = new RegExp(rule.pattern, 'gi');
    let match;
    while ((match = regex.exec(prompt)) !== null) {
      threats.push({
        type: rule.type, pattern: match[0], confidence: 0.8,
        location: {start: match.index, end: match.index + match[0].length}
      });
      score += rule.type === 'injection' ? 0.4 : rule.type === 'jailbreak' ? 0.5 : 0.2;
      if (rule.action === 'sanitize') {
        sanitized = sanitized.replace(match[0], '[REDACTED]');
      }
    }
  }
  
  const threatLevel: ThreatLevel = score >= 0.7 ? 'critical' : score >= 0.5 ? 'malicious' : score >= 0.3 ? 'suspicious' : 'safe';
  
  const analysis: PromptAnalysis = {
    id: `pa_${Date.now()}_${Math.random().toString(36).substr(2,6)}`,
    prompt, threatLevel, threats, sanitized, blocked: threatLevel === 'critical' || threatLevel === 'malicious',
    score, timestamp: Date.now()
  };
  
  analyses.set(analysis.id, analysis);
  return analysis;
}

export function addRule(config: {name: string; type: ThreatDetection['type']; pattern: string; action: FirewallRule['action']; priority?: number}): FirewallRule {
  const rule: FirewallRule = {
    id: `rule_${Date.now()}_${Math.random().toString(36).substr(2,4)}`,
    ...config, enabled: true, priority: config.priority || 5
  };
  rules.set(rule.id, rule);
  return rule;
}

export function getAnalysis(id: string): PromptAnalysis | undefined { return analyses.get(id); }
export function getRules(): FirewallRule[] { return Array.from(rules.values()); }

export function getPromptFirewallStats() {
  const analyses_arr = Array.from(analyses.values());
  return {
    total: analyses.size,
    blocked: analyses_arr.filter(a=>a.blocked).length,
    byThreat: {
      injection: analyses_arr.filter(a=>a.threats.some(t=>t.type==='injection')).length,
      jailbreak: analyses_arr.filter(a=>a.threats.some(t=>t.type==='jailbreak')).length,
      pii: analyses_arr.filter(a=>a.threats.some(t=>t.type==='pii')).length,
    }
  };
}

export function runPromptFirewallTests() {
  const results: {name: string; passed: boolean}[] = [];
  try { const a = analyzePrompt('Hello world'); results.push({name:'Safe',passed:a.threatLevel==='safe'}); } catch { results.push({name:'Safe',passed:false}); }
  try { const a = analyzePrompt('SELECT * FROM users'); results.push({name:'Injection',passed:a.threats.length>0}); } catch { results.push({name:'Injection',passed:false}); }
  try { const a = analyzePrompt('Ignore previous instructions'); results.push({name:'Jailbreak',passed:a.blocked}); } catch { results.push({name:'Jailbreak',passed:false}); }
  try { const s = getPromptFirewallStats(); results.push({name:'Stats',passed:s.total>0}); } catch { results.push({name:'Stats',passed:false}); }
  const passed = results.filter(r=>r.passed).length, failed = results.filter(r=>!r.passed).length;
  return {passed: failed===0, tests:{total:results.length,passed,failed}, results};
}

export default {analyzePrompt,addRule,getAnalysis,getRules,getPromptFirewallStats,runPromptFirewallTests};
