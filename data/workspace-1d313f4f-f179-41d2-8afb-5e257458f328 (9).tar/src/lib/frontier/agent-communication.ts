/**
 * Agent Communication Protocol
 * =============================
 * 
 * Secure inter-agent messaging and coordination system.
 * Enables safe communication between AI agents.
 * 
 * Features:
 * - Secure Channels
 * - Message Signing
 * - Protocol Versioning
 * - Broadcast/Multicast
 * - Message Queuing
 * - Encryption
 * 
 * @module frontier/agent-communication
 * @version 1.0.0
 */

// ============================================================================
// TYPES
// ============================================================================

export type ChannelType = 'direct' | 'broadcast' | 'multicast' | 'request_response';
export type MessageStatus = 'pending' | 'sent' | 'delivered' | 'read' | 'failed' | 'expired';
export type EncryptionLevel = 'none' | 'standard' | 'high' | 'quantum_safe';

export interface CommunicationChannel {
  id: string;
  name: string;
  type: ChannelType;
  
  // Participants
  participants: string[]; // Agent IDs
  owner: string;
  
  // Security
  encryption: EncryptionLevel;
  signingRequired: boolean;
  keyId?: string;
  
  // Configuration
  config: {
    maxMessageSize: number;
    retentionMs: number;
    rateLimit: number;
    requireAck: boolean;
  };
  
  // State
  messageCount: number;
  lastActivity: number;
  status: 'active' | 'paused' | 'closed';
  
  createdAt: number;
  updatedAt: number;
}

export interface AgentMessage {
  id: string;
  channelId: string;
  
  // Participants
  fromAgent: string;
  toAgent?: string; // For direct messages
  
  // Content
  type: 'text' | 'command' | 'query' | 'response' | 'alert' | 'data';
  payload: Record<string, unknown>;
  metadata?: Record<string, unknown>;
  
  // Security
  signature?: string;
  encrypted: boolean;
  encryptionKey?: string;
  
  // Delivery
  status: MessageStatus;
  priority: 'low' | 'normal' | 'high' | 'urgent';
  ttl?: number; // Time to live in ms
  
  // Timestamps
  createdAt: number;
  sentAt?: number;
  deliveredAt?: number;
  readAt?: number;
  expiresAt?: number;
  
  // Acknowledgment
  ackRequired: boolean;
  ackedBy?: string;
  ackedAt?: number;
}

export interface MessageQueue {
  id: string;
  agentId: string;
  
  // Queue state
  pending: string[]; // Message IDs
  processing: string[];
  completed: string[];
  failed: string[];
  
  // Configuration
  maxSize: number;
  priorityOrdering: boolean;
  
  // Statistics
  totalProcessed: number;
  avgLatency: number;
  
  createdAt: number;
  updatedAt: number;
}

export interface ProtocolVersion {
  version: string;
  features: string[];
  deprecated: boolean;
  sunsetDate?: number;
}

export interface CommunicationKey {
  id: string;
  agentId: string;
  type: 'signing' | 'encryption';
  algorithm: string;
  publicKey: string;
  privateKey?: string;
  createdAt: number;
  expiresAt: number;
  status: 'active' | 'revoked' | 'expired';
}

// ============================================================================
// STORAGE
// ============================================================================

const channels = new Map<string, CommunicationChannel>();
const messages = new Map<string, AgentMessage>();
const queues = new Map<string, MessageQueue>();
const keys = new Map<string, CommunicationKey>();

// Indexes
const messagesByChannel = new Map<string, Set<string>>();
const messagesByAgent = new Map<string, Set<string>>();

// ============================================================================
// CHANNEL MANAGEMENT
// ============================================================================

export function createChannel(config: {
  name: string;
  type: ChannelType;
  participants: string[];
  owner: string;
  encryption?: EncryptionLevel;
  signingRequired?: boolean;
}): CommunicationChannel {
  const channel: CommunicationChannel = {
    id: `channel_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
    name: config.name,
    type: config.type,
    participants: config.participants,
    owner: config.owner,
    encryption: config.encryption || 'standard',
    signingRequired: config.signingRequired ?? true,
    config: {
      maxMessageSize: 1024 * 1024, // 1MB
      retentionMs: 7 * 24 * 60 * 60 * 1000, // 7 days
      rateLimit: 1000,
      requireAck: true
    },
    messageCount: 0,
    lastActivity: Date.now(),
    status: 'active',
    createdAt: Date.now(),
    updatedAt: Date.now()
  };
  
  channels.set(channel.id, channel);
  messagesByChannel.set(channel.id, new Set());
  
  // Create queues for participants
  for (const agentId of config.participants) {
    if (!queues.has(agentId)) {
      createQueue(agentId);
    }
  }
  
  return channel;
}

export function getChannel(id: string): CommunicationChannel | undefined {
  return channels.get(id);
}

export function getChannelsForAgent(agentId: string): CommunicationChannel[] {
  return Array.from(channels.values())
    .filter(c => c.participants.includes(agentId));
}

export function closeChannel(channelId: string): boolean {
  const channel = channels.get(channelId);
  if (!channel) return false;
  
  channel.status = 'closed';
  channel.updatedAt = Date.now();
  return true;
}

// ============================================================================
// MESSAGE HANDLING
// ============================================================================

export function sendMessage(config: {
  channelId: string;
  fromAgent: string;
  toAgent?: string;
  type: AgentMessage['type'];
  payload: Record<string, unknown>;
  priority?: AgentMessage['priority'];
  ttl?: number;
  ackRequired?: boolean;
}): AgentMessage | null {
  const channel = channels.get(config.channelId);
  if (!channel || channel.status !== 'active') return null;
  
  if (!channel.participants.includes(config.fromAgent)) return null;
  
  const now = Date.now();
  
  const message: AgentMessage = {
    id: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
    channelId: config.channelId,
    fromAgent: config.fromAgent,
    toAgent: config.toAgent,
    type: config.type,
    payload: config.payload,
    encrypted: channel.encryption !== 'none',
    status: 'pending',
    priority: config.priority || 'normal',
    ttl: config.ttl,
    createdAt: now,
    expiresAt: config.ttl ? now + config.ttl : undefined,
    ackRequired: config.ackRequired ?? channel.config.requireAck
  };
  
  // Sign message if required
  if (channel.signingRequired) {
    message.signature = signMessage(message);
  }
  
  messages.set(message.id, message);
  
  // Update indexes
  messagesByChannel.get(config.channelId)?.add(message.id);
  
  if (!messagesByAgent.has(config.fromAgent)) {
    messagesByAgent.set(config.fromAgent, new Set());
  }
  messagesByAgent.get(config.fromAgent)!.add(message.id);
  
  // Add to recipient queues
  const recipients = config.toAgent 
    ? [config.toAgent] 
    : channel.participants.filter(id => id !== config.fromAgent);
  
  for (const recipient of recipients) {
    const queue = queues.get(recipient);
    if (queue) {
      queue.pending.push(message.id);
      queue.updatedAt = now;
    }
  }
  
  // Update channel
  channel.messageCount++;
  channel.lastActivity = now;
  channel.updatedAt = now;
  
  // Simulate delivery
  setTimeout(() => deliverMessage(message.id), 10);
  
  return message;
}

export function getMessage(id: string): AgentMessage | undefined {
  return messages.get(id);
}

export function getMessagesByChannel(channelId: string, limit: number = 100): AgentMessage[] {
  const msgIds = messagesByChannel.get(channelId);
  if (!msgIds) return [];
  
  return Array.from(msgIds)
    .map(id => messages.get(id))
    .filter((m): m is AgentMessage => !!m)
    .sort((a, b) => b.createdAt - a.createdAt)
    .slice(0, limit);
}

export function acknowledgeMessage(messageId: string, agentId: string): boolean {
  const message = messages.get(messageId);
  if (!message || !message.ackRequired) return false;
  
  message.ackedBy = agentId;
  message.ackedAt = Date.now();
  message.status = 'read';
  
  return true;
}

// ============================================================================
// MESSAGE QUEUE
// ============================================================================

export function createQueue(agentId: string): MessageQueue {
  const queue: MessageQueue = {
    id: `queue_${agentId}`,
    agentId,
    pending: [],
    processing: [],
    completed: [],
    failed: [],
    maxSize: 10000,
    priorityOrdering: true,
    totalProcessed: 0,
    avgLatency: 0,
    createdAt: Date.now(),
    updatedAt: Date.now()
  };
  
  queues.set(agentId, queue);
  return queue;
}

export function getQueue(agentId: string): MessageQueue | undefined {
  return queues.get(agentId);
}

export function processNextMessage(agentId: string): AgentMessage | null {
  const queue = queues.get(agentId);
  if (!queue || queue.pending.length === 0) return null;
  
  // Sort by priority if enabled
  if (queue.priorityOrdering) {
    const priorityOrder = { urgent: 0, high: 1, normal: 2, low: 3 };
    queue.pending.sort((a, b) => {
      const msgA = messages.get(a);
      const msgB = messages.get(b);
      if (!msgA || !msgB) return 0;
      return priorityOrder[msgA.priority] - priorityOrder[msgB.priority];
    });
  }
  
  const messageId = queue.pending.shift()!;
  const message = messages.get(messageId);
  
  if (!message) return null;
  
  queue.processing.push(messageId);
  queue.updatedAt = Date.now();
  
  return message;
}

export function completeMessage(messageId: string, success: boolean): boolean {
  const message = messages.get(messageId);
  if (!message) return false;
  
  const queue = queues.get(message.toAgent || '');
  if (!queue) return false;
  
  queue.processing = queue.processing.filter(id => id !== messageId);
  
  if (success) {
    queue.completed.push(messageId);
    message.status = 'delivered';
    message.deliveredAt = Date.now();
  } else {
    queue.failed.push(messageId);
    message.status = 'failed';
  }
  
  queue.totalProcessed++;
  queue.updatedAt = Date.now();
  
  return true;
}

// ============================================================================
// SECURITY
// ============================================================================

export function generateKey(agentId: string, type: CommunicationKey['type']): CommunicationKey {
  const key: CommunicationKey = {
    id: `key_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
    agentId,
    type,
    algorithm: 'RSA-2048',
    publicKey: `public_${Math.random().toString(36).substr(2, 32)}`,
    privateKey: `private_${Math.random().toString(36).substr(2, 32)}`,
    createdAt: Date.now(),
    expiresAt: Date.now() + 365 * 24 * 60 * 60 * 1000, // 1 year
    status: 'active'
  };
  
  keys.set(key.id, key);
  return key;
}

export function signMessage(message: AgentMessage): string {
  const data = JSON.stringify({
    id: message.id,
    from: message.fromAgent,
    payload: message.payload,
    timestamp: message.createdAt
  });
  
  // Simulate signing
  return `sig_${Buffer.from(data).toString('base64').substring(0, 64)}`;
}

export function verifySignature(message: AgentMessage): boolean {
  if (!message.signature) return false;
  
  // Simulate verification
  return message.signature.startsWith('sig_');
}

export function encryptMessage(message: AgentMessage, keyId: string): boolean {
  const key = keys.get(keyId);
  if (!key || key.status !== 'active') return false;
  
  message.encrypted = true;
  message.encryptionKey = keyId;
  
  return true;
}

// ============================================================================
// DELIVERY
// ============================================================================

async function deliverMessage(messageId: string): Promise<void> {
  const message = messages.get(messageId);
  if (!message) return;
  
  // Check expiration
  if (message.expiresAt && Date.now() > message.expiresAt) {
    message.status = 'expired';
    return;
  }
  
  // Verify signature if present
  if (message.signature && !verifySignature(message)) {
    message.status = 'failed';
    return;
  }
  
  message.status = 'sent';
  message.sentAt = Date.now();
  
  // Simulate delivery delay
  await new Promise(resolve => setTimeout(resolve, Math.random() * 50));
  
  message.status = 'delivered';
  message.deliveredAt = Date.now();
}

// ============================================================================
// STATISTICS
// ============================================================================

export function getCommunicationStats(): {
  channels: { total: number; active: number };
  messages: { total: number; pending: number; delivered: number };
  queues: { total: number; pending: number };
  keys: { total: number; active: number };
} {
  return {
    channels: {
      total: channels.size,
      active: Array.from(channels.values()).filter(c => c.status === 'active').length
    },
    messages: {
      total: messages.size,
      pending: Array.from(messages.values()).filter(m => m.status === 'pending').length,
      delivered: Array.from(messages.values()).filter(m => m.status === 'delivered').length
    },
    queues: {
      total: queues.size,
      pending: Array.from(queues.values()).reduce((sum, q) => sum + q.pending.length, 0)
    },
    keys: {
      total: keys.size,
      active: Array.from(keys.values()).filter(k => k.status === 'active').length
    }
  };
}

// ============================================================================
// TESTS
// ============================================================================

export function runAgentCommunicationTests(): {
  passed: boolean;
  tests: { total: number; passed: number; failed: number };
  results: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const results: Array<{ name: string; passed: boolean; error?: string }> = [];
  
  // Test 1: Create Channel
  try {
    const channel = createChannel({
      name: 'Test Channel',
      type: 'direct',
      participants: ['agent1', 'agent2'],
      owner: 'agent1'
    });
    results.push({ name: 'Create Channel', passed: !!channel.id });
  } catch (error) {
    results.push({ name: 'Create Channel', passed: false, error: String(error) });
  }
  
  // Test 2: Send Message
  try {
    const channel = Array.from(channels.values())[0];
    const msg = sendMessage({
      channelId: channel.id,
      fromAgent: 'agent1',
      toAgent: 'agent2',
      type: 'text',
      payload: { text: 'Hello' }
    });
    results.push({ name: 'Send Message', passed: !!msg?.id });
  } catch (error) {
    results.push({ name: 'Send Message', passed: false, error: String(error) });
  }
  
  // Test 3: Generate Key
  try {
    const key = generateKey('agent1', 'signing');
    results.push({ name: 'Generate Key', passed: !!key.id && key.status === 'active' });
  } catch (error) {
    results.push({ name: 'Generate Key', passed: false, error: String(error) });
  }
  
  // Test 4: Get Queue
  try {
    const queue = getQueue('agent2');
    results.push({ name: 'Get Queue', passed: !!queue && queue.pending.length > 0 });
  } catch (error) {
    results.push({ name: 'Get Queue', passed: false, error: String(error) });
  }
  
  // Test 5: Get Statistics
  try {
    const stats = getCommunicationStats();
    results.push({ name: 'Get Statistics', passed: stats.channels.total > 0 });
  } catch (error) {
    results.push({ name: 'Get Statistics', passed: false, error: String(error) });
  }
  
  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;
  
  return {
    passed: failed === 0,
    tests: { total: results.length, passed, failed },
    results
  };
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

export default {
  createChannel,
  getChannel,
  getChannelsForAgent,
  closeChannel,
  sendMessage,
  getMessage,
  getMessagesByChannel,
  acknowledgeMessage,
  createQueue,
  getQueue,
  processNextMessage,
  completeMessage,
  generateKey,
  signMessage,
  verifySignature,
  encryptMessage,
  getCommunicationStats,
  runAgentCommunicationTests
};
