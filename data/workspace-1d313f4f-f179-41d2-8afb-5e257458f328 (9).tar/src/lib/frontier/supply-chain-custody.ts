/**
 * Supply Chain Custody Module
 *
 * Supply chain tracking with CAIL (Cryptographic Audit Integrity Ledger).
 * Hash-chained custody tracking for product authenticity.
 *
 * @module frontier/supply-chain-custody
 * @version 9.1.0
 *
 * Capabilities:
 * - Chain of custody tracking
 * - Product authentication
 * - Anti-counterfeiting
 * - Shipment tracking
 * - Temperature monitoring
 * - Quality assurance
 * - Regulatory compliance
 * - Vendor verification
 * - Recall management
 * - Sustainability tracking
 */

import { generateUUID, sha256Hash, sha512Hash, hmacSign } from '../crypto-utils';

// ============================================================================
// TYPES
// ============================================================================

/**
 * Product
 */
export interface Product {
  /** Product ID */
  id: string;
  /** SKU */
  sku: string;
  /** Name */
  name: string;
  /** Description */
  description: string;
  /** Category */
  category: string;
  /** Manufacturer */
  manufacturer: Manufacturer;
  /** Batch/lot number */
  batchNumber: string;
  /** Serial number */
  serialNumber?: string;
  /** Manufacturing date */
  manufacturingDate: number;
  /** Expiration date */
  expirationDate?: number;
  /** Current status */
  status: 'manufactured' | 'in_transit' | 'stored' | 'delivered' | 'sold' | 'recalled' | 'disposed';
  /** Custody chain */
  custodyChain: CustodyEvent[];
  /** Hash chain */
  hashChain: HashChainBlock[];
  /** Quality checks */
  qualityChecks: QualityCheck[];
  /** Certifications */
  certifications: Certification[];
  /** Current holder */
  currentHolder: SupplyChainEntity;
  /** Location */
  currentLocation: ProductLocation;
  /** Metadata */
  metadata: Record<string, unknown>;
  /** Created timestamp */
  createdAt: number;
  /** Updated timestamp */
  updatedAt: number;
}

/**
 * Manufacturer
 */
export interface Manufacturer {
  /** Entity ID */
  id: string;
  /** Name */
  name: string;
  /** Location */
  location: string;
  /** Country */
  country: string;
  /** Certifications */
  certifications: string[];
  /** Contact */
  contact?: {
    email?: string;
    phone?: string;
    address?: string;
  };
}

/**
 * Supply chain entity
 */
export interface SupplyChainEntity {
  /** Entity ID */
  id: string;
  /** Name */
  name: string;
  /** Type */
  type: 'manufacturer' | 'distributor' | 'retailer' | 'logistics' | 'warehouse' | 'customer' | 'regulator';
  /** Location */
  location: string;
  /** Country */
  country: string;
  /** Verification status */
  verified: boolean;
  /** Trust score */
  trustScore: number;
}

/**
 * Product location
 */
export interface ProductLocation {
  /** Facility name */
  facility: string;
  /** Address */
  address: string;
  /** Coordinates */
  coordinates?: {
    latitude: number;
    longitude: number;
  };
  /** Zone/area */
  zone?: string;
  /** Timestamp */
  timestamp: number;
}

/**
 * Custody event
 */
export interface CustodyEvent {
  /** Event ID */
  id: string;
  /** Event type */
  type: 'manufactured' | 'transferred' | 'received' | 'stored' | 'shipped' | 'delivered' | 'processed' | 'inspected' | 'recalled';
  /** From entity */
  fromEntity?: SupplyChainEntity;
  /** To entity */
  toEntity: SupplyChainEntity;
  /** Location */
  location: ProductLocation;
  /** Timestamp */
  timestamp: number;
  /** Handler */
  handler: string;
  /** Conditions during transfer */
  conditions?: TransferConditions;
  /** Documents */
  documents: DocumentReference[];
  /** Signature */
  signature: string;
  /** Notes */
  notes?: string;
}

/**
 * Transfer conditions
 */
export interface TransferConditions {
  /** Temperature (C) */
  temperature?: number;
  /** Temperature range */
  temperatureRange?: { min: number; max: number };
  /** Humidity (%) */
  humidity?: number;
  /** Humidity range */
  humidityRange?: { min: number; max: number };
  /** Light exposure */
  lightExposure?: 'none' | 'minimal' | 'moderate' | 'high';
  /** Shock/vibration detected */
  shockDetected?: boolean;
  /** Package integrity */
  packageIntegrity: 'intact' | 'damaged' | 'tampered' | 'unknown';
  /** Seal status */
  sealStatus: 'sealed' | 'broken' | 'resealed' | 'not_applicable';
}

/**
 * Hash chain block
 */
export interface HashChainBlock {
  /** Block ID */
  id: string;
  /** Hash */
  hash: string;
  /** Previous hash */
  previousHash: string;
  /** Event ID */
  eventId: string;
  /** Timestamp */
  timestamp: number;
  /** Signature */
  signature: string;
}

/**
 * Quality check
 */
export interface QualityCheck {
  /** Check ID */
  id: string;
  /** Check type */
  type: 'incoming' | 'outgoing' | 'periodic' | 'random' | 'compliance';
  /** Inspector */
  inspector: string;
  /** Timestamp */
  timestamp: number;
  /** Result */
  result: 'pass' | 'fail' | 'conditional' | 'pending';
  /** Checklist items */
  items: QualityCheckItem[];
  /** Overall score */
  score: number;
  /** Notes */
  notes?: string;
}

/**
 * Quality check item
 */
export interface QualityCheckItem {
  /** Item name */
  name: string;
  /** Result */
  result: 'pass' | 'fail' | 'na';
  /** Value */
  value?: string | number;
  /** Expected value */
  expected?: string | number;
  /** Notes */
  notes?: string;
}

/**
 * Certification
 */
export interface Certification {
  /** Certification ID */
  id: string;
  /** Name */
  name: string;
  /** Issuer */
  issuer: string;
  /** Certificate number */
  certificateNumber: string;
  /** Issue date */
  issueDate: number;
  /** Expiry date */
  expiryDate?: number;
  /** Status */
  status: 'valid' | 'expired' | 'revoked' | 'pending';
  /** Verification URL */
  verificationUrl?: string;
}

/**
 * Document reference
 */
export interface DocumentReference {
  /** Document ID */
  id: string;
  /** Document type */
  type: 'invoice' | 'bill_of_lading' | 'certificate' | 'inspection_report' | 'customs' | 'other';
  /** Document number */
  documentNumber: string;
  /** Document hash */
  documentHash: string;
  /** Timestamp */
  timestamp: number;
  /** Signed */
  signed: boolean;
}

/**
 * Shipment
 */
export interface Shipment {
  /** Shipment ID */
  id: string;
  /** Shipment number */
  shipmentNumber: string;
  /** Products */
  productIds: string[];
  /** Origin */
  origin: ProductLocation;
  /** Destination */
  destination: ProductLocation;
  /** Carrier */
  carrier: SupplyChainEntity;
  /** Status */
  status: 'pending' | 'picked_up' | 'in_transit' | 'customs' | 'delivered' | 'cancelled';
  /** Estimated delivery */
  estimatedDelivery: number;
  /** Actual delivery */
  actualDelivery?: number;
  /** Tracking events */
  trackingEvents: TrackingEvent[];
  /** Conditions log */
  conditionsLog: ConditionReading[];
  /** Created timestamp */
  createdAt: number;
  /** Updated timestamp */
  updatedAt: number;
}

/**
 * Tracking event
 */
export interface TrackingEvent {
  /** Event ID */
  id: string;
  /** Event type */
  type: 'pickup' | 'checkpoint' | 'transfer' | 'customs' | 'delivery' | 'exception';
  /** Location */
  location: ProductLocation;
  /** Timestamp */
  timestamp: number;
  /** Description */
  description: string;
  /** Carrier reference */
  carrierReference?: string;
}

/**
 * Condition reading
 */
export interface ConditionReading {
  /** Reading ID */
  id: string;
  /** Timestamp */
  timestamp: number;
  /** Temperature (C) */
  temperature?: number;
  /** Humidity (%) */
  humidity?: number;
  /** Shock (G) */
  shock?: number;
  /** Location */
  location?: ProductLocation;
  /** Within acceptable range */
  withinRange: boolean;
}

/**
 * Recall notice
 */
export interface RecallNotice {
  /** Recall ID */
  id: string;
  /** Recall number */
  recallNumber: string;
  /** Reason */
  reason: string;
  /** Severity */
  severity: 'low' | 'medium' | 'high' | 'critical';
  /** Affected products */
  affectedProducts: string[];
  /** Affected batches */
  affectedBatches: string[];
  /** Issue date */
  issueDate: number;
  /** Status */
  status: 'active' | 'resolved' | 'cancelled';
  /** Actions taken */
  actions: RecallAction[];
  /** Regulatory reference */
  regulatoryReference?: string;
}

/**
 * Recall action
 */
export interface RecallAction {
  /** Action ID */
  id: string;
  /** Action type */
  type: 'notification' | 'retrieval' | 'destruction' | 'quarantine' | 'replacement';
  /** Description */
  description: string;
  /** Timestamp */
  timestamp: number;
  /** Actor */
  actor: string;
  /** Status */
  status: 'pending' | 'in_progress' | 'completed';
}

/**
 * Supply chain configuration
 */
export interface SupplyChainConfig {
  /** Hash algorithm */
  hashAlgorithm: 'SHA256' | 'SHA512';
  /** Enable automatic verification */
  enableAutoVerification: boolean;
  /** Verification interval (hours) */
  verificationInterval: number;
  /** Enable condition monitoring */
  enableConditionMonitoring: boolean;
  /** Alert thresholds */
  alertThresholds: {
    temperatureMin: number;
    temperatureMax: number;
    humidityMin: number;
    humidityMax: number;
    shockMax: number;
  };
  /** Require signatures */
  requireSignatures: boolean;
  /** Retention period (days) */
  retentionPeriod: number;
}

// ============================================================================
// STORAGE
// ============================================================================

const products = new Map<string, Product>();
const shipments = new Map<string, Shipment>();
const entities = new Map<string, SupplyChainEntity>();
const recalls = new Map<string, RecallNotice>();

// Configuration
let supplyChainConfig: SupplyChainConfig = {
  hashAlgorithm: 'SHA256',
  enableAutoVerification: true,
  verificationInterval: 6,
  enableConditionMonitoring: true,
  alertThresholds: {
    temperatureMin: -20,
    temperatureMax: 25,
    humidityMin: 30,
    humidityMax: 70,
    shockMax: 5
  },
  requireSignatures: true,
  retentionPeriod: 365 * 7 // 7 years
};

// Platform secret
const PLATFORM_SECRET = 'supply_chain_custody_secret_v1';

// ============================================================================
// CONFIGURATION
// ============================================================================

/**
 * Update supply chain configuration
 */
export function updateSupplyChainConfig(newConfig: Partial<SupplyChainConfig>): SupplyChainConfig {
  supplyChainConfig = { ...supplyChainConfig, ...newConfig };
  return supplyChainConfig;
}

/**
 * Get supply chain configuration
 */
export function getSupplyChainConfig(): SupplyChainConfig {
  return { ...supplyChainConfig };
}

// ============================================================================
// ENTITY MANAGEMENT
// ============================================================================

/**
 * Register entity
 */
export function registerEntity(params: Omit<SupplyChainEntity, 'verified' | 'trustScore'>): SupplyChainEntity {
  const entity: SupplyChainEntity = {
    ...params,
    verified: false,
    trustScore: 50
  };

  entities.set(entity.id, entity);
  return entity;
}

/**
 * Verify entity
 */
export function verifyEntity(entityId: string): SupplyChainEntity | null {
  const entity = entities.get(entityId);
  if (!entity) return null;

  entity.verified = true;
  entity.trustScore = Math.min(100, entity.trustScore + 20);
  entities.set(entityId, entity);

  return entity;
}

/**
 * Get entity
 */
export function getEntity(entityId: string): SupplyChainEntity | undefined {
  return entities.get(entityId);
}

// ============================================================================
// PRODUCT MANAGEMENT
// ============================================================================

/**
 * Register product
 */
export function registerProduct(params: {
  sku: string;
  name: string;
  description: string;
  category: string;
  manufacturer: Manufacturer;
  batchNumber: string;
  serialNumber?: string;
  manufacturingDate: number;
  expirationDate?: number;
  initialLocation: ProductLocation;
  initialHolder: SupplyChainEntity;
  certifications?: Certification[];
}): Product {
  const id = `product_${generateUUID()}`;
  const now = Date.now();

  // Create genesis hash
  const genesisData = JSON.stringify({
    id,
    sku: params.sku,
    batchNumber: params.batchNumber,
    manufacturingDate: params.manufacturingDate
  });
  const genesisHash = supplyChainConfig.hashAlgorithm === 'SHA512'
    ? sha512Hash(genesisData)
    : sha256Hash(genesisData);

  // Create initial custody event
  const custodyEvent: CustodyEvent = {
    id: `custody_${generateUUID()}`,
    type: 'manufactured',
    toEntity: params.initialHolder,
    location: params.initialLocation,
    timestamp: now,
    handler: 'system',
    documents: [],
    signature: hmacSign(genesisHash, PLATFORM_SECRET)
  };

  // Create genesis hash block
  const hashBlock: HashChainBlock = {
    id: `block_${generateUUID()}`,
    hash: genesisHash,
    previousHash: '0',
    eventId: custodyEvent.id,
    timestamp: now,
    signature: hmacSign(`${genesisHash}0`, PLATFORM_SECRET)
  };

  const product: Product = {
    id,
    sku: params.sku,
    name: params.name,
    description: params.description,
    category: params.category,
    manufacturer: params.manufacturer,
    batchNumber: params.batchNumber,
    serialNumber: params.serialNumber,
    manufacturingDate: params.manufacturingDate,
    expirationDate: params.expirationDate,
    status: 'manufactured',
    custodyChain: [custodyEvent],
    hashChain: [hashBlock],
    qualityChecks: [],
    certifications: params.certifications || [],
    currentHolder: params.initialHolder,
    currentLocation: params.initialLocation,
    metadata: {},
    createdAt: now,
    updatedAt: now
  };

  products.set(id, product);
  return product;
}

/**
 * Get product
 */
export function getProduct(productId: string): Product | undefined {
  return products.get(productId);
}

/**
 * Get product by batch
 */
export function getProductsByBatch(batchNumber: string): Product[] {
  return Array.from(products.values()).filter(p => p.batchNumber === batchNumber);
}

/**
 * Get product by serial number
 */
export function getProductBySerial(serialNumber: string): Product | undefined {
  return Array.from(products.values()).find(p => p.serialNumber === serialNumber);
}

// ============================================================================
// CUSTODY TRANSFER
// ============================================================================

/**
 * Transfer custody
 */
export function transferCustody(params: {
  productId: string;
  fromEntity: SupplyChainEntity;
  toEntity: SupplyChainEntity;
  location: ProductLocation;
  handler: string;
  conditions?: TransferConditions;
  documents?: DocumentReference[];
  notes?: string;
}): Product | null {
  const product = products.get(params.productId);
  if (!product) return null;

  // Verify current holder
  if (product.currentHolder.id !== params.fromEntity.id) {
    throw new Error('Invalid transfer - not current holder');
  }

  const now = Date.now();

  // Create custody event
  const custodyEvent: CustodyEvent = {
    id: `custody_${generateUUID()}`,
    type: 'transferred',
    fromEntity: params.fromEntity,
    toEntity: params.toEntity,
    location: params.location,
    timestamp: now,
    handler: params.handler,
    conditions: params.conditions,
    documents: params.documents || [],
    signature: hmacSign(`${product.id}${now}`, PLATFORM_SECRET),
    notes: params.notes
  };

  // Create hash block
  const lastBlock = product.hashChain[product.hashChain.length - 1];
  const blockData = JSON.stringify({
    productId: product.id,
    eventId: custodyEvent.id,
    timestamp: now,
    previousHash: lastBlock.hash
  });
  const blockHash = supplyChainConfig.hashAlgorithm === 'SHA512'
    ? sha512Hash(blockData)
    : sha256Hash(blockData);

  const hashBlock: HashChainBlock = {
    id: `block_${generateUUID()}`,
    hash: blockHash,
    previousHash: lastBlock.hash,
    eventId: custodyEvent.id,
    timestamp: now,
    signature: hmacSign(blockHash + lastBlock.hash, PLATFORM_SECRET)
  };

  // Update product
  product.custodyChain.push(custodyEvent);
  product.hashChain.push(hashBlock);
  product.currentHolder = params.toEntity;
  product.currentLocation = params.location;
  product.status = 'in_transit';
  product.updatedAt = now;

  // Check conditions
  if (params.conditions) {
    checkConditions(product, params.conditions);
  }

  products.set(product.id, product);

  return product;
}

/**
 * Check conditions and generate alerts
 */
function checkConditions(product: Product, conditions: TransferConditions): void {
  const thresholds = supplyChainConfig.alertThresholds;

  if (conditions.temperature !== undefined) {
    if (conditions.temperature < thresholds.temperatureMin ||
        conditions.temperature > thresholds.temperatureMax) {
      // Temperature out of range
      product.metadata.temperatureAlert = {
        value: conditions.temperature,
        range: [thresholds.temperatureMin, thresholds.temperatureMax],
        timestamp: Date.now()
      };
    }
  }

  if (conditions.packageIntegrity !== 'intact') {
    product.metadata.integrityAlert = {
      status: conditions.packageIntegrity,
      timestamp: Date.now()
    };
  }
}

/**
 * Verify product chain
 */
export function verifyProductChain(productId: string): {
  valid: boolean;
  chainIntact: boolean;
  blocksVerified: number;
  issues: string[];
} {
  const product = products.get(productId);
  if (!product) {
    return { valid: false, chainIntact: false, blocksVerified: 0, issues: ['Product not found'] };
  }

  const issues: string[] = [];
  let chainIntact = true;

  // Verify hash chain
  for (let i = 1; i < product.hashChain.length; i++) {
    const block = product.hashChain[i];
    const prevBlock = product.hashChain[i - 1];

    if (block.previousHash !== prevBlock.hash) {
      chainIntact = false;
      issues.push(`Hash chain broken at block ${i}`);
    }

    // Verify signature
    const expectedSignature = hmacSign(block.hash + prevBlock.hash, PLATFORM_SECRET);
    if (block.signature !== expectedSignature && supplyChainConfig.requireSignatures) {
      issues.push(`Invalid signature at block ${i}`);
    }
  }

  return {
    valid: issues.length === 0,
    chainIntact,
    blocksVerified: product.hashChain.length,
    issues
  };
}

// ============================================================================
// QUALITY CHECKS
// ============================================================================

/**
 * Perform quality check
 */
export function performQualityCheck(params: {
  productId: string;
  type: QualityCheck['type'];
  inspector: string;
  items: Omit<QualityCheckItem, 'result'>[];
}): QualityCheck | null {
  const product = products.get(params.productId);
  if (!product) return null;

  // Evaluate items
  const evaluatedItems: QualityCheckItem[] = params.items.map(item => {
    let result: 'pass' | 'fail' | 'na' = 'na';

    if (item.expected !== undefined && item.value !== undefined) {
      result = item.value === item.expected ? 'pass' : 'fail';
    }

    return { ...item, result };
  });

  // Calculate score
  const relevantItems = evaluatedItems.filter(i => i.result !== 'na');
  const passCount = relevantItems.filter(i => i.result === 'pass').length;
  const score = relevantItems.length > 0 ? (passCount / relevantItems.length) * 100 : 100;

  const overallResult: 'pass' | 'fail' | 'conditional' | 'pending' =
    score >= 90 ? 'pass' : score >= 70 ? 'conditional' : 'fail';

  const check: QualityCheck = {
    id: `qc_${generateUUID()}`,
    type: params.type,
    inspector: params.inspector,
    timestamp: Date.now(),
    result: overallResult,
    items: evaluatedItems,
    score
  };

  product.qualityChecks.push(check);
  product.updatedAt = Date.now();
  products.set(product.id, product);

  return check;
}

/**
 * Get quality check history
 */
export function getQualityCheckHistory(productId: string): QualityCheck[] {
  const product = products.get(productId);
  if (!product) return [];
  return product.qualityChecks;
}

// ============================================================================
// SHIPMENT MANAGEMENT
// ============================================================================

/**
 * Create shipment
 */
export function createShipment(params: {
  productIds: string[];
  origin: ProductLocation;
  destination: ProductLocation;
  carrier: SupplyChainEntity;
  estimatedDelivery: number;
}): Shipment {
  const shipment: Shipment = {
    id: `shipment_${generateUUID()}`,
    shipmentNumber: `SHP-${Date.now().toString(36).toUpperCase()}`,
    productIds: params.productIds,
    origin: params.origin,
    destination: params.destination,
    carrier: params.carrier,
    status: 'pending',
    estimatedDelivery: params.estimatedDelivery,
    trackingEvents: [],
    conditionsLog: [],
    createdAt: Date.now(),
    updatedAt: Date.now()
  };

  shipments.set(shipment.id, shipment);

  // Update product statuses
  for (const productId of params.productIds) {
    const product = products.get(productId);
    if (product) {
      product.status = 'in_transit';
      products.set(productId, product);
    }
  }

  return shipment;
}

/**
 * Add tracking event
 */
export function addTrackingEvent(shipmentId: string, event: Omit<TrackingEvent, 'id'>): TrackingEvent | null {
  const shipment = shipments.get(shipmentId);
  if (!shipment) return null;

  const trackingEvent: TrackingEvent = {
    ...event,
    id: `track_${generateUUID()}`
  };

  shipment.trackingEvents.push(trackingEvent);
  shipment.updatedAt = Date.now();

  if (event.type === 'delivery') {
    shipment.status = 'delivered';
    shipment.actualDelivery = event.timestamp;
  }

  shipments.set(shipmentId, shipment);

  return trackingEvent;
}

/**
 * Log condition reading
 */
export function logConditionReading(shipmentId: string, reading: Omit<ConditionReading, 'id' | 'withinRange'>): ConditionReading | null {
  const shipment = shipments.get(shipmentId);
  if (!shipment) return null;

  const thresholds = supplyChainConfig.alertThresholds;

  // Check if within range
  let withinRange = true;
  if (reading.temperature !== undefined) {
    withinRange = withinRange &&
      reading.temperature >= thresholds.temperatureMin &&
      reading.temperature <= thresholds.temperatureMax;
  }
  if (reading.humidity !== undefined) {
    withinRange = withinRange &&
      reading.humidity >= thresholds.humidityMin &&
      reading.humidity <= thresholds.humidityMax;
  }
  if (reading.shock !== undefined) {
    withinRange = withinRange && reading.shock <= thresholds.shockMax;
  }

  const fullReading: ConditionReading = {
    ...reading,
    id: `cond_${generateUUID()}`,
    withinRange
  };

  shipment.conditionsLog.push(fullReading);
  shipment.updatedAt = Date.now();
  shipments.set(shipmentId, shipment);

  return fullReading;
}

/**
 * Get shipment
 */
export function getShipment(shipmentId: string): Shipment | undefined {
  return shipments.get(shipmentId);
}

/**
 * Get shipment by product
 */
export function getShipmentsByProduct(productId: string): Shipment[] {
  return Array.from(shipments.values()).filter(s => s.productIds.includes(productId));
}

// ============================================================================
// RECALL MANAGEMENT
// ============================================================================

/**
 * Create recall notice
 */
export function createRecallNotice(params: {
  reason: string;
  severity: RecallNotice['severity'];
  affectedProducts: string[];
  affectedBatches: string[];
  regulatoryReference?: string;
}): RecallNotice {
  const recall: RecallNotice = {
    id: `recall_${generateUUID()}`,
    recallNumber: `RC-${Date.now().toString(36).toUpperCase()}`,
    reason: params.reason,
    severity: params.severity,
    affectedProducts: params.affectedProducts,
    affectedBatches: params.affectedBatches,
    issueDate: Date.now(),
    status: 'active',
    actions: [],
    regulatoryReference: params.regulatoryReference
  };

  recalls.set(recall.id, recall);

  // Update affected products
  for (const productId of params.affectedProducts) {
    const product = products.get(productId);
    if (product) {
      product.status = 'recalled';
      products.set(productId, product);
    }
  }

  // Also find products by batch
  for (const batchNumber of params.affectedBatches) {
    const batchProducts = getProductsByBatch(batchNumber);
    for (const product of batchProducts) {
      product.status = 'recalled';
      products.set(product.id, product);
    }
  }

  return recall;
}

/**
 * Add recall action
 */
export function addRecallAction(recallId: string, action: Omit<RecallAction, 'id'>): RecallAction | null {
  const recall = recalls.get(recallId);
  if (!recall) return null;

  const fullAction: RecallAction = {
    ...action,
    id: `action_${generateUUID()}`
  };

  recall.actions.push(fullAction);
  recalls.set(recallId, recall);

  return fullAction;
}

/**
 * Get active recalls
 */
export function getActiveRecalls(): RecallNotice[] {
  return Array.from(recalls.values()).filter(r => r.status === 'active');
}

/**
 * Check if product is recalled
 */
export function isProductRecalled(productId: string): { recalled: boolean; recall?: RecallNotice } {
  const product = products.get(productId);
  if (!product) return { recalled: false };

  if (product.status === 'recalled') {
    const recall = Array.from(recalls.values()).find(r =>
      r.status === 'active' &&
      (r.affectedProducts.includes(productId) || r.affectedBatches.includes(product.batchNumber))
    );
    return { recalled: true, recall };
  }

  return { recalled: false };
}

// ============================================================================
// AUTHENTICATION
// ============================================================================

/**
 * Authenticate product
 */
export function authenticateProduct(productId: string): {
  authentic: boolean;
  chainValid: boolean;
  recallStatus: { recalled: boolean; recall?: RecallNotice };
  custodyComplete: boolean;
  qualityStatus: 'verified' | 'failed' | 'unchecked';
  issues: string[];
} {
  const product = products.get(productId);
  if (!product) {
    return {
      authentic: false,
      chainValid: false,
      recallStatus: { recalled: false },
      custodyComplete: false,
      qualityStatus: 'unchecked',
      issues: ['Product not found']
    };
  }

  const chainVerification = verifyProductChain(productId);
  const recallStatus = isProductRecalled(productId);
  const custodyComplete = product.custodyChain.every(c => c.signature);
  const qualityStatus = product.qualityChecks.length > 0
    ? product.qualityChecks.every(q => q.result === 'pass') ? 'verified' : 'failed'
    : 'unchecked';

  const issues: string[] = [...chainVerification.issues];
  if (recallStatus.recalled) {
    issues.push('Product is under recall');
  }
  if (!custodyComplete) {
    issues.push('Incomplete custody chain signatures');
  }

  return {
    authentic: issues.length === 0,
    chainValid: chainVerification.valid,
    recallStatus,
    custodyComplete,
    qualityStatus,
    issues
  };
}

// ============================================================================
// STATISTICS
// ============================================================================

/**
 * Get system statistics
 */
export function getSystemStats(): {
  products: { total: number; byStatus: Record<string, number> };
  shipments: { total: number; byStatus: Record<string, number> };
  entities: { total: number; verified: number };
  recalls: { total: number; active: number };
  conditions: { totalReadings: number; outOfRange: number };
} {
  const allProducts = Array.from(products.values());
  const allShipments = Array.from(shipments.values());
  const allEntities = Array.from(entities.values());
  const allRecalls = Array.from(recalls.values());

  const productByStatus: Record<string, number> = {};
  for (const p of allProducts) {
    productByStatus[p.status] = (productByStatus[p.status] || 0) + 1;
  }

  const shipmentByStatus: Record<string, number> = {};
  for (const s of allShipments) {
    shipmentByStatus[s.status] = (shipmentByStatus[s.status] || 0) + 1;
  }

  const allReadings = allShipments.flatMap(s => s.conditionsLog);

  return {
    products: { total: allProducts.length, byStatus: productByStatus },
    shipments: { total: allShipments.length, byStatus: shipmentByStatus },
    entities: { total: allEntities.length, verified: allEntities.filter(e => e.verified).length },
    recalls: { total: allRecalls.length, active: allRecalls.filter(r => r.status === 'active').length },
    conditions: {
      totalReadings: allReadings.length,
      outOfRange: allReadings.filter(r => !r.withinRange).length
    }
  };
}

// ============================================================================
// TEST SUITE
// ============================================================================

/**
 * Run supply chain custody tests
 */
export function runSupplyChainCustodyTests(): {
  passed: boolean;
  tests: { total: number; passed: number; failed: number };
  results: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const results: Array<{ name: string; passed: boolean; error?: string }> = [];

  try {
    // Test 1: Register entity
    const manufacturer = registerEntity({
      id: 'mfr_1',
      name: 'Test Manufacturer',
      type: 'manufacturer',
      location: 'Factory City',
      country: 'US'
    });
    results.push({ name: 'Register Entity', passed: !!manufacturer.id });

    // Test 2: Verify entity
    const verifiedEntity = verifyEntity(manufacturer.id);
    results.push({ name: 'Verify Entity', passed: verifiedEntity?.verified === true });

    // Test 3: Register product
    const product = registerProduct({
      sku: 'SKU-001',
      name: 'Test Product',
      description: 'Test product description',
      category: 'electronics',
      manufacturer: {
        id: manufacturer.id,
        name: manufacturer.name,
        location: manufacturer.location,
        country: manufacturer.country,
        certifications: ['ISO 9001']
      },
      batchNumber: 'BATCH-2024-001',
      serialNumber: 'SN-001',
      manufacturingDate: Date.now(),
      initialLocation: {
        facility: 'Factory A',
        address: '123 Factory St',
        timestamp: Date.now()
      },
      initialHolder: manufacturer
    });
    results.push({ name: 'Register Product', passed: !!product.id && product.hashChain.length === 1 });

    // Test 4: Transfer custody
    const distributor = registerEntity({
      id: 'dist_1',
      name: 'Test Distributor',
      type: 'distributor',
      location: 'Warehouse City',
      country: 'US'
    });

    const transferred = transferCustody({
      productId: product.id,
      fromEntity: manufacturer,
      toEntity: distributor,
      location: {
        facility: 'Warehouse B',
        address: '456 Warehouse Ave',
        timestamp: Date.now()
      },
      handler: 'John Handler'
    });
    results.push({ name: 'Transfer Custody', passed: (transferred?.custodyChain.length || 0) === 2 });

    // Test 5: Verify chain
    const chainVerification = verifyProductChain(product.id);
    results.push({ name: 'Verify Chain', passed: chainVerification.valid && chainVerification.chainIntact });

    // Test 6: Quality check
    const qc = performQualityCheck({
      productId: product.id,
      type: 'incoming',
      inspector: 'Jane Inspector',
      items: [
        { name: 'Packaging intact', value: 'yes', expected: 'yes' },
        { name: 'Labels correct', value: 'yes', expected: 'yes' }
      ]
    });
    results.push({ name: 'Quality Check', passed: qc?.result === 'pass' });

    // Test 7: Create shipment
    const shipment = createShipment({
      productIds: [product.id],
      origin: product.currentLocation,
      destination: {
        facility: 'Retail Store',
        address: '789 Retail Blvd',
        timestamp: Date.now()
      },
      carrier: distributor,
      estimatedDelivery: Date.now() + 7 * 24 * 60 * 60 * 1000
    });
    results.push({ name: 'Create Shipment', passed: !!shipment.id });

    // Test 8: Log condition
    const condition = logConditionReading(shipment.id, {
      timestamp: Date.now(),
      temperature: 22,
      humidity: 50
    });
    results.push({ name: 'Log Condition', passed: condition?.withinRange === true });

    // Test 9: Tracking event
    const tracking = addTrackingEvent(shipment.id, {
      type: 'delivery',
      location: {
        facility: 'Retail Store',
        address: '789 Retail Blvd',
        timestamp: Date.now()
      },
      description: 'Delivered successfully'
    });
    results.push({ name: 'Add Tracking Event', passed: tracking?.type === 'delivery' });

    // Test 10: Create recall
    const recall = createRecallNotice({
      reason: 'Potential contamination',
      severity: 'high',
      affectedProducts: [],
      affectedBatches: ['BATCH-2024-001']
    });
    results.push({ name: 'Create Recall', passed: !!recall.id && recall.status === 'active' });

    // Test 11: Check recall status
    const recallStatus = isProductRecalled(product.id);
    results.push({ name: 'Check Recall Status', passed: recallStatus.recalled === true });

    // Test 12: Authenticate product
    const auth = authenticateProduct(product.id);
    results.push({ name: 'Authenticate Product', passed: auth.chainValid && auth.recallStatus.recalled });

  } catch (error) {
    results.push({ name: 'Test execution', passed: false, error: String(error) });
  }

  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;

  return {
    passed: failed === 0,
    tests: { total: results.length, passed, failed },
    results
  };
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

const supplyChainCustody = {
  // Configuration
  updateSupplyChainConfig,
  getSupplyChainConfig,
  // Entity management
  registerEntity,
  verifyEntity,
  getEntity,
  // Product management
  registerProduct,
  getProduct,
  getProductsByBatch,
  getProductBySerial,
  // Custody
  transferCustody,
  verifyProductChain,
  // Quality
  performQualityCheck,
  getQualityCheckHistory,
  // Shipment
  createShipment,
  addTrackingEvent,
  logConditionReading,
  getShipment,
  getShipmentsByProduct,
  // Recall
  createRecallNotice,
  addRecallAction,
  getActiveRecalls,
  isProductRecalled,
  // Authentication
  authenticateProduct,
  // Statistics
  getSystemStats,
  // Tests
  runSupplyChainCustodyTests
};

export default supplyChainCustody;
