/**
 * Brittleness Analyzer Module
 *
 * Detects over-reliance on single components/people/processes.
 * B(r) = usage / Σusage - identifies single points of failure.
 *
 * @module frontier/brittleness-analyzer
 * @version 9.0.0
 *
 * Capabilities:
 * - Brittleness calculation (B(r) formula)
 * - Single point of failure detection
 * - Dependency graph analysis
 * - Knowledge silo identification
 * - Resource concentration analysis
 * - Cascade failure prediction
 * - Resilience scoring
 * - Risk mitigation recommendations
 * - Capacity planning insights
 * - Organizational risk assessment
 */

import { generateUUID, sha256Hash } from '../crypto-utils';

// ============================================================================
// TYPES
// ============================================================================

/**
 * Resource entity (person, system, process, etc.)
 */
export interface Resource {
  /** Resource ID */
  id: string;
  /** Resource name */
  name: string;
  /** Resource type */
  type: 'person' | 'system' | 'process' | 'infrastructure' | 'vendor' | 'data' | 'skill' | 'tool' | 'service' | 'asset';
  /** Current utilization */
  utilization: number;
  /** Maximum capacity */
  maxCapacity: number;
  /** Utilization percentage */
  utilizationPercent: number;
  /** Dependencies */
  dependencies: string[];
  /** Dependents (who relies on this) */
  dependents: ResourceDependent[];
  /** Brittleness score */
  brittlenessScore: number;
  /** Risk level */
  riskLevel: 'minimal' | 'low' | 'moderate' | 'high' | 'critical';
  /** Redundancy status */
  redundancy: RedundancyStatus;
  /** Criticality */
  criticality: 'non_critical' | 'important' | 'critical' | 'mission_critical';
  /** Replacement difficulty */
  replacementDifficulty: 'easy' | 'moderate' | 'difficult' | 'very_difficult' | 'impossible';
  /** Time to replace (days) */
  timeToReplace: number;
  /** Cost to replace */
  costToReplace: number;
  /** Metadata */
  metadata: Record<string, unknown>;
  /** Last updated */
  updatedAt: number;
}

/**
 * Resource dependent
 */
export interface ResourceDependent {
  /** Dependent resource ID */
  resourceId: string;
  /** Resource name */
  name: string;
  /** Dependency weight (0-1) */
  weight: number;
  /** Type of dependency */
  type: 'essential' | 'important' | 'optional';
  /** Impact if resource fails */
  impactScore: number;
}

/**
 * Redundancy status
 */
export interface RedundancyStatus {
  /** Has redundancy */
  hasRedundancy: boolean;
  /** Number of backups */
  backupCount: number;
  /** Backup resource IDs */
  backups: string[];
  /** Failover capability */
  failoverCapable: boolean;
  /** Failover time (minutes) */
  failoverTime: number;
  /** Last tested */
  lastTested?: number;
}

/**
 * Brittleness assessment
 */
export interface BrittlenessAssessment {
  /** Assessment ID */
  id: string;
  /** System/process being assessed */
  systemId: string;
  /** Assessment timestamp */
  timestamp: number;
  /** Overall brittleness score (0-100) */
  overallBrittleness: number;
  /** Brittleness level */
  brittlenessLevel: 'resilient' | 'stable' | 'brittle' | 'fragile' | 'critical';
  /** Resource brittleness breakdown */
  resourceAnalysis: ResourceBrittlenessResult[];
  /** Single points of failure */
  singlePointsOfFailure: SinglePointOfFailure[];
  /** Dependency clusters */
  dependencyClusters: DependencyCluster[];
  /** Knowledge silos */
  knowledgeSilos: KnowledgeSilo[];
  /** Concentration risks */
  concentrationRisks: ConcentrationRisk[];
  /** Cascade failure paths */
  cascadePaths: CascadePath[];
  /** Resilience score */
  resilienceScore: number;
  /** Recommendations */
  recommendations: BrittlenessRecommendation[];
  /** Risk summary */
  riskSummary: RiskSummary;
}

/**
 * Resource brittleness result
 */
export interface ResourceBrittlenessResult {
  /** Resource ID */
  resourceId: string;
  /** Resource name */
  resourceName: string;
  /** Resource type */
  resourceType: Resource['type'];
  /** Brittleness score B(r) = usage / Σusage */
  brittlenessScore: number;
  /** Usage value */
  usage: number;
  /** Total usage */
  totalUsage: number;
  /** Contribution percentage */
  contributionPercent: number;
  /** Risk level */
  riskLevel: Resource['riskLevel'];
  /** Is single point of failure */
  isSPOF: boolean;
  /** Impact score */
  impactScore: number;
  /** Affected dependents count */
  affectedDependents: number;
}

/**
 * Single point of failure
 */
export interface SinglePointOfFailure {
  /** SPOF ID */
  id: string;
  /** Resource ID */
  resourceId: string;
  /** Resource name */
  resourceName: string;
  /** SPOF type */
  type: 'absolute' | 'critical' | 'significant';
  /** Brittleness score */
  brittlenessScore: number;
  /** Impact description */
  impact: string;
  /** Affected resources */
  affectedResources: string[];
  /** Affected processes */
  affectedProcesses: string[];
  /** Potential loss (estimated) */
  potentialLoss: number;
  /** Mitigation strategies */
  mitigations: string[];
  /** Priority */
  priority: 'immediate' | 'high' | 'medium' | 'low';
}

/**
 * Dependency cluster
 */
export interface DependencyCluster {
  /** Cluster ID */
  id: string;
  /** Cluster name */
  name: string;
  /** Resources in cluster */
  resources: string[];
  /** Cluster brittleness */
  brittlenessScore: number;
  /** Interdependency level */
  interdependencyLevel: 'loose' | 'moderate' | 'tight' | 'circular';
  /** Risk level */
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  /** Cluster type */
  type: 'hub_spoke' | 'mesh' | 'chain' | 'tree' | 'circular';
  /** Central resource (if hub-spoke) */
  centralResource?: string;
}

/**
 * Knowledge silo
 */
export interface KnowledgeSilo {
  /** Silo ID */
  id: string;
  /** Silo name */
  name: string;
  /** Knowledge holder */
  holder: {
    id: string;
    name: string;
    type: 'person' | 'team' | 'system';
  };
  /** Knowledge domains */
  domains: string[];
  /** Criticality */
  criticality: 'low' | 'medium' | 'high' | 'critical';
  /** Coverage percentage */
  coveragePercent: number;
  /** Impact if lost */
  impactDescription: string;
  /** Documentation status */
  documentationStatus: 'none' | 'partial' | 'complete' | 'verified';
  /** Risk of loss (turnover, etc.) */
  lossRisk: number;
  /** Mitigation status */
  mitigationStatus: 'none' | 'in_progress' | 'mitigated';
}

/**
 * Concentration risk
 */
export interface ConcentrationRisk {
  /** Risk ID */
  id: string;
  /** Risk type */
  type: 'vendor' | 'person' | 'system' | 'location' | 'technology' | 'process';
  /** Concentrated entity */
  entity: {
    id: string;
    name: string;
  };
  /** Concentration percentage */
  concentrationPercent: number;
  /** Threshold breached */
  thresholdBreached: boolean;
  /** Safe threshold */
  safeThreshold: number;
  /** Risk description */
  description: string;
  /** Potential impact */
  potentialImpact: string;
  /** Affected areas */
  affectedAreas: string[];
  /** Diversification needed */
  diversificationNeeded: number;
}

/**
 * Cascade path
 */
export interface CascadePath {
  /** Path ID */
  id: string;
  /** Starting resource */
  startResource: string;
  /** Path sequence */
  path: Array<{
    resourceId: string;
    resourceName: string;
    failureProbability: number;
    impactScore: number;
  }>;
  /** Total cascade probability */
  cascadeProbability: number;
  /** Total impact score */
  totalImpact: number;
  /** Path length */
  length: number;
  /** Estimated time to cascade failure (minutes) */
  estimatedTime: number;
  /** Prevention points */
  preventionPoints: string[];
}

/**
 * Brittleness recommendation
 */
export interface BrittlenessRecommendation {
  /** Recommendation ID */
  id: string;
  /** Priority */
  priority: 'critical' | 'high' | 'medium' | 'low';
  /** Type */
  type: 'redundancy' | 'documentation' | 'cross_training' | 'backup' | 'diversification' | 'monitoring' | 'process';
  /** Affected resources */
  resourceIds: string[];
  /** Description */
  description: string;
  /** Rationale */
  rationale: string;
  /** Estimated effort (hours) */
  estimatedEffort: number;
  /** Estimated cost */
  estimatedCost: number;
  /** Expected impact */
  expectedImpact: number;
  /** Deadline */
  deadline: number;
  /** Implementation steps */
  steps: string[];
}

/**
 * Risk summary
 */
export interface RiskSummary {
  /** Overall risk score */
  riskScore: number;
  /** Risk level */
  riskLevel: 'minimal' | 'low' | 'moderate' | 'high' | 'critical' | 'extreme';
  /** SPOF count */
  spofCount: number;
  /** Critical SPOF count */
  criticalSpofCount: number;
  /** Knowledge silo count */
  siloCount: number;
  /** High concentration count */
  highConcentrationCount: number;
  /** Cascade risk probability */
  cascadeRiskProbability: number;
  /** Estimated recovery time (hours) */
  estimatedRecoveryTime: number;
  /** Risk trend */
  trend: 'improving' | 'stable' | 'degrading';
}

/**
 * System configuration
 */
export interface SystemConfig {
  /** System ID */
  id: string;
  /** System name */
  name: string;
  /** System type */
  type: 'organization' | 'process' | 'infrastructure' | 'supply_chain' | 'manufacturing' | 'it_system' | 'project';
  /** Brittleness thresholds */
  thresholds: {
    warning: number;
    critical: number;
    fragile: number;
  };
  /** Concentration thresholds */
  concentrationThresholds: {
    person: number;
    vendor: number;
    system: number;
    location: number;
  };
  /** Assessment interval (hours) */
  assessmentInterval: number;
}

// ============================================================================
// STORAGE
// ============================================================================

const systems = new Map<string, SystemConfig>();
const resources = new Map<string, Resource>();
const assessments = new Map<string, BrittlenessAssessment>();

// Default thresholds
const DEFAULT_THRESHOLDS = {
  brittleness: { warning: 30, critical: 50, fragile: 70 },
  concentration: { person: 50, vendor: 40, system: 60, location: 70 }
};

// ============================================================================
// SYSTEM MANAGEMENT
// ============================================================================

/**
 * Create system configuration
 */
export function createSystem(config: Omit<SystemConfig, 'id'>): SystemConfig {
  const system: SystemConfig = {
    ...config,
    id: `system_${generateUUID()}`
  };

  systems.set(system.id, system);
  return system;
}

/**
 * Get system
 */
export function getSystem(systemId: string): SystemConfig | undefined {
  return systems.get(systemId);
}

/**
 * List systems
 */
export function listSystems(type?: SystemConfig['type']): SystemConfig[] {
  const all = Array.from(systems.values());
  return type ? all.filter(s => s.type === type) : all;
}

// ============================================================================
// RESOURCE MANAGEMENT
// ============================================================================

/**
 * Register resource
 */
export function registerResource(config: Omit<Resource, 'id' | 'updatedAt' | 'brittlenessScore' | 'riskLevel' | 'utilizationPercent'>): Resource {
  const id = `resource_${generateUUID()}`;
  const utilizationPercent = config.maxCapacity > 0 ? (config.utilization / config.maxCapacity) * 100 : 0;

  const resource: Resource = {
    ...config,
    id,
    utilizationPercent,
    brittlenessScore: 0, // Will be calculated
    riskLevel: 'minimal', // Will be determined
    updatedAt: Date.now()
  };

  resources.set(id, resource);
  return resource;
}

/**
 * Get resource
 */
export function getResource(resourceId: string): Resource | undefined {
  return resources.get(resourceId);
}

/**
 * Update resource utilization
 */
export function updateResourceUtilization(resourceId: string, utilization: number): Resource | null {
  const resource = resources.get(resourceId);
  if (!resource) return null;

  resource.utilization = utilization;
  resource.utilizationPercent = resource.maxCapacity > 0 ? (utilization / resource.maxCapacity) * 100 : 0;
  resource.updatedAt = Date.now();

  resources.set(resourceId, resource);
  return resource;
}

/**
 * Add dependent to resource
 */
export function addDependent(resourceId: string, dependent: Omit<ResourceDependent, 'impactScore'>): Resource | null {
  const resource = resources.get(resourceId);
  if (!resource) return null;

  const impactScore = calculateDependentImpact(dependent.weight, dependent.type);
  resource.dependents.push({ ...dependent, impactScore });
  resource.updatedAt = Date.now();

  resources.set(resourceId, resource);
  return resource;
}

/**
 * Calculate dependent impact score
 */
function calculateDependentImpact(weight: number, type: ResourceDependent['type']): number {
  const typeMultiplier: Record<string, number> = {
    'essential': 1.0,
    'important': 0.6,
    'optional': 0.2
  };
  return weight * typeMultiplier[type] * 100;
}

/**
 * List resources
 */
export function listResources(type?: Resource['type']): Resource[] {
  const all = Array.from(resources.values());
  return type ? all.filter(r => r.type === type) : all;
}

// ============================================================================
// BRITTLENESS CALCULATION
// ============================================================================

/**
 * Calculate brittleness score B(r)
 * 
 * Formula: B(r) = usage(r) / Σusage(all resources in category)
 * 
 * Higher score = more brittle = higher risk
 * B(r) > 0.5 indicates potential single point of failure
 */
export function calculateBrittlenessScore(
  resourceId: string,
  resourceType: Resource['type']
): number {
  const resource = resources.get(resourceId);
  if (!resource) return 0;

  // Get all resources of same type
  const sameTypeResources = Array.from(resources.values())
    .filter(r => r.type === resourceType);

  // Calculate total usage (based on utilization * dependent weight)
  const totalUsage = sameTypeResources.reduce((sum, r) => {
    const dependentWeight = r.dependents.reduce((s, d) => s + d.weight, 0);
    return sum + r.utilization * (1 + dependentWeight);
  }, 0);

  if (totalUsage === 0) return 0;

  // Calculate this resource's usage
  const resourceUsage = resource.utilization * (1 + resource.dependents.reduce((s, d) => s + d.weight, 0));

  // B(r) = usage(r) / total_usage
  return Math.min(1, resourceUsage / totalUsage);
}

/**
 * Determine risk level from brittleness score
 */
export function determineRiskLevel(brittlenessScore: number): Resource['riskLevel'] {
  if (brittlenessScore >= 0.8) return 'critical';
  if (brittlenessScore >= 0.6) return 'high';
  if (brittlenessScore >= 0.4) return 'moderate';
  if (brittlenessScore >= 0.2) return 'low';
  return 'minimal';
}

/**
 * Check if resource is single point of failure
 */
export function isSinglePointOfFailure(resource: Resource): boolean {
  // SPOF conditions:
  // 1. High brittleness score (> 0.5)
  // 2. No redundancy
  // 3. Has dependents
  return (
    resource.brittlenessScore > 0.5 &&
    !resource.redundancy.hasRedundancy &&
    resource.dependents.length > 0
  );
}

// ============================================================================
// BRITTLENESS ASSESSMENT
// ============================================================================

/**
 * Run brittleness assessment
 */
export function runBrittlenessAssessment(systemId: string): BrittlenessAssessment {
  const system = systems.get(systemId);
  if (!system) {
    throw new Error('System not found');
  }

  const id = `assessment_${generateUUID()}`;
  const now = Date.now();

  // Get all resources for this system
  const systemResources = Array.from(resources.values());

  // Update brittleness scores for all resources
  for (const resource of systemResources) {
    resource.brittlenessScore = calculateBrittlenessScore(resource.id, resource.type);
    resource.riskLevel = determineRiskLevel(resource.brittlenessScore);
    resources.set(resource.id, resource);
  }

  // Calculate resource analysis
  const resourceAnalysis = calculateResourceAnalysis(systemResources);

  // Identify single points of failure
  const singlePointsOfFailure = identifySPOFs(systemResources);

  // Analyze dependency clusters
  const dependencyClusters = analyzeDependencyClusters(systemResources);

  // Identify knowledge silos
  const knowledgeSilos = identifyKnowledgeSilos(systemResources);

  // Check concentration risks
  const concentrationRisks = checkConcentrationRisks(systemResources, system.concentrationThresholds);

  // Calculate cascade paths
  const cascadePaths = calculateCascadePaths(systemResources);

  // Calculate overall brittleness
  const overallBrittleness = calculateOverallBrittleness(resourceAnalysis);

  // Determine brittleness level
  const brittlenessLevel = determineBrittlenessLevel(overallBrittleness, system.thresholds);

  // Calculate resilience score (inverse of brittleness)
  const resilienceScore = 100 - overallBrittleness;

  // Generate recommendations
  const recommendations = generateBrittlenessRecommendations(
    singlePointsOfFailure,
    knowledgeSilos,
    concentrationRisks,
    cascadePaths
  );

  // Generate risk summary
  const riskSummary = generateRiskSummary(
    singlePointsOfFailure,
    knowledgeSilos,
    concentrationRisks,
    cascadePaths,
    overallBrittleness
  );

  const assessment: BrittlenessAssessment = {
    id,
    systemId,
    timestamp: now,
    overallBrittleness,
    brittlenessLevel,
    resourceAnalysis,
    singlePointsOfFailure,
    dependencyClusters,
    knowledgeSilos,
    concentrationRisks,
    cascadePaths,
    resilienceScore,
    recommendations,
    riskSummary
  };

  assessments.set(id, assessment);
  return assessment;
}

/**
 * Calculate resource analysis
 */
function calculateResourceAnalysis(allResources: Resource[]): ResourceBrittlenessResult[] {
  // Calculate total usage per type
  const usageByType = new Map<Resource['type'], number>();

  for (const resource of allResources) {
    const current = usageByType.get(resource.type) || 0;
    const usage = resource.utilization * (1 + resource.dependents.reduce((s, d) => s + d.weight, 0));
    usageByType.set(resource.type, current + usage);
  }

  return allResources.map(resource => {
    const totalUsage = usageByType.get(resource.type) || 1;
    const usage = resource.utilization * (1 + resource.dependents.reduce((s, d) => s + d.weight, 0));
    const contributionPercent = (usage / totalUsage) * 100;

    return {
      resourceId: resource.id,
      resourceName: resource.name,
      resourceType: resource.type,
      brittlenessScore: resource.brittlenessScore,
      usage,
      totalUsage,
      contributionPercent,
      riskLevel: resource.riskLevel,
      isSPOF: isSinglePointOfFailure(resource),
      impactScore: resource.dependents.reduce((sum, d) => sum + d.impactScore, 0),
      affectedDependents: resource.dependents.length
    };
  });
}

/**
 * Identify single points of failure
 */
function identifySPOFs(allResources: Resource[]): SinglePointOfFailure[] {
  const spofs: SinglePointOfFailure[] = [];

  for (const resource of allResources) {
    if (resource.brittlenessScore > 0.5 && resource.dependents.length > 0) {
      let type: SinglePointOfFailure['type'] = 'significant';
      if (resource.brittlenessScore > 0.8 && !resource.redundancy.hasRedundancy) {
        type = 'absolute';
      } else if (resource.brittlenessScore > 0.6 || resource.criticality === 'mission_critical') {
        type = 'critical';
      }

      spofs.push({
        id: `spof_${generateUUID()}`,
        resourceId: resource.id,
        resourceName: resource.name,
        type,
        brittlenessScore: resource.brittlenessScore,
        impact: `Failure would impact ${resource.dependents.length} dependent resources`,
        affectedResources: resource.dependents.map(d => d.resourceId),
        affectedProcesses: resource.dependents.map(d => d.name),
        potentialLoss: calculatePotentialLoss(resource),
        mitigations: generateSPOFMitigations(resource),
        priority: resource.brittlenessScore > 0.8 ? 'immediate' : 
                  resource.brittlenessScore > 0.6 ? 'high' : 'medium'
      });
    }
  }

  return spofs.sort((a, b) => b.brittlenessScore - a.brittlenessScore);
}

/**
 * Calculate potential loss from resource failure
 */
function calculatePotentialLoss(resource: Resource): number {
  const dependentLoss = resource.dependents.reduce((sum, d) => {
    return sum + d.impactScore * 1000; // Base cost per impact point
  }, 0);

  const replacementCost = resource.costToReplace;
  const downtimeCost = resource.timeToReplace * 500; // Cost per day of downtime

  return dependentLoss + replacementCost + downtimeCost;
}

/**
 * Generate SPOF mitigations
 */
function generateSPOFMitigations(resource: Resource): string[] {
  const mitigations: string[] = [];

  if (!resource.redundancy.hasRedundancy) {
    mitigations.push('Implement redundant backup resource');
  }
  if (resource.type === 'person') {
    mitigations.push('Cross-train additional team members');
    mitigations.push('Document critical knowledge');
  }
  if (resource.type === 'system' || resource.type === 'service') {
    mitigations.push('Implement failover mechanism');
    mitigations.push('Create disaster recovery plan');
  }
  if (resource.documentationStatus === 'none') {
    mitigations.push('Create comprehensive documentation');
  }

  return mitigations;
}

/**
 * Analyze dependency clusters
 */
function analyzeDependencyClusters(allResources: Resource[]): DependencyCluster[] {
  const clusters: DependencyCluster[] = [];
  const processed = new Set<string>();

  for (const resource of allResources) {
    if (processed.has(resource.id)) continue;

    // Find connected resources (dependencies and dependents)
    const clusterResources = findConnectedResources(resource.id, allResources);
    clusterResources.forEach(id => processed.add(id));

    if (clusterResources.length > 1) {
      const clusterType = determineClusterType(clusterResources, allResources);
      const centralResource = findCentralResource(clusterResources, allResources);

      clusters.push({
        id: `cluster_${generateUUID()}`,
        name: `Dependency Cluster ${clusters.length + 1}`,
        resources: Array.from(clusterResources),
        brittlenessScore: calculateClusterBrittleness(clusterResources, allResources),
        interdependencyLevel: determineInterdependencyLevel(clusterResources, allResources),
        riskLevel: determineClusterRiskLevel(clusterResources, allResources),
        type: clusterType,
        centralResource
      });
    }
  }

  return clusters;
}

/**
 * Find connected resources
 */
function findConnectedResources(resourceId: string, allResources: Resource[]): Set<string> {
  const connected = new Set<string>();
  const queue = [resourceId];

  while (queue.length > 0) {
    const currentId = queue.shift()!;
    if (connected.has(currentId)) continue;

    connected.add(currentId);
    const resource = allResources.find(r => r.id === currentId);
    if (!resource) continue;

    // Add dependencies
    for (const depId of resource.dependencies) {
      if (!connected.has(depId)) {
        queue.push(depId);
      }
    }

    // Add dependents
    for (const dep of resource.dependents) {
      if (!connected.has(dep.resourceId)) {
        queue.push(dep.resourceId);
      }
    }
  }

  return connected;
}

/**
 * Determine cluster type
 */
function determineClusterType(clusterResources: Set<string>, allResources: Resource[]): DependencyCluster['type'] {
  // Check for hub-spoke pattern
  const centralResource = findCentralResource(clusterResources, allResources);
  if (centralResource) {
    const central = allResources.find(r => r.id === centralResource);
    if (central && central.dependents.length > clusterResources.size * 0.5) {
      return 'hub_spoke';
    }
  }

  // Check for circular dependencies
  if (hasCircularDependency(clusterResources, allResources)) {
    return 'circular';
  }

  // Check for chain pattern
  if (isChainPattern(clusterResources, allResources)) {
    return 'chain';
  }

  // Default to mesh
  return 'mesh';
}

/**
 * Find central resource in cluster
 */
function findCentralResource(clusterResources: Set<string>, allResources: Resource[]): string | undefined {
  let maxConnections = 0;
  let centralId: string | undefined;

  for (const resourceId of clusterResources) {
    const resource = allResources.find(r => r.id === resourceId);
    if (!resource) continue;

    const connections = resource.dependencies.length + resource.dependents.length;
    if (connections > maxConnections) {
      maxConnections = connections;
      centralId = resourceId;
    }
  }

  return centralId;
}

/**
 * Check for circular dependencies
 */
function hasCircularDependency(clusterResources: Set<string>, allResources: Resource[]): boolean {
  const visited = new Set<string>();
  const recursionStack = new Set<string>();

  function hasCycle(resourceId: string): boolean {
    if (recursionStack.has(resourceId)) return true;
    if (visited.has(resourceId)) return false;

    visited.add(resourceId);
    recursionStack.add(resourceId);

    const resource = allResources.find(r => r.id === resourceId);
    if (resource) {
      for (const depId of resource.dependencies) {
        if (clusterResources.has(depId) && hasCycle(depId)) {
          return true;
        }
      }
    }

    recursionStack.delete(resourceId);
    return false;
  }

  for (const resourceId of clusterResources) {
    if (hasCycle(resourceId)) return true;
  }

  return false;
}

/**
 * Check if cluster forms a chain pattern
 */
function isChainPattern(clusterResources: Set<string>, allResources: Resource[]): boolean {
  let startNodes = 0;
  let endNodes = 0;

  for (const resourceId of clusterResources) {
    const resource = allResources.find(r => r.id === resourceId);
    if (!resource) continue;

    const inClusterDeps = resource.dependencies.filter(d => clusterResources.has(d)).length;
    const inClusterDependents = resource.dependents.filter(d => clusterResources.has(d.resourceId)).length;

    if (inClusterDeps === 0) startNodes++;
    if (inClusterDependents === 0) endNodes++;
  }

  return startNodes === 1 && endNodes === 1;
}

/**
 * Calculate cluster brittleness
 */
function calculateClusterBrittleness(clusterResources: Set<string>, allResources: Resource[]): number {
  let totalBrittleness = 0;
  let count = 0;

  for (const resourceId of clusterResources) {
    const resource = allResources.find(r => r.id === resourceId);
    if (resource) {
      totalBrittleness += resource.brittlenessScore;
      count++;
    }
  }

  return count > 0 ? totalBrittleness / count : 0;
}

/**
 * Determine interdependency level
 */
function determineInterdependencyLevel(clusterResources: Set<string>, allResources: Resource[]): DependencyCluster['interdependencyLevel'] {
  let totalConnections = 0;

  for (const resourceId of clusterResources) {
    const resource = allResources.find(r => r.id === resourceId);
    if (resource) {
      totalConnections += resource.dependencies.filter(d => clusterResources.has(d)).length;
      totalConnections += resource.dependents.filter(d => clusterResources.has(d.resourceId)).length;
    }
  }

  const avgConnections = totalConnections / clusterResources.size;

  if (avgConnections >= 4) return 'tight';
  if (avgConnections >= 2) return 'moderate';
  return 'loose';
}

/**
 * Determine cluster risk level
 */
function determineClusterRiskLevel(clusterResources: Set<string>, allResources: Resource[]): DependencyCluster['riskLevel'] {
  const avgBrittleness = calculateClusterBrittleness(clusterResources, allResources);
  const hasCircular = hasCircularDependency(clusterResources, allResources);

  if (hasCircular || avgBrittleness > 0.7) return 'critical';
  if (avgBrittleness > 0.5) return 'high';
  if (avgBrittleness > 0.3) return 'medium';
  return 'low';
}

/**
 * Identify knowledge silos
 */
function identifyKnowledgeSilos(allResources: Resource[]): KnowledgeSilo[] {
  const silos: KnowledgeSilo[] = [];

  // Find people with high brittleness scores (knowledge concentration)
  const people = allResources.filter(r => r.type === 'person');

  for (const person of people) {
    if (person.brittlenessScore > 0.3 && person.dependents.length > 0) {
      // Check documentation status from metadata
      const docStatus = (person.metadata.documentationStatus as KnowledgeSilo['documentationStatus']) || 'none';
      const domains = (person.metadata.knowledgeDomains as string[]) || ['General'];

      silos.push({
        id: `silo_${generateUUID()}`,
        name: `${person.name} Knowledge Silo`,
        holder: {
          id: person.id,
          name: person.name,
          type: 'person'
        },
        domains,
        criticality: person.brittlenessScore > 0.6 ? 'critical' : 
                      person.brittlenessScore > 0.4 ? 'high' : 'medium',
        coveragePercent: person.brittlenessScore * 100,
        impactDescription: `Loss of ${person.name} would impact ${person.dependents.length} processes`,
        documentationStatus: docStatus,
        lossRisk: person.brittlenessScore * 100,
        mitigationStatus: docStatus === 'complete' || docStatus === 'verified' ? 'mitigated' : 
                          docStatus === 'partial' ? 'in_progress' : 'none'
      });
    }
  }

  return silos.sort((a, b) => b.coveragePercent - a.coveragePercent);
}

/**
 * Check concentration risks
 */
function checkConcentrationRisks(
  allResources: Resource[],
  thresholds: SystemConfig['concentrationThresholds']
): ConcentrationRisk[] {
  const risks: ConcentrationRisk[] = [];

  // Group by type
  const byType = new Map<Resource['type'], Resource[]>();
  for (const resource of allResources) {
    const existing = byType.get(resource.type) || [];
    existing.push(resource);
    byType.set(resource.type, existing);
  }

  // Check each type for concentration
  for (const [type, resources] of byType) {
    const totalUsage = resources.reduce((sum, r) => sum + r.utilization, 0);

    for (const resource of resources) {
      const concentrationPercent = totalUsage > 0 ? (resource.utilization / totalUsage) * 100 : 0;
      const threshold = thresholds[type as keyof typeof thresholds] || 50;

      if (concentrationPercent > threshold) {
        risks.push({
          id: `risk_${generateUUID()}`,
          type: type as ConcentrationRisk['type'],
          entity: {
            id: resource.id,
            name: resource.name
          },
          concentrationPercent,
          thresholdBreached: true,
          safeThreshold: threshold,
          description: `${resource.name} handles ${concentrationPercent.toFixed(1)}% of ${type} capacity`,
          potentialImpact: `Failure would reduce ${type} capacity by ${concentrationPercent.toFixed(1)}%`,
          affectedAreas: resource.dependents.map(d => d.name),
          diversificationNeeded: concentrationPercent - threshold
        });
      }
    }
  }

  return risks.sort((a, b) => b.concentrationPercent - a.concentrationPercent);
}

/**
 * Calculate cascade paths
 */
function calculateCascadePaths(allResources: Resource[]): CascadePath[] {
  const paths: CascadePath[] = [];

  // Find high-brittleness resources with dependencies
  const startPoints = allResources.filter(r => 
    r.brittlenessScore > 0.5 && 
    r.dependents.length > 0 &&
    !r.redundancy.hasRedundancy
  );

  for (const start of startPoints.slice(0, 10)) { // Limit to top 10
    const path = traceCascadePath(start, allResources);
    if (path.length > 1) {
      paths.push({
        id: `cascade_${generateUUID()}`,
        startResource: start.id,
        path,
        cascadeProbability: calculateCascadeProbability(path),
        totalImpact: path.reduce((sum, p) => sum + p.impactScore, 0),
        length: path.length,
        estimatedTime: path.length * 15, // 15 min per hop
        preventionPoints: identifyPreventionPoints(path, allResources)
      });
    }
  }

  return paths.sort((a, b) => b.cascadeProbability - a.cascadeProbability);
}

/**
 * Trace cascade path from starting resource
 */
function traceCascadePath(start: Resource, allResources: Resource[]): CascadePath['path'] {
  const path: CascadePath['path'] = [];
  const visited = new Set<string>();
  const queue: Array<{ resource: Resource; probability: number }> = [{ resource: start, probability: 1 }];

  while (queue.length > 0 && path.length < 10) {
    const { resource, probability } = queue.shift()!;
    if (visited.has(resource.id)) continue;
    visited.add(resource.id);

    path.push({
      resourceId: resource.id,
      resourceName: resource.name,
      failureProbability: probability * resource.brittlenessScore,
      impactScore: resource.dependents.reduce((sum, d) => sum + d.impactScore, 0)
    });

    // Add dependents to queue with reduced probability
    for (const dependent of resource.dependents) {
      const depResource = allResources.find(r => r.id === dependent.resourceId);
      if (depResource && !visited.has(depResource.id)) {
        queue.push({
          resource: depResource,
          probability: probability * dependent.weight
        });
      }
    }
  }

  return path;
}

/**
 * Calculate cascade probability
 */
function calculateCascadeProbability(path: CascadePath['path']): number {
  if (path.length === 0) return 0;

  // Probability compounds along the path
  let probability = 1;
  for (const node of path) {
    probability *= (1 - node.failureProbability * 0.5); // Dampening factor
  }
  return (1 - probability) * 100;
}

/**
 * Identify prevention points
 */
function identifyPreventionPoints(path: CascadePath['path'], allResources: Resource[]): string[] {
  const preventionPoints: string[] = [];

  for (const node of path) {
    const resource = allResources.find(r => r.id === node.resourceId);
    if (resource && resource.redundancy.hasRedundancy) {
      preventionPoints.push(`${resource.name}: Has redundancy`);
    }
    if (resource && resource.redundancy.failoverCapable) {
      preventionPoints.push(`${resource.name}: Failover capable`);
    }
  }

  return preventionPoints;
}

/**
 * Calculate overall brittleness
 */
function calculateOverallBrittleness(resourceAnalysis: ResourceBrittlenessResult[]): number {
  if (resourceAnalysis.length === 0) return 0;

  // Weighted average of brittleness scores
  const totalImpact = resourceAnalysis.reduce((sum, r) => sum + r.impactScore, 0);
  if (totalImpact === 0) return 0;

  const weightedSum = resourceAnalysis.reduce((sum, r) => {
    return sum + (r.brittlenessScore * r.impactScore);
  }, 0);

  return (weightedSum / totalImpact) * 100;
}

/**
 * Determine brittleness level
 */
function determineBrittlenessLevel(
  overallBrittleness: number,
  thresholds: SystemConfig['thresholds']
): BrittlenessAssessment['brittlenessLevel'] {
  if (overallBrittleness >= thresholds.fragile) return 'fragile';
  if (overallBrittleness >= thresholds.critical) return 'critical';
  if (overallBrittleness >= thresholds.warning) return 'brittle';
  if (overallBrittleness >= 20) return 'stable';
  return 'resilient';
}

/**
 * Generate brittleness recommendations
 */
function generateBrittlenessRecommendations(
  spofs: SinglePointOfFailure[],
  silos: KnowledgeSilo[],
  concentrations: ConcentrationRisk[],
  cascades: CascadePath[]
): BrittlenessRecommendation[] {
  const recommendations: BrittlenessRecommendation[] = [];

  // SPOF recommendations
  for (const spof of spofs.slice(0, 5)) {
    recommendations.push({
      id: `rec_${generateUUID()}`,
      priority: spof.priority === 'immediate' ? 'critical' : 
                spof.priority === 'high' ? 'high' : 'medium',
      type: 'redundancy',
      resourceIds: [spof.resourceId, ...spof.affectedResources],
      description: `Address SPOF: ${spof.resourceName}`,
      rationale: spof.impact,
      estimatedEffort: spof.type === 'absolute' ? 80 : 40,
      estimatedCost: spof.potentialLoss * 0.1,
      expectedImpact: spof.brittlenessScore * 50,
      deadline: Date.now() + (spof.priority === 'immediate' ? 7 : 30) * 24 * 60 * 60 * 1000,
      steps: spof.mitigations
    });
  }

  // Knowledge silo recommendations
  for (const silo of silos.filter(s => s.criticality === 'critical').slice(0, 3)) {
    recommendations.push({
      id: `rec_${generateUUID()}`,
      priority: 'high',
      type: 'cross_training',
      resourceIds: [silo.holder.id],
      description: `Mitigate knowledge silo: ${silo.name}`,
      rationale: `Risk of knowledge loss: ${silo.lossRisk.toFixed(0)}%`,
      estimatedEffort: 40,
      estimatedCost: 10000,
      expectedImpact: silo.coveragePercent,
      deadline: Date.now() + 60 * 24 * 60 * 60 * 1000,
      steps: [
        'Document critical processes',
        'Cross-train backup personnel',
        'Create runbooks and playbooks',
        'Schedule knowledge transfer sessions'
      ]
    });
  }

  // Concentration risk recommendations
  for (const concentration of concentrations.slice(0, 3)) {
    recommendations.push({
      id: `rec_${generateUUID()}`,
      priority: 'medium',
      type: 'diversification',
      resourceIds: [concentration.entity.id],
      description: `Reduce concentration: ${concentration.entity.name}`,
      rationale: concentration.description,
      estimatedEffort: concentration.diversificationNeeded * 2,
      estimatedCost: concentration.diversificationNeeded * 1000,
      expectedImpact: concentration.diversificationNeeded,
      deadline: Date.now() + 90 * 24 * 60 * 60 * 1000,
      steps: [
        'Identify alternative resources',
        'Gradually migrate workload',
        'Monitor distribution balance'
      ]
    });
  }

  return recommendations.sort((a, b) => {
    const priorityOrder: Record<string, number> = {
      'critical': 0, 'high': 1, 'medium': 2, 'low': 3
    };
    return priorityOrder[a.priority] - priorityOrder[b.priority];
  });
}

/**
 * Generate risk summary
 */
function generateRiskSummary(
  spofs: SinglePointOfFailure[],
  silos: KnowledgeSilo[],
  concentrations: ConcentrationRisk[],
  cascades: CascadePath[],
  overallBrittleness: number
): RiskSummary {
  const criticalSpofs = spofs.filter(s => s.type === 'absolute' || s.type === 'critical');
  const criticalSilos = silos.filter(s => s.criticality === 'critical');
  const highConcentrations = concentrations.filter(c => c.concentrationPercent > 70);

  const riskScore = Math.min(100,
    (spofs.length * 10) +
    (criticalSpofs.length * 20) +
    (criticalSilos.length * 15) +
    (highConcentrations.length * 10) +
    overallBrittleness
  );

  let riskLevel: RiskSummary['riskLevel'] = 'minimal';
  if (riskScore >= 80) riskLevel = 'extreme';
  else if (riskScore >= 60) riskLevel = 'critical';
  else if (riskScore >= 40) riskLevel = 'high';
  else if (riskScore >= 20) riskLevel = 'moderate';
  else if (riskScore >= 10) riskLevel = 'low';

  const cascadeRiskProbability = cascades.length > 0
    ? Math.max(...cascades.map(c => c.cascadeProbability))
    : 0;

  return {
    riskScore,
    riskLevel,
    spofCount: spofs.length,
    criticalSpofCount: criticalSpofs.length,
    siloCount: silos.length,
    highConcentrationCount: highConcentrations.length,
    cascadeRiskProbability,
    estimatedRecoveryTime: spofs.reduce((sum, s) => sum + 24, 0), // 24 hours per SPOF
    trend: 'stable'
  };
}

// ============================================================================
// ASSESSMENT QUERIES
// ============================================================================

/**
 * Get assessment
 */
export function getAssessment(assessmentId: string): BrittlenessAssessment | undefined {
  return assessments.get(assessmentId);
}

/**
 * Get latest assessment for system
 */
export function getLatestAssessment(systemId: string): BrittlenessAssessment | undefined {
  const systemAssessments = Array.from(assessments.values())
    .filter(a => a.systemId === systemId)
    .sort((a, b) => b.timestamp - a.timestamp);

  return systemAssessments[0];
}

// ============================================================================
// STATISTICS
// ============================================================================

/**
 * Get system statistics
 */
export function getSystemStats(): {
  systems: { total: number; byType: Record<string, number> };
  resources: { total: number; byType: Record<string, number>; avgBrittleness: number };
  assessments: { total: number; avgBrittleness: number };
  spofs: { total: number; critical: number };
} {
  const allSystems = Array.from(systems.values());
  const allResources = Array.from(resources.values());
  const allAssessments = Array.from(assessments.values());

  const avgResourceBrittleness = allResources.length > 0
    ? allResources.reduce((sum, r) => sum + r.brittlenessScore, 0) / allResources.length
    : 0;

  const avgAssessmentBrittleness = allAssessments.length > 0
    ? allAssessments.reduce((sum, a) => sum + a.overallBrittleness, 0) / allAssessments.length
    : 0;

  return {
    systems: {
      total: allSystems.length,
      byType: allSystems.reduce((acc, s) => {
        acc[s.type] = (acc[s.type] || 0) + 1;
        return acc;
      }, {} as Record<string, number>)
    },
    resources: {
      total: allResources.length,
      byType: allResources.reduce((acc, r) => {
        acc[r.type] = (acc[r.type] || 0) + 1;
        return acc;
      }, {} as Record<string, number>),
      avgBrittleness: avgResourceBrittleness
    },
    assessments: {
      total: allAssessments.length,
      avgBrittleness: avgAssessmentBrittleness
    },
    spofs: {
      total: allAssessments.reduce((sum, a) => sum + a.singlePointsOfFailure.length, 0),
      critical: allAssessments.reduce((sum, a) => 
        sum + a.singlePointsOfFailure.filter(s => s.type === 'absolute').length, 0)
    }
  };
}

// ============================================================================
// TEST SUITE
// ============================================================================

/**
 * Run brittleness analyzer tests
 */
export function runBrittlenessAnalyzerTests(): {
  passed: boolean;
  tests: { total: number; passed: number; failed: number };
  results: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const results: Array<{ name: string; passed: boolean; error?: string }> = [];

  try {
    // Test 1: Create system
    const system = createSystem({
      name: 'Test Manufacturing',
      type: 'manufacturing',
      thresholds: { warning: 30, critical: 50, fragile: 70 },
      concentrationThresholds: { person: 50, vendor: 40, system: 60, location: 70 },
      assessmentInterval: 24
    });
    results.push({ name: 'Create System', passed: !!system.id });

    // Test 2: Register resource
    const resource1 = registerResource({
      name: 'Senior Engineer',
      type: 'person',
      utilization: 80,
      maxCapacity: 100,
      dependencies: [],
      dependents: [
        { resourceId: 'process_1', name: 'Code Review', weight: 0.8, type: 'essential' }
      ],
      redundancy: {
        hasRedundancy: false,
        backupCount: 0,
        backups: [],
        failoverCapable: false,
        failoverTime: 0
      },
      criticality: 'mission_critical',
      replacementDifficulty: 'very_difficult',
      timeToReplace: 180,
      costToReplace: 50000,
      metadata: { knowledgeDomains: ['Architecture', 'Backend'] }
    });
    results.push({ name: 'Register Resource', passed: !!resource1.id });

    // Test 3: Register second resource
    const resource2 = registerResource({
      name: 'Junior Engineer',
      type: 'person',
      utilization: 40,
      maxCapacity: 100,
      dependencies: [resource1.id],
      dependents: [],
      redundancy: {
        hasRedundancy: false,
        backupCount: 0,
        backups: [],
        failoverCapable: false,
        failoverTime: 0
      },
      criticality: 'important',
      replacementDifficulty: 'easy',
      timeToReplace: 30,
      costToReplace: 10000,
      metadata: {}
    });
    results.push({ name: 'Register Second Resource', passed: !!resource2.id });

    // Test 4: Calculate brittleness score
    const brittleness = calculateBrittlenessScore(resource1.id, 'person');
    results.push({ name: 'Calculate Brittleness Score', passed: brittleness >= 0 && brittleness <= 1 });

    // Test 5: Determine risk level
    const riskLevel = determineRiskLevel(0.7);
    results.push({ name: 'Determine Risk Level', passed: riskLevel === 'high' });

    // Test 6: Check SPOF detection
    const isSPOF = isSinglePointOfFailure({ ...resource1, brittlenessScore: 0.7 });
    results.push({ name: 'SPOF Detection', passed: isSPOF === true });

    // Test 7: Run full assessment
    const assessment = runBrittlenessAssessment(system.id);
    results.push({ name: 'Run Assessment', passed: !!assessment.id });

    // Test 8: Verify SPOF identification
    results.push({ 
      name: 'SPOF Identification', 
      passed: assessment.singlePointsOfFailure.length >= 0 
    });

    // Test 9: Verify dependency clusters
    results.push({ 
      name: 'Dependency Cluster Analysis', 
      passed: assessment.dependencyClusters.length >= 0 
    });

    // Test 10: Verify recommendations
    results.push({ 
      name: 'Recommendations Generated', 
      passed: assessment.recommendations.length >= 0 
    });

    // Test 11: Verify risk summary
    results.push({ 
      name: 'Risk Summary', 
      passed: !!assessment.riskSummary && assessment.riskSummary.spofCount >= 0 
    });

    // Test 12: System stats
    const stats = getSystemStats();
    results.push({ name: 'System Stats', passed: stats.systems.total > 0 });

  } catch (error) {
    results.push({ name: 'Test execution', passed: false, error: String(error) });
  }

  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;

  return {
    passed: failed === 0,
    tests: { total: results.length, passed, failed },
    results
  };
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

const brittlenessAnalyzer = {
  // System management
  createSystem,
  getSystem,
  listSystems,
  // Resource management
  registerResource,
  getResource,
  updateResourceUtilization,
  addDependent,
  listResources,
  // Calculations
  calculateBrittlenessScore,
  determineRiskLevel,
  isSinglePointOfFailure,
  // Assessment
  runBrittlenessAssessment,
  getAssessment,
  getLatestAssessment,
  // Stats
  getSystemStats,
  // Tests
  runBrittlenessAnalyzerTests
};

export default brittlenessAnalyzer;
