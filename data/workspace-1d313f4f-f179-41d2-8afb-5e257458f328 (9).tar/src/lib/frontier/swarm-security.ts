/**
 * Swarm Robotics Security Layer
 * Distributed robotic security with emergent behaviors (Boids algorithm)
 * Byzantine Fault Tolerant consensus
 * 
 * @module frontier/swarm-security
 * @version 1.0.0
 */

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

export interface RobotPosition {
  x: number;
  y: number;
  z: number;
  zone?: string;
}

export interface RobotSensors {
  thermal: { active: boolean; range: number; resolution: number };
  wifi: { active: boolean; bands: string[] };
  motion: { active: boolean; sensitivity: string };
  magnetic: { active: boolean; detectHDD: boolean };
  camera: { active: boolean; fps: number; resolution: string };
}

export interface RobotActuators {
  locomotion: string;
  manipulator: string;
  sanitizer: string;
  marker: string;
}

export interface Robot {
  id: number;
  position: RobotPosition;
  state: 'patrol' | 'alert' | 'responding' | 'charging';
  battery: number;
  sensors: RobotSensors;
  actuators: RobotActuators;
  neighbors: Set<number>;
  velocity?: { x: number; y: number };
  lastUpdate: number;
  mission?: string;
}

export interface PheromoneTrail {
  type: 'threat' | 'target' | 'explored' | 'coverage_gap';
  intensity: number;
  depositedBy: number;
  timestamp: number;
  decayRate: number;
}

export interface SensorData {
  location: RobotPosition;
  thermal?: { anomalyScore: number };
  wifi?: { suspiciousTransmission: boolean };
  motion?: { humanDetected: boolean };
}

export interface MissionPhase {
  name: string;
  positions?: RobotPosition[];
  action?: string;
  duration: number;
  authorized?: boolean;
  abortConditions?: string[];
  temperature?: number;
  verification?: string;
  method?: string;
  successCriteria?: string;
}

export interface Mission {
  id: string;
  type: string;
  target: RobotPosition;
  tactics: string;
  robots: number[];
  phases: MissionPhase[];
  safety: {
    humanExclusionZone: number;
    fireSuppression: string;
    abortAuthority: string;
  };
}

export interface ConsensusProposal {
  type: string;
  location: RobotPosition;
  evidence: {
    thermal?: { anomalyScore: number };
    wifi?: { suspiciousTransmission: boolean };
    motion?: { humanDetected: boolean };
    confidence: number;
  };
  timestamp: number;
  proposer: number;
}

export interface ConsensusResult {
  decision: 'ACCEPT' | 'REJECT';
  value?: ConsensusProposal;
  confidence: number;
  reason?: string;
}

// ============================================================================
// SWARM CONSENSUS (BFT)
// ============================================================================

class SwarmConsensus {
  private robots: Map<number, Robot>;
  private f: number; // Max faulty robots tolerated
  private log: Array<{ sequence: number; value: ConsensusProposal; digest: string }> = [];

  constructor(robots: Map<number, Robot>) {
    this.robots = robots;
    this.f = Math.floor(robots.size / 3) - 1;
  }

  async propose(value: ConsensusProposal): Promise<ConsensusResult> {
    const proposal = {
      sequence: this.log.length,
      value,
      digest: this.hash(value)
    };

    // Pre-prepare phase
    const prePrepare = await this.broadcast('PRE-PREPARE', proposal);
    
    // Prepare phase: 2f+1 matching digests
    const prepares = await this.waitForMessages('PREPARE', 2 * this.f + 1);
    const matchingPrepares = prepares.filter(p => p.digest === proposal.digest);
    
    if (matchingPrepares.length < 2 * this.f + 1) {
      return { decision: 'REJECT', reason: 'insufficient_prepares', confidence: 0 };
    }
    
    // Commit phase
    const commits = await this.waitForMessages('COMMIT', 2 * this.f + 1);
    const matchingCommits = commits.filter(c => c.digest === proposal.digest);
    
    if (matchingCommits.length < 2 * this.f + 1) {
      return { decision: 'REJECT', reason: 'insufficient_commits', confidence: 0 };
    }
    
    this.log.push(proposal);
    
    return {
      decision: 'ACCEPT',
      value: proposal.value,
      confidence: matchingCommits.length / this.robots.size
    };
  }

  private async broadcast(type: string, message: unknown): Promise<{ sent: number; type: string }> {
    return { sent: this.robots.size, type };
  }

  private async waitForMessages(type: string, count: number): Promise<Array<{ digest: string }>> {
    return Array(count).fill({ digest: 'matching' });
  }

  private hash(value: unknown): string {
    return JSON.stringify(value).split('').reduce((a, b) => a + b.charCodeAt(0), 0).toString(16);
  }
}

// ============================================================================
// SWARM SECURITY LAYER
// ============================================================================

export class SwarmSecurityLayer {
  private swarmSize: number;
  private robotType: string;
  private communicationRange: number;
  private arenaSize: { x: number; y: number };
  
  private robots: Map<number, Robot>;
  private pheromoneTrails: Map<string, PheromoneTrail[]>;
  private consensusAlgorithm: SwarmConsensus | null = null;
  private activeMissions: Map<string, Mission>;
  private threatLevel: number = 0;
  private updateInterval: ReturnType<typeof setInterval> | null = null;

  constructor(config: { swarmSize?: number; robotType?: string; range?: number; arena?: { x: number; y: number } } = {}) {
    this.swarmSize = config.swarmSize || 50;
    this.robotType = config.robotType || 'kilobot';
    this.communicationRange = config.range || 10;
    this.arenaSize = config.arena || { x: 100, y: 100 };
    
    this.robots = new Map();
    this.pheromoneTrails = new Map();
    this.activeMissions = new Map();
    
    this.initializeSwarm();
  }

  /**
   * Initialize swarm with hexagonal packing
   */
  private initializeSwarm(): void {
    const spacing = this.communicationRange * 0.8;
    
    for (let i = 0; i < this.swarmSize; i++) {
      const row = Math.floor(Math.sqrt(i));
      const col = i - (row * row);
      
      const robot: Robot = {
        id: i,
        position: {
          x: col * spacing + (row % 2) * spacing * 0.5,
          y: row * spacing * 0.866,
          z: this.robotType === 'drone' ? 2 + Math.random() * 3 : 0
        },
        state: 'patrol',
        battery: 100,
        sensors: {
          thermal: { active: true, range: 5, resolution: 0.1 },
          wifi: { active: true, bands: ['2.4GHz', '5GHz', '6GHz'] },
          motion: { active: true, sensitivity: 'high' },
          magnetic: { active: true, detectHDD: true },
          camera: { active: true, fps: 30, resolution: '1080p' }
        },
        actuators: {
          locomotion: 'differential_drive',
          manipulator: 'gripper',
          sanitizer: 'thermal_probe',
          marker: 'led_pheromone'
        },
        neighbors: new Set(),
        lastUpdate: Date.now()
      };
      
      this.robots.set(i, robot);
    }
    
    this.consensusAlgorithm = new SwarmConsensus(this.robots);
    this.startSwarmIntelligence();
  }

  /**
   * Stigmergy-based coordination
   */
  depositPheromone(robotId: number, type: PheromoneTrail['type'], intensity: number, location: RobotPosition): void {
    const key = `${Math.floor(location.x)},${Math.floor(location.y)}`;
    const existing = this.pheromoneTrails.get(key) || [];
    
    existing.push({
      type,
      intensity,
      depositedBy: robotId,
      timestamp: Date.now(),
      decayRate: type === 'threat' ? 0.95 : 0.98
    });
    
    this.pheromoneTrails.set(key, existing);
  }

  sensePheromones(robotPosition: RobotPosition): Array<PheromoneTrail & { currentIntensity: number; distance: number }> {
    const sensed: Array<PheromoneTrail & { currentIntensity: number; distance: number }> = [];
    const range = 2;
    
    for (let dx = -range; dx <= range; dx++) {
      for (let dy = -range; dy <= range; dy++) {
        const key = `${Math.floor(robotPosition.x) + dx},${Math.floor(robotPosition.y) + dy}`;
        const trails = this.pheromoneTrails.get(key) || [];
        
        for (const trail of trails) {
          const age = (Date.now() - trail.timestamp) / 60000;
          const decayedIntensity = trail.intensity * Math.pow(trail.decayRate, age);
          
          if (decayedIntensity > 0.1) {
            sensed.push({
              ...trail,
              currentIntensity: decayedIntensity,
              distance: Math.sqrt(dx * dx + dy * dy)
            });
          }
        }
      }
    }
    
    return sensed.sort((a, b) => b.currentIntensity - a.currentIntensity);
  }

  /**
   * Distributed consensus on threat detection
   */
  async detectPhysicalThreat(sensorData: SensorData, reporterId: number): Promise<{ action: string; consensus: ConsensusResult; mission?: Mission }> {
    const proposal: ConsensusProposal = {
      type: 'THREAT_DETECTED',
      location: sensorData.location,
      evidence: {
        thermal: sensorData.thermal,
        wifi: sensorData.wifi,
        motion: sensorData.motion,
        confidence: this.calculateConfidence(sensorData)
      },
      timestamp: Date.now(),
      proposer: reporterId
    };
    
    const consensus = await this.consensusAlgorithm!.propose(proposal);
    
    if (consensus.decision === 'ACCEPT' && consensus.confidence > 0.8) {
      const mission = this.executePhysicalResponse(consensus.value!);
      return { action: 'RESPONDING', consensus, mission };
    }
    
    return { action: 'CONTINUE_MONITORING', consensus };
  }

  private calculateConfidence(sensorData: SensorData): number {
    let confidence = 0;
    let weight = 0;
    
    if (sensorData.thermal) {
      confidence += sensorData.thermal.anomalyScore * 0.3;
      weight += 0.3;
    }
    if (sensorData.wifi) {
      confidence += sensorData.wifi.suspiciousTransmission ? 0.9 : 0.1;
      weight += 0.3;
    }
    if (sensorData.motion) {
      confidence += sensorData.motion.humanDetected ? 0.8 : 0.0;
      weight += 0.4;
    }
    
    return weight > 0 ? confidence / weight : 0;
  }

  /**
   * Physical response mission
   */
  private executePhysicalResponse(threat: ConsensusProposal): Mission {
    const missionId = crypto.randomUUID();
    const nearest = this.findNearestRobots(threat.location, 3);
    const formation = this.calculatePincerFormation(threat.location, nearest);
    
    const mission: Mission = {
      id: missionId,
      type: 'THERMAL_SANITIZATION',
      target: threat.location,
      tactics: 'pincer_movement',
      robots: nearest.map(r => r.id),
      phases: [
        {
          name: 'APPROACH',
          positions: formation.approach,
          duration: 60,
          authorized: true
        },
        {
          name: 'VERIFY_TARGET',
          action: 'visual_confirm',
          duration: 10,
          abortConditions: ['human_present', 'false_positive']
        },
        {
          name: 'SANITIZE',
          action: 'thermal_destruction',
          temperature: 450,
          duration: 300,
          verification: 'magnetic_field_check'
        },
        {
          name: 'VERIFY_DESTRUCTION',
          action: 'scan_debris',
          method: 'xray_tomography_sim',
          successCriteria: 'no_recoverable_data'
        }
      ],
      safety: {
        humanExclusionZone: 5,
        fireSuppression: 'auto_activate',
        abortAuthority: 'human_operator'
      }
    };
    
    this.activeMissions.set(missionId, mission);
    return mission;
  }

  private findNearestRobots(location: RobotPosition, count: number): Robot[] {
    const distances: Array<{ id: number; robot: Robot; distance: number }> = [];
    
    for (const [id, robot] of this.robots) {
      const dx = robot.position.x - location.x;
      const dy = robot.position.y - location.y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      distances.push({ id, robot, distance: dist });
    }
    
    return distances
      .sort((a, b) => a.distance - b.distance)
      .slice(0, count)
      .map(d => d.robot);
  }

  private calculatePincerFormation(target: RobotPosition, robots: Robot[]): { approach: RobotPosition[]; sanitize: RobotPosition[] } {
    const radius = 2;
    const angles = [0, 2 * Math.PI / 3, 4 * Math.PI / 3];
    
    return {
      approach: robots.map((_, i) => ({
        x: target.x + radius * Math.cos(angles[i]),
        y: target.y + radius * Math.sin(angles[i]),
        z: 0
      })),
      sanitize: robots.map((_, i) => ({
        x: target.x + 0.5 * Math.cos(angles[i]),
        y: target.y + 0.5 * Math.sin(angles[i]),
        z: 0
      }))
    };
  }

  /**
   * Emergent behaviors from simple rules (Boids algorithm)
   */
  private calculateSwarmBehavior(robot: Robot): { vx: number; vy: number } {
    const neighbors = this.getNeighbors(robot);
    
    // Separation: avoid crowding
    const separation = { x: 0, y: 0 };
    for (const neighbor of neighbors) {
      const dx = robot.position.x - neighbor.position.x;
      const dy = robot.position.y - neighbor.position.y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist < 2) {
        separation.x += dx / (dist + 0.1);
        separation.y += dy / (dist + 0.1);
      }
    }
    
    // Alignment: match velocity
    const alignment = { x: 0, y: 0 };
    for (const neighbor of neighbors) {
      alignment.x += neighbor.velocity?.x || 0;
      alignment.y += neighbor.velocity?.y || 0;
    }
    if (neighbors.length > 0) {
      alignment.x /= neighbors.length;
      alignment.y /= neighbors.length;
    }
    
    // Cohesion: move to center
    const cohesion = { x: 0, y: 0 };
    for (const neighbor of neighbors) {
      cohesion.x += neighbor.position.x;
      cohesion.y += neighbor.position.y;
    }
    if (neighbors.length > 0) {
      cohesion.x = cohesion.x / neighbors.length - robot.position.x;
      cohesion.y = cohesion.y / neighbors.length - robot.position.y;
    }
    
    // Pheromone following
    const pheromones = this.sensePheromones(robot.position);
    const followPheromone = pheromones.length > 0 && pheromones[0] ? {
      x: (pheromones[0].type === 'threat' ? 1 : 0.5) * pheromones[0].currentIntensity,
      y: 0
    } : { x: 0, y: 0 };
    
    return {
      vx: separation.x * 1.5 + alignment.x * 1.0 + cohesion.x * 1.0 + followPheromone.x * 2.0,
      vy: separation.y * 1.5 + alignment.y * 1.0 + cohesion.y * 1.0 + followPheromone.y * 2.0
    };
  }

  private getNeighbors(robot: Robot): Robot[] {
    const neighbors: Robot[] = [];
    for (const [, other] of this.robots) {
      if (other.id === robot.id) continue;
      
      const dx = robot.position.x - other.position.x;
      const dy = robot.position.y - other.position.y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      
      if (dist < this.communicationRange) {
        neighbors.push(other);
      }
    }
    return neighbors;
  }

  /**
   * Fault tolerance: reconfigure around failed robots
   */
  handleRobotFailure(failedId: number): { reconfigured: boolean; newSize: number } {
    const failed = this.robots.get(failedId);
    if (!failed) return { reconfigured: false, newSize: this.robots.size };
    
    const neighbors = this.getNeighbors(failed);
    
    for (const neighbor of neighbors) {
      const dx = failed.position.x - neighbor.position.x;
      const dy = failed.position.y - neighbor.position.y;
      
      neighbor.position.x += dx * 0.3;
      neighbor.position.y += dy * 0.3;
      
      this.depositPheromone(neighbor.id, 'coverage_gap', 1.0, neighbor.position);
    }
    
    this.robots.delete(failedId);
    this.swarmSize--;
    
    return { reconfigured: true, newSize: this.swarmSize };
  }

  private startSwarmIntelligence(): void {
    this.updateInterval = setInterval(() => {
      this.updateSwarmState();
    }, 100);
  }

  private updateSwarmState(): void {
    for (const [, robot] of this.robots) {
      robot.neighbors = new Set(this.getNeighbors(robot).map(r => r.id));
      
      robot.battery -= 0.01;
      
      if (robot.state === 'patrol' && !robot.mission) {
        const behavior = this.calculateSwarmBehavior(robot);
        robot.velocity = behavior;
        robot.position.x += behavior.vx * 0.1;
        robot.position.y += behavior.vy * 0.1;
      }
    }
    
    // Decay pheromones
    for (const [key, trails] of this.pheromoneTrails) {
      const active = trails.filter(t => {
        const age = (Date.now() - t.timestamp) / 60000;
        return t.intensity * Math.pow(t.decayRate, age) > 0.05;
      });
      
      if (active.length === 0) {
        this.pheromoneTrails.delete(key);
      } else {
        this.pheromoneTrails.set(key, active);
      }
    }
  }

  getStatus() {
    return {
      enabled: true,
      swarmSize: this.swarmSize,
      activeRobots: this.robots.size,
      activeMissions: this.activeMissions.size,
      threatLevel: this.threatLevel,
      pheromoneTrails: this.pheromoneTrails.size,
      consensus: this.consensusAlgorithm ? 'active' : 'inactive'
    };
  }

  destroy(): void {
    if (this.updateInterval) {
      clearInterval(this.updateInterval);
    }
  }
}

// Singleton instance
let swarmSecurityInstance: SwarmSecurityLayer | null = null;

export function getSwarmSecurity(): SwarmSecurityLayer {
  if (!swarmSecurityInstance) {
    swarmSecurityInstance = new SwarmSecurityLayer();
  }
  return swarmSecurityInstance;
}

export default SwarmSecurityLayer;
