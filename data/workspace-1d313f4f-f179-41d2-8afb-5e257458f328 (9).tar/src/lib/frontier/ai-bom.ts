/**
 * AI Bill of Materials (AI-BOM) - Component tracking and provenance
 * @module frontier/ai-bom
 */
export type ComponentType = 'model' | 'dataset' | 'library' | 'framework' | 'tool' | 'service';

export interface BOMRecord {
  id: string; systemId: string; name: string; version: string;
  components: BOMComponent[]; dependencies: Dependency[];
  vulnerabilities: Vulnerability[]; licenses: License[];
  createdAt: number; updatedAt: number;
}

export interface BOMComponent {
  id: string; name: string; type: ComponentType;
  version: string; supplier: string; hash: string;
  provenance: string; license: string;
}

export interface Dependency {
  id: string; from: string; to: string; type: 'direct' | 'transitive';
}

export interface Vulnerability {
  id: string; cveId: string; severity: 'low' | 'medium' | 'high' | 'critical';
  affectedComponent: string; description: string; patched: boolean;
}

export interface License {
  id: string; name: string; type: 'permissive' | 'copyleft' | 'proprietary';
  components: string[]; compliant: boolean;
}

const boms = new Map<string, BOMRecord>();
const components = new Map<string, BOMComponent>();

export function createBOM(config: {systemId: string; name: string; version: string}): BOMRecord {
  const bom: BOMRecord = {
    id: `bom_${Date.now()}_${Math.random().toString(36).substr(2,6)}`,
    ...config, components: [], dependencies: [],
    vulnerabilities: [], licenses: [],
    createdAt: Date.now(), updatedAt: Date.now()
  };
  boms.set(bom.id, bom);
  return bom;
}

export function addComponent(bomId: string, config: Omit<BOMComponent, 'id'>): BOMComponent | null {
  const bom = boms.get(bomId);
  if (!bom) return null;
  const comp: BOMComponent = {
    id: `comp_${Date.now()}_${Math.random().toString(36).substr(2,4)}`, ...config
  };
  components.set(comp.id, comp);
  bom.components.push(comp);
  bom.updatedAt = Date.now();
  return comp;
}

export function addDependency(bomId: string, fromId: string, toId: string, type: 'direct' | 'transitive' = 'direct'): boolean {
  const bom = boms.get(bomId);
  if (!bom) return false;
  bom.dependencies.push({id: `dep_${Date.now()}`, from: fromId, to: toId, type});
  bom.updatedAt = Date.now();
  return true;
}

export function reportVulnerability(bomId: string, cveId: string, severity: Vulnerability['severity'], affected: string, desc: string): Vulnerability | null {
  const bom = boms.get(bomId);
  if (!bom) return null;
  const vuln: Vulnerability = {
    id: `vuln_${Date.now()}`, cveId, severity,
    affectedComponent: affected, description: desc, patched: false
  };
  bom.vulnerabilities.push(vuln);
  bom.updatedAt = Date.now();
  return vuln;
}

export function getBOM(id: string): BOMRecord | undefined { return boms.get(id); }

export function getBOMStats() {
  const allBOMs = Array.from(boms.values());
  return {
    total: boms.size,
    components: components.size,
    vulnerabilities: allBOMs.reduce((s,b) => s + b.vulnerabilities.length, 0),
    criticalVulns: allBOMs.flatMap(b => b.vulnerabilities).filter(v => v.severity === 'critical' && !v.patched).length
  };
}

export function runAIBOMTests() {
  const results: {name: string; passed: boolean}[] = [];
  try { const b = createBOM({systemId:'sys1',name:'Test AI',version:'1.0'}); results.push({name:'Create',passed:!!b.id}); } catch { results.push({name:'Create',passed:false}); }
  try { const b = Array.from(boms.values())[0]; const c = addComponent(b.id,{name:'PyTorch',type:'framework',version:'2.0',supplier:'Meta',hash:'abc',provenance:'github',license:'BSD'}); results.push({name:'Component',passed:!!c?.id}); } catch { results.push({name:'Component',passed:false}); }
  try { const b = Array.from(boms.values())[0]; const v = reportVulnerability(b.id,'CVE-2024-1234','high','comp1','Test'); results.push({name:'Vulnerability',passed:!!v?.id}); } catch { results.push({name:'Vulnerability',passed:false}); }
  try { const s = getBOMStats(); results.push({name:'Stats',passed:s.total>0}); } catch { results.push({name:'Stats',passed:false}); }
  const passed = results.filter(r=>r.passed).length, failed = results.filter(r=>!r.passed).length;
  return {passed: failed===0, tests:{total:results.length,passed,failed}, results};
}

export default {createBOM,addComponent,addDependency,reportVulnerability,getBOM,getBOMStats,runAIBOMTests};
