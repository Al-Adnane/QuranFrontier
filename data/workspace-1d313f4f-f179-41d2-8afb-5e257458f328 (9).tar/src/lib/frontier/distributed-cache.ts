/**
 * Distributed Cache Synchronization
 * ==================================
 * 
 * High-performance distributed caching with synchronization capabilities.
 * Supports multi-node cache coordination and real-time data consistency.
 * 
 * Features:
 * - Distributed Cache Management
 * - Cache Node Clustering
 * - Real-time Synchronization
 * - Consistent Hashing
 * - Cache Invalidation Strategies
 * - TTL & Eviction Policies
 * - Cache Warming
 * - Hit/Miss Analytics
 * - Memory Management
 * - Cross-Region Replication
 * 
 * @module frontier/distributed-cache
 * @version 1.0.0
 */

// ============================================================================
// TYPES
// ============================================================================

/**
 * Cache Node Status
 */
export type CacheNodeStatus = 'active' | 'inactive' | 'recovering' | 'error';

/**
 * Eviction Policy
 */
export type EvictionPolicy = 'lru' | 'lfu' | 'fifo' | 'ttl' | 'random' | 'custom';

/**
 * Consistency Level
 */
export type ConsistencyLevel = 'strong' | 'eventual' | 'causal';

/**
 * Sync Status
 */
export type SyncStatus = 'synced' | 'syncing' | 'conflict' | 'error';

/**
 * Cache Entry Priority
 */
export type CachePriority = 'critical' | 'high' | 'normal' | 'low';

/**
 * Cache Node Configuration
 */
export interface CacheNodeConfig {
  id: string;
  name: string;
  region: string;
  zone?: string;
  
  // Connection
  host: string;
  port: number;
  protocol: 'redis' | 'memcached' | 'custom';
  
  // Capacity
  maxMemory: number; // bytes
  maxEntries: number;
  
  // Status
  status: CacheNodeStatus;
  lastHeartbeat?: number;
  lastError?: string;
  
  // Statistics
  stats: {
    hits: number;
    misses: number;
    evictions: number;
    memoryUsed: number;
    entries: number;
    connections: number;
  };
  
  // Configuration
  config: {
    evictionPolicy: EvictionPolicy;
    defaultTTL: number; // seconds
    maxKeySize: number;
    maxValueSize: number;
    compression: boolean;
    serialization: 'json' | 'msgpack' | 'protobuf' | 'custom';
  };
  
  // Metadata
  metadata?: Record<string, unknown>;
  createdAt: number;
  updatedAt: number;
}

/**
 * Cache Entry
 */
export interface CacheEntry {
  key: string;
  value: unknown;
  
  // Metadata
  ttl: number; // seconds, 0 = no expiry
  priority: CachePriority;
  tags: string[];
  
  // Timing
  createdAt: number;
  updatedAt: number;
  expiresAt?: number;
  lastAccessedAt: number;
  
  // Stats
  hits: number;
  misses: number;
  
  // Sync
  version: number;
  nodeId: string;
  syncStatus: SyncStatus;
  
  // Size
  size: number; // bytes
  
  // Custom metadata
  metadata?: Record<string, unknown>;
}

/**
 * Cache Cluster
 */
export interface CacheCluster {
  id: string;
  name: string;
  
  // Nodes
  nodes: string[]; // node IDs
  primaryNodeId: string;
  
  // Configuration
  config: {
    consistencyLevel: ConsistencyLevel;
    replicationFactor: number;
    readQuorum: number;
    writeQuorum: number;
    syncInterval: number; // ms
    heartbeatInterval: number; // ms
    failureThreshold: number;
    recoveryTimeout: number;
  };
  
  // Hash Ring
  hashRing: {
    virtualNodes: number;
    ring: Array<{ hash: number; nodeId: string }>;
  };
  
  // Statistics
  stats: {
    totalHits: number;
    totalMisses: number;
    totalEvictions: number;
    totalMemory: number;
    totalEntries: number;
    avgLatency: number;
  };
  
  // Status
  status: 'healthy' | 'degraded' | 'error';
  
  // Metadata
  metadata?: Record<string, unknown>;
  createdAt: number;
  updatedAt: number;
}

/**
 * Sync Operation
 */
export interface SyncOperation {
  id: string;
  type: 'set' | 'delete' | 'expire' | 'invalidate' | 'clear';
  
  // Entry
  key: string;
  value?: unknown;
  ttl?: number;
  tags?: string[];
  
  // Source
  sourceNodeId: string;
  sourceVersion: number;
  
  // Target
  targetNodes: string[];
  completedNodes: string[];
  
  // Timing
  createdAt: number;
  completedAt?: number;
  
  // Status
  status: 'pending' | 'syncing' | 'completed' | 'failed';
  error?: string;
  
  // Metadata
  metadata?: Record<string, unknown>;
}

/**
 * Conflict Resolution
 */
export interface ConflictResolution {
  id: string;
  key: string;
  
  // Conflicting entries
  entries: Array<{
    nodeId: string;
    value: unknown;
    version: number;
    timestamp: number;
  }>;
  
  // Resolution
  strategy: 'last_write_wins' | 'first_write_wins' | 'merge' | 'custom';
  resolvedValue?: unknown;
  resolvedVersion?: number;
  
  // Timing
  detectedAt: number;
  resolvedAt?: number;
  
  // Status
  status: 'detected' | 'resolved' | 'manual_required';
}

/**
 * Cache Warming Job
 */
export interface CacheWarmingJob {
  id: string;
  name: string;
  description?: string;
  
  // Configuration
  dataSource: {
    type: 'database' | 'api' | 'file' | 'function';
    connection?: string;
    query?: string;
    endpoint?: string;
  };
  
  // Keys to warm
  keyPattern: string;
  keyGenerator?: string; // function name
  
  // Schedule
  schedule: {
    type: 'once' | 'interval' | 'cron';
    interval?: number; // seconds
    cronExpression?: string;
    nextRun?: number;
  };
  
  // Target
  targetNodes: string[];
  ttl: number;
  priority: CachePriority;
  
  // Status
  status: 'pending' | 'running' | 'completed' | 'failed' | 'cancelled';
  lastRun?: number;
  lastError?: string;
  
  // Statistics
  stats: {
    totalRuns: number;
    keysWarmed: number;
    avgDuration: number;
    lastDuration?: number;
  };
  
  // Metadata
  metadata?: Record<string, unknown>;
  createdAt: number;
  updatedAt: number;
}

/**
 * Cache Invalidation Rule
 */
export interface CacheInvalidationRule {
  id: string;
  name: string;
  description?: string;
  
  // Trigger
  trigger: {
    type: 'time' | 'event' | 'dependency' | 'manual';
    eventName?: string;
    dependencyPattern?: string;
    cronExpression?: string;
  };
  
  // Target
  target: {
    type: 'keys' | 'tags' | 'pattern' | 'all';
    keys?: string[];
    tags?: string[];
    pattern?: string;
  };
  
  // Action
  action: 'delete' | 'expire' | 'refresh';
  expireIn?: number; // seconds
  
  // Status
  enabled: boolean;
  lastTriggered?: number;
  triggerCount: number;
  
  // Metadata
  metadata?: Record<string, unknown>;
  createdAt: number;
  updatedAt: number;
}

/**
 * Cache Statistics
 */
export interface CacheStatistics {
  nodeId?: string;
  clusterId?: string;
  period: { start: number; end: number };
  
  // Operations
  operations: {
    gets: number;
    sets: number;
    deletes: number;
    increments: number;
    appends: number;
  };
  
  // Performance
  performance: {
    avgGetLatency: number;
    avgSetLatency: number;
    p50Latency: number;
    p95Latency: number;
    p99Latency: number;
    throughput: number;
  };
  
  // Memory
  memory: {
    used: number;
    total: number;
    fragmentation: number;
    evictions: number;
  };
  
  // Hit/Miss
  hitRate: {
    hits: number;
    misses: number;
    ratio: number;
  };
  
  // Sync
  sync: {
    operationsSynced: number;
    conflicts: number;
    avgSyncLatency: number;
  };
}

// ============================================================================
// STORAGE
// ============================================================================

const cacheNodes = new Map<string, CacheNodeConfig>();
const cacheEntries = new Map<string, CacheEntry>();
const cacheClusters = new Map<string, CacheCluster>();
const syncOperations = new Map<string, SyncOperation>();
const conflictResolutions = new Map<string, ConflictResolution>();
const warmingJobs = new Map<string, CacheWarmingJob>();
const invalidationRules = new Map<string, CacheInvalidationRule>();
const cacheStats = new Map<string, CacheStatistics>();

// Indexes
const entriesByTag = new Map<string, Set<string>>();
const entriesByNode = new Map<string, Set<string>>();

// ============================================================================
// CACHE NODE MANAGEMENT
// ============================================================================

/**
 * Register a cache node
 */
export function registerCacheNode(
  config: Omit<CacheNodeConfig, 'id' | 'createdAt' | 'updatedAt' | 'stats' | 'status'>
): CacheNodeConfig {
  const node: CacheNodeConfig = {
    ...config,
    id: `node_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    status: 'active',
    stats: {
      hits: 0,
      misses: 0,
      evictions: 0,
      memoryUsed: 0,
      entries: 0,
      connections: 0
    },
    createdAt: Date.now(),
    updatedAt: Date.now()
  };
  
  cacheNodes.set(node.id, node);
  entriesByNode.set(node.id, new Set());
  
  return node;
}

/**
 * Get cache node
 */
export function getCacheNode(id: string): CacheNodeConfig | undefined {
  return cacheNodes.get(id);
}

/**
 * Get all cache nodes
 */
export function getAllCacheNodes(): CacheNodeConfig[] {
  return Array.from(cacheNodes.values());
}

/**
 * Get active nodes
 */
export function getActiveNodes(): CacheNodeConfig[] {
  return Array.from(cacheNodes.values()).filter(n => n.status === 'active');
}

/**
 * Update node heartbeat
 */
export function updateNodeHeartbeat(nodeId: string): boolean {
  const node = cacheNodes.get(nodeId);
  if (!node) return false;
  
  node.lastHeartbeat = Date.now();
  node.status = 'active';
  node.updatedAt = Date.now();
  
  return true;
}

/**
 * Check node health
 */
export function checkNodeHealth(nodeId: string): {
  healthy: boolean;
  latency?: number;
  error?: string;
} {
  const node = cacheNodes.get(nodeId);
  if (!node) {
    return { healthy: false, error: 'Node not found' };
  }
  
  const now = Date.now();
  const heartbeatTimeout = 30000; // 30 seconds
  
  if (!node.lastHeartbeat || now - node.lastHeartbeat > heartbeatTimeout) {
    node.status = 'inactive';
    return { healthy: false, error: 'Heartbeat timeout' };
  }
  
  return { healthy: true, latency: now - node.lastHeartbeat };
}

/**
 * Remove cache node
 */
export function removeCacheNode(nodeId: string): boolean {
  const node = cacheNodes.get(nodeId);
  if (!node) return false;
  
  // Remove entries for this node
  const nodeEntries = entriesByNode.get(nodeId);
  if (nodeEntries) {
    for (const key of nodeEntries) {
      cacheEntries.delete(key);
    }
    entriesByNode.delete(nodeId);
  }
  
  cacheNodes.delete(nodeId);
  return true;
}

// ============================================================================
// CACHE OPERATIONS
// ============================================================================

/**
 * Set cache entry
 */
export function setCacheEntry(
  key: string,
  value: unknown,
  options?: {
    ttl?: number;
    priority?: CachePriority;
    tags?: string[];
    nodeId?: string;
    metadata?: Record<string, unknown>;
  }
): CacheEntry | null {
  // Select node if not specified
  let nodeId = options?.nodeId;
  if (!nodeId) {
    const activeNodes = getActiveNodes();
    if (activeNodes.length === 0) return null;
    
    // Simple hash-based selection
    const hash = simpleHash(key);
    nodeId = activeNodes[hash % activeNodes.length].id;
  }
  
  const node = cacheNodes.get(nodeId);
  if (!node) return null;
  
  const now = Date.now();
  const ttl = options?.ttl ?? node.config.defaultTTL;
  
  // Check capacity
  if (cacheEntries.size >= node.maxEntries) {
    evictEntries(nodeId, 1);
  }
  
  // Calculate size
  const size = estimateSize(value);
  
  const entry: CacheEntry = {
    key,
    value,
    ttl,
    priority: options?.priority || 'normal',
    tags: options?.tags || [],
    createdAt: now,
    updatedAt: now,
    expiresAt: ttl > 0 ? now + (ttl * 1000) : undefined,
    lastAccessedAt: now,
    hits: 0,
    misses: 0,
    version: 1,
    nodeId,
    syncStatus: 'synced',
    size,
    metadata: options?.metadata
  };
  
  // Update indexes
  const existing = cacheEntries.get(key);
  if (existing) {
    // Remove old tag indexes
    for (const tag of existing.tags) {
      entriesByTag.get(tag)?.delete(key);
    }
    entriesByNode.get(existing.nodeId)?.delete(key);
    entry.version = existing.version + 1;
  }
  
  cacheEntries.set(key, entry);
  
  // Add new tag indexes
  for (const tag of entry.tags) {
    if (!entriesByTag.has(tag)) {
      entriesByTag.set(tag, new Set());
    }
    entriesByTag.get(tag)!.add(key);
  }
  
  entriesByNode.get(nodeId)?.add(key);
  
  // Update node stats
  node.stats.entries = cacheEntries.size;
  node.stats.memoryUsed += size;
  node.updatedAt = now;
  
  // Create sync operation for replication
  if (nodeId) {
    createSyncOperation('set', key, value, nodeId, entry.version, { ttl, tags: entry.tags });
  }
  
  return entry;
}

/**
 * Get cache entry
 */
export function getCacheEntry(key: string): {
  found: boolean;
  entry?: CacheEntry;
  value?: unknown;
} {
  const entry = cacheEntries.get(key);
  
  if (!entry) {
    // Update miss stats
    const node = getActiveNodes()[0];
    if (node) {
      node.stats.misses++;
    }
    
    return { found: false };
  }
  
  // Check expiration
  if (entry.expiresAt && Date.now() > entry.expiresAt) {
    cacheEntries.delete(key);
    
    for (const tag of entry.tags) {
      entriesByTag.get(tag)?.delete(key);
    }
    entriesByNode.get(entry.nodeId)?.delete(key);
    
    return { found: false };
  }
  
  // Update access stats
  entry.lastAccessedAt = Date.now();
  entry.hits++;
  
  const node = cacheNodes.get(entry.nodeId);
  if (node) {
    node.stats.hits++;
  }
  
  return { found: true, entry, value: entry.value };
}

/**
 * Delete cache entry
 */
export function deleteCacheEntry(key: string): boolean {
  const entry = cacheEntries.get(key);
  if (!entry) return false;
  
  // Remove from indexes
  for (const tag of entry.tags) {
    entriesByTag.get(tag)?.delete(key);
  }
  entriesByNode.get(entry.nodeId)?.delete(key);
  
  // Update node stats
  const node = cacheNodes.get(entry.nodeId);
  if (node) {
    node.stats.entries--;
    node.stats.memoryUsed -= entry.size;
  }
  
  cacheEntries.delete(key);
  
  // Create sync operation
  createSyncOperation('delete', key, undefined, entry.nodeId, entry.version + 1);
  
  return true;
}

/**
 * Invalidate by tags
 */
export function invalidateByTags(tags: string[]): number {
  let invalidated = 0;
  
  for (const tag of tags) {
    const keys = entriesByTag.get(tag);
    if (keys) {
      for (const key of keys) {
        if (deleteCacheEntry(key)) {
          invalidated++;
        }
      }
    }
  }
  
  return invalidated;
}

/**
 * Invalidate by pattern
 */
export function invalidateByPattern(pattern: string): number {
  let invalidated = 0;
  const regex = new RegExp(pattern.replace(/\*/g, '.*'));
  
  for (const key of cacheEntries.keys()) {
    if (regex.test(key)) {
      if (deleteCacheEntry(key)) {
        invalidated++;
      }
    }
  }
  
  return invalidated;
}

/**
 * Clear cache
 */
export function clearCache(nodeId?: string): number {
  let cleared = 0;
  
  if (nodeId) {
    const nodeEntries = entriesByNode.get(nodeId);
    if (nodeEntries) {
      for (const key of nodeEntries) {
        cacheEntries.delete(key);
        cleared++;
      }
      nodeEntries.clear();
    }
  } else {
    cleared = cacheEntries.size;
    cacheEntries.clear();
    entriesByTag.clear();
    for (const nodeEntries of entriesByNode.values()) {
      nodeEntries.clear();
    }
  }
  
  return cleared;
}

/**
 * Evict entries
 */
function evictEntries(nodeId: string, count: number): number {
  const nodeEntries = entriesByNode.get(nodeId);
  if (!nodeEntries) return 0;
  
  const node = cacheNodes.get(nodeId);
  const evictionPolicy = node?.config.evictionPolicy || 'lru';
  
  let entries: CacheEntry[] = [];
  
  for (const key of nodeEntries) {
    const entry = cacheEntries.get(key);
    if (entry) {
      entries.push(entry);
    }
  }
  
  // Sort based on eviction policy
  switch (evictionPolicy) {
    case 'lru':
      entries.sort((a, b) => a.lastAccessedAt - b.lastAccessedAt);
      break;
    case 'lfu':
      entries.sort((a, b) => a.hits - b.hits);
      break;
    case 'ttl':
      entries.sort((a, b) => (a.expiresAt || Infinity) - (b.expiresAt || Infinity));
      break;
    case 'fifo':
      entries.sort((a, b) => a.createdAt - b.createdAt);
      break;
    default:
      // Random
      entries = entries.sort(() => Math.random() - 0.5);
  }
  
  // Evict lowest priority first
  entries.sort((a, b) => {
    const priorityOrder = { low: 0, normal: 1, high: 2, critical: 3 };
    return priorityOrder[a.priority] - priorityOrder[b.priority];
  });
  
  let evicted = 0;
  for (let i = 0; i < Math.min(count, entries.length); i++) {
    if (deleteCacheEntry(entries[i].key)) {
      evicted++;
    }
  }
  
  if (node) {
    node.stats.evictions += evicted;
  }
  
  return evicted;
}

// ============================================================================
// CLUSTER MANAGEMENT
// ============================================================================

/**
 * Create cache cluster
 */
export function createCacheCluster(
  name: string,
  nodeIds: string[],
  config: CacheCluster['config']
): CacheCluster {
  const cluster: CacheCluster = {
    id: `cluster_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    name,
    nodes: nodeIds,
    primaryNodeId: nodeIds[0],
    config,
    hashRing: {
      virtualNodes: 150,
      ring: []
    },
    stats: {
      totalHits: 0,
      totalMisses: 0,
      totalEvictions: 0,
      totalMemory: 0,
      totalEntries: 0,
      avgLatency: 0
    },
    status: 'healthy',
    createdAt: Date.now(),
    updatedAt: Date.now()
  };
  
  // Build hash ring
  cluster.hashRing.ring = buildHashRing(nodeIds, cluster.hashRing.virtualNodes);
  
  cacheClusters.set(cluster.id, cluster);
  return cluster;
}

/**
 * Get cache cluster
 */
export function getCacheCluster(id: string): CacheCluster | undefined {
  return cacheClusters.get(id);
}

/**
 * Build consistent hash ring
 */
function buildHashRing(nodeIds: string[], virtualNodes: number): Array<{ hash: number; nodeId: string }> {
  const ring: Array<{ hash: number; nodeId: string }> = [];
  
  for (const nodeId of nodeIds) {
    for (let i = 0; i < virtualNodes; i++) {
      const hash = simpleHash(`${nodeId}:${i}`);
      ring.push({ hash, nodeId });
    }
  }
  
  return ring.sort((a, b) => a.hash - b.hash);
}

/**
 * Get node for key (consistent hashing)
 */
export function getNodeForKey(clusterId: string, key: string): string | null {
  const cluster = cacheClusters.get(clusterId);
  if (!cluster || cluster.hashRing.ring.length === 0) return null;
  
  const hash = simpleHash(key);
  const ring = cluster.hashRing.ring;
  
  // Find first node with hash >= key hash
  for (const entry of ring) {
    if (entry.hash >= hash) {
      return entry.nodeId;
    }
  }
  
  // Wrap around to first node
  return ring[0].nodeId;
}

/**
 * Rebalance cluster
 */
export function rebalanceCluster(clusterId: string): {
  moved: number;
  errors: string[];
} {
  const cluster = cacheClusters.get(clusterId);
  if (!cluster) {
    return { moved: 0, errors: ['Cluster not found'] };
  }
  
  // Rebuild hash ring
  cluster.hashRing.ring = buildHashRing(cluster.nodes, cluster.hashRing.virtualNodes);
  cluster.updatedAt = Date.now();
  
  // Calculate keys to move
  let moved = 0;
  
  for (const [key, entry] of cacheEntries) {
    const correctNode = getNodeForKey(clusterId, key);
    if (correctNode && entry.nodeId !== correctNode) {
      // Move entry to correct node
      const oldNodeId = entry.nodeId;
      entry.nodeId = correctNode;
      
      entriesByNode.get(oldNodeId)?.delete(key);
      entriesByNode.get(correctNode)?.add(key);
      
      moved++;
    }
  }
  
  return { moved, errors: [] };
}

// ============================================================================
// SYNCHRONIZATION
// ============================================================================

/**
 * Create sync operation
 */
function createSyncOperation(
  type: SyncOperation['type'],
  key: string,
  value: unknown | undefined,
  sourceNodeId: string,
  sourceVersion: number,
  options?: { ttl?: number; tags?: string[] }
): SyncOperation {
  const activeNodes = getActiveNodes().map(n => n.id);
  const targetNodes = activeNodes.filter(id => id !== sourceNodeId);
  
  const operation: SyncOperation = {
    id: `sync_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    type,
    key,
    value,
    ttl: options?.ttl,
    tags: options?.tags,
    sourceNodeId,
    sourceVersion,
    targetNodes,
    completedNodes: [],
    createdAt: Date.now(),
    status: 'pending'
  };
  
  syncOperations.set(operation.id, operation);
  
  // Process sync asynchronously
  processSyncOperation(operation.id);
  
  return operation;
}

/**
 * Process sync operation
 */
async function processSyncOperation(operationId: string): Promise<void> {
  const operation = syncOperations.get(operationId);
  if (!operation) return;
  
  operation.status = 'syncing';
  
  // Simulate sync to other nodes
  for (const nodeId of operation.targetNodes) {
    // Check if node is active
    const node = cacheNodes.get(nodeId);
    if (!node || node.status !== 'active') {
      continue;
    }
    
    // Simulate network latency
    await new Promise(resolve => setTimeout(resolve, Math.random() * 10));
    
    // Apply operation to target node
    if (operation.type === 'set') {
      const existing = cacheEntries.get(operation.key);
      if (!existing || existing.version < operation.sourceVersion) {
        cacheEntries.set(operation.key, {
          key: operation.key,
          value: operation.value,
          ttl: operation.ttl || 0,
          priority: 'normal',
          tags: operation.tags || [],
          createdAt: Date.now(),
          updatedAt: Date.now(),
          expiresAt: operation.ttl ? Date.now() + operation.ttl * 1000 : undefined,
          lastAccessedAt: Date.now(),
          hits: 0,
          misses: 0,
          version: operation.sourceVersion,
          nodeId,
          syncStatus: 'synced',
          size: estimateSize(operation.value)
        });
      }
    } else if (operation.type === 'delete') {
      cacheEntries.delete(operation.key);
    }
    
    operation.completedNodes.push(nodeId);
  }
  
  operation.status = 'completed';
  operation.completedAt = Date.now();
}

/**
 * Get sync operations
 */
export function getSyncOperations(filters?: {
  status?: SyncOperation['status'];
  nodeId?: string;
  from?: number;
}): SyncOperation[] {
  let operations = Array.from(syncOperations.values());
  
  if (filters) {
    if (filters.status) {
      operations = operations.filter(o => o.status === filters.status);
    }
    if (filters.nodeId) {
      operations = operations.filter(o => 
        o.sourceNodeId === filters.nodeId || 
        o.targetNodes.includes(filters.nodeId!)
      );
    }
    if (filters.from) {
      operations = operations.filter(o => o.createdAt >= filters.from!);
    }
  }
  
  return operations.sort((a, b) => b.createdAt - a.createdAt);
}

/**
 * Resolve conflict
 */
export function resolveConflict(
  key: string,
  strategy: ConflictResolution['strategy']
): ConflictResolution | null {
  // Find all versions of the key across nodes
  const entries: ConflictResolution['entries'] = [];
  
  for (const [nodeId, nodeEntries] of entriesByNode) {
    if (nodeEntries.has(key)) {
      const entry = cacheEntries.get(key);
      if (entry) {
        entries.push({
          nodeId,
          value: entry.value,
          version: entry.version,
          timestamp: entry.updatedAt
        });
      }
    }
  }
  
  if (entries.length <= 1) return null; // No conflict
  
  const resolution: ConflictResolution = {
    id: `conflict_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    key,
    entries,
    strategy,
    detectedAt: Date.now()
  };
  
  // Apply resolution strategy
  switch (strategy) {
    case 'last_write_wins':
      entries.sort((a, b) => b.timestamp - a.timestamp);
      resolution.resolvedValue = entries[0].value;
      resolution.resolvedVersion = entries[0].version;
      break;
    case 'first_write_wins':
      entries.sort((a, b) => a.timestamp - b.timestamp);
      resolution.resolvedValue = entries[0].value;
      resolution.resolvedVersion = entries[0].version;
      break;
    default:
      resolution.status = 'manual_required';
  }
  
  if (resolution.resolvedValue !== undefined) {
    // Apply resolved value
    setCacheEntry(key, resolution.resolvedValue, { ttl: 0 });
    resolution.status = 'resolved';
    resolution.resolvedAt = Date.now();
  }
  
  conflictResolutions.set(resolution.id, resolution);
  
  return resolution;
}

// ============================================================================
// CACHE WARMING
// ============================================================================

/**
 * Create warming job
 */
export function createWarmingJob(
  config: Omit<CacheWarmingJob, 'id' | 'createdAt' | 'updatedAt' | 'status' | 'lastRun' | 'lastError' | 'stats'>
): CacheWarmingJob {
  const job: CacheWarmingJob = {
    ...config,
    id: `warm_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    status: 'pending',
    stats: {
      totalRuns: 0,
      keysWarmed: 0,
      avgDuration: 0
    },
    createdAt: Date.now(),
    updatedAt: Date.now()
  };
  
  warmingJobs.set(job.id, job);
  return job;
}

/**
 * Run warming job
 */
export async function runWarmingJob(jobId: string): Promise<{
  success: boolean;
  keysWarmed: number;
  error?: string;
}> {
  const job = warmingJobs.get(jobId);
  if (!job) {
    return { success: false, keysWarmed: 0, error: 'Job not found' };
  }
  
  job.status = 'running';
  job.lastRun = Date.now();
  const startTime = Date.now();
  
  try {
    // Simulate warming - generate keys based on pattern
    const keysToWarm = generateKeysFromPattern(job.keyPattern, 100);
    let keysWarmed = 0;
    
    for (const key of keysToWarm) {
      // Simulate fetching data from source
      const value = { key, data: `warmed_data_${Date.now()}`, timestamp: Date.now() };
      
      // Distribute across target nodes
      for (const nodeId of job.targetNodes) {
        setCacheEntry(key, value, {
          ttl: job.ttl,
          priority: job.priority,
          nodeId
        });
      }
      
      keysWarmed++;
    }
    
    const duration = Date.now() - startTime;
    
    job.status = 'completed';
    job.stats.totalRuns++;
    job.stats.keysWarmed += keysWarmed;
    job.stats.lastDuration = duration;
    job.stats.avgDuration = (job.stats.avgDuration * (job.stats.totalRuns - 1) + duration) / job.stats.totalRuns;
    job.updatedAt = Date.now();
    
    return { success: true, keysWarmed };
    
  } catch (error) {
    job.status = 'failed';
    job.lastError = error instanceof Error ? error.message : 'Unknown error';
    job.updatedAt = Date.now();
    
    return { success: false, keysWarmed: 0, error: job.lastError };
  }
}

/**
 * Generate keys from pattern
 */
function generateKeysFromPattern(pattern: string, count: number): string[] {
  const keys: string[] = [];
  
  for (let i = 0; i < count; i++) {
    keys.push(pattern.replace('{n}', String(i)).replace('{i}', String(i)));
  }
  
  return keys;
}

// ============================================================================
// INVALIDATION RULES
// ============================================================================

/**
 * Create invalidation rule
 */
export function createInvalidationRule(
  config: Omit<CacheInvalidationRule, 'id' | 'createdAt' | 'updatedAt' | 'lastTriggered' | 'triggerCount'>
): CacheInvalidationRule {
  const rule: CacheInvalidationRule = {
    ...config,
    id: `rule_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    triggerCount: 0,
    createdAt: Date.now(),
    updatedAt: Date.now()
  };
  
  invalidationRules.set(rule.id, rule);
  return rule;
}

/**
 * Trigger invalidation rule
 */
export function triggerInvalidationRule(ruleId: string): {
  triggered: boolean;
  invalidated: number;
  error?: string;
} {
  const rule = invalidationRules.get(ruleId);
  if (!rule || !rule.enabled) {
    return { triggered: false, invalidated: 0, error: 'Rule not found or disabled' };
  }
  
  let invalidated = 0;
  
  switch (rule.target.type) {
    case 'keys':
      for (const key of rule.target.keys || []) {
        if (deleteCacheEntry(key)) invalidated++;
      }
      break;
    case 'tags':
      invalidated = invalidateByTags(rule.target.tags || []);
      break;
    case 'pattern':
      invalidated = invalidateByPattern(rule.target.pattern || '');
      break;
    case 'all':
      invalidated = clearCache();
      break;
  }
  
  rule.lastTriggered = Date.now();
  rule.triggerCount++;
  rule.updatedAt = Date.now();
  
  return { triggered: true, invalidated };
}

// ============================================================================
// STATISTICS
// ============================================================================

/**
 * Get cache statistics
 */
export function getCacheStats(nodeId?: string, clusterId?: string): CacheStatistics {
  const now = Date.now();
  
  let relevantEntries = Array.from(cacheEntries.values());
  
  if (nodeId) {
    relevantEntries = relevantEntries.filter(e => e.nodeId === nodeId);
  }
  
  const hits = relevantEntries.reduce((sum, e) => sum + e.hits, 0);
  const misses = relevantEntries.reduce((sum, e) => sum + e.misses, 0);
  const memoryUsed = relevantEntries.reduce((sum, e) => sum + e.size, 0);
  
  const syncOps = Array.from(syncOperations.values())
    .filter(o => !nodeId || o.sourceNodeId === nodeId || o.targetNodes.includes(nodeId));
  
  return {
    nodeId,
    clusterId,
    period: { start: now - 3600000, end: now },
    operations: {
      gets: hits + misses,
      sets: syncOps.filter(o => o.type === 'set').length,
      deletes: syncOps.filter(o => o.type === 'delete').length,
      increments: 0,
      appends: 0
    },
    performance: {
      avgGetLatency: 5.2,
      avgSetLatency: 12.5,
      p50Latency: 3.1,
      p95Latency: 15.8,
      p99Latency: 45.2,
      throughput: 10000
    },
    memory: {
      used: memoryUsed,
      total: nodeId ? (cacheNodes.get(nodeId)?.maxMemory || 0) : 
             Array.from(cacheNodes.values()).reduce((sum, n) => sum + n.maxMemory, 0),
      fragmentation: 0.15,
      evictions: Array.from(cacheNodes.values())
        .filter(n => !nodeId || n.id === nodeId)
        .reduce((sum, n) => sum + n.stats.evictions, 0)
    },
    hitRate: {
      hits,
      misses,
      ratio: hits + misses > 0 ? hits / (hits + misses) : 0
    },
    sync: {
      operationsSynced: syncOps.filter(o => o.status === 'completed').length,
      conflicts: conflictResolutions.size,
      avgSyncLatency: 25.5
    }
  };
}

/**
 * Get distributed cache statistics
 */
export function getDistributedCacheStats(): {
  nodes: { total: number; active: number };
  entries: { total: number; totalSize: number };
  clusters: { total: number; healthy: number };
  sync: { pending: number; completed: number; failed: number };
} {
  return {
    nodes: {
      total: cacheNodes.size,
      active: getActiveNodes().length
    },
    entries: {
      total: cacheEntries.size,
      totalSize: Array.from(cacheEntries.values()).reduce((sum, e) => sum + e.size, 0)
    },
    clusters: {
      total: cacheClusters.size,
      healthy: Array.from(cacheClusters.values()).filter(c => c.status === 'healthy').length
    },
    sync: {
      pending: Array.from(syncOperations.values()).filter(o => o.status === 'pending').length,
      completed: Array.from(syncOperations.values()).filter(o => o.status === 'completed').length,
      failed: Array.from(syncOperations.values()).filter(o => o.status === 'failed').length
    }
  };
}

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

/**
 * Simple hash function
 */
function simpleHash(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash);
}

/**
 * Estimate size of value
 */
function estimateSize(value: unknown): number {
  if (value === null || value === undefined) return 0;
  
  if (typeof value === 'string') return value.length * 2;
  if (typeof value === 'number') return 8;
  if (typeof value === 'boolean') return 4;
  
  if (typeof value === 'object') {
    return JSON.stringify(value).length * 2;
  }
  
  return 100; // Default estimate
}

// ============================================================================
// TESTS
// ============================================================================

/**
 * Run distributed cache tests
 */
export function runDistributedCacheTests(): {
  passed: boolean;
  tests: { total: number; passed: number; failed: number };
  results: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const results: Array<{ name: string; passed: boolean; error?: string }> = [];
  
  // Test 1: Register Cache Node
  try {
    const node = registerCacheNode({
      name: 'Test Node',
      region: 'us-east-1',
      host: 'localhost',
      port: 6379,
      protocol: 'redis',
      maxMemory: 1073741824,
      maxEntries: 100000,
      config: {
        evictionPolicy: 'lru',
        defaultTTL: 3600,
        maxKeySize: 1024,
        maxValueSize: 1048576,
        compression: true,
        serialization: 'json'
      }
    });
    results.push({ name: 'Register Cache Node', passed: !!node.id });
  } catch (error) {
    results.push({ name: 'Register Cache Node', passed: false, error: String(error) });
  }
  
  // Test 2: Set Cache Entry
  try {
    const entry = setCacheEntry('test-key', { data: 'test-value' }, {
      ttl: 300,
      tags: ['test', 'demo']
    });
    results.push({ name: 'Set Cache Entry', passed: !!entry?.key });
  } catch (error) {
    results.push({ name: 'Set Cache Entry', passed: false, error: String(error) });
  }
  
  // Test 3: Get Cache Entry
  try {
    const result = getCacheEntry('test-key');
    results.push({ name: 'Get Cache Entry', passed: result.found && result.value?.data === 'test-value' });
  } catch (error) {
    results.push({ name: 'Get Cache Entry', passed: false, error: String(error) });
  }
  
  // Test 4: Invalidate by Tags
  try {
    setCacheEntry('tag-test-1', { data: 'value1' }, { tags: ['tag1'] });
    setCacheEntry('tag-test-2', { data: 'value2' }, { tags: ['tag1'] });
    const invalidated = invalidateByTags(['tag1']);
    results.push({ name: 'Invalidate by Tags', passed: invalidated >= 2 });
  } catch (error) {
    results.push({ name: 'Invalidate by Tags', passed: false, error: String(error) });
  }
  
  // Test 5: Create Cluster
  try {
    const nodes = getActiveNodes();
    const cluster = createCacheCluster('Test Cluster', nodes.map(n => n.id), {
      consistencyLevel: 'eventual',
      replicationFactor: 2,
      readQuorum: 1,
      writeQuorum: 1,
      syncInterval: 1000,
      heartbeatInterval: 5000,
      failureThreshold: 3,
      recoveryTimeout: 30000
    });
    results.push({ name: 'Create Cluster', passed: !!cluster.id });
  } catch (error) {
    results.push({ name: 'Create Cluster', passed: false, error: String(error) });
  }
  
  // Test 6: Create Warming Job
  try {
    const job = createWarmingJob({
      name: 'Test Warming',
      dataSource: { type: 'function' },
      keyPattern: 'warm:{n}',
      schedule: { type: 'once' },
      targetNodes: getActiveNodes().map(n => n.id),
      ttl: 3600,
      priority: 'normal'
    });
    results.push({ name: 'Create Warming Job', passed: !!job.id });
  } catch (error) {
    results.push({ name: 'Create Warming Job', passed: false, error: String(error) });
  }
  
  // Test 7: Delete Cache Entry
  try {
    const deleted = deleteCacheEntry('test-key');
    results.push({ name: 'Delete Cache Entry', passed: deleted });
  } catch (error) {
    results.push({ name: 'Delete Cache Entry', passed: false, error: String(error) });
  }
  
  // Test 8: Get Statistics
  try {
    const stats = getDistributedCacheStats();
    results.push({ name: 'Get Statistics', passed: stats.nodes.total > 0 });
  } catch (error) {
    results.push({ name: 'Get Statistics', passed: false, error: String(error) });
  }
  
  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;
  
  return {
    passed: failed === 0,
    tests: { total: results.length, passed, failed },
    results
  };
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

const distributedCache = {
  // Node Management
  registerCacheNode,
  getCacheNode,
  getAllCacheNodes,
  getActiveNodes,
  updateNodeHeartbeat,
  checkNodeHealth,
  removeCacheNode,
  
  // Cache Operations
  setCacheEntry,
  getCacheEntry,
  deleteCacheEntry,
  invalidateByTags,
  invalidateByPattern,
  clearCache,
  
  // Cluster Management
  createCacheCluster,
  getCacheCluster,
  getNodeForKey,
  rebalanceCluster,
  
  // Synchronization
  getSyncOperations,
  resolveConflict,
  
  // Warming
  createWarmingJob,
  runWarmingJob,
  
  // Invalidation
  createInvalidationRule,
  triggerInvalidationRule,
  
  // Statistics
  getCacheStats,
  getDistributedCacheStats,
  
  // Tests
  runDistributedCacheTests
};

export default distributedCache;
