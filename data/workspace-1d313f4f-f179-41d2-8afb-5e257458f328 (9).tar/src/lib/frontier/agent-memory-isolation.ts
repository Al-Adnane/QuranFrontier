/**
 * Agent Memory Isolation
 * =======================
 * 
 * Isolated and encrypted memory for AI agents.
 * Provides secure memory compartments with access control.
 * 
 * Features:
 * - Memory Compartments
 * - Encryption at Rest
 * - Access Control
 * - Memory Wiping
 * - Isolation Levels
 * - Secure Key Management
 * 
 * @module frontier/agent-memory-isolation
 * @version 1.0.0
 */

// ============================================================================
// TYPES
// ============================================================================

export type IsolationLevel = 'shared' | 'isolated' | 'strict' | 'air_gap';
export type MemoryStatus = 'active' | 'frozen' | 'wiped' | 'error';
export type AccessPermission = 'read' | 'write' | 'delete' | 'admin';

export interface MemoryCompartment {
  id: string;
  agentId: string;
  name: string;
  
  // Isolation
  isolationLevel: IsolationLevel;
  parentCompartment?: string;
  
  // Configuration
  config: {
    maxSizeMB: number;
    encryptionEnabled: boolean;
    encryptionAlgorithm: 'AES-256-GCM' | 'ChaCha20-Poly1305';
    autoWipeOnDelete: boolean;
    retentionMs: number;
  };
  
  // State
  usedSizeMB: number;
  entryCount: number;
  status: MemoryStatus;
  
  // Access Control
  accessControl: AccessControlEntry[];
  
  // Encryption
  encryptionKey?: string;
  keyVersion: number;
  
  // Statistics
  stats: {
    totalReads: number;
    totalWrites: number;
    totalDeletes: number;
    lastAccess: number;
  };
  
  createdAt: number;
  updatedAt: number;
}

export interface AccessControlEntry {
  id: string;
  agentId: string;
  compartmentId: string;
  permissions: AccessPermission[];
  grantedBy: string;
  grantedAt: number;
  expiresAt?: number;
  conditions?: {
    timeWindow?: { start: number; end: number };
    maxAccessCount?: number;
    accessCount: number;
  };
}

export interface MemoryEntry {
  id: string;
  compartmentId: string;
  
  // Content
  key: string;
  value: unknown;
  encrypted: boolean;
  encryptedValue?: string;
  
  // Metadata
  contentType: string;
  sizeBytes: number;
  tags: string[];
  
  // Security
  classification: 'public' | 'internal' | 'confidential' | 'secret';
  checksum: string;
  
  // Access
  readCount: number;
  writeCount: number;
  
  // Timestamps
  createdAt: number;
  updatedAt: number;
  accessedAt: number;
  expiresAt?: number;
}

export interface MemorySnapshot {
  id: string;
  compartmentId: string;
  
  // Snapshot
  name: string;
  description?: string;
  entryCount: number;
  sizeMB: number;
  
  // Encryption
  encrypted: boolean;
  checksum: string;
  
  // Timestamps
  createdAt: number;
  expiresAt?: number;
}

export interface WipeRecord {
  id: string;
  compartmentId: string;
  
  // Details
  triggeredBy: string;
  reason: string;
  method: 'soft' | 'secure' | 'crypto_shred';
  
  // Statistics
  entriesWiped: number;
  bytesWiped: number;
  
  timestamp: number;
}

export interface EncryptionKey {
  id: string;
  compartmentId: string;
  version: number;
  algorithm: string;
  encryptedKey: string;
  createdAt: number;
  expiresAt?: number;
  status: 'active' | 'rotating' | 'deprecated' | 'revoked';
}

// ============================================================================
// STORAGE
// ============================================================================

const compartments = new Map<string, MemoryCompartment>();
const entries = new Map<string, MemoryEntry>();
const accessControl = new Map<string, AccessControlEntry>();
const snapshots = new Map<string, MemorySnapshot>();
const wipeRecords = new Map<string, WipeRecord>();
const encryptionKeys = new Map<string, EncryptionKey>();

// Indexes
const entriesByCompartment = new Map<string, Set<string>>();
const accessByAgent = new Map<string, Set<string>>();

// ============================================================================
// COMPARTMENT MANAGEMENT
// ============================================================================

export function createCompartment(config: {
  agentId: string;
  name: string;
  isolationLevel: IsolationLevel;
  maxSizeMB: number;
  encryptionEnabled?: boolean;
  autoWipeOnDelete?: boolean;
  retentionMs?: number;
}): MemoryCompartment {
  const compartment: MemoryCompartment = {
    id: `comp_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
    agentId: config.agentId,
    name: config.name,
    isolationLevel: config.isolationLevel,
    config: {
      maxSizeMB: config.maxSizeMB,
      encryptionEnabled: config.encryptionEnabled ?? true,
      encryptionAlgorithm: 'AES-256-GCM',
      autoWipeOnDelete: config.autoWipeOnDelete ?? true,
      retentionMs: config.retentionMs || 30 * 24 * 60 * 60 * 1000 // 30 days
    },
    usedSizeMB: 0,
    entryCount: 0,
    status: 'active',
    accessControl: [],
    keyVersion: 1,
    stats: {
      totalReads: 0,
      totalWrites: 0,
      totalDeletes: 0,
      lastAccess: Date.now()
    },
    createdAt: Date.now(),
    updatedAt: Date.now()
  };
  
  // Generate encryption key if enabled
  if (compartment.config.encryptionEnabled) {
    const key = generateEncryptionKey(compartment.id);
    compartment.encryptionKey = key.id;
  }
  
  compartments.set(compartment.id, compartment);
  entriesByCompartment.set(compartment.id, new Set());
  
  // Grant owner full access
  grantAccess(compartment.id, config.agentId, ['read', 'write', 'delete', 'admin'], 'system');
  
  return compartment;
}

export function getCompartment(id: string): MemoryCompartment | undefined {
  return compartments.get(id);
}

export function getCompartmentsByAgent(agentId: string): MemoryCompartment[] {
  return Array.from(compartments.values()).filter(c => c.agentId === agentId);
}

export function freezeCompartment(id: string): boolean {
  const compartment = compartments.get(id);
  if (!compartment) return false;
  
  compartment.status = 'frozen';
  compartment.updatedAt = Date.now();
  return true;
}

// ============================================================================
// ACCESS CONTROL
// ============================================================================

export function grantAccess(
  compartmentId: string,
  agentId: string,
  permissions: AccessPermission[],
  grantedBy: string,
  expiresAt?: number,
  conditions?: AccessControlEntry['conditions']
): AccessControlEntry | null {
  const compartment = compartments.get(compartmentId);
  if (!compartment) return null;
  
  const ace: AccessControlEntry = {
    id: `ace_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
    agentId,
    compartmentId,
    permissions,
    grantedBy,
    grantedAt: Date.now(),
    expiresAt,
    conditions: conditions || { accessCount: 0 }
  };
  
  accessControl.set(ace.id, ace);
  
  // Update indexes
  if (!accessByAgent.has(agentId)) {
    accessByAgent.set(agentId, new Set());
  }
  accessByAgent.get(agentId)!.add(ace.id);
  
  compartment.accessControl.push(ace);
  compartment.updatedAt = Date.now();
  
  return ace;
}

export function checkAccess(
  compartmentId: string,
  agentId: string,
  permission: AccessPermission
): { allowed: boolean; ace?: AccessControlEntry; reason?: string } {
  const compartment = compartments.get(compartmentId);
  if (!compartment) {
    return { allowed: false, reason: 'Compartment not found' };
  }
  
  if (compartment.status !== 'active') {
    return { allowed: false, reason: 'Compartment not active' };
  }
  
  // Owner always has access
  if (compartment.agentId === agentId) {
    return { allowed: true };
  }
  
  // Check ACEs
  const aceIds = accessByAgent.get(agentId);
  if (!aceIds) {
    return { allowed: false, reason: 'No access granted' };
  }
  
  for (const aceId of aceIds) {
    const ace = accessControl.get(aceId);
    if (ace && ace.compartmentId === compartmentId) {
      // Check expiration
      if (ace.expiresAt && Date.now() > ace.expiresAt) {
        continue;
      }
      
      // Check conditions
      if (ace.conditions?.maxAccessCount !== undefined) {
        if (ace.conditions.accessCount >= ace.conditions.maxAccessCount) {
          continue;
        }
      }
      
      if (ace.permissions.includes(permission) || ace.permissions.includes('admin')) {
        // Update access count
        if (ace.conditions) {
          ace.conditions.accessCount++;
        }
        return { allowed: true, ace };
      }
    }
  }
  
  return { allowed: false, reason: 'Permission denied' };
}

export function revokeAccess(aceId: string): boolean {
  const ace = accessControl.get(aceId);
  if (!ace) return false;
  
  accessControl.delete(aceId);
  accessByAgent.get(ace.agentId)?.delete(aceId);
  
  const compartment = compartments.get(ace.compartmentId);
  if (compartment) {
    compartment.accessControl = compartment.accessControl.filter(a => a.id !== aceId);
    compartment.updatedAt = Date.now();
  }
  
  return true;
}

// ============================================================================
// MEMORY OPERATIONS
// ============================================================================

export function writeMemory(
  compartmentId: string,
  agentId: string,
  key: string,
  value: unknown,
  options?: {
    classification?: MemoryEntry['classification'];
    tags?: string[];
    ttl?: number;
  }
): MemoryEntry | null {
  const compartment = compartments.get(compartmentId);
  if (!compartment || compartment.status !== 'active') return null;
  
  // Check access
  const access = checkAccess(compartmentId, agentId, 'write');
  if (!access.allowed) return null;
  
  // Serialize and encrypt
  const serialized = JSON.stringify(value);
  const sizeBytes = Buffer.byteLength(serialized);
  const sizeMB = sizeBytes / (1024 * 1024);
  
  // Check capacity
  if (compartment.usedSizeMB + sizeMB > compartment.config.maxSizeMB) {
    return null;
  }
  
  let encrypted = false;
  let encryptedValue: string | undefined;
  
  if (compartment.config.encryptionEnabled && compartment.encryptionKey) {
    encryptedValue = encryptData(serialized, compartment.encryptionKey);
    encrypted = true;
  }
  
  const entry: MemoryEntry = {
    id: `entry_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
    compartmentId,
    key,
    value: compartment.config.encryptionEnabled ? undefined : value,
    encrypted,
    encryptedValue,
    contentType: 'application/json',
    sizeBytes,
    tags: options?.tags || [],
    classification: options?.classification || 'internal',
    checksum: generateChecksum(serialized),
    readCount: 0,
    writeCount: 1,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    accessedAt: Date.now(),
    expiresAt: options?.ttl ? Date.now() + options.ttl : undefined
  };
  
  entries.set(entry.id, entry);
  entriesByCompartment.get(compartmentId)?.add(entry.id);
  
  compartment.usedSizeMB += sizeMB;
  compartment.entryCount++;
  compartment.stats.totalWrites++;
  compartment.stats.lastAccess = Date.now();
  compartment.updatedAt = Date.now();
  
  return entry;
}

export function readMemory(
  compartmentId: string,
  agentId: string,
  key: string
): { found: boolean; value?: unknown; entry?: MemoryEntry } {
  const compartment = compartments.get(compartmentId);
  if (!compartment || compartment.status !== 'active') {
    return { found: false };
  }
  
  // Check access
  const access = checkAccess(compartmentId, agentId, 'read');
  if (!access.allowed) {
    return { found: false };
  }
  
  // Find entry
  const compartmentEntries = entriesByCompartment.get(compartmentId);
  if (!compartmentEntries) {
    return { found: false };
  }
  
  for (const entryId of compartmentEntries) {
    const entry = entries.get(entryId);
    if (entry && entry.key === key) {
      // Check expiration
      if (entry.expiresAt && Date.now() > entry.expiresAt) {
        return { found: false };
      }
      
      // Decrypt if needed
      let value = entry.value;
      if (entry.encrypted && entry.encryptedValue && compartment.encryptionKey) {
        const decrypted = decryptData(entry.encryptedValue, compartment.encryptionKey);
        value = JSON.parse(decrypted);
      }
      
      entry.readCount++;
      entry.accessedAt = Date.now();
      compartment.stats.totalReads++;
      compartment.stats.lastAccess = Date.now();
      
      return { found: true, value, entry };
    }
  }
  
  return { found: false };
}

export function deleteMemory(
  compartmentId: string,
  agentId: string,
  key: string
): boolean {
  const compartment = compartments.get(compartmentId);
  if (!compartment) return false;
  
  // Check access
  const access = checkAccess(compartmentId, agentId, 'delete');
  if (!access.allowed) return false;
  
  const compartmentEntries = entriesByCompartment.get(compartmentId);
  if (!compartmentEntries) return false;
  
  for (const entryId of compartmentEntries) {
    const entry = entries.get(entryId);
    if (entry && entry.key === key) {
      // Wipe data
      if (compartment.config.autoWipeOnDelete) {
        entry.value = undefined;
        entry.encryptedValue = undefined;
      }
      
      compartment.usedSizeMB -= entry.sizeBytes / (1024 * 1024);
      compartment.entryCount--;
      compartment.stats.totalDeletes++;
      compartment.updatedAt = Date.now();
      
      entries.delete(entryId);
      compartmentEntries.delete(entryId);
      
      return true;
    }
  }
  
  return false;
}

// ============================================================================
// ENCRYPTION
// ============================================================================

export function generateEncryptionKey(compartmentId: string): EncryptionKey {
  const key: EncryptionKey = {
    id: `key_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
    compartmentId,
    version: 1,
    algorithm: 'AES-256-GCM',
    encryptedKey: `enc_${Math.random().toString(36).substr(2, 64)}`,
    createdAt: Date.now(),
    status: 'active'
  };
  
  encryptionKeys.set(key.id, key);
  return key;
}

export function rotateKey(compartmentId: string): EncryptionKey | null {
  const compartment = compartments.get(compartmentId);
  if (!compartment) return null;
  
  // Mark old key as deprecated
  if (compartment.encryptionKey) {
    const oldKey = encryptionKeys.get(compartment.encryptionKey);
    if (oldKey) {
      oldKey.status = 'deprecated';
    }
  }
  
  // Generate new key
  const newKey = generateEncryptionKey(compartmentId);
  newKey.version = (compartment.keyVersion || 0) + 1;
  
  compartment.encryptionKey = newKey.id;
  compartment.keyVersion = newKey.version;
  compartment.updatedAt = Date.now();
  
  // In production, would re-encrypt all entries with new key
  
  return newKey;
}

function encryptData(data: string, keyId: string): string {
  // Simulate encryption
  return `enc:${Buffer.from(data).toString('base64')}:${keyId.substring(0, 8)}`;
}

function decryptData(encrypted: string, keyId: string): string {
  // Simulate decryption
  const parts = encrypted.split(':');
  if (parts.length >= 2) {
    return Buffer.from(parts[1], 'base64').toString('utf-8');
  }
  return encrypted;
}

function generateChecksum(data: string): string {
  // Simple checksum
  let hash = 0;
  for (let i = 0; i < data.length; i++) {
    hash = ((hash << 5) - hash) + data.charCodeAt(i);
    hash = hash & hash;
  }
  return Math.abs(hash).toString(16);
}

// ============================================================================
// MEMORY WIPING
// ============================================================================

export function wipeCompartment(
  compartmentId: string,
  method: WipeRecord['method'],
  triggeredBy: string,
  reason: string
): WipeRecord | null {
  const compartment = compartments.get(compartmentId);
  if (!compartment) return null;
  
  const entryIds = entriesByCompartment.get(compartmentId) || new Set();
  let entriesWiped = 0;
  let bytesWiped = 0;
  
  for (const entryId of entryIds) {
    const entry = entries.get(entryId);
    if (entry) {
      entriesWiped++;
      bytesWiped += entry.sizeBytes;
      
      if (method === 'crypto_shred') {
        // Overwrite with random data multiple times
        entry.value = null;
        entry.encryptedValue = null;
      } else if (method === 'secure') {
        // Single overwrite
        entry.value = undefined;
        entry.encryptedValue = undefined;
      }
      
      entries.delete(entryId);
    }
  }
  
  entryIds.clear();
  
  compartment.usedSizeMB = 0;
  compartment.entryCount = 0;
  compartment.status = 'wiped';
  compartment.updatedAt = Date.now();
  
  const record: WipeRecord = {
    id: `wipe_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
    compartmentId,
    triggeredBy,
    reason,
    method,
    entriesWiped,
    bytesWiped,
    timestamp: Date.now()
  };
  
  wipeRecords.set(record.id, record);
  return record;
}

// ============================================================================
// STATISTICS
// ============================================================================

export function getMemoryStats(): {
  compartments: { total: number; active: number };
  entries: { total: number; totalSizeMB: number };
  access: { total: number };
  encryption: { keysActive: number };
} {
  return {
    compartments: {
      total: compartments.size,
      active: Array.from(compartments.values()).filter(c => c.status === 'active').length
    },
    entries: {
      total: entries.size,
      totalSizeMB: Array.from(compartments.values()).reduce((sum, c) => sum + c.usedSizeMB, 0)
    },
    access: {
      total: accessControl.size
    },
    encryption: {
      keysActive: Array.from(encryptionKeys.values()).filter(k => k.status === 'active').length
    }
  };
}

// ============================================================================
// TESTS
// ============================================================================

export function runAgentMemoryIsolationTests(): {
  passed: boolean;
  tests: { total: number; passed: number; failed: number };
  results: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const results: Array<{ name: string; passed: boolean; error?: string }> = [];
  
  // Test 1: Create Compartment
  try {
    const comp = createCompartment({
      agentId: 'test-agent',
      name: 'Test Memory',
      isolationLevel: 'isolated',
      maxSizeMB: 100
    });
    results.push({ name: 'Create Compartment', passed: !!comp.id });
  } catch (error) {
    results.push({ name: 'Create Compartment', passed: false, error: String(error) });
  }
  
  // Test 2: Write Memory
  try {
    const comp = Array.from(compartments.values())[0];
    const entry = writeMemory(comp.id, 'test-agent', 'test-key', { data: 'value' });
    results.push({ name: 'Write Memory', passed: !!entry?.id });
  } catch (error) {
    results.push({ name: 'Write Memory', passed: false, error: String(error) });
  }
  
  // Test 3: Read Memory
  try {
    const comp = Array.from(compartments.values())[0];
    const result = readMemory(comp.id, 'test-agent', 'test-key');
    results.push({ name: 'Read Memory', passed: result.found && result.value?.data === 'value' });
  } catch (error) {
    results.push({ name: 'Read Memory', passed: false, error: String(error) });
  }
  
  // Test 4: Grant Access
  try {
    const comp = Array.from(compartments.values())[0];
    const ace = grantAccess(comp.id, 'other-agent', ['read'], 'test-agent');
    results.push({ name: 'Grant Access', passed: !!ace?.id });
  } catch (error) {
    results.push({ name: 'Grant Access', passed: false, error: String(error) });
  }
  
  // Test 5: Get Statistics
  try {
    const stats = getMemoryStats();
    results.push({ name: 'Get Statistics', passed: stats.compartments.total > 0 });
  } catch (error) {
    results.push({ name: 'Get Statistics', passed: false, error: String(error) });
  }
  
  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;
  
  return {
    passed: failed === 0,
    tests: { total: results.length, passed, failed },
    results
  };
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

export default {
  createCompartment,
  getCompartment,
  getCompartmentsByAgent,
  freezeCompartment,
  grantAccess,
  checkAccess,
  revokeAccess,
  writeMemory,
  readMemory,
  deleteMemory,
  generateEncryptionKey,
  rotateKey,
  wipeCompartment,
  getMemoryStats,
  runAgentMemoryIsolationTests
};
