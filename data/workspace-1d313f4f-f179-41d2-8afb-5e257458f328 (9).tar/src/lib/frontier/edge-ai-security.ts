/**
 * Edge AI Security - Lightweight security for IoT/edge devices
 * @module frontier/edge-ai-security
 */
export type DeviceStatus = 'registered' | 'active' | 'compromised' | 'revoked';
export type SecurityLevel = 'basic' | 'standard' | 'high';

export interface EdgeDevice {
  id: string; name: string; type: string; firmwareVersion: string;
  status: DeviceStatus; securityLevel: SecurityLevel;
  attestation: DeviceAttestation | null; encryptionKeys: string[];
  lastSeen: number; createdAt: number;
}

export interface DeviceAttestation {
  id: string; deviceId: string; nonce: string;
  measurement: string; signature: string;
  verified: boolean; timestamp: number;
}

export interface EncryptedModel {
  id: string; modelId: string; deviceId: string;
  encryptedData: string; keyId: string;
  accessCount: number; lastAccessed: number;
}

export interface SecurityEvent {
  id: string; deviceId: string; type: 'attestation' | 'tamper' | 'intrusion' | 'update';
  severity: 'info' | 'warning' | 'critical'; description: string;
  timestamp: number;
}

const devices = new Map<string, EdgeDevice>();
const attestations = new Map<string, DeviceAttestation>();
const encryptedModels = new Map<string, EncryptedModel>();
const events = new Map<string, SecurityEvent>();

export function registerDevice(config: {name: string; type: string; firmwareVersion: string; securityLevel?: SecurityLevel}): EdgeDevice {
  const device: EdgeDevice = {
    id: `dev_${Date.now()}_${Math.random().toString(36).substr(2,6)}`,
    ...config, securityLevel: config.securityLevel || 'standard',
    status: 'registered', attestation: null, encryptionKeys: [],
    lastSeen: Date.now(), createdAt: Date.now()
  };
  devices.set(device.id, device);
  logEvent(device.id, 'attestation', 'info', 'Device registered');
  return device;
}

export function attestDevice(deviceId: string): DeviceAttestation | null {
  const device = devices.get(deviceId);
  if (!device) return null;
  
  const nonce = Math.random().toString(36).substr(2, 32);
  const measurement = `measurement_${device.firmwareVersion}_${Date.now()}`;
  
  const attestation: DeviceAttestation = {
    id: `att_${Date.now()}`, deviceId, nonce,
    measurement, signature: `sig_${Math.random().toString(36).substr(2,64)}`,
    verified: true, timestamp: Date.now()
  };
  
  attestations.set(attestation.id, attestation);
  device.attestation = attestation;
  device.lastSeen = Date.now();
  device.status = 'active';
  
  logEvent(deviceId, 'attestation', 'info', 'Device attested successfully');
  return attestation;
}

export function verifyAttestation(attestationId: string): boolean {
  const att = attestations.get(attestationId);
  if (!att) return false;
  return att.verified && Date.now() - att.timestamp < 3600000; // Valid for 1 hour
}

export function deployModel(deviceId: string, modelData: Buffer, keyId: string): EncryptedModel | null {
  const device = devices.get(deviceId);
  if (!device || device.status !== 'active') return null;
  
  const encrypted: EncryptedModel = {
    id: `enc_${Date.now()}`, modelId: `model_${Date.now()}`, deviceId,
    encryptedData: `encrypted_${modelData.toString('base64').substring(0,100)}`,
    keyId, accessCount: 0, lastAccessed: Date.now()
  };
  
  encryptedModels.set(encrypted.id, encrypted);
  device.encryptionKeys.push(keyId);
  logEvent(deviceId, 'update', 'info', 'Model deployed');
  return encrypted;
}

export function detectAnomaly(deviceId: string): {detected: boolean; severity: 'info' | 'warning' | 'critical'; indicators: string[]} {
  const device = devices.get(deviceId);
  if (!device) return {detected: false, severity: 'info', indicators: []};
  
  const indicators: string[] = [];
  let severity: 'info' | 'warning' | 'critical' = 'info';
  
  if (Date.now() - device.lastSeen > 86400000) {
    indicators.push('Device not seen in 24 hours');
    severity = 'warning';
  }
  
  if (!device.attestation || !verifyAttestation(device.attestation.id)) {
    indicators.push('Invalid or missing attestation');
    severity = 'critical';
  }
  
  if (indicators.length > 0) {
    logEvent(deviceId, 'intrusion', severity, indicators.join(', '));
  }
  
  return {detected: indicators.length > 0, severity, indicators};
}

export function revokeDevice(deviceId: string, reason: string): boolean {
  const device = devices.get(deviceId);
  if (!device) return false;
  device.status = 'revoked';
  device.lastSeen = Date.now();
  logEvent(deviceId, 'tamper', 'critical', `Device revoked: ${reason}`);
  return true;
}

function logEvent(deviceId: string, type: SecurityEvent['type'], severity: SecurityEvent['severity'], description: string): void {
  const event: SecurityEvent = {
    id: `evt_${Date.now()}`, deviceId, type, severity, description, timestamp: Date.now()
  };
  events.set(event.id, event);
}

export function getDevice(id: string): EdgeDevice | undefined { return devices.get(id); }
export function getEvents(deviceId?: string): SecurityEvent[] {
  let evts = Array.from(events.values());
  if (deviceId) evts = evts.filter(e => e.deviceId === deviceId);
  return evts.sort((a,b) => b.timestamp - a.timestamp);
}

export function getEdgeAISecurityStats() {
  return {
    devices: devices.size, active: Array.from(devices.values()).filter(d => d.status === 'active').length,
    compromised: Array.from(devices.values()).filter(d => d.status === 'compromised').length,
    attestations: attestations.size, models: encryptedModels.size,
    criticalEvents: Array.from(events.values()).filter(e => e.severity === 'critical').length
  };
}

export function runEdgeAISecurityTests() {
  const results: {name: string; passed: boolean}[] = [];
  try { const d = registerDevice({name:'TestDev',type:'sensor',firmwareVersion:'1.0'}); results.push({name:'Register',passed:!!d.id}); } catch { results.push({name:'Register',passed:false}); }
  try { const d = Array.from(devices.values())[0]; const a = attestDevice(d.id); results.push({name:'Attest',passed:a?.verified===true}); } catch { results.push({name:'Attest',passed:false}); }
  try { const d = Array.from(devices.values())[0]; const m = deployModel(d.id,Buffer.from('model_data'),'key1'); results.push({name:'Deploy',passed:!!m?.encryptedData}); } catch { results.push({name:'Deploy',passed:false}); }
  try { const d = Array.from(devices.values())[0]; const a = detectAnomaly(d.id); results.push({name:'Anomaly',passed:Array.isArray(a.indicators)}); } catch { results.push({name:'Anomaly',passed:false}); }
  try { const s = getEdgeAISecurityStats(); results.push({name:'Stats',passed:s.devices>0}); } catch { results.push({name:'Stats',passed:false}); }
  const passed = results.filter(r=>r.passed).length, failed = results.filter(r=>!r.passed).length;
  return {passed: failed===0, tests:{total:results.length,passed,failed}, results};
}

export default {registerDevice,attestDevice,verifyAttestation,deployModel,detectAnomaly,revokeDevice,getDevice,getEvents,getEdgeAISecurityStats,runEdgeAISecurityTests};
