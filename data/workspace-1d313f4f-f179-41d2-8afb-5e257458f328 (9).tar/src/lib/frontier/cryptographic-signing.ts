/**
 * Cryptographic Signing Module
 *
 * HMAC-SHA256 signing for decision tickets and data integrity.
 * Provides non-repudiation and tamper detection.
 *
 * @module frontier/cryptographic-signing
 * @version 9.1.0
 *
 * Capabilities:
 * - HMAC-SHA256 signing
 * - HMAC-SHA512 signing
 * - Signature verification
 * - Key management
 * - Signature chains
 * - Time-bound signatures
 * - Batch signing
 * - Multi-signature support
 * - Signature revocation
 * - Audit trail
 */

import { generateUUID, sha256Hash, sha512Hash, hmacSign } from '../crypto-utils';

// ============================================================================
// TYPES
// ============================================================================

/**
 * Signature algorithm
 */
export type SignatureAlgorithm = 'HMAC-SHA256' | 'HMAC-SHA512';

/**
 * Signed document
 */
export interface SignedDocument {
  /** Document ID */
  id: string;
  /** Document hash */
  hash: string;
  /** Signature */
  signature: string;
  /** Algorithm */
  algorithm: SignatureAlgorithm;
  /** Key ID used */
  keyId: string;
  /** Signer */
  signer: SignerInfo;
  /** Timestamp */
  timestamp: number;
  /** Expiration (optional) */
  expiresAt?: number;
  /** Status */
  status: 'valid' | 'expired' | 'revoked';
  /** Revocation info */
  revocation?: {
    reason: string;
    revokedAt: number;
    revokedBy: string;
  };
  /** Metadata */
  metadata: Record<string, unknown>;
}

/**
 * Signer information
 */
export interface SignerInfo {
  /** Signer ID */
  id: string;
  /** Signer type */
  type: 'user' | 'service' | 'system' | 'device';
  /** Signer name */
  name: string;
  /** Additional identity info */
  identity?: {
    email?: string;
    organization?: string;
    role?: string;
  };
}

/**
 * Signing key
 */
export interface SigningKey {
  /** Key ID */
  id: string;
  /** Key name */
  name: string;
  /** Secret key (hashed for storage) */
  secretHash: string;
  /** Algorithm */
  algorithm: SignatureAlgorithm;
  /** Key status */
  status: 'active' | 'rotating' | 'revoked' | 'expired';
  /** Created timestamp */
  createdAt: number;
  /** Expires timestamp */
  expiresAt?: number;
  /** Owner */
  owner: string;
  /** Key version */
  version: number;
  /** Usage count */
  usageCount: number;
  /** Last used */
  lastUsed?: number;
}

/**
 * Signature chain
 */
export interface SignatureChain {
  /** Chain ID */
  id: string;
  /** Chain name */
  name: string;
  /** Documents in chain */
  documents: ChainDocument[];
  /** Chain hash (hash of all document hashes) */
  chainHash: string;
  /** Created timestamp */
  createdAt: number;
  /** Last updated */
  updatedAt: number;
  /** Status */
  status: 'active' | 'sealed' | 'broken';
}

/**
 * Chain document
 */
export interface ChainDocument {
  /** Document ID */
  documentId: string;
  /** Document hash */
  hash: string;
  /** Signature */
  signature: string;
  /** Previous hash in chain */
  previousHash: string;
  /** Position in chain */
  position: number;
  /** Timestamp */
  timestamp: number;
}

/**
 * Verification result
 */
export interface VerificationResult {
  /** Verification ID */
  id: string;
  /** Document ID */
  documentId: string;
  /** Valid */
  valid: boolean;
  /** Status */
  status: 'valid' | 'invalid_signature' | 'expired' | 'revoked' | 'key_revoked' | 'chain_broken';
  /** Verification time (ms) */
  verificationTimeMs: number;
  /** Details */
  details?: string;
  /** Timestamp */
  timestamp: number;
}

/**
 * Batch signing result
 */
export interface BatchSigningResult {
  /** Batch ID */
  id: string;
  /** Signed documents */
  documents: SignedDocument[];
  /** Batch hash */
  batchHash: string;
  /** Total signing time (ms) */
  totalSigningTimeMs: number;
  /** Average signing time (ms) */
  avgSigningTimeMs: number;
  /** All successful */
  allSuccessful: boolean;
}

/**
 * Multi-signature request
 */
export interface MultiSignatureRequest {
  /** Request ID */
  id: string;
  /** Document hash */
  documentHash: string;
  /** Required signers */
  requiredSigners: string[];
  /** Collected signatures */
  signatures: Map<string, SignedDocument>;
  /** Threshold (min signatures needed) */
  threshold: number;
  /** Status */
  status: 'pending' | 'complete' | 'expired' | 'cancelled';
  /** Created timestamp */
  createdAt: number;
  /** Expires timestamp */
  expiresAt?: number;
}

/**
 * Revocation entry
 */
export interface RevocationEntry {
  /** Entry ID */
  id: string;
  /** Document or key ID */
  targetId: string;
  /** Target type */
  targetType: 'document' | 'key';
  /** Reason */
  reason: string;
  /** Revoked by */
  revokedBy: string;
  /** Timestamp */
  timestamp: number;
}

/**
 * Signing configuration
 */
export interface SigningConfig {
  /** Default algorithm */
  defaultAlgorithm: SignatureAlgorithm;
  /** Default key TTL (milliseconds) */
  defaultKeyTtl: number;
  /** Enable key rotation */
  enableKeyRotation: boolean;
  /** Key rotation interval (milliseconds) */
  keyRotationInterval: number;
  /** Max usage per key */
  maxKeyUsage: number;
  /** Enable audit logging */
  enableAuditLog: boolean;
}

/**
 * Audit entry
 */
export interface SigningAuditEntry {
  /** Entry ID */
  id: string;
  /** Action */
  action: 'sign' | 'verify' | 'revoke' | 'key_create' | 'key_rotate' | 'chain_add';
  /** Document/Key ID */
  targetId: string;
  /** Actor */
  actor: string;
  /** Timestamp */
  timestamp: number;
  /** Details */
  details: Record<string, unknown>;
}

// ============================================================================
// STORAGE
// ============================================================================

const documents = new Map<string, SignedDocument>();
const keys = new Map<string, SigningKey>();
const chains = new Map<string, SignatureChain>();
const multiSigRequests = new Map<string, MultiSignatureRequest>();
const revocations = new Map<string, RevocationEntry>();
const auditLog = new Map<string, SigningAuditEntry>();

// Configuration
let config: SigningConfig = {
  defaultAlgorithm: 'HMAC-SHA256',
  defaultKeyTtl: 365 * 24 * 60 * 60 * 1000, // 1 year
  enableKeyRotation: true,
  keyRotationInterval: 90 * 24 * 60 * 60 * 1000, // 90 days
  maxKeyUsage: 1000000,
  enableAuditLog: true
};

// Platform secret for key generation
const PLATFORM_SECRET = 'cryptographic_signing_secret_v1';

// ============================================================================
// CONFIGURATION
// ============================================================================

/**
 * Update configuration
 */
export function updateConfig(newConfig: Partial<SigningConfig>): SigningConfig {
  config = { ...config, ...newConfig };
  return config;
}

/**
 * Get configuration
 */
export function getConfig(): SigningConfig {
  return { ...config };
}

// ============================================================================
// KEY MANAGEMENT
// ============================================================================

/**
 * Create signing key
 */
export function createKey(params: {
  name: string;
  algorithm?: SignatureAlgorithm;
  owner: string;
  ttl?: number;
}): SigningKey {
  const id = `key_${generateUUID()}`;
  const algorithm = params.algorithm || config.defaultAlgorithm;
  const ttl = params.ttl || config.defaultKeyTtl;

  // Generate secret
  const secret = generateSecret(id, algorithm);
  const secretHash = sha256Hash(secret);

  const key: SigningKey = {
    id,
    name: params.name,
    secretHash,
    algorithm,
    status: 'active',
    createdAt: Date.now(),
    expiresAt: Date.now() + ttl,
    owner: params.owner,
    version: 1,
    usageCount: 0
  };

  keys.set(id, key);
  createAuditEntry('key_create', id, params.owner, { algorithm, ttl });

  return key;
}

/**
 * Get key
 */
export function getKey(keyId: string): SigningKey | undefined {
  return keys.get(keyId);
}

/**
 * Rotate key
 */
export function rotateKey(keyId: string, rotatedBy: string): SigningKey | null {
  const key = keys.get(keyId);
  if (!key || key.status !== 'active') return null;

  // Create new key version
  const newSecret = generateSecret(`${keyId}_v${key.version + 1}`, key.algorithm);
  const newSecretHash = sha256Hash(newSecret);

  key.secretHash = newSecretHash;
  key.version++;
  key.status = 'active';
  key.usageCount = 0;
  key.createdAt = Date.now();

  keys.set(keyId, key);
  createAuditEntry('key_rotate', keyId, rotatedBy, { newVersion: key.version });

  return key;
}

/**
 * Revoke key
 */
export function revokeKey(keyId: string, reason: string, revokedBy: string): SigningKey | null {
  const key = keys.get(keyId);
  if (!key) return null;

  key.status = 'revoked';
  keys.set(keyId, key);

  const revocation: RevocationEntry = {
    id: `revoke_${generateUUID()}`,
    targetId: keyId,
    targetType: 'key',
    reason,
    revokedBy,
    timestamp: Date.now()
  };

  revocations.set(revocation.id, revocation);
  createAuditEntry('revoke', keyId, revokedBy, { reason, type: 'key' });

  return key;
}

/**
 * List keys
 */
export function listKeys(owner?: string, status?: SigningKey['status']): SigningKey[] {
  let result = Array.from(keys.values());
  if (owner) {
    result = result.filter(k => k.owner === owner);
  }
  if (status) {
    result = result.filter(k => k.status === status);
  }
  return result;
}

/**
 * Generate secret for key
 */
function generateSecret(keyId: string, algorithm: SignatureAlgorithm): string {
  const data = `${PLATFORM_SECRET}:${keyId}:${algorithm}:${Date.now()}`;
  return algorithm === 'HMAC-SHA512' ? sha512Hash(data) : sha256Hash(data);
}

/**
 * Get actual secret for signing (reconstructed)
 */
function getKeySecret(key: SigningKey): string {
  // In production, this would retrieve from secure storage
  return generateSecret(key.id, key.algorithm);
}

// ============================================================================
// DOCUMENT SIGNING
// ============================================================================

/**
 * Sign document
 */
export function signDocument(params: {
  data: string | Buffer;
  keyId: string;
  signer: SignerInfo;
  expiresIn?: number;
  metadata?: Record<string, unknown>;
}): SignedDocument {
  const startTime = performance.now();
  const key = keys.get(params.keyId);

  if (!key) {
    throw new Error(`Key ${params.keyId} not found`);
  }

  if (key.status !== 'active') {
    throw new Error(`Key ${params.keyId} is not active`);
  }

  // Calculate document hash
  const dataString = typeof params.data === 'string' ? params.data : params.data.toString('base64');
  const hash = sha256Hash(dataString);

  // Generate signature
  const secret = getKeySecret(key);
  const signature = hmacSign(hash, secret);

  const now = Date.now();
  const id = `doc_${generateUUID()}`;

  const document: SignedDocument = {
    id,
    hash,
    signature,
    algorithm: key.algorithm,
    keyId: key.id,
    signer: params.signer,
    timestamp: now,
    expiresAt: params.expiresIn ? now + params.expiresIn : undefined,
    status: 'valid',
    metadata: params.metadata || {}
  };

  // Update key usage
  key.usageCount++;
  key.lastUsed = now;
  keys.set(key.id, key);

  // Store document
  documents.set(id, document);
  createAuditEntry('sign', id, params.signer.id, { keyId: key.id, algorithm: key.algorithm });

  return document;
}

/**
 * Sign batch of documents
 */
export function signBatch(params: {
  items: Array<{ data: string | Buffer; metadata?: Record<string, unknown> }>;
  keyId: string;
  signer: SignerInfo;
  expiresIn?: number;
}): BatchSigningResult {
  const startTime = performance.now();
  const signedDocuments: SignedDocument[] = [];
  const signingTimes: number[] = [];

  for (const item of params.items) {
    const docStart = performance.now();
    const doc = signDocument({
      data: item.data,
      keyId: params.keyId,
      signer: params.signer,
      expiresIn: params.expiresIn,
      metadata: item.metadata
    });
    signedDocuments.push(doc);
    signingTimes.push(performance.now() - docStart);
  }

  const totalSigningTimeMs = performance.now() - startTime;
  const avgSigningTimeMs = signingTimes.reduce((a, b) => a + b, 0) / signingTimes.length;
  const batchHash = sha256Hash(signedDocuments.map(d => d.hash).join(''));

  return {
    id: `batch_${generateUUID()}`,
    documents: signedDocuments,
    batchHash,
    totalSigningTimeMs,
    avgSigningTimeMs,
    allSuccessful: signedDocuments.every(d => d.status === 'valid')
  };
}

// ============================================================================
// SIGNATURE VERIFICATION
// ============================================================================

/**
 * Verify signature
 */
export function verifySignature(documentId: string): VerificationResult {
  const startTime = performance.now();
  const document = documents.get(documentId);

  if (!document) {
    return createVerificationResult(documentId, false, 'invalid_signature', 'Document not found', startTime);
  }

  // Check if revoked
  if (document.status === 'revoked') {
    return createVerificationResult(documentId, false, 'revoked', 'Document has been revoked', startTime);
  }

  // Check expiration
  if (document.expiresAt && Date.now() > document.expiresAt) {
    document.status = 'expired';
    documents.set(documentId, document);
    return createVerificationResult(documentId, false, 'expired', 'Signature has expired', startTime);
  }

  // Check key status
  const key = keys.get(document.keyId);
  if (!key || key.status === 'revoked') {
    return createVerificationResult(documentId, false, 'key_revoked', 'Signing key has been revoked', startTime);
  }

  // Verify signature
  const secret = getKeySecret(key);
  const expectedSignature = hmacSign(document.hash, secret);

  if (document.signature !== expectedSignature) {
    return createVerificationResult(documentId, false, 'invalid_signature', 'Signature verification failed', startTime);
  }

  createAuditEntry('verify', documentId, 'system', { valid: true });

  return createVerificationResult(documentId, true, 'valid', undefined, startTime);
}

/**
 * Create verification result
 */
function createVerificationResult(
  documentId: string,
  valid: boolean,
  status: VerificationResult['status'],
  details: string | undefined,
  startTime: number
): VerificationResult {
  return {
    id: `verify_${generateUUID()}`,
    documentId,
    valid,
    status,
    verificationTimeMs: performance.now() - startTime,
    details,
    timestamp: Date.now()
  };
}

/**
 * Verify with data
 */
export function verifyWithData(documentId: string, data: string | Buffer): VerificationResult {
  const document = documents.get(documentId);
  if (!document) {
    return createVerificationResult(documentId, false, 'invalid_signature', 'Document not found', performance.now());
  }

  // Verify hash matches
  const dataString = typeof data === 'string' ? data : data.toString('base64');
  const hash = sha256Hash(dataString);

  if (hash !== document.hash) {
    return createVerificationResult(documentId, false, 'invalid_signature', 'Data hash does not match', performance.now());
  }

  return verifySignature(documentId);
}

// ============================================================================
// SIGNATURE CHAINS
// ============================================================================

/**
 * Create signature chain
 */
export function createChain(name: string, creator: string): SignatureChain {
  const chain: SignatureChain = {
    id: `chain_${generateUUID()}`,
    name,
    documents: [],
    chainHash: '0', // Genesis hash
    createdAt: Date.now(),
    updatedAt: Date.now(),
    status: 'active'
  };

  chains.set(chain.id, chain);
  return chain;
}

/**
 * Add document to chain
 */
export function addToChain(chainId: string, document: SignedDocument): SignatureChain | null {
  const chain = chains.get(chainId);
  if (!chain || chain.status !== 'active') return null;

  const previousHash = chain.documents.length > 0
    ? chain.documents[chain.documents.length - 1].hash
    : '0';

  const chainDoc: ChainDocument = {
    documentId: document.id,
    hash: document.hash,
    signature: document.signature,
    previousHash,
    position: chain.documents.length,
    timestamp: Date.now()
  };

  chain.documents.push(chainDoc);

  // Update chain hash
  chain.chainHash = sha256Hash(chain.documents.map(d => d.hash).join(''));
  chain.updatedAt = Date.now();

  chains.set(chainId, chain);
  createAuditEntry('chain_add', chainId, document.signer.id, { documentId: document.id });

  return chain;
}

/**
 * Verify chain integrity
 */
export function verifyChain(chainId: string): { valid: boolean; brokenAt?: number; reason?: string } {
  const chain = chains.get(chainId);
  if (!chain) {
    return { valid: false, reason: 'Chain not found' };
  }

  for (let i = 0; i < chain.documents.length; i++) {
    const doc = chain.documents[i];
    const expectedPreviousHash = i === 0 ? '0' : chain.documents[i - 1].hash;

    if (doc.previousHash !== expectedPreviousHash) {
      chain.status = 'broken';
      chains.set(chainId, chain);
      return { valid: false, brokenAt: i, reason: 'Chain link broken' };
    }

    // Verify document signature
    const verification = verifySignature(doc.documentId);
    if (!verification.valid) {
      chain.status = 'broken';
      chains.set(chainId, chain);
      return { valid: false, brokenAt: i, reason: verification.details };
    }
  }

  // Verify chain hash
  const expectedChainHash = sha256Hash(chain.documents.map(d => d.hash).join(''));
  if (chain.chainHash !== expectedChainHash) {
    chain.status = 'broken';
    chains.set(chainId, chain);
    return { valid: false, reason: 'Chain hash mismatch' };
  }

  return { valid: true };
}

/**
 * Seal chain (prevent further additions)
 */
export function sealChain(chainId: string): SignatureChain | null {
  const chain = chains.get(chainId);
  if (!chain) return null;

  chain.status = 'sealed';
  chain.updatedAt = Date.now();
  chains.set(chainId, chain);

  return chain;
}

// ============================================================================
// MULTI-SIGNATURE
// ============================================================================

/**
 * Create multi-signature request
 */
export function createMultiSignatureRequest(params: {
  documentHash: string;
  requiredSigners: string[];
  threshold: number;
  expiresIn?: number;
}): MultiSignatureRequest {
  const request: MultiSignatureRequest = {
    id: `multisig_${generateUUID()}`,
    documentHash: params.documentHash,
    requiredSigners: params.requiredSigners,
    signatures: new Map(),
    threshold: params.threshold,
    status: 'pending',
    createdAt: Date.now(),
    expiresAt: params.expiresIn ? Date.now() + params.expiresIn : undefined
  };

  multiSigRequests.set(request.id, request);
  return request;
}

/**
 * Add signature to multi-sig request
 */
export function addMultiSignature(requestId: string, signature: SignedDocument): MultiSignatureRequest | null {
  const request = multiSigRequests.get(requestId);
  if (!request || request.status !== 'pending') return null;

  // Verify signature matches document hash
  if (signature.hash !== request.documentHash) {
    return null;
  }

  // Check if signer is authorized
  if (!request.requiredSigners.includes(signature.signer.id)) {
    return null;
  }

  // Add signature
  request.signatures.set(signature.signer.id, signature);

  // Check if threshold met
  if (request.signatures.size >= request.threshold) {
    request.status = 'complete';
  }

  multiSigRequests.set(requestId, request);
  return request;
}

/**
 * Get multi-signature request
 */
export function getMultiSignatureRequest(requestId: string): MultiSignatureRequest | undefined {
  return multiSigRequests.get(requestId);
}

// ============================================================================
// REVOCATION
// ============================================================================

/**
 * Revoke document
 */
export function revokeDocument(documentId: string, reason: string, revokedBy: string): SignedDocument | null {
  const document = documents.get(documentId);
  if (!document) return null;

  document.status = 'revoked';
  document.revocation = {
    reason,
    revokedAt: Date.now(),
    revokedBy
  };

  documents.set(documentId, document);

  const revocation: RevocationEntry = {
    id: `revoke_${generateUUID()}`,
    targetId: documentId,
    targetType: 'document',
    reason,
    revokedBy,
    timestamp: Date.now()
  };

  revocations.set(revocation.id, revocation);
  createAuditEntry('revoke', documentId, revokedBy, { reason, type: 'document' });

  return document;
}

/**
 * Get revocation status
 */
export function getRevocationStatus(targetId: string): RevocationEntry | undefined {
  return Array.from(revocations.values()).find(r => r.targetId === targetId);
}

// ============================================================================
// QUERIES
// ============================================================================

/**
 * Get document
 */
export function getDocument(documentId: string): SignedDocument | undefined {
  return documents.get(documentId);
}

/**
 * Get documents by signer
 */
export function getDocumentsBySigner(signerId: string, limit: number = 100): SignedDocument[] {
  return Array.from(documents.values())
    .filter(d => d.signer.id === signerId)
    .sort((a, b) => b.timestamp - a.timestamp)
    .slice(0, limit);
}

/**
 * Get chain
 */
export function getChain(chainId: string): SignatureChain | undefined {
  return chains.get(chainId);
}

// ============================================================================
// AUDIT
// ============================================================================

/**
 * Create audit entry
 */
function createAuditEntry(
  action: SigningAuditEntry['action'],
  targetId: string,
  actor: string,
  details: Record<string, unknown>
): void {
  if (!config.enableAuditLog) return;

  const entry: SigningAuditEntry = {
    id: `audit_${generateUUID()}`,
    action,
    targetId,
    actor,
    timestamp: Date.now(),
    details
  };

  auditLog.set(entry.id, entry);
}

/**
 * Get audit log
 */
export function getAuditLog(targetId?: string, limit: number = 100): SigningAuditEntry[] {
  let entries = Array.from(auditLog.values());
  if (targetId) {
    entries = entries.filter(e => e.targetId === targetId);
  }
  return entries.sort((a, b) => b.timestamp - a.timestamp).slice(0, limit);
}

// ============================================================================
// STATISTICS
// ============================================================================

/**
 * Get system statistics
 */
export function getSystemStats(): {
  documents: { total: number; valid: number; revoked: number; expired: number };
  keys: { total: number; active: number; revoked: number };
  chains: { total: number; active: number; sealed: number; broken: number };
  multiSig: { total: number; pending: number; complete: number };
  revocations: number;
} {
  const allDocs = Array.from(documents.values());
  const allKeys = Array.from(keys.values());
  const allChains = Array.from(chains.values());
  const allMultiSig = Array.from(multiSigRequests.values());

  return {
    documents: {
      total: allDocs.length,
      valid: allDocs.filter(d => d.status === 'valid').length,
      revoked: allDocs.filter(d => d.status === 'revoked').length,
      expired: allDocs.filter(d => d.status === 'expired').length
    },
    keys: {
      total: allKeys.length,
      active: allKeys.filter(k => k.status === 'active').length,
      revoked: allKeys.filter(k => k.status === 'revoked').length
    },
    chains: {
      total: allChains.length,
      active: allChains.filter(c => c.status === 'active').length,
      sealed: allChains.filter(c => c.status === 'sealed').length,
      broken: allChains.filter(c => c.status === 'broken').length
    },
    multiSig: {
      total: allMultiSig.length,
      pending: allMultiSig.filter(m => m.status === 'pending').length,
      complete: allMultiSig.filter(m => m.status === 'complete').length
    },
    revocations: revocations.size
  };
}

// ============================================================================
// TEST SUITE
// ============================================================================

/**
 * Run cryptographic signing tests
 */
export function runCryptographicSigningTests(): {
  passed: boolean;
  tests: { total: number; passed: number; failed: number };
  results: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const results: Array<{ name: string; passed: boolean; error?: string }> = [];

  try {
    // Test 1: Create key
    const key = createKey({
      name: 'Test Key',
      owner: 'test_user'
    });
    results.push({ name: 'Create Key', passed: !!key.id && key.status === 'active' });

    // Test 2: Sign document
    const document = signDocument({
      data: 'Hello, World!',
      keyId: key.id,
      signer: { id: 'test_user', type: 'user', name: 'Test User' }
    });
    results.push({ name: 'Sign Document', passed: !!document.id && document.status === 'valid' });

    // Test 3: Verify signature
    const verification = verifySignature(document.id);
    results.push({ name: 'Verify Signature', passed: verification.valid });

    // Test 4: Verify with data
    const dataVerification = verifyWithData(document.id, 'Hello, World!');
    results.push({ name: 'Verify With Data', passed: dataVerification.valid });

    // Test 5: Verify wrong data fails
    const wrongDataVerification = verifyWithData(document.id, 'Wrong data');
    results.push({ name: 'Wrong Data Fails', passed: !wrongDataVerification.valid });

    // Test 6: Batch signing
    const batch = signBatch({
      items: [
        { data: 'Document 1' },
        { data: 'Document 2' },
        { data: 'Document 3' }
      ],
      keyId: key.id,
      signer: { id: 'test_user', type: 'user', name: 'Test User' }
    });
    results.push({ name: 'Batch Signing', passed: batch.documents.length === 3 && batch.allSuccessful });

    // Test 7: Create chain
    const chain = createChain('Test Chain', 'test_user');
    results.push({ name: 'Create Chain', passed: !!chain.id && chain.status === 'active' });

    // Test 8: Add to chain
    const chainDoc1 = signDocument({
      data: 'Chain document 1',
      keyId: key.id,
      signer: { id: 'test_user', type: 'user', name: 'Test User' }
    });
    const updatedChain = addToChain(chain.id, chainDoc1);
    results.push({ name: 'Add to Chain', passed: (updatedChain?.documents.length || 0) === 1 });

    // Test 9: Verify chain
    const chainVerification = verifyChain(chain.id);
    results.push({ name: 'Verify Chain', passed: chainVerification.valid });

    // Test 10: Multi-signature request
    const multiSig = createMultiSignatureRequest({
      documentHash: sha256Hash('Multi-sig document'),
      requiredSigners: ['user1', 'user2', 'user3'],
      threshold: 2
    });
    results.push({ name: 'Create Multi-Sig Request', passed: !!multiSig.id && multiSig.status === 'pending' });

    // Test 11: Revoke document
    const revokedDoc = revokeDocument(document.id, 'Test revocation', 'admin');
    results.push({ name: 'Revoke Document', passed: revokedDoc?.status === 'revoked' });

    // Test 12: Verify revoked fails
    const revokedVerification = verifySignature(document.id);
    results.push({ name: 'Revoked Verification Fails', passed: !revokedVerification.valid && revokedVerification.status === 'revoked' });

  } catch (error) {
    results.push({ name: 'Test execution', passed: false, error: String(error) });
  }

  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;

  return {
    passed: failed === 0,
    tests: { total: results.length, passed, failed },
    results
  };
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

const cryptographicSigning = {
  // Configuration
  updateConfig,
  getConfig,
  // Key management
  createKey,
  getKey,
  rotateKey,
  revokeKey,
  listKeys,
  // Document signing
  signDocument,
  signBatch,
  // Verification
  verifySignature,
  verifyWithData,
  // Chains
  createChain,
  addToChain,
  verifyChain,
  sealChain,
  getChain,
  // Multi-signature
  createMultiSignatureRequest,
  addMultiSignature,
  getMultiSignatureRequest,
  // Revocation
  revokeDocument,
  getRevocationStatus,
  // Queries
  getDocument,
  getDocumentsBySigner,
  // Audit
  getAuditLog,
  // Statistics
  getSystemStats,
  // Tests
  runCryptographicSigningTests
};

export default cryptographicSigning;
