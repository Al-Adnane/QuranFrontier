/**
 * Tool-Use Security Layer
 * ========================
 * 
 * Secure integration and sandboxing for AI tools/APIs.
 * Controls and monitors external tool access by AI agents.
 * 
 * Features:
 * - Tool Registry
 * - Permission Management
 * - Sandboxed Execution
 * - Rate Limiting
 * - Input/Output Validation
 * - Tool Access Policies
 * 
 * @module frontier/tool-use-security
 * @version 1.0.0
 */

// ============================================================================
// TYPES
// ============================================================================

export type ToolStatus = 'active' | 'inactive' | 'deprecated' | 'blocked';
export type PermissionLevel = 'none' | 'read' | 'write' | 'execute' | 'admin';
export type ExecutionResult = 'success' | 'denied' | 'error' | 'timeout' | 'rate_limited';

export interface ToolDefinition {
  id: string;
  name: string;
  description: string;
  version: string;
  category: string;
  
  // Configuration
  endpoint?: string;
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE';
  headers?: Record<string, string>;
  authentication?: {
    type: 'api_key' | 'oauth' | 'bearer' | 'custom';
    header?: string;
  };
  
  // Schema
  inputSchema: Record<string, unknown>;
  outputSchema?: Record<string, unknown>;
  
  // Security
  securityLevel: 'low' | 'medium' | 'high' | 'critical';
  requiresApproval: boolean;
  allowedAgents: string[];
  permissions: PermissionLevel[];
  
  // Rate Limiting
  rateLimit: {
    maxRequests: number;
    windowMs: number;
    burstLimit?: number;
  };
  
  // Sandbox
  sandboxConfig: {
    enabled: boolean;
    timeout: number;
    maxMemoryMB: number;
    networkAccess: boolean;
    fileAccess: boolean;
  };
  
  // Status
  status: ToolStatus;
  
  // Statistics
  stats: {
    totalCalls: number;
    successCalls: number;
    failedCalls: number;
    avgLatency: number;
  };
  
  // Metadata
  owner: string;
  createdAt: number;
  updatedAt: number;
}

export interface ToolPermission {
  id: string;
  agentId: string;
  toolId: string;
  permission: PermissionLevel;
  grantedBy: string;
  grantedAt: number;
  expiresAt?: number;
  constraints?: {
    maxCalls?: number;
    allowedInputs?: string[];
    blockedInputs?: string[];
    timeWindow?: { start: string; end: string };
  };
}

export interface ToolExecution {
  id: string;
  toolId: string;
  agentId: string;
  
  // Input/Output
  input: Record<string, unknown>;
  output?: Record<string, unknown>;
  error?: string;
  
  // Execution
  status: ExecutionResult;
  startTime: number;
  endTime?: number;
  duration?: number;
  
  // Security
  validated: boolean;
  sanitized: boolean;
  sandboxed: boolean;
  
  // Rate Limiting
  rateLimited: boolean;
  remainingQuota?: number;
  
  // Metadata
  metadata?: Record<string, unknown>;
}

export interface ToolPolicy {
  id: string;
  name: string;
  description: string;
  
  // Scope
  tools: string[]; // Tool IDs or patterns
  agents: string[]; // Agent IDs or patterns
  
  // Rules
  rules: Array<{
    type: 'allow' | 'deny' | 'require_approval';
    condition: string;
    priority: number;
  }>;
  
  // Actions
  onViolation: 'deny' | 'log' | 'alert' | 'block_agent';
  
  // Status
  enabled: boolean;
  priority: number;
  
  createdAt: number;
  updatedAt: number;
}

export interface Sandbox {
  id: string;
  toolId: string;
  executionId: string;
  
  // Resources
  memoryMB: number;
  cpuPercent: number;
  
  // Limits
  limits: {
    maxMemoryMB: number;
    maxCpuPercent: number;
    timeout: number;
  };
  
  // State
  status: 'creating' | 'running' | 'completed' | 'error' | 'killed';
  createdAt: number;
  killedAt?: number;
  killReason?: string;
}

// ============================================================================
// STORAGE
// ============================================================================

const tools = new Map<string, ToolDefinition>();
const permissions = new Map<string, ToolPermission>();
const executions = new Map<string, ToolExecution>();
const policies = new Map<string, ToolPolicy>();
const sandboxes = new Map<string, Sandbox>();

// Indexes
const permissionsByAgent = new Map<string, Set<string>>();
const permissionsByTool = new Map<string, Set<string>>();
const rateLimitCounters = new Map<string, { count: number; resetAt: number }>();

// ============================================================================
// TOOL REGISTRY
// ============================================================================

export function registerTool(config: Omit<ToolDefinition, 'id' | 'status' | 'stats' | 'createdAt' | 'updatedAt'>): ToolDefinition {
  const tool: ToolDefinition = {
    ...config,
    id: `tool_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
    status: 'active',
    stats: {
      totalCalls: 0,
      successCalls: 0,
      failedCalls: 0,
      avgLatency: 0
    },
    createdAt: Date.now(),
    updatedAt: Date.now()
  };
  
  tools.set(tool.id, tool);
  return tool;
}

export function getTool(id: string): ToolDefinition | undefined {
  return tools.get(id);
}

export function getAllTools(): ToolDefinition[] {
  return Array.from(tools.values());
}

export function getToolsByCategory(category: string): ToolDefinition[] {
  return Array.from(tools.values()).filter(t => t.category === category);
}

export function updateToolStatus(id: string, status: ToolStatus): boolean {
  const tool = tools.get(id);
  if (!tool) return false;
  
  tool.status = status;
  tool.updatedAt = Date.now();
  return true;
}

// ============================================================================
// PERMISSION MANAGEMENT
// ============================================================================

export function grantPermission(config: {
  agentId: string;
  toolId: string;
  permission: PermissionLevel;
  grantedBy: string;
  expiresAt?: number;
  constraints?: ToolPermission['constraints'];
}): ToolPermission | null {
  const tool = tools.get(config.toolId);
  if (!tool) return null;
  
  const perm: ToolPermission = {
    id: `perm_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
    ...config,
    grantedAt: Date.now()
  };
  
  permissions.set(perm.id, perm);
  
  // Update indexes
  if (!permissionsByAgent.has(config.agentId)) {
    permissionsByAgent.set(config.agentId, new Set());
  }
  permissionsByAgent.get(config.agentId)!.add(perm.id);
  
  if (!permissionsByTool.has(config.toolId)) {
    permissionsByTool.set(config.toolId, new Set());
  }
  permissionsByTool.get(config.toolId)!.add(perm.id);
  
  return perm;
}

export function checkPermission(agentId: string, toolId: string, required: PermissionLevel): {
  allowed: boolean;
  permission?: ToolPermission;
  reason?: string;
} {
  const tool = tools.get(toolId);
  if (!tool) {
    return { allowed: false, reason: 'Tool not found' };
  }
  
  if (tool.status !== 'active') {
    return { allowed: false, reason: 'Tool not active' };
  }
  
  // Check allowed agents
  if (tool.allowedAgents.length > 0 && !tool.allowedAgents.includes(agentId)) {
    return { allowed: false, reason: 'Agent not allowed for this tool' };
  }
  
  // Check permission level
  const permIds = permissionsByAgent.get(agentId);
  if (!permIds) {
    // Check if tool allows default access
    if (tool.securityLevel === 'low') {
      return { allowed: true };
    }
    return { allowed: false, reason: 'No permission granted' };
  }
  
  for (const permId of permIds) {
    const perm = permissions.get(permId);
    if (perm && perm.toolId === toolId) {
      // Check expiration
      if (perm.expiresAt && Date.now() > perm.expiresAt) {
        continue;
      }
      
      // Check permission level
      const levels: PermissionLevel[] = ['none', 'read', 'write', 'execute', 'admin'];
      const permLevel = levels.indexOf(perm.permission);
      const reqLevel = levels.indexOf(required);
      
      if (permLevel >= reqLevel) {
        return { allowed: true, permission: perm };
      }
    }
  }
  
  return { allowed: false, reason: 'Insufficient permission level' };
}

export function revokePermission(permId: string): boolean {
  const perm = permissions.get(permId);
  if (!perm) return false;
  
  permissions.delete(permId);
  permissionsByAgent.get(perm.agentId)?.delete(permId);
  permissionsByTool.get(perm.toolId)?.delete(permId);
  
  return true;
}

// ============================================================================
// RATE LIMITING
// ============================================================================

export function checkRateLimit(toolId: string, agentId: string): {
  allowed: boolean;
  remaining: number;
  resetIn: number;
} {
  const tool = tools.get(toolId);
  if (!tool) {
    return { allowed: false, remaining: 0, resetIn: 0 };
  }
  
  const key = `${toolId}:${agentId}`;
  const now = Date.now();
  let counter = rateLimitCounters.get(key);
  
  if (!counter || now > counter.resetAt) {
    counter = { count: 0, resetAt: now + tool.rateLimit.windowMs };
    rateLimitCounters.set(key, counter);
  }
  
  const allowed = counter.count < tool.rateLimit.maxRequests;
  const remaining = Math.max(0, tool.rateLimit.maxRequests - counter.count);
  const resetIn = counter.resetAt - now;
  
  if (allowed) {
    counter.count++;
  }
  
  return { allowed, remaining, resetIn };
}

// ============================================================================
// INPUT/OUTPUT VALIDATION
// ============================================================================

export function validateInput(toolId: string, input: Record<string, unknown>): {
  valid: boolean;
  errors: string[];
  sanitized?: Record<string, unknown>;
} {
  const tool = tools.get(toolId);
  if (!tool) {
    return { valid: false, errors: ['Tool not found'] };
  }
  
  const errors: string[] = [];
  const sanitized: Record<string, unknown> = {};
  
  // Basic schema validation
  const schema = tool.inputSchema as { required?: string[]; properties?: Record<string, unknown> };
  
  if (schema.required) {
    for (const field of schema.required) {
      if (input[field] === undefined) {
        errors.push(`Missing required field: ${field}`);
      }
    }
  }
  
  // Sanitize input
  for (const [key, value] of Object.entries(input)) {
    // Remove potential injection patterns
    if (typeof value === 'string') {
      sanitized[key] = value
        .replace(/<script[^>]*>.*?<\/script>/gi, '')
        .replace(/javascript:/gi, '')
        .replace(/on\w+=/gi, '');
    } else {
      sanitized[key] = value;
    }
  }
  
  return { valid: errors.length === 0, errors, sanitized };
}

export function validateOutput(toolId: string, output: Record<string, unknown>): {
  valid: boolean;
  errors: string[];
} {
  const tool = tools.get(toolId);
  if (!tool || !tool.outputSchema) {
    return { valid: true, errors: [] };
  }
  
  const errors: string[] = [];
  // Basic output validation
  // In production, this would use JSON Schema validation
  
  return { valid: errors.length === 0, errors };
}

// ============================================================================
// SANDBOX EXECUTION
// ============================================================================

export function createSandbox(toolId: string, executionId: string): Sandbox | null {
  const tool = tools.get(toolId);
  if (!tool) return null;
  
  const sandbox: Sandbox = {
    id: `sandbox_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
    toolId,
    executionId,
    memoryMB: 0,
    cpuPercent: 0,
    limits: {
      maxMemoryMB: tool.sandboxConfig.maxMemoryMB,
      maxCpuPercent: 100,
      timeout: tool.sandboxConfig.timeout
    },
    status: 'creating',
    createdAt: Date.now()
  };
  
  sandboxes.set(sandbox.id, sandbox);
  
  // Simulate sandbox creation
  setTimeout(() => {
    sandbox.status = 'running';
  }, 10);
  
  return sandbox;
}

export function killSandbox(sandboxId: string, reason: string): boolean {
  const sandbox = sandboxes.get(sandboxId);
  if (!sandbox) return false;
  
  sandbox.status = 'killed';
  sandbox.killedAt = Date.now();
  sandbox.killReason = reason;
  
  return true;
}

// ============================================================================
// TOOL EXECUTION
// ============================================================================

export async function executeTool(
  toolId: string,
  agentId: string,
  input: Record<string, unknown>
): Promise<ToolExecution> {
  const tool = tools.get(toolId);
  
  const execution: ToolExecution = {
    id: `exec_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
    toolId,
    agentId,
    input,
    status: 'success',
    startTime: Date.now(),
    validated: false,
    sanitized: false,
    sandboxed: false,
    rateLimited: false
  };
  
  // Check tool exists
  if (!tool) {
    execution.status = 'denied';
    execution.error = 'Tool not found';
    execution.endTime = Date.now();
    execution.duration = execution.endTime - execution.startTime;
    executions.set(execution.id, execution);
    return execution;
  }
  
  // Check permission
  const permCheck = checkPermission(agentId, toolId, 'execute');
  if (!permCheck.allowed) {
    execution.status = 'denied';
    execution.error = permCheck.reason;
    execution.endTime = Date.now();
    execution.duration = execution.endTime - execution.startTime;
    executions.set(execution.id, execution);
    return execution;
  }
  
  // Check rate limit
  const rateCheck = checkRateLimit(toolId, agentId);
  if (!rateCheck.allowed) {
    execution.status = 'rate_limited';
    execution.error = 'Rate limit exceeded';
    execution.rateLimited = true;
    execution.remainingQuota = 0;
    execution.endTime = Date.now();
    execution.duration = execution.endTime - execution.startTime;
    executions.set(execution.id, execution);
    return execution;
  }
  
  execution.remainingQuota = rateCheck.remaining;
  
  // Validate input
  const validation = validateInput(toolId, input);
  if (!validation.valid) {
    execution.status = 'denied';
    execution.error = validation.errors.join(', ');
    execution.endTime = Date.now();
    execution.duration = execution.endTime - execution.startTime;
    executions.set(execution.id, execution);
    return execution;
  }
  
  execution.validated = true;
  execution.sanitized = !!validation.sanitized;
  execution.input = validation.sanitized || input;
  
  // Create sandbox if enabled
  let sandbox: Sandbox | null = null;
  if (tool.sandboxConfig.enabled) {
    sandbox = createSandbox(toolId, execution.id);
    execution.sandboxed = true;
  }
  
  // Execute (simulate)
  try {
    await new Promise(resolve => setTimeout(resolve, Math.random() * 100));
    
    execution.output = { result: 'success', data: {} };
    execution.status = 'success';
    
    // Update tool stats
    tool.stats.totalCalls++;
    tool.stats.successCalls++;
    tool.stats.avgLatency = (tool.stats.avgLatency + (Date.now() - execution.startTime)) / 2;
    
  } catch (error) {
    execution.status = 'error';
    execution.error = error instanceof Error ? error.message : 'Unknown error';
    tool.stats.failedCalls++;
  }
  
  execution.endTime = Date.now();
  execution.duration = execution.endTime - execution.startTime;
  
  if (sandbox) {
    sandbox.status = 'completed';
  }
  
  executions.set(execution.id, execution);
  return execution;
}

export function getExecution(id: string): ToolExecution | undefined {
  return executions.get(id);
}

// ============================================================================
// STATISTICS
// ============================================================================

export function getToolUseStats(): {
  tools: { total: number; active: number };
  permissions: { total: number };
  executions: { total: number; today: number; success: number; failed: number };
  sandboxes: { total: number; running: number };
} {
  const now = Date.now();
  const todayStart = now - (now % 86400000);
  
  return {
    tools: {
      total: tools.size,
      active: Array.from(tools.values()).filter(t => t.status === 'active').length
    },
    permissions: {
      total: permissions.size
    },
    executions: {
      total: executions.size,
      today: Array.from(executions.values()).filter(e => e.startTime >= todayStart).length,
      success: Array.from(executions.values()).filter(e => e.status === 'success').length,
      failed: Array.from(executions.values()).filter(e => ['error', 'denied', 'timeout'].includes(e.status)).length
    },
    sandboxes: {
      total: sandboxes.size,
      running: Array.from(sandboxes.values()).filter(s => s.status === 'running').length
    }
  };
}

// ============================================================================
// TESTS
// ============================================================================

export function runToolUseSecurityTests(): {
  passed: boolean;
  tests: { total: number; passed: number; failed: number };
  results: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const results: Array<{ name: string; passed: boolean; error?: string }> = [];
  
  // Test 1: Register Tool
  try {
    const tool = registerTool({
      name: 'TestTool',
      description: 'Test tool',
      version: '1.0.0',
      category: 'utility',
      inputSchema: { required: ['query'], properties: { query: { type: 'string' } } },
      securityLevel: 'low',
      requiresApproval: false,
      allowedAgents: [],
      permissions: ['read'],
      rateLimit: { maxRequests: 100, windowMs: 60000 },
      sandboxConfig: { enabled: true, timeout: 30000, maxMemoryMB: 256, networkAccess: false, fileAccess: false },
      owner: 'test-user'
    });
    results.push({ name: 'Register Tool', passed: !!tool.id });
  } catch (error) {
    results.push({ name: 'Register Tool', passed: false, error: String(error) });
  }
  
  // Test 2: Grant Permission
  try {
    const tool = Array.from(tools.values())[0];
    const perm = grantPermission({
      agentId: 'test-agent',
      toolId: tool.id,
      permission: 'execute',
      grantedBy: 'admin'
    });
    results.push({ name: 'Grant Permission', passed: !!perm?.id });
  } catch (error) {
    results.push({ name: 'Grant Permission', passed: false, error: String(error) });
  }
  
  // Test 3: Validate Input
  try {
    const tool = Array.from(tools.values())[0];
    const validation = validateInput(tool.id, { query: 'test' });
    results.push({ name: 'Validate Input', passed: validation.valid });
  } catch (error) {
    results.push({ name: 'Validate Input', passed: false, error: String(error) });
  }
  
  // Test 4: Check Rate Limit
  try {
    const tool = Array.from(tools.values())[0];
    const rate = checkRateLimit(tool.id, 'test-agent');
    results.push({ name: 'Check Rate Limit', passed: rate.allowed });
  } catch (error) {
    results.push({ name: 'Check Rate Limit', passed: false, error: String(error) });
  }
  
  // Test 5: Get Statistics
  try {
    const stats = getToolUseStats();
    results.push({ name: 'Get Statistics', passed: stats.tools.total > 0 });
  } catch (error) {
    results.push({ name: 'Get Statistics', passed: false, error: String(error) });
  }
  
  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;
  
  return {
    passed: failed === 0,
    tests: { total: results.length, passed, failed },
    results
  };
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

export default {
  registerTool,
  getTool,
  getAllTools,
  getToolsByCategory,
  updateToolStatus,
  grantPermission,
  checkPermission,
  revokePermission,
  checkRateLimit,
  validateInput,
  validateOutput,
  createSandbox,
  killSandbox,
  executeTool,
  getExecution,
  getToolUseStats,
  runToolUseSecurityTests
};
