/**
 * Metrics Dashboard Module
 *
 * Real-time module performance monitoring with health tracking and usage analytics.
 * Provides comprehensive observability for all frontier modules.
 *
 * @module frontier/metrics-dashboard
 * @version 8.1.0
 *
 * Capabilities:
 * - Real-time performance metrics
 * - Health monitoring
 * - Usage analytics
 * - Custom dashboards
 * - Alerting
 * - Historical data
 * - Aggregation
 * - Export
 */

import { generateUUID, sha256Hash } from '../crypto-utils';

// ============================================================================
// TYPES
// ============================================================================

/**
 * Metric type
 */
export type MetricType = 'counter' | 'gauge' | 'histogram' | 'summary' | 'timer';

/**
 * Metric value
 */
export interface MetricValue {
  /** Metric name */
  name: string;
  /** Metric value */
  value: number;
  /** Metric type */
  type: MetricType;
  /** Timestamp */
  timestamp: number;
  /** Tags */
  tags: Record<string, string>;
  /** Module */
  module: string;
  /** Additional metadata */
  metadata?: Record<string, unknown>;
}

/**
 * Metric aggregation
 */
export interface MetricAggregation {
  /** Aggregation ID */
  id: string;
  /** Metric name */
  metricName: string;
  /** Aggregation period */
  period: '1m' | '5m' | '15m' | '1h' | '1d';
  /** Aggregation type */
  aggregation: 'avg' | 'sum' | 'min' | 'max' | 'count' | 'p50' | 'p95' | 'p99';
  /** Start time */
  startTime: number;
  /** End time */
  endTime: number;
  /** Values */
  values: Array<{ timestamp: number; value: number }>;
  /** Current value */
  currentValue: number;
}

/**
 * Module health status
 */
export interface ModuleHealth {
  /** Module ID */
  moduleId: string;
  /** Module name */
  moduleName: string;
  /** Health status */
  status: 'healthy' | 'degraded' | 'unhealthy' | 'unknown';
  /** Health score (0-100) */
  score: number;
  /** Last check timestamp */
  lastCheck: number;
  /** Issues */
  issues: HealthIssue[];
  /** Metrics summary */
  metrics: {
    errorRate: number;
    latency: number;
    throughput: number;
    availability: number;
  };
  /** Dependencies */
  dependencies: Array<{
    name: string;
    status: 'healthy' | 'degraded' | 'unhealthy';
  }>;
}

/**
 * Health issue
 */
export interface HealthIssue {
  /** Issue ID */
  id: string;
  /** Issue type */
  type: 'error_rate' | 'latency' | 'availability' | 'resource' | 'dependency';
  /** Severity */
  severity: 'low' | 'medium' | 'high' | 'critical';
  /** Description */
  description: string;
  /** Detected timestamp */
  detectedAt: number;
  /** Affected metric */
  metric?: string;
  /** Threshold */
  threshold?: number;
  /** Current value */
  currentValue?: number;
}

/**
 * Dashboard
 */
export interface Dashboard {
  /** Dashboard ID */
  id: string;
  /** Dashboard name */
  name: string;
  /** Description */
  description: string;
  /** Panels */
  panels: DashboardPanel[];
  /** Layout */
  layout: {
    columns: number;
    rowHeight: number;
  };
  /** Refresh interval ms */
  refreshInterval: number;
  /** Time range */
  timeRange: {
    default: string;
    options: string[];
  };
  /** Created by */
  createdBy: string;
  /** Created timestamp */
  createdAt: number;
  /** Updated timestamp */
  updatedAt: number;
  /** Is public */
  isPublic: boolean;
}

/**
 * Dashboard panel
 */
export interface DashboardPanel {
  /** Panel ID */
  id: string;
  /** Panel title */
  title: string;
  /** Panel type */
  type: 'line' | 'bar' | 'gauge' | 'stat' | 'table' | 'heatmap' | 'pie';
  /** Metrics to display */
  metrics: Array<{
    name: string;
    aggregation: string;
    alias?: string;
  }>;
  /** Grid position */
  position: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  /** Visualization options */
  options: {
    unit?: string;
    decimals?: number;
    min?: number;
    max?: number;
    thresholds?: Array<{ value: number; color: string }>;
    legend?: boolean;
  };
  /** Query */
  query?: string;
}

/**
 * Alert rule
 */
export interface AlertRule {
  /** Rule ID */
  id: string;
  /** Rule name */
  name: string;
  /** Description */
  description: string;
  /** Metric to monitor */
  metric: string;
  /** Condition */
  condition: {
    operator: 'gt' | 'lt' | 'gte' | 'lte' | 'eq' | 'neq';
    threshold: number;
    for: number; // Duration in seconds
  };
  /** Severity */
  severity: 'info' | 'warning' | 'error' | 'critical';
  /** Notification channels */
  channels: string[];
  /** Module filter */
  moduleFilter?: string[];
  /** Tags filter */
  tagsFilter?: Record<string, string>;
  /** Enabled */
  enabled: boolean;
  /** Created timestamp */
  createdAt: number;
  /** Updated timestamp */
  updatedAt: number;
  /** Last triggered */
  lastTriggered?: number;
  /** Trigger count */
  triggerCount: number;
}

/**
 * Alert state
 */
export interface AlertState {
  /** State ID */
  id: string;
  /** Rule ID */
  ruleId: string;
  /** State */
  state: 'ok' | 'pending' | 'firing' | 'resolved';
  /** Current value */
  currentValue: number;
  /** Started timestamp */
  startedAt: number;
  /** Last updated */
  updatedAt: number;
  /** Acknowledged */
  acknowledged: boolean;
  /** Acknowledged by */
  acknowledgedBy?: string;
  /** Silenced until */
  silencedUntil?: number;
}

/**
 * Usage analytics
 */
export interface UsageAnalytics {
  /** Period */
  period: {
    start: number;
    end: number;
  };
  /** Total requests */
  totalRequests: number;
  /** Requests by module */
  requestsByModule: Record<string, number>;
  /** Requests by endpoint */
  requestsByEndpoint: Record<string, number>;
  /** Error rate */
  errorRate: number;
  /** Average latency */
  avgLatency: number;
  /** Latency percentiles */
  latencyPercentiles: {
    p50: number;
    p95: number;
    p99: number;
  };
  /** Throughput */
  throughput: number;
  /** Active users */
  activeUsers: number;
  /** Top users */
  topUsers: Array<{
    userId: string;
    requestCount: number;
  }>;
  /** Resource usage */
  resourceUsage: {
    cpu: number;
    memory: number;
    storage: number;
    network: number;
  };
  /** Trends */
  trends: {
    requests: 'increasing' | 'stable' | 'decreasing';
    errors: 'increasing' | 'stable' | 'decreasing';
    latency: 'increasing' | 'stable' | 'decreasing';
  };
}

/**
 * Export format
 */
export interface MetricsExport {
  /** Export ID */
  id: string;
  /** Export format */
  format: 'json' | 'csv' | 'prometheus' | 'influxdb';
  /** Metrics included */
  metrics: string[];
  /** Time range */
  timeRange: {
    start: number;
    end: number;
  };
  /** Created timestamp */
  createdAt: number;
  /** Data */
  data?: string;
  /** Status */
  status: 'pending' | 'completed' | 'failed';
}

// ============================================================================
// STORAGE
// ============================================================================

const metrics = new Map<string, MetricValue[]>();
const aggregations = new Map<string, MetricAggregation>();
const healthStatuses = new Map<string, ModuleHealth>();
const dashboards = new Map<string, Dashboard>();
const alertRules = new Map<string, AlertRule>();
const alertStates = new Map<string, AlertState>();
const exports = new Map<string, MetricsExport>();

// Time series data
const timeSeriesData: Map<string, Array<{ timestamp: number; value: number }>> = new Map();

// Default retention period (7 days)
const RETENTION_MS = 7 * 24 * 60 * 60 * 1000;

// ============================================================================
// METRIC RECORDING
// ============================================================================

/**
 * Record metric
 */
export function recordMetric(config: {
  name: string;
  value: number;
  type?: MetricType;
  module: string;
  tags?: Record<string, string>;
  metadata?: Record<string, unknown>;
}): MetricValue {
  const metric: MetricValue = {
    name: config.name,
    value: config.value,
    type: config.type || 'gauge',
    timestamp: Date.now(),
    tags: config.tags || {},
    module: config.module,
    metadata: config.metadata
  };

  // Store metric
  const key = `${config.module}:${config.name}`;
  if (!metrics.has(key)) {
    metrics.set(key, []);
  }
  const metricList = metrics.get(key)!;
  metricList.push(metric);

  // Store in time series
  const tsKey = `${key}:${JSON.stringify(config.tags || {})}`;
  if (!timeSeriesData.has(tsKey)) {
    timeSeriesData.set(tsKey, []);
  }
  timeSeriesData.get(tsKey)!.push({ timestamp: metric.timestamp, value: metric.value });

  // Clean old data
  cleanOldData(key);
  cleanOldData(tsKey);

  // Check alerts
  checkAlerts(metric);

  return metric;
}

/**
 * Record timer metric
 */
export function recordTimer(name: string, module: string, durationMs: number, tags?: Record<string, string>): MetricValue {
  return recordMetric({
    name,
    value: durationMs,
    type: 'timer',
    module,
    tags
  });
}

/**
 * Record counter increment
 */
export function incrementCounter(name: string, module: string, amount = 1, tags?: Record<string, string>): MetricValue {
  const key = `${module}:${name}`;
  const existing = metrics.get(key);
  const lastValue = existing && existing.length > 0 ? existing[existing.length - 1].value : 0;

  return recordMetric({
    name,
    value: lastValue + amount,
    type: 'counter',
    module,
    tags
  });
}

/**
 * Clean old data
 */
function cleanOldData(key: string): void {
  const cutoff = Date.now() - RETENTION_MS;

  const metricList = metrics.get(key);
  if (metricList) {
    const filtered = metricList.filter(m => m.timestamp > cutoff);
    metrics.set(key, filtered);
  }

  const tsList = timeSeriesData.get(key);
  if (tsList) {
    const filtered = tsList.filter(d => d.timestamp > cutoff);
    timeSeriesData.set(key, filtered);
  }
}

// ============================================================================
// METRIC QUERYING
// ============================================================================

/**
 * Get metrics
 */
export function getMetrics(filters?: {
  module?: string;
  name?: string;
  tags?: Record<string, string>;
  since?: number;
  limit?: number;
}): MetricValue[] {
  let result: MetricValue[] = [];

  for (const [key, metricList] of metrics) {
    const [module, name] = key.split(':');

    if (filters?.module && module !== filters.module) continue;
    if (filters?.name && name !== filters.name) continue;

    for (const metric of metricList) {
      if (filters?.since && metric.timestamp < filters.since) continue;

      if (filters?.tags) {
        let matches = true;
        for (const [tagKey, tagValue] of Object.entries(filters.tags)) {
          if (metric.tags[tagKey] !== tagValue) {
            matches = false;
            break;
          }
        }
        if (!matches) continue;
      }

      result.push(metric);
    }
  }

  result.sort((a, b) => b.timestamp - a.timestamp);

  if (filters?.limit) {
    result = result.slice(0, filters.limit);
  }

  return result;
}

/**
 * Get metric aggregation
 */
export function getMetricAggregation(config: {
  metricName: string;
  module: string;
  period: MetricAggregation['period'];
  aggregation: MetricAggregation['aggregation'];
  since?: number;
}): MetricAggregation {
  const { metricName, module, period, aggregation } = config;
  const periodMs = parsePeriod(period);
  const now = Date.now();
  const startTime = config.since || (now - periodMs);
  const endTime = now;

  const key = `${module}:${metricName}`;
  const metricList = metrics.get(key) || [];

  const relevantMetrics = metricList.filter(m => m.timestamp >= startTime && m.timestamp <= endTime);
  const values = relevantMetrics.map(m => ({ timestamp: m.timestamp, value: m.value }));

  let currentValue: number;
  switch (aggregation) {
    case 'avg':
      currentValue = values.length > 0 ? values.reduce((s, v) => s + v.value, 0) / values.length : 0;
      break;
    case 'sum':
      currentValue = values.reduce((s, v) => s + v.value, 0);
      break;
    case 'min':
      currentValue = values.length > 0 ? Math.min(...values.map(v => v.value)) : 0;
      break;
    case 'max':
      currentValue = values.length > 0 ? Math.max(...values.map(v => v.value)) : 0;
      break;
    case 'count':
      currentValue = values.length;
      break;
    case 'p50':
      currentValue = calculatePercentile(values.map(v => v.value), 50);
      break;
    case 'p95':
      currentValue = calculatePercentile(values.map(v => v.value), 95);
      break;
    case 'p99':
      currentValue = calculatePercentile(values.map(v => v.value), 99);
      break;
    default:
      currentValue = 0;
  }

  const result: MetricAggregation = {
    id: `agg_${generateUUID()}`,
    metricName,
    period,
    aggregation,
    startTime,
    endTime,
    values: aggregateByInterval(values, period),
    currentValue
  };

  return result;
}

/**
 * Parse period string to milliseconds
 */
function parsePeriod(period: MetricAggregation['period']): number {
  switch (period) {
    case '1m': return 60 * 1000;
    case '5m': return 5 * 60 * 1000;
    case '15m': return 15 * 60 * 1000;
    case '1h': return 60 * 60 * 1000;
    case '1d': return 24 * 60 * 60 * 1000;
  }
}

/**
 * Calculate percentile
 */
function calculatePercentile(values: number[], percentile: number): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const index = Math.ceil((percentile / 100) * sorted.length) - 1;
  return sorted[Math.max(0, index)];
}

/**
 * Aggregate by interval
 */
function aggregateByInterval(values: Array<{ timestamp: number; value: number }>, period: MetricAggregation['period']): Array<{ timestamp: number; value: number }> {
  if (values.length === 0) return [];

  const intervalMs = parsePeriod(period) / 10; // 10 points
  const result: Array<{ timestamp: number; value: number }> = [];
  const now = Date.now();
  const startTime = now - parsePeriod(period);

  for (let t = startTime; t <= now; t += intervalMs) {
    const intervalValues = values.filter(v => v.timestamp >= t && v.timestamp < t + intervalMs);
    const avg = intervalValues.length > 0 
      ? intervalValues.reduce((s, v) => s + v.value, 0) / intervalValues.length 
      : 0;
    result.push({ timestamp: t, value: avg });
  }

  return result;
}

// ============================================================================
// HEALTH MONITORING
// ============================================================================

/**
 * Update module health
 */
export function updateModuleHealth(moduleId: string, moduleName: string, metrics: {
  errorRate: number;
  latency: number;
  throughput: number;
  availability: number;
}): ModuleHealth {
  const issues: HealthIssue[] = [];
  let score = 100;

  // Check error rate
  if (metrics.errorRate > 0.1) {
    issues.push({
      id: `issue_${generateUUID()}`,
      type: 'error_rate',
      severity: metrics.errorRate > 0.5 ? 'critical' : metrics.errorRate > 0.25 ? 'high' : 'medium',
      description: `High error rate: ${(metrics.errorRate * 100).toFixed(1)}%`,
      detectedAt: Date.now(),
      metric: 'error_rate',
      threshold: 0.1,
      currentValue: metrics.errorRate
    });
    score -= Math.min(40, metrics.errorRate * 100);
  }

  // Check latency
  if (metrics.latency > 1000) {
    issues.push({
      id: `issue_${generateUUID()}`,
      type: 'latency',
      severity: metrics.latency > 5000 ? 'critical' : metrics.latency > 2000 ? 'high' : 'medium',
      description: `High latency: ${metrics.latency.toFixed(0)}ms`,
      detectedAt: Date.now(),
      metric: 'latency',
      threshold: 1000,
      currentValue: metrics.latency
    });
    score -= Math.min(30, metrics.latency / 100);
  }

  // Check availability
  if (metrics.availability < 0.99) {
    issues.push({
      id: `issue_${generateUUID()}`,
      type: 'availability',
      severity: metrics.availability < 0.9 ? 'critical' : metrics.availability < 0.95 ? 'high' : 'medium',
      description: `Low availability: ${(metrics.availability * 100).toFixed(2)}%`,
      detectedAt: Date.now(),
      metric: 'availability',
      threshold: 0.99,
      currentValue: metrics.availability
    });
    score -= Math.min(30, (1 - metrics.availability) * 100);
  }

  score = Math.max(0, score);

  let status: ModuleHealth['status'];
  if (score >= 90) status = 'healthy';
  else if (score >= 70) status = 'degraded';
  else status = 'unhealthy';

  const health: ModuleHealth = {
    moduleId,
    moduleName,
    status,
    score,
    lastCheck: Date.now(),
    issues,
    metrics,
    dependencies: []
  };

  healthStatuses.set(moduleId, health);
  return health;
}

/**
 * Get module health
 */
export function getModuleHealth(moduleId: string): ModuleHealth | undefined {
  return healthStatuses.get(moduleId);
}

/**
 * Get all module healths
 */
export function getAllModuleHealth(): ModuleHealth[] {
  return Array.from(healthStatuses.values());
}

/**
 * Get system health summary
 */
export function getSystemHealthSummary(): {
  overallStatus: 'healthy' | 'degraded' | 'unhealthy';
  overallScore: number;
  healthyCount: number;
  degradedCount: number;
  unhealthyCount: number;
  totalIssues: number;
  criticalIssues: number;
} {
  const allHealth = Array.from(healthStatuses.values());
  
  const healthyCount = allHealth.filter(h => h.status === 'healthy').length;
  const degradedCount = allHealth.filter(h => h.status === 'degraded').length;
  const unhealthyCount = allHealth.filter(h => h.status === 'unhealthy').length;

  const totalIssues = allHealth.reduce((sum, h) => sum + h.issues.length, 0);
  const criticalIssues = allHealth.reduce((sum, h) => 
    sum + h.issues.filter(i => i.severity === 'critical').length, 0);

  const overallScore = allHealth.length > 0 
    ? allHealth.reduce((sum, h) => sum + h.score, 0) / allHealth.length 
    : 100;

  let overallStatus: 'healthy' | 'degraded' | 'unhealthy';
  if (overallScore >= 90 && unhealthyCount === 0) overallStatus = 'healthy';
  else if (overallScore >= 70 && criticalIssues === 0) overallStatus = 'degraded';
  else overallStatus = 'unhealthy';

  return {
    overallStatus,
    overallScore,
    healthyCount,
    degradedCount,
    unhealthyCount,
    totalIssues,
    criticalIssues
  };
}

// ============================================================================
// DASHBOARDS
// ============================================================================

/**
 * Create dashboard
 */
export function createDashboard(config: {
  name: string;
  description: string;
  panels: Omit<DashboardPanel, 'id'>[];
  createdBy: string;
  isPublic?: boolean;
  refreshInterval?: number;
}): Dashboard {
  const now = Date.now();

  const dashboard: Dashboard = {
    id: `dashboard_${generateUUID()}`,
    name: config.name,
    description: config.description,
    panels: config.panels.map(p => ({ ...p, id: `panel_${generateUUID()}` })),
    layout: { columns: 12, rowHeight: 100 },
    refreshInterval: config.refreshInterval || 30000,
    timeRange: {
      default: '1h',
      options: ['15m', '1h', '6h', '24h', '7d']
    },
    createdBy: config.createdBy,
    createdAt: now,
    updatedAt: now,
    isPublic: config.isPublic ?? false
  };

  dashboards.set(dashboard.id, dashboard);
  return dashboard;
}

/**
 * Get dashboard
 */
export function getDashboard(dashboardId: string): Dashboard | undefined {
  return dashboards.get(dashboardId);
}

/**
 * List dashboards
 */
export function listDashboards(createdBy?: string): Dashboard[] {
  const all = Array.from(dashboards.values());
  return createdBy ? all.filter(d => d.createdBy === createdBy || d.isPublic) : all;
}

/**
 * Update dashboard
 */
export function updateDashboard(dashboardId: string, updates: Partial<Dashboard>): Dashboard | null {
  const dashboard = dashboards.get(dashboardId);
  if (!dashboard) return null;

  const protectedFields = ['id', 'createdAt', 'createdBy'];
  for (const key of Object.keys(updates)) {
    if (!protectedFields.includes(key)) {
      (dashboard as Record<string, unknown>)[key] = updates[key as keyof Dashboard];
    }
  }

  dashboard.updatedAt = Date.now();
  dashboards.set(dashboardId, dashboard);
  return dashboard;
}

/**
 * Delete dashboard
 */
export function deleteDashboard(dashboardId: string): boolean {
  return dashboards.delete(dashboardId);
}

// ============================================================================
// ALERTS
// ============================================================================

/**
 * Create alert rule
 */
export function createAlertRule(config: {
  name: string;
  description: string;
  metric: string;
  condition: AlertRule['condition'];
  severity: AlertRule['severity'];
  channels: string[];
  moduleFilter?: string[];
  tagsFilter?: Record<string, string>;
}): AlertRule {
  const now = Date.now();

  const rule: AlertRule = {
    id: `rule_${generateUUID()}`,
    name: config.name,
    description: config.description,
    metric: config.metric,
    condition: config.condition,
    severity: config.severity,
    channels: config.channels,
    moduleFilter: config.moduleFilter,
    tagsFilter: config.tagsFilter,
    enabled: true,
    createdAt: now,
    updatedAt: now,
    triggerCount: 0
  };

  alertRules.set(rule.id, rule);
  return rule;
}

/**
 * Check alerts for metric
 */
function checkAlerts(metric: MetricValue): void {
  for (const rule of alertRules.values()) {
    if (!rule.enabled) continue;

    // Check metric match
    if (rule.metric !== '*' && rule.metric !== metric.name) continue;

    // Check module filter
    if (rule.moduleFilter && !rule.moduleFilter.includes(metric.module)) continue;

    // Check tags filter
    if (rule.tagsFilter) {
      let matches = true;
      for (const [key, value] of Object.entries(rule.tagsFilter)) {
        if (metric.tags[key] !== value) {
          matches = false;
          break;
        }
      }
      if (!matches) continue;
    }

    // Evaluate condition
    const stateKey = `${rule.id}:${metric.module}:${metric.name}`;
    let state = alertStates.get(stateKey);

    const conditionMet = evaluateCondition(metric.value, rule.condition.operator, rule.condition.threshold);

    if (conditionMet) {
      if (!state || state.state === 'ok') {
        // Start pending state
        state = {
          id: stateKey,
          ruleId: rule.id,
          state: 'pending',
          currentValue: metric.value,
          startedAt: metric.timestamp,
          updatedAt: metric.timestamp,
          acknowledged: false
        };
      } else if (state.state === 'pending') {
        // Check if duration met
        const duration = (metric.timestamp - state.startedAt) / 1000;
        if (duration >= rule.condition.for) {
          // Fire alert
          state.state = 'firing';
          rule.lastTriggered = metric.timestamp;
          rule.triggerCount++;
          alertRules.set(rule.id, rule);

          // In production, send to notification channels here
        }
      }
      state.currentValue = metric.value;
      state.updatedAt = metric.timestamp;
    } else {
      if (state && state.state !== 'ok') {
        // Resolve alert
        state.state = 'resolved';
        state.updatedAt = metric.timestamp;
      } else {
        state = {
          id: stateKey,
          ruleId: rule.id,
          state: 'ok',
          currentValue: metric.value,
          startedAt: metric.timestamp,
          updatedAt: metric.timestamp,
          acknowledged: false
        };
      }
    }

    alertStates.set(stateKey, state);
  }
}

/**
 * Evaluate condition
 */
function evaluateCondition(value: number, operator: AlertRule['condition']['operator'], threshold: number): boolean {
  switch (operator) {
    case 'gt': return value > threshold;
    case 'lt': return value < threshold;
    case 'gte': return value >= threshold;
    case 'lte': return value <= threshold;
    case 'eq': return value === threshold;
    case 'neq': return value !== threshold;
  }
}

/**
 * Get alert rule
 */
export function getAlertRule(ruleId: string): AlertRule | undefined {
  return alertRules.get(ruleId);
}

/**
 * List alert rules
 */
export function listAlertRules(enabled?: boolean): AlertRule[] {
  const all = Array.from(alertRules.values());
  return enabled !== undefined ? all.filter(r => r.enabled === enabled) : all;
}

/**
 * Get alert states
 */
export function getAlertStates(ruleId?: string): AlertState[] {
  const all = Array.from(alertStates.values());
  return ruleId ? all.filter(s => s.ruleId === ruleId) : all;
}

/**
 * Acknowledge alert
 */
export function acknowledgeAlert(stateId: string, acknowledgedBy: string): AlertState | null {
  const state = alertStates.get(stateId);
  if (!state) return null;

  state.acknowledged = true;
  state.acknowledgedBy = acknowledgedBy;
  state.updatedAt = Date.now();
  alertStates.set(stateId, state);

  return state;
}

/**
 * Silence alert
 */
export function silenceAlert(stateId: string, durationMs: number): AlertState | null {
  const state = alertStates.get(stateId);
  if (!state) return null;

  state.silencedUntil = Date.now() + durationMs;
  state.updatedAt = Date.now();
  alertStates.set(stateId, state);

  return state;
}

// ============================================================================
// USAGE ANALYTICS
// ============================================================================

/**
 * Get usage analytics
 */
export function getUsageAnalytics(periodStart: number, periodEnd: number): UsageAnalytics {
  const allMetrics = getMetrics({ since: periodStart });

  // Filter to period
  const periodMetrics = allMetrics.filter(m => m.timestamp >= periodStart && m.timestamp <= periodEnd);

  // Calculate metrics
  const requestMetrics = periodMetrics.filter(m => m.name.includes('request') || m.name.includes('call'));
  const errorMetrics = periodMetrics.filter(m => m.name.includes('error'));
  const latencyMetrics = periodMetrics.filter(m => m.name.includes('latency') || m.name.includes('duration'));

  const totalRequests = requestMetrics.length;
  const totalErrors = errorMetrics.filter(m => m.value > 0).length;
  const errorRate = totalRequests > 0 ? totalErrors / totalRequests : 0;

  const latencyValues = latencyMetrics.map(m => m.value);
  const avgLatency = latencyValues.length > 0 
    ? latencyValues.reduce((s, v) => s + v, 0) / latencyValues.length 
    : 0;

  const periodDuration = (periodEnd - periodStart) / 1000;
  const throughput = periodDuration > 0 ? totalRequests / periodDuration : 0;

  // Group by module
  const requestsByModule: Record<string, number> = {};
  for (const metric of requestMetrics) {
    requestsByModule[metric.module] = (requestsByModule[metric.module] || 0) + 1;
  }

  // Calculate trends
  const midPoint = periodStart + (periodEnd - periodStart) / 2;
  const firstHalfRequests = requestMetrics.filter(m => m.timestamp < midPoint).length;
  const secondHalfRequests = requestMetrics.filter(m => m.timestamp >= midPoint).length;

  let requestsTrend: 'increasing' | 'stable' | 'decreasing';
  if (secondHalfRequests > firstHalfRequests * 1.1) requestsTrend = 'increasing';
  else if (secondHalfRequests < firstHalfRequests * 0.9) requestsTrend = 'decreasing';
  else requestsTrend = 'stable';

  return {
    period: { start: periodStart, end: periodEnd },
    totalRequests,
    requestsByModule,
    requestsByEndpoint: {},
    errorRate,
    avgLatency,
    latencyPercentiles: {
      p50: calculatePercentile(latencyValues, 50),
      p95: calculatePercentile(latencyValues, 95),
      p99: calculatePercentile(latencyValues, 99)
    },
    throughput,
    activeUsers: 0,
    topUsers: [],
    resourceUsage: { cpu: 0, memory: 0, storage: 0, network: 0 },
    trends: {
      requests: requestsTrend,
      errors: 'stable',
      latency: 'stable'
    }
  };
}

// ============================================================================
// EXPORT
// ============================================================================

/**
 * Export metrics
 */
export function exportMetrics(config: {
  format: MetricsExport['format'];
  metrics: string[];
  timeRange: { start: number; end: number };
}): MetricsExport {
  const exportItem: MetricsExport = {
    id: `export_${generateUUID()}`,
    format: config.format,
    metrics: config.metrics,
    timeRange: config.timeRange,
    createdAt: Date.now(),
    status: 'pending'
  };

  try {
    const allMetrics = getMetrics({ since: config.timeRange.start });
    const filteredMetrics = allMetrics.filter(m => 
      m.timestamp >= config.timeRange.start && 
      m.timestamp <= config.timeRange.end &&
      (config.metrics.includes('*') || config.metrics.includes(m.name))
    );

    switch (config.format) {
      case 'json':
        exportItem.data = JSON.stringify(filteredMetrics, null, 2);
        break;
      case 'csv':
        exportItem.data = convertToCSV(filteredMetrics);
        break;
      case 'prometheus':
        exportItem.data = convertToPrometheus(filteredMetrics);
        break;
      case 'influxdb':
        exportItem.data = convertToInfluxDB(filteredMetrics);
        break;
    }

    exportItem.status = 'completed';
  } catch {
    exportItem.status = 'failed';
  }

  exports.set(exportItem.id, exportItem);
  return exportItem;
}

/**
 * Convert to CSV
 */
function convertToCSV(metrics: MetricValue[]): string {
  const headers = ['name', 'value', 'type', 'timestamp', 'module', 'tags'];
  const rows = metrics.map(m => [
    m.name,
    m.value,
    m.type,
    new Date(m.timestamp).toISOString(),
    m.module,
    JSON.stringify(m.tags)
  ]);

  return [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
}

/**
 * Convert to Prometheus format
 */
function convertToPrometheus(metrics: MetricValue[]): string {
  return metrics.map(m => {
    const tags = Object.entries(m.tags).map(([k, v]) => `${k}="${v}"`).join(',');
    return `${m.name}{${tags},module="${m.module}"} ${m.value} ${Math.floor(m.timestamp / 1000)}`;
  }).join('\n');
}

/**
 * Convert to InfluxDB format
 */
function convertToInfluxDB(metrics: MetricValue[]): string {
  return metrics.map(m => {
    const tags = Object.entries(m.tags).map(([k, v]) => `${k}=${v}`).join(',');
    return `${m.name},module=${m.module},${tags} value=${m.value} ${m.timestamp}`;
  }).join('\n');
}

/**
 * Get export
 */
export function getExport(exportId: string): MetricsExport | undefined {
  return exports.get(exportId);
}

// ============================================================================
// STATISTICS
// ============================================================================

/**
 * Get dashboard statistics
 */
export function getDashboardStats(): {
  totalMetrics: number;
  totalDataPoints: number;
  modules: number;
  dashboards: number;
  alertRules: number;
  activeAlerts: number;
  storageUsed: string;
} {
  let totalDataPoints = 0;
  for (const metricList of metrics.values()) {
    totalDataPoints += metricList.length;
  }

  const modules = new Set(Array.from(metrics.keys()).map(k => k.split(':')[0]));

  const activeAlerts = Array.from(alertStates.values()).filter(s => s.state === 'firing').length;

  return {
    totalMetrics: metrics.size,
    totalDataPoints,
    modules: modules.size,
    dashboards: dashboards.size,
    alertRules: alertRules.size,
    activeAlerts,
    storageUsed: `${((totalDataPoints * 200) / 1024 / 1024).toFixed(2)} MB` // Estimate
  };
}

// ============================================================================
// TEST SUITE
// ============================================================================

/**
 * Run metrics dashboard tests
 */
export function runMetricsDashboardTests(): {
  passed: boolean;
  tests: { total: number; passed: number; failed: number };
  results: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const results: Array<{ name: string; passed: boolean; error?: string }> = [];

  try {
    // Test 1: Record metric
    const metric = recordMetric({
      name: 'test.value',
      value: 42,
      type: 'gauge',
      module: 'test',
      tags: { env: 'test' }
    });
    results.push({ name: 'Record Metric', passed: !!metric && metric.value === 42 });

    // Test 2: Get metrics
    const retrieved = getMetrics({ module: 'test' });
    results.push({ name: 'Get Metrics', passed: retrieved.length > 0 });

    // Test 3: Record timer
    const timer = recordTimer('test.latency', 'test', 150);
    results.push({ name: 'Record Timer', passed: timer.value === 150 && timer.type === 'timer' });

    // Test 4: Increment counter
    incrementCounter('test.counter', 'test');
    incrementCounter('test.counter', 'test');
    const counterMetrics = getMetrics({ name: 'test.counter' });
    results.push({ name: 'Increment Counter', passed: counterMetrics.length > 0 });

    // Test 5: Get aggregation
    const agg = getMetricAggregation({
      metricName: 'test.value',
      module: 'test',
      period: '1h',
      aggregation: 'avg'
    });
    results.push({ name: 'Get Aggregation', passed: agg.metricName === 'test.value' });

    // Test 6: Update module health
    const health = updateModuleHealth('test', 'Test Module', {
      errorRate: 0.01,
      latency: 100,
      throughput: 1000,
      availability: 0.999
    });
    results.push({ name: 'Update Module Health', passed: health.status === 'healthy' && health.score >= 90 });

    // Test 7: Get system health
    const systemHealth = getSystemHealthSummary();
    results.push({ name: 'Get System Health', passed: systemHealth.overallStatus === 'healthy' });

    // Test 8: Create dashboard
    const dashboard = createDashboard({
      name: 'Test Dashboard',
      description: 'Test dashboard',
      panels: [{
        title: 'Test Panel',
        type: 'line',
        metrics: [{ name: 'test.value', aggregation: 'avg' }],
        position: { x: 0, y: 0, width: 6, height: 4 },
        options: {}
      }],
      createdBy: 'tester'
    });
    results.push({ name: 'Create Dashboard', passed: !!dashboard.id && dashboard.panels.length === 1 });

    // Test 9: Create alert rule
    const rule = createAlertRule({
      name: 'Test Alert',
      description: 'Test alert rule',
      metric: 'test.value',
      condition: { operator: 'gt', threshold: 50, for: 60 },
      severity: 'warning',
      channels: ['email']
    });
    results.push({ name: 'Create Alert Rule', passed: !!rule.id && rule.enabled });

    // Test 10: Get usage analytics
    const analytics = getUsageAnalytics(Date.now() - 3600000, Date.now());
    results.push({ name: 'Get Usage Analytics', passed: !!analytics.period });

    // Test 11: Export metrics
    const exportResult = exportMetrics({
      format: 'json',
      metrics: ['test.value'],
      timeRange: { start: Date.now() - 3600000, end: Date.now() }
    });
    results.push({ name: 'Export Metrics', passed: exportResult.status === 'completed' });

    // Test 12: Get stats
    const stats = getDashboardStats();
    results.push({ name: 'Get Dashboard Stats', passed: stats.totalMetrics > 0 });

  } catch (error) {
    results.push({ name: 'Test Execution', passed: false, error: String(error) });
  }

  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;

  return {
    passed: failed === 0,
    tests: { total: results.length, passed, failed },
    results
  };
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

export default {
  recordMetric,
  recordTimer,
  incrementCounter,
  getMetrics,
  getMetricAggregation,
  updateModuleHealth,
  getModuleHealth,
  getAllModuleHealth,
  getSystemHealthSummary,
  createDashboard,
  getDashboard,
  listDashboards,
  updateDashboard,
  deleteDashboard,
  createAlertRule,
  getAlertRule,
  listAlertRules,
  getAlertStates,
  acknowledgeAlert,
  silenceAlert,
  getUsageAnalytics,
  exportMetrics,
  getExport,
  getDashboardStats,
  runMetricsDashboardTests
};
