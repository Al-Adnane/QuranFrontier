/**
 * Acoustic Security Layer
 * Ultrasonic and acoustic side-channel detection/prevention
 * 
 * @module frontier/acoustic-security
 * @version 1.0.0
 */

// ============================================================================
// TYPE DEFINITIONS
// ============================================================================

export interface FrequencyBand {
  min: number;
  max: number;
  threshold: number;
}

export interface AttackSignature {
  carrier: number;
  modulation: string;
  bandwidth: number;
  description: string;
}

export interface AcousticDetection {
  band: string;
  frequency: number;
  db: number;
  type: string;
  confidence: number;
  signature?: AttackSignature;
}

export interface JammingResult {
  jamId: string;
  targetFrequency: number;
  bandwidth: number;
  method: string;
  coverage: string;
  power: string;
}

export interface MaskingResult {
  type: string;
  duration: string;
  coverage: string;
  comfortLevel: string;
}

export interface AnalysisResult {
  isSuspicious: boolean;
  type?: string;
  peakFrequency?: number;
  confidence?: number;
  signature?: AttackSignature;
  features?: { spectralFlatness: number; crestFactor: number };
}

export interface ModulationDetection {
  type: string;
  frequencies?: number[];
  depth?: number;
  confidence: number;
  description: string;
}

// ============================================================================
// ACOUSTIC SECURITY LAYER
// ============================================================================

export class AcousticSecurityLayer {
  private sampleRate = 192000;
  private fftSize = 4096;
  private frequencyResolution: number;
  
  private bands: Record<string, FrequencyBand> = {
    audible: { min: 20, max: 20000, threshold: 60 },
    nearUltrasonic: { min: 20000, max: 22050, threshold: 40 },
    ultrasonic: { min: 22050, max: 48000, threshold: 30 },
    extremeUltrasonic: { min: 48000, max: 96000, threshold: 20 }
  };
  
  private signatures: Record<string, AttackSignature> = {
    fansmitter: {
      carrier: 4500,
      modulation: 'RPM',
      bandwidth: 100,
      description: 'CPU fan speed modulation'
    },
    diskfiltration: {
      carrier: 2086,
      modulation: 'seek_rate',
      bandwidth: 50,
      description: 'Hard drive actuator positioning'
    },
    ultrasonic_network: {
      carrier: 25000,
      modulation: 'FSK',
      bandwidth: 2000,
      description: 'Speaker-based ultrasonic mesh'
    },
    gyrophone: {
      carrier: 200,
      modulation: 'AM',
      bandwidth: 20,
      description: 'MEMS gyroscope resonance'
    },
    badbios: {
      carrier: 17000,
      modulation: 'OOK',
      bandwidth: 100,
      description: 'Speaker-to-speaker networking'
    }
  };
  
  private isMonitoring = false;
  private jammerNodes: Map<string, { active: boolean; frequency: number; startedAt: number }> = new Map();
  private detectionCallback: ((detection: AcousticDetection[]) => void) | null = null;

  constructor() {
    this.frequencyResolution = this.sampleRate / this.fftSize;
  }

  /**
   * Analyze audio data for acoustic threats
   */
  analyze(audioData: Uint8Array): AcousticDetection[] {
    const detections: AcousticDetection[] = [];
    
    const freqData = this.computeFFT(audioData);
    
    for (const [bandName, band] of Object.entries(this.bands)) {
      const startBin = Math.floor(band.min / this.frequencyResolution);
      const endBin = Math.floor(band.max / this.frequencyResolution);
      
      const energy = this.calculateBandEnergy(freqData, startBin, endBin);
      const db = 20 * Math.log10(energy / 255 + 0.001);
      
      if (db > band.threshold) {
        const analysis = this.analyzeSignal(freqData, startBin, endBin, bandName);
        
        if (analysis.isSuspicious) {
          detections.push({
            band: bandName,
            frequency: analysis.peakFrequency || 0,
            db,
            type: analysis.type || 'unknown',
            confidence: analysis.confidence || 0,
            signature: analysis.signature
          });
        }
      }
    }
    
    return detections;
  }

  private computeFFT(audioData: Uint8Array): Float32Array {
    const freqData = new Float32Array(this.fftSize / 2);
    const N = audioData.length;
    
    for (let k = 0; k < freqData.length; k++) {
      let real = 0;
      let imag = 0;
      
      for (let n = 0; n < N; n++) {
        const angle = -2 * Math.PI * k * n / N;
        real += audioData[n] * Math.cos(angle);
        imag += audioData[n] * Math.sin(angle);
      }
      
      freqData[k] = Math.sqrt(real * real + imag * imag) / N;
    }
    
    return freqData;
  }

  private calculateBandEnergy(data: Float32Array, startBin: number, endBin: number): number {
    let sum = 0;
    for (let i = startBin; i < endBin && i < data.length; i++) {
      sum += data[i] * data[i];
    }
    return Math.sqrt(sum / Math.max(1, endBin - startBin));
  }

  private analyzeSignal(data: Float32Array, startBin: number, endBin: number, bandName: string): AnalysisResult {
    let peakValue = 0;
    let peakBin = 0;
    
    for (let i = startBin; i < endBin && i < data.length; i++) {
      if (data[i] > peakValue) {
        peakValue = data[i];
        peakBin = i;
      }
    }
    
    const peakFrequency = peakBin * this.frequencyResolution;
    
    for (const [attackName, signature] of Object.entries(this.signatures)) {
      if (Math.abs(peakFrequency - signature.carrier) < signature.bandwidth) {
        return {
          isSuspicious: true,
          type: attackName,
          peakFrequency,
          confidence: 1 - Math.abs(peakFrequency - signature.carrier) / signature.bandwidth,
          signature
        };
      }
    }
    
    const spectralFlatness = this.calculateSpectralFlatness(data, startBin, endBin);
    const crestFactor = this.calculateCrestFactor(data, startBin, endBin);
    
    if (spectralFlatness < 0.3 && crestFactor > 10) {
      return {
        isSuspicious: true,
        type: 'unknown_modulated',
        peakFrequency,
        confidence: 0.6,
        features: { spectralFlatness, crestFactor }
      };
    }
    
    return { isSuspicious: false };
  }

  private calculateSpectralFlatness(data: Float32Array, start: number, end: number): number {
    let logSum = 0;
    let arithmeticSum = 0;
    let count = 0;
    
    for (let i = start; i < end && i < data.length; i++) {
      const val = Math.max(data[i], 0.001);
      logSum += Math.log(val);
      arithmeticSum += val;
      count++;
    }
    
    if (count === 0) return 1;
    
    const geometricMean = Math.exp(logSum / count);
    const arithmeticMean = arithmeticSum / count;
    
    return geometricMean / arithmeticMean;
  }

  private calculateCrestFactor(data: Float32Array, start: number, end: number): number {
    let max = 0;
    let sum = 0;
    
    for (let i = start; i < end && i < data.length; i++) {
      max = Math.max(max, Math.abs(data[i]));
      sum += data[i] * data[i];
    }
    
    const rms = Math.sqrt(sum / Math.max(1, end - start));
    return max / (rms + 0.001);
  }

  /**
   * Detect modulation patterns
   */
  detectModulation(audioData: Uint8Array): ModulationDetection[] {
    const detections: ModulationDetection[] = [];
    const freqData = this.computeFFT(audioData);
    
    const fskPeaks = this.detectFSK(freqData);
    if (fskPeaks.length >= 2) {
      detections.push({
        type: 'fsk_detected',
        frequencies: fskPeaks,
        confidence: 0.8,
        description: 'Frequency shift keying suggests digital data transmission'
      });
    }
    
    const amDepth = this.detectAM(audioData);
    if (amDepth > 0.5) {
      detections.push({
        type: 'am_detected',
        depth: amDepth,
        confidence: 0.7,
        description: 'Amplitude modulation detected'
      });
    }
    
    return detections;
  }

  private detectFSK(freqData: Float32Array): number[] {
    const peaks: Array<{ bin: number; value: number }> = [];
    
    for (let i = 1; i < freqData.length - 1; i++) {
      if (freqData[i] > freqData[i-1] && freqData[i] > freqData[i+1] && freqData[i] > 0.5) {
        peaks.push({ bin: i, value: freqData[i] });
      }
    }
    
    peaks.sort((a, b) => b.value - a.value);
    
    return peaks.slice(0, 2).map(p => p.bin * this.frequencyResolution);
  }

  private detectAM(audioData: Uint8Array): number {
    const envelope = this.hilbertEnvelope(audioData);
    const maxEnv = Math.max(...envelope);
    const minEnv = Math.min(...envelope);
    
    return (maxEnv - minEnv) / (maxEnv + minEnv + 0.001);
  }

  private hilbertEnvelope(signal: Uint8Array): Float32Array {
    const envelope = new Float32Array(signal.length);
    
    for (let i = 1; i < signal.length - 1; i++) {
      envelope[i] = Math.sqrt(
        signal[i] * signal[i] + 
        Math.pow((signal[i+1] - signal[i-1]) / 2, 2)
      );
    }
    
    return envelope;
  }

  /**
   * Activate jamming countermeasure
   */
  activateJamming(targetFrequency: number, bandwidth = 1000): JammingResult {
    const jamId = `jam_${Date.now()}`;
    
    this.jammerNodes.set(jamId, {
      active: true,
      frequency: targetFrequency,
      startedAt: Date.now()
    });
    
    setTimeout(() => this.stopJamming(jamId), 30000);
    
    return {
      jamId,
      targetFrequency,
      bandwidth,
      method: 'destructive_interference',
      coverage: 'local_360_degrees',
      power: 'safe_for_humans_ultrasonic'
    };
  }

  stopJamming(jamId: string): void {
    const jammer = this.jammerNodes.get(jamId);
    if (jammer) {
      jammer.active = false;
      this.jammerNodes.delete(jamId);
    }
  }

  /**
   * White noise masking for audible range
   */
  generateMaskingNoise(duration: number): Float32Array {
    const sampleCount = this.sampleRate * duration;
    const buffer = new Float32Array(sampleCount);
    
    // Pink noise generation
    let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
    
    for (let i = 0; i < sampleCount; i++) {
      const white = Math.random() * 2 - 1;
      
      b0 = 0.99886 * b0 + white * 0.0555179;
      b1 = 0.99332 * b1 + white * 0.0750759;
      b2 = 0.96900 * b2 + white * 0.1538520;
      b3 = 0.86650 * b3 + white * 0.3104856;
      b4 = 0.55000 * b4 + white * 0.5329522;
      b5 = -0.7616 * b5 - white * 0.0168980;
      
      buffer[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.11;
      b6 = white * 0.115926;
    }
    
    return buffer;
  }

  /**
   * Countermeasures for known attacks
   */
  async counterFansmitter(): Promise<{ action: string; method: string; effectiveness: string }> {
    return {
      action: 'fan_speed_randomization',
      method: 'pwm_jitter',
      effectiveness: 'high'
    };
  }

  async counterDiskfiltration(): Promise<{ action: string; method: string; effectiveness: string; performanceImpact: string }> {
    return {
      action: 'seek_noise_injection',
      method: 'random_seek_patterns',
      effectiveness: 'medium',
      performanceImpact: '5%'
    };
  }

  async counterUltrasonicNetwork(): Promise<JammingResult & { speakerStatus: string }> {
    const jam = this.activateJamming(25000, 5000);
    return {
      ...jam,
      speakerStatus: 'disabled_above_20khz'
    };
  }

  setDetectionCallback(callback: (detection: AcousticDetection[]) => void): void {
    this.detectionCallback = callback;
  }

  getStatus() {
    return {
      enabled: true,
      monitoring: this.isMonitoring,
      sampleRate: this.sampleRate,
      detectedSignatures: Object.keys(this.signatures).length,
      activeJammers: this.jammerNodes.size
    };
  }
}

// Singleton instance
let acousticSecurityInstance: AcousticSecurityLayer | null = null;

export function getAcousticSecurity(): AcousticSecurityLayer {
  if (!acousticSecurityInstance) {
    acousticSecurityInstance = new AcousticSecurityLayer();
  }
  return acousticSecurityInstance;
}

export function analyzeAudio(audioData: Uint8Array): AcousticDetection[] {
  return getAcousticSecurity().analyze(audioData);
}

export default AcousticSecurityLayer;
