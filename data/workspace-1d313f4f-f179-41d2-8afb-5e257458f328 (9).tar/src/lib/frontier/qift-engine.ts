/**
 * QIFT Engine Module
 *
 * Quantized Iterative Feature Transformation Engine.
 * Adaptive feature transformation for personalized ML pipelines.
 *
 * @module frontier/qift-engine
 * @version 9.0.0
 *
 * Capabilities:
 * - Adaptive feature transformation
 * - Personalized feature weighting
 * - Quantized feature extraction
 * - Iterative refinement
 * - Domain adaptation
 * - Feature importance tracking
 * - Transformation caching
 * - Multi-modal feature fusion
 * - Real-time adaptation
 * - Feature drift detection
 */

import { generateUUID, sha256Hash } from '../crypto-utils';

// ============================================================================
// TYPES
// ============================================================================

/**
 * Feature type
 */
export type FeatureType = 
  | 'numeric' | 'categorical' | 'ordinal' | 'binary' 
  | 'temporal' | 'spatial' | 'textual' | 'audio' | 'visual' 
  | 'behavioral' | 'contextual' | 'derived';

/**
 * Raw feature
 */
export interface RawFeature {
  /** Feature ID */
  id: string;
  /** Feature name */
  name: string;
  /** Feature type */
  type: FeatureType;
  /** Raw value */
  rawValue: unknown;
  /** Timestamp */
  timestamp: number;
  /** Source */
  source: string;
  /** Quality score */
  quality: number;
  /** Metadata */
  metadata: Record<string, unknown>;
}

/**
 * Transformed feature
 */
export interface TransformedFeature {
  /** Feature ID */
  id: string;
  /** Source feature ID */
  sourceId: string;
  /** Feature name */
  name: string;
  /** Transformed value */
  value: number;
  /** Quantization level */
  quantizationLevel: number;
  /** Transformation type */
  transformationType: TransformationType;
  /** Feature importance */
  importance: number;
  /** Confidence */
  confidence: number;
  /** Transformation metadata */
  transformationMeta: {
    iterations: number;
    convergenceScore: number;
    adaptationDelta: number;
  };
}

/**
 * Transformation type
 */
export type TransformationType = 
  | 'normalization' | 'standardization' | 'quantization' 
  | 'embedding' | 'encoding' | 'scaling' 
  | 'aggregation' | 'decomposition' | 'interaction'
  | 'polynomial' | 'binning' | 'log_transform'
  | 'custom';

/**
 * Feature transformation rule
 */
export interface TransformationRule {
  /** Rule ID */
  id: string;
  /** Rule name */
  name: string;
  /** Applicable feature types */
  applicableTypes: FeatureType[];
  /** Transformation type */
  transformationType: TransformationType;
  /** Rule parameters */
  parameters: Record<string, unknown>;
  /** Priority (higher = applied first) */
  priority: number;
  /** Enabled */
  enabled: boolean;
  /** Custom transformation function name */
  customFunction?: string;
}

/**
 * Feature weight profile
 */
export interface FeatureWeightProfile {
  /** Profile ID */
  id: string;
  /** Profile name */
  name: string;
  /** Domain/context */
  domain: string;
  /** Feature weights */
  weights: Map<string, number>;
  /** Weight history */
  history: WeightHistoryEntry[];
  /** Adaptation rate */
  adaptationRate: number;
  /** Last updated */
  updatedAt: number;
  /** Performance metrics */
  performance: {
    accuracy: number;
    precision: number;
    recall: number;
    f1Score: number;
  };
}

/**
 * Weight history entry
 */
export interface WeightHistoryEntry {
  /** Feature name */
  featureName: string;
  /** Old weight */
  oldWeight: number;
  /** New weight */
  newWeight: number;
  /** Reason for change */
  reason: string;
  /** Timestamp */
  timestamp: number;
}

/**
 * QIFT Configuration
 */
export interface QIFTConfig {
  /** Number of quantization levels */
  quantizationLevels: number;
  /** Maximum iterations */
  maxIterations: number;
  /** Convergence threshold */
  convergenceThreshold: number;
  /** Adaptation learning rate */
  learningRate: number;
  /** Feature importance decay */
  importanceDecay: number;
  /** Enable caching */
  enableCaching: boolean;
  /** Cache TTL (milliseconds) */
  cacheTtl: number;
  /** Enable drift detection */
  enableDriftDetection: boolean;
  /** Drift threshold */
  driftThreshold: number;
}

/**
 * QIFT Pipeline
 */
export interface QIFTPipeline {
  /** Pipeline ID */
  id: string;
  /** Pipeline name */
  name: string;
  /** Domain */
  domain: string;
  /** Input feature spec */
  inputSpec: FeatureSpec[];
  /** Output feature spec */
  outputSpec: FeatureSpec[];
  /** Transformation rules */
  rules: TransformationRule[];
  /** Weight profile ID */
  weightProfileId: string;
  /** Pipeline status */
  status: 'draft' | 'active' | 'deprecated' | 'archived';
  /** Version */
  version: string;
  /** Created timestamp */
  createdAt: number;
  /** Updated timestamp */
  updatedAt: number;
}

/**
 * Feature specification
 */
export interface FeatureSpec {
  /** Feature name */
  name: string;
  /** Feature type */
  type: FeatureType;
  /** Required */
  required: boolean;
  /** Default value */
  defaultValue?: unknown;
  /** Validation rules */
  validation?: {
    min?: number;
    max?: number;
    pattern?: string;
    enum?: string[];
  };
}

/**
 * Transformation result
 */
export interface TransformationResult {
  /** Result ID */
  id: string;
  /** Pipeline ID */
  pipelineId: string;
  /** Input features */
  inputFeatures: RawFeature[];
  /** Transformed features */
  transformedFeatures: TransformedFeature[];
  /** Feature vector */
  featureVector: number[];
  /** Total iterations */
  totalIterations: number;
  /** Convergence achieved */
  converged: boolean;
  /** Processing time (milliseconds) */
  processingTimeMs: number;
  /** Quality score */
  qualityScore: number;
  /** Drift detected */
  driftDetected: boolean;
  /** Timestamp */
  timestamp: number;
}

/**
 * Feature drift report
 */
export interface FeatureDriftReport {
  /** Report ID */
  id: string;
  /** Feature name */
  featureName: string;
  /** Drift type */
  driftType: 'sudden' | 'gradual' | 'incremental' | 'recurring';
  /** Drift magnitude */
  magnitude: number;
  /** Statistical significance */
  pValue: number;
  /** Reference distribution */
  referenceDistribution: {
    mean: number;
    std: number;
    min: number;
    max: number;
  };
  /** Current distribution */
  currentDistribution: {
    mean: number;
    std: number;
    min: number;
    max: number;
  };
  /** Detected timestamp */
  detectedAt: number;
  /** Affected models */
  affectedModels: string[];
  /** Recommended actions */
  recommendations: string[];
}

/**
 * Adaptation request
 */
export interface AdaptationRequest {
  /** Request ID */
  id: string;
  /** Pipeline ID */
  pipelineId: string;
  /** Feedback type */
  feedbackType: 'positive' | 'negative' | 'neutral';
  /** Target features */
  targetFeatures: string[];
  /** Expected outcome */
  expectedOutcome?: number;
  /** Actual outcome */
  actualOutcome: number;
  /** Context */
  context: Record<string, unknown>;
  /** Timestamp */
  timestamp: number;
}

/**
 * Adaptation result
 */
export interface AdaptationResult {
  /** Result ID */
  id: string;
  /** Request ID */
  requestId: string;
  /** Success */
  success: boolean;
  /** Weight changes */
  weightChanges: Array<{
    featureName: string;
    oldWeight: number;
    newWeight: number;
    change: number;
  }>;
  /** Performance improvement */
  performanceImprovement: number;
  /** New accuracy */
  newAccuracy: number;
  /** Timestamp */
  timestamp: number;
}

// ============================================================================
// STORAGE
// ============================================================================

const pipelines = new Map<string, QIFTPipeline>();
const profiles = new Map<string, FeatureWeightProfile>();
const rules = new Map<string, TransformationRule>();
const results = new Map<string, TransformationResult>();
const driftReports = new Map<string, FeatureDriftReport>();
const cache = new Map<string, { value: TransformedFeature[]; timestamp: number }>();

// Configuration
let config: QIFTConfig = {
  quantizationLevels: 256,
  maxIterations: 100,
  convergenceThreshold: 0.001,
  learningRate: 0.01,
  importanceDecay: 0.995,
  enableCaching: true,
  cacheTtl: 300000, // 5 minutes
  enableDriftDetection: true,
  driftThreshold: 0.05
};

// Feature statistics for drift detection
const featureStats = new Map<string, {
  values: number[];
  mean: number;
  std: number;
  count: number;
}>();

// ============================================================================
// CONFIGURATION
// ============================================================================

/**
 * Update configuration
 */
export function updateConfig(newConfig: Partial<QIFTConfig>): QIFTConfig {
  config = { ...config, ...newConfig };
  return config;
}

/**
 * Get configuration
 */
export function getConfig(): QIFTConfig {
  return { ...config };
}

// ============================================================================
// PIPELINE MANAGEMENT
// ============================================================================

/**
 * Create pipeline
 */
export function createPipeline(params: {
  name: string;
  domain: string;
  inputSpec: FeatureSpec[];
  outputSpec: FeatureSpec[];
  rules?: TransformationRule[];
  weightProfileId?: string;
}): QIFTPipeline {
  const id = `pipeline_${generateUUID()}`;
  const now = Date.now();

  // Create default weight profile if not provided
  let weightProfileId = params.weightProfileId;
  if (!weightProfileId) {
    const profile = createWeightProfile({
      name: `${params.name}_weights`,
      domain: params.domain
    });
    weightProfileId = profile.id;
  }

  const pipeline: QIFTPipeline = {
    id,
    name: params.name,
    domain: params.domain,
    inputSpec: params.inputSpec,
    outputSpec: params.outputSpec,
    rules: params.rules || [],
    weightProfileId,
    status: 'draft',
    version: '1.0.0',
    createdAt: now,
    updatedAt: now
  };

  pipelines.set(id, pipeline);
  return pipeline;
}

/**
 * Get pipeline
 */
export function getPipeline(pipelineId: string): QIFTPipeline | undefined {
  return pipelines.get(pipelineId);
}

/**
 * Activate pipeline
 */
export function activatePipeline(pipelineId: string): QIFTPipeline | null {
  const pipeline = pipelines.get(pipelineId);
  if (!pipeline) return null;

  pipeline.status = 'active';
  pipeline.updatedAt = Date.now();
  pipelines.set(pipelineId, pipeline);
  return pipeline;
}

/**
 * List pipelines
 */
export function listPipelines(domain?: string, status?: QIFTPipeline['status']): QIFTPipeline[] {
  let result = Array.from(pipelines.values());
  if (domain) {
    result = result.filter(p => p.domain === domain);
  }
  if (status) {
    result = result.filter(p => p.status === status);
  }
  return result;
}

// ============================================================================
// WEIGHT PROFILE MANAGEMENT
// ============================================================================

/**
 * Create weight profile
 */
export function createWeightProfile(params: {
  name: string;
  domain: string;
  initialWeights?: Map<string, number>;
  adaptationRate?: number;
}): FeatureWeightProfile {
  const id = `profile_${generateUUID()}`;

  const profile: FeatureWeightProfile = {
    id,
    name: params.name,
    domain: params.domain,
    weights: params.initialWeights || new Map(),
    history: [],
    adaptationRate: params.adaptationRate || config.learningRate,
    updatedAt: Date.now(),
    performance: {
      accuracy: 0,
      precision: 0,
      recall: 0,
      f1Score: 0
    }
  };

  profiles.set(id, profile);
  return profile;
}

/**
 * Get weight profile
 */
export function getWeightProfile(profileId: string): FeatureWeightProfile | undefined {
  return profiles.get(profileId);
}

/**
 * Update feature weight
 */
export function updateFeatureWeight(
  profileId: string,
  featureName: string,
  newWeight: number,
  reason: string
): FeatureWeightProfile | null {
  const profile = profiles.get(profileId);
  if (!profile) return null;

  const oldWeight = profile.weights.get(featureName) || 0;
  profile.weights.set(featureName, newWeight);

  profile.history.push({
    featureName,
    oldWeight,
    newWeight,
    reason,
    timestamp: Date.now()
  });

  profile.updatedAt = Date.now();
  profiles.set(profileId, profile);

  return profile;
}

// ============================================================================
// TRANSFORMATION RULES
// ============================================================================

/**
 * Create transformation rule
 */
export function createTransformationRule(params: {
  name: string;
  applicableTypes: FeatureType[];
  transformationType: TransformationType;
  parameters: Record<string, unknown>;
  priority?: number;
  customFunction?: string;
}): TransformationRule {
  const rule: TransformationRule = {
    id: `rule_${generateUUID()}`,
    name: params.name,
    applicableTypes: params.applicableTypes,
    transformationType: params.transformationType,
    parameters: params.parameters,
    priority: params.priority || 0,
    enabled: true,
    customFunction: params.customFunction
  };

  rules.set(rule.id, rule);
  return rule;
}

/**
 * Add rule to pipeline
 */
export function addRuleToPipeline(pipelineId: string, ruleId: string): QIFTPipeline | null {
  const pipeline = pipelines.get(pipelineId);
  const rule = rules.get(ruleId);
  if (!pipeline || !rule) return null;

  pipeline.rules.push(rule);
  pipeline.rules.sort((a, b) => b.priority - a.priority);
  pipeline.updatedAt = Date.now();
  pipelines.set(pipelineId, pipeline);

  return pipeline;
}

// ============================================================================
// FEATURE TRANSFORMATION
// ============================================================================

/**
 * Transform features through pipeline
 */
export function transformFeatures(
  pipelineId: string,
  rawFeatures: RawFeature[]
): TransformationResult {
  const pipeline = pipelines.get(pipelineId);
  if (!pipeline) {
    throw new Error(`Pipeline ${pipelineId} not found`);
  }

  const startTime = performance.now();
  const id = `result_${generateUUID()}`;

  // Check cache
  if (config.enableCaching) {
    const cacheKey = generateCacheKey(pipelineId, rawFeatures);
    const cached = cache.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < config.cacheTtl) {
      const cachedResult: TransformationResult = {
        id,
        pipelineId,
        inputFeatures: rawFeatures,
        transformedFeatures: cached.value,
        featureVector: cached.value.map(f => f.value),
        totalIterations: 0,
        converged: true,
        processingTimeMs: performance.now() - startTime,
        qualityScore: 1.0,
        driftDetected: false,
        timestamp: Date.now()
      };
      results.set(id, cachedResult);
      return cachedResult;
    }
  }

  // Get weight profile
  const profile = profiles.get(pipeline.weightProfileId);

  // Apply transformations iteratively
  let currentFeatures = [...rawFeatures];
  let transformedFeatures: TransformedFeature[] = [];
  let iterations = 0;
  let converged = false;
  let previousVector: number[] = [];

  while (iterations < config.maxIterations && !converged) {
    transformedFeatures = applyTransformations(
      currentFeatures,
      pipeline.rules,
      profile
    );

    // Quantize features
    transformedFeatures = quantizeFeatures(transformedFeatures);

    // Check convergence
    const currentVector = transformedFeatures.map(f => f.value);
    if (previousVector.length > 0) {
      const convergence = calculateConvergence(previousVector, currentVector);
      if (convergence < config.convergenceThreshold) {
        converged = true;
      }
    }
    previousVector = currentVector;
    iterations++;
  }

  // Calculate quality score
  const qualityScore = calculateQualityScore(transformedFeatures);

  // Check for drift
  let driftDetected = false;
  if (config.enableDriftDetection) {
    driftDetected = checkForDrift(transformedFeatures, pipelineId);
  }

  // Update feature statistics
  for (const feature of transformedFeatures) {
    updateFeatureStatistics(feature.name, feature.value);
  }

  // Cache result
  if (config.enableCaching) {
    const cacheKey = generateCacheKey(pipelineId, rawFeatures);
    cache.set(cacheKey, { value: transformedFeatures, timestamp: Date.now() });
  }

  const processingTimeMs = performance.now() - startTime;

  const result: TransformationResult = {
    id,
    pipelineId,
    inputFeatures: rawFeatures,
    transformedFeatures,
    featureVector: transformedFeatures.map(f => f.value),
    totalIterations: iterations,
    converged,
    processingTimeMs,
    qualityScore,
    driftDetected,
    timestamp: Date.now()
  };

  results.set(id, result);
  return result;
}

/**
 * Apply transformation rules
 */
function applyTransformations(
  features: RawFeature[],
  rules: TransformationRule[],
  profile?: FeatureWeightProfile
): TransformedFeature[] {
  const transformed: TransformedFeature[] = [];

  for (const feature of features) {
    // Find applicable rules
    const applicableRules = rules.filter(r => 
      r.enabled && r.applicableTypes.includes(feature.type)
    );

    let value = 0;
    let transformationType: TransformationType = 'normalization';
    let iterations = 0;
    let adaptationDelta = 0;

    for (const rule of applicableRules) {
      const result = applyRule(feature, rule);
      value = result.value;
      transformationType = rule.transformationType;
      iterations += result.iterations;
      adaptationDelta += result.delta;
    }

    // Apply weight from profile
    const weight = profile?.weights.get(feature.name) || 1;
    value *= weight;

    transformed.push({
      id: `tf_${generateUUID()}`,
      sourceId: feature.id,
      name: feature.name,
      value,
      quantizationLevel: config.quantizationLevels,
      transformationType,
      importance: weight,
      confidence: feature.quality,
      transformationMeta: {
        iterations,
        convergenceScore: 1 - adaptationDelta,
        adaptationDelta
      }
    });
  }

  return transformed;
}

/**
 * Apply single rule
 */
function applyRule(
  feature: RawFeature,
  rule: TransformationRule
): { value: number; iterations: number; delta: number } {
  const params = rule.parameters;
  let value = 0;
  let iterations = 1;
  let delta = 0;

  switch (rule.transformationType) {
    case 'normalization':
      const normMin = params.min as number || 0;
      const normMax = params.max as number || 1;
      const rawNum = Number(feature.rawValue);
      value = (rawNum - normMin) / (normMax - normMin);
      value = Math.max(0, Math.min(1, value));
      break;

    case 'standardization':
      const mean = params.mean as number || 0;
      const std = params.std as number || 1;
      value = (Number(feature.rawValue) - mean) / std;
      break;

    case 'quantization':
      const levels = params.levels as number || config.quantizationLevels;
      const qMin = params.min as number || 0;
      const qMax = params.max as number || 1;
      const normalized = (Number(feature.rawValue) - qMin) / (qMax - qMin);
      value = Math.floor(normalized * levels) / levels;
      break;

    case 'log_transform':
      value = Math.log(Number(feature.rawValue) + 1);
      break;

    case 'binning':
      const bins = params.bins as number[] || [0, 0.25, 0.5, 0.75, 1];
      const binValue = Number(feature.rawValue);
      for (let i = 0; i < bins.length - 1; i++) {
        if (binValue >= bins[i] && binValue < bins[i + 1]) {
          value = i / (bins.length - 1);
          break;
        }
      }
      break;

    case 'encoding':
      if (feature.type === 'categorical') {
        const categories = params.categories as string[] || [];
        value = categories.indexOf(String(feature.rawValue)) / Math.max(1, categories.length - 1);
      }
      break;

    case 'scaling':
      const scale = params.scale as number || 1;
      value = Number(feature.rawValue) * scale;
      break;

    default:
      value = Number(feature.rawValue) || 0;
  }

  return { value, iterations, delta };
}

/**
 * Quantize features
 */
function quantizeFeatures(features: TransformedFeature[]): TransformedFeature[] {
  const levels = config.quantizationLevels;

  return features.map(f => {
    // Normalize to [0, 1]
    const normalized = Math.max(0, Math.min(1, f.value));
    
    // Quantize
    const quantized = Math.floor(normalized * levels) / levels;

    return {
      ...f,
      value: quantized,
      quantizationLevel: levels
    };
  });
}

/**
 * Calculate convergence
 */
function calculateConvergence(previous: number[], current: number[]): number {
  if (previous.length !== current.length) return 1;

  let sumSquaredDiff = 0;
  for (let i = 0; i < previous.length; i++) {
    sumSquaredDiff += Math.pow(current[i] - previous[i], 2);
  }

  return Math.sqrt(sumSquaredDiff / previous.length);
}

/**
 * Calculate quality score
 */
function calculateQualityScore(features: TransformedFeature[]): number {
  if (features.length === 0) return 0;

  const avgConfidence = features.reduce((sum, f) => sum + f.confidence, 0) / features.length;
  const avgConvergence = features.reduce((sum, f) => sum + f.transformationMeta.convergenceScore, 0) / features.length;

  return (avgConfidence + avgConvergence) / 2;
}

// ============================================================================
// DRIFT DETECTION
// ============================================================================

/**
 * Update feature statistics
 */
function updateFeatureStatistics(featureName: string, value: number): void {
  const stats = featureStats.get(featureName) || {
    values: [],
    mean: 0,
    std: 0,
    count: 0
  };

  stats.values.push(value);
  if (stats.values.length > 1000) {
    stats.values = stats.values.slice(-1000);
  }

  // Update statistics
  stats.count = stats.values.length;
  stats.mean = stats.values.reduce((a, b) => a + b, 0) / stats.count;

  const squaredDiffs = stats.values.map(v => Math.pow(v - stats.mean, 2));
  stats.std = Math.sqrt(squaredDiffs.reduce((a, b) => a + b, 0) / stats.count);

  featureStats.set(featureName, stats);
}

/**
 * Check for drift
 */
function checkForDrift(features: TransformedFeature[], pipelineId: string): boolean {
  for (const feature of features) {
    const stats = featureStats.get(feature.name);
    if (!stats || stats.count < 30) continue;

    // Calculate z-score
    const zScore = stats.std > 0 ? Math.abs(feature.value - stats.mean) / stats.std : 0;

    if (zScore > 3) { // More than 3 standard deviations
      // Generate drift report
      const report: FeatureDriftReport = {
        id: `drift_${generateUUID()}`,
        featureName: feature.name,
        driftType: 'sudden',
        magnitude: zScore,
        pValue: 2 * (1 - normalCDF(zScore)),
        referenceDistribution: {
          mean: stats.mean,
          std: stats.std,
          min: Math.min(...stats.values),
          max: Math.max(...stats.values)
        },
        currentDistribution: {
          mean: feature.value,
          std: 0,
          min: feature.value,
          max: feature.value
        },
        detectedAt: Date.now(),
        affectedModels: [pipelineId],
        recommendations: [
          'Review recent changes to data pipeline',
          'Consider retraining model',
          'Update feature baseline'
        ]
      };

      driftReports.set(report.id, report);
      return true;
    }
  }

  return false;
}

/**
 * Normal CDF approximation
 */
function normalCDF(x: number): number {
  const a1 = 0.254829592;
  const a2 = -0.284496736;
  const a3 = 1.421413741;
  const a4 = -1.453152027;
  const a5 = 1.061405429;
  const p = 0.3275911;

  const sign = x < 0 ? -1 : 1;
  x = Math.abs(x) / Math.sqrt(2);

  const t = 1.0 / (1.0 + p * x);
  const y = 1.0 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * Math.exp(-x * x);

  return 0.5 * (1.0 + sign * y);
}

// ============================================================================
// ADAPTATION
// ============================================================================

/**
 * Submit adaptation request
 */
export function submitAdaptation(params: {
  pipelineId: string;
  feedbackType: 'positive' | 'negative' | 'neutral';
  targetFeatures: string[];
  actualOutcome: number;
  expectedOutcome?: number;
  context?: Record<string, unknown>;
}): AdaptationResult {
  const pipeline = pipelines.get(params.pipelineId);
  if (!pipeline) {
    throw new Error(`Pipeline ${params.pipelineId} not found`);
  }

  const profile = profiles.get(pipeline.weightProfileId);
  if (!profile) {
    throw new Error(`Weight profile not found`);
  }

  const request: AdaptationRequest = {
    id: `adapt_${generateUUID()}`,
    pipelineId: params.pipelineId,
    feedbackType: params.feedbackType,
    targetFeatures: params.targetFeatures,
    expectedOutcome: params.expectedOutcome,
    actualOutcome: params.actualOutcome,
    context: params.context || {},
    timestamp: Date.now()
  };

  // Calculate error
  const expected = params.expectedOutcome ?? params.actualOutcome;
  const error = expected - params.actualOutcome;

  // Adjust weights
  const weightChanges: AdaptationResult['weightChanges'] = [];
  const learningRate = profile.adaptationRate;

  for (const featureName of params.targetFeatures) {
    const oldWeight = profile.weights.get(featureName) || 1;
    let newWeight = oldWeight;

    if (params.feedbackType === 'positive') {
      // Increase weight for positive feedback
      newWeight = oldWeight + learningRate * Math.abs(error);
    } else if (params.feedbackType === 'negative') {
      // Decrease weight for negative feedback
      newWeight = oldWeight - learningRate * Math.abs(error);
    }

    // Clamp weight to reasonable range
    newWeight = Math.max(0.01, Math.min(10, newWeight));

    profile.weights.set(featureName, newWeight);
    profile.history.push({
      featureName,
      oldWeight,
      newWeight,
      reason: `Adaptation: ${params.feedbackType} feedback`,
      timestamp: Date.now()
    });

    weightChanges.push({
      featureName,
      oldWeight,
      newWeight,
      change: newWeight - oldWeight
    });
  }

  profile.updatedAt = Date.now();
  profiles.set(profile.id, profile);

  // Apply importance decay to non-target features
  for (const [name, weight] of profile.weights) {
    if (!params.targetFeatures.includes(name)) {
      const decayed = weight * config.importanceDecay;
      profile.weights.set(name, decayed);
    }
  }

  const result: AdaptationResult = {
    id: `adapt_result_${generateUUID()}`,
    requestId: request.id,
    success: true,
    weightChanges,
    performanceImprovement: Math.abs(error) * learningRate,
    newAccuracy: 1 - Math.abs(error),
    timestamp: Date.now()
  };

  return result;
}

// ============================================================================
// CACHING
// ============================================================================

/**
 * Generate cache key
 */
function generateCacheKey(pipelineId: string, features: RawFeature[]): string {
  const data = JSON.stringify({
    pipelineId,
    features: features.map(f => ({ id: f.id, value: f.rawValue }))
  });
  return sha256Hash(data);
}

/**
 * Clear cache
 */
export function clearCache(): void {
  cache.clear();
}

// ============================================================================
// QUERIES
// ============================================================================

/**
 * Get transformation result
 */
export function getTransformationResult(resultId: string): TransformationResult | undefined {
  return results.get(resultId);
}

/**
 * Get drift reports
 */
export function getDriftReports(featureName?: string): FeatureDriftReport[] {
  let reports = Array.from(driftReports.values());
  if (featureName) {
    reports = reports.filter(r => r.featureName === featureName);
  }
  return reports.sort((a, b) => b.detectedAt - a.detectedAt);
}

/**
 * Get feature statistics
 */
export function getFeatureStatistics(featureName: string): {
  mean: number;
  std: number;
  count: number;
} | undefined {
  return featureStats.get(featureName);
}

// ============================================================================
// STATISTICS
// ============================================================================

/**
 * Get system statistics
 */
export function getSystemStats(): {
  pipelines: { total: number; byStatus: Record<string, number> };
  profiles: { total: number; avgWeights: number };
  rules: { total: number; enabled: number };
  transformations: { total: number; avgProcessingTime: number };
  driftReports: { total: number; recent: number };
} {
  const allPipelines = Array.from(pipelines.values());
  const allProfiles = Array.from(profiles.values());
  const allRules = Array.from(rules.values());
  const allResults = Array.from(results.values());
  const allDriftReports = Array.from(driftReports.values());

  const avgProcessingTime = allResults.length > 0
    ? allResults.reduce((sum, r) => sum + r.processingTimeMs, 0) / allResults.length
    : 0;

  const avgWeights = allProfiles.length > 0
    ? allProfiles.reduce((sum, p) => sum + p.weights.size, 0) / allProfiles.length
    : 0;

  const recentDrift = allDriftReports.filter(
    r => r.detectedAt > Date.now() - 24 * 60 * 60 * 1000
  ).length;

  return {
    pipelines: {
      total: allPipelines.length,
      byStatus: allPipelines.reduce((acc, p) => {
        acc[p.status] = (acc[p.status] || 0) + 1;
        return acc;
      }, {} as Record<string, number>)
    },
    profiles: {
      total: allProfiles.length,
      avgWeights
    },
    rules: {
      total: allRules.length,
      enabled: allRules.filter(r => r.enabled).length
    },
    transformations: {
      total: allResults.length,
      avgProcessingTime
    },
    driftReports: {
      total: allDriftReports.length,
      recent: recentDrift
    }
  };
}

// ============================================================================
// TEST SUITE
// ============================================================================

/**
 * Run QIFT engine tests
 */
export function runQIFTEngineTests(): {
  passed: boolean;
  tests: { total: number; passed: number; failed: number };
  results: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const results: Array<{ name: string; passed: boolean; error?: string }> = [];

  try {
    // Test 1: Create pipeline
    const pipeline = createPipeline({
      name: 'Test Pipeline',
      domain: 'test',
      inputSpec: [
        { name: 'feature1', type: 'numeric', required: true }
      ],
      outputSpec: [
        { name: 'transformed1', type: 'numeric', required: true }
      ]
    });
    results.push({ name: 'Create Pipeline', passed: !!pipeline.id });

    // Test 2: Create weight profile
    const profile = createWeightProfile({
      name: 'Test Profile',
      domain: 'test'
    });
    results.push({ name: 'Create Weight Profile', passed: !!profile.id });

    // Test 3: Create transformation rule
    const rule = createTransformationRule({
      name: 'Normalization Rule',
      applicableTypes: ['numeric'],
      transformationType: 'normalization',
      parameters: { min: 0, max: 100 }
    });
    results.push({ name: 'Create Rule', passed: !!rule.id });

    // Test 4: Add rule to pipeline
    const updatedPipeline = addRuleToPipeline(pipeline.id, rule.id);
    results.push({ name: 'Add Rule to Pipeline', passed: (updatedPipeline?.rules.length || 0) > 0 });

    // Test 5: Activate pipeline
    const activePipeline = activatePipeline(pipeline.id);
    results.push({ name: 'Activate Pipeline', passed: activePipeline?.status === 'active' });

    // Test 6: Transform features
    const rawFeatures: RawFeature[] = [
      {
        id: 'rf_1',
        name: 'feature1',
        type: 'numeric',
        rawValue: 50,
        timestamp: Date.now(),
        source: 'test',
        quality: 0.9,
        metadata: {}
      }
    ];
    const transformResult = transformFeatures(pipeline.id, rawFeatures);
    results.push({ name: 'Transform Features', passed: transformResult.transformedFeatures.length > 0 });

    // Test 7: Feature vector generation
    results.push({ name: 'Feature Vector', passed: transformResult.featureVector.length > 0 });

    // Test 8: Convergence check
    results.push({ name: 'Convergence', passed: transformResult.converged || transformResult.totalIterations <= config.maxIterations });

    // Test 9: Update weight
    const updatedProfile = updateFeatureWeight(profile.id, 'feature1', 1.5, 'Test update');
    results.push({ name: 'Update Weight', passed: updatedProfile?.weights.get('feature1') === 1.5 });

    // Test 10: Adaptation
    const adaptation = submitAdaptation({
      pipelineId: pipeline.id,
      feedbackType: 'positive',
      targetFeatures: ['feature1'],
      actualOutcome: 0.9,
      expectedOutcome: 1.0
    });
    results.push({ name: 'Adaptation', passed: adaptation.success });

    // Test 11: Drift reports
    const driftReports = getDriftReports();
    results.push({ name: 'Drift Reports Query', passed: Array.isArray(driftReports) });

    // Test 12: System stats
    const stats = getSystemStats();
    results.push({ name: 'System Stats', passed: stats.pipelines.total > 0 });

  } catch (error) {
    results.push({ name: 'Test execution', passed: false, error: String(error) });
  }

  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;

  return {
    passed: failed === 0,
    tests: { total: results.length, passed, failed },
    results
  };
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

const qiftEngine = {
  // Configuration
  updateConfig,
  getConfig,
  // Pipeline management
  createPipeline,
  getPipeline,
  activatePipeline,
  listPipelines,
  addRuleToPipeline,
  // Weight profiles
  createWeightProfile,
  getWeightProfile,
  updateFeatureWeight,
  // Transformation rules
  createTransformationRule,
  // Feature transformation
  transformFeatures,
  // Adaptation
  submitAdaptation,
  // Cache
  clearCache,
  // Queries
  getTransformationResult,
  getDriftReports,
  getFeatureStatistics,
  // Stats
  getSystemStats,
  // Tests
  runQIFTEngineTests
};

export default qiftEngine;
