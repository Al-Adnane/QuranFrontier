/**
 * Insider Threat Detection Module
 *
 * Detects insider threats through resource correlation analysis.
 * Monitors clipboard, file system, network activity, and behavioral patterns.
 *
 * @module frontier/insider-threat-detection
 * @version 8.0.0
 *
 * Capabilities:
 * - Resource correlation analysis
 * - Behavioral anomaly detection
 * - Data exfiltration detection
 * - Access pattern monitoring
 * - User risk scoring
 * - Threat hunting support
 * - Alert generation
 * - Investigation workflow
 * - Integration with SIEM
 * - Machine learning detection
 */

import { generateUUID, sha256Hash, hmacSign } from '../crypto-utils';

// ============================================================================
// TYPES
// ============================================================================

/**
 * User profile
 */
export interface UserProfile {
  /** User ID */
  id: string;
  /** Username */
  username: string;
  /** Email */
  email: string;
  /** Department */
  department: string;
  /** Role */
  role: string;
  /** Access level */
  accessLevel: 'basic' | 'elevated' | 'privileged' | 'admin' | 'root';
  /** Employment status */
  status: 'active' | 'suspended' | 'terminated' | 'on_leave';
  /** Risk profile */
  riskProfile: UserRiskProfile;
  /** Baseline behavior */
  baseline: UserBaseline;
  /** Employment dates */
  hireDate: number;
  /** Last activity */
  lastActivity: number;
  /** Creation timestamp */
  createdAt: number;
}

/**
 * User risk profile
 */
export interface UserRiskProfile {
  /** Overall risk score (0-100) */
  riskScore: number;
  /** Risk level */
  riskLevel: 'minimal' | 'low' | 'moderate' | 'high' | 'critical';
  /** Risk factors */
  factors: RiskFactorDetail[];
  /** Threat indicators */
  indicators: ThreatIndicator[];
  /** Historical incidents */
  incidents: string[];
  /** Last assessment */
  lastAssessment: number;
  /** Trend direction */
  trend: 'increasing' | 'stable' | 'decreasing';
}

/**
 * Risk factor detail
 */
export interface RiskFactorDetail {
  /** Factor name */
  name: string;
  /** Factor category */
  category: 'behavioral' | 'technical' | 'contextual' | 'historical';
  /** Factor weight */
  weight: number;
  /** Current value */
  value: number;
  /** Threshold */
  threshold: number;
  /** Whether exceeded */
  exceeded: boolean;
  /** Last occurrence */
  lastOccurrence: number;
}

/**
 * Threat indicator
 */
export interface ThreatIndicator {
  /** Indicator ID */
  id: string;
  /** Indicator type */
  type: 'data_exfiltration' | 'privilege_abuse' | 'policy_violation' | 'suspicious_access' | 
        'anomalous_behavior' | 'credential_sharing' | 'system_abuse' | 'data_staging';
  /** Severity */
  severity: 'low' | 'medium' | 'high' | 'critical';
  /** Description */
  description: string;
  /** Evidence */
  evidence: string[];
  /** Confidence */
  confidence: number;
  /** First seen */
  firstSeen: number;
  /** Last seen */
  lastSeen: number;
  /** Occurrence count */
  count: number;
  /** Status */
  status: 'active' | 'investigating' | 'resolved' | 'false_positive';
}

/**
 * User baseline
 */
export interface UserBaseline {
  /** Typical working hours */
  workingHours: {
    start: number; // Hour of day (0-23)
    end: number;
    variance: number;
  };
  /** Typical access patterns */
  accessPatterns: AccessPattern[];
  /** Typical resource usage */
  resourceUsage: ResourceUsageBaseline;
  /** Typical network activity */
  networkActivity: NetworkBaseline;
  /** Typical file activity */
  fileActivity: FileBaseline;
  /** Baseline established date */
  establishedAt: number;
  /** Last updated */
  updatedAt: number;
  /** Confidence level */
  confidence: number;
}

/**
 * Access pattern
 */
export interface AccessPattern {
  /** Resource type */
  resourceType: 'database' | 'file_share' | 'application' | 'api' | 'system';
  /** Resource identifier */
  resourceId: string;
  /** Access frequency per day */
  frequencyPerDay: number;
  /** Typical times */
  typicalHours: number[];
  /** Access types */
  accessTypes: ('read' | 'write' | 'delete' | 'execute' | 'admin')[];
}

/**
 * Resource usage baseline
 */
export interface ResourceUsageBaseline {
  /** Average CPU usage */
  avgCpuUsage: number;
  /** Average memory usage */
  avgMemoryUsage: number;
  /** Average disk I/O */
  avgDiskIO: number;
  /** Average network throughput */
  avgNetworkThroughput: number;
  /** Typical processes */
  typicalProcesses: string[];
}

/**
 * Network baseline
 */
export interface NetworkBaseline {
  /** Typical destinations */
  typicalDestinations: string[];
  /** Average connections per hour */
  avgConnectionsPerHour: number;
  /** Typical ports */
  typicalPorts: number[];
  /** Data transfer limits */
  dataTransferLimits: {
    hourly: number;
    daily: number;
  };
}

/**
 * File baseline
 */
export interface FileBaseline {
  /** Average files accessed per day */
  avgFilesPerDay: number;
  /** Average file size accessed */
  avgFileSize: number;
  /** Typical file types */
  typicalFileTypes: string[];
  /** Sensitive file access rate */
  sensitiveFileAccessRate: number;
}

/**
 * Resource event
 */
export interface ResourceEvent {
  /** Event ID */
  id: string;
  /** Event type */
  type: 'clipboard_copy' | 'clipboard_paste' | 'file_read' | 'file_write' | 'file_delete' |
        'file_copy' | 'file_move' | 'network_connect' | 'network_send' | 'network_receive' |
        'usb_insert' | 'usb_copy' | 'print' | 'email_send' | 'email_attachment' |
        'cloud_upload' | 'cloud_download' | 'screenshot' | 'screen_record' | 'keylog';
  /** User ID */
  userId: string;
  /** Device ID */
  deviceId: string;
  /** Timestamp */
  timestamp: number;
  /** Resource details */
  resource: {
    type: string;
    name: string;
    path?: string;
    size?: number;
    hash?: string;
    sensitivity?: 'public' | 'internal' | 'confidential' | 'restricted' | 'top_secret';
  };
  /** Source */
  source: {
    type: string;
    address?: string;
    application?: string;
    process?: string;
  };
  /** Destination */
  destination?: {
    type: string;
    address?: string;
    application?: string;
    process?: string;
  };
  /** Content hash (for DLP) */
  contentHash?: string;
  /** Content categories */
  contentCategories?: string[];
  /** Event metadata */
  metadata: Record<string, unknown>;
  /** Risk score for this event */
  riskScore: number;
  /** Processing status */
  processed: boolean;
}

/**
 * Correlation result
 */
export interface CorrelationResult {
  /** Result ID */
  id: string;
  /** Correlation type */
  type: 'temporal' | 'behavioral' | 'cross_resource' | 'cross_user' | 'anomaly';
  /** Events involved */
  eventIds: string[];
  /** Users involved */
  userIds: string[];
  /** Correlation score */
  score: number;
  /** Description */
  description: string;
  /** Indicators identified */
  indicators: string[];
  /** Timestamp */
  timestamp: number;
  /** Status */
  status: 'new' | 'reviewed' | 'investigating' | 'resolved';
}

/**
 * Investigation
 */
export interface Investigation {
  /** Investigation ID */
  id: string;
  /** Title */
  title: string;
  /** Description */
  description: string;
  /** Severity */
  severity: 'low' | 'medium' | 'high' | 'critical';
  /** Status */
  status: 'open' | 'investigating' | 'escalated' | 'closed' | 'false_positive';
  /** Users involved */
  users: string[];
  /** Events involved */
  events: string[];
  /** Indicators */
  indicators: string[];
  /** Timeline */
  timeline: TimelineEntry[];
  /** Evidence */
  evidence: Evidence[];
  /** Findings */
  findings: Finding[];
  /** Assigned to */
  assignedTo?: string;
  /** Created timestamp */
  createdAt: number;
  /** Updated timestamp */
  updatedAt: number;
  /** Closed timestamp */
  closedAt?: number;
  /** Resolution */
  resolution?: string;
}

/**
 * Timeline entry
 */
export interface TimelineEntry {
  /** Entry ID */
  id: string;
  /** Timestamp */
  timestamp: number;
  /** Event type */
  eventType: string;
  /** Description */
  description: string;
  /** User */
  userId: string;
  /** Related event IDs */
  relatedEvents: string[];
  /** Significance */
  significance: 'low' | 'medium' | 'high';
}

/**
 * Evidence
 */
export interface Evidence {
  /** Evidence ID */
  id: string;
  /** Evidence type */
  type: 'log' | 'screenshot' | 'network_capture' | 'file' | 'memory_dump' | 'testimony';
  /** Description */
  description: string;
  /** Hash for integrity */
  hash: string;
  /** Collection timestamp */
  collectedAt: number;
  /** Collected by */
  collectedBy: string;
  /** Storage location */
  location: string;
  /** Chain of custody */
  custody: CustodyEntry[];
}

/**
 * Custody entry
 */
export interface CustodyEntry {
  /** Timestamp */
  timestamp: number;
  /** Action */
  action: 'collected' | 'transferred' | 'analyzed' | 'stored' | 'returned';
  /** Actor */
  actor: string;
  /** Notes */
  notes: string;
}

/**
 * Finding
 */
export interface Finding {
  /** Finding ID */
  id: string;
  /** Finding type */
  type: 'policy_violation' | 'data_exfiltration' | 'unauthorized_access' | 
        'privilege_abuse' | 'sabotage' | 'fraud' | 'espionage' | 'no_wrongdoing';
  /** Description */
  description: string;
  /** Supporting evidence */
  evidence: string[];
  /** Impact assessment */
  impact: {
    severity: 'minor' | 'moderate' | 'major' | 'severe';
    affectedSystems: string[];
    affectedData: string[];
    businessImpact: string;
  };
  /** Recommendations */
  recommendations: string[];
  /** Created timestamp */
  createdAt: number;
}

/**
 * Alert
 */
export interface InsiderAlert {
  /** Alert ID */
  id: string;
  /** Alert type */
  type: 'risk_threshold' | 'anomaly' | 'correlation' | 'policy_violation' | 'indicator';
  /** Severity */
  severity: 'info' | 'low' | 'medium' | 'high' | 'critical';
  /** User IDs involved */
  userIds: string[];
  /** Event IDs involved */
  eventIds: string[];
  /** Description */
  description: string;
  /** Indicators triggered */
  indicators: string[];
  /** Recommended actions */
  recommendedActions: string[];
  /** Status */
  status: 'new' | 'acknowledged' | 'investigating' | 'resolved' | 'false_positive';
  /** Created timestamp */
  createdAt: number;
  /** Acknowledged by */
  acknowledgedBy?: string;
  /** Acknowledged timestamp */
  acknowledgedAt?: number;
  /** Resolution */
  resolution?: string;
  /** Resolved timestamp */
  resolvedAt?: number;
}

/**
 * Detection rule
 */
export interface DetectionRule {
  /** Rule ID */
  id: string;
  /** Rule name */
  name: string;
  /** Rule description */
  description: string;
  /** Rule type */
  type: 'threshold' | 'pattern' | 'sequence' | 'anomaly' | 'correlation';
  /** Conditions */
  conditions: RuleCondition[];
  /** Actions on match */
  actions: RuleAction[];
  /** Severity on match */
  severity: 'low' | 'medium' | 'high' | 'critical';
  /** Is enabled */
  enabled: boolean;
  /** Created timestamp */
  createdAt: number;
  /** Last triggered */
  lastTriggered?: number;
  /** Trigger count */
  triggerCount: number;
}

/**
 * Rule condition
 */
export interface RuleCondition {
  /** Field to check */
  field: string;
  /** Operator */
  operator: 'eq' | 'neq' | 'gt' | 'lt' | 'gte' | 'lte' | 'contains' | 'matches' | 'in';
  /** Value */
  value: number | string | string[];
  /** Time window in seconds */
  timeWindow?: number;
  /** Aggregation */
  aggregation?: 'count' | 'sum' | 'avg' | 'max' | 'min' | 'distinct';
}

/**
 * Rule action
 */
export interface RuleAction {
  /** Action type */
  type: 'alert' | 'block' | 'log' | 'notify' | 'investigate' | 'quarantine';
  /** Action parameters */
  parameters: Record<string, unknown>;
}

/**
 * System configuration
 */
export interface SystemConfiguration {
  /** Monitoring enabled */
  monitoringEnabled: boolean;
  /** Event collection */
  eventCollection: {
    clipboard: boolean;
    fileSystem: boolean;
    network: boolean;
    usb: boolean;
    printing: boolean;
    email: boolean;
    cloud: boolean;
    screenshots: boolean;
  };
  /** Retention period in days */
  retentionPeriod: number;
  /** Alert thresholds */
  alertThresholds: {
    riskScore: number;
    eventCount: number;
    dataVolume: number;
  };
  /** Integration settings */
  integrations: {
    siem: boolean;
    email: boolean;
    ticketing: boolean;
  };
}

// ============================================================================
// STORAGE
// ============================================================================

const users = new Map<string, UserProfile>();
const events = new Map<string, ResourceEvent>();
const correlations = new Map<string, CorrelationResult>();
const investigations = new Map<string, Investigation>();
const alerts = new Map<string, InsiderAlert>();
const rules = new Map<string, DetectionRule>();

// Configuration
let config: SystemConfiguration = {
  monitoringEnabled: true,
  eventCollection: {
    clipboard: true,
    fileSystem: true,
    network: true,
    usb: true,
    printing: true,
    email: true,
    cloud: true,
    screenshots: true
  },
  retentionPeriod: 90,
  alertThresholds: {
    riskScore: 60,
    eventCount: 100,
    dataVolume: 1000000000 // 1GB
  },
  integrations: {
    siem: false,
    email: true,
    ticketing: false
  }
};

// Platform secret
const PLATFORM_SECRET = 'insider_threat_detection_secret_v1';

// ============================================================================
// USER MANAGEMENT
// ============================================================================

/**
 * Create user profile
 */
export function createUser(config: {
  username: string;
  email: string;
  department: string;
  role: string;
  accessLevel: UserProfile['accessLevel'];
}): UserProfile {
  const id = `user_${generateUUID()}`;
  const now = Date.now();

  const user: UserProfile = {
    id,
    username: config.username,
    email: config.email,
    department: config.department,
    role: config.role,
    accessLevel: config.accessLevel,
    status: 'active',
    riskProfile: {
      riskScore: 10, // Low default for new users
      riskLevel: 'minimal',
      factors: [],
      indicators: [],
      incidents: [],
      lastAssessment: now,
      trend: 'stable'
    },
    baseline: {
      workingHours: { start: 9, end: 17, variance: 2 },
      accessPatterns: [],
      resourceUsage: {
        avgCpuUsage: 20,
        avgMemoryUsage: 30,
        avgDiskIO: 10,
        avgNetworkThroughput: 1000000,
        typicalProcesses: []
      },
      networkActivity: {
        typicalDestinations: [],
        avgConnectionsPerHour: 50,
        typicalPorts: [80, 443],
        dataTransferLimits: { hourly: 100000000, daily: 1000000000 }
      },
      fileActivity: {
        avgFilesPerDay: 100,
        avgFileSize: 100000,
        typicalFileTypes: ['.doc', '.xls', '.pdf', '.txt'],
        sensitiveFileAccessRate: 0.05
      },
      establishedAt: now,
      updatedAt: now,
      confidence: 0.1 // Low confidence for new users
    },
    hireDate: now,
    lastActivity: now,
    createdAt: now
  };

  users.set(id, user);
  return user;
}

/**
 * Get user
 */
export function getUser(userId: string): UserProfile | undefined {
  return users.get(userId);
}

/**
 * Update user status
 */
export function updateUserStatus(
  userId: string,
  status: UserProfile['status']
): UserProfile | null {
  const user = users.get(userId);
  if (!user) return null;

  user.status = status;
  user.lastActivity = Date.now();
  users.set(userId, user);
  return user;
}

/**
 * List users by risk level
 */
export function listUsersByRisk(
  riskLevel?: UserProfile['riskProfile']['riskLevel']
): UserProfile[] {
  const all = Array.from(users.values());
  return riskLevel 
    ? all.filter(u => u.riskProfile.riskLevel === riskLevel)
    : all;
}

// ============================================================================
// EVENT COLLECTION
// ============================================================================

/**
 * Record resource event
 */
export function recordEvent(event: Omit<ResourceEvent, 'id' | 'processed' | 'riskScore'>): {
  event: ResourceEvent;
  riskScore: number;
  alertsGenerated: InsiderAlert[];
} {
  const id = `event_${generateUUID()}`;
  
  // Calculate risk score
  const riskScore = calculateEventRiskScore(event);

  const fullEvent: ResourceEvent = {
    id,
    ...event,
    riskScore,
    processed: false
  };

  events.set(id, fullEvent);

  // Process event
  const generatedAlerts = processEvent(fullEvent);

  // Update user last activity
  const user = users.get(event.userId);
  if (user) {
    user.lastActivity = event.timestamp;
    users.set(event.userId, user);
  }

  return {
    event: fullEvent,
    riskScore,
    alertsGenerated: generatedAlerts
  };
}

/**
 * Calculate event risk score
 */
function calculateEventRiskScore(event: Omit<ResourceEvent, 'id' | 'processed' | 'riskScore'>): number {
  let score = 0;
  const user = users.get(event.userId);

  // Factor 1: Event type risk
  const eventTypeRisks: Record<string, number> = {
    'clipboard_copy': 5,
    'clipboard_paste': 3,
    'file_read': 2,
    'file_write': 5,
    'file_delete': 15,
    'file_copy': 10,
    'file_move': 8,
    'network_connect': 3,
    'network_send': 8,
    'network_receive': 5,
    'usb_insert': 10,
    'usb_copy': 25,
    'print': 8,
    'email_send': 5,
    'email_attachment': 15,
    'cloud_upload': 20,
    'cloud_download': 10,
    'screenshot': 12,
    'screen_record': 25,
    'keylog': 50
  };
  score += eventTypeRisks[event.type] || 5;

  // Factor 2: Data sensitivity
  const sensitivityScores: Record<string, number> = {
    'public': 0,
    'internal': 5,
    'confidential': 15,
    'restricted': 25,
    'top_secret': 40
  };
  if (event.resource.sensitivity) {
    score += sensitivityScores[event.resource.sensitivity] || 0;
  }

  // Factor 3: Time anomaly
  if (user) {
    const hour = new Date(event.timestamp).getHours();
    const { start, end, variance } = user.baseline.workingHours;
    if (hour < start - variance || hour > end + variance) {
      score += 10;
    }
  }

  // Factor 4: Content categories
  if (event.contentCategories) {
    const riskyCategories = ['pii', 'financial', 'health', 'intellectual_property', 'credentials'];
    for (const cat of event.contentCategories) {
      if (riskyCategories.includes(cat)) {
        score += 10;
      }
    }
  }

  // Factor 5: Destination risk
  if (event.destination) {
    const dest = event.destination.address || '';
    if (dest.includes('personal') || dest.includes('dropbox') || dest.includes('drive')) {
      score += 15;
    }
  }

  return Math.min(score, 100);
}

/**
 * Process event for correlations and alerts
 */
function processEvent(event: ResourceEvent): InsiderAlert[] {
  const generatedAlerts: InsiderAlert[] = [];

  // Update user risk
  updateUserRisk(event.userId, event);

  // Check rules
  const matchingRules = checkRules(event);
  for (const rule of matchingRules) {
    const alert = createAlertFromRule(rule, event);
    if (alert) {
      generatedAlerts.push(alert);
    }
  }

  // Correlate with recent events
  const correlation = correlateEvent(event);
  if (correlation && correlation.score > 50) {
    const alert: InsiderAlert = {
      id: `alert_${generateUUID()}`,
      type: 'correlation',
      severity: correlation.score > 80 ? 'critical' : correlation.score > 60 ? 'high' : 'medium',
      userIds: correlation.userIds,
      eventIds: correlation.eventIds,
      description: correlation.description,
      indicators: correlation.indicators,
      recommendedActions: ['Review correlated events', 'Investigate user activity'],
      status: 'new',
      createdAt: Date.now()
    };
    alerts.set(alert.id, alert);
    generatedAlerts.push(alert);
  }

  // Mark as processed
  event.processed = true;
  events.set(event.id, event);

  return generatedAlerts;
}

/**
 * Update user risk based on event
 */
function updateUserRisk(userId: string, event: ResourceEvent): void {
  const user = users.get(userId);
  if (!user) return;

  // Add event score to risk (with decay)
  const decayFactor = 0.95;
  user.riskProfile.riskScore = 
    user.riskProfile.riskScore * decayFactor + event.riskScore * (1 - decayFactor);

  // Update risk level
  if (user.riskProfile.riskScore >= 80) {
    user.riskProfile.riskLevel = 'critical';
  } else if (user.riskProfile.riskScore >= 60) {
    user.riskProfile.riskLevel = 'high';
  } else if (user.riskProfile.riskScore >= 40) {
    user.riskProfile.riskLevel = 'moderate';
  } else if (user.riskProfile.riskScore >= 20) {
    user.riskProfile.riskLevel = 'low';
  } else {
    user.riskProfile.riskLevel = 'minimal';
  }

  // Update trend
  const oldScore = user.riskProfile.riskScore;
  if (event.riskScore > oldScore) {
    user.riskProfile.trend = 'increasing';
  }

  user.riskProfile.lastAssessment = Date.now();
  users.set(userId, user);
}

// ============================================================================
// CORRELATION ENGINE
// ============================================================================

/**
 * Correlate event with recent events
 */
function correlateEvent(event: ResourceEvent): CorrelationResult | null {
  // Get recent events for this user (last 24 hours)
  const cutoff = event.timestamp - 86400000; // 24 hours
  const recentEvents = Array.from(events.values())
    .filter(e => e.userId === event.userId && e.timestamp >= cutoff && e.id !== event.id);

  if (recentEvents.length < 3) return null;

  const eventIds = [event.id, ...recentEvents.map(e => e.id)];
  const indicators: string[] = [];
  let score = 0;
  let description = '';

  // Pattern 1: Data staging (multiple file copies followed by external transfer)
  const fileCopies = recentEvents.filter(e => 
    e.type === 'file_copy' || e.type === 'file_move'
  );
  const externalTransfers = recentEvents.filter(e =>
    e.type === 'cloud_upload' || e.type === 'email_attachment' || e.type === 'usb_copy'
  );
  
  if (fileCopies.length >= 3 && externalTransfers.length > 0 && 
      event.type === 'cloud_upload') {
    score += 40;
    indicators.push('data_staging');
    description = 'Potential data staging: Multiple file copies followed by external transfer';
  }

  // Pattern 2: Credential harvesting (clipboard copies of sensitive data)
  const clipboardCopies = recentEvents.filter(e => e.type === 'clipboard_copy');
  const sensitiveClipboard = clipboardCopies.filter(e => 
    e.contentCategories?.includes('credentials') || 
    e.contentCategories?.includes('pii')
  );
  
  if (sensitiveClipboard.length >= 3) {
    score += 35;
    indicators.push('credential_harvesting');
    description += ' Potential credential harvesting: Multiple clipboard copies of sensitive data';
  }

  // Pattern 3: Off-hours activity spike
  const user = users.get(event.userId);
  if (user) {
    const offHoursEvents = recentEvents.filter(e => {
      const hour = new Date(e.timestamp).getHours();
      return hour < user.baseline.workingHours.start - user.baseline.workingHours.variance ||
             hour > user.baseline.workingHours.end + user.baseline.workingHours.variance;
    });
    
    if (offHoursEvents.length >= 5) {
      score += 25;
      indicators.push('off_hours_activity');
      description += ' Unusual off-hours activity detected';
    }
  }

  // Pattern 4: Volume anomaly
  const totalDataVolume = recentEvents.reduce((sum, e) => 
    sum + (e.resource.size || 0), 0
  );
  if (user && totalDataVolume > user.baseline.networkActivity.dataTransferLimits.daily) {
    score += 30;
    indicators.push('data_volume_anomaly');
    description += ' Data transfer volume exceeds baseline';
  }

  if (score === 0) return null;

  const correlation: CorrelationResult = {
    id: `corr_${generateUUID()}`,
    type: 'behavioral',
    eventIds,
    userIds: [event.userId],
    score: Math.min(score, 100),
    description: description.trim(),
    indicators,
    timestamp: Date.now(),
    status: 'new'
  };

  correlations.set(correlation.id, correlation);
  return correlation;
}

// ============================================================================
// DETECTION RULES
// ============================================================================

/**
 * Create detection rule
 */
export function createRule(config: {
  name: string;
  description: string;
  type: DetectionRule['type'];
  conditions: RuleCondition[];
  actions: RuleAction[];
  severity: DetectionRule['severity'];
}): DetectionRule {
  const rule: DetectionRule = {
    id: `rule_${generateUUID()}`,
    name: config.name,
    description: config.description,
    type: config.type,
    conditions: config.conditions,
    actions: config.actions,
    severity: config.severity,
    enabled: true,
    createdAt: Date.now(),
    triggerCount: 0
  };

  rules.set(rule.id, rule);
  return rule;
}

/**
 * Check rules against event
 */
function checkRules(event: ResourceEvent): DetectionRule[] {
  const matchingRules: DetectionRule[] = [];

  for (const rule of rules.values()) {
    if (!rule.enabled) continue;

    let matches = true;
    for (const condition of rule.conditions) {
      const value = getEventFieldValue(event, condition.field);
      if (!evaluateCondition(condition, value)) {
        matches = false;
        break;
      }
    }

    if (matches) {
      rule.lastTriggered = Date.now();
      rule.triggerCount++;
      rules.set(rule.id, rule);
      matchingRules.push(rule);
    }
  }

  return matchingRules;
}

/**
 * Get event field value
 */
function getEventFieldValue(event: ResourceEvent, field: string): number | string | string[] {
  const parts = field.split('.');
  let value: unknown = event;

  for (const part of parts) {
    if (value && typeof value === 'object') {
      value = (value as Record<string, unknown>)[part];
    }
  }

  return value as number | string | string[];
}

/**
 * Evaluate condition
 */
function evaluateCondition(condition: RuleCondition, value: number | string | string[]): boolean {
  switch (condition.operator) {
    case 'eq':
      return value === condition.value;
    case 'neq':
      return value !== condition.value;
    case 'gt':
      return typeof value === 'number' && value > (condition.value as number);
    case 'lt':
      return typeof value === 'number' && value < (condition.value as number);
    case 'gte':
      return typeof value === 'number' && value >= (condition.value as number);
    case 'lte':
      return typeof value === 'number' && value <= (condition.value as number);
    case 'contains':
      return typeof value === 'string' && value.includes(condition.value as string);
    case 'matches':
      return typeof value === 'string' && new RegExp(condition.value as string).test(value);
    case 'in':
      return Array.isArray(condition.value) && condition.value.includes(value);
    default:
      return false;
  }
}

/**
 * Create alert from rule
 */
function createAlertFromRule(rule: DetectionRule, event: ResourceEvent): InsiderAlert | null {
  const alert: InsiderAlert = {
    id: `alert_${generateUUID()}`,
    type: 'policy_violation',
    severity: rule.severity === 'critical' ? 'critical' : 
              rule.severity === 'high' ? 'high' : 
              rule.severity === 'medium' ? 'medium' : 'low',
    userIds: [event.userId],
    eventIds: [event.id],
    description: `Rule "${rule.name}" triggered: ${rule.description}`,
    indicators: [],
    recommendedActions: rule.actions.map(a => a.type),
    status: 'new',
    createdAt: Date.now()
  };

  alerts.set(alert.id, alert);
  return alert;
}

// ============================================================================
// INVESTIGATION MANAGEMENT
// ============================================================================

/**
 * Create investigation
 */
export function createInvestigation(config: {
  title: string;
  description: string;
  severity: Investigation['severity'];
  userIds: string[];
  eventIds: string[];
}): Investigation {
  const investigation: Investigation = {
    id: `inv_${generateUUID()}`,
    title: config.title,
    description: config.description,
    severity: config.severity,
    status: 'open',
    users: config.userIds,
    events: config.eventIds,
    indicators: [],
    timeline: [],
    evidence: [],
    findings: [],
    createdAt: Date.now(),
    updatedAt: Date.now()
  };

  // Build timeline from events
  for (const eventId of config.eventIds) {
    const event = events.get(eventId);
    if (event) {
      investigation.timeline.push({
        id: `tl_${generateUUID()}`,
        timestamp: event.timestamp,
        eventType: event.type,
        description: `${event.type} on ${event.resource.name}`,
        userId: event.userId,
        relatedEvents: [eventId],
        significance: event.riskScore > 50 ? 'high' : event.riskScore > 25 ? 'medium' : 'low'
      });
    }
  }

  // Sort timeline
  investigation.timeline.sort((a, b) => a.timestamp - b.timestamp);

  investigations.set(investigation.id, investigation);
  return investigation;
}

/**
 * Get investigation
 */
export function getInvestigation(investigationId: string): Investigation | undefined {
  return investigations.get(investigationId);
}

/**
 * Add evidence to investigation
 */
export function addEvidence(investigationId: string, evidence: Omit<Evidence, 'id' | 'hash' | 'custody'>): Evidence | null {
  const investigation = investigations.get(investigationId);
  if (!investigation) return null;

  const fullEvidence: Evidence = {
    id: `evidence_${generateUUID()}`,
    ...evidence,
    hash: sha256Hash(JSON.stringify(evidence)),
    custody: [{
      timestamp: Date.now(),
      action: 'collected',
      actor: evidence.collectedBy,
      notes: 'Initial collection'
    }]
  };

  investigation.evidence.push(fullEvidence);
  investigation.updatedAt = Date.now();
  investigations.set(investigationId, investigation);

  return fullEvidence;
}

/**
 * Add finding to investigation
 */
export function addFinding(investigationId: string, finding: Omit<Finding, 'id' | 'createdAt'>): Finding | null {
  const investigation = investigations.get(investigationId);
  if (!investigation) return null;

  const fullFinding: Finding = {
    id: `finding_${generateUUID()}`,
    ...finding,
    createdAt: Date.now()
  };

  investigation.findings.push(fullFinding);
  investigation.updatedAt = Date.now();
  investigations.set(investigationId, investigation);

  return fullFinding;
}

/**
 * Close investigation
 */
export function closeInvestigation(investigationId: string, resolution: string): Investigation | null {
  const investigation = investigations.get(investigationId);
  if (!investigation) return null;

  investigation.status = 'closed';
  investigation.resolution = resolution;
  investigation.closedAt = Date.now();
  investigation.updatedAt = Date.now();
  investigations.set(investigationId, investigation);

  // Update user risk if wrongdoing found
  if (investigation.findings.some(f => f.type !== 'no_wrongdoing')) {
    for (const userId of investigation.users) {
      const user = users.get(userId);
      if (user) {
        user.riskProfile.incidents.push(investigationId);
        user.riskProfile.riskScore = Math.min(100, user.riskProfile.riskScore + 20);
        users.set(userId, user);
      }
    }
  }

  return investigation;
}

// ============================================================================
// ALERT MANAGEMENT
// ============================================================================

/**
 * Get alert
 */
export function getAlert(alertId: string): InsiderAlert | undefined {
  return alerts.get(alertId);
}

/**
 * List alerts
 */
export function listAlerts(status?: InsiderAlert['status']): InsiderAlert[] {
  const all = Array.from(alerts.values());
  return status ? all.filter(a => a.status === status) : all;
}

/**
 * Acknowledge alert
 */
export function acknowledgeAlert(alertId: string, acknowledgedBy: string): InsiderAlert | null {
  const alert = alerts.get(alertId);
  if (!alert) return null;

  alert.status = 'acknowledged';
  alert.acknowledgedBy = acknowledgedBy;
  alert.acknowledgedAt = Date.now();
  alerts.set(alertId, alert);

  return alert;
}

/**
 * Resolve alert
 */
export function resolveAlert(alertId: string, resolution: string): InsiderAlert | null {
  const alert = alerts.get(alertId);
  if (!alert) return null;

  alert.status = 'resolved';
  alert.resolution = resolution;
  alert.resolvedAt = Date.now();
  alerts.set(alertId, alert);

  return alert;
}

// ============================================================================
// STATISTICS
// ============================================================================

/**
 * Get system statistics
 */
export function getSystemStats(): {
  users: { total: number; byRiskLevel: Record<string, number> };
  events: { total: number; last24h: number; byType: Record<string, number> };
  alerts: { total: number; open: number; bySeverity: Record<string, number> };
  investigations: { total: number; open: number; bySeverity: Record<string, number> };
  correlations: { total: number; highRisk: number };
} {
  const allUsers = Array.from(users.values());
  const allEvents = Array.from(events.values());
  const allAlerts = Array.from(alerts.values());
  const allInvestigations = Array.from(investigations.values());
  const allCorrelations = Array.from(correlations.values());

  const cutoff24h = Date.now() - 86400000;

  return {
    users: {
      total: allUsers.length,
      byRiskLevel: {
        minimal: allUsers.filter(u => u.riskProfile.riskLevel === 'minimal').length,
        low: allUsers.filter(u => u.riskProfile.riskLevel === 'low').length,
        moderate: allUsers.filter(u => u.riskProfile.riskLevel === 'moderate').length,
        high: allUsers.filter(u => u.riskProfile.riskLevel === 'high').length,
        critical: allUsers.filter(u => u.riskProfile.riskLevel === 'critical').length
      }
    },
    events: {
      total: allEvents.length,
      last24h: allEvents.filter(e => e.timestamp >= cutoff24h).length,
      byType: allEvents.reduce((acc, e) => {
        acc[e.type] = (acc[e.type] || 0) + 1;
        return acc;
      }, {} as Record<string, number>)
    },
    alerts: {
      total: allAlerts.length,
      open: allAlerts.filter(a => a.status === 'new' || a.status === 'acknowledged').length,
      bySeverity: {
        info: allAlerts.filter(a => a.severity === 'info').length,
        low: allAlerts.filter(a => a.severity === 'low').length,
        medium: allAlerts.filter(a => a.severity === 'medium').length,
        high: allAlerts.filter(a => a.severity === 'high').length,
        critical: allAlerts.filter(a => a.severity === 'critical').length
      }
    },
    investigations: {
      total: allInvestigations.length,
      open: allInvestigations.filter(i => i.status === 'open' || i.status === 'investigating').length,
      bySeverity: {
        low: allInvestigations.filter(i => i.severity === 'low').length,
        medium: allInvestigations.filter(i => i.severity === 'medium').length,
        high: allInvestigations.filter(i => i.severity === 'high').length,
        critical: allInvestigations.filter(i => i.severity === 'critical').length
      }
    },
    correlations: {
      total: allCorrelations.length,
      highRisk: allCorrelations.filter(c => c.score > 60).length
    }
  };
}

// ============================================================================
// CONFIGURATION
// ============================================================================

/**
 * Update system configuration
 */
export function updateConfiguration(newConfig: Partial<SystemConfiguration>): SystemConfiguration {
  config = { ...config, ...newConfig };
  return config;
}

/**
 * Get configuration
 */
export function getConfiguration(): SystemConfiguration {
  return { ...config };
}

// ============================================================================
// TEST SUITE
// ============================================================================

/**
 * Run insider threat detection tests
 */
export function runInsiderThreatDetectionTests(): {
  passed: boolean;
  tests: { total: number; passed: number; failed: number };
  results: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const results: Array<{ name: string; passed: boolean; error?: string }> = [];

  try {
    // Test 1: Create user
    const user = createUser({
      username: 'test_user',
      email: 'test@example.com',
      department: 'Engineering',
      role: 'Developer',
      accessLevel: 'elevated'
    });
    results.push({ name: 'Create User', passed: !!user.id && user.riskProfile.riskLevel === 'minimal' });

    // Test 2: Record clipboard event
    const clipboardEvent = recordEvent({
      type: 'clipboard_copy',
      userId: user.id,
      deviceId: 'device1',
      timestamp: Date.now(),
      resource: {
        type: 'clipboard',
        name: 'Sensitive Document',
        sensitivity: 'confidential',
        size: 1000
      },
      source: {
        type: 'application',
        application: 'Word'
      },
      contentCategories: ['confidential'],
      metadata: {}
    });
    results.push({ name: 'Record Clipboard Event', passed: clipboardEvent.event.riskScore > 0 });

    // Test 3: Record file event
    const fileEvent = recordEvent({
      type: 'file_copy',
      userId: user.id,
      deviceId: 'device1',
      timestamp: Date.now(),
      resource: {
        type: 'file',
        name: 'confidential_report.pdf',
        path: '/documents/confidential/',
        sensitivity: 'restricted',
        size: 5000000
      },
      source: {
        type: 'file_system',
        application: 'Explorer'
      },
      destination: {
        type: 'usb',
        address: '/media/usb/'
      },
      metadata: {}
    });
    results.push({ name: 'Record File Event', passed: fileEvent.event.riskScore > clipboardEvent.event.riskScore });

    // Test 4: User risk update
    const updatedUser = getUser(user.id);
    results.push({ 
      name: 'User Risk Update', 
      passed: updatedUser!.riskProfile.riskScore > user.riskProfile.riskScore 
    });

    // Test 5: Create detection rule
    const rule = createRule({
      name: 'USB Copy Detection',
      description: 'Detects file copies to USB devices',
      type: 'pattern',
      conditions: [
        { field: 'type', operator: 'eq', value: 'usb_copy' }
      ],
      actions: [
        { type: 'alert', parameters: { severity: 'high' } }
      ],
      severity: 'high'
    });
    results.push({ name: 'Create Detection Rule', passed: !!rule.id });

    // Test 6: Create investigation
    const investigation = createInvestigation({
      title: 'Suspicious USB Activity',
      description: 'User copied files to USB device',
      severity: 'high',
      userIds: [user.id],
      eventIds: [fileEvent.event.id]
    });
    results.push({ name: 'Create Investigation', passed: !!investigation.id && investigation.timeline.length > 0 });

    // Test 7: Add evidence
    const evidence = addEvidence(investigation.id, {
      type: 'log',
      description: 'USB access log',
      collectedAt: Date.now(),
      collectedBy: 'admin',
      location: '/evidence/usb_log.txt'
    });
    results.push({ name: 'Add Evidence', passed: !!evidence && evidence.custody.length > 0 });

    // Test 8: Add finding
    const finding = addFinding(investigation.id, {
      type: 'policy_violation',
      description: 'User violated data handling policy',
      evidence: [evidence!.id],
      impact: {
        severity: 'major',
        affectedSystems: ['File Server'],
        affectedData: ['Confidential Reports'],
        businessImpact: 'Potential data exposure'
      },
      recommendations: ['Revoke USB access', 'Retrain on data handling']
    });
    results.push({ name: 'Add Finding', passed: !!finding });

    // Test 9: Close investigation
    const closed = closeInvestigation(investigation.id, 'Policy violation confirmed');
    results.push({ name: 'Close Investigation', passed: closed!.status === 'closed' });

    // Test 10: System statistics
    const stats = getSystemStats();
    results.push({ 
      name: 'System Statistics', 
      passed: stats.users.total === 1 && stats.events.total >= 2 
    });

    // Test 11: List users by risk
    const highRiskUsers = listUsersByRisk('high');
    results.push({ name: 'List Users by Risk', passed: Array.isArray(highRiskUsers) });

    // Test 12: Alert management
    const allAlerts = listAlerts('new');
    results.push({ name: 'Alert Management', passed: allAlerts.length >= 0 });

  } catch (error) {
    results.push({ name: 'Test Execution', passed: false, error: String(error) });
  }

  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;

  return {
    passed: failed === 0,
    tests: { total: results.length, passed, failed },
    results
  };
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

export default {
  createUser,
  getUser,
  updateUserStatus,
  listUsersByRisk,
  recordEvent,
  createRule,
  createInvestigation,
  getInvestigation,
  addEvidence,
  addFinding,
  closeInvestigation,
  getAlert,
  listAlerts,
  acknowledgeAlert,
  resolveAlert,
  getSystemStats,
  updateConfiguration,
  getConfiguration,
  runInsiderThreatDetectionTests
};
