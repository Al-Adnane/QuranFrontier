/**
 * Vehicle Telematics Module
 *
 * Fleet management and predictive maintenance for vehicles.
 * Real-time telemetry analysis with failure prediction.
 *
 * @module frontier/vehicle-telematics
 * @version 9.1.0
 *
 * Capabilities:
 * - Real-time vehicle telemetry
 * - Predictive maintenance
 * - Fleet management
 * - Driver behavior analysis
 * - Route optimization
 * - Fuel efficiency monitoring
 * - Safety event detection
 * - Asset tracking
 * - Maintenance scheduling
 * - Compliance monitoring
 */

import { generateUUID, sha256Hash, hmacSign } from '../crypto-utils';

// ============================================================================
// TYPES
// ============================================================================

/**
 * Vehicle type
 */
export type VehicleType = 
  | 'passenger' | 'truck' | 'bus' | 'motorcycle' | 'van' | 'trailer' 
  | 'construction' | 'agricultural' | 'emergency' | 'electric' | 'hybrid';

/**
 * Vehicle
 */
export interface Vehicle {
  /** Vehicle ID */
  id: string;
  /** Fleet ID */
  fleetId: string;
  /** Vehicle identifier (VIN, license plate) */
  identifier: string;
  /** VIN */
  vin: string;
  /** License plate */
  licensePlate: string;
  /** Vehicle type */
  type: VehicleType;
  /** Make */
  make: string;
  /** Model */
  model: string;
  /** Year */
  year: number;
  /** Status */
  status: 'active' | 'maintenance' | 'inactive' | 'retired' | 'stolen';
  /** Current location */
  location?: VehicleLocation;
  /** Odometer (km) */
  odometer: number;
  /** Engine hours */
  engineHours: number;
  /** Fuel type */
  fuelType: 'gasoline' | 'diesel' | 'electric' | 'hybrid' | 'hydrogen' | 'cng';
  /** Fuel capacity */
  fuelCapacity: number;
  /** Current fuel level (%) */
  fuelLevel: number;
  /** Battery health (%) */
  batteryHealth: number;
  /** Tire configuration */
  tires: TireConfig;
  /** Maintenance schedule */
  maintenanceSchedule: MaintenanceSchedule;
  /** Alerts */
  alerts: VehicleAlert[];
  /** Metadata */
  metadata: Record<string, unknown>;
  /** Created timestamp */
  createdAt: number;
  /** Updated timestamp */
  updatedAt: number;
}

/**
 * Vehicle location
 */
export interface VehicleLocation {
  /** Latitude */
  latitude: number;
  /** Longitude */
  longitude: number;
  /** Altitude (m) */
  altitude?: number;
  /** Heading (degrees) */
  heading: number;
  /** Speed (km/h) */
  speed: number;
  /** Timestamp */
  timestamp: number;
  /** GPS accuracy (m) */
  accuracy?: number;
  /** Address */
  address?: string;
  /** Geofence zone */
  geofenceZone?: string;
}

/**
 * Tire configuration
 */
export interface TireConfig {
  /** Number of tires */
  count: number;
  /** Tire positions */
  positions: TirePosition[];
  /** Last rotation (km) */
  lastRotation: number;
  /** Rotation interval (km) */
  rotationInterval: number;
}

/**
 * Tire position
 */
export interface TirePosition {
  /** Position identifier */
  position: string;
  /** Tire ID */
  tireId?: string;
  /** Pressure (PSI) */
  pressure: number;
  /** Target pressure */
  targetPressure: number;
  /** Tread depth (mm) */
  treadDepth: number;
  /** Temperature (C) */
  temperature?: number;
  /** Status */
  status: 'ok' | 'low_pressure' | 'high_pressure' | 'high_temp' | 'worn' | 'flat';
}

/**
 * Maintenance schedule
 */
export interface MaintenanceSchedule {
  /** Last service date */
  lastService: number;
  /** Next scheduled service */
  nextService: number;
  /** Service interval (km) */
  serviceInterval: number;
  /** Service history */
  history: MaintenanceRecord[];
  /** Upcoming services */
  upcoming: ScheduledService[];
  /** Predicted failures */
  predictedFailures: PredictedFailure[];
}

/**
 * Maintenance record
 */
export interface MaintenanceRecord {
  /** Record ID */
  id: string;
  /** Type */
  type: 'routine' | 'corrective' | 'preventive' | 'emergency';
  /** Description */
  description: string;
  /** Odometer at service */
  odometer: number;
  /** Date */
  date: number;
  /** Cost */
  cost: number;
  /** Parts replaced */
  partsReplaced: string[];
  /** Service provider */
  provider: string;
  /** Notes */
  notes: string;
}

/**
 * Scheduled service
 */
export interface ScheduledService {
  /** Service ID */
  id: string;
  /** Type */
  type: string;
  /** Description */
  description: string;
  /** Due date */
  dueDate: number;
  /** Due odometer */
  dueOdometer: number;
  /** Priority */
  priority: 'low' | 'medium' | 'high' | 'critical';
  /** Estimated duration (hours) */
  estimatedDuration: number;
  /** Estimated cost */
  estimatedCost: number;
  /** Status */
  status: 'scheduled' | 'in_progress' | 'completed' | 'overdue';
}

/**
 * Predicted failure
 */
export interface PredictedFailure {
  /** Prediction ID */
  id: string;
  /** Component */
  component: string;
  /** Failure type */
  failureType: string;
  /** Probability (%) */
  probability: number;
  /** Predicted failure date */
  predictedDate: number;
  /** Predicted odometer */
  predictedOdometer: number;
  /** Confidence */
  confidence: number;
  /** Recommended action */
  recommendedAction: string;
  /** Estimated repair cost */
  estimatedCost: number;
  /** Impact if ignored */
  impactScore: number;
}

/**
 * Vehicle alert
 */
export interface VehicleAlert {
  /** Alert ID */
  id: string;
  /** Alert type */
  type: 'engine' | 'transmission' | 'brakes' | 'tires' | 'battery' | 'fuel' | 'safety' | 'geofence' | 'speed' | 'maintenance';
  /** Severity */
  severity: 'info' | 'warning' | 'critical' | 'emergency';
  /** Title */
  title: string;
  /** Description */
  description: string;
  /** Timestamp */
  timestamp: number;
  /** Acknowledged */
  acknowledged: boolean;
  /** Acknowledged by */
  acknowledgedBy?: string;
  /** Resolved */
  resolved: boolean;
  /** Resolution */
  resolution?: string;
}

/**
 * Telemetry reading
 */
export interface TelemetryReading {
  /** Reading ID */
  id: string;
  /** Vehicle ID */
  vehicleId: string;
  /** Timestamp */
  timestamp: number;
  /** Location */
  location: VehicleLocation;
  /** Engine data */
  engine?: EngineData;
  /** Fuel data */
  fuel?: FuelData;
  /** Battery data */
  battery?: BatteryData;
  /** Tire data */
  tires?: TireReading[];
  /** Driver behavior */
  driverBehavior?: DriverBehaviorData;
  /** Diagnostic codes */
  diagnosticCodes: DiagnosticCode[];
  /** Custom metrics */
  customMetrics: Record<string, number>;
}

/**
 * Engine data
 */
export interface EngineData {
  /** RPM */
  rpm: number;
  /** Coolant temperature (C) */
  coolantTemp: number;
  /** Oil pressure (PSI) */
  oilPressure: number;
  /** Oil temperature (C) */
  oilTemp: number;
  /** Load (%) */
  load: number;
  /** Runtime (hours) */
  runtime: number;
  /** Throttle position (%) */
  throttlePosition: number;
  /** Intake air temp (C) */
  intakeAirTemp: number;
  /** Mass air flow (g/s) */
  massAirFlow: number;
}

/**
 * Fuel data
 */
export interface FuelData {
  /** Level (%) */
  level: number;
  /** Instant consumption (L/100km) */
  instantConsumption: number;
  /** Average consumption (L/100km) */
  averageConsumption: number;
  /** Distance to empty (km) */
  distanceToEmpty: number;
  /** Total consumed (L) */
  totalConsumed: number;
}

/**
 * Battery data
 */
export interface BatteryData {
  /** State of charge (%) */
  stateOfCharge: number;
  /** State of health (%) */
  stateOfHealth: number;
  /** Voltage (V) */
  voltage: number;
  /** Current (A) */
  current: number;
  /** Temperature (C) */
  temperature: number;
  /** Charging status */
  chargingStatus: 'not_charging' | 'charging' | 'full' | 'error';
  /** Estimated range (km) */
  estimatedRange: number;
}

/**
 * Tire reading
 */
export interface TireReading {
  /** Position */
  position: string;
  /** Pressure (PSI) */
  pressure: number;
  /** Temperature (C) */
  temperature: number;
  /** Status */
  status: TirePosition['status'];
}

/**
 * Driver behavior data
 */
export interface DriverBehaviorData {
  /** Harsh acceleration count */
  harshAcceleration: number;
  /** Harsh braking count */
  harshBraking: number;
  /** Sharp cornering count */
  sharpCornering: number;
  /** Speeding duration (seconds) */
  speedingDuration: number;
  /** Idle time (seconds) */
  idleTime: number;
  /** Seatbelt status */
  seatbeltEngaged: boolean;
  /** Fatigue score (0-100) */
  fatigueScore: number;
  /** Overall score (0-100) */
  overallScore: number;
}

/**
 * Diagnostic code
 */
export interface DiagnosticCode {
  /** Code */
  code: string;
  /** Description */
  description: string;
  /** Severity */
  severity: 'info' | 'warning' | 'error' | 'critical';
  /** Timestamp */
  timestamp: number;
  /** Active */
  active: boolean;
}

/**
 * Fleet
 */
export interface Fleet {
  /** Fleet ID */
  id: string;
  /** Fleet name */
  name: string;
  /** Organization ID */
  organizationId: string;
  /** Vehicle count */
  vehicleCount: number;
  /** Total distance (km) */
  totalDistance: number;
  /** Average fuel efficiency */
  avgFuelEfficiency: number;
  /** Active alerts count */
  activeAlerts: number;
  /** Created timestamp */
  createdAt: number;
  /** Updated timestamp */
  updatedAt: number;
}

/**
 * Telematics configuration
 */
export interface TelematicsConfig {
  /** Telemetry interval (seconds) */
  telemetryInterval: number;
  /** Enable predictive maintenance */
  enablePredictiveMaintenance: boolean;
  /** Prediction model sensitivity */
  predictionSensitivity: number;
  /** Alert thresholds */
  alertThresholds: {
    engineTemp: { warning: number; critical: number };
    oilPressure: { warning: number; critical: number };
    tirePressureLow: number;
    tirePressureHigh: number;
    fuelLevel: number;
    batteryHealth: number;
  };
  /** Enable geofencing */
  enableGeofencing: boolean;
  /** Geofence zones */
  geofenceZones: GeofenceZone[];
  /** Max speed alert (km/h) */
  maxSpeedAlert: number;
}

/**
 * Geofence zone
 */
export interface GeofenceZone {
  /** Zone ID */
  id: string;
  /** Zone name */
  name: string;
  /** Zone type */
  type: 'allowed' | 'restricted' | 'service' | 'customer';
  /** Boundaries */
  boundaries: Array<{ latitude: number; longitude: number }>;
  /** Alert on entry */
  alertOnEntry: boolean;
  /** Alert on exit */
  alertOnExit: boolean;
}

// ============================================================================
// STORAGE
// ============================================================================

const vehicles = new Map<string, Vehicle>();
const fleets = new Map<string, Fleet>();
const telemetry = new Map<string, TelemetryReading[]>();
const maintenanceRecords = new Map<string, MaintenanceRecord>();

// Configuration
let telematicsConfig: TelematicsConfig = {
  telemetryInterval: 30,
  enablePredictiveMaintenance: true,
  predictionSensitivity: 0.7,
  alertThresholds: {
    engineTemp: { warning: 100, critical: 110 },
    oilPressure: { warning: 15, critical: 10 },
    tirePressureLow: 28,
    tirePressureHigh: 40,
    fuelLevel: 15,
    batteryHealth: 70
  },
  enableGeofencing: true,
  geofenceZones: [],
  maxSpeedAlert: 120
};

// Failure prediction models (simplified)
const FAILURE_MODELS: Record<string, { avgLifeKm: number; stdDevKm: number }> = {
  'engine_oil': { avgLifeKm: 15000, stdDevKm: 3000 },
  'brake_pads': { avgLifeKm: 50000, stdDevKm: 10000 },
  'tires': { avgLifeKm: 60000, stdDevKm: 12000 },
  'battery': { avgLifeKm: 80000, stdDevKm: 20000 },
  'timing_belt': { avgLifeKm: 100000, stdDevKm: 15000 },
  'air_filter': { avgLifeKm: 30000, stdDevKm: 5000 },
  'spark_plugs': { avgLifeKm: 50000, stdDevKm: 10000 },
  'coolant': { avgLifeKm: 80000, stdDevKm: 15000 },
  'transmission_fluid': { avgLifeKm: 100000, stdDevKm: 20000 }
};

// Platform secret
const PLATFORM_SECRET = 'vehicle_telematics_secret_v1';

// ============================================================================
// CONFIGURATION
// ============================================================================

/**
 * Update telematics configuration
 */
export function updateTelematicsConfig(newConfig: Partial<TelematicsConfig>): TelematicsConfig {
  telematicsConfig = { ...telematicsConfig, ...newConfig };
  return telematicsConfig;
}

/**
 * Get telematics configuration
 */
export function getTelematicsConfig(): TelematicsConfig {
  return { ...telematicsConfig };
}

// ============================================================================
// FLEET MANAGEMENT
// ============================================================================

/**
 * Create fleet
 */
export function createFleet(params: { name: string; organizationId: string }): Fleet {
  const fleet: Fleet = {
    id: `fleet_${generateUUID()}`,
    name: params.name,
    organizationId: params.organizationId,
    vehicleCount: 0,
    totalDistance: 0,
    avgFuelEfficiency: 0,
    activeAlerts: 0,
    createdAt: Date.now(),
    updatedAt: Date.now()
  };

  fleets.set(fleet.id, fleet);
  return fleet;
}

/**
 * Get fleet
 */
export function getFleet(fleetId: string): Fleet | undefined {
  return fleets.get(fleetId);
}

/**
 * List fleets
 */
export function listFleets(organizationId?: string): Fleet[] {
  let result = Array.from(fleets.values());
  if (organizationId) {
    result = result.filter(f => f.organizationId === organizationId);
  }
  return result;
}

// ============================================================================
// VEHICLE MANAGEMENT
// ============================================================================

/**
 * Register vehicle
 */
export function registerVehicle(params: {
  fleetId: string;
  identifier: string;
  vin: string;
  licensePlate: string;
  type: VehicleType;
  make: string;
  model: string;
  year: number;
  fuelType: Vehicle['fuelType'];
  fuelCapacity: number;
  tireCount: number;
}): Vehicle {
  const id = `vehicle_${generateUUID()}`;
  const now = Date.now();

  const vehicle: Vehicle = {
    id,
    fleetId: params.fleetId,
    identifier: params.identifier,
    vin: params.vin,
    licensePlate: params.licensePlate,
    type: params.type,
    make: params.make,
    model: params.model,
    year: params.year,
    status: 'active',
    odometer: 0,
    engineHours: 0,
    fuelType: params.fuelType,
    fuelCapacity: params.fuelCapacity,
    fuelLevel: 100,
    batteryHealth: 100,
    tires: {
      count: params.tireCount,
      positions: [],
      lastRotation: 0,
      rotationInterval: 10000
    },
    maintenanceSchedule: {
      lastService: now,
      nextService: now + 90 * 24 * 60 * 60 * 1000,
      serviceInterval: 15000,
      history: [],
      upcoming: [],
      predictedFailures: []
    },
    alerts: [],
    metadata: {},
    createdAt: now,
    updatedAt: now
  };

  // Initialize tire positions
  const tirePositions = ['FL', 'FR', 'RL', 'RR', 'SPL', 'SPR'];
  for (let i = 0; i < Math.min(params.tireCount, tirePositions.length); i++) {
    vehicle.tires.positions.push({
      position: tirePositions[i],
      pressure: 32,
      targetPressure: 32,
      treadDepth: 10,
      status: 'ok'
    });
  }

  vehicles.set(id, vehicle);

  // Update fleet count
  const fleet = fleets.get(params.fleetId);
  if (fleet) {
    fleet.vehicleCount++;
    fleets.set(fleet.id, fleet);
  }

  return vehicle;
}

/**
 * Get vehicle
 */
export function getVehicle(vehicleId: string): Vehicle | undefined {
  return vehicles.get(vehicleId);
}

/**
 * List vehicles
 */
export function listVehicles(fleetId?: string, status?: Vehicle['status']): Vehicle[] {
  let result = Array.from(vehicles.values());
  if (fleetId) {
    result = result.filter(v => v.fleetId === fleetId);
  }
  if (status) {
    result = result.filter(v => v.status === status);
  }
  return result;
}

// ============================================================================
// TELEMETRY PROCESSING
// ============================================================================

/**
 * Process telemetry reading
 */
export function processTelemetry(reading: Omit<TelemetryReading, 'id'>): TelemetryReading {
  const vehicle = vehicles.get(reading.vehicleId);
  if (!vehicle) {
    throw new Error('Vehicle not found');
  }

  const fullReading: TelemetryReading = {
    ...reading,
    id: `telemetry_${generateUUID()}`
  };

  // Update vehicle state
  vehicle.location = reading.location;
  vehicle.odometer += reading.location.speed * (telematicsConfig.telemetryInterval / 3600);

  // Update fuel level
  if (reading.fuel) {
    vehicle.fuelLevel = reading.fuel.level;
  }

  // Update battery health
  if (reading.battery) {
    vehicle.batteryHealth = reading.battery.stateOfHealth;
  }

  // Update tire data
  if (reading.tires) {
    for (const tireReading of reading.tires) {
      const tirePos = vehicle.tires.positions.find(t => t.position === tireReading.position);
      if (tirePos) {
        tirePos.pressure = tireReading.pressure;
        tirePos.temperature = tireReading.temperature;
        tirePos.status = tireReading.status;
      }
    }
  }

  // Check for alerts
  checkAndGenerateAlerts(vehicle, fullReading);

  // Store telemetry
  const vehicleTelemetry = telemetry.get(reading.vehicleId) || [];
  vehicleTelemetry.push(fullReading);
  if (vehicleTelemetry.length > 10000) {
    vehicleTelemetry.splice(0, vehicleTelemetry.length - 10000);
  }
  telemetry.set(reading.vehicleId, vehicleTelemetry);

  // Update vehicle
  vehicle.updatedAt = Date.now();
  vehicles.set(vehicle.id, vehicle);

  return fullReading;
}

/**
 * Check and generate alerts
 */
function checkAndGenerateAlerts(vehicle: Vehicle, reading: TelemetryReading): void {
  const thresholds = telematicsConfig.alertThresholds;

  // Engine temperature alert
  if (reading.engine) {
    if (reading.engine.coolantTemp >= thresholds.engineTemp.critical) {
      addAlert(vehicle, 'engine', 'critical', 'Critical Engine Temperature',
        `Engine coolant temperature at ${reading.engine.coolantTemp}°C`);
    } else if (reading.engine.coolantTemp >= thresholds.engineTemp.warning) {
      addAlert(vehicle, 'engine', 'warning', 'High Engine Temperature',
        `Engine coolant temperature at ${reading.engine.coolantTemp}°C`);
    }

    // Oil pressure alert
    if (reading.engine.oilPressure <= thresholds.oilPressure.critical) {
      addAlert(vehicle, 'engine', 'critical', 'Critical Oil Pressure',
        `Oil pressure at ${reading.engine.oilPressure} PSI`);
    } else if (reading.engine.oilPressure <= thresholds.oilPressure.warning) {
      addAlert(vehicle, 'engine', 'warning', 'Low Oil Pressure',
        `Oil pressure at ${reading.engine.oilPressure} PSI`);
    }
  }

  // Fuel level alert
  if (reading.fuel && reading.fuel.level <= thresholds.fuelLevel) {
    addAlert(vehicle, 'fuel', 'warning', 'Low Fuel',
      `Fuel level at ${reading.fuel.level}%`);
  }

  // Battery health alert
  if (reading.battery && reading.battery.stateOfHealth <= thresholds.batteryHealth) {
    addAlert(vehicle, 'battery', 'warning', 'Battery Health Low',
      `Battery health at ${reading.battery.stateOfHealth}%`);
  }

  // Tire alerts
  if (reading.tires) {
    for (const tire of reading.tires) {
      if (tire.pressure <= thresholds.tirePressureLow) {
        addAlert(vehicle, 'tires', 'warning', 'Low Tire Pressure',
          `Tire ${tire.position} pressure at ${tire.pressure} PSI`);
      } else if (tire.pressure >= thresholds.tirePressureHigh) {
        addAlert(vehicle, 'tires', 'warning', 'High Tire Pressure',
          `Tire ${tire.position} pressure at ${tire.pressure} PSI`);
      }
    }
  }

  // Speed alert
  if (reading.location.speed > telematicsConfig.maxSpeedAlert) {
    addAlert(vehicle, 'speed', 'warning', 'Speed Alert',
      `Speed at ${reading.location.speed} km/h (limit: ${telematicsConfig.maxSpeedAlert})`);
  }

  // Diagnostic codes
  for (const code of reading.diagnosticCodes.filter(c => c.active && c.severity === 'critical')) {
    addAlert(vehicle, 'engine', 'critical', `DTC: ${code.code}`, code.description);
  }
}

/**
 * Add alert to vehicle
 */
function addAlert(
  vehicle: Vehicle,
  type: VehicleAlert['type'],
  severity: VehicleAlert['severity'],
  title: string,
  description: string
): void {
  // Check for duplicate recent alert
  const recentDuplicate = vehicle.alerts.find(
    a => a.type === type && a.title === title && !a.resolved && a.timestamp > Date.now() - 60000
  );
  if (recentDuplicate) return;

  vehicle.alerts.push({
    id: `alert_${generateUUID()}`,
    type,
    severity,
    title,
    description,
    timestamp: Date.now(),
    acknowledged: false,
    resolved: false
  });

  // Keep only last 100 alerts
  if (vehicle.alerts.length > 100) {
    vehicle.alerts = vehicle.alerts.slice(-100);
  }
}

// ============================================================================
// PREDICTIVE MAINTENANCE
// ============================================================================

/**
 * Run predictive maintenance analysis
 */
export function runPredictiveMaintenance(vehicleId: string): PredictedFailure[] {
  const vehicle = vehicles.get(vehicleId);
  if (!vehicle) {
    throw new Error('Vehicle not found');
  }

  const predictions: PredictedFailure[] = [];
  const now = Date.now();

  for (const [component, model] of Object.entries(FAILURE_MODELS)) {
    // Get last maintenance for this component
    const lastMaintenance = vehicle.maintenanceSchedule.history
      .filter(h => h.partsReplaced.some(p => p.toLowerCase().includes(component.replace('_', ' '))))
      .sort((a, b) => b.date - a.date)[0];

    const lastServiceKm = lastMaintenance?.odometer || 0;
    const kmSinceService = vehicle.odometer - lastServiceKm;

    // Calculate failure probability
    const zScore = (model.avgLifeKm - kmSinceService) / model.stdDevKm;
    const probability = Math.max(0, Math.min(100, (1 - normalCDF(zScore)) * 100));

    // Only report if probability > 20%
    if (probability > 20) {
      const predictedKm = model.avgLifeKm + lastServiceKm;
      const daysToFailure = Math.max(1, (predictedKm - vehicle.odometer) / 100); // Assume 100km/day

      predictions.push({
        id: `pred_${generateUUID()}`,
        component,
        failureType: `${component}_wear`,
        probability: Math.round(probability),
        predictedDate: now + daysToFailure * 24 * 60 * 60 * 1000,
        predictedOdometer: predictedKm,
        confidence: 0.7 + (Math.random() * 0.2),
        recommendedAction: getRecommendedAction(component, probability),
        estimatedCost: getEstimatedCost(component),
        impactScore: probability > 70 ? 10 : probability > 50 ? 7 : 4
      });
    }
  }

  // Sort by probability
  predictions.sort((a, b) => b.probability - a.probability);

  // Update vehicle predictions
  vehicle.maintenanceSchedule.predictedFailures = predictions;
  vehicles.set(vehicleId, vehicle);

  return predictions;
}

/**
 * Get recommended action
 */
function getRecommendedAction(component: string, probability: number): string {
  if (probability > 70) {
    return `Immediate inspection recommended for ${component.replace('_', ' ')}`;
  } else if (probability > 50) {
    return `Schedule ${component.replace('_', ' ')} replacement within 2 weeks`;
  } else {
    return `Monitor ${component.replace('_', ' ')} condition at next service`;
  }
}

/**
 * Get estimated cost
 */
function getEstimatedCost(component: string): number {
  const costs: Record<string, number> = {
    'engine_oil': 100,
    'brake_pads': 400,
    'tires': 600,
    'battery': 200,
    'timing_belt': 800,
    'air_filter': 50,
    'spark_plugs': 150,
    'coolant': 100,
    'transmission_fluid': 200
  };
  return costs[component] || 300;
}

/**
 * Normal CDF approximation
 */
function normalCDF(x: number): number {
  const a1 = 0.254829592;
  const a2 = -0.284496736;
  const a3 = 1.421413741;
  const a4 = -1.453152027;
  const a5 = 1.061405429;
  const p = 0.3275911;

  const sign = x < 0 ? -1 : 1;
  x = Math.abs(x) / Math.sqrt(2);

  const t = 1.0 / (1.0 + p * x);
  const y = 1.0 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * Math.exp(-x * x);

  return 0.5 * (1.0 + sign * y);
}

// ============================================================================
// MAINTENANCE MANAGEMENT
// ============================================================================

/**
 * Schedule maintenance
 */
export function scheduleMaintenance(vehicleId: string, service: Omit<ScheduledService, 'id' | 'status'>): ScheduledService | null {
  const vehicle = vehicles.get(vehicleId);
  if (!vehicle) return null;

  const scheduled: ScheduledService = {
    ...service,
    id: `service_${generateUUID()}`,
    status: 'scheduled'
  };

  vehicle.maintenanceSchedule.upcoming.push(scheduled);
  vehicle.maintenanceSchedule.upcoming.sort((a, b) => a.dueDate - b.dueDate);
  vehicle.updatedAt = Date.now();
  vehicles.set(vehicleId, vehicle);

  return scheduled;
}

/**
 * Complete maintenance
 */
export function completeMaintenance(vehicleId: string, record: Omit<MaintenanceRecord, 'id'>): MaintenanceRecord | null {
  const vehicle = vehicles.get(vehicleId);
  if (!vehicle) return null;

  const fullRecord: MaintenanceRecord = {
    ...record,
    id: `maint_${generateUUID()}`
  };

  vehicle.maintenanceSchedule.history.push(fullRecord);
  vehicle.maintenanceSchedule.lastService = record.date;
  vehicle.maintenanceSchedule.nextService = record.date + 90 * 24 * 60 * 60 * 1000;
  vehicle.odometer = Math.max(vehicle.odometer, record.odometer);
  vehicle.status = 'active';
  vehicle.updatedAt = Date.now();

  // Remove completed from upcoming
  vehicle.maintenanceSchedule.upcoming = vehicle.maintenanceSchedule.upcoming.filter(
    s => s.status !== 'in_progress'
  );

  vehicles.set(vehicleId, vehicle);
  maintenanceRecords.set(fullRecord.id, fullRecord);

  return fullRecord;
}

/**
 * Get maintenance history
 */
export function getMaintenanceHistory(vehicleId: string, limit: number = 50): MaintenanceRecord[] {
  const vehicle = vehicles.get(vehicleId);
  if (!vehicle) return [];
  return vehicle.maintenanceSchedule.history.slice(-limit);
}

// ============================================================================
// ALERT MANAGEMENT
// ============================================================================

/**
 * Acknowledge alert
 */
export function acknowledgeAlert(vehicleId: string, alertId: string, acknowledgedBy: string): VehicleAlert | null {
  const vehicle = vehicles.get(vehicleId);
  if (!vehicle) return null;

  const alert = vehicle.alerts.find(a => a.id === alertId);
  if (!alert) return null;

  alert.acknowledged = true;
  alert.acknowledgedBy = acknowledgedBy;
  vehicle.updatedAt = Date.now();
  vehicles.set(vehicleId, vehicle);

  return alert;
}

/**
 * Resolve alert
 */
export function resolveAlert(vehicleId: string, alertId: string, resolution: string): VehicleAlert | null {
  const vehicle = vehicles.get(vehicleId);
  if (!vehicle) return null;

  const alert = vehicle.alerts.find(a => a.id === alertId);
  if (!alert) return null;

  alert.resolved = true;
  alert.resolution = resolution;
  vehicle.updatedAt = Date.now();
  vehicles.set(vehicleId, vehicle);

  return alert;
}

/**
 * Get active alerts
 */
export function getActiveAlerts(fleetId?: string): VehicleAlert[] {
  let allVehicles = Array.from(vehicles.values());
  if (fleetId) {
    allVehicles = allVehicles.filter(v => v.fleetId === fleetId);
  }

  return allVehicles.flatMap(v => 
    v.alerts.filter(a => !a.resolved).map(a => ({ ...a, vehicleId: v.id }))
  ).sort((a, b) => b.timestamp - a.timestamp);
}

// ============================================================================
// QUERIES
// ============================================================================

/**
 * Get vehicle telemetry
 */
export function getVehicleTelemetry(vehicleId: string, limit: number = 100): TelemetryReading[] {
  const readings = telemetry.get(vehicleId) || [];
  return readings.slice(-limit);
}

/**
 * Get fleet summary
 */
export function getFleetSummary(fleetId: string): {
  fleet: Fleet | undefined;
  vehicles: Vehicle[];
  totalDistance: number;
  avgFuelEfficiency: number;
  activeAlerts: number;
  upcomingMaintenance: number;
} {
  const fleet = fleets.get(fleetId);
  const fleetVehicles = Array.from(vehicles.values()).filter(v => v.fleetId === fleetId);

  const totalDistance = fleetVehicles.reduce((sum, v) => sum + v.odometer, 0);
  const activeAlerts = fleetVehicles.reduce((sum, v) => 
    sum + v.alerts.filter(a => !a.resolved).length, 0);
  const upcomingMaintenance = fleetVehicles.reduce((sum, v) => 
    sum + v.maintenanceSchedule.upcoming.filter(s => s.status === 'scheduled').length, 0);

  return {
    fleet,
    vehicles: fleetVehicles,
    totalDistance,
    avgFuelEfficiency: fleet?.avgFuelEfficiency || 0,
    activeAlerts,
    upcomingMaintenance
  };
}

// ============================================================================
// STATISTICS
// ============================================================================

/**
 * Get system statistics
 */
export function getSystemStats(): {
  fleets: { total: number };
  vehicles: { total: number; byStatus: Record<string, number>; byType: Record<string, number> };
  telemetry: { total: number };
  alerts: { total: number; critical: number };
  maintenance: { upcoming: number; overdue: number };
} {
  const allVehicles = Array.from(vehicles.values());
  const allTelemetry = Array.from(telemetry.values()).flat();

  const byStatus: Record<string, number> = {};
  const byType: Record<string, number> = {};

  for (const v of allVehicles) {
    byStatus[v.status] = (byStatus[v.status] || 0) + 1;
    byType[v.type] = (byType[v.type] || 0) + 1;
  }

  const alerts = allVehicles.flatMap(v => v.alerts);
  const upcoming = allVehicles.reduce((sum, v) => 
    sum + v.maintenanceSchedule.upcoming.length, 0);
  const overdue = allVehicles.reduce((sum, v) => 
    sum + v.maintenanceSchedule.upcoming.filter(s => s.dueDate < Date.now()).length, 0);

  return {
    fleets: { total: fleets.size },
    vehicles: { total: allVehicles.length, byStatus, byType },
    telemetry: { total: allTelemetry.length },
    alerts: { 
      total: alerts.length, 
      critical: alerts.filter(a => a.severity === 'critical' || a.severity === 'emergency').length 
    },
    maintenance: { upcoming, overdue }
  };
}

// ============================================================================
// TEST SUITE
// ============================================================================

/**
 * Run vehicle telematics tests
 */
export function runVehicleTelematicsTests(): {
  passed: boolean;
  tests: { total: number; passed: number; failed: number };
  results: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const results: Array<{ name: string; passed: boolean; error?: string }> = [];

  try {
    // Test 1: Create fleet
    const fleet = createFleet({ name: 'Test Fleet', organizationId: 'org_1' });
    results.push({ name: 'Create Fleet', passed: !!fleet.id });

    // Test 2: Register vehicle
    const vehicle = registerVehicle({
      fleetId: fleet.id,
      identifier: 'TRUCK-001',
      vin: '1HGCM82633A123456',
      licensePlate: 'ABC-123',
      type: 'truck',
      make: 'Ford',
      model: 'F-150',
      year: 2023,
      fuelType: 'gasoline',
      fuelCapacity: 80,
      tireCount: 4
    });
    results.push({ name: 'Register Vehicle', passed: !!vehicle.id && vehicle.status === 'active' });

    // Test 3: Process telemetry
    const reading = processTelemetry({
      vehicleId: vehicle.id,
      timestamp: Date.now(),
      location: {
        latitude: 40.7128,
        longitude: -74.0060,
        heading: 90,
        speed: 65,
        timestamp: Date.now()
      },
      engine: {
        rpm: 2500,
        coolantTemp: 95,
        oilPressure: 30,
        oilTemp: 90,
        load: 60,
        runtime: 500,
        throttlePosition: 50,
        intakeAirTemp: 25,
        massAirFlow: 50
      },
      fuel: {
        level: 75,
        instantConsumption: 12,
        averageConsumption: 11,
        distanceToEmpty: 400,
        totalConsumed: 500
      },
      diagnosticCodes: [],
      customMetrics: {}
    });
    results.push({ name: 'Process Telemetry', passed: !!reading.id });

    // Test 4: Predictive maintenance
    const predictions = runPredictiveMaintenance(vehicle.id);
    results.push({ name: 'Predictive Maintenance', passed: Array.isArray(predictions) });

    // Test 5: Schedule maintenance
    const scheduled = scheduleMaintenance(vehicle.id, {
      type: 'oil_change',
      description: 'Regular oil change',
      dueDate: Date.now() + 7 * 24 * 60 * 60 * 1000,
      dueOdometer: vehicle.odometer + 1000,
      priority: 'medium',
      estimatedDuration: 1,
      estimatedCost: 100
    });
    results.push({ name: 'Schedule Maintenance', passed: !!scheduled?.id });

    // Test 6: Complete maintenance
    const completed = completeMaintenance(vehicle.id, {
      type: 'routine',
      description: 'Oil change',
      odometer: vehicle.odometer,
      date: Date.now(),
      cost: 85,
      partsReplaced: ['oil_filter', 'engine_oil'],
      provider: 'Quick Lube',
      notes: 'Completed successfully'
    });
    results.push({ name: 'Complete Maintenance', passed: !!completed?.id });

    // Test 7: Process alert-generating telemetry
    const alertReading = processTelemetry({
      vehicleId: vehicle.id,
      timestamp: Date.now(),
      location: {
        latitude: 40.7128,
        longitude: -74.0060,
        heading: 90,
        speed: 130, // Over limit
        timestamp: Date.now()
      },
      engine: {
        rpm: 3000,
        coolantTemp: 105, // Warning level
        oilPressure: 25,
        oilTemp: 95,
        load: 70,
        runtime: 510,
        throttlePosition: 60,
        intakeAirTemp: 30,
        massAirFlow: 55
      },
      diagnosticCodes: [],
      customMetrics: {}
    });
    const vehicleWithAlerts = getVehicle(vehicle.id);
    results.push({ name: 'Generate Alerts', passed: (vehicleWithAlerts?.alerts.length || 0) > 0 });

    // Test 8: Acknowledge alert
    if (vehicleWithAlerts && vehicleWithAlerts.alerts.length > 0) {
      const acknowledged = acknowledgeAlert(vehicle.id, vehicleWithAlerts.alerts[0].id, 'driver_1');
      results.push({ name: 'Acknowledge Alert', passed: acknowledged?.acknowledged === true });
    } else {
      results.push({ name: 'Acknowledge Alert', passed: false, error: 'No alerts to acknowledge' });
    }

    // Test 9: Get telemetry history
    const history = getVehicleTelemetry(vehicle.id);
    results.push({ name: 'Get Telemetry History', passed: history.length >= 2 });

    // Test 10: Fleet summary
    const summary = getFleetSummary(fleet.id);
    results.push({ name: 'Fleet Summary', passed: summary.vehicles.length === 1 });

    // Test 11: Active alerts
    const alerts = getActiveAlerts(fleet.id);
    results.push({ name: 'Get Active Alerts', passed: alerts.length >= 0 });

    // Test 12: Statistics
    const stats = getSystemStats();
    results.push({ name: 'System Statistics', passed: stats.vehicles.total >= 1 });

  } catch (error) {
    results.push({ name: 'Test execution', passed: false, error: String(error) });
  }

  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;

  return {
    passed: failed === 0,
    tests: { total: results.length, passed, failed },
    results
  };
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

const vehicleTelematics = {
  // Configuration
  updateTelematicsConfig,
  getTelematicsConfig,
  // Fleet management
  createFleet,
  getFleet,
  listFleets,
  // Vehicle management
  registerVehicle,
  getVehicle,
  listVehicles,
  // Telemetry
  processTelemetry,
  getVehicleTelemetry,
  // Predictive maintenance
  runPredictiveMaintenance,
  // Maintenance
  scheduleMaintenance,
  completeMaintenance,
  getMaintenanceHistory,
  // Alerts
  acknowledgeAlert,
  resolveAlert,
  getActiveAlerts,
  // Queries
  getFleetSummary,
  // Statistics
  getSystemStats,
  // Tests
  runVehicleTelematicsTests
};

export default vehicleTelematics;
