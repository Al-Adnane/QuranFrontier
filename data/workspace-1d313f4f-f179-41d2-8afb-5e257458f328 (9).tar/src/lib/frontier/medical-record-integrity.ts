/**
 * Medical Record Integrity Module
 *
 * Tamper-proof Electronic Health Records (EHR) with CAIL-based audit trails.
 * Implements cryptographic integrity verification for healthcare compliance.
 *
 * @module frontier/medical-record-integrity
 * @version 8.0.0
 *
 * Capabilities:
 * - Hash-chained medical record storage (CAIL)
 * - HIPAA-compliant audit trails
 * - Patient consent management
 * - Access control verification
 * - Medical record versioning
 * - Integrity verification
 * - Breach detection
 * - Compliance reporting
 * - Provider attestation
 * - Patient data rights
 */

import { generateUUID, sha256Hash, hmacSign } from '../crypto-utils';

// ============================================================================
// TYPES
// ============================================================================

/**
 * Patient
 */
export interface Patient {
  /** Patient ID */
  id: string;
  /** Medical record number */
  mrn: string;
  /** Demographics (encrypted) */
  demographics: {
    firstName: string;
    lastName: string;
    dateOfBirth: string;
    gender: string;
    address: string;
    phone: string;
    email: string;
    emergencyContact: string;
  };
  /** Consent status */
  consent: PatientConsent;
  /** Access control list */
  accessControl: AccessControlEntry[];
  /** Record summary */
  recordSummary: {
    totalRecords: number;
    lastVisit: number;
    primaryProvider: string;
    conditions: string[];
    medications: string[];
    allergies: string[];
  };
  /** Status */
  status: 'active' | 'inactive' | 'deceased' | 'transferred';
  /** Creation timestamp */
  createdAt: number;
  /** Last updated */
  updatedAt: number;
  /** Record integrity hash */
  integrityHash: string;
}

/**
 * Patient consent
 */
export interface PatientConsent {
  /** Consent ID */
  id: string;
  /** Consent status */
  status: 'granted' | 'partial' | 'revoked' | 'expired';
  /** Consent types */
  types: ConsentType[];
  /** Granted to */
  grantedTo: string[];
  /** Restrictions */
  restrictions: ConsentRestriction[];
  /** Valid from */
  validFrom: number;
  /** Valid until */
  validUntil?: number;
  /** Consent timestamp */
  timestamp: number;
  /** Consent signature */
  signature: string;
  /** Last modified */
  modifiedAt: number;
}

/**
 * Consent type
 */
export interface ConsentType {
  /** Type */
  type: 'treatment' | 'payment' | 'operations' | 'research' | 'marketing' | 'disclosure';
  /** Granted */
  granted: boolean;
  /** Description */
  description: string;
}

/**
 * Consent restriction
 */
export interface ConsentRestriction {
  /** Restriction type */
  type: 'no_disclosure' | 'limited_disclosure' | 'specific_providers' | 'time_limited';
  /** Description */
  description: string;
  /** Affected data categories */
  categories: string[];
  /** Exceptions */
  exceptions: string[];
}

/**
 * Access control entry
 */
export interface AccessControlEntry {
  /** Entry ID */
  id: string;
  /** Principal type */
  principalType: 'provider' | 'department' | 'organization' | 'role';
  /** Principal ID */
  principalId: string;
  /** Principal name */
  principalName: string;
  /** Permissions */
  permissions: ('read' | 'write' | 'delete' | 'admin')[];
  /** Access scope */
  scope: 'full' | 'limited' | 'emergency';
  /** Granted by */
  grantedBy: string;
  /** Granted timestamp */
  grantedAt: number;
  /** Expires */
  expiresAt?: number;
  /** Status */
  status: 'active' | 'revoked' | 'expired';
}

/**
 * Medical record
 */
export interface MedicalRecord {
  /** Record ID */
  id: string;
  /** Patient ID */
  patientId: string;
  /** Record type */
  type: MedicalRecordType;
  /** Record status */
  status: 'active' | 'amended' | 'voided' | 'archived';
  /** Clinical data */
  clinicalData: ClinicalData;
  /** Provider info */
  provider: ProviderInfo;
  /** Visit/Encounter info */
  encounter: EncounterInfo;
  /** Record integrity */
  integrity: RecordIntegrity;
  /** Version info */
  version: {
    number: number;
    previousVersionId?: string;
    createdBy: string;
    createdAt: number;
    reason?: string;
  };
  /** Retention info */
  retention: {
    category: 'permanent' | 'long_term' | 'short_term';
    destroyAfter?: number;
    legalHold: boolean;
  };
}

/**
 * Medical record type
 */
export type MedicalRecordType = 
  | 'progress_note' | 'consultation' | 'discharge_summary' | 'operative_report'
  | 'radiology_report' | 'lab_result' | 'pathology_report' | 'medication_record'
  | 'immunization' | 'allergy' | 'problem_list' | 'vital_signs'
  | 'procedure_note' | 'referral' | 'prescription' | 'consent_form'
  | 'advance_directive' | 'clinical_summary';

/**
 * Clinical data
 */
export interface ClinicalData {
  /** Chief complaint */
  chiefComplaint?: string;
  /** History of present illness */
  hpi?: string;
  /** Review of systems */
  ros?: string[];
  /** Physical exam */
  physicalExam?: string;
  /** Assessment */
  assessment?: string;
  /** Plan */
  plan?: string;
  /** Diagnoses (ICD-10) */
  diagnoses?: Diagnosis[];
  /** Procedures (CPT) */
  procedures?: Procedure[];
  /** Medications */
  medications?: Medication[];
  /** Lab results */
  labResults?: LabResult[];
  /** Vital signs */
  vitalSigns?: VitalSigns;
  /** Attachments */
  attachments?: Attachment[];
  /** Structured data */
  structured?: Record<string, unknown>;
  /** Hash of clinical data */
  dataHash: string;
}

/**
 * Diagnosis
 */
export interface Diagnosis {
  code: string;
  description: string;
  type: 'principal' | 'secondary' | 'admitting';
  status: 'active' | 'resolved' | 'ruled_out';
}

/**
 * Procedure
 */
export interface Procedure {
  code: string;
  description: string;
  date: number;
  provider: string;
  status: 'planned' | 'in_progress' | 'completed' | 'cancelled';
}

/**
 * Medication
 */
export interface Medication {
  name: string;
  dose: string;
  frequency: string;
  route: string;
  startDate: number;
  endDate?: number;
  prescriber: string;
  status: 'active' | 'discontinued' | 'completed';
}

/**
 * Lab result
 */
export interface LabResult {
  test: string;
  value: string;
  unit: string;
  referenceRange: string;
  flag?: 'high' | 'low' | 'critical' | 'abnormal';
  timestamp: number;
}

/**
 * Vital signs
 */
export interface VitalSigns {
  timestamp: number;
  temperature?: number;
  heartRate?: number;
  bloodPressureSystolic?: number;
  bloodPressureDiastolic?: number;
  respiratoryRate?: number;
  oxygenSaturation?: number;
  weight?: number;
  height?: number;
  bmi?: number;
  painScore?: number;
}

/**
 * Attachment
 */
export interface Attachment {
  id: string;
  type: string;
  name: string;
  mimeType: string;
  size: number;
  hash: string;
  storageRef: string;
  uploadedAt: number;
  uploadedBy: string;
}

/**
 * Provider info
 */
export interface ProviderInfo {
  /** Provider ID */
  providerId: string;
  /** Provider name */
  name: string;
  /** NPI number */
  npi: string;
  /** Department */
  department: string;
  /** Organization */
  organization: string;
  /** Role */
  role: string;
  /** Signature */
  signature: string;
  /** Attestation timestamp */
  attestedAt: number;
}

/**
 * Encounter info
 */
export interface EncounterInfo {
  /** Encounter ID */
  encounterId: string;
  /** Encounter type */
  type: 'office_visit' | 'emergency' | 'inpatient' | 'outpatient' | 'telehealth' | 'home_health';
  /** Location */
  location: string;
  /** Department */
  department: string;
  /** Start time */
  startTime: number;
  /** End time */
  endTime?: number;
  /** Disposition */
  disposition?: string;
}

/**
 * Record integrity (CAIL)
 */
export interface RecordIntegrity {
  /** Current hash */
  hash: string;
  /** Previous hash (chain) */
  previousHash: string;
  /** Block index */
  blockIndex: number;
  /** Merkle root */
  merkleRoot: string;
  /** Signature */
  signature: string;
  /** Signed by */
  signedBy: string;
  /** Timestamp */
  timestamp: number;
  /** Verification status */
  verificationStatus: 'verified' | 'unverified' | 'tampered';
}

/**
 * Audit entry (CAIL)
 */
export interface AuditEntry {
  /** Entry ID */
  id: string;
  /** Patient ID */
  patientId: string;
  /** Record ID (if applicable) */
  recordId?: string;
  /** Action type */
  action: 'create' | 'read' | 'update' | 'delete' | 'print' | 'export' | 'share' | 'amend' | 'void';
  /** Actor */
  actor: {
    type: 'provider' | 'patient' | 'system' | 'admin';
    id: string;
    name: string;
    role: string;
  };
  /** Access context */
  context: {
    ipAddress: string;
    deviceId: string;
    application: string;
    location: string;
    reason?: string;
  };
  /** Data accessed */
  dataAccessed: string[];
  /** Previous state hash */
  previousHash: string;
  /** Current state hash */
  currentHash: string;
  /** Entry signature */
  signature: string;
  /** Timestamp */
  timestamp: number;
  /** Compliance flags */
  complianceFlags: string[];
}

/**
 * Amendment request
 */
export interface AmendmentRequest {
  /** Request ID */
  id: string;
  /** Patient ID */
  patientId: string;
  /** Record ID */
  recordId: string;
  /** Request type */
  type: 'correction' | 'addition' | 'deletion';
  /** Requested by */
  requestedBy: string;
  /** Request details */
  details: {
    field: string;
    currentValue: string;
    proposedValue: string;
    reason: string;
    supportingDocuments: string[];
  };
  /** Status */
  status: 'pending' | 'under_review' | 'approved' | 'denied' | 'completed';
  /** Review notes */
  reviewNotes?: string;
  /** Reviewed by */
  reviewedBy?: string;
  /** Reviewed at */
  reviewedAt?: number;
  /** Created timestamp */
  createdAt: number;
  /** Updated timestamp */
  updatedAt: number;
}

/**
 * Breach incident
 */
export interface BreachIncident {
  /** Incident ID */
  id: string;
  /** Incident type */
  type: 'unauthorized_access' | 'disclosure' | 'theft' | 'loss' | 'hacking' | 'improper_disposal';
  /** Severity */
  severity: 'low' | 'medium' | 'high' | 'critical';
  /** Status */
  status: 'detected' | 'investigating' | 'contained' | 'resolved' | 'reported';
  /** Affected patients */
  affectedPatients: string[];
  /** Affected records */
  affectedRecords: string[];
  /** Description */
  description: string;
  /** Detection timestamp */
  detectedAt: number;
  /** Detection method */
  detectionMethod: string;
  /** Root cause */
  rootCause?: string;
  /** Containment actions */
  containmentActions: string[];
  /** Notification status */
  notification: {
    patientsNotified: boolean;
    patientsNotifiedAt?: number;
    hhsNotified: boolean;
    hhsNotifiedAt?: number;
    mediaNotified: boolean;
    mediaNotifiedAt?: number;
  };
  /** Resolution */
  resolution?: string;
  /** Resolved at */
  resolvedAt?: number;
}

/**
 * Compliance report
 */
export interface ComplianceReport {
  /** Report ID */
  id: string;
  /** Report type */
  type: 'access_audit' | 'disclosure_log' | 'amendment_log' | 'breach_report' | 'hipaa_audit';
  /** Period */
  period: {
    start: number;
    end: number;
  };
  /** Summary */
  summary: {
    totalAccesses: number;
    uniqueUsers: number;
    uniquePatients: number;
    amendments: number;
    breaches: number;
    violations: number;
  };
  /** Details */
  details: Array<{
    category: string;
    count: number;
    riskLevel: string;
  }>;
  /** Findings */
  findings: Array<{
    type: string;
    description: string;
    severity: 'info' | 'warning' | 'critical';
    recommendation: string;
  }>;
  /** Generated timestamp */
  generatedAt: number;
  /** Generated by */
  generatedBy: string;
  /** Report hash */
  reportHash: string;
}

// ============================================================================
// STORAGE
// ============================================================================

const patients = new Map<string, Patient>();
const records = new Map<string, MedicalRecord>();
const auditChain = new Map<string, AuditEntry>();
const amendments = new Map<string, AmendmentRequest>();
const breaches = new Map<string, BreachIncident>();
const reports = new Map<string, ComplianceReport>();

// Genesis block for audit chain
let genesisEntry: AuditEntry | null = null;

// Platform secret
const PLATFORM_SECRET = 'medical_record_integrity_secret_v1';

// Record block index counter
let blockIndex = 0;

// ============================================================================
// PATIENT MANAGEMENT
// ============================================================================

/**
 * Create patient
 */
export function createPatient(config: {
  mrn: string;
  demographics: Patient['demographics'];
}): Patient {
  const id = `patient_${generateUUID()}`;
  const now = Date.now();

  const patient: Patient = {
    id,
    mrn: config.mrn,
    demographics: config.demographics,
    consent: {
      id: `consent_${generateUUID()}`,
      status: 'partial',
      types: [
        { type: 'treatment', granted: true, description: 'Treatment consent' },
        { type: 'payment', granted: true, description: 'Payment consent' },
        { type: 'operations', granted: true, description: 'Healthcare operations' }
      ],
      grantedTo: [],
      restrictions: [],
      validFrom: now,
      timestamp: now,
      signature: '',
      modifiedAt: now
    },
    accessControl: [],
    recordSummary: {
      totalRecords: 0,
      lastVisit: 0,
      primaryProvider: '',
      conditions: [],
      medications: [],
      allergies: []
    },
    status: 'active',
    createdAt: now,
    updatedAt: now,
    integrityHash: ''
  };

  // Calculate integrity hash
  patient.integrityHash = calculatePatientHash(patient);

  patients.set(id, patient);

  // Create audit entry
  createAuditEntry({
    patientId: id,
    action: 'create',
    actor: { type: 'system', id: 'system', name: 'System', role: 'System' },
    context: { ipAddress: 'system', deviceId: 'system', application: 'EHR', location: 'System' },
    dataAccessed: ['demographics']
  });

  return patient;
}

/**
 * Get patient
 */
export function getPatient(patientId: string): Patient | undefined {
  return patients.get(patientId);
}

/**
 * Update patient
 */
export function updatePatient(patientId: string, updates: Partial<Patient>): Patient | null {
  const patient = patients.get(patientId);
  if (!patient) return null;

  // Store previous hash
  const previousHash = patient.integrityHash;

  // Apply updates (excluding protected fields)
  const protectedFields = ['id', 'createdAt', 'integrityHash'];
  for (const key of Object.keys(updates)) {
    if (!protectedFields.includes(key)) {
      (patient as Record<string, unknown>)[key] = updates[key as keyof Patient];
    }
  }

  patient.updatedAt = Date.now();
  patient.integrityHash = calculatePatientHash(patient);

  patients.set(patientId, patient);

  // Create audit entry
  createAuditEntry({
    patientId,
    action: 'update',
    actor: { type: 'system', id: 'system', name: 'System', role: 'System' },
    context: { ipAddress: 'system', deviceId: 'system', application: 'EHR', location: 'System' },
    dataAccessed: Object.keys(updates),
    previousHash
  });

  return patient;
}

/**
 * Calculate patient hash
 */
function calculatePatientHash(patient: Patient): string {
  const data = JSON.stringify({
    id: patient.id,
    mrn: patient.mrn,
    status: patient.status,
    consentStatus: patient.consent.status,
    updatedAt: patient.updatedAt
  });
  return sha256Hash(data);
}

// ============================================================================
// CONSENT MANAGEMENT
// ============================================================================

/**
 * Update consent
 */
export function updateConsent(patientId: string, consent: Partial<PatientConsent>): PatientConsent | null {
  const patient = patients.get(patientId);
  if (!patient) return null;

  Object.assign(patient.consent, consent);
  patient.consent.modifiedAt = Date.now();
  patient.updatedAt = Date.now();

  patients.set(patientId, patient);

  // Create audit entry
  createAuditEntry({
    patientId,
    action: 'update',
    actor: { type: 'patient', id: patientId, name: 'Patient', role: 'Patient' },
    context: { ipAddress: '', deviceId: '', application: 'EHR', location: 'Patient Portal' },
    dataAccessed: ['consent']
  });

  return patient.consent;
}

/**
 * Revoke consent
 */
export function revokeConsent(patientId: string, reason: string): PatientConsent | null {
  const patient = patients.get(patientId);
  if (!patient) return null;

  patient.consent.status = 'revoked';
  patient.consent.modifiedAt = Date.now();

  // Add restriction
  patient.consent.restrictions.push({
    type: 'no_disclosure',
    description: reason,
    categories: ['all'],
    exceptions: []
  });

  patients.set(patientId, patient);

  return patient.consent;
}

// ============================================================================
// ACCESS CONTROL
// ============================================================================

/**
 * Grant access
 */
export function grantAccess(config: {
  patientId: string;
  principalType: AccessControlEntry['principalType'];
  principalId: string;
  principalName: string;
  permissions: AccessControlEntry['permissions'];
  scope: AccessControlEntry['scope'];
  grantedBy: string;
  expiresAt?: number;
}): AccessControlEntry | null {
  const patient = patients.get(config.patientId);
  if (!patient) return null;

  const entry: AccessControlEntry = {
    id: `ace_${generateUUID()}`,
    principalType: config.principalType,
    principalId: config.principalId,
    principalName: config.principalName,
    permissions: config.permissions,
    scope: config.scope,
    grantedBy: config.grantedBy,
    grantedAt: Date.now(),
    expiresAt: config.expiresAt,
    status: 'active'
  };

  patient.accessControl.push(entry);
  patient.updatedAt = Date.now();
  patients.set(config.patientId, patient);

  return entry;
}

/**
 * Revoke access
 */
export function revokeAccess(patientId: string, aceId: string): boolean {
  const patient = patients.get(patientId);
  if (!patient) return false;

  const entry = patient.accessControl.find(ace => ace.id === aceId);
  if (!entry) return false;

  entry.status = 'revoked';
  patient.updatedAt = Date.now();
  patients.set(patientId, patient);

  return true;
}

/**
 * Check access
 */
export function checkAccess(patientId: string, principalId: string, permission: 'read' | 'write' | 'delete' | 'admin'): {
  allowed: boolean;
  reason?: string;
} {
  const patient = patients.get(patientId);
  if (!patient) {
    return { allowed: false, reason: 'Patient not found' };
  }

  // Check consent status
  if (patient.consent.status === 'revoked') {
    return { allowed: false, reason: 'Consent revoked' };
  }

  // Find access entry
  const entry = patient.accessControl.find(
    ace => ace.principalId === principalId && 
           ace.status === 'active' &&
           ace.permissions.includes(permission)
  );

  if (!entry) {
    return { allowed: false, reason: 'No access granted' };
  }

  // Check expiration
  if (entry.expiresAt && entry.expiresAt < Date.now()) {
    entry.status = 'expired';
    patients.set(patientId, patient);
    return { allowed: false, reason: 'Access expired' };
  }

  return { allowed: true };
}

// ============================================================================
// MEDICAL RECORDS
// ============================================================================

/**
 * Create medical record
 */
export function createRecord(config: {
  patientId: string;
  type: MedicalRecordType;
  clinicalData: Omit<ClinicalData, 'dataHash'>;
  provider: Omit<ProviderInfo, 'signature' | 'attestedAt'>;
  encounter: EncounterInfo;
}): MedicalRecord {
  const patient = patients.get(config.patientId);
  if (!patient) {
    throw new Error('Patient not found');
  }

  const id = `record_${generateUUID()}`;
  const now = Date.now();

  // Calculate clinical data hash
  const dataHash = sha256Hash(JSON.stringify(config.clinicalData));

  const record: MedicalRecord = {
    id,
    patientId: config.patientId,
    type: config.type,
    status: 'active',
    clinicalData: {
      ...config.clinicalData,
      dataHash
    },
    provider: {
      ...config.provider,
      signature: signRecord(id, dataHash),
      attestedAt: now
    },
    encounter: config.encounter,
    integrity: {
      hash: '',
      previousHash: getPreviousRecordHash(config.patientId),
      blockIndex: ++blockIndex,
      merkleRoot: '',
      signature: '',
      signedBy: config.provider.providerId,
      timestamp: now,
      verificationStatus: 'verified'
    },
    version: {
      number: 1,
      createdBy: config.provider.providerId,
      createdAt: now
    },
    retention: {
      category: 'long_term',
      legalHold: false
    }
  };

  // Calculate integrity hash
  record.integrity.hash = calculateRecordHash(record);
  record.integrity.merkleRoot = calculateMerkleRoot([record]);
  record.integrity.signature = signRecordIntegrity(record);

  records.set(id, record);

  // Update patient summary
  patient.recordSummary.totalRecords++;
  patient.recordSummary.lastVisit = now;
  patient.updatedAt = now;
  patients.set(config.patientId, patient);

  // Create audit entry
  createAuditEntry({
    patientId: config.patientId,
    recordId: id,
    action: 'create',
    actor: { type: 'provider', id: config.provider.providerId, name: config.provider.name, role: config.provider.role },
    context: { ipAddress: '', deviceId: '', application: 'EHR', location: config.encounter.location },
    dataAccessed: [config.type]
  });

  return record;
}

/**
 * Get record
 */
export function getRecord(recordId: string): MedicalRecord | undefined {
  return records.get(recordId);
}

/**
 * Get patient records
 */
export function getPatientRecords(patientId: string): MedicalRecord[] {
  return Array.from(records.values()).filter(r => r.patientId === patientId);
}

/**
 * Amend record
 */
export function amendRecord(config: {
  recordId: string;
  amendments: Partial<ClinicalData>;
  amendedBy: ProviderInfo;
  reason: string;
}): MedicalRecord | null {
  const record = records.get(config.recordId);
  if (!record) return null;

  // Create new version
  const previousVersion = { ...record };
  const newVersionNumber = record.version.number + 1;

  // Apply amendments
  for (const key of Object.keys(config.amendments)) {
    if (key !== 'dataHash') {
      (record.clinicalData as Record<string, unknown>)[key] = 
        config.amendments[key as keyof ClinicalData];
    }
  }

  // Update clinical data hash
  record.clinicalData.dataHash = sha256Hash(JSON.stringify(record.clinicalData));

  // Update integrity
  record.integrity.previousHash = record.integrity.hash;
  record.integrity.hash = calculateRecordHash(record);
  record.integrity.blockIndex = ++blockIndex;
  record.integrity.timestamp = Date.now();
  record.integrity.signature = signRecordIntegrity(record);
  record.integrity.verificationStatus = 'verified';

  // Update version
  record.version = {
    number: newVersionNumber,
    previousVersionId: record.id,
    createdBy: config.amendedBy.providerId,
    createdAt: Date.now(),
    reason: config.reason
  };

  record.status = 'amended';
  record.provider = {
    ...config.amendedBy,
    signature: signRecord(record.id, record.clinicalData.dataHash),
    attestedAt: Date.now()
  };

  records.set(config.recordId, record);

  // Create audit entry
  createAuditEntry({
    patientId: record.patientId,
    recordId: config.recordId,
    action: 'amend',
    actor: { type: 'provider', id: config.amendedBy.providerId, name: config.amendedBy.name, role: config.amendedBy.role },
    context: { ipAddress: '', deviceId: '', application: 'EHR', location: '', reason: config.reason },
    dataAccessed: Object.keys(config.amendments)
  });

  return record;
}

/**
 * Void record
 */
export function voidRecord(recordId: string, voidedBy: ProviderInfo, reason: string): MedicalRecord | null {
  const record = records.get(recordId);
  if (!record) return null;

  record.status = 'voided';
  record.version = {
    ...record.version,
    number: record.version.number + 1,
    createdBy: voidedBy.providerId,
    createdAt: Date.now(),
    reason: `Voided: ${reason}`
  };

  records.set(recordId, record);

  // Create audit entry
  createAuditEntry({
    patientId: record.patientId,
    recordId,
    action: 'void',
    actor: { type: 'provider', id: voidedBy.providerId, name: voidedBy.name, role: voidedBy.role },
    context: { ipAddress: '', deviceId: '', application: 'EHR', location: '', reason },
    dataAccessed: [record.type]
  });

  return record;
}

/**
 * Calculate record hash
 */
function calculateRecordHash(record: MedicalRecord): string {
  const data = JSON.stringify({
    id: record.id,
    patientId: record.patientId,
    type: record.type,
    status: record.status,
    clinicalDataHash: record.clinicalData.dataHash,
    providerId: record.provider.providerId,
    previousHash: record.integrity.previousHash,
    blockIndex: record.integrity.blockIndex,
    timestamp: record.integrity.timestamp
  });
  return sha256Hash(data);
}

/**
 * Calculate merkle root
 */
function calculateMerkleRoot(records: MedicalRecord[]): string {
  if (records.length === 0) return '';
  if (records.length === 1) return records[0].integrity.hash;

  const hashes = records.map(r => r.integrity.hash);
  
  while (hashes.length > 1) {
    const newHashes: string[] = [];
    for (let i = 0; i < hashes.length; i += 2) {
      const left = hashes[i];
      const right = hashes[i + 1] || left;
      newHashes.push(sha256Hash(left + right));
    }
    hashes.length = 0;
    hashes.push(...newHashes);
  }

  return hashes[0];
}

/**
 * Get previous record hash
 */
function getPreviousRecordHash(patientId: string): string {
  const patientRecords = getPatientRecords(patientId);
  if (patientRecords.length === 0) {
    return '0'.repeat(64);
  }
  return patientRecords[patientRecords.length - 1].integrity.hash;
}

// ============================================================================
// AUDIT CHAIN (CAIL)
// ============================================================================

/**
 * Initialize genesis block
 */
function initializeGenesisBlock(): AuditEntry {
  if (genesisEntry) return genesisEntry;

  const now = Date.now();
  genesisEntry = {
    id: `audit_genesis`,
    patientId: 'genesis',
    action: 'create',
    actor: { type: 'system', id: 'system', name: 'System', role: 'System' },
    context: { ipAddress: 'system', deviceId: 'system', application: 'EHR', location: 'System' },
    dataAccessed: [],
    previousHash: '0'.repeat(64),
    currentHash: '',
    signature: '',
    timestamp: now,
    complianceFlags: []
  };

  genesisEntry.currentHash = calculateAuditHash(genesisEntry);
  genesisEntry.signature = signAuditEntry(genesisEntry);

  auditChain.set(genesisEntry.id, genesisEntry);
  return genesisEntry;
}

/**
 * Create audit entry
 */
function createAuditEntry(config: {
  patientId: string;
  recordId?: string;
  action: AuditEntry['action'];
  actor: AuditEntry['actor'];
  context: AuditEntry['context'];
  dataAccessed: string[];
  previousHash?: string;
}): AuditEntry {
  if (!genesisEntry) {
    initializeGenesisBlock();
  }

  const lastEntry = getLastAuditEntry();
  const previousHash = config.previousHash || lastEntry?.currentHash || '0'.repeat(64);

  const entry: AuditEntry = {
    id: `audit_${generateUUID()}`,
    patientId: config.patientId,
    recordId: config.recordId,
    action: config.action,
    actor: config.actor,
    context: config.context,
    dataAccessed: config.dataAccessed,
    previousHash,
    currentHash: '',
    signature: '',
    timestamp: Date.now(),
    complianceFlags: checkComplianceFlags(config)
  };

  entry.currentHash = calculateAuditHash(entry);
  entry.signature = signAuditEntry(entry);

  auditChain.set(entry.id, entry);
  return entry;
}

/**
 * Get last audit entry
 */
function getLastAuditEntry(): AuditEntry | undefined {
  const entries = Array.from(auditChain.values());
  return entries[entries.length - 1];
}

/**
 * Calculate audit hash
 */
function calculateAuditHash(entry: AuditEntry): string {
  const data = JSON.stringify({
    id: entry.id,
    patientId: entry.patientId,
    action: entry.action,
    actor: entry.actor.id,
    dataAccessed: entry.dataAccessed.sort(),
    previousHash: entry.previousHash,
    timestamp: entry.timestamp
  });
  return sha256Hash(data);
}

/**
 * Sign audit entry
 */
function signAuditEntry(entry: AuditEntry): string {
  return hmacSign(entry.currentHash, PLATFORM_SECRET);
}

/**
 * Sign record
 */
function signRecord(recordId: string, dataHash: string): string {
  return hmacSign(recordId + dataHash, PLATFORM_SECRET);
}

/**
 * Sign record integrity
 */
function signRecordIntegrity(record: MedicalRecord): string {
  return hmacSign(record.integrity.hash, PLATFORM_SECRET);
}

/**
 * Check compliance flags
 */
function checkComplianceFlags(config: { action: AuditEntry['action']; dataAccessed: string[] }): string[] {
  const flags: string[] = [];

  // Check for sensitive data access
  const sensitiveCategories = ['mental_health', 'substance_abuse', 'hiv', 'genetic', 'reproductive'];
  for (const category of sensitiveCategories) {
    if (config.dataAccessed.some(d => d.toLowerCase().includes(category))) {
      flags.push(`sensitive_access:${category}`);
    }
  }

  // Check for high-risk actions
  if (config.action === 'delete' || config.action === 'void') {
    flags.push('destructive_action');
  }

  if (config.action === 'export' || config.action === 'print') {
    flags.push('data_export');
  }

  return flags;
}

/**
 * Verify audit chain integrity
 */
export function verifyAuditChainIntegrity(): {
  valid: boolean;
  entriesChecked: number;
  brokenAt?: string;
  errors: string[];
} {
  const entries = Array.from(auditChain.values());
  const errors: string[] = [];
  let brokenAt: string | undefined;

  for (let i = 1; i < entries.length; i++) {
    const current = entries[i];
    const previous = entries[i - 1];

    // Verify chain link
    if (current.previousHash !== previous.currentHash) {
      errors.push(`Chain break at ${current.id}: previous hash mismatch`);
      brokenAt = current.id;
      break;
    }

    // Verify hash
    const calculatedHash = calculateAuditHash(current);
    if (current.currentHash !== calculatedHash) {
      errors.push(`Hash mismatch at ${current.id}`);
      brokenAt = current.id;
      break;
    }

    // Verify signature
    const expectedSig = signAuditEntry(current);
    if (current.signature !== expectedSig) {
      errors.push(`Signature invalid at ${current.id}`);
      brokenAt = current.id;
      break;
    }
  }

  return {
    valid: errors.length === 0,
    entriesChecked: entries.length,
    brokenAt,
    errors
  };
}

/**
 * Get audit trail for patient
 */
export function getPatientAuditTrail(patientId: string): AuditEntry[] {
  return Array.from(auditChain.values())
    .filter(e => e.patientId === patientId)
    .sort((a, b) => a.timestamp - b.timestamp);
}

// ============================================================================
// AMENDMENT REQUESTS
// ============================================================================

/**
 * Create amendment request
 */
export function createAmendmentRequest(config: {
  patientId: string;
  recordId: string;
  type: AmendmentRequest['type'];
  requestedBy: string;
  details: AmendmentRequest['details'];
}): AmendmentRequest {
  const request: AmendmentRequest = {
    id: `amend_${generateUUID()}`,
    patientId: config.patientId,
    recordId: config.recordId,
    type: config.type,
    requestedBy: config.requestedBy,
    details: config.details,
    status: 'pending',
    createdAt: Date.now(),
    updatedAt: Date.now()
  };

  amendments.set(request.id, request);

  // Create audit entry
  createAuditEntry({
    patientId: config.patientId,
    recordId: config.recordId,
    action: 'amend',
    actor: { type: 'patient', id: config.requestedBy, name: 'Patient', role: 'Patient' },
    context: { ipAddress: '', deviceId: '', application: 'Patient Portal', location: '', reason: `Amendment request: ${config.type}` },
    dataAccessed: [config.details.field]
  });

  return request;
}

/**
 * Review amendment request
 */
export function reviewAmendmentRequest(config: {
  requestId: string;
  approved: boolean;
  reviewedBy: string;
  notes: string;
}): AmendmentRequest | null {
  const request = amendments.get(config.requestId);
  if (!request) return null;

  request.status = config.approved ? 'approved' : 'denied';
  request.reviewNotes = config.notes;
  request.reviewedBy = config.reviewedBy;
  request.reviewedAt = Date.now();
  request.updatedAt = Date.now();

  if (config.approved) {
    request.status = 'completed';
  }

  amendments.set(config.requestId, request);
  return request;
}

/**
 * Get amendment request
 */
export function getAmendmentRequest(requestId: string): AmendmentRequest | undefined {
  return amendments.get(requestId);
}

// ============================================================================
// BREACH DETECTION
// ============================================================================

/**
 * Report breach
 */
export function reportBreach(config: {
  type: BreachIncident['type'];
  severity: BreachIncident['severity'];
  affectedPatients: string[];
  affectedRecords: string[];
  description: string;
  detectionMethod: string;
}): BreachIncident {
  const incident: BreachIncident = {
    id: `breach_${generateUUID()}`,
    type: config.type,
    severity: config.severity,
    status: 'detected',
    affectedPatients: config.affectedPatients,
    affectedRecords: config.affectedRecords,
    description: config.description,
    detectedAt: Date.now(),
    detectionMethod: config.detectionMethod,
    containmentActions: [],
    notification: {
      patientsNotified: false,
      hhsNotified: false,
      mediaNotified: false
    }
  };

  breaches.set(incident.id, incident);

  // Create audit entries for affected patients
  for (const patientId of config.affectedPatients) {
    createAuditEntry({
      patientId,
      action: 'read',
      actor: { type: 'system', id: 'breach_detection', name: 'Breach Detection', role: 'System' },
      context: { ipAddress: '', deviceId: '', application: 'Security', location: '', reason: `Breach incident: ${incident.id}` },
      dataAccessed: ['breach_notification'],
      previousHash: ''
    });
  }

  return incident;
}

/**
 * Update breach status
 */
export function updateBreachStatus(config: {
  breachId: string;
  status: BreachIncident['status'];
  rootCause?: string;
  containmentActions?: string[];
  resolution?: string;
}): BreachIncident | null {
  const incident = breaches.get(config.breachId);
  if (!incident) return null;

  incident.status = config.status;
  if (config.rootCause) incident.rootCause = config.rootCause;
  if (config.containmentActions) incident.containmentActions = config.containmentActions;
  if (config.resolution) incident.resolution = config.resolution;

  if (config.status === 'resolved') {
    incident.resolvedAt = Date.now();
  }

  breaches.set(config.breachId, incident);
  return incident;
}

/**
 * Record notification
 */
export function recordNotification(config: {
  breachId: string;
  type: 'patients' | 'hhs' | 'media';
}): BreachIncident | null {
  const incident = breaches.get(config.breachId);
  if (!incident) return null;

  const now = Date.now();
  switch (config.type) {
    case 'patients':
      incident.notification.patientsNotified = true;
      incident.notification.patientsNotifiedAt = now;
      break;
    case 'hhs':
      incident.notification.hhsNotified = true;
      incident.notification.hhsNotifiedAt = now;
      break;
    case 'media':
      incident.notification.mediaNotified = true;
      incident.notification.mediaNotifiedAt = now;
      break;
  }

  breaches.set(config.breachId, incident);
  return incident;
}

/**
 * Get breach
 */
export function getBreach(breachId: string): BreachIncident | undefined {
  return breaches.get(breachId);
}

// ============================================================================
// COMPLIANCE REPORTING
// ============================================================================

/**
 * Generate compliance report
 */
export function generateComplianceReport(config: {
  type: ComplianceReport['type'];
  periodStart: number;
  periodEnd: number;
  generatedBy: string;
}): ComplianceReport {
  const periodEntries = Array.from(auditChain.values())
    .filter(e => e.timestamp >= config.periodStart && e.timestamp <= config.periodEnd);

  const uniqueUsers = new Set(periodEntries.map(e => e.actor.id));
  const uniquePatients = new Set(periodEntries.map(e => e.patientId));

  const report: ComplianceReport = {
    id: `report_${generateUUID()}`,
    type: config.type,
    period: {
      start: config.periodStart,
      end: config.periodEnd
    },
    summary: {
      totalAccesses: periodEntries.length,
      uniqueUsers: uniqueUsers.size,
      uniquePatients: uniquePatients.size,
      amendments: amendments.size,
      breaches: breaches.size,
      violations: periodEntries.filter(e => e.complianceFlags.length > 0).length
    },
    details: [
      { category: 'Read Access', count: periodEntries.filter(e => e.action === 'read').length, riskLevel: 'low' },
      { category: 'Updates', count: periodEntries.filter(e => e.action === 'update').length, riskLevel: 'medium' },
      { category: 'Deletions', count: periodEntries.filter(e => e.action === 'delete').length, riskLevel: 'high' },
      { category: 'Exports', count: periodEntries.filter(e => e.action === 'export').length, riskLevel: 'medium' },
      { category: 'Prints', count: periodEntries.filter(e => e.action === 'print').length, riskLevel: 'low' }
    ],
    findings: analyzeComplianceFindings(periodEntries),
    generatedAt: Date.now(),
    generatedBy: config.generatedBy,
    reportHash: ''
  };

  report.reportHash = sha256Hash(JSON.stringify({
    id: report.id,
    type: report.type,
    summary: report.summary,
    generatedAt: report.generatedAt
  }));

  reports.set(report.id, report);
  return report;
}

/**
 * Analyze compliance findings
 */
function analyzeComplianceFindings(entries: AuditEntry[]): ComplianceReport['findings'] {
  const findings: ComplianceReport['findings'] = [];

  // Check for after-hours access
  const afterHoursEntries = entries.filter(e => {
    const hour = new Date(e.timestamp).getHours();
    return hour < 6 || hour > 22;
  });

  if (afterHoursEntries.length > 10) {
    findings.push({
      type: 'after_hours_access',
      description: `${afterHoursEntries.length} accesses outside normal hours`,
      severity: 'warning',
      recommendation: 'Review after-hours access patterns'
    });
  }

  // Check for bulk access
  const accessesByUser = new Map<string, number>();
  for (const entry of entries) {
    accessesByUser.set(entry.actor.id, (accessesByUser.get(entry.actor.id) || 0) + 1);
  }

  for (const [userId, count] of accessesByUser) {
    if (count > 500) {
      findings.push({
        type: 'high_volume_access',
        description: `User ${userId} accessed ${count} records`,
        severity: 'warning',
        recommendation: 'Verify access necessity'
      });
    }
  }

  // Check for compliance flags
  const flaggedEntries = entries.filter(e => e.complianceFlags.length > 0);
  if (flaggedEntries.length > 0) {
    findings.push({
      type: 'compliance_flags',
      description: `${flaggedEntries.length} entries with compliance flags`,
      severity: 'critical',
      recommendation: 'Review flagged entries immediately'
    });
  }

  return findings;
}

/**
 * Get report
 */
export function getReport(reportId: string): ComplianceReport | undefined {
  return reports.get(reportId);
}

// ============================================================================
// STATISTICS
// ============================================================================

/**
 * Get system statistics
 */
export function getSystemStats(): {
  patients: { total: number; active: number };
  records: { total: number; byType: Record<string, number> };
  audit: { totalEntries: number; chainIntegrity: boolean };
  amendments: { total: number; pending: number };
  breaches: { total: number; open: number };
  reports: number;
} {
  const allRecords = Array.from(records.values());
  const allAmendments = Array.from(amendments.values());
  const allBreaches = Array.from(breaches.values());

  const chainResult = verifyAuditChainIntegrity();

  return {
    patients: {
      total: patients.size,
      active: Array.from(patients.values()).filter(p => p.status === 'active').length
    },
    records: {
      total: allRecords.length,
      byType: allRecords.reduce((acc, r) => {
        acc[r.type] = (acc[r.type] || 0) + 1;
        return acc;
      }, {} as Record<string, number>)
    },
    audit: {
      totalEntries: auditChain.size,
      chainIntegrity: chainResult.valid
    },
    amendments: {
      total: allAmendments.length,
      pending: allAmendments.filter(a => a.status === 'pending').length
    },
    breaches: {
      total: allBreaches.length,
      open: allBreaches.filter(b => b.status !== 'resolved').length
    },
    reports: reports.size
  };
}

// ============================================================================
// TEST SUITE
// ============================================================================

/**
 * Run medical record integrity tests
 */
export function runMedicalRecordIntegrityTests(): {
  passed: boolean;
  tests: { total: number; passed: number; failed: number };
  results: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const results: Array<{ name: string; passed: boolean; error?: string }> = [];

  try {
    // Initialize genesis block
    initializeGenesisBlock();

    // Test 1: Create patient
    const patient = createPatient({
      mrn: 'MRN001',
      demographics: {
        firstName: 'John',
        lastName: 'Doe',
        dateOfBirth: '1990-01-01',
        gender: 'male',
        address: '123 Main St',
        phone: '555-1234',
        email: 'john@example.com',
        emergencyContact: 'Jane Doe'
      }
    });
    results.push({ name: 'Create Patient', passed: !!patient.id && !!patient.integrityHash });

    // Test 2: Grant access
    const access = grantAccess({
      patientId: patient.id,
      principalType: 'provider',
      principalId: 'dr_smith',
      principalName: 'Dr. Smith',
      permissions: ['read', 'write'],
      scope: 'full',
      grantedBy: 'admin'
    });
    results.push({ name: 'Grant Access', passed: !!access && access.status === 'active' });

    // Test 3: Check access
    const accessCheck = checkAccess(patient.id, 'dr_smith', 'read');
    results.push({ name: 'Check Access', passed: accessCheck.allowed });

    // Test 4: Create medical record
    const record = createRecord({
      patientId: patient.id,
      type: 'progress_note',
      clinicalData: {
        chiefComplaint: 'Headache',
        hpi: 'Patient reports headache for 3 days',
        assessment: 'Tension headache',
        plan: 'Rest and OTC pain medication'
      },
      provider: {
        providerId: 'dr_smith',
        name: 'Dr. Smith',
        npi: '1234567890',
        department: 'Primary Care',
        organization: 'Medical Center',
        role: 'Physician'
      },
      encounter: {
        encounterId: 'enc_001',
        type: 'office_visit',
        location: 'Clinic A',
        department: 'Primary Care',
        startTime: Date.now()
      }
    });
    results.push({ name: 'Create Medical Record', passed: !!record.id && record.integrity.verificationStatus === 'verified' });

    // Test 5: Verify record integrity
    const calculatedHash = calculateRecordHash(record);
    results.push({ name: 'Record Integrity', passed: record.integrity.hash === calculatedHash });

    // Test 6: Amend record
    const amendedRecord = amendRecord({
      recordId: record.id,
      amendments: {
        plan: 'Rest, OTC pain medication, and follow-up in 1 week'
      },
      amendedBy: {
        providerId: 'dr_smith',
        name: 'Dr. Smith',
        npi: '1234567890',
        department: 'Primary Care',
        organization: 'Medical Center',
        role: 'Physician'
      },
      reason: 'Added follow-up instructions'
    });
    results.push({ name: 'Amend Record', passed: amendedRecord!.status === 'amended' && amendedRecord!.version.number === 2 });

    // Test 7: Create amendment request
    const amendmentRequest = createAmendmentRequest({
      patientId: patient.id,
      recordId: record.id,
      type: 'correction',
      requestedBy: patient.id,
      details: {
        field: 'allergies',
        currentValue: '',
        proposedValue: 'Penicillin',
        reason: 'Forgot to mention allergy',
        supportingDocuments: []
      }
    });
    results.push({ name: 'Create Amendment Request', passed: amendmentRequest.status === 'pending' });

    // Test 8: Verify audit chain integrity
    const chainResult = verifyAuditChainIntegrity();
    results.push({ name: 'Audit Chain Integrity', passed: chainResult.valid });

    // Test 9: Get patient audit trail
    const auditTrail = getPatientAuditTrail(patient.id);
    results.push({ name: 'Patient Audit Trail', passed: auditTrail.length >= 3 });

    // Test 10: Report breach
    const breach = reportBreach({
      type: 'unauthorized_access',
      severity: 'medium',
      affectedPatients: [patient.id],
      affectedRecords: [record.id],
      description: 'Unauthorized access attempt detected',
      detectionMethod: 'Access monitoring'
    });
    results.push({ name: 'Report Breach', passed: breach.status === 'detected' });

    // Test 11: Generate compliance report
    const complianceReport = generateComplianceReport({
      type: 'access_audit',
      periodStart: Date.now() - 86400000,
      periodEnd: Date.now(),
      generatedBy: 'admin'
    });
    results.push({ name: 'Generate Compliance Report', passed: !!complianceReport.reportHash });

    // Test 12: System statistics
    const stats = getSystemStats();
    results.push({ name: 'System Statistics', passed: stats.patients.total === 1 && stats.audit.chainIntegrity });

  } catch (error) {
    results.push({ name: 'Test Execution', passed: false, error: String(error) });
  }

  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;

  return {
    passed: failed === 0,
    tests: { total: results.length, passed, failed },
    results
  };
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

export default {
  createPatient,
  getPatient,
  updatePatient,
  updateConsent,
  revokeConsent,
  grantAccess,
  revokeAccess,
  checkAccess,
  createRecord,
  getRecord,
  getPatientRecords,
  amendRecord,
  voidRecord,
  verifyAuditChainIntegrity,
  getPatientAuditTrail,
  createAmendmentRequest,
  reviewAmendmentRequest,
  getAmendmentRequest,
  reportBreach,
  updateBreachStatus,
  recordNotification,
  getBreach,
  generateComplianceReport,
  getReport,
  getSystemStats,
  runMedicalRecordIntegrityTests
};
