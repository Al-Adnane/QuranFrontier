/**
 * Agent Spending Authorization & API Access Delegation
 * =====================================================
 * 
 * Controls "what can this agent consume, on whose behalf, with what limit"
 * 
 * Features:
 * - Spending authorization with budgets and quotas
 * - API access delegation with scope restrictions
 * - Principal (user) delegation chains
 * - Time-limited authorizations
 * - Real-time consumption tracking
 * - Rate limiting per agent/principal
 * - Cost attribution and billing
 * - Revocation and audit trails
 * - Multi-tenant isolation
 * - Hierarchical permission inheritance
 * 
 * @module frontier/agent-delegation
 * @version 1.0.0
 */

// ============================================================================
// TYPES
// ============================================================================

/**
 * Resource types that can be consumed
 */
export type ResourceType = 
  | 'api_calls'
  | 'tokens'
  | 'compute_seconds'
  | 'storage_bytes'
  | 'bandwidth_bytes'
  | 'memory_mb_seconds'
  | 'gpu_seconds'
  | 'vlm_calls'
  | 'llm_calls'
  | 'image_generations'
  | 'video_seconds'
  | 'audio_seconds';

/**
 * API categories that can be delegated
 */
export type APICategory = 
  | 'detection'
  | 'generation'
  | 'analysis'
  | 'forensics'
  | 'blockchain'
  | 'xai'
  | 'admin'
  | 'billing'
  | 'user_management'
  | 'agent_management';

/**
 * Authorization status
 */
export type AuthorizationStatus = 
  | 'active'
  | 'paused'
  | 'exhausted'
  | 'expired'
  | 'revoked'
  | 'pending_approval';

/**
 * Delegation level
 */
export type DelegationLevel = 
  | 'primary'      // Direct user authorization
  | 'secondary'    // Agent delegated by primary agent
  | 'tertiary';    // Agent delegated by secondary agent

/**
 * Principal (user/account) identity
 */
export interface Principal {
  id: string;
  type: 'user' | 'service_account' | 'organization' | 'system';
  email?: string;
  name: string;
  tier: 'free' | 'basic' | 'pro' | 'enterprise' | 'internal';
  metadata?: Record<string, unknown>;
  createdAt: number;
}

/**
 * Agent identity
 */
export interface AgentIdentity {
  id: string;
  name: string;
  type: 'autonomous' | 'semi-autonomous' | 'assistant' | 'workflow' | 'orchestrator';
  ownerId: string; // Principal who owns this agent
  trustLevel: number; // 0-100
  capabilities: string[];
  createdAt: number;
  lastActive?: number;
}

/**
 * Budget allocation for a resource
 */
export interface BudgetAllocation {
  resourceType: ResourceType;
  /** Total allocated amount */
  totalAllocated: number;
  /** Amount consumed so far */
  consumed: number;
  /** Remaining amount */
  remaining: number;
  /** Reset period in seconds (0 = never) */
  resetPeriodSeconds: number;
  /** Last reset timestamp */
  lastReset: number;
  /** Overdraft allowed */
  overdraftAllowed: boolean;
  /** Overdraft limit */
  overdraftLimit: number;
  /** Current overdraft used */
  overdraftUsed: number;
  /** Alert thresholds (percentages) */
  alertThresholds: number[];
  /** Alerts triggered */
  alertsTriggered: string[];
}

/**
 * Rate limit configuration
 */
export interface RateLimitConfig {
  requestsPerSecond?: number;
  requestsPerMinute?: number;
  requestsPerHour?: number;
  requestsPerDay?: number;
  tokensPerMinute?: number;
  tokensPerHour?: number;
  concurrentRequests?: number;
  burstSize?: number;
}

/**
 * API Scope definition
 */
export interface APIScope {
  category: APICategory;
  actions: string[];
  resources: string[]; // Specific resource IDs or patterns
  conditions?: {
    timeWindow?: { start: number; end: number };
    ipRanges?: string[];
    userAgentPatterns?: string[];
    metadata?: Record<string, unknown>;
  };
}

/**
 * Spending Authorization
 */
export interface SpendingAuthorization {
  id: string;
  agentId: string;
  principalId: string;
  status: AuthorizationStatus;
  delegationLevel: DelegationLevel;
  
  // Budgets
  budgets: BudgetAllocation[];
  
  // Rate limits
  rateLimits: RateLimitConfig;
  
  // Time constraints
  validFrom: number;
  validUntil: number;
  
  // Approval workflow
  requiresApproval: boolean;
  approvedBy?: string;
  approvedAt?: number;
  
  // Audit
  createdAt: number;
  updatedAt: number;
  lastConsumptionAt?: number;
  
  // Metadata
  purpose?: string;
  tags: string[];
  metadata?: Record<string, unknown>;
}

/**
 * API Access Delegation
 */
export interface APIAccessDelegation {
  id: string;
  agentId: string;
  principalId: string;
  delegatorId: string; // Who delegated (could be principal or another agent)
  delegationLevel: DelegationLevel;
  
  // Scopes
  scopes: APIScope[];
  
  // Restrictions
  maxDelegationDepth: number;
  allowFurtherDelegation: boolean;
  
  // Status
  status: AuthorizationStatus;
  
  // Time constraints
  validFrom: number;
  validUntil: number;
  
  // Audit
  createdAt: number;
  revokedAt?: number;
  revokedBy?: string;
  revocationReason?: string;
  
  // Usage tracking
  totalCalls: number;
  lastCallAt?: number;
}

/**
 * Consumption record
 */
export interface ConsumptionRecord {
  id: string;
  authorizationId: string;
  agentId: string;
  principalId: string;
  
  // What was consumed
  resourceType: ResourceType;
  amount: number;
  
  // Context
  apiEndpoint?: string;
  apiCategory?: APICategory;
  requestId?: string;
  
  // Attribution
  costCents: number; // Cost in cents (USD)
  
  // Timing
  timestamp: number;
  durationMs?: number;
  
  // Result
  success: boolean;
  errorMessage?: string;
  
  // Metadata
  metadata?: Record<string, unknown>;
}

/**
 * Spending alert
 */
export interface SpendingAlert {
  id: string;
  authorizationId: string;
  agentId: string;
  principalId: string;
  alertType: 'threshold' | 'exhausted' | 'overdraft' | 'rate_limited' | 'expired' | 'anomaly';
  resourceType: ResourceType;
  thresholdPercent?: number;
  message: string;
  timestamp: number;
  acknowledged: boolean;
  acknowledgedBy?: string;
  acknowledgedAt?: number;
}

/**
 * Delegation chain entry
 */
export interface DelegationChainEntry {
  id: string;
  delegatorType: 'principal' | 'agent';
  delegatorId: string;
  delegateeAgentId: string;
  delegatedAt: number;
  scope: string[];
  constraints: Record<string, unknown>;
}

/**
 * Policy rule for authorization
 */
export interface AuthorizationPolicy {
  id: string;
  name: string;
  description: string;
  
  // Who it applies to
  principalTiers?: string[];
  agentTypes?: string[];
  agentIdPatterns?: string[];
  
  // Budget rules
  defaultBudgets: Partial<Record<ResourceType, {
    default: number;
    max: number;
    resetPeriodSeconds: number;
  }>>;
  
  // Rate limit rules
  defaultRateLimits: RateLimitConfig;
  
  // Scope restrictions
  allowedScopes: APICategory[];
  deniedScopes: APICategory[];
  
  // Delegation rules
  maxDelegationDepth: number;
  allowCrossPrincipalDelegation: boolean;
  
  // Approval requirements
  approvalRequired: boolean;
  autoApproveThreshold?: number;
  
  // Priority
  priority: number;
  
  // Status
  enabled: boolean;
  createdAt: number;
  updatedAt: number;
}

/**
 * Cost attribution entry
 */
export interface CostAttribution {
  id: string;
  principalId: string;
  agentId: string;
  periodStart: number;
  periodEnd: number;
  
  // Costs by resource
  costsByResource: Record<ResourceType, {
    quantity: number;
    rateCents: number;
    totalCents: number;
  }>;
  
  // Total
  totalCents: number;
  
  // Billing
  billingStatus: 'pending' | 'invoiced' | 'paid' | 'waived';
  invoiceId?: string;
}

// ============================================================================
// STORAGE
// ============================================================================

const principals = new Map<string, Principal>();
const agents = new Map<string, AgentIdentity>();
const authorizations = new Map<string, SpendingAuthorization>();
const delegations = new Map<string, APIAccessDelegation>();
const consumptionRecords = new Map<string, ConsumptionRecord>();
const alerts = new Map<string, SpendingAlert>();
const delegationChains = new Map<string, DelegationChainEntry[]>();
const policies = new Map<string, AuthorizationPolicy>();
const costAttributions = new Map<string, CostAttribution>();

// Rate limit tracking
const rateLimitCounters = new Map<string, {
  minute: { count: number; resetAt: number };
  hour: { count: number; resetAt: number };
  day: { count: number; resetAt: number };
}>();

// Resource costs (cents per unit)
const RESOURCE_COSTS: Record<ResourceType, number> = {
  api_calls: 0.01,
  tokens: 0.00002,
  compute_seconds: 0.05,
  storage_bytes: 0.00000001,
  bandwidth_bytes: 0.00000001,
  memory_mb_seconds: 0.00001,
  gpu_seconds: 0.10,
  vlm_calls: 0.50,
  llm_calls: 0.02,
  image_generations: 2.00,
  video_seconds: 5.00,
  audio_seconds: 0.10
};

// Default budgets by tier
const DEFAULT_BUDGETS: Record<Principal['tier'], Partial<Record<ResourceType, number>>> = {
  free: {
    api_calls: 100,
    tokens: 10000,
    vlm_calls: 10,
    llm_calls: 50
  },
  basic: {
    api_calls: 1000,
    tokens: 100000,
    vlm_calls: 100,
    llm_calls: 500,
    image_generations: 10
  },
  pro: {
    api_calls: 10000,
    tokens: 1000000,
    vlm_calls: 1000,
    llm_calls: 5000,
    image_generations: 100,
    video_seconds: 60
  },
  enterprise: {
    api_calls: 100000,
    tokens: 10000000,
    vlm_calls: 10000,
    llm_calls: 50000,
    image_generations: 1000,
    video_seconds: 600,
    gpu_seconds: 1000
  },
  internal: {
    api_calls: 1000000,
    tokens: 100000000,
    vlm_calls: 100000,
    llm_calls: 500000,
    image_generations: 10000,
    video_seconds: 3600,
    gpu_seconds: 10000
  }
};

// ============================================================================
// PRINCIPAL MANAGEMENT
// ============================================================================

/**
 * Register a principal (user/service account)
 */
export function registerPrincipal(
  id: string,
  name: string,
  type: Principal['type'],
  tier: Principal['tier'],
  email?: string,
  metadata?: Record<string, unknown>
): Principal {
  const principal: Principal = {
    id,
    name,
    type,
    tier,
    email,
    metadata,
    createdAt: Date.now()
  };
  
  principals.set(id, principal);
  return principal;
}

/**
 * Get principal by ID
 */
export function getPrincipal(id: string): Principal | undefined {
  return principals.get(id);
}

/**
 * List principals by tier
 */
export function listPrincipalsByTier(tier: Principal['tier']): Principal[] {
  return Array.from(principals.values()).filter(p => p.tier === tier);
}

// ============================================================================
// AGENT MANAGEMENT
// ============================================================================

/**
 * Register an agent
 */
export function registerAgent(
  id: string,
  name: string,
  type: AgentIdentity['type'],
  ownerId: string,
  capabilities: string[],
  trustLevel: number = 50
): AgentIdentity | null {
  const owner = principals.get(ownerId);
  if (!owner) return null;
  
  const agent: AgentIdentity = {
    id,
    name,
    type,
    ownerId,
    trustLevel: Math.min(100, Math.max(0, trustLevel)),
    capabilities,
    createdAt: Date.now()
  };
  
  agents.set(id, agent);
  return agent;
}

/**
 * Get agent by ID
 */
export function getAgent(id: string): AgentIdentity | undefined {
  return agents.get(id);
}

/**
 * List agents by owner
 */
export function listAgentsByOwner(ownerId: string): AgentIdentity[] {
  return Array.from(agents.values()).filter(a => a.ownerId === ownerId);
}

/**
 * Update agent trust level
 */
export function updateAgentTrustLevel(
  agentId: string,
  delta: number,
  reason: string
): boolean {
  const agent = agents.get(agentId);
  if (!agent) return false;
  
  const oldLevel = agent.trustLevel;
  agent.trustLevel = Math.min(100, Math.max(0, agent.trustLevel + delta));
  agent.lastActive = Date.now();
  
  return true;
}

// ============================================================================
// SPENDING AUTHORIZATION
// ============================================================================

/**
 * Create spending authorization for an agent
 */
export function createSpendingAuthorization(
  agentId: string,
  principalId: string,
  budgets: Partial<Record<ResourceType, {
    total: number;
    resetPeriodSeconds?: number;
    overdraftAllowed?: boolean;
    overdraftLimit?: number;
  }>>,
  rateLimits: RateLimitConfig,
  validUntil: number,
  purpose?: string,
  requiresApproval: boolean = false
): SpendingAuthorization | null {
  const agent = agents.get(agentId);
  const principal = principals.get(principalId);
  
  if (!agent || !principal) return null;
  
  // Check if principal owns the agent
  if (agent.ownerId !== principalId) {
    // Check for delegation chain
    const chain = getDelegationChain(agentId);
    const hasDelegation = chain.some(e => e.delegatorId === principalId);
    if (!hasDelegation) return null;
  }
  
  // Get default budgets for tier
  const tierDefaults = DEFAULT_BUDGETS[principal.tier];
  
  // Build budget allocations
  const budgetAllocations: BudgetAllocation[] = [];
  
  for (const [resourceType, config] of Object.entries(budgets)) {
    const rt = resourceType as ResourceType;
    const defaultTotal = tierDefaults[rt] || 0;
    
    budgetAllocations.push({
      resourceType: rt,
      totalAllocated: config?.total ?? defaultTotal,
      consumed: 0,
      remaining: config?.total ?? defaultTotal,
      resetPeriodSeconds: config?.resetPeriodSeconds ?? 86400, // Daily reset
      lastReset: Date.now(),
      overdraftAllowed: config?.overdraftAllowed ?? false,
      overdraftLimit: config?.overdraftLimit ?? 0,
      overdraftUsed: 0,
      alertThresholds: [50, 75, 90, 95],
      alertsTriggered: []
    });
  }
  
  const auth: SpendingAuthorization = {
    id: `auth_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    agentId,
    principalId,
    status: requiresApproval ? 'pending_approval' : 'active',
    delegationLevel: agent.ownerId === principalId ? 'primary' : 'secondary',
    budgets: budgetAllocations,
    rateLimits,
    validFrom: Date.now(),
    validUntil,
    requiresApproval,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    purpose,
    tags: []
  };
  
  authorizations.set(auth.id, auth);
  return auth;
}

/**
 * Get authorization by ID
 */
export function getAuthorization(id: string): SpendingAuthorization | undefined {
  return authorizations.get(id);
}

/**
 * Get active authorization for agent
 */
export function getActiveAuthorizationForAgent(agentId: string): SpendingAuthorization | undefined {
  const now = Date.now();
  
  return Array.from(authorizations.values()).find(
    auth => auth.agentId === agentId &&
            auth.status === 'active' &&
            auth.validFrom <= now &&
            auth.validUntil > now
  );
}

/**
 * Approve authorization
 */
export function approveAuthorization(
  authId: string,
  approverPrincipalId: string
): boolean {
  const auth = authorizations.get(authId);
  if (!auth || auth.status !== 'pending_approval') return false;
  
  auth.status = 'active';
  auth.approvedBy = approverPrincipalId;
  auth.approvedAt = Date.now();
  auth.updatedAt = Date.now();
  
  return true;
}

/**
 * Revoke authorization
 */
export function revokeAuthorization(
  authId: string,
  revokedByPrincipalId: string,
  reason: string
): boolean {
  const auth = authorizations.get(authId);
  if (!auth) return false;
  
  auth.status = 'revoked';
  auth.updatedAt = Date.now();
  auth.metadata = {
    ...auth.metadata,
    revokedBy: revokedByPrincipalId,
    revocationReason: reason,
    revokedAt: Date.now()
  };
  
  return true;
}

// ============================================================================
// API ACCESS DELEGATION
// ============================================================================

/**
 * Create API access delegation
 */
export function createAPIDelegation(
  agentId: string,
  principalId: string,
  scopes: APIScope[],
  validUntil: number,
  maxDelegationDepth: number = 1,
  allowFurtherDelegation: boolean = false
): APIAccessDelegation | null {
  const agent = agents.get(agentId);
  const principal = principals.get(principalId);
  
  if (!agent || !principal) return null;
  
  const delegation: APIAccessDelegation = {
    id: `del_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    agentId,
    principalId,
    delegatorId: principalId,
    delegationLevel: agent.ownerId === principalId ? 'primary' : 'secondary',
    scopes,
    maxDelegationDepth,
    allowFurtherDelegation,
    status: 'active',
    validFrom: Date.now(),
    validUntil,
    createdAt: Date.now(),
    totalCalls: 0
  };
  
  delegations.set(delegation.id, delegation);
  
  // Record in delegation chain
  const chain = delegationChains.get(agentId) || [];
  chain.push({
    id: `chain_${Date.now()}`,
    delegatorType: 'principal',
    delegatorId: principalId,
    delegateeAgentId: agentId,
    delegatedAt: Date.now(),
    scope: scopes.map(s => s.category),
    constraints: { maxDelegationDepth, validUntil }
  });
  delegationChains.set(agentId, chain);
  
  return delegation;
}

/**
 * Delegate from one agent to another
 */
export function delegateAgentToAgent(
  sourceAgentId: string,
  targetAgentId: string,
  scopes: APIScope[],
  validUntil: number
): APIAccessDelegation | null {
  const sourceAgent = agents.get(sourceAgentId);
  const targetAgent = agents.get(targetAgentId);
  
  if (!sourceAgent || !targetAgent) return null;
  
  // Check source agent's delegation permissions
  const sourceDelegation = getActiveDelegationForAgent(sourceAgentId);
  if (!sourceDelegation || !sourceDelegation.allowFurtherDelegation) return null;
  
  // Check delegation depth
  const currentDepth = getDelegationDepth(targetAgentId);
  if (currentDepth >= sourceDelegation.maxDelegationDepth) return null;
  
  // Filter scopes to only those allowed by source
  const allowedCategories = sourceDelegation.scopes.map(s => s.category);
  const filteredScopes = scopes.filter(s => allowedCategories.includes(s.category));
  
  if (filteredScopes.length === 0) return null;
  
  const delegation: APIAccessDelegation = {
    id: `del_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    agentId: targetAgentId,
    principalId: sourceDelegation.principalId, // Original principal
    delegatorId: sourceAgentId,
    delegationLevel: 'tertiary',
    scopes: filteredScopes,
    maxDelegationDepth: sourceDelegation.maxDelegationDepth - 1,
    allowFurtherDelegation: sourceDelegation.maxDelegationDepth > 1,
    status: 'active',
    validFrom: Date.now(),
    validUntil: Math.min(validUntil, sourceDelegation.validUntil),
    createdAt: Date.now(),
    totalCalls: 0
  };
  
  delegations.set(delegation.id, delegation);
  
  // Update delegation chain
  const chain = delegationChains.get(targetAgentId) || [];
  chain.push({
    id: `chain_${Date.now()}`,
    delegatorType: 'agent',
    delegatorId: sourceAgentId,
    delegateeAgentId: targetAgentId,
    delegatedAt: Date.now(),
    scope: filteredScopes.map(s => s.category),
    constraints: { maxDelegationDepth: delegation.maxDelegationDepth }
  });
  delegationChains.set(targetAgentId, chain);
  
  return delegation;
}

/**
 * Get active delegation for agent
 */
export function getActiveDelegationForAgent(agentId: string): APIAccessDelegation | undefined {
  const now = Date.now();
  
  return Array.from(delegations.values()).find(
    d => d.agentId === agentId &&
         d.status === 'active' &&
         d.validFrom <= now &&
         d.validUntil > now
  );
}

/**
 * Check if agent has API access
 */
export function checkAPIAccess(
  agentId: string,
  category: APICategory,
  action: string,
  resource?: string
): { allowed: boolean; reason?: string; delegationId?: string } {
  const delegation = getActiveDelegationForAgent(agentId);
  
  if (!delegation) {
    return { allowed: false, reason: 'No active delegation found' };
  }
  
  const matchingScope = delegation.scopes.find(s => {
    if (s.category !== category) return false;
    if (!s.actions.includes(action) && !s.actions.includes('*')) return false;
    if (resource && s.resources.length > 0) {
      if (!s.resources.includes(resource) && !s.resources.includes('*')) {
        return false;
      }
    }
    return true;
  });
  
  if (!matchingScope) {
    return { allowed: false, reason: 'No matching scope found for this action' };
  }
  
  // Check conditions
  if (matchingScope.conditions) {
    const now = Date.now();
    if (matchingScope.conditions.timeWindow) {
      if (now < matchingScope.conditions.timeWindow.start ||
          now > matchingScope.conditions.timeWindow.end) {
        return { allowed: false, reason: 'Outside allowed time window' };
      }
    }
  }
  
  return { allowed: true, delegationId: delegation.id };
}

/**
 * Revoke delegation
 */
export function revokeDelegation(
  delegationId: string,
  revokedByPrincipalId: string,
  reason: string
): boolean {
  const delegation = delegations.get(delegationId);
  if (!delegation) return false;
  
  delegation.status = 'revoked';
  delegation.revokedAt = Date.now();
  delegation.revokedBy = revokedByPrincipalId;
  delegation.revocationReason = reason;
  
  return true;
}

/**
 * Get delegation chain for agent
 */
export function getDelegationChain(agentId: string): DelegationChainEntry[] {
  return delegationChains.get(agentId) || [];
}

/**
 * Get delegation depth
 */
export function getDelegationDepth(agentId: string): number {
  const chain = delegationChains.get(agentId);
  return chain?.length ?? 0;
}

// ============================================================================
// CONSUMPTION TRACKING
// ============================================================================

/**
 * Check if consumption is allowed
 */
export function checkConsumptionAllowed(
  agentId: string,
  resourceType: ResourceType,
  amount: number
): { allowed: boolean; reason?: string; authorizationId?: string } {
  // Get active authorization
  const auth = getActiveAuthorizationForAgent(agentId);
  
  if (!auth) {
    return { allowed: false, reason: 'No active authorization found' };
  }
  
  if (auth.status !== 'active') {
    return { allowed: false, reason: `Authorization status: ${auth.status}` };
  }
  
  // Check rate limits
  const rateLimitResult = checkRateLimit(agentId, auth.rateLimits);
  if (!rateLimitResult.allowed) {
    return { allowed: false, reason: rateLimitResult.reason };
  }
  
  // Find budget for resource
  const budget = auth.budgets.find(b => b.resourceType === resourceType);
  
  if (!budget) {
    return { allowed: false, reason: `No budget allocated for ${resourceType}` };
  }
  
  // Check if budget needs reset
  resetBudgetIfNeeded(budget);
  
  // Check if enough remaining
  if (budget.remaining >= amount) {
    return { allowed: true, authorizationId: auth.id };
  }
  
  // Check overdraft
  if (budget.overdraftAllowed && budget.overdraftUsed + (amount - budget.remaining) <= budget.overdraftLimit) {
    return { allowed: true, authorizationId: auth.id };
  }
  
  return { allowed: false, reason: `Insufficient ${resourceType} budget` };
}

/**
 * Record consumption
 */
export function recordConsumption(
  authorizationId: string,
  agentId: string,
  principalId: string,
  resourceType: ResourceType,
  amount: number,
  context?: {
    apiEndpoint?: string;
    apiCategory?: APICategory;
    requestId?: string;
    durationMs?: number;
    success?: boolean;
    errorMessage?: string;
    metadata?: Record<string, unknown>;
  }
): ConsumptionRecord | null {
  const auth = authorizations.get(authorizationId);
  if (!auth) return null;
  
  // Update budget
  const budget = auth.budgets.find(b => b.resourceType === resourceType);
  if (budget) {
    budget.consumed += amount;
    budget.remaining = Math.max(0, budget.remaining - amount);
    
    // Handle overdraft
    if (budget.remaining < 0 && budget.overdraftAllowed) {
      budget.overdraftUsed = Math.abs(budget.remaining);
      budget.remaining = 0;
    }
    
    // Check thresholds and create alerts
    checkBudgetThresholds(auth, budget);
  }
  
  // Update rate limit counters
  updateRateLimitCounters(agentId);
  
  // Calculate cost
  const costCents = amount * (RESOURCE_COSTS[resourceType] || 0);
  
  // Create record
  const record: ConsumptionRecord = {
    id: `cons_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    authorizationId,
    agentId,
    principalId,
    resourceType,
    amount,
    apiEndpoint: context?.apiEndpoint,
    apiCategory: context?.apiCategory,
    requestId: context?.requestId,
    costCents,
    timestamp: Date.now(),
    durationMs: context?.durationMs,
    success: context?.success ?? true,
    errorMessage: context?.errorMessage,
    metadata: context?.metadata
  };
  
  consumptionRecords.set(record.id, record);
  
  // Update authorization
  auth.lastConsumptionAt = Date.now();
  auth.updatedAt = Date.now();
  
  // Update agent
  const agent = agents.get(agentId);
  if (agent) {
    agent.lastActive = Date.now();
  }
  
  return record;
}

/**
 * Get consumption history
 */
export function getConsumptionHistory(
  agentId?: string,
  principalId?: string,
  resourceType?: ResourceType,
  from?: number,
  to?: number,
  limit: number = 100
): ConsumptionRecord[] {
  let records = Array.from(consumptionRecords.values());
  
  if (agentId) {
    records = records.filter(r => r.agentId === agentId);
  }
  if (principalId) {
    records = records.filter(r => r.principalId === principalId);
  }
  if (resourceType) {
    records = records.filter(r => r.resourceType === resourceType);
  }
  if (from) {
    records = records.filter(r => r.timestamp >= from);
  }
  if (to) {
    records = records.filter(r => r.timestamp <= to);
  }
  
  return records
    .sort((a, b) => b.timestamp - a.timestamp)
    .slice(0, limit);
}

/**
 * Get consumption summary
 */
export function getConsumptionSummary(
  agentId?: string,
  principalId?: string,
  periodStart?: number,
  periodEnd?: number
): Record<ResourceType, { total: number; cost: number }> {
  const records = getConsumptionHistory(
    agentId,
    principalId,
    undefined,
    periodStart,
    periodEnd,
    10000
  );
  
  const summary: Record<string, { total: number; cost: number }> = {};
  
  for (const record of records) {
    if (!summary[record.resourceType]) {
      summary[record.resourceType] = { total: 0, cost: 0 };
    }
    summary[record.resourceType].total += record.amount;
    summary[record.resourceType].cost += record.costCents;
  }
  
  return summary as Record<ResourceType, { total: number; cost: number }>;
}

// ============================================================================
// RATE LIMITING
// ============================================================================

/**
 * Check rate limit
 */
function checkRateLimit(
  agentId: string,
  limits: RateLimitConfig
): { allowed: boolean; reason?: string } {
  const now = Date.now();
  const counters = rateLimitCounters.get(agentId) || {
    minute: { count: 0, resetAt: now + 60000 },
    hour: { count: 0, resetAt: now + 3600000 },
    day: { count: 0, resetAt: now + 86400000 }
  };
  
  // Reset counters if needed
  if (now > counters.minute.resetAt) {
    counters.minute = { count: 0, resetAt: now + 60000 };
  }
  if (now > counters.hour.resetAt) {
    counters.hour = { count: 0, resetAt: now + 3600000 };
  }
  if (now > counters.day.resetAt) {
    counters.day = { count: 0, resetAt: now + 86400000 };
  }
  
  // Check limits
  if (limits.requestsPerMinute && counters.minute.count >= limits.requestsPerMinute) {
    return { allowed: false, reason: `Rate limit exceeded: ${limits.requestsPerMinute} requests per minute` };
  }
  if (limits.requestsPerHour && counters.hour.count >= limits.requestsPerHour) {
    return { allowed: false, reason: `Rate limit exceeded: ${limits.requestsPerHour} requests per hour` };
  }
  if (limits.requestsPerDay && counters.day.count >= limits.requestsPerDay) {
    return { allowed: false, reason: `Rate limit exceeded: ${limits.requestsPerDay} requests per day` };
  }
  
  return { allowed: true };
}

/**
 * Update rate limit counters
 */
function updateRateLimitCounters(agentId: string): void {
  const now = Date.now();
  const counters = rateLimitCounters.get(agentId) || {
    minute: { count: 0, resetAt: now + 60000 },
    hour: { count: 0, resetAt: now + 3600000 },
    day: { count: 0, resetAt: now + 86400000 }
  };
  
  counters.minute.count++;
  counters.hour.count++;
  counters.day.count++;
  
  rateLimitCounters.set(agentId, counters);
}

// ============================================================================
// BUDGET MANAGEMENT
// ============================================================================

/**
 * Reset budget if needed
 */
function resetBudgetIfNeeded(budget: BudgetAllocation): void {
  if (budget.resetPeriodSeconds <= 0) return;
  
  const now = Date.now();
  const nextReset = budget.lastReset + (budget.resetPeriodSeconds * 1000);
  
  if (now >= nextReset) {
    budget.consumed = 0;
    budget.overdraftUsed = 0;
    budget.remaining = budget.totalAllocated;
    budget.lastReset = now;
    budget.alertsTriggered = [];
  }
}

/**
 * Check budget thresholds and create alerts
 */
function checkBudgetThresholds(
  auth: SpendingAuthorization,
  budget: BudgetAllocation
): void {
  if (budget.totalAllocated === 0) return;
  
  const usedPercent = ((budget.consumed / budget.totalAllocated) * 100);
  
  for (const threshold of budget.alertThresholds) {
    const alertKey = `threshold_${threshold}`;
    
    if (usedPercent >= threshold && !budget.alertsTriggered.includes(alertKey)) {
      budget.alertsTriggered.push(alertKey);
      
      // Create alert
      createAlert(
        auth.id,
        auth.agentId,
        auth.principalId,
        'threshold',
        budget.resourceType,
        threshold,
        `${budget.resourceType} usage has reached ${usedPercent.toFixed(1)}% (${threshold}% threshold)`
      );
    }
  }
  
  // Check for exhaustion
  if (budget.remaining <= 0 && budget.overdraftUsed >= budget.overdraftLimit) {
    if (!budget.alertsTriggered.includes('exhausted')) {
      budget.alertsTriggered.push('exhausted');
      
      createAlert(
        auth.id,
        auth.agentId,
        auth.principalId,
        'exhausted',
        budget.resourceType,
        undefined,
        `${budget.resourceType} budget has been exhausted`
      );
      
      // Update authorization status
      const allExhausted = auth.budgets.every(b => b.remaining <= 0);
      if (allExhausted) {
        auth.status = 'exhausted';
      }
    }
  }
}

/**
 * Add budget to authorization
 */
export function addBudgetToAuthorization(
  authId: string,
  resourceType: ResourceType,
  additionalAmount: number
): boolean {
  const auth = authorizations.get(authId);
  if (!auth) return false;
  
  let budget = auth.budgets.find(b => b.resourceType === resourceType);
  
  if (budget) {
    budget.totalAllocated += additionalAmount;
    budget.remaining += additionalAmount;
    
    // Reset exhausted status if applicable
    if (budget.remaining > 0) {
      const exhaustedIndex = budget.alertsTriggered.indexOf('exhausted');
      if (exhaustedIndex > -1) {
        budget.alertsTriggered.splice(exhaustedIndex, 1);
      }
    }
  } else {
    auth.budgets.push({
      resourceType,
      totalAllocated: additionalAmount,
      consumed: 0,
      remaining: additionalAmount,
      resetPeriodSeconds: 86400,
      lastReset: Date.now(),
      overdraftAllowed: false,
      overdraftLimit: 0,
      overdraftUsed: 0,
      alertThresholds: [50, 75, 90, 95],
      alertsTriggered: []
    });
  }
  
  // Reset authorization status if all budgets have remaining
  if (auth.status === 'exhausted') {
    const hasRemaining = auth.budgets.some(b => b.remaining > 0);
    if (hasRemaining) {
      auth.status = 'active';
    }
  }
  
  auth.updatedAt = Date.now();
  
  return true;
}

// ============================================================================
// ALERTS
// ============================================================================

/**
 * Create alert
 */
function createAlert(
  authorizationId: string,
  agentId: string,
  principalId: string,
  alertType: SpendingAlert['alertType'],
  resourceType: ResourceType,
  thresholdPercent: number | undefined,
  message: string
): SpendingAlert {
  const alert: SpendingAlert = {
    id: `alert_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    authorizationId,
    agentId,
    principalId,
    alertType,
    resourceType,
    thresholdPercent,
    message,
    timestamp: Date.now(),
    acknowledged: false
  };
  
  alerts.set(alert.id, alert);
  return alert;
}

/**
 * Get alerts
 */
export function getAlerts(
  principalId?: string,
  agentId?: string,
  acknowledged?: boolean,
  limit: number = 50
): SpendingAlert[] {
  let filtered = Array.from(alerts.values());
  
  if (principalId) {
    filtered = filtered.filter(a => a.principalId === principalId);
  }
  if (agentId) {
    filtered = filtered.filter(a => a.agentId === agentId);
  }
  if (acknowledged !== undefined) {
    filtered = filtered.filter(a => a.acknowledged === acknowledged);
  }
  
  return filtered
    .sort((a, b) => b.timestamp - a.timestamp)
    .slice(0, limit);
}

/**
 * Acknowledge alert
 */
export function acknowledgeAlert(
  alertId: string,
  acknowledgedBy: string
): boolean {
  const alert = alerts.get(alertId);
  if (!alert || alert.acknowledged) return false;
  
  alert.acknowledged = true;
  alert.acknowledgedBy = acknowledgedBy;
  alert.acknowledgedAt = Date.now();
  
  return true;
}

// ============================================================================
// POLICIES
// ============================================================================

/**
 * Create authorization policy
 */
export function createPolicy(
  name: string,
  description: string,
  config: {
    principalTiers?: string[];
    agentTypes?: string[];
    defaultBudgets?: AuthorizationPolicy['defaultBudgets'];
    defaultRateLimits?: RateLimitConfig;
    allowedScopes?: APICategory[];
    deniedScopes?: APICategory[];
    maxDelegationDepth?: number;
    allowCrossPrincipalDelegation?: boolean;
    approvalRequired?: boolean;
    autoApproveThreshold?: number;
    priority?: number;
  }
): AuthorizationPolicy {
  const policy: AuthorizationPolicy = {
    id: `policy_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    name,
    description,
    principalTiers: config.principalTiers,
    agentTypes: config.agentTypes,
    defaultBudgets: config.defaultBudgets || {},
    defaultRateLimits: config.defaultRateLimits || {},
    allowedScopes: config.allowedScopes || [],
    deniedScopes: config.deniedScopes || [],
    maxDelegationDepth: config.maxDelegationDepth ?? 2,
    allowCrossPrincipalDelegation: config.allowCrossPrincipalDelegation ?? false,
    approvalRequired: config.approvalRequired ?? false,
    autoApproveThreshold: config.autoApproveThreshold,
    priority: config.priority ?? 100,
    enabled: true,
    createdAt: Date.now(),
    updatedAt: Date.now()
  };
  
  policies.set(policy.id, policy);
  return policy;
}

/**
 * Get applicable policies
 */
export function getApplicablePolicies(
  principal: Principal,
  agent: AgentIdentity
): AuthorizationPolicy[] {
  return Array.from(policies.values())
    .filter(p => {
      if (!p.enabled) return false;
      if (p.principalTiers && !p.principalTiers.includes(principal.tier)) return false;
      if (p.agentTypes && !p.agentTypes.includes(agent.type)) return false;
      return true;
    })
    .sort((a, b) => b.priority - a.priority);
}

// ============================================================================
// COST ATTRIBUTION
// ============================================================================

/**
 * Generate cost attribution for period
 */
export function generateCostAttribution(
  principalId: string,
  agentId: string | null,
  periodStart: number,
  periodEnd: number
): CostAttribution {
  const records = getConsumptionHistory(
    agentId || undefined,
    principalId,
    undefined,
    periodStart,
    periodEnd,
    100000
  );
  
  const costsByResource: CostAttribution['costsByResource'] = {} as any;
  let totalCents = 0;
  
  for (const record of records) {
    if (!costsByResource[record.resourceType]) {
      costsByResource[record.resourceType] = {
        quantity: 0,
        rateCents: RESOURCE_COSTS[record.resourceType] || 0,
        totalCents: 0
      };
    }
    
    costsByResource[record.resourceType].quantity += record.amount;
    costsByResource[record.resourceType].totalCents += record.costCents;
    totalCents += record.costCents;
  }
  
  const attribution: CostAttribution = {
    id: `attr_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    principalId,
    agentId: agentId || 'all',
    periodStart,
    periodEnd,
    costsByResource,
    totalCents,
    billingStatus: 'pending'
  };
  
  costAttributions.set(attribution.id, attribution);
  return attribution;
}

/**
 * Get cost attributions
 */
export function getCostAttributions(
  principalId?: string,
  billingStatus?: CostAttribution['billingStatus']
): CostAttribution[] {
  let filtered = Array.from(costAttributions.values());
  
  if (principalId) {
    filtered = filtered.filter(a => a.principalId === principalId);
  }
  if (billingStatus) {
    filtered = filtered.filter(a => a.billingStatus === billingStatus);
  }
  
  return filtered.sort((a, b) => b.periodEnd - a.periodEnd);
}

// ============================================================================
// STATUS & STATS
// ============================================================================

/**
 * Get delegation system status
 */
export function getDelegationSystemStatus(): {
  principals: number;
  agents: number;
  activeAuthorizations: number;
  activeDelegations: number;
  totalConsumptionRecords: number;
  pendingAlerts: number;
  policies: number;
} {
  const now = Date.now();
  
  return {
    principals: principals.size,
    agents: agents.size,
    activeAuthorizations: Array.from(authorizations.values())
      .filter(a => a.status === 'active' && a.validUntil > now).length,
    activeDelegations: Array.from(delegations.values())
      .filter(d => d.status === 'active' && d.validUntil > now).length,
    totalConsumptionRecords: consumptionRecords.size,
    pendingAlerts: Array.from(alerts.values()).filter(a => !a.acknowledged).length,
    policies: policies.size
  };
}

/**
 * Get agent spending status
 */
export function getAgentSpendingStatus(agentId: string): {
  agent: AgentIdentity | null;
  authorization: SpendingAuthorization | null;
  delegation: APIAccessDelegation | null;
  budgetStatus: BudgetAllocation[];
  recentConsumption: ConsumptionRecord[];
  activeAlerts: SpendingAlert[];
} | null {
  const agent = agents.get(agentId);
  if (!agent) return null;
  
  const authorization = getActiveAuthorizationForAgent(agentId);
  const delegation = getActiveDelegationForAgent(agentId);
  
  return {
    agent,
    authorization,
    delegation,
    budgetStatus: authorization?.budgets || [],
    recentConsumption: getConsumptionHistory(agentId, undefined, undefined, undefined, undefined, 10),
    activeAlerts: getAlerts(undefined, agentId, false, 10)
  };
}

// ============================================================================
// TESTS
// ============================================================================

/**
 * Run tests
 */
export function runAgentDelegationTests(): {
  passed: boolean;
  tests: { total: number; passed: number; failed: number };
  results: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const results: Array<{ name: string; passed: boolean; error?: string }> = [];
  
  // Test 1: Principal registration
  try {
    const principal = registerPrincipal('test_user_1', 'Test User', 'user', 'pro', 'test@example.com');
    if (!principal || principal.id !== 'test_user_1') {
      throw new Error('Principal registration failed');
    }
    results.push({ name: 'Principal Registration', passed: true });
  } catch (e) {
    results.push({ name: 'Principal Registration', passed: false, error: String(e) });
  }
  
  // Test 2: Agent registration
  try {
    const agent = registerAgent('test_agent_1', 'Test Agent', 'autonomous', 'test_user_1', ['detection', 'analysis'], 75);
    if (!agent || agent.ownerId !== 'test_user_1') {
      throw new Error('Agent registration failed');
    }
    results.push({ name: 'Agent Registration', passed: true });
  } catch (e) {
    results.push({ name: 'Agent Registration', passed: false, error: String(e) });
  }
  
  // Test 3: Spending authorization creation
  try {
    const auth = createSpendingAuthorization(
      'test_agent_1',
      'test_user_1',
      {
        api_calls: { total: 1000 },
        tokens: { total: 100000 }
      },
      { requestsPerMinute: 100, requestsPerHour: 1000 },
      Date.now() + 86400000,
      'Testing authorization'
    );
    
    if (!auth || auth.status !== 'active') {
      throw new Error('Authorization creation failed');
    }
    results.push({ name: 'Spending Authorization', passed: true });
  } catch (e) {
    results.push({ name: 'Spending Authorization', passed: false, error: String(e) });
  }
  
  // Test 4: Consumption check
  try {
    const check = checkConsumptionAllowed('test_agent_1', 'api_calls', 10);
    if (!check.allowed) {
      throw new Error('Consumption check failed: ' + check.reason);
    }
    results.push({ name: 'Consumption Check', passed: true });
  } catch (e) {
    results.push({ name: 'Consumption Check', passed: false, error: String(e) });
  }
  
  // Test 5: API delegation
  try {
    const delegation = createAPIDelegation(
      'test_agent_1',
      'test_user_1',
      [{ category: 'detection', actions: ['analyze', 'detect'], resources: ['*'] }],
      Date.now() + 86400000
    );
    
    if (!delegation || delegation.status !== 'active') {
      throw new Error('Delegation creation failed');
    }
    results.push({ name: 'API Delegation', passed: true });
  } catch (e) {
    results.push({ name: 'API Delegation', passed: false, error: String(e) });
  }
  
  // Test 6: API access check
  try {
    const access = checkAPIAccess('test_agent_1', 'detection', 'analyze');
    if (!access.allowed) {
      throw new Error('API access check failed: ' + access.reason);
    }
    results.push({ name: 'API Access Check', passed: true });
  } catch (e) {
    results.push({ name: 'API Access Check', passed: false, error: String(e) });
  }
  
  // Test 7: Consumption recording
  try {
    const auth = getActiveAuthorizationForAgent('test_agent_1');
    if (!auth) throw new Error('No authorization found');
    
    const record = recordConsumption(
      auth.id,
      'test_agent_1',
      'test_user_1',
      'api_calls',
      10,
      { apiEndpoint: '/api/detect', success: true }
    );
    
    if (!record || record.amount !== 10) {
      throw new Error('Consumption recording failed');
    }
    results.push({ name: 'Consumption Recording', passed: true });
  } catch (e) {
    results.push({ name: 'Consumption Recording', passed: false, error: String(e) });
  }
  
  // Test 8: Budget threshold alert
  try {
    const auth = getActiveAuthorizationForAgent('test_agent_1');
    if (!auth) throw new Error('No authorization found');
    
    // Consume 90% of budget
    for (let i = 0; i < 89; i++) {
      recordConsumption(auth.id, 'test_agent_1', 'test_user_1', 'api_calls', 10);
    }
    
    const alertCheck = getAlerts('test_user_1', 'test_agent_1', false, 10);
    if (alertCheck.length === 0) {
      throw new Error('No alerts generated for threshold');
    }
    results.push({ name: 'Budget Threshold Alert', passed: true });
  } catch (e) {
    results.push({ name: 'Budget Threshold Alert', passed: false, error: String(e) });
  }
  
  // Test 9: Policy creation
  try {
    const policy = createPolicy(
      'Default Pro Policy',
      'Default policy for pro tier users',
      {
        principalTiers: ['pro'],
        defaultRateLimits: { requestsPerMinute: 60, requestsPerHour: 1000 },
        maxDelegationDepth: 3
      }
    );
    
    if (!policy || !policy.enabled) {
      throw new Error('Policy creation failed');
    }
    results.push({ name: 'Policy Creation', passed: true });
  } catch (e) {
    results.push({ name: 'Policy Creation', passed: false, error: String(e) });
  }
  
  // Test 10: Cost attribution
  try {
    const attribution = generateCostAttribution(
      'test_user_1',
      'test_agent_1',
      Date.now() - 86400000,
      Date.now()
    );
    
    if (!attribution || attribution.totalCents <= 0) {
      throw new Error('Cost attribution failed');
    }
    results.push({ name: 'Cost Attribution', passed: true });
  } catch (e) {
    results.push({ name: 'Cost Attribution', passed: false, error: String(e) });
  }
  
  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;
  
  return {
    passed: failed === 0,
    tests: { total: results.length, passed, failed },
    results
  };
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

const agentDelegationModule = {
  // Principal management
  registerPrincipal,
  getPrincipal,
  listPrincipalsByTier,
  
  // Agent management
  registerAgent,
  getAgent,
  listAgentsByOwner,
  updateAgentTrustLevel,
  
  // Spending authorization
  createSpendingAuthorization,
  getAuthorization,
  getActiveAuthorizationForAgent,
  approveAuthorization,
  revokeAuthorization,
  addBudgetToAuthorization,
  
  // API delegation
  createAPIDelegation,
  delegateAgentToAgent,
  getActiveDelegationForAgent,
  checkAPIAccess,
  revokeDelegation,
  getDelegationChain,
  getDelegationDepth,
  
  // Consumption tracking
  checkConsumptionAllowed,
  recordConsumption,
  getConsumptionHistory,
  getConsumptionSummary,
  
  // Alerts
  getAlerts,
  acknowledgeAlert,
  
  // Policies
  createPolicy,
  getApplicablePolicies,
  
  // Cost attribution
  generateCostAttribution,
  getCostAttributions,
  
  // Status
  getDelegationSystemStatus,
  getAgentSpendingStatus,
  
  // Tests
  runAgentDelegationTests,
  
  // Constants
  RESOURCE_COSTS,
  DEFAULT_BUDGETS
};

export default agentDelegationModule;
