/**
 * Plugin Architecture Module
 *
 * Third-party module support with custom frontier modules and extension points.
 * Provides secure plugin loading, lifecycle management, and sandboxing.
 *
 * @module frontier/plugin-architecture
 * @version 8.1.0
 *
 * Capabilities:
 * - Plugin registration
 * - Lifecycle management
 * - Extension points
 * - Plugin sandboxing
 * - Dependency management
 * - Version control
 * - Plugin marketplace
 * - Hot loading
 */

import { generateUUID, sha256Hash, hmacSign } from '../crypto-utils';

// ============================================================================
// TYPES
// ============================================================================

/**
 * Plugin manifest
 */
export interface PluginManifest {
  /** Plugin ID */
  id: string;
  /** Plugin name */
  name: string;
  /** Plugin version */
  version: string;
  /** Description */
  description: string;
  /** Author */
  author: {
    name: string;
    email?: string;
    url?: string;
  };
  /** License */
  license: string;
  /** Homepage */
  homepage?: string;
  /** Repository */
  repository?: string;
  /** Keywords */
  keywords: string[];
  /** Frontier version compatibility */
  frontierVersion: string;
  /** Dependencies */
  dependencies: Array<{
    pluginId: string;
    versionRange: string;
    optional?: boolean;
  }>;
  /** Extension points */
  extensionPoints: string[];
  /** Permissions required */
  permissions: PluginPermission[];
  /** Configuration schema */
  configSchema?: Record<string, {
    type: string;
    description: string;
    default?: unknown;
    required?: boolean;
  }>;
  /** Main entry point */
  main: string;
  /** Icon */
  icon?: string;
  /** Category */
  category: 'detection' | 'security' | 'compliance' | 'integration' | 'utility' | 'custom';
  /** Tags */
  tags: string[];
}

/**
 * Plugin permission
 */
export interface PluginPermission {
  /** Permission type */
  type: 'file_read' | 'file_write' | 'network' | 'database' | 'config' | 'secrets' | 'admin';
  /** Resource pattern */
  resource?: string;
  /** Actions allowed */
  actions: ('read' | 'write' | 'execute')[];
}

/**
 * Plugin instance
 */
export interface PluginInstance {
  /** Instance ID */
  id: string;
  /** Plugin manifest */
  manifest: PluginManifest;
  /** Installation path */
  installPath: string;
  /** Status */
  status: 'installed' | 'active' | 'inactive' | 'error' | 'updating';
  /** Enabled */
  enabled: boolean;
  /** Configuration */
  config: Record<string, unknown>;
  /** Installed timestamp */
  installedAt: number;
  /** Updated timestamp */
  updatedAt: number;
  /** Last activated timestamp */
  lastActivated?: number;
  /** Error message */
  error?: string;
  /** Health status */
  health: {
    status: 'healthy' | 'degraded' | 'unhealthy';
    lastCheck: number;
    errorCount: number;
  };
  /** Metrics */
  metrics: {
    invocations: number;
    errors: number;
    avgExecutionTime: number;
  };
}

/**
 * Extension point
 */
export interface ExtensionPoint {
  /** Extension point ID */
  id: string;
  /** Extension point name */
  name: string;
  /** Description */
  description: string;
  /** Interface type */
  interfaceType: string;
  /** Module that defines this point */
  module: string;
  /** Priority */
  priority: number;
  /** Registered extensions */
  extensions: Extension[];
}

/**
 * Extension
 */
export interface Extension {
  /** Extension ID */
  id: string;
  /** Plugin ID */
  pluginId: string;
  /** Extension point ID */
  extensionPointId: string;
  /** Extension name */
  name: string;
  /** Priority */
  priority: number;
  /** Enabled */
  enabled: boolean;
  /** Handler function name */
  handler: string;
  /** Configuration */
  config?: Record<string, unknown>;
}

/**
 * Plugin hook result
 */
export interface PluginHookResult {
  /** Success */
  success: boolean;
  /** Result data */
  data?: unknown;
  /** Error message */
  error?: string;
  /** Execution time ms */
  executionTimeMs: number;
}

/**
 * Plugin event
 */
export interface PluginEvent {
  /** Event ID */
  id: string;
  /** Event type */
  type: 'install' | 'activate' | 'deactivate' | 'uninstall' | 'update' | 'error';
  /** Plugin ID */
  pluginId: string;
  /** Timestamp */
  timestamp: number;
  /** Details */
  details: Record<string, unknown>;
}

/**
 * Plugin marketplace entry
 */
export interface MarketplaceEntry {
  /** Entry ID */
  id: string;
  /** Plugin manifest */
  manifest: PluginManifest;
  /** Downloads count */
  downloads: number;
  /** Rating */
  rating: number;
  /** Review count */
  reviewCount: number;
  /** Featured */
  featured: boolean;
  /** Verified */
  verified: boolean;
  /** Last updated */
  lastUpdated: number;
  /** Publisher */
  publisher: {
    name: string;
    verified: boolean;
  };
  /** Screenshots */
  screenshots?: string[];
  /** Changelog */
  changelog?: Array<{
    version: string;
    date: number;
    changes: string[];
  }>;
}

/**
 * Plugin sandbox
 */
export interface PluginSandbox {
  /** Sandbox ID */
  id: string;
  /** Plugin ID */
  pluginId: string;
  /** Memory limit MB */
  memoryLimit: number;
  /** CPU limit percentage */
  cpuLimit: number;
  /** Timeout ms */
  timeoutMs: number;
  /** Allowed modules */
  allowedModules: string[];
  /** Allowed APIs */
  allowedAPIs: string[];
  /** Network whitelist */
  networkWhitelist: string[];
  /** File system whitelist */
  fsWhitelist: string[];
  /** Environment variables */
  env: Record<string, string>;
}

/**
 * Plugin dependency graph
 */
export interface DependencyGraph {
  /** Nodes */
  nodes: Array<{
    id: string;
    name: string;
    version: string;
    status: 'resolved' | 'missing' | 'conflict';
  }>;
  /** Edges */
  edges: Array<{
    from: string;
    to: string;
    versionRange: string;
  }>;
  /** Resolution order */
  resolutionOrder: string[];
  /** Conflicts */
  conflicts: Array<{
    pluginId: string;
    reason: string;
  }>;
}

// ============================================================================
// STORAGE
// ============================================================================

const plugins = new Map<string, PluginInstance>();
const extensionPoints = new Map<string, ExtensionPoint>();
const extensions = new Map<string, Extension>();
const events = new Map<string, PluginEvent>();
const sandboxes = new Map<string, PluginSandbox>();
const marketplaceCache = new Map<string, MarketplaceEntry>();

// Plugin handlers (simulated)
const pluginHandlers = new Map<string, Map<string, (...args: unknown[]) => unknown>>();

// Platform secret
const PLATFORM_SECRET = 'plugin_architecture_secret_v1';

// Default sandbox limits
const DEFAULT_SANDBOX_LIMITS = {
  memoryLimit: 256,
  cpuLimit: 50,
  timeoutMs: 30000,
  allowedModules: [],
  allowedAPIs: ['log', 'getConfig'],
  networkWhitelist: [],
  fsWhitelist: []
};

// ============================================================================
// PLUGIN REGISTRATION
// ============================================================================

/**
 * Register plugin
 */
export function registerPlugin(config: {
  manifest: PluginManifest;
  installPath: string;
  config?: Record<string, unknown>;
}): PluginInstance {
  const { manifest } = config;

  // Check if already installed
  const existing = Array.from(plugins.values()).find(p => p.manifest.id === manifest.id);
  if (existing) {
    throw new Error(`Plugin ${manifest.id} is already installed`);
  }

  // Validate manifest
  validateManifest(manifest);

  // Check dependencies
  const depCheck = checkDependencies(manifest);
  if (depCheck.conflicts.length > 0) {
    throw new Error(`Dependency conflicts: ${depCheck.conflicts.map(c => c.reason).join(', ')}`);
  }

  const instance: PluginInstance = {
    id: `plugin_${generateUUID()}`,
    manifest,
    installPath: config.installPath,
    status: 'installed',
    enabled: false,
    config: config.config || {},
    installedAt: Date.now(),
    updatedAt: Date.now(),
    health: {
      status: 'healthy',
      lastCheck: Date.now(),
      errorCount: 0
    },
    metrics: {
      invocations: 0,
      errors: 0,
      avgExecutionTime: 0
    }
  };

  plugins.set(instance.id, instance);

  // Create sandbox
  createSandbox(instance.id, manifest);

  // Register event
  registerEvent({
    type: 'install',
    pluginId: instance.id,
    details: { version: manifest.version, path: config.installPath }
  });

  return instance;
}

/**
 * Validate manifest
 */
function validateManifest(manifest: PluginManifest): void {
  const required = ['id', 'name', 'version', 'description', 'author', 'license', 'main'];
  for (const field of required) {
    if (!(field in manifest)) {
      throw new Error(`Missing required manifest field: ${field}`);
    }
  }

  // Validate version format
  if (!/^\d+\.\d+\.\d+(-[\w.]+)?$/.test(manifest.version)) {
    throw new Error(`Invalid version format: ${manifest.version}`);
  }

  // Validate permissions
  for (const permission of manifest.permissions) {
    if (!['file_read', 'file_write', 'network', 'database', 'config', 'secrets', 'admin'].includes(permission.type)) {
      throw new Error(`Invalid permission type: ${permission.type}`);
    }
  }
}

/**
 * Check dependencies
 */
function checkDependencies(manifest: PluginManifest): DependencyGraph {
  const nodes: DependencyGraph['nodes'] = [];
  const edges: DependencyGraph['edges'] = [];
  const resolutionOrder: string[] = [];
  const conflicts: DependencyGraph['conflicts'] = [];

  // Add current plugin as node
  nodes.push({
    id: manifest.id,
    name: manifest.name,
    version: manifest.version,
    status: 'resolved'
  });

  // Check each dependency
  for (const dep of manifest.dependencies) {
    const installed = Array.from(plugins.values()).find(p => p.manifest.id === dep.pluginId);

    edges.push({
      from: manifest.id,
      to: dep.pluginId,
      versionRange: dep.versionRange
    });

    if (!installed) {
      nodes.push({
        id: dep.pluginId,
        name: dep.pluginId,
        version: 'unknown',
        status: dep.optional ? 'missing' : 'conflict'
      });

      if (!dep.optional) {
        conflicts.push({
          pluginId: dep.pluginId,
          reason: `Missing required dependency: ${dep.pluginId}`
        });
      }
    } else {
      nodes.push({
        id: dep.pluginId,
        name: installed.manifest.name,
        version: installed.manifest.version,
        status: 'resolved'
      });

      // Check version compatibility
      if (!satisfiesVersion(installed.manifest.version, dep.versionRange)) {
        nodes[nodes.length - 1].status = 'conflict';
        conflicts.push({
          pluginId: dep.pluginId,
          reason: `Version mismatch: required ${dep.versionRange}, found ${installed.manifest.version}`
        });
      }

      resolutionOrder.push(dep.pluginId);
    }
  }

  resolutionOrder.push(manifest.id);

  return { nodes, edges, resolutionOrder, conflicts };
}

/**
 * Check if version satisfies range
 */
function satisfiesVersion(version: string, range: string): boolean {
  // Simplified version range check
  if (range === '*') return true;
  if (range.startsWith('^')) {
    const minVersion = range.slice(1);
    return compareVersions(version, minVersion) >= 0;
  }
  if (range.startsWith('~')) {
    const minVersion = range.slice(1);
    return compareVersions(version, minVersion) >= 0;
  }
  return version === range;
}

/**
 * Compare versions
 */
function compareVersions(a: string, b: string): number {
  const partsA = a.split('.').map(Number);
  const partsB = b.split('.').map(Number);

  for (let i = 0; i < Math.max(partsA.length, partsB.length); i++) {
    const partA = partsA[i] || 0;
    const partB = partsB[i] || 0;
    if (partA > partB) return 1;
    if (partA < partB) return -1;
  }
  return 0;
}

/**
 * Get plugin
 */
export function getPlugin(pluginId: string): PluginInstance | undefined {
  return plugins.get(pluginId) || Array.from(plugins.values()).find(p => p.manifest.id === pluginId);
}

/**
 * List plugins
 */
export function listPlugins(filters?: {
  status?: PluginInstance['status'];
  category?: PluginManifest['category'];
  enabled?: boolean;
}): PluginInstance[] {
  let result = Array.from(plugins.values());

  if (filters) {
    if (filters.status) result = result.filter(p => p.status === filters.status);
    if (filters.category) result = result.filter(p => p.manifest.category === filters.category);
    if (filters.enabled !== undefined) result = result.filter(p => p.enabled === filters.enabled);
  }

  return result;
}

/**
 * Uninstall plugin
 */
export function uninstallPlugin(pluginId: string): boolean {
  const plugin = getPlugin(pluginId);
  if (!plugin) return false;

  // Deactivate first if active
  if (plugin.status === 'active') {
    deactivatePlugin(pluginId);
  }

  // Remove extensions
  for (const [extId, ext] of extensions) {
    if (ext.pluginId === plugin.id) {
      extensions.delete(extId);
    }
  }

  // Remove sandbox
  sandboxes.delete(plugin.id);

  // Register event
  registerEvent({
    type: 'uninstall',
    pluginId: plugin.id,
    details: { version: plugin.manifest.version }
  });

  return plugins.delete(plugin.id);
}

// ============================================================================
// PLUGIN LIFECYCLE
// ============================================================================

/**
 * Activate plugin
 */
export function activatePlugin(pluginId: string): PluginInstance | null {
  const plugin = getPlugin(pluginId);
  if (!plugin) return null;

  if (plugin.status === 'active') {
    return plugin;
  }

  try {
    // Initialize plugin handlers (simulated)
    initializePluginHandlers(plugin);

    // Register extension points
    for (const epName of plugin.manifest.extensionPoints) {
      registerExtensionPoint({
        name: epName,
        description: `Extension point from ${plugin.manifest.name}`,
        interfaceType: 'any',
        module: plugin.manifest.id
      });
    }

    plugin.status = 'active';
    plugin.enabled = true;
    plugin.lastActivated = Date.now();
    plugin.updatedAt = Date.now();

    plugins.set(plugin.id, plugin);

    // Register event
    registerEvent({
      type: 'activate',
      pluginId: plugin.id,
      details: { version: plugin.manifest.version }
    });

    return plugin;
  } catch (error) {
    plugin.status = 'error';
    plugin.error = String(error);
    plugin.health.status = 'unhealthy';
    plugins.set(plugin.id, plugin);

    registerEvent({
      type: 'error',
      pluginId: plugin.id,
      details: { error: String(error) }
    });

    return null;
  }
}

/**
 * Deactivate plugin
 */
export function deactivatePlugin(pluginId: string): PluginInstance | null {
  const plugin = getPlugin(pluginId);
  if (!plugin) return null;

  if (plugin.status !== 'active') {
    return plugin;
  }

  try {
    // Cleanup handlers
    pluginHandlers.delete(plugin.id);

    plugin.status = 'inactive';
    plugin.enabled = false;
    plugin.updatedAt = Date.now();

    plugins.set(plugin.id, plugin);

    registerEvent({
      type: 'deactivate',
      pluginId: plugin.id,
      details: { version: plugin.manifest.version }
    });

    return plugin;
  } catch (error) {
    plugin.status = 'error';
    plugin.error = String(error);
    plugins.set(plugin.id, plugin);
    return null;
  }
}

/**
 * Initialize plugin handlers (simulated)
 */
function initializePluginHandlers(plugin: PluginInstance): void {
  const handlers = new Map<string, (...args: unknown[]) => unknown>();

  // Simulate loading handlers from plugin
  handlers.set('init', () => ({ initialized: true }));
  handlers.set('execute', (input: unknown) => ({ result: input }));

  pluginHandlers.set(plugin.id, handlers);
}

/**
 * Update plugin configuration
 */
export function updatePluginConfig(
  pluginId: string,
  config: Record<string, unknown>
): PluginInstance | null {
  const plugin = getPlugin(pluginId);
  if (!plugin) return null;

  plugin.config = { ...plugin.config, ...config };
  plugin.updatedAt = Date.now();

  plugins.set(plugin.id, plugin);
  return plugin;
}

// ============================================================================
// EXTENSION POINTS
// ============================================================================

/**
 * Register extension point
 */
export function registerExtensionPoint(config: {
  name: string;
  description: string;
  interfaceType: string;
  module: string;
  priority?: number;
}): ExtensionPoint {
  const existing = Array.from(extensionPoints.values()).find(ep => ep.name === config.name);
  
  if (existing) {
    return existing;
  }

  const extensionPoint: ExtensionPoint = {
    id: `ep_${generateUUID()}`,
    name: config.name,
    description: config.description,
    interfaceType: config.interfaceType,
    module: config.module,
    priority: config.priority || 0,
    extensions: []
  };

  extensionPoints.set(extensionPoint.id, extensionPoint);
  return extensionPoint;
}

/**
 * Register extension
 */
export function registerExtension(config: {
  pluginId: string;
  extensionPointName: string;
  name: string;
  handler: string;
  priority?: number;
  config?: Record<string, unknown>;
}): Extension | null {
  const plugin = getPlugin(config.pluginId);
  if (!plugin || plugin.status !== 'active') return null;

  const extensionPoint = Array.from(extensionPoints.values()).find(ep => ep.name === config.extensionPointName);
  if (!extensionPoint) return null;

  const extension: Extension = {
    id: `ext_${generateUUID()}`,
    pluginId: plugin.id,
    extensionPointId: extensionPoint.id,
    name: config.name,
    priority: config.priority || 0,
    enabled: true,
    handler: config.handler,
    config: config.config
  };

  extensions.set(extension.id, extension);
  extensionPoint.extensions.push(extension);
  extensionPoints.set(extensionPoint.id, extensionPoint);

  return extension;
}

/**
 * Get extension point
 */
export function getExtensionPoint(name: string): ExtensionPoint | undefined {
  return Array.from(extensionPoints.values()).find(ep => ep.name === name);
}

/**
 * List extension points
 */
export function listExtensionPoints(module?: string): ExtensionPoint[] {
  const all = Array.from(extensionPoints.values());
  return module ? all.filter(ep => ep.module === module) : all;
}

/**
 * Execute extension
 */
export function executeExtension(extensionPointName: string, input: unknown): PluginHookResult[] {
  const extensionPoint = getExtensionPoint(extensionPointName);
  if (!extensionPoint) return [];

  const results: PluginHookResult[] = [];
  const sortedExtensions = [...extensionPoint.extensions]
    .filter(e => e.enabled)
    .sort((a, b) => b.priority - a.priority);

  for (const extension of sortedExtensions) {
    const startTime = Date.now();
    const plugin = plugins.get(extension.pluginId);

    if (!plugin || plugin.status !== 'active') {
      results.push({
        success: false,
        error: 'Plugin not active',
        executionTimeMs: 0
      });
      continue;
    }

    try {
      const handlers = pluginHandlers.get(extension.pluginId);
      const handler = handlers?.get(extension.handler);

      if (!handler) {
        results.push({
          success: false,
          error: `Handler ${extension.handler} not found`,
          executionTimeMs: Date.now() - startTime
        });
        continue;
      }

      // Execute in sandbox
      const result = executeInSandbox(plugin.id, () => handler(input));

      results.push({
        success: true,
        data: result,
        executionTimeMs: Date.now() - startTime
      });

      // Update metrics
      plugin.metrics.invocations++;
      const totalTime = plugin.metrics.avgExecutionTime * (plugin.metrics.invocations - 1) + (Date.now() - startTime);
      plugin.metrics.avgExecutionTime = totalTime / plugin.metrics.invocations;
      plugins.set(plugin.id, plugin);

    } catch (error) {
      results.push({
        success: false,
        error: String(error),
        executionTimeMs: Date.now() - startTime
      });

      plugin.metrics.errors++;
      plugins.set(plugin.id, plugin);
    }
  }

  return results;
}

// ============================================================================
// SANDBOX
// ============================================================================

/**
 * Create sandbox
 */
function createSandbox(pluginId: string, manifest: PluginManifest): PluginSandbox {
  // Calculate limits based on permissions
  const memoryLimit = manifest.permissions.some(p => p.type === 'admin') ? 512 : DEFAULT_SANDBOX_LIMITS.memoryLimit;
  const cpuLimit = manifest.permissions.some(p => p.type === 'admin') ? 80 : DEFAULT_SANDBOX_LIMITS.cpuLimit;

  const allowedAPIs = [...DEFAULT_SANDBOX_LIMITS.allowedAPIs];
  const networkWhitelist: string[] = [];
  const fsWhitelist: string[] = [];

  for (const permission of manifest.permissions) {
    switch (permission.type) {
      case 'network':
        if (permission.actions.includes('execute')) {
          allowedAPIs.push('fetch');
        }
        if (permission.resource) {
          networkWhitelist.push(permission.resource);
        }
        break;
      case 'file_read':
        allowedAPIs.push('fs.read');
        if (permission.resource) fsWhitelist.push(permission.resource);
        break;
      case 'file_write':
        allowedAPIs.push('fs.write');
        if (permission.resource) fsWhitelist.push(permission.resource);
        break;
      case 'database':
        allowedAPIs.push('db.query');
        break;
      case 'config':
        allowedAPIs.push('config.read', 'config.write');
        break;
      case 'secrets':
        allowedAPIs.push('secrets.read');
        break;
      case 'admin':
        allowedAPIs.push('admin.*');
        break;
    }
  }

  const sandbox: PluginSandbox = {
    id: `sandbox_${generateUUID()}`,
    pluginId,
    memoryLimit,
    cpuLimit,
    timeoutMs: DEFAULT_SANDBOX_LIMITS.timeoutMs,
    allowedModules: [],
    allowedAPIs,
    networkWhitelist,
    fsWhitelist,
    env: {}
  };

  sandboxes.set(sandbox.id, sandbox);
  return sandbox;
}

/**
 * Execute in sandbox (simulated)
 */
function executeInSandbox(pluginId: string, fn: () => unknown): unknown {
  const sandbox = Array.from(sandboxes.values()).find(s => s.pluginId === pluginId);
  if (!sandbox) {
    throw new Error('Sandbox not found');
  }

  // In production, this would use vm2 or similar
  // For now, we simulate the execution
  const startTime = Date.now();

  try {
    const result = fn();

    const elapsed = Date.now() - startTime;
    if (elapsed > sandbox.timeoutMs) {
      throw new Error('Execution timeout');
    }

    return result;
  } catch (error) {
    throw error;
  }
}

/**
 * Get sandbox
 */
export function getSandbox(pluginId: string): PluginSandbox | undefined {
  return Array.from(sandboxes.values()).find(s => s.pluginId === pluginId);
}

// ============================================================================
// EVENTS
// ============================================================================

/**
 * Register event
 */
function registerEvent(config: {
  type: PluginEvent['type'];
  pluginId: string;
  details: Record<string, unknown>;
}): PluginEvent {
  const event: PluginEvent = {
    id: `event_${generateUUID()}`,
    type: config.type,
    pluginId: config.pluginId,
    timestamp: Date.now(),
    details: config.details
  };

  events.set(event.id, event);
  return event;
}

/**
 * Get plugin events
 */
export function getPluginEvents(pluginId: string): PluginEvent[] {
  return Array.from(events.values())
    .filter(e => e.pluginId === pluginId)
    .sort((a, b) => b.timestamp - a.timestamp);
}

// ============================================================================
// MARKETPLACE (SIMULATED)
// ============================================================================

/**
 * Search marketplace
 */
export function searchMarketplace(query: string): MarketplaceEntry[] {
  // Simulated marketplace entries
  const allEntries = Array.from(marketplaceCache.values());
  
  if (!query) return allEntries;

  const lowerQuery = query.toLowerCase();
  return allEntries.filter(e => 
    e.manifest.name.toLowerCase().includes(lowerQuery) ||
    e.manifest.description.toLowerCase().includes(lowerQuery) ||
    e.manifest.keywords.some(k => k.toLowerCase().includes(lowerQuery))
  );
}

/**
 * Get marketplace entry
 */
export function getMarketplaceEntry(pluginId: string): MarketplaceEntry | undefined {
  return marketplaceCache.get(pluginId);
}

/**
 * Install from marketplace
 */
export function installFromMarketplace(pluginId: string, config?: Record<string, unknown>): PluginInstance | null {
  const entry = marketplaceCache.get(pluginId);
  if (!entry) return null;

  return registerPlugin({
    manifest: entry.manifest,
    installPath: `/plugins/${pluginId}`,
    config
  });
}

// ============================================================================
// PLUGIN UPDATES
// ============================================================================

/**
 * Check for updates
 */
export function checkForUpdates(pluginId: string): {
  hasUpdate: boolean;
  currentVersion: string;
  latestVersion?: string;
} | null {
  const plugin = getPlugin(pluginId);
  if (!plugin) return null;

  // Simulated update check
  const marketplaceEntry = marketplaceCache.get(plugin.manifest.id);
  
  if (marketplaceEntry && compareVersions(marketplaceEntry.manifest.version, plugin.manifest.version) > 0) {
    return {
      hasUpdate: true,
      currentVersion: plugin.manifest.version,
      latestVersion: marketplaceEntry.manifest.version
    };
  }

  return {
    hasUpdate: false,
    currentVersion: plugin.manifest.version
  };
}

/**
 * Update plugin
 */
export function updatePlugin(pluginId: string): PluginInstance | null {
  const plugin = getPlugin(pluginId);
  if (!plugin) return null;

  const updateCheck = checkForUpdates(pluginId);
  if (!updateCheck?.hasUpdate) return null;

  const marketplaceEntry = marketplaceCache.get(plugin.manifest.id);
  if (!marketplaceEntry) return null;

  // Deactivate before update
  const wasActive = plugin.status === 'active';
  if (wasActive) {
    deactivatePlugin(pluginId);
  }

  plugin.status = 'updating';
  plugins.set(plugin.id, plugin);

  try {
    // Update manifest
    plugin.manifest = marketplaceEntry.manifest;
    plugin.updatedAt = Date.now();
    plugin.status = wasActive ? 'inactive' : 'installed';

    plugins.set(plugin.id, plugin);

    registerEvent({
      type: 'update',
      pluginId: plugin.id,
      details: { 
        fromVersion: updateCheck.currentVersion,
        toVersion: updateCheck.latestVersion 
      }
    });

    // Reactivate if was active
    if (wasActive) {
      return activatePlugin(pluginId);
    }

    return plugin;
  } catch (error) {
    plugin.status = 'error';
    plugin.error = String(error);
    plugins.set(plugin.id, plugin);
    return null;
  }
}

// ============================================================================
// STATISTICS
// ============================================================================

/**
 * Get plugin statistics
 */
export function getPluginStats(): {
  totalPlugins: number;
  activePlugins: number;
  extensionPoints: number;
  extensions: number;
  byCategory: Record<string, number>;
  byStatus: Record<string, number>;
} {
  const allPlugins = Array.from(plugins.values());

  const byCategory: Record<string, number> = {};
  const byStatus: Record<string, number> = {};

  for (const plugin of allPlugins) {
    byCategory[plugin.manifest.category] = (byCategory[plugin.manifest.category] || 0) + 1;
    byStatus[plugin.status] = (byStatus[plugin.status] || 0) + 1;
  }

  return {
    totalPlugins: allPlugins.length,
    activePlugins: allPlugins.filter(p => p.status === 'active').length,
    extensionPoints: extensionPoints.size,
    extensions: extensions.size,
    byCategory,
    byStatus
  };
}

// ============================================================================
// TEST SUITE
// ============================================================================

/**
 * Run plugin architecture tests
 */
export function runPluginArchitectureTests(): {
  passed: boolean;
  tests: { total: number; passed: number; failed: number };
  results: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const results: Array<{ name: string; passed: boolean; error?: string }> = [];

  try {
    // Test 1: Register plugin
    const manifest: PluginManifest = {
      id: 'test-plugin',
      name: 'Test Plugin',
      version: '1.0.0',
      description: 'A test plugin',
      author: { name: 'Test Author' },
      license: 'MIT',
      keywords: ['test'],
      frontierVersion: '8.0.0',
      dependencies: [],
      extensionPoints: ['test.point'],
      permissions: [],
      main: 'index.js',
      category: 'utility',
      tags: ['test']
    };

    const plugin = registerPlugin({
      manifest,
      installPath: '/plugins/test-plugin'
    });
    results.push({ name: 'Register Plugin', passed: !!plugin.id && plugin.status === 'installed' });

    // Test 2: Get plugin
    const retrieved = getPlugin('test-plugin');
    results.push({ name: 'Get Plugin', passed: retrieved?.manifest.id === 'test-plugin' });

    // Test 3: List plugins
    const pluginList = listPlugins();
    results.push({ name: 'List Plugins', passed: pluginList.length === 1 });

    // Test 4: Activate plugin
    const activated = activatePlugin('test-plugin');
    results.push({ name: 'Activate Plugin', passed: activated?.status === 'active' && activated.enabled });

    // Test 5: Register extension point
    const extensionPoint = registerExtensionPoint({
      name: 'custom.point',
      description: 'Custom extension point',
      interfaceType: 'any',
      module: 'test'
    });
    results.push({ name: 'Register Extension Point', passed: !!extensionPoint.id });

    // Test 6: Register extension
    const extension = registerExtension({
      pluginId: 'test-plugin',
      extensionPointName: 'test.point',
      name: 'Test Extension',
      handler: 'execute'
    });
    results.push({ name: 'Register Extension', passed: !!extension?.id });

    // Test 7: Execute extension
    const execResults = executeExtension('test.point', { test: true });
    results.push({ name: 'Execute Extension', passed: execResults.length > 0 });

    // Test 8: Get extension points
    const allExtensionPoints = listExtensionPoints();
    results.push({ name: 'List Extension Points', passed: allExtensionPoints.length >= 1 });

    // Test 9: Update plugin config
    const updated = updatePluginConfig('test-plugin', { setting: 'value' });
    results.push({ name: 'Update Plugin Config', passed: updated?.config.setting === 'value' });

    // Test 10: Deactivate plugin
    const deactivated = deactivatePlugin('test-plugin');
    results.push({ name: 'Deactivate Plugin', passed: deactivated?.status === 'inactive' && !deactivated.enabled });

    // Test 11: Get plugin events
    const pluginEvents = getPluginEvents(plugin.id);
    results.push({ name: 'Get Plugin Events', passed: pluginEvents.length > 0 });

    // Test 12: Get statistics
    const stats = getPluginStats();
    results.push({ name: 'Get Statistics', passed: stats.totalPlugins === 1 });

    // Test 13: Uninstall plugin
    const uninstalled = uninstallPlugin('test-plugin');
    results.push({ name: 'Uninstall Plugin', passed: uninstalled && listPlugins().length === 0 });

  } catch (error) {
    results.push({ name: 'Test Execution', passed: false, error: String(error) });
  }

  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;

  return {
    passed: failed === 0,
    tests: { total: results.length, passed, failed },
    results
  };
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

export default {
  registerPlugin,
  getPlugin,
  listPlugins,
  uninstallPlugin,
  activatePlugin,
  deactivatePlugin,
  updatePluginConfig,
  registerExtensionPoint,
  registerExtension,
  getExtensionPoint,
  listExtensionPoints,
  executeExtension,
  getSandbox,
  getPluginEvents,
  searchMarketplace,
  getMarketplaceEntry,
  installFromMarketplace,
  checkForUpdates,
  updatePlugin,
  getPluginStats,
  runPluginArchitectureTests
};
