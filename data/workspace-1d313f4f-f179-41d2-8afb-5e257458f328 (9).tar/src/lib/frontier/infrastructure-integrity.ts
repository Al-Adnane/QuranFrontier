/**
 * Infrastructure Integrity Monitor Module
 *
 * Weighted Geometric Mean Integrity - ONE critical failure drops entire score.
 * Prevents masking of critical failures through averaging.
 *
 * @module frontier/infrastructure-integrity
 * @version 9.0.0
 *
 * Capabilities:
 * - Weighted geometric mean scoring
 * - Critical failure detection (no masking)
 * - Infrastructure health monitoring
 * - Structural integrity assessment
 * - Compliance verification
 * - Risk propagation analysis
 * - Component dependency mapping
 * - Failure cascade prediction
 * - Real-time alert generation
 * - Regulatory reporting
 */

import { generateUUID, sha256Hash, hmacSign } from '../crypto-utils';

// ============================================================================
// TYPES
// ============================================================================

/**
 * Infrastructure component
 */
export interface InfrastructureComponent {
  /** Component ID */
  id: string;
  /** Component name */
  name: string;
  /** Component type */
  type: 'sensor' | 'equipment' | 'software' | 'network' | 'structural' | 'electrical' | 'mechanical' | 'safety';
  /** Component status */
  status: 'operational' | 'degraded' | 'critical' | 'failed' | 'maintenance' | 'offline';
  /** Health score (0-100) */
  healthScore: number;
  /** Weight in overall system (higher = more critical) */
  weight: number;
  /** Criticality level */
  criticality: 'low' | 'medium' | 'high' | 'critical' | 'lifethreatening';
  /** Last reading */
  lastReading: ComponentReading;
  /** Reading history */
  readingHistory: ComponentReading[];
  /** Dependencies */
  dependencies: string[];
  /** Dependents (components that depend on this) */
  dependents: string[];
  /** Maintenance schedule */
  maintenanceSchedule: MaintenanceSchedule;
  /** Location */
  location: {
    facility: string;
    zone: string;
    position: string;
  };
  /** Metadata */
  metadata: Record<string, unknown>;
  /** Created timestamp */
  createdAt: number;
  /** Last updated */
  updatedAt: number;
}

/**
 * Component reading
 */
export interface ComponentReading {
  /** Reading ID */
  id: string;
  /** Component ID */
  componentId: string;
  /** Reading value */
  value: number;
  /** Unit */
  unit: string;
  /** Normal range */
  normalRange: {
    min: number;
    max: number;
  };
  /** Warning range */
  warningRange: {
    min: number;
    max: number;
  };
  /** Critical range */
  criticalRange: {
    min: number;
    max: number;
  };
  /** Reading status */
  status: 'normal' | 'warning' | 'critical' | 'error';
  /** Confidence */
  confidence: number;
  /** Timestamp */
  timestamp: number;
  /** Sensor metadata */
  sensorMeta?: {
    id: string;
    type: string;
    calibration: number;
  };
}

/**
 * Maintenance schedule
 */
export interface MaintenanceSchedule {
  /** Last maintenance */
  lastMaintenance: number;
  /** Next scheduled maintenance */
  nextMaintenance: number;
  /** Maintenance interval (days) */
  interval: number;
  /** Maintenance history */
  history: MaintenanceRecord[];
}

/**
 * Maintenance record
 */
export interface MaintenanceRecord {
  /** Record ID */
  id: string;
  /** Type */
  type: 'routine' | 'corrective' | 'emergency' | 'predictive';
  /** Description */
  description: string;
  /** Performed by */
  performedBy: string;
  /** Timestamp */
  timestamp: number;
  /** Duration (minutes) */
  duration: number;
  /** Parts replaced */
  partsReplaced: string[];
  /** Notes */
  notes: string;
}

/**
 * Integrity assessment
 */
export interface IntegrityAssessment {
  /** Assessment ID */
  id: string;
  /** Infrastructure ID */
  infrastructureId: string;
  /** Assessment timestamp */
  timestamp: number;
  /** Overall integrity score (geometric mean) */
  overallScore: number;
  /** Arithmetic mean (for comparison) */
  arithmeticMean: number;
  /** Geometric mean vs arithmetic difference */
  maskingDetected: boolean;
  /** Masking severity */
  maskingSeverity: 'none' | 'minor' | 'moderate' | 'severe' | 'critical';
  /** Component scores */
  componentScores: ComponentScore[];
  /** Critical failures */
  criticalFailures: CriticalFailure[];
  /** Risk assessment */
  riskAssessment: RiskAssessment;
  /** Compliance status */
  compliance: ComplianceStatus;
  /** Recommendations */
  recommendations: Recommendation[];
  /** Status */
  status: 'healthy' | 'degraded' | 'critical' | 'failed';
}

/**
 * Component score
 */
export interface ComponentScore {
  /** Component ID */
  componentId: string;
  /** Component name */
  componentName: string;
  /** Health score */
  healthScore: number;
  /** Weight */
  weight: number;
  /** Weighted contribution */
  weightedContribution: number;
  /** Status */
  status: 'normal' | 'warning' | 'critical' | 'failed';
  /** Is critical failure */
  isCriticalFailure: boolean;
  /** Impact on overall score */
  impactScore: number;
}

/**
 * Critical failure
 */
export interface CriticalFailure {
  /** Failure ID */
  id: string;
  /** Component ID */
  componentId: string;
  /** Failure type */
  type: 'sensor_failure' | 'equipment_malfunction' | 'structural_damage' | 'safety_breach' | 'communication_loss' | 'power_failure' | 'overload' | 'leak' | 'contamination';
  /** Severity */
  severity: 'warning' | 'critical' | 'emergency' | 'catastrophic';
  /** Description */
  description: string;
  /** Detection timestamp */
  detectedAt: number;
  /** Affected components */
  affectedComponents: string[];
  /** Cascade risk */
  cascadeRisk: number;
  /** Required action */
  requiredAction: string;
  /** Estimated repair time (minutes) */
  estimatedRepairTime: number;
  /** Status */
  status: 'active' | 'acknowledged' | 'investigating' | 'resolved';
}

/**
 * Risk assessment
 */
export interface RiskAssessment {
  /** Overall risk level */
  riskLevel: 'minimal' | 'low' | 'moderate' | 'high' | 'critical' | 'extreme';
  /** Risk score (0-100) */
  riskScore: number;
  /** Risk factors */
  factors: RiskFactor[];
  /** Cascade probability */
  cascadeProbability: number;
  /** Time to failure estimate */
  timeToFailureEstimate?: number;
  /** Mitigation recommendations */
  mitigations: string[];
}

/**
 * Risk factor
 */
export interface RiskFactor {
  /** Factor name */
  name: string;
  /** Factor category */
  category: 'operational' | 'environmental' | 'structural' | 'safety' | 'compliance';
  /** Factor weight */
  weight: number;
  /** Factor value */
  value: number;
  /** Contribution to risk */
  contribution: number;
  /** Trend */
  trend: 'improving' | 'stable' | 'degrading';
}

/**
 * Compliance status
 */
export interface ComplianceStatus {
  /** Overall compliance */
  compliant: boolean;
  /** Standards checked */
  standards: ComplianceStandard[];
  /** Violations */
  violations: ComplianceViolation[];
  /** Last audit */
  lastAudit: number;
  /** Next audit */
  nextAudit: number;
}

/**
 * Compliance standard
 */
export interface ComplianceStandard {
  /** Standard ID */
  id: string;
  /** Standard name */
  name: string;
  /** Regulatory body */
  regulator: string;
  /** Compliant */
  compliant: boolean;
  /** Score */
  score: number;
  /** Requirements */
  requirements: ComplianceRequirement[];
}

/**
 * Compliance requirement
 */
export interface ComplianceRequirement {
  /** Requirement ID */
  id: string;
  /** Description */
  description: string;
  /** Met */
  met: boolean;
  /** Evidence */
  evidence: string[];
}

/**
 * Compliance violation
 */
export interface ComplianceViolation {
  /** Violation ID */
  id: string;
  /** Standard ID */
  standardId: string;
  /** Severity */
  severity: 'minor' | 'major' | 'critical';
  /** Description */
  description: string;
  /** Detected timestamp */
  detectedAt: number;
  /** Remediation deadline */
  remediationDeadline: number;
  /** Status */
  status: 'open' | 'in_progress' | 'resolved';
}

/**
 * Recommendation
 */
export interface Recommendation {
  /** Recommendation ID */
  id: string;
  /** Priority */
  priority: 'low' | 'medium' | 'high' | 'urgent' | 'immediate';
  /** Type */
  type: 'maintenance' | 'repair' | 'replacement' | 'inspection' | 'calibration' | 'upgrade' | 'procedure';
  /** Description */
  description: string;
  /** Affected components */
  componentIds: string[];
  /** Estimated cost */
  estimatedCost?: number;
  /** Estimated impact */
  estimatedImpact: number;
  /** Deadline */
  deadline: number;
  /** Rationale */
  rationale: string;
}

/**
 * Infrastructure configuration
 */
export interface InfrastructureConfig {
  /** Infrastructure ID */
  id: string;
  /** Name */
  name: string;
  /** Type */
  type: 'bridge' | 'building' | 'dam' | 'nuclear' | 'power_plant' | 'datacenter' | 'water_treatment' | 'airport' | 'port' | 'hospital' | 'manufacturing';
  /** Assessment interval (minutes) */
  assessmentInterval: number;
  /** Failure tolerance */
  failureTolerance: 'none' | 'low' | 'medium' | 'high';
  /** Alert thresholds */
  alertThresholds: {
    warning: number;
    critical: number;
    emergency: number;
  };
  /** Compliance requirements */
  complianceRequirements: string[];
  /** Creation timestamp */
  createdAt: number;
}

/**
 * Infrastructure alert
 */
export interface InfrastructureAlert {
  /** Alert ID */
  id: string;
  /** Infrastructure ID */
  infrastructureId: string;
  /** Component ID */
  componentId: string;
  /** Alert type */
  type: 'threshold_breach' | 'critical_failure' | 'cascade_warning' | 'compliance_violation' | 'maintenance_due' | 'anomaly';
  /** Severity */
  severity: 'info' | 'warning' | 'critical' | 'emergency';
  /** Title */
  title: string;
  /** Description */
  description: string;
  /** Timestamp */
  timestamp: number;
  /** Acknowledged */
  acknowledged: boolean;
  /** Acknowledged by */
  acknowledgedBy?: string;
  /** Resolved */
  resolved: boolean;
  /** Resolution */
  resolution?: string;
}

// ============================================================================
// STORAGE
// ============================================================================

const infrastructures = new Map<string, InfrastructureConfig>();
const components = new Map<string, InfrastructureComponent>();
const assessments = new Map<string, IntegrityAssessment>();
const alerts = new Map<string, InfrastructureAlert>();

// Platform secret
const PLATFORM_SECRET = 'infrastructure_integrity_secret_v1';

// ============================================================================
// INFRASTRUCTURE MANAGEMENT
// ============================================================================

/**
 * Create infrastructure configuration
 */
export function createInfrastructure(config: Omit<InfrastructureConfig, 'createdAt'>): InfrastructureConfig {
  const infrastructure: InfrastructureConfig = {
    ...config,
    createdAt: Date.now()
  };

  infrastructures.set(config.id, infrastructure);
  return infrastructure;
}

/**
 * Get infrastructure
 */
export function getInfrastructure(infrastructureId: string): InfrastructureConfig | undefined {
  return infrastructures.get(infrastructureId);
}

/**
 * List infrastructures
 */
export function listInfrastructures(type?: InfrastructureConfig['type']): InfrastructureConfig[] {
  const all = Array.from(infrastructures.values());
  return type ? all.filter(i => i.type === type) : all;
}

// ============================================================================
// COMPONENT MANAGEMENT
// ============================================================================

/**
 * Register component
 */
export function registerComponent(config: Omit<InfrastructureComponent, 'id' | 'createdAt' | 'updatedAt' | 'readingHistory'>): InfrastructureComponent {
  const id = `component_${generateUUID()}`;
  const now = Date.now();

  const component: InfrastructureComponent = {
    ...config,
    id,
    readingHistory: [],
    createdAt: now,
    updatedAt: now
  };

  components.set(id, component);
  return component;
}

/**
 * Get component
 */
export function getComponent(componentId: string): InfrastructureComponent | undefined {
  return components.get(componentId);
}

/**
 * Update component status
 */
export function updateComponentStatus(componentId: string, status: InfrastructureComponent['status']): InfrastructureComponent | null {
  const component = components.get(componentId);
  if (!component) return null;

  component.status = status;
  component.updatedAt = Date.now();
  components.set(componentId, component);

  return component;
}

/**
 * Add component reading
 */
export function addComponentReading(componentId: string, reading: Omit<ComponentReading, 'id' | 'componentId' | 'timestamp'>): ComponentReading | null {
  const component = components.get(componentId);
  if (!component) return null;

  const fullReading: ComponentReading = {
    ...reading,
    id: `reading_${generateUUID()}`,
    componentId,
    timestamp: Date.now()
  };

  // Update component
  component.lastReading = fullReading;
  component.readingHistory.push(fullReading);

  // Keep only last 100 readings
  if (component.readingHistory.length > 100) {
    component.readingHistory = component.readingHistory.slice(-100);
  }

  // Update health score based on reading
  component.healthScore = calculateHealthScore(fullReading);
  component.status = determineComponentStatus(fullReading, component.criticality);
  component.updatedAt = Date.now();

  components.set(componentId, component);

  // Generate alert if needed
  if (fullReading.status === 'critical') {
    createAlert({
      infrastructureId: component.location.facility,
      componentId,
      type: 'threshold_breach',
      severity: component.criticality === 'lifethreatening' ? 'emergency' : 'critical',
      title: `Critical reading: ${component.name}`,
      description: `Reading value ${reading.value} ${reading.unit} exceeds critical threshold`
    });
  }

  return fullReading;
}

/**
 * Calculate health score from reading
 */
function calculateHealthScore(reading: ComponentReading): number {
  const { value, normalRange, warningRange, criticalRange } = reading;

  if (value >= normalRange.min && value <= normalRange.max) {
    return 100;
  }

  if (value >= warningRange.min && value <= warningRange.max) {
    // Linear interpolation in warning zone
    const warningWidth = warningRange.max - warningRange.min;
    const normalWidth = normalRange.max - normalRange.min;
    const distanceFromNormal = Math.min(
      Math.abs(value - normalRange.min),
      Math.abs(value - normalRange.max)
    );
    const warningDistance = Math.min(
      Math.abs(value - warningRange.min),
      Math.abs(value - warningRange.max)
    );
    return Math.max(50, 100 - (distanceFromNormal / (warningWidth - normalWidth)) * 50);
  }

  if (value >= criticalRange.min && value <= criticalRange.max) {
    return Math.max(0, 50 - (Math.abs(value - warningRange.min) / (criticalRange.max - criticalRange.min)) * 50);
  }

  return 0;
}

/**
 * Determine component status
 */
function determineComponentStatus(reading: ComponentReading, criticality: InfrastructureComponent['criticality']): InfrastructureComponent['status'] {
  if (reading.status === 'critical' || reading.status === 'error') {
    return criticality === 'critical' || criticality === 'lifethreatening' ? 'critical' : 'degraded';
  }
  if (reading.status === 'warning') {
    return 'degraded';
  }
  return 'operational';
}

// ============================================================================
// GEOMETRIC MEAN INTEGRITY CALCULATION
// ============================================================================

/**
 * Calculate weighted geometric mean
 * 
 * Key property: If ANY component has score 0, the entire mean becomes 0.
 * This prevents masking of critical failures.
 * 
 * Formula: (∏(score_i ^ weight_i)) ^ (1 / Σweight_i)
 */
export function calculateWeightedGeometricMean(scores: Array<{ score: number; weight: number }>): number {
  if (scores.length === 0) return 0;

  // Check for any zero scores (critical failure)
  const hasZeroScore = scores.some(s => s.score === 0);
  if (hasZeroScore) return 0;

  // Calculate weighted product
  let weightedProduct = 1;
  let totalWeight = 0;

  for (const { score, weight } of scores) {
    // Ensure score is positive (geometric mean requirement)
    const adjustedScore = Math.max(0.0001, score);
    weightedProduct *= Math.pow(adjustedScore, weight);
    totalWeight += weight;
  }

  if (totalWeight === 0) return 0;

  // Calculate geometric mean
  const geometricMean = Math.pow(weightedProduct, 1 / totalWeight);

  return Math.round(geometricMean * 100) / 100;
}

/**
 * Calculate weighted arithmetic mean (for comparison)
 */
export function calculateWeightedArithmeticMean(scores: Array<{ score: number; weight: number }>): number {
  if (scores.length === 0) return 0;

  let weightedSum = 0;
  let totalWeight = 0;

  for (const { score, weight } of scores) {
    weightedSum += score * weight;
    totalWeight += weight;
  }

  if (totalWeight === 0) return 0;

  return Math.round((weightedSum / totalWeight) * 100) / 100;
}

/**
 * Detect masking (arithmetic mean hiding critical failures)
 */
export function detectMasking(geometricMean: number, arithmeticMean: number): {
  masking: boolean;
  severity: 'none' | 'minor' | 'moderate' | 'severe' | 'critical';
  difference: number;
} {
  const difference = arithmeticMean - geometricMean;
  const percentageDiff = arithmeticMean > 0 ? (difference / arithmeticMean) * 100 : 0;

  let severity: 'none' | 'minor' | 'moderate' | 'severe' | 'critical' = 'none';

  if (geometricMean === 0 && arithmeticMean > 0) {
    severity = 'critical'; // Critical failure masked!
  } else if (percentageDiff >= 50) {
    severity = 'severe';
  } else if (percentageDiff >= 30) {
    severity = 'moderate';
  } else if (percentageDiff >= 10) {
    severity = 'minor';
  }

  return {
    masking: severity !== 'none',
    severity,
    difference: Math.round(difference * 100) / 100
  };
}

// ============================================================================
// INTEGRITY ASSESSMENT
// ============================================================================

/**
 * Run integrity assessment
 */
export function runIntegrityAssessment(infrastructureId: string): IntegrityAssessment {
  const infrastructure = infrastructures.get(infrastructureId);
  if (!infrastructure) {
    throw new Error('Infrastructure not found');
  }

  // Get all components for this infrastructure
  const infrastructureComponents = Array.from(components.values())
    .filter(c => c.location.facility === infrastructureId);

  const id = `assessment_${generateUUID()}`;
  const now = Date.now();

  // Calculate component scores
  const componentScores: ComponentScore[] = infrastructureComponents.map(component => {
    const score: ComponentScore = {
      componentId: component.id,
      componentName: component.name,
      healthScore: component.healthScore,
      weight: component.weight,
      weightedContribution: component.healthScore * component.weight,
      status: component.status === 'operational' ? 'normal' : 
              component.status === 'degraded' ? 'warning' : 
              component.status === 'critical' ? 'critical' : 'failed',
      isCriticalFailure: component.healthScore === 0 && component.criticality === 'lifethreatening',
      impactScore: component.weight * (100 - component.healthScore)
    };
    return score;
  });

  // Calculate geometric mean
  const geometricMean = calculateWeightedGeometricMean(
    componentScores.map(s => ({ score: s.healthScore, weight: s.weight }))
  );

  // Calculate arithmetic mean (for comparison)
  const arithmeticMean = calculateWeightedArithmeticMean(
    componentScores.map(s => ({ score: s.healthScore, weight: s.weight }))
  );

  // Detect masking
  const maskingResult = detectMasking(geometricMean, arithmeticMean);

  // Identify critical failures
  const criticalFailures: CriticalFailure[] = infrastructureComponents
    .filter(c => c.healthScore === 0 || c.status === 'critical')
    .map(component => ({
      id: `failure_${generateUUID()}`,
      componentId: component.id,
      type: determineFailureType(component),
      severity: component.criticality === 'lifethreatening' ? 'catastrophic' : 
                component.criticality === 'critical' ? 'emergency' : 'critical',
      description: `Component ${component.name} in ${component.status} state`,
      detectedAt: now,
      affectedComponents: component.dependents,
      cascadeRisk: calculateCascadeRisk(component, infrastructureComponents),
      requiredAction: determineRequiredAction(component),
      estimatedRepairTime: estimateRepairTime(component),
      status: 'active'
    }));

  // Risk assessment
  const riskAssessment = assessRisk(componentScores, criticalFailures);

  // Compliance check
  const compliance = checkCompliance(infrastructure, componentScores, criticalFailures);

  // Generate recommendations
  const recommendations = generateRecommendations(componentScores, criticalFailures, riskAssessment);

  // Determine overall status
  let status: IntegrityAssessment['status'] = 'healthy';
  if (geometricMean === 0 || criticalFailures.some(f => f.severity === 'catastrophic')) {
    status = 'failed';
  } else if (geometricMean < infrastructure.alertThresholds.critical || 
             criticalFailures.some(f => f.severity === 'emergency')) {
    status = 'critical';
  } else if (geometricMean < infrastructure.alertThresholds.warning || 
             criticalFailures.length > 0) {
    status = 'degraded';
  }

  const assessment: IntegrityAssessment = {
    id,
    infrastructureId,
    timestamp: now,
    overallScore: geometricMean,
    arithmeticMean,
    maskingDetected: maskingResult.masking,
    maskingSeverity: maskingResult.severity,
    componentScores,
    criticalFailures,
    riskAssessment,
    compliance,
    recommendations,
    status
  };

  assessments.set(id, assessment);

  // Generate alerts for critical issues
  if (status === 'critical' || status === 'failed') {
    createAlert({
      infrastructureId,
      componentId: 'system',
      type: 'critical_failure',
      severity: status === 'failed' ? 'emergency' : 'critical',
      title: `Infrastructure integrity ${status}`,
      description: `Overall integrity score: ${geometricMean.toFixed(2)}%. Critical failures: ${criticalFailures.length}`
    });
  }

  return assessment;
}

/**
 * Determine failure type
 */
function determineFailureType(component: InfrastructureComponent): CriticalFailure['type'] {
  const typeMap: Record<InfrastructureComponent['type'], CriticalFailure['type']> = {
    'sensor': 'sensor_failure',
    'equipment': 'equipment_malfunction',
    'software': 'equipment_malfunction',
    'network': 'communication_loss',
    'structural': 'structural_damage',
    'electrical': 'power_failure',
    'mechanical': 'equipment_malfunction',
    'safety': 'safety_breach'
  };
  return typeMap[component.type] || 'equipment_malfunction';
}

/**
 * Calculate cascade risk
 */
function calculateCascadeRisk(component: InfrastructureComponent, allComponents: InfrastructureComponent[]): number {
  if (component.dependents.length === 0) return 0;

  // Calculate how many components would be affected
  const dependentWeight = component.dependents.reduce((sum, depId) => {
    const dep = allComponents.find(c => c.id === depId);
    return sum + (dep?.weight || 0);
  }, 0);

  const totalWeight = allComponents.reduce((sum, c) => sum + c.weight, 0);

  return Math.min(100, (dependentWeight / totalWeight) * 100);
}

/**
 * Determine required action
 */
function determineRequiredAction(component: InfrastructureComponent): string {
  if (component.criticality === 'lifethreatening') {
    return 'IMMEDIATE: Isolate component and evacuate affected areas';
  }
  if (component.criticality === 'critical') {
    return 'URGENT: Initiate emergency procedures and notify stakeholders';
  }
  if (component.status === 'failed') {
    return 'Schedule immediate repair or replacement';
  }
  return 'Schedule maintenance within SLA window';
}

/**
 * Estimate repair time
 */
function estimateRepairTime(component: InfrastructureComponent): number {
  const baseTime: Record<InfrastructureComponent['type'], number> = {
    'sensor': 30,
    'equipment': 240,
    'software': 60,
    'network': 120,
    'structural': 1440,
    'electrical': 480,
    'mechanical': 360,
    'safety': 120
  };

  const criticalityMultiplier: Record<InfrastructureComponent['criticality'], number> = {
    'low': 1,
    'medium': 1.5,
    'high': 2,
    'critical': 3,
    'lifethreatening': 4
  };

  return baseTime[component.type] * criticalityMultiplier[component.criticality];
}

/**
 * Assess risk
 */
function assessRisk(componentScores: ComponentScore[], criticalFailures: CriticalFailure[]): RiskAssessment {
  // Calculate risk score
  const failureRisk = criticalFailures.reduce((sum, f) => {
    const severityScore: Record<string, number> = {
      'warning': 10,
      'critical': 30,
      'emergency': 60,
      'catastrophic': 100
    };
    return sum + (severityScore[f.severity] || 0);
  }, 0);

  const degradationRisk = componentScores
    .filter(s => s.status === 'warning')
    .reduce((sum, s) => sum + (100 - s.healthScore) * (s.weight / 100), 0);

  const riskScore = Math.min(100, failureRisk + degradationRisk);

  // Determine risk level
  let riskLevel: RiskAssessment['riskLevel'] = 'minimal';
  if (riskScore >= 80) riskLevel = 'extreme';
  else if (riskScore >= 60) riskLevel = 'critical';
  else if (riskScore >= 40) riskLevel = 'high';
  else if (riskScore >= 20) riskLevel = 'moderate';
  else if (riskScore >= 10) riskLevel = 'low';

  // Calculate cascade probability
  const cascadeProbability = criticalFailures.length > 0
    ? criticalFailures.reduce((max, f) => Math.max(max, f.cascadeRisk), 0)
    : 0;

  // Generate mitigations
  const mitigations: string[] = [];
  if (criticalFailures.length > 0) {
    mitigations.push('Address all critical failures immediately');
  }
  if (cascadeProbability > 50) {
    mitigations.push('Isolate affected components to prevent cascade');
  }
  if (componentScores.some(s => s.status === 'warning')) {
    mitigations.push('Schedule preventive maintenance for degraded components');
  }

  return {
    riskLevel,
    riskScore,
    factors: [
      {
        name: 'component_failures',
        category: 'operational',
        weight: 0.4,
        value: criticalFailures.length,
        contribution: criticalFailures.length * 10,
        trend: 'stable'
      },
      {
        name: 'cascade_potential',
        category: 'safety',
        weight: 0.3,
        value: cascadeProbability,
        contribution: cascadeProbability * 0.3,
        trend: 'stable'
      },
      {
        name: 'degradation_level',
        category: 'structural',
        weight: 0.3,
        value: degradationRisk,
        contribution: degradationRisk * 0.3,
        trend: 'stable'
      }
    ],
    cascadeProbability,
    mitigations
  };
}

/**
 * Check compliance
 */
function checkCompliance(
  infrastructure: InfrastructureConfig,
  componentScores: ComponentScore[],
  criticalFailures: CriticalFailure[]
): ComplianceStatus {
  const violations: ComplianceViolation[] = [];

  // Check each compliance requirement
  const standards: ComplianceStandard[] = infrastructure.complianceRequirements.map(req => {
    let compliant = true;
    const requirements: ComplianceRequirement[] = [];

    if (req === 'safety') {
      const noCriticalFailures = criticalFailures.filter(f => f.severity === 'catastrophic' || f.severity === 'emergency').length === 0;
      requirements.push({
        id: 'safety_1',
        description: 'No catastrophic or emergency failures',
        met: noCriticalFailures,
        evidence: noCriticalFailures ? ['All components operational'] : []
      });
      if (!noCriticalFailures) {
        compliant = false;
        violations.push({
          id: `violation_${generateUUID()}`,
          standardId: 'safety',
          severity: 'critical',
          description: 'Critical safety failures detected',
          detectedAt: Date.now(),
          remediationDeadline: Date.now() + 3600000, // 1 hour
          status: 'open'
        });
      }
    }

    if (req === 'operational') {
      const operationalScore = componentScores.reduce((sum, s) => sum + s.healthScore, 0) / componentScores.length;
      const meetsThreshold = operationalScore >= 80;
      requirements.push({
        id: 'operational_1',
        description: 'Average health score >= 80%',
        met: meetsThreshold,
        evidence: meetsThreshold ? [`Average score: ${operationalScore.toFixed(2)}%`] : []
      });
      if (!meetsThreshold) {
        compliant = false;
        violations.push({
          id: `violation_${generateUUID()}`,
          standardId: 'operational',
          severity: 'major',
          description: `Operational score below threshold: ${operationalScore.toFixed(2)}%`,
          detectedAt: Date.now(),
          remediationDeadline: Date.now() + 86400000, // 24 hours
          status: 'open'
        });
      }
    }

    return {
      id: req,
      name: req.charAt(0).toUpperCase() + req.slice(1),
      regulator: 'Internal',
      compliant,
      score: compliant ? 100 : 50,
      requirements
    };
  });

  return {
    compliant: violations.filter(v => v.severity === 'critical').length === 0,
    standards,
    violations,
    lastAudit: Date.now(),
    nextAudit: Date.now() + 30 * 24 * 60 * 60 * 1000 // 30 days
  };
}

/**
 * Generate recommendations
 */
function generateRecommendations(
  componentScores: ComponentScore[],
  criticalFailures: CriticalFailure[],
  riskAssessment: RiskAssessment
): Recommendation[] {
  const recommendations: Recommendation[] = [];

  // Critical failure recommendations
  for (const failure of criticalFailures) {
    recommendations.push({
      id: `rec_${generateUUID()}`,
      priority: failure.severity === 'catastrophic' ? 'immediate' :
                failure.severity === 'emergency' ? 'urgent' : 'high',
      type: 'repair',
      description: failure.requiredAction,
      componentIds: [failure.componentId, ...failure.affectedComponents],
      estimatedImpact: failure.cascadeRisk,
      deadline: Date.now() + failure.estimatedRepairTime * 60 * 1000,
      rationale: `Critical failure with ${failure.severity} severity`
    });
  }

  // Degraded component recommendations
  const degradedComponents = componentScores.filter(s => s.status === 'warning');
  for (const component of degradedComponents) {
    recommendations.push({
      id: `rec_${generateUUID()}`,
      priority: 'medium',
      type: 'maintenance',
      description: `Preventive maintenance for ${component.componentName}`,
      componentIds: [component.componentId],
      estimatedImpact: component.impactScore,
      deadline: Date.now() + 7 * 24 * 60 * 60 * 1000, // 7 days
      rationale: `Component health score at ${component.healthScore}%`
    });
  }

  // Risk-based recommendations
  if (riskAssessment.cascadeProbability > 50) {
    recommendations.push({
      id: `rec_${generateUUID()}`,
      priority: 'high',
      type: 'procedure',
      description: 'Implement isolation procedures to prevent cascade failures',
      componentIds: [],
      estimatedImpact: riskAssessment.cascadeProbability,
      deadline: Date.now() + 24 * 60 * 60 * 1000, // 24 hours
      rationale: `Cascade probability at ${riskAssessment.cascadeProbability.toFixed(1)}%`
    });
  }

  return recommendations.sort((a, b) => {
    const priorityOrder: Record<string, number> = {
      'immediate': 0,
      'urgent': 1,
      'high': 2,
      'medium': 3,
      'low': 4
    };
    return priorityOrder[a.priority] - priorityOrder[b.priority];
  });
}

// ============================================================================
// ALERT MANAGEMENT
// ============================================================================

/**
 * Create alert
 */
function createAlert(config: Omit<InfrastructureAlert, 'id' | 'timestamp' | 'acknowledged' | 'resolved'>): InfrastructureAlert {
  const alert: InfrastructureAlert = {
    id: `alert_${generateUUID()}`,
    ...config,
    timestamp: Date.now(),
    acknowledged: false,
    resolved: false
  };

  alerts.set(alert.id, alert);
  return alert;
}

/**
 * Get alert
 */
export function getAlert(alertId: string): InfrastructureAlert | undefined {
  return alerts.get(alertId);
}

/**
 * List alerts
 */
export function listAlerts(infrastructureId?: string, severity?: InfrastructureAlert['severity']): InfrastructureAlert[] {
  let result = Array.from(alerts.values());
  if (infrastructureId) {
    result = result.filter(a => a.infrastructureId === infrastructureId);
  }
  if (severity) {
    result = result.filter(a => a.severity === severity);
  }
  return result;
}

/**
 * Acknowledge alert
 */
export function acknowledgeAlert(alertId: string, acknowledgedBy: string): InfrastructureAlert | null {
  const alert = alerts.get(alertId);
  if (!alert) return null;

  alert.acknowledged = true;
  alert.acknowledgedBy = acknowledgedBy;
  alerts.set(alertId, alert);

  return alert;
}

/**
 * Resolve alert
 */
export function resolveAlert(alertId: string, resolution: string): InfrastructureAlert | null {
  const alert = alerts.get(alertId);
  if (!alert) return null;

  alert.resolved = true;
  alert.resolution = resolution;
  alerts.set(alertId, alert);

  return alert;
}

// ============================================================================
// ASSESSMENT QUERIES
// ============================================================================

/**
 * Get assessment
 */
export function getAssessment(assessmentId: string): IntegrityAssessment | undefined {
  return assessments.get(assessmentId);
}

/**
 * Get latest assessment for infrastructure
 */
export function getLatestAssessment(infrastructureId: string): IntegrityAssessment | undefined {
  const infrastructureAssessments = Array.from(assessments.values())
    .filter(a => a.infrastructureId === infrastructureId)
    .sort((a, b) => b.timestamp - a.timestamp);

  return infrastructureAssessments[0];
}

/**
 * Get assessment history
 */
export function getAssessmentHistory(infrastructureId: string, limit: number = 10): IntegrityAssessment[] {
  return Array.from(assessments.values())
    .filter(a => a.infrastructureId === infrastructureId)
    .sort((a, b) => b.timestamp - a.timestamp)
    .slice(0, limit);
}

// ============================================================================
// STATISTICS
// ============================================================================

/**
 * Get system statistics
 */
export function getSystemStats(): {
  infrastructures: { total: number; byType: Record<string, number> };
  components: { total: number; byStatus: Record<string, number>; byCriticality: Record<string, number> };
  assessments: { total: number; avgScore: number };
  alerts: { total: number; open: number; bySeverity: Record<string, number> };
} {
  const allInfrastructures = Array.from(infrastructures.values());
  const allComponents = Array.from(components.values());
  const allAssessments = Array.from(assessments.values());
  const allAlerts = Array.from(alerts.values());

  return {
    infrastructures: {
      total: allInfrastructures.length,
      byType: allInfrastructures.reduce((acc, i) => {
        acc[i.type] = (acc[i.type] || 0) + 1;
        return acc;
      }, {} as Record<string, number>)
    },
    components: {
      total: allComponents.length,
      byStatus: allComponents.reduce((acc, c) => {
        acc[c.status] = (acc[c.status] || 0) + 1;
        return acc;
      }, {} as Record<string, number>),
      byCriticality: allComponents.reduce((acc, c) => {
        acc[c.criticality] = (acc[c.criticality] || 0) + 1;
        return acc;
      }, {} as Record<string, number>)
    },
    assessments: {
      total: allAssessments.length,
      avgScore: allAssessments.length > 0
        ? allAssessments.reduce((sum, a) => sum + a.overallScore, 0) / allAssessments.length
        : 0
    },
    alerts: {
      total: allAlerts.length,
      open: allAlerts.filter(a => !a.resolved).length,
      bySeverity: allAlerts.reduce((acc, a) => {
        acc[a.severity] = (acc[a.severity] || 0) + 1;
        return acc;
      }, {} as Record<string, number>)
    }
  };
}

// ============================================================================
// TEST SUITE
// ============================================================================

/**
 * Run infrastructure integrity tests
 */
export function runInfrastructureIntegrityTests(): {
  passed: boolean;
  tests: { total: number; passed: number; failed: number };
  results: Array<{ name: string; passed: boolean; error?: string }>;
} {
  const results: Array<{ name: string; passed: boolean; error?: string }> = [];

  try {
    // Test 1: Create infrastructure
    const infrastructure = createInfrastructure({
      id: 'test_infra_1',
      name: 'Test Bridge',
      type: 'bridge',
      assessmentInterval: 60,
      failureTolerance: 'none',
      alertThresholds: { warning: 80, critical: 60, emergency: 40 },
      complianceRequirements: ['safety', 'operational']
    });
    results.push({ name: 'Create Infrastructure', passed: !!infrastructure.id });

    // Test 2: Register component
    const component = registerComponent({
      name: 'Main Cable Sensor',
      type: 'sensor',
      status: 'operational',
      healthScore: 100,
      weight: 10,
      criticality: 'critical',
      lastReading: {
        id: 'init',
        componentId: '',
        value: 50,
        unit: 'kN',
        normalRange: { min: 40, max: 60 },
        warningRange: { min: 30, max: 70 },
        criticalRange: { min: 20, max: 80 },
        status: 'normal',
        confidence: 1,
        timestamp: Date.now()
      },
      dependencies: [],
      dependents: ['component_2'],
      maintenanceSchedule: {
        lastMaintenance: Date.now() - 30 * 24 * 60 * 60 * 1000,
        nextMaintenance: Date.now() + 30 * 24 * 60 * 60 * 1000,
        interval: 60,
        history: []
      },
      location: { facility: 'test_infra_1', zone: 'A', position: '1' },
      metadata: {}
    });
    results.push({ name: 'Register Component', passed: !!component.id });

    // Test 3: Add reading
    const reading = addComponentReading(component.id, {
      value: 55,
      unit: 'kN',
      normalRange: { min: 40, max: 60 },
      warningRange: { min: 30, max: 70 },
      criticalRange: { min: 20, max: 80 },
      status: 'normal',
      confidence: 0.95
    });
    results.push({ name: 'Add Component Reading', passed: !!reading && reading.value === 55 });

    // Test 4: Geometric mean calculation (normal)
    const geometricMean = calculateWeightedGeometricMean([
      { score: 90, weight: 1 },
      { score: 80, weight: 1 },
      { score: 70, weight: 1 }
    ]);
    results.push({ name: 'Geometric Mean Calculation', passed: geometricMean > 0 });

    // Test 5: Geometric mean with zero (critical failure)
    const geometricMeanZero = calculateWeightedGeometricMean([
      { score: 90, weight: 1 },
      { score: 0, weight: 1 },  // Critical failure
      { score: 80, weight: 1 }
    ]);
    results.push({ name: 'Geometric Mean Zero Propagation', passed: geometricMeanZero === 0 });

    // Test 6: Masking detection
    const masking = detectMasking(50, 80);
    results.push({ name: 'Masking Detection', passed: masking.masking === true });

    // Test 7: Run assessment
    const assessment = runIntegrityAssessment('test_infra_1');
    results.push({ name: 'Run Integrity Assessment', passed: !!assessment.id && assessment.overallScore >= 0 });

    // Test 8: Critical failure detection
    // Create a component with zero health
    const criticalComponent = registerComponent({
      name: 'Critical Safety Valve',
      type: 'safety',
      status: 'critical',
      healthScore: 0,
      weight: 50,
      criticality: 'lifethreatening',
      lastReading: {
        id: 'init',
        componentId: '',
        value: 0,
        unit: 'psi',
        normalRange: { min: 100, max: 200 },
        warningRange: { min: 50, max: 250 },
        criticalRange: { min: 0, max: 300 },
        status: 'critical',
        confidence: 1,
        timestamp: Date.now()
      },
      dependencies: [],
      dependents: [],
      maintenanceSchedule: {
        lastMaintenance: Date.now() - 30 * 24 * 60 * 60 * 1000,
        nextMaintenance: Date.now() + 30 * 24 * 60 * 60 * 1000,
        interval: 60,
        history: []
      },
      location: { facility: 'test_infra_1', zone: 'B', position: '2' },
      metadata: {}
    });
    const criticalAssessment = runIntegrityAssessment('test_infra_1');
    results.push({ 
      name: 'Critical Failure Detection', 
      passed: criticalAssessment.overallScore === 0 && criticalAssessment.criticalFailures.length > 0 
    });

    // Test 9: Risk assessment
    results.push({ 
      name: 'Risk Assessment', 
      passed: criticalAssessment.riskAssessment.riskLevel !== 'minimal' 
    });

    // Test 10: Recommendations generation
    results.push({ 
      name: 'Recommendations Generation', 
      passed: criticalAssessment.recommendations.length > 0 
    });

    // Test 11: Alert generation
    const testAlerts = listAlerts('test_infra_1');
    results.push({ name: 'Alert Generation', passed: testAlerts.length > 0 });

    // Test 12: System stats
    const stats = getSystemStats();
    results.push({ name: 'System Stats', passed: stats.infrastructures.total > 0 });

  } catch (error) {
    results.push({ name: 'Test execution', passed: false, error: String(error) });
  }

  const passed = results.filter(r => r.passed).length;
  const failed = results.filter(r => !r.passed).length;

  return {
    passed: failed === 0,
    tests: { total: results.length, passed, failed },
    results
  };
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

const infrastructureIntegrity = {
  // Infrastructure management
  createInfrastructure,
  getInfrastructure,
  listInfrastructures,
  // Component management
  registerComponent,
  getComponent,
  updateComponentStatus,
  addComponentReading,
  // Calculations
  calculateWeightedGeometricMean,
  calculateWeightedArithmeticMean,
  detectMasking,
  // Assessment
  runIntegrityAssessment,
  getAssessment,
  getLatestAssessment,
  getAssessmentHistory,
  // Alerts
  getAlert,
  listAlerts,
  acknowledgeAlert,
  resolveAlert,
  // Stats
  getSystemStats,
  // Tests
  runInfrastructureIntegrityTests
};

export default infrastructureIntegrity;
