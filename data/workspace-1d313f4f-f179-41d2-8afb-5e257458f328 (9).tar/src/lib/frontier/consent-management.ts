/**
 * Consent Management Hub - GDPR/CCPA data consent orchestration
 * @module frontier/consent-management
 */
export type ConsentStatus = 'granted' | 'denied' | 'pending' | 'withdrawn' | 'expired';
export type PurposeType = 'processing' | 'marketing' | 'analytics' | 'third_party' | 'ai_training';

export interface ConsentRecord {
  id: string; subjectId: string; jurisdiction: 'GDPR' | 'CCPA' | 'OTHER';
  purposes: ConsentPurpose[]; preferences: Record<string, boolean>;
  history: ConsentEvent[]; expiresAt?: number;
  createdAt: number; updatedAt: number;
}

export interface ConsentPurpose {
  id: string; type: PurposeType; description: string;
  status: ConsentStatus; grantedAt?: number; withdrawnAt?: number;
  lawfulBasis: 'consent' | 'legitimate_interest' | 'contract' | 'legal_obligation';
}

export interface ConsentEvent {
  id: string; type: 'grant' | 'withdraw' | 'update' | 'expire';
  purpose?: string; timestamp: number; details: string;
}

export interface DataSubjectRequest {
  id: string; subjectId: string; type: 'access' | 'erasure' | 'portability' | 'rectification';
  status: 'pending' | 'processing' | 'completed' | 'denied';
  requestedAt: number; completedAt?: number; response?: string;
}

const consents = new Map<string, ConsentRecord>();
const requests = new Map<string, DataSubjectRequest>();

export function createConsentRecord(config: {subjectId: string; jurisdiction: 'GDPR' | 'CCPA' | 'OTHER'}): ConsentRecord {
  const record: ConsentRecord = {
    id: `consent_${Date.now()}_${Math.random().toString(36).substr(2,6)}`,
    ...config, purposes: [], preferences: {}, history: [],
    createdAt: Date.now(), updatedAt: Date.now()
  };
  consents.set(record.id, record);
  return record;
}

export function grantConsent(consentId: string, purpose: PurposeType, description: string, lawfulBasis: ConsentPurpose['lawfulBasis']): ConsentPurpose | null {
  const record = consents.get(consentId);
  if (!record) return null;
  
  const cp: ConsentPurpose = {
    id: `purp_${Date.now()}`, type: purpose, description,
    status: 'granted', grantedAt: Date.now(),
    lawfulBasis
  };
  record.purposes.push(cp);
  record.preferences[purpose] = true;
  record.history.push({id: `evt_${Date.now()}`, type: 'grant', purpose, timestamp: Date.now(), details: description});
  record.updatedAt = Date.now();
  return cp;
}

export function withdrawConsent(consentId: string, purpose: PurposeType): boolean {
  const record = consents.get(consentId);
  if (!record) return false;
  
  const cp = record.purposes.find(p => p.type === purpose && p.status === 'granted');
  if (!cp) return false;
  
  cp.status = 'withdrawn';
  cp.withdrawnAt = Date.now();
  record.preferences[purpose] = false;
  record.history.push({id: `evt_${Date.now()}`, type: 'withdraw', purpose, timestamp: Date.now(), details: `Withdrawn: ${purpose}`});
  record.updatedAt = Date.now();
  return true;
}

export function checkConsent(consentId: string, purpose: PurposeType): {granted: boolean; record?: ConsentPurpose} {
  const record = consents.get(consentId);
  if (!record) return {granted: false};
  const cp = record.purposes.find(p => p.type === purpose);
  return {granted: cp?.status === 'granted', record: cp};
}

export function createDataSubjectRequest(subjectId: string, type: DataSubjectRequest['type']): DataSubjectRequest {
  const req: DataSubjectRequest = {
    id: `dsr_${Date.now()}`, subjectId, type,
    status: 'pending', requestedAt: Date.now()
  };
  requests.set(req.id, req);
  return req;
}

export function processDSR(requestId: string, status: 'completed' | 'denied', response?: string): boolean {
  const req = requests.get(requestId);
  if (!req || req.status !== 'pending') return false;
  req.status = 'processing';
  req.status = status;
  req.completedAt = Date.now();
  req.response = response;
  return true;
}

export function getConsentRecord(id: string): ConsentRecord | undefined { return consents.get(id); }
export function getDSR(id: string): DataSubjectRequest | undefined { return requests.get(id); }

export function getConsentStats() {
  const all = Array.from(consents.values());
  return {
    total: consents.size, dsrRequests: requests.size,
    active: all.filter(c => c.purposes.some(p => p.status === 'granted')).length,
    byJurisdiction: {GDPR: all.filter(c=>c.jurisdiction==='GDPR').length, CCPA: all.filter(c=>c.jurisdiction==='CCPA').length}
  };
}

export function runConsentManagementTests() {
  const results: {name: string; passed: boolean}[] = [];
  try { const c = createConsentRecord({subjectId:'user1',jurisdiction:'GDPR'}); results.push({name:'Create',passed:!!c.id}); } catch { results.push({name:'Create',passed:false}); }
  try { const c = Array.from(consents.values())[0]; grantConsent(c.id,'marketing','Email marketing','consent'); results.push({name:'Grant',passed:c.purposes.length>0}); } catch { results.push({name:'Grant',passed:false}); }
  try { const c = Array.from(consents.values())[0]; withdrawConsent(c.id,'marketing'); results.push({name:'Withdraw',passed:c.purposes[0].status==='withdrawn'}); } catch { results.push({name:'Withdraw',passed:false}); }
  try { const r = createDataSubjectRequest('user1','access'); results.push({name:'DSR',passed:!!r.id}); } catch { results.push({name:'DSR',passed:false}); }
  try { const s = getConsentStats(); results.push({name:'Stats',passed:s.total>0}); } catch { results.push({name:'Stats',passed:false}); }
  const passed = results.filter(r=>r.passed).length, failed = results.filter(r=>!r.passed).length;
  return {passed: failed===0, tests:{total:results.length,passed,failed}, results};
}

export default {createConsentRecord,grantConsent,withdrawConsent,checkConsent,createDataSubjectRequest,processDSR,getConsentRecord,getDSR,getConsentStats,runConsentManagementTests};
