/**
 * Kasbah Guard - API Credit Management System
 * 
 * Tracks and manages API credits for protected applications.
 * Provides quota management, usage tracking, and cost attribution.
 * 
 * @module kasbah-guard/credits
 * @version 1.0.0
 */

// ============================================================================
// TYPES
// ============================================================================

/**
 * Credit Account
 */
export interface CreditAccount {
  id: string;
  name: string;
  type: 'global' | 'app' | 'user' | 'team';
  balance: number;
  used: number;
  limit: number;
  resetPeriod: 'daily' | 'weekly' | 'monthly' | 'never';
  lastReset: number;
  nextReset: number;
  costPerUnit: number;
  currency: string;
  createdAt: number;
  updatedAt: number;
}

/**
 * Credit Transaction
 */
export interface CreditTransaction {
  id: string;
  accountId: string;
  type: 'debit' | 'credit' | 'refund' | 'adjustment';
  amount: number;
  balance: number;
  description: string;
  source: string;
  metadata?: Record<string, unknown>;
  timestamp: number;
}

/**
 * Credit Alert
 */
export interface CreditAlert {
  id: string;
  accountId: string;
  type: 'low_balance' | 'exhausted' | 'over_budget' | 'unusual_usage';
  threshold: number;
  currentValue: number;
  message: string;
  timestamp: number;
  acknowledged: boolean;
}

/**
 * Credit Budget
 */
export interface CreditBudget {
  id: string;
  accountId: string;
  allocated: number;
  spent: number;
  remaining: number;
  period: 'daily' | 'weekly' | 'monthly';
  categories: Record<string, number>;
  alerts: CreditAlert[];
}

/**
 * Usage Record
 */
export interface UsageRecord {
  id: string;
  appId: string;
  endpoint: string;
  method: string;
  credits: number;
  responseTime: number;
  statusCode: number;
  timestamp: number;
}

/**
 * Credit Pricing Tier
 */
export interface PricingTier {
  name: string;
  minCredits: number;
  maxCredits: number;
  pricePerCredit: number;
  features: string[];
}

// ============================================================================
// STORAGE
// ============================================================================

const accounts = new Map<string, CreditAccount>();
const transactions = new Map<string, CreditTransaction[]>();
const budgets = new Map<string, CreditBudget>();
const alerts = new Map<string, CreditAlert[]>();
const usageRecords: UsageRecord[] = [];

// Pricing tiers
const PRICING_TIERS: PricingTier[] = [
  { name: 'Free', minCredits: 0, maxCredits: 1000, pricePerCredit: 0, features: ['Basic protection', 'Community support'] },
  { name: 'Starter', minCredits: 1000, maxCredits: 10000, pricePerCredit: 0.001, features: ['Standard protection', 'Email support', 'API access'] },
  { name: 'Pro', minCredits: 10000, maxCredits: 100000, pricePerCredit: 0.0008, features: ['Advanced protection', 'Priority support', 'Custom policies'] },
  { name: 'Enterprise', minCredits: 100000, maxCredits: Infinity, pricePerCredit: 0.0005, features: ['Full protection', '24/7 support', 'Custom integration', 'SLA'] }
];

// Default global account
let globalAccount: CreditAccount = {
  id: 'global',
  name: 'Global Credits',
  type: 'global',
  balance: 100000,
  used: 0,
  limit: 100000,
  resetPeriod: 'monthly',
  lastReset: Date.now(),
  nextReset: Date.now() + 30 * 24 * 60 * 60 * 1000,
  costPerUnit: 0.001,
  currency: 'USD',
  createdAt: Date.now(),
  updatedAt: Date.now()
};

accounts.set('global', globalAccount);

// ============================================================================
// ACCOUNT MANAGEMENT
// ============================================================================

/**
 * Create a credit account
 */
export function createAccount(config: {
  name: string;
  type: CreditAccount['type'];
  limit: number;
  resetPeriod: CreditAccount['resetPeriod'];
}): CreditAccount {
  const id = `acc_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  
  const account: CreditAccount = {
    id,
    name: config.name,
    type: config.type,
    balance: config.limit,
    used: 0,
    limit: config.limit,
    resetPeriod: config.resetPeriod,
    lastReset: Date.now(),
    nextReset: calculateNextReset(config.resetPeriod),
    costPerUnit: 0.001,
    currency: 'USD',
    createdAt: Date.now(),
    updatedAt: Date.now()
  };
  
  accounts.set(id, account);
  transactions.set(id, []);
  
  return account;
}

/**
 * Get account by ID
 */
export function getAccount(id: string): CreditAccount | undefined {
  return accounts.get(id);
}

/**
 * Get all accounts
 */
export function listAccounts(type?: CreditAccount['type']): CreditAccount[] {
  const all = Array.from(accounts.values());
  return type ? all.filter(a => a.type === type) : all;
}

/**
 * Update account
 */
export function updateAccount(id: string, updates: Partial<CreditAccount>): CreditAccount | undefined {
  const account = accounts.get(id);
  if (!account) return undefined;
  
  Object.assign(account, updates, { updatedAt: Date.now() });
  accounts.set(id, account);
  
  return account;
}

/**
 * Delete account
 */
export function deleteAccount(id: string): boolean {
  if (id === 'global') return false;
  return accounts.delete(id);
}

// ============================================================================
// CREDIT OPERATIONS
// ============================================================================

/**
 * Check if enough credits available
 */
export function hasCredits(accountId: string, amount: number): boolean {
  const account = accounts.get(accountId);
  if (!account) return false;
  return account.balance >= amount;
}

/**
 * Debit credits from an account
 */
export function debitCredits(
  accountId: string,
  amount: number,
  description: string,
  source: string,
  metadata?: Record<string, unknown>
): { success: boolean; transaction?: CreditTransaction; error?: string } {
  const account = accounts.get(accountId);
  if (!account) {
    return { success: false, error: 'Account not found' };
  }
  
  if (account.balance < amount) {
    // Emit low credit alert
    emitAlert(accountId, 'exhausted', 0, account.balance, 'Credit exhausted');
    return { success: false, error: 'Insufficient credits' };
  }
  
  // Perform debit
  account.balance -= amount;
  account.used += amount;
  account.updatedAt = Date.now();
  accounts.set(accountId, account);
  
  // Record transaction
  const transaction: CreditTransaction = {
    id: `txn_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    accountId,
    type: 'debit',
    amount,
    balance: account.balance,
    description,
    source,
    metadata,
    timestamp: Date.now()
  };
  
  const accountTransactions = transactions.get(accountId) || [];
  accountTransactions.push(transaction);
  transactions.set(accountId, accountTransactions);
  
  // Check for low balance alert
  if (account.balance < account.limit * 0.2) {
    emitAlert(accountId, 'low_balance', account.limit * 0.2, account.balance, 
      `Low credit balance: ${account.balance} remaining`);
  }
  
  return { success: true, transaction };
}

/**
 * Add credits (credit)
 */
export function addCredits(
  accountId: string,
  amount: number,
  description: string,
  source: string
): CreditTransaction | undefined {
  const account = accounts.get(accountId);
  if (!account) return undefined;
  
  account.balance += amount;
  account.updatedAt = Date.now();
  accounts.set(accountId, account);
  
  const transaction: CreditTransaction = {
    id: `txn_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    accountId,
    type: 'credit',
    amount,
    balance: account.balance,
    description,
    source,
    timestamp: Date.now()
  };
  
  const accountTransactions = transactions.get(accountId) || [];
  accountTransactions.push(transaction);
  transactions.set(accountId, accountTransactions);
  
  return transaction;
}

/**
 * Refund credits
 */
export function refundCredits(
  accountId: string,
  amount: number,
  reason: string,
  originalTransactionId: string
): CreditTransaction | undefined {
  const account = accounts.get(accountId);
  if (!account) return undefined;
  
  account.balance += amount;
  account.used -= amount;
  account.updatedAt = Date.now();
  accounts.set(accountId, account);
  
  const transaction: CreditTransaction = {
    id: `txn_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    accountId,
    type: 'refund',
    amount,
    balance: account.balance,
    description: `Refund: ${reason}`,
    source: originalTransactionId,
    timestamp: Date.now()
  };
  
  const accountTransactions = transactions.get(accountId) || [];
  accountTransactions.push(transaction);
  transactions.set(accountId, accountTransactions);
  
  return transaction;
}

// ============================================================================
// USAGE TRACKING
// ============================================================================

/**
 * Record API usage
 */
export function recordUsage(record: Omit<UsageRecord, 'id' | 'timestamp'>): UsageRecord {
  const fullRecord: UsageRecord = {
    ...record,
    id: `use_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    timestamp: Date.now()
  };
  
  usageRecords.push(fullRecord);
  
  // Keep only last 10000 records
  if (usageRecords.length > 10000) {
    usageRecords.shift();
  }
  
  // Debit credits from account
  const appId = record.appId || 'global';
  debitCredits(appId, record.credits, `API: ${record.method} ${record.endpoint}`, 'api_usage', {
    endpoint: record.endpoint,
    method: record.method,
    responseTime: record.responseTime,
    statusCode: record.statusCode
  });
  
  return fullRecord;
}

/**
 * Get usage history
 */
export function getUsageHistory(
  accountId?: string,
  timeRange?: { start: number; end: number }
): UsageRecord[] {
  let records = usageRecords;
  
  if (accountId) {
    records = records.filter(r => r.appId === accountId);
  }
  
  if (timeRange) {
    records = records.filter(r => r.timestamp >= timeRange.start && r.timestamp <= timeRange.end);
  }
  
  return records;
}

/**
 * Get usage statistics
 */
export function getUsageStats(accountId?: string, period: string = '24h'): {
  totalCredits: number;
  totalRequests: number;
  avgCreditsPerRequest: number;
  avgResponseTime: number;
  errorRate: number;
  topEndpoints: Array<{ endpoint: string; count: number; credits: number }>;
} {
  const now = Date.now();
  const periodMs: Record<string, number> = {
    '1h': 60 * 60 * 1000,
    '6h': 6 * 60 * 60 * 1000,
    '24h': 24 * 60 * 60 * 1000,
    '7d': 7 * 24 * 60 * 60 * 1000,
    '30d': 30 * 24 * 60 * 60 * 1000
  };
  
  const cutoff = now - (periodMs[period] || periodMs['24h']);
  let records = usageRecords.filter(r => r.timestamp >= cutoff);
  
  if (accountId) {
    records = records.filter(r => r.appId === accountId);
  }
  
  const totalCredits = records.reduce((sum, r) => sum + r.credits, 0);
  const totalRequests = records.length;
  const errors = records.filter(r => r.statusCode >= 400).length;
  
  const endpointCounts = new Map<string, { count: number; credits: number }>();
  for (const r of records) {
    const key = `${r.method} ${r.endpoint}`;
    const existing = endpointCounts.get(key) || { count: 0, credits: 0 };
    existing.count++;
    existing.credits += r.credits;
    endpointCounts.set(key, existing);
  }
  
  const topEndpoints = Array.from(endpointCounts.entries())
    .map(([endpoint, data]) => ({ endpoint, ...data }))
    .sort((a, b) => b.credits - a.credits)
    .slice(0, 10);
  
  return {
    totalCredits,
    totalRequests,
    avgCreditsPerRequest: totalRequests > 0 ? totalCredits / totalRequests : 0,
    avgResponseTime: totalRequests > 0 ? records.reduce((sum, r) => sum + r.responseTime, 0) / totalRequests : 0,
    errorRate: totalRequests > 0 ? errors / totalRequests : 0,
    topEndpoints
  };
}

// ============================================================================
// BUDGET MANAGEMENT
// ============================================================================

/**
 * Set credit limit
 */
export function setCreditLimit(accountId: string, limit: number, period?: string): void {
  const account = accounts.get(accountId);
  if (!account) return;
  
  account.limit = limit;
  if (period) {
    account.resetPeriod = period as CreditAccount['resetPeriod'];
    account.nextReset = calculateNextReset(account.resetPeriod);
  }
  
  accounts.set(accountId, account);
}

/**
 * Create budget
 */
export function createBudget(accountId: string, allocated: number, period: CreditBudget['period']): CreditBudget {
  const budget: CreditBudget = {
    id: `budget_${Date.now()}`,
    accountId,
    allocated,
    spent: 0,
    remaining: allocated,
    period,
    categories: {},
    alerts: []
  };
  
  budgets.set(budget.id, budget);
  return budget;
}

/**
 * Get budget
 */
export function getBudget(budgetId: string): CreditBudget | undefined {
  return budgets.get(budgetId);
}

/**
 * Update budget spending
 */
export function updateBudgetSpending(budgetId: string, amount: number, category?: string): void {
  const budget = budgets.get(budgetId);
  if (!budget) return;
  
  budget.spent += amount;
  budget.remaining = budget.allocated - budget.spent;
  
  if (category) {
    budget.categories[category] = (budget.categories[category] || 0) + amount;
  }
  
  // Check for over budget
  if (budget.remaining < 0) {
    const alert: CreditAlert = {
      id: `alert_${Date.now()}`,
      accountId: budget.accountId,
      type: 'over_budget',
      threshold: budget.allocated,
      currentValue: budget.spent,
      message: `Budget exceeded: spent ${budget.spent} of ${budget.allocated}`,
      timestamp: Date.now(),
      acknowledged: false
    };
    budget.alerts.push(alert);
  }
  
  budgets.set(budgetId, budget);
}

// ============================================================================
// ALERTS
// ============================================================================

/**
 * Emit credit alert
 */
function emitAlert(
  accountId: string,
  type: CreditAlert['type'],
  threshold: number,
  currentValue: number,
  message: string
): CreditAlert {
  const alert: CreditAlert = {
    id: `alert_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    accountId,
    type,
    threshold,
    currentValue,
    message,
    timestamp: Date.now(),
    acknowledged: false
  };
  
  const accountAlerts = alerts.get(accountId) || [];
  accountAlerts.push(alert);
  alerts.set(accountId, accountAlerts);
  
  return alert;
}

/**
 * Get alerts
 */
export function getAlerts(accountId?: string): CreditAlert[] {
  if (accountId) {
    return alerts.get(accountId) || [];
  }
  
  return Array.from(alerts.values()).flat();
}

/**
 * Acknowledge alert
 */
export function acknowledgeAlert(alertId: string): boolean {
  for (const [accountId, accountAlerts] of alerts.entries()) {
    const alert = accountAlerts.find(a => a.id === alertId);
    if (alert) {
      alert.acknowledged = true;
      alerts.set(accountId, accountAlerts);
      return true;
    }
  }
  return false;
}

// ============================================================================
// TRANSACTIONS
// ============================================================================

/**
 * Get transaction history
 */
export function getTransactionHistory(accountId: string, limit: number = 100): CreditTransaction[] {
  const accountTransactions = transactions.get(accountId) || [];
  return accountTransactions.slice(-limit);
}

// ============================================================================
// RESET & MAINTENANCE
// ============================================================================

/**
 * Calculate next reset time
 */
function calculateNextReset(period: CreditAccount['resetPeriod']): number {
  const now = new Date();
  
  switch (period) {
    case 'daily':
      return new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1).getTime();
    case 'weekly':
      const daysUntilSunday = 7 - now.getDay();
      return new Date(now.getFullYear(), now.getMonth(), now.getDate() + daysUntilSunday).getTime();
    case 'monthly':
      return new Date(now.getFullYear(), now.getMonth() + 1, 1).getTime();
    default:
      return Infinity;
  }
}

/**
 * Check and perform resets
 */
export function performResets(): void {
  const now = Date.now();
  
  for (const [id, account] of accounts.entries()) {
    if (account.nextReset <= now) {
      account.balance = account.limit;
      account.used = 0;
      account.lastReset = now;
      account.nextReset = calculateNextReset(account.resetPeriod);
      account.updatedAt = now;
      accounts.set(id, account);
    }
  }
}

// ============================================================================
// STATUS & REPORTING
// ============================================================================

/**
 * Get credit status
 */
export function getCreditStatus(accountId?: string): {
  global: CreditAccount;
  apps: CreditAccount[];
  totalUsed: number;
  totalRemaining: number;
  usageStats: ReturnType<typeof getUsageStats>;
  recentAlerts: CreditAlert[];
} {
  const appAccounts = listAccounts('app');
  
  return {
    global: accounts.get('global')!,
    apps: accountId ? appAccounts.filter(a => a.id === accountId) : appAccounts,
    totalUsed: Array.from(accounts.values()).reduce((sum, a) => sum + a.used, 0),
    totalRemaining: Array.from(accounts.values()).reduce((sum, a) => sum + a.balance, 0),
    usageStats: getUsageStats(accountId),
    recentAlerts: getAlerts().slice(-10)
  };
}

/**
 * Get pricing tiers
 */
export function getPricingTiers(): PricingTier[] {
  return PRICING_TIERS;
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

const creditSystem = {
  // Account management
  createAccount,
  getAccount,
  listAccounts,
  updateAccount,
  deleteAccount,
  
  // Credit operations
  hasCredits,
  debitCredits,
  addCredits,
  refundCredits,
  
  // Usage tracking
  recordUsage,
  getUsageHistory,
  getUsageStats,
  
  // Budget management
  setCreditLimit,
  createBudget,
  getBudget,
  updateBudgetSpending,
  
  // Alerts
  getAlerts,
  acknowledgeAlert,
  
  // Transactions
  getTransactionHistory,
  
  // Maintenance
  performResets,
  
  // Status
  getCreditStatus,
  getPricingTiers
};

export default creditSystem;
