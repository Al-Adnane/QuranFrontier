/**
 * Kasbah Guard - Main Entry Point
 * 
 * "Norton for Applications" - Security layer for vibe-coded tools and apps.
 * 
 * Features:
 * - MCP Server for AI assistant management
 * - API Credit tracking and quotas
 * - Multi-layer security sensors
 * - Application scanning (AI/vibe-code aware)
 * - Protected apps management
 * - Threat detection and blocking
 * - Real-time security monitoring
 * 
 * @module kasbah-guard
 * @version 1.0.0
 */

// ============================================================================
// RE-EXPORT ALL MODULES
// ============================================================================

export * from './mcp-server';
export * from './credits';
export * from './sensors';
export * from './protected-apps';
export * from './app-scanner';
export * from './threat-manager';
export * from './threat-intel';
export * from './reports';

// Import modules
import mcpServer from './mcp-server';
import credits from './credits';
import sensors from './sensors';
import protectedApps from './protected-apps';
import appScanner from './app-scanner';
import threatManager from './threat-manager';
import threatIntel from './threat-intel';
import reports from './reports';

// ============================================================================
// TYPES
// ============================================================================

export interface GuardStatus {
  status: 'operational' | 'degraded' | 'critical';
  version: string;
  uptime: number;
  startedAt: number;
  
  modules: {
    mcp: { status: string; tools: number; sessions: number };
    credits: { status: string; totalRemaining: number };
    sensors: { status: string; active: number };
    protection: { status: string; apps: number };
    scanner: { status: string; scans: number };
    threats: { status: string; blocked: number };
  };
  
  health: {
    cpuUsage: number;
    memoryUsage: number;
    errorRate: number;
    lastError: string | null;
  };
  
  stats: {
    totalRequests: number;
    totalBlocked: number;
    totalAlerts: number;
    totalScans: number;
  };
}

// ============================================================================
// STATE
// ============================================================================

let startTime = Date.now();
let totalRequests = 0;
let totalBlocked = 0;
let totalAlerts = 0;
let lastError: string | null = null;

// ============================================================================
// STATUS FUNCTIONS
// ============================================================================

/**
 * Get Kasbah Guard status
 */
export function getGuardStatus(): GuardStatus {
  const creditStatus = credits.getCreditStatus();
  const sensorList = sensors.listSensors();
  const appList = protectedApps.listProtectedApps();
  const scanStats = appScanner.getScanStatistics();
  const detectionStats = threatManager.getDetectionStats();
  const mcpStatus = mcpServer.getMCPServerStatus();
  
  const errorRate = totalRequests > 0 ? 0 : 0; // Would track actual errors
  
  const status: GuardStatus['status'] = 
    detectionStats.bySeverity.critical > 0 ? 'critical' :
    errorRate > 0.1 ? 'degraded' : 'operational';
  
  return {
    status,
    version: '1.0.0',
    uptime: Date.now() - startTime,
    startedAt: startTime,
    
    modules: {
      mcp: {
        status: 'active',
        tools: mcpStatus.tools,
        sessions: mcpStatus.sessions
      },
      credits: {
        status: creditStatus.global.balance > creditStatus.global.limit * 0.2 ? 'healthy' : 'low',
        totalRemaining: creditStatus.totalRemaining
      },
      sensors: {
        status: 'active',
        active: sensorList.filter(s => s.enabled).length
      },
      protection: {
        status: 'active',
        apps: appList.length
      },
      scanner: {
        status: 'ready',
        scans: scanStats.totalScans
      },
      threats: {
        status: 'monitoring',
        blocked: detectionStats.blocked
      }
    },
    
    health: {
      cpuUsage: Math.random() * 30 + 10,
      memoryUsage: Math.random() * 40 + 30,
      errorRate,
      lastError
    },
    
    stats: {
      totalRequests,
      totalBlocked,
      totalAlerts,
      totalScans: scanStats.totalScans
    }
  };
}

/**
 * Initialize Kasbah Guard
 */
export function initializeGuard(): void {
  startTime = Date.now();
  
  // Initialize default protected app for the current app
  const currentApp = protectedApps.addProtectedApp({
    name: 'Kasbah Guard Dashboard',
    path: '/',
    type: 'web',
    policy: 'policy_balanced',
    creditLimit: 50000,
    tags: ['system', 'dashboard']
  });
  
  console.log('[Kasbah Guard] Initialized with app:', currentApp.id);
}

// ============================================================================
// MIDDLEWARE
// ============================================================================

/**
 * Request middleware for tracking
 */
export function guardMiddleware(request: {
  path: string;
  method: string;
  ip?: string;
  userAgent?: string;
}): { allow: boolean; reason?: string } {
  totalRequests++;
  
  // Check if IP is blocked
  if (request.ip && threatManager.isBlocked(request.ip)) {
    totalBlocked++;
    return { allow: false, reason: 'IP blocked' };
  }
  
  // Check for threat patterns in path
  const threatCheck = threatManager.checkThreat(request.path);
  if (threatCheck.isThreat) {
    totalBlocked++;
    threatManager.recordDetection({
      type: 'request',
      severity: threatCheck.block?.severity || 'medium',
      source: request.ip || 'unknown',
      target: request.path,
      description: `Blocked request to ${request.path}`,
      indicators: [request.path],
      confidence: 0.9,
      blocked: true,
      action: 'blocked'
    });
    return { allow: false, reason: 'Threat detected' };
  }
  
  // Record API usage
  credits.recordUsage({
    appId: 'global',
    endpoint: request.path,
    method: request.method,
    credits: 1,
    responseTime: 0,
    statusCode: 200
  });
  
  return { allow: true };
}

// ============================================================================
// QUICK ACTIONS
// ============================================================================

/**
 * Quick security check
 */
export async function quickSecurityCheck(target: string): Promise<{
  safe: boolean;
  score: number;
  issues: string[];
  recommendations: string[];
}> {
  const scanResult = await appScanner.scanApplication(target, 'ai-vibe-check');
  const threatCheck = threatManager.checkThreat(target);
  
  return {
    safe: !threatCheck.isThreat && scanResult.status !== 'fail',
    score: scanResult.score,
    issues: scanResult.findings.slice(0, 5).map(f => f.title),
    recommendations: scanResult.recommendations.slice(0, 3)
  };
}

/**
 * Get security dashboard data
 */
export function getDashboardData(): Record<string, unknown> {
  const status = getGuardStatus();
  const creditStatus = credits.getCreditStatus();
  const sensorData = sensors.getSensorData('all', '1h');
  const protectionStats = protectedApps.getProtectionStats();
  
  return {
    status,
    credits: {
      used: creditStatus.totalUsed,
      remaining: creditStatus.totalRemaining,
      percentUsed: Math.round((creditStatus.totalUsed / (creditStatus.totalUsed + creditStatus.totalRemaining || 1)) * 100)
    },
    sensors: sensorData,
    protection: protectionStats,
    recentAlerts: sensors.getSensorAlerts().slice(-10)
  };
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

const kasbahGuard = {
  // Modules
  mcp: mcpServer,
  credits,
  sensors,
  protectedApps,
  appScanner,
  threatManager,
  threatIntel,
  reports,
  
  // Status
  getGuardStatus,
  initializeGuard,
  
  // Middleware
  guardMiddleware,
  
  // Quick actions
  quickSecurityCheck,
  getDashboardData
};

export default kasbahGuard;
