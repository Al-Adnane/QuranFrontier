/**
 * Kasbah Guard - Threat Manager
 * 
 * Manages threat detection, blocking, and quarantine.
 * 
 * @module kasbah-guard/threat-manager
 * @version 1.0.0
 */

// ============================================================================
// TYPES
// ============================================================================

export interface ThreatBlock {
  id: string;
  type: 'ip' | 'domain' | 'hash' | 'process' | 'api' | 'pattern' | 'user';
  value: string;
  reason: string;
  source: 'manual' | 'auto' | 'intelligence' | 'community';
  severity: 'low' | 'medium' | 'high' | 'critical';
  duration: number; // 0 = permanent
  createdAt: number;
  expiresAt: number | null;
  hits: number;
  lastHit: number | null;
  enabled: boolean;
}

export interface ThreatDetection {
  id: string;
  type: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  source: string;
  target: string;
  description: string;
  indicators: string[];
  confidence: number;
  timestamp: number;
  blocked: boolean;
  action: string;
}

export interface QuarantineItem {
  id: string;
  type: 'file' | 'process' | 'connection' | 'request';
  value: string;
  reason: string;
  originalPath?: string;
  quarantinedAt: number;
  expiresAt: number | null;
  released: boolean;
  releasedAt?: number;
  releasedBy?: string;
}

// ============================================================================
// STORAGE
// ============================================================================

const blocklist = new Map<string, ThreatBlock>();
const detections: ThreatDetection[] = [];
const quarantine = new Map<string, QuarantineItem>();

// Pre-populate with known threats
const KNOWN_THREATS = [
  { type: 'ip' as const, value: '185.220.101.1', reason: 'Known Tor exit node', severity: 'medium' as const },
  { type: 'ip' as const, value: '45.33.32.156', reason: 'Known malicious IP', severity: 'high' as const },
  { type: 'domain' as const, value: 'malware-test.com', reason: 'Known malware domain', severity: 'critical' as const },
  { type: 'pattern' as const, value: 'UNION SELECT', reason: 'SQL injection pattern', severity: 'critical' as const },
  { type: 'pattern' as const, value: '<script>', reason: 'XSS pattern', severity: 'high' as const },
  { type: 'pattern' as const, value: '../', reason: 'Path traversal pattern', severity: 'high' as const },
];

KNOWN_THREATS.forEach(threat => {
  const id = `block_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  blocklist.set(threat.value, {
    id,
    type: threat.type,
    value: threat.value,
    reason: threat.reason,
    source: 'intelligence',
    severity: threat.severity,
    duration: 0,
    createdAt: Date.now(),
    expiresAt: null,
    hits: 0,
    lastHit: null,
    enabled: true
  });
});

// ============================================================================
// BLOCK OPERATIONS
// ============================================================================

export function blockThreat(config: {
  type: ThreatBlock['type'];
  value: string;
  reason: string;
  duration?: number;
  severity?: ThreatBlock['severity'];
  source?: ThreatBlock['source'];
}): ThreatBlock {
  const id = `block_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  const duration = config.duration || 0;
  
  const block: ThreatBlock = {
    id,
    type: config.type,
    value: config.value,
    reason: config.reason,
    source: config.source || 'manual',
    severity: config.severity || 'medium',
    duration,
    createdAt: Date.now(),
    expiresAt: duration > 0 ? Date.now() + duration * 1000 : null,
    hits: 0,
    lastHit: null,
    enabled: true
  };
  
  blocklist.set(config.value, block);
  return block;
}

export function unblockThreat(value: string): boolean {
  return blocklist.delete(value);
}

export function isBlocked(value: string): boolean {
  const block = blocklist.get(value);
  if (!block || !block.enabled) return false;
  
  // Check expiration
  if (block.expiresAt && block.expiresAt < Date.now()) {
    block.enabled = false;
    return false;
  }
  
  // Update hit count
  block.hits++;
  block.lastHit = Date.now();
  
  return true;
}

export function getBlock(value: string): ThreatBlock | undefined {
  return blocklist.get(value);
}

export function listBlocks(type?: ThreatBlock['type']): ThreatBlock[] {
  const blocks = Array.from(blocklist.values());
  return type ? blocks.filter(b => b.type === type) : blocks;
}

// ============================================================================
// DETECTION OPERATIONS
// ============================================================================

export function recordDetection(detection: Omit<ThreatDetection, 'id' | 'timestamp'>): ThreatDetection {
  const full: ThreatDetection = {
    ...detection,
    id: `det_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    timestamp: Date.now()
  };
  
  detections.push(full);
  
  // Keep only last 1000 detections
  if (detections.length > 1000) {
    detections.shift();
  }
  
  return full;
}

export function getDetections(limit: number = 100): ThreatDetection[] {
  return detections.slice(-limit);
}

export function getDetectionStats(): {
  total: number;
  blocked: number;
  bySeverity: Record<string, number>;
  byType: Record<string, number>;
} {
  return {
    total: detections.length,
    blocked: detections.filter(d => d.blocked).length,
    bySeverity: {
      critical: detections.filter(d => d.severity === 'critical').length,
      high: detections.filter(d => d.severity === 'high').length,
      medium: detections.filter(d => d.severity === 'medium').length,
      low: detections.filter(d => d.severity === 'low').length
    },
    byType: detections.reduce((acc, d) => {
      acc[d.type] = (acc[d.type] || 0) + 1;
      return acc;
    }, {} as Record<string, number>)
  };
}

// ============================================================================
// QUARANTINE OPERATIONS
// ============================================================================

export function quarantineItem(config: {
  type: QuarantineItem['type'];
  value: string;
  reason: string;
  originalPath?: string;
  duration?: number;
}): QuarantineItem {
  const id = `quar_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  const duration = config.duration || 86400; // Default 24 hours
  
  const item: QuarantineItem = {
    id,
    type: config.type,
    value: config.value,
    reason: config.reason,
    originalPath: config.originalPath,
    quarantinedAt: Date.now(),
    expiresAt: Date.now() + duration * 1000,
    released: false
  };
  
  quarantine.set(id, item);
  return item;
}

export function releaseFromQuarantine(id: string, releasedBy?: string): boolean {
  const item = quarantine.get(id);
  if (!item || item.released) return false;
  
  item.released = true;
  item.releasedAt = Date.now();
  item.releasedBy = releasedBy;
  
  return true;
}

export function getQuarantineItems(): QuarantineItem[] {
  return Array.from(quarantine.values()).filter(i => !i.released);
}

export function getQuarantineItem(id: string): QuarantineItem | undefined {
  return quarantine.get(id);
}

// ============================================================================
// THREAT CHECKING
// ============================================================================

export function checkThreat(value: string, type?: ThreatBlock['type']): {
  isThreat: boolean;
  block?: ThreatBlock;
  action: 'allow' | 'block' | 'quarantine' | 'alert';
} {
  // Direct block check
  if (isBlocked(value)) {
    const block = getBlock(value);
    return { isThreat: true, block, action: 'block' };
  }
  
  // Pattern matching for common threats
  const patterns = [
    { pattern: /union.*select/i, type: 'sql_injection', severity: 'critical' as const },
    { pattern: /<script/i, type: 'xss', severity: 'high' as const },
    { pattern: /\.\.[\/\\]/i, type: 'path_traversal', severity: 'high' as const },
    { pattern: /eval\s*\(/i, type: 'code_injection', severity: 'critical' as const },
    { pattern: /exec\s*\(/i, type: 'command_injection', severity: 'critical' as const },
  ];
  
  for (const { pattern, type: threatType, severity } of patterns) {
    if (pattern.test(value)) {
      const detection = recordDetection({
        type: threatType,
        severity,
        source: 'pattern_match',
        target: value.substring(0, 100),
        description: `Pattern matched: ${threatType}`,
        indicators: [pattern.source],
        confidence: 0.8,
        blocked: true,
        action: 'blocked'
      });
      
      return { isThreat: true, action: 'block' };
    }
  }
  
  return { isThreat: false, action: 'allow' };
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

const threatManager = {
  blockThreat,
  unblockThreat,
  isBlocked,
  getBlock,
  listBlocks,
  recordDetection,
  getDetections,
  getDetectionStats,
  quarantineItem,
  releaseFromQuarantine,
  getQuarantineItems,
  getQuarantineItem,
  checkThreat
};

export default threatManager;
