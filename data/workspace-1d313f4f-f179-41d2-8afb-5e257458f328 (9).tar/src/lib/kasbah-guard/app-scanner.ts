/**
 * Kasbah Guard - Application Security Scanner
 * 
 * Scans applications for security vulnerabilities, especially targeting
 * common issues in AI/vibe-coded applications.
 * 
 * @module kasbah-guard/app-scanner
 * @version 1.0.0
 */

// ============================================================================
// TYPES
// ============================================================================

/**
 * Scan Configuration
 */
export interface ScanConfig {
  target: string;
  type: 'quick' | 'standard' | 'deep' | 'ai-vibe-check';
  categories?: string[];
  excludePaths?: string[];
  includeNodeModules?: boolean;
  checkDependencies?: boolean;
  checkSecrets?: boolean;
  checkPermissions?: boolean;
  checkInjection?: boolean;
}

/**
 * Scan Result
 */
export interface ScanResult {
  id: string;
  target: string;
  type: string;
  timestamp: number;
  duration: number;
  score: number;
  grade: 'A' | 'B' | 'C' | 'D' | 'F';
  status: 'pass' | 'warn' | 'fail';
  
  summary: {
    totalChecks: number;
    passed: number;
    warnings: number;
    failed: number;
    critical: number;
    high: number;
    medium: number;
    low: number;
  };
  
  findings: ScanFinding[];
  
  recommendations: string[];
  
  aiVibeSpecific?: {
    aiGeneratedPatterns: number;
    hardcodedSecrets: number;
    insecureDefaults: number;
    missingValidation: number;
    logicFlaws: number;
  };
}

/**
 * Scan Finding
 */
export interface ScanFinding {
  id: string;
  category: string;
  severity: 'critical' | 'high' | 'medium' | 'low' | 'info';
  title: string;
  description: string;
  location: {
    file?: string;
    line?: number;
    code?: string;
  };
  impact: string;
  remediation: string;
  references?: string[];
  cwe?: string;
  owasp?: string;
}

/**
 * Scan Category
 */
export interface ScanCategory {
  id: string;
  name: string;
  description: string;
  checks: ScanCheck[];
}

/**
 * Scan Check
 */
export interface ScanCheck {
  id: string;
  name: string;
  description: string;
  severity: ScanFinding['severity'];
  patterns?: RegExp[];
  files?: string[];
  check: (target: string, config: ScanConfig) => Promise<ScanFinding | null>;
}

// ============================================================================
// STORAGE
// ============================================================================

const scanHistory: ScanResult[] = [];
const scanCategories: ScanCategory[] = [];

// ============================================================================
// AI/VIBE-CODED SPECIFIC CHECKS
// ============================================================================

/**
 * Patterns commonly found in AI-generated code that indicate security issues
 */
const AI_VIBE_PATTERNS = {
  // Hardcoded secrets
  hardcodedSecrets: [
    /(?:password|passwd|pwd)\s*[=:]\s*['"][^'"]+['"]/gi,
    /(?:api[_-]?key|apikey)\s*[=:]\s*['"][^'"]+['"]/gi,
    /(?:secret|token)\s*[=:]\s*['"][a-zA-Z0-9]{16,}['"]/gi,
    /(?:aws|azure|gcp)[_-]?(?:key|secret|token)\s*[=:]\s*['"][^'"]+['"]/gi,
    /(?:database|db)[_-]?url\s*[=:]\s*['"][^'"]*@[^'"]+['"]/gi,
    /private[_-]?key\s*[=:]\s*['"]-----BEGIN/gi,
  ],
  
  // Insecure defaults
  insecureDefaults: [
    /cors\s*[=:]\s*['"]\*['"]/gi,
    /allowOrigin\s*[=:]\s*['"]\*['"]/gi,
    /secure\s*[=:]\s*false/gi,
    /httponly\s*[=:]\s*false/gi,
    /skipAuth\s*[=:]\s*true/gi,
    /disableAuth\s*[=:]\s*true/gi,
    /NODE_ENV\s*[=:]\s*['"]development['"]/gi,
  ],
  
  // Missing validation
  missingValidation: [
    /eval\s*\(/gi,
    /Function\s*\(/gi,
    /innerHTML\s*[=:]/gi,
    /dangerouslySetInnerHTML/gi,
    /exec\s*\(/gi,
    /spawn\s*\(/gi,
  ],
  
  // SQL/NoSQL injection patterns
  injectionPatterns: [
    /\$\{.*\}.*(?:SELECT|INSERT|UPDATE|DELETE)/gi,
    /query\s*\(\s*['"`].*\$\{/gi,
    /\.find\s*\(\s*\{.*\+/gi,
    /where\s*:\s*['"`].*\+/gi,
  ],
  
  // Path traversal
  pathTraversal: [
    /\.join\s*\(\s*['"`]\.\.['"`]\)/gi,
    /path\s*\+\s*['"`]\.\./gi,
    /readFile\s*\(\s*[^'"]*\+/gi,
  ],
  
  // Command injection
  commandInjection: [
    /exec\s*\(\s*['"`].*\$\{/gi,
    /spawn\s*\(\s*['"`].*\$\{/gi,
    /system\s*\(\s*['"`].*\$\{/gi,
  ]
};

// ============================================================================
// SCAN IMPLEMENTATIONS
// ============================================================================

/**
 * Scan for hardcoded secrets
 */
async function scanHardcodedSecrets(target: string, config: ScanConfig): Promise<ScanFinding[]> {
  const findings: ScanFinding[] = [];
  
  for (const pattern of AI_VIBE_PATTERNS.hardcodedSecrets) {
    const matches = target.match(pattern);
    if (matches) {
      findings.push({
        id: `finding_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        category: 'secrets',
        severity: 'critical',
        title: 'Hardcoded Secret Detected',
        description: `Potential hardcoded secret found: ${matches[0].substring(0, 50)}...`,
        location: {
          code: matches[0]
        },
        impact: 'Exposure of sensitive credentials could lead to unauthorized access',
        remediation: 'Move secrets to environment variables or secure secret management',
        cwe: 'CWE-798',
        owasp: 'A07:2021'
      });
    }
  }
  
  return findings;
}

/**
 * Scan for insecure defaults
 */
async function scanInsecureDefaults(target: string, config: ScanConfig): Promise<ScanFinding[]> {
  const findings: ScanFinding[] = [];
  
  for (const pattern of AI_VIBE_PATTERNS.insecureDefaults) {
    const matches = target.match(pattern);
    if (matches) {
      findings.push({
        id: `finding_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        category: 'configuration',
        severity: 'high',
        title: 'Insecure Default Configuration',
        description: `Insecure default detected: ${matches[0]}`,
        location: {
          code: matches[0]
        },
        impact: 'Insecure defaults can expose application to attacks',
        remediation: 'Review and harden default configurations',
        cwe: 'CWE-1188'
      });
    }
  }
  
  return findings;
}

/**
 * Scan for injection vulnerabilities
 */
async function scanInjectionVulnerabilities(target: string, config: ScanConfig): Promise<ScanFinding[]> {
  const findings: ScanFinding[] = [];
  
  // SQL Injection
  for (const pattern of AI_VIBE_PATTERNS.injectionPatterns) {
    const matches = target.match(pattern);
    if (matches) {
      findings.push({
        id: `finding_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        category: 'injection',
        severity: 'critical',
        title: 'Potential SQL/NoSQL Injection',
        description: 'User input directly concatenated into database query',
        location: {
          code: matches[0]
        },
        impact: 'Could allow attackers to execute arbitrary database commands',
        remediation: 'Use parameterized queries or prepared statements',
        cwe: 'CWE-89',
        owasp: 'A03:2021'
      });
    }
  }
  
  // Command Injection
  for (const pattern of AI_VIBE_PATTERNS.commandInjection) {
    const matches = target.match(pattern);
    if (matches) {
      findings.push({
        id: `finding_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        category: 'injection',
        severity: 'critical',
        title: 'Potential Command Injection',
        description: 'User input used in system command execution',
        location: {
          code: matches[0]
        },
        impact: 'Could allow attackers to execute arbitrary system commands',
        remediation: 'Sanitize all user input and avoid shell command execution with user data',
        cwe: 'CWE-78',
        owasp: 'A03:2021'
      });
    }
  }
  
  return findings;
}

/**
 * Scan for missing input validation
 */
async function scanMissingValidation(target: string, config: ScanConfig): Promise<ScanFinding[]> {
  const findings: ScanFinding[] = [];
  
  for (const pattern of AI_VIBE_PATTERNS.missingValidation) {
    const matches = target.match(pattern);
    if (matches) {
      findings.push({
        id: `finding_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        category: 'validation',
        severity: 'high',
        title: 'Dangerous Function Usage',
        description: `Use of potentially dangerous function: ${matches[0]}`,
        location: {
          code: matches[0]
        },
        impact: 'Could lead to code injection or XSS vulnerabilities',
        remediation: 'Validate and sanitize all inputs before using dynamic code execution',
        cwe: 'CWE-94'
      });
    }
  }
  
  return findings;
}

/**
 * Scan for path traversal
 */
async function scanPathTraversal(target: string, config: ScanConfig): Promise<ScanFinding[]> {
  const findings: ScanFinding[] = [];
  
  for (const pattern of AI_VIBE_PATTERNS.pathTraversal) {
    const matches = target.match(pattern);
    if (matches) {
      findings.push({
        id: `finding_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        category: 'filesystem',
        severity: 'high',
        title: 'Potential Path Traversal',
        description: 'User input may allow access to unintended files',
        location: {
          code: matches[0]
        },
        impact: 'Could allow attackers to read or write arbitrary files',
        remediation: 'Validate and sanitize file paths, use allowlists',
        cwe: 'CWE-22',
        owasp: 'A01:2021'
      });
    }
  }
  
  return findings;
}

/**
 * Check for authentication/authorization issues
 */
async function scanAuthIssues(target: string, config: ScanConfig): Promise<ScanFinding[]> {
  const findings: ScanFinding[] = [];
  
  // Check for missing auth middleware
  const hasAuthMiddleware = /(?:auth|authenticate|verifyToken|checkAuth)/i.test(target);
  const hasApiRoutes = /(?:router|app\.(?:get|post|put|delete))/i.test(target);
  
  if (hasApiRoutes && !hasAuthMiddleware) {
    findings.push({
      id: `finding_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      category: 'authentication',
      severity: 'medium',
      title: 'Missing Authentication Check',
      description: 'API routes detected without visible authentication middleware',
      location: {},
      impact: 'Unauthenticated access to potentially sensitive endpoints',
      remediation: 'Implement authentication middleware for all sensitive routes',
      cwe: 'CWE-306'
    });
  }
  
  // Check for weak password patterns
  if (/password\s*[=:]\s*['"][^'"]{1,8}['"]/i.test(target)) {
    findings.push({
      id: `finding_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      category: 'authentication',
      severity: 'medium',
      title: 'Weak Password Configuration',
      description: 'Short password minimum length detected',
      location: {},
      impact: 'Users may set easily guessable passwords',
      remediation: 'Enforce minimum 12 character passwords with complexity requirements',
      cwe: 'CWE-521'
    });
  }
  
  return findings;
}

/**
 * Check for data exposure
 */
async function scanDataExposure(target: string, config: ScanConfig): Promise<ScanFinding[]> {
  const findings: ScanFinding[] = [];
  
  // Check for verbose error handling
  if (/\.catch\s*\(\s*(?:e|err|error)\s*=>\s*(?:res|response)\.(?:json|send)\s*\(\s*(?:e|err|error)\)/i.test(target)) {
    findings.push({
      id: `finding_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      category: 'information-disclosure',
      severity: 'medium',
      title: 'Verbose Error Response',
      description: 'Full error objects returned to client',
      location: {},
      impact: 'Could leak sensitive information about internal systems',
      remediation: 'Return generic error messages and log detailed errors server-side',
      cwe: 'CWE-209'
    });
  }
  
  // Check for exposed stack traces
  if (/(?:stack|trace)\s*[=:]/i.test(target) && /res\.(?:json|send)/i.test(target)) {
    findings.push({
      id: `finding_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      category: 'information-disclosure',
      severity: 'medium',
      title: 'Stack Trace Exposure',
      description: 'Stack traces may be exposed to users',
      location: {},
      impact: 'Reveals internal implementation details',
      remediation: 'Disable stack trace exposure in production',
      cwe: 'CWE-209'
    });
  }
  
  return findings;
}

// ============================================================================
// MAIN SCAN FUNCTION
// ============================================================================

/**
 * Perform application security scan
 */
export async function scanApplication(
  target: string,
  scanType: ScanConfig['type'] = 'standard',
  options: Record<string, unknown> = {}
): Promise<ScanResult> {
  const startTime = Date.now();
  const id = `scan_${startTime}_${Math.random().toString(36).substr(2, 9)}`;
  
  const config: ScanConfig = {
    target,
    type: scanType,
    ...options
  };
  
  const findings: ScanFinding[] = [];
  
  // Always run these checks
  findings.push(...await scanHardcodedSecrets(target, config));
  findings.push(...await scanInsecureDefaults(target, config));
  
  // Standard and deep scans include more checks
  if (scanType === 'standard' || scanType === 'deep' || scanType === 'ai-vibe-check') {
    findings.push(...await scanInjectionVulnerabilities(target, config));
    findings.push(...await scanMissingValidation(target, config));
    findings.push(...await scanPathTraversal(target, config));
  }
  
  // Deep and AI-vibe-check scans include all checks
  if (scanType === 'deep' || scanType === 'ai-vibe-check') {
    findings.push(...await scanAuthIssues(target, config));
    findings.push(...await scanDataExposure(target, config));
  }
  
  // Calculate score
  const severityWeights = { critical: 25, high: 10, medium: 5, low: 2, info: 0 };
  const totalPenalty = findings.reduce((sum, f) => sum + severityWeights[f.severity], 0);
  const score = Math.max(0, 100 - totalPenalty);
  
  // Determine grade
  let grade: ScanResult['grade'];
  if (score >= 90) grade = 'A';
  else if (score >= 80) grade = 'B';
  else if (score >= 70) grade = 'C';
  else if (score >= 60) grade = 'D';
  else grade = 'F';
  
  // Determine status
  const status: ScanResult['status'] = 
    findings.some(f => f.severity === 'critical') ? 'fail' :
    findings.some(f => f.severity === 'high') ? 'warn' : 'pass';
  
  // Generate recommendations
  const recommendations = generateRecommendations(findings);
  
  // AI/Vibe-specific metrics
  const aiVibeSpecific = scanType === 'ai-vibe-check' ? {
    aiGeneratedPatterns: findings.filter(f => 
      f.title.includes('Default') || f.title.includes('Missing')
    ).length,
    hardcodedSecrets: findings.filter(f => f.category === 'secrets').length,
    insecureDefaults: findings.filter(f => f.category === 'configuration').length,
    missingValidation: findings.filter(f => f.category === 'validation').length,
    logicFlaws: findings.filter(f => f.category === 'authentication').length
  } : undefined;
  
  const result: ScanResult = {
    id,
    target,
    type: scanType,
    timestamp: startTime,
    duration: Date.now() - startTime,
    score,
    grade,
    status,
    summary: {
      totalChecks: findings.length,
      passed: 0,
      warnings: findings.filter(f => f.severity === 'medium' || f.severity === 'low').length,
      failed: findings.filter(f => f.severity === 'critical' || f.severity === 'high').length,
      critical: findings.filter(f => f.severity === 'critical').length,
      high: findings.filter(f => f.severity === 'high').length,
      medium: findings.filter(f => f.severity === 'medium').length,
      low: findings.filter(f => f.severity === 'low').length
    },
    findings,
    recommendations,
    aiVibeSpecific
  };
  
  scanHistory.push(result);
  
  return result;
}

/**
 * Generate recommendations based on findings
 */
function generateRecommendations(findings: ScanFinding[]): string[] {
  const recommendations: string[] = [];
  
  const categories = new Set(findings.map(f => f.category));
  
  if (categories.has('secrets')) {
    recommendations.push('Implement secret management using environment variables or a secrets manager');
  }
  
  if (categories.has('injection')) {
    recommendations.push('Use parameterized queries and input validation to prevent injection attacks');
  }
  
  if (categories.has('validation')) {
    recommendations.push('Implement comprehensive input validation and output encoding');
  }
  
  if (categories.has('authentication')) {
    recommendations.push('Review and strengthen authentication and authorization mechanisms');
  }
  
  if (categories.has('configuration')) {
    recommendations.push('Review and harden default configuration settings');
  }
  
  if (categories.has('information-disclosure')) {
    recommendations.push('Implement proper error handling that doesn\'t expose sensitive information');
  }
  
  // Add general recommendations
  recommendations.push('Enable security headers (CSP, HSTS, X-Frame-Options)');
  recommendations.push('Implement rate limiting on all API endpoints');
  recommendations.push('Set up logging and monitoring for security events');
  
  return recommendations;
}

// ============================================================================
// SCAN HISTORY
// ============================================================================

/**
 * Get scan history
 */
export function getScanHistory(limit: number = 50): ScanResult[] {
  return scanHistory.slice(-limit);
}

/**
 * Get scan by ID
 */
export function getScanById(id: string): ScanResult | undefined {
  return scanHistory.find(s => s.id === id);
}

/**
 * Get scan statistics
 */
export function getScanStatistics(): {
  totalScans: number;
  avgScore: number;
  passRate: number;
  criticalFindings: number;
  topIssues: Array<{ category: string; count: number }>;
} {
  const totalScans = scanHistory.length;
  const avgScore = totalScans > 0 
    ? scanHistory.reduce((sum, s) => sum + s.score, 0) / totalScans 
    : 0;
  const passRate = totalScans > 0
    ? scanHistory.filter(s => s.status === 'pass').length / totalScans
    : 0;
  
  const allFindings = scanHistory.flatMap(s => s.findings);
  const criticalFindings = allFindings.filter(f => f.severity === 'critical').length;
  
  const categoryCounts = new Map<string, number>();
  for (const finding of allFindings) {
    categoryCounts.set(finding.category, (categoryCounts.get(finding.category) || 0) + 1);
  }
  
  const topIssues = Array.from(categoryCounts.entries())
    .map(([category, count]) => ({ category, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 10);
  
  return {
    totalScans,
    avgScore,
    passRate,
    criticalFindings,
    topIssues
  };
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

const appScanner = {
  // Main scan function
  scanApplication,
  
  // History
  getScanHistory,
  getScanById,
  getScanStatistics
};

export default appScanner;
