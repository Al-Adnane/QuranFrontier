/**
 * Kasbah Guard - Protected Applications Manager
 * 
 * Manages applications under Kasbah Guard protection.
 * Tracks security status, policies, and resource usage per app.
 * 
 * @module kasbah-guard/protected-apps
 * @version 1.0.0
 */

// ============================================================================
// TYPES
// ============================================================================

/**
 * Protected Application
 */
export interface ProtectedApp {
  id: string;
  name: string;
  description?: string;
  path: string;
  type: 'web' | 'api' | 'cli' | 'desktop' | 'mobile' | 'service' | 'ai-agent' | 'vibe-coded';
  status: 'protected' | 'monitoring' | 'quarantine' | 'unprotected';
  policy: string;
  riskScore: number;
  
  // Protection settings
  protection: {
    networkMonitor: boolean;
    fileMonitor: boolean;
    processMonitor: boolean;
    apiMonitor: boolean;
    behaviorAnalysis: boolean;
    autoBlock: boolean;
    sandbox: boolean;
  };
  
  // Credit settings
  creditLimit: number;
  creditsUsed: number;
  creditsRemaining: number;
  
  // Statistics
  stats: {
    totalScans: number;
    threatsBlocked: number;
    alertsGenerated: number;
    lastScan: number | null;
    lastThreat: number | null;
    uptime: number;
  };
  
  // Metadata
  tags: string[];
  owner: string;
  createdAt: number;
  updatedAt: number;
  lastActivity: number;
}

/**
 * App Protection Policy
 */
export interface AppProtectionPolicy {
  id: string;
  name: string;
  description: string;
  
  // Network rules
  networkRules: {
    allowedDomains: string[];
    blockedDomains: string[];
    allowedPorts: number[];
    blockedPorts: number[];
    maxConnections: number;
    requireHttps: boolean;
  };
  
  // File rules
  fileRules: {
    allowedPaths: string[];
    blockedPaths: string[];
    allowedExtensions: string[];
    blockedExtensions: string[];
    maxFileSize: number;
    readOnlyPaths: string[];
  };
  
  // Process rules
  processRules: {
    allowedProcesses: string[];
    blockedProcesses: string[];
    maxCpuPercent: number;
    maxMemoryMB: number;
    allowChildProcesses: boolean;
  };
  
  // API rules
  apiRules: {
    allowedEndpoints: string[];
    blockedEndpoints: string[];
    rateLimit: number;
    requireAuth: boolean;
    allowedMethods: string[];
  };
  
  // Behavior rules
  behaviorRules: {
    anomalyThreshold: number;
    blockOnAnomaly: boolean;
    learningMode: boolean;
    sensitiveActions: string[];
  };
  
  // Response actions
  actions: {
    onThreat: 'alert' | 'block' | 'quarantine' | 'terminate';
    onViolation: 'alert' | 'block' | 'log';
    onAnomaly: 'alert' | 'monitor' | 'block';
    notifyEmail: boolean;
    notifyWebhook: string | null;
  };
}

/**
 * App Security Event
 */
export interface AppSecurityEvent {
  id: string;
  appId: string;
  type: 'threat' | 'violation' | 'anomaly' | 'alert' | 'blocked';
  severity: 'low' | 'medium' | 'high' | 'critical';
  title: string;
  description: string;
  action: string;
  timestamp: number;
  resolved: boolean;
  metadata?: Record<string, unknown>;
}

// ============================================================================
// STORAGE
// ============================================================================

const protectedApps = new Map<string, ProtectedApp>();
const policies = new Map<string, AppProtectionPolicy>();
const appEvents = new Map<string, AppSecurityEvent[]>();

// Default policies
const defaultPolicies: AppProtectionPolicy[] = [
  {
    id: 'policy_strict',
    name: 'Strict Protection',
    description: 'Maximum security with aggressive blocking',
    networkRules: {
      allowedDomains: [],
      blockedDomains: [],
      allowedPorts: [443],
      blockedPorts: [22, 23, 21, 25],
      maxConnections: 50,
      requireHttps: true
    },
    fileRules: {
      allowedPaths: ['/app/data', '/app/config'],
      blockedPaths: ['/etc', '/root', '/var/log'],
      allowedExtensions: ['.json', '.txt', '.csv'],
      blockedExtensions: ['.exe', '.sh', '.bat', '.dll'],
      maxFileSize: 10 * 1024 * 1024,
      readOnlyPaths: ['/app/config']
    },
    processRules: {
      allowedProcesses: [],
      blockedProcesses: ['nc', 'netcat', 'telnet', 'nmap'],
      maxCpuPercent: 50,
      maxMemoryMB: 512,
      allowChildProcesses: false
    },
    apiRules: {
      allowedEndpoints: [],
      blockedEndpoints: ['/admin', '/debug', '/config'],
      rateLimit: 100,
      requireAuth: true,
      allowedMethods: ['GET', 'POST']
    },
    behaviorRules: {
      anomalyThreshold: 30,
      blockOnAnomaly: true,
      learningMode: false,
      sensitiveActions: ['file_delete', 'process_spawn', 'network_connect']
    },
    actions: {
      onThreat: 'block',
      onViolation: 'block',
      onAnomaly: 'block',
      notifyEmail: true,
      notifyWebhook: null
    }
  },
  {
    id: 'policy_balanced',
    name: 'Balanced Protection',
    description: 'Balanced security with monitoring and selective blocking',
    networkRules: {
      allowedDomains: [],
      blockedDomains: [],
      allowedPorts: [80, 443, 8080, 3000],
      blockedPorts: [22, 23],
      maxConnections: 200,
      requireHttps: false
    },
    fileRules: {
      allowedPaths: [],
      blockedPaths: ['/etc/passwd', '/etc/shadow'],
      allowedExtensions: [],
      blockedExtensions: ['.exe'],
      maxFileSize: 50 * 1024 * 1024,
      readOnlyPaths: []
    },
    processRules: {
      allowedProcesses: [],
      blockedProcesses: [],
      maxCpuPercent: 80,
      maxMemoryMB: 1024,
      allowChildProcesses: true
    },
    apiRules: {
      allowedEndpoints: [],
      blockedEndpoints: ['/admin'],
      rateLimit: 500,
      requireAuth: false,
      allowedMethods: ['GET', 'POST', 'PUT', 'DELETE']
    },
    behaviorRules: {
      anomalyThreshold: 50,
      blockOnAnomaly: false,
      learningMode: true,
      sensitiveActions: ['file_delete', 'process_spawn']
    },
    actions: {
      onThreat: 'alert',
      onViolation: 'alert',
      onAnomaly: 'monitor',
      notifyEmail: true,
      notifyWebhook: null
    }
  },
  {
    id: 'policy_permissive',
    name: 'Permissive Protection',
    description: 'Minimal restrictions with monitoring only',
    networkRules: {
      allowedDomains: [],
      blockedDomains: [],
      allowedPorts: [],
      blockedPorts: [],
      maxConnections: 1000,
      requireHttps: false
    },
    fileRules: {
      allowedPaths: [],
      blockedPaths: [],
      allowedExtensions: [],
      blockedExtensions: [],
      maxFileSize: 100 * 1024 * 1024,
      readOnlyPaths: []
    },
    processRules: {
      allowedProcesses: [],
      blockedProcesses: [],
      maxCpuPercent: 100,
      maxMemoryMB: 2048,
      allowChildProcesses: true
    },
    apiRules: {
      allowedEndpoints: [],
      blockedEndpoints: [],
      rateLimit: 1000,
      requireAuth: false,
      allowedMethods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH']
    },
    behaviorRules: {
      anomalyThreshold: 80,
      blockOnAnomaly: false,
      learningMode: true,
      sensitiveActions: []
    },
    actions: {
      onThreat: 'alert',
      onViolation: 'log',
      onAnomaly: 'monitor',
      notifyEmail: false,
      notifyWebhook: null
    }
  },
  {
    id: 'policy_vibe_coded',
    name: 'AI/Vibe-Coded App Protection',
    description: 'Specialized protection for AI-generated applications',
    networkRules: {
      allowedDomains: [],
      blockedDomains: [],
      allowedPorts: [80, 443, 3000, 8080, 5173],
      blockedPorts: [22, 23],
      maxConnections: 300,
      requireHttps: false
    },
    fileRules: {
      allowedPaths: [],
      blockedPaths: ['/etc', '/root', '.env', '.git'],
      allowedExtensions: [],
      blockedExtensions: [],
      maxFileSize: 20 * 1024 * 1024,
      readOnlyPaths: ['.env', 'config']
    },
    processRules: {
      allowedProcesses: [],
      blockedProcesses: ['nc', 'telnet'],
      maxCpuPercent: 70,
      maxMemoryMB: 1536,
      allowChildProcesses: true
    },
    apiRules: {
      allowedEndpoints: [],
      blockedEndpoints: ['/admin', '/debug', '/console'],
      rateLimit: 300,
      requireAuth: true,
      allowedMethods: ['GET', 'POST', 'PUT', 'DELETE']
    },
    behaviorRules: {
      anomalyThreshold: 40,
      blockOnAnomaly: true,
      learningMode: true,
      sensitiveActions: ['file_delete', 'env_access', 'secret_access', 'db_drop']
    },
    actions: {
      onThreat: 'alert',
      onViolation: 'block',
      onAnomaly: 'alert',
      notifyEmail: true,
      notifyWebhook: null
    }
  }
];

// Initialize default policies
defaultPolicies.forEach(policy => policies.set(policy.id, policy));

// ============================================================================
// APP MANAGEMENT
// ============================================================================

/**
 * Add a protected application
 */
export function addProtectedApp(config: {
  name: string;
  description?: string;
  path: string;
  type?: ProtectedApp['type'];
  policy?: string;
  creditLimit?: number;
  owner?: string;
  tags?: string[];
}): ProtectedApp {
  const id = `app_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  
  const app: ProtectedApp = {
    id,
    name: config.name,
    description: config.description,
    path: config.path,
    type: config.type || 'web',
    status: 'protected',
    policy: config.policy || 'policy_balanced',
    riskScore: 0,
    
    protection: {
      networkMonitor: true,
      fileMonitor: true,
      processMonitor: true,
      apiMonitor: true,
      behaviorAnalysis: true,
      autoBlock: false,
      sandbox: false
    },
    
    creditLimit: config.creditLimit || 10000,
    creditsUsed: 0,
    creditsRemaining: config.creditLimit || 10000,
    
    stats: {
      totalScans: 0,
      threatsBlocked: 0,
      alertsGenerated: 0,
      lastScan: null,
      lastThreat: null,
      uptime: 0
    },
    
    tags: config.tags || [],
    owner: config.owner || 'system',
    createdAt: Date.now(),
    updatedAt: Date.now(),
    lastActivity: Date.now()
  };
  
  protectedApps.set(id, app);
  appEvents.set(id, []);
  
  // Log event
  addAppEvent(id, {
    type: 'alert',
    severity: 'low',
    title: 'Application Protected',
    description: `${config.name} is now under Kasbah Guard protection`,
    action: 'added_to_protection'
  });
  
  return app;
}

/**
 * Get protected app by ID
 */
export function getProtectedApp(id: string): ProtectedApp | undefined {
  return protectedApps.get(id);
}

/**
 * List all protected apps
 */
export function listProtectedApps(filter?: {
  status?: ProtectedApp['status'];
  type?: ProtectedApp['type'];
  policy?: string;
}): ProtectedApp[] {
  let apps = Array.from(protectedApps.values());
  
  if (filter) {
    if (filter.status) apps = apps.filter(a => a.status === filter.status);
    if (filter.type) apps = apps.filter(a => a.type === filter.type);
    if (filter.policy) apps = apps.filter(a => a.policy === filter.policy);
  }
  
  return apps;
}

/**
 * Update protected app
 */
export function updateProtectedApp(id: string, updates: Partial<ProtectedApp>): ProtectedApp | undefined {
  const app = protectedApps.get(id);
  if (!app) return undefined;
  
  // Don't allow updating certain fields
  delete updates.id;
  delete updates.createdAt;
  
  Object.assign(app, updates, {
    updatedAt: Date.now(),
    lastActivity: Date.now()
  });
  
  protectedApps.set(id, app);
  
  return app;
}

/**
 * Remove protected app
 */
export function removeProtectedApp(id: string): boolean {
  const app = protectedApps.get(id);
  if (!app) return false;
  
  protectedApps.delete(id);
  appEvents.delete(id);
  
  return true;
}

/**
 * Set app protection status
 */
export function setAppStatus(id: string, status: ProtectedApp['status']): boolean {
  const app = protectedApps.get(id);
  if (!app) return false;
  
  app.status = status;
  app.updatedAt = Date.now();
  protectedApps.set(id, app);
  
  addAppEvent(id, {
    type: 'alert',
    severity: 'medium',
    title: 'Protection Status Changed',
    description: `Protection status changed to: ${status}`,
    action: `status_${status}`
  });
  
  return true;
}

/**
 * Update app credits
 */
export function updateAppCredits(id: string, used: number): boolean {
  const app = protectedApps.get(id);
  if (!app) return false;
  
  app.creditsUsed = used;
  app.creditsRemaining = app.creditLimit - used;
  app.lastActivity = Date.now();
  
  protectedApps.set(id, app);
  
  return true;
}

// ============================================================================
// POLICY MANAGEMENT
// ============================================================================

/**
 * Create custom policy
 */
export function createPolicy(config: Partial<AppProtectionPolicy>): AppProtectionPolicy {
  const id = `policy_custom_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  
  const policy: AppProtectionPolicy = {
    id,
    name: config.name || 'Custom Policy',
    description: config.description || 'Custom protection policy',
    
    networkRules: config.networkRules || defaultPolicies[1].networkRules,
    fileRules: config.fileRules || defaultPolicies[1].fileRules,
    processRules: config.processRules || defaultPolicies[1].processRules,
    apiRules: config.apiRules || defaultPolicies[1].apiRules,
    behaviorRules: config.behaviorRules || defaultPolicies[1].behaviorRules,
    actions: config.actions || defaultPolicies[1].actions
  };
  
  policies.set(id, policy);
  
  return policy;
}

/**
 * Get policy by ID
 */
export function getPolicy(id: string): AppProtectionPolicy | undefined {
  return policies.get(id);
}

/**
 * List all policies
 */
export function listPolicies(): AppProtectionPolicy[] {
  return Array.from(policies.values());
}

/**
 * Apply policy to app
 */
export function applyPolicy(appId: string, policyId: string): boolean {
  const app = protectedApps.get(appId);
  const policy = policies.get(policyId);
  
  if (!app || !policy) return false;
  
  app.policy = policyId;
  app.updatedAt = Date.now();
  protectedApps.set(appId, app);
  
  addAppEvent(appId, {
    type: 'alert',
    severity: 'low',
    title: 'Policy Applied',
    description: `Policy "${policy.name}" applied to ${app.name}`,
    action: 'policy_applied'
  });
  
  return true;
}

// ============================================================================
// SECURITY EVENTS
// ============================================================================

/**
 * Add app security event
 */
export function addAppEvent(appId: string, event: Omit<AppSecurityEvent, 'id' | 'appId' | 'timestamp' | 'resolved'>): AppSecurityEvent {
  const fullEvent: AppSecurityEvent = {
    ...event,
    id: `evt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    appId,
    timestamp: Date.now(),
    resolved: false
  };
  
  const events = appEvents.get(appId) || [];
  events.push(fullEvent);
  
  // Keep only last 500 events
  if (events.length > 500) {
    events.shift();
  }
  
  appEvents.set(appId, events);
  
  // Update app stats
  const app = protectedApps.get(appId);
  if (app) {
    if (event.type === 'threat' || event.type === 'blocked') {
      app.stats.threatsBlocked++;
      app.stats.lastThreat = Date.now();
    }
    app.stats.alertsGenerated++;
    protectedApps.set(appId, app);
  }
  
  return fullEvent;
}

/**
 * Get app events
 */
export function getAppEvents(appId: string, limit: number = 50): AppSecurityEvent[] {
  const events = appEvents.get(appId) || [];
  return events.slice(-limit);
}

/**
 * Resolve app event
 */
export function resolveAppEvent(appId: string, eventId: string): boolean {
  const events = appEvents.get(appId) || [];
  const event = events.find(e => e.id === eventId);
  
  if (event) {
    event.resolved = true;
    appEvents.set(appId, events);
    return true;
  }
  
  return false;
}

// ============================================================================
// QUICK ACTIONS
// ============================================================================

/**
 * Quarantine app
 */
export function quarantineApp(id: string, reason: string): boolean {
  const app = protectedApps.get(id);
  if (!app) return false;
  
  app.status = 'quarantine';
  app.protection.sandbox = true;
  app.updatedAt = Date.now();
  protectedApps.set(id, app);
  
  addAppEvent(id, {
    type: 'alert',
    severity: 'high',
    title: 'Application Quarantined',
    description: `Application quarantined: ${reason}`,
    action: 'quarantine'
  });
  
  return true;
}

/**
 * Release app from quarantine
 */
export function releaseFromQuarantine(id: string): boolean {
  const app = protectedApps.get(id);
  if (!app || app.status !== 'quarantine') return false;
  
  app.status = 'protected';
  app.protection.sandbox = false;
  app.updatedAt = Date.now();
  protectedApps.set(id, app);
  
  addAppEvent(id, {
    type: 'alert',
    severity: 'medium',
    title: 'Released from Quarantine',
    description: 'Application released from quarantine',
    action: 'release'
  });
  
  return true;
}

/**
 * Block app
 */
export function blockApp(id: string, reason: string): boolean {
  const app = protectedApps.get(id);
  if (!app) return false;
  
  app.status = 'unprotected';
  app.protection.autoBlock = true;
  app.updatedAt = Date.now();
  protectedApps.set(id, app);
  
  addAppEvent(id, {
    type: 'blocked',
    severity: 'critical',
    title: 'Application Blocked',
    description: `Application blocked: ${reason}`,
    action: 'block'
  });
  
  return true;
}

// ============================================================================
// STATISTICS
// ============================================================================

/**
 * Get protection statistics
 */
export function getProtectionStats(): {
  totalApps: number;
  protectedApps: number;
  monitoringApps: number;
  quarantinedApps: number;
  blockedApps: number;
  totalThreatsBlocked: number;
  totalAlerts: number;
  avgRiskScore: number;
  totalCreditsUsed: number;
  totalCreditsRemaining: number;
} {
  const apps = Array.from(protectedApps.values());
  
  return {
    totalApps: apps.length,
    protectedApps: apps.filter(a => a.status === 'protected').length,
    monitoringApps: apps.filter(a => a.status === 'monitoring').length,
    quarantinedApps: apps.filter(a => a.status === 'quarantine').length,
    blockedApps: apps.filter(a => a.status === 'unprotected').length,
    totalThreatsBlocked: apps.reduce((sum, a) => sum + a.stats.threatsBlocked, 0),
    totalAlerts: apps.reduce((sum, a) => sum + a.stats.alertsGenerated, 0),
    avgRiskScore: apps.length > 0 
      ? apps.reduce((sum, a) => sum + a.riskScore, 0) / apps.length 
      : 0,
    totalCreditsUsed: apps.reduce((sum, a) => sum + a.creditsUsed, 0),
    totalCreditsRemaining: apps.reduce((sum, a) => sum + a.creditsRemaining, 0)
  };
}

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

const protectedAppsManager = {
  // App management
  addProtectedApp,
  getProtectedApp,
  listProtectedApps,
  updateProtectedApp,
  removeProtectedApp,
  setAppStatus,
  updateAppCredits,
  
  // Policy management
  createPolicy,
  getPolicy,
  listPolicies,
  applyPolicy,
  
  // Events
  addAppEvent,
  getAppEvents,
  resolveAppEvent,
  
  // Quick actions
  quarantineApp,
  releaseFromQuarantine,
  blockApp,
  
  // Statistics
  getProtectionStats
};

export default protectedAppsManager;
