/**
 * MCP Server Module - Model Context Protocol Implementation
 * 
 * Enables AI assistants to manage Kasbah Guard through standardized MCP protocol.
 * Provides tools, resources, and prompts for security management.
 * 
 * @module kasbah-guard/mcp-server
 */

// ============================================================================
// TYPES
// ============================================================================

export interface MCPTool {
  name: string;
  description: string;
  inputSchema: {
    type: 'object';
    properties: Record<string, {
      type: string;
      description: string;
      enum?: string[];
    }>;
    required?: string[];
  };
  handler: (args: Record<string, unknown>) => Promise<unknown>;
}

export interface MCPResource {
  uri: string;
  name: string;
  description: string;
  mimeType: string;
  handler: () => Promise<unknown>;
}

export interface MCPPrompt {
  name: string;
  description: string;
  arguments?: Array<{
    name: string;
    description: string;
    required: boolean;
  }>;
  handler: (args: Record<string, string>) => Promise<string>;
}

export interface MCPSession {
  id: string;
  clientInfo: {
    name: string;
    version: string;
  };
  connectedAt: number;
  lastActivity: number;
  toolsCalled: number;
  resourcesAccessed: number;
}

export interface MCPServerStatus {
  status: 'running' | 'stopped' | 'error';
  tools: number;
  resources: number;
  prompts: number;
  sessions: number;
  uptime: number;
}

// ============================================================================
// STATE
// ============================================================================

let sessions: Map<string, MCPSession> = new Map();
let startTime = Date.now();

// ============================================================================
// TOOLS REGISTRY
// ============================================================================

const tools: Map<string, MCPTool> = new Map();

/**
 * Register an MCP tool
 */
export function registerTool(tool: MCPTool): void {
  tools.set(tool.name, tool);
}

/**
 * Get tool by name
 */
export function getTool(name: string): MCPTool | undefined {
  return tools.get(name);
}

/**
 * List all tools
 */
export function listTools(): MCPTool[] {
  return Array.from(tools.values());
}

// ============================================================================
// RESOURCES REGISTRY
// ============================================================================

const resources: Map<string, MCPResource> = new Map();

/**
 * Register an MCP resource
 */
export function registerResource(resource: MCPResource): void {
  resources.set(resource.uri, resource);
}

/**
 * Get resource by URI
 */
export function getResource(uri: string): MCPResource | undefined {
  return resources.get(uri);
}

/**
 * List all resources
 */
export function listResources(): MCPResource[] {
  return Array.from(resources.values());
}

// ============================================================================
// PROMPTS REGISTRY
// ============================================================================

const prompts: Map<string, MCPPrompt> = new Map();

/**
 * Register an MCP prompt
 */
export function registerPrompt(prompt: MCPPrompt): void {
  prompts.set(prompt.name, prompt);
}

/**
 * Get prompt by name
 */
export function getPrompt(name: string): MCPPrompt | undefined {
  return prompts.get(name);
}

/**
 * List all prompts
 */
export function listPrompts(): MCPPrompt[] {
  return Array.from(prompts.values());
}

// ============================================================================
// SESSION MANAGEMENT
// ============================================================================

/**
 * Create a new MCP session
 */
export function createSession(clientInfo: { name: string; version: string }): MCPSession {
  const session: MCPSession = {
    id: `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    clientInfo,
    connectedAt: Date.now(),
    lastActivity: Date.now(),
    toolsCalled: 0,
    resourcesAccessed: 0
  };
  sessions.set(session.id, session);
  return session;
}

/**
 * Get session by ID
 */
export function getSession(id: string): MCPSession | undefined {
  return sessions.get(id);
}

/**
 * Update session activity
 */
export function updateSessionActivity(id: string): void {
  const session = sessions.get(id);
  if (session) {
    session.lastActivity = Date.now();
  }
}

/**
 * Close a session
 */
export function closeSession(id: string): boolean {
  return sessions.delete(id);
}

/**
 * List all active sessions
 */
export function listSessions(): MCPSession[] {
  return Array.from(sessions.values());
}

// ============================================================================
// HANDLERS
// ============================================================================

/**
 * Handle tool call
 */
export async function handleCallTool(name: string, args: Record<string, unknown>): Promise<{
  content: Array<{ type: string; text: string }>;
  isError?: boolean;
}> {
  const tool = tools.get(name);
  if (!tool) {
    return {
      content: [{ type: 'text', text: `Unknown tool: ${name}` }],
      isError: true
    };
  }

  try {
    const result = await tool.handler(args);
    return {
      content: [{ type: 'text', text: JSON.stringify(result, null, 2) }]
    };
  } catch (error) {
    return {
      content: [{ type: 'text', text: `Error executing tool: ${error}` }],
      isError: true
    };
  }
}

/**
 * Handle resource read
 */
export async function handleReadResource(uri: string): Promise<{
  contents: Array<{ uri: string; mimeType: string; text: string }>;
}> {
  const resource = resources.get(uri);
  if (!resource) {
    return {
      contents: [{ uri, mimeType: 'text/plain', text: `Unknown resource: ${uri}` }]
    };
  }

  try {
    const data = await resource.handler();
    return {
      contents: [{ uri, mimeType: resource.mimeType, text: JSON.stringify(data, null, 2) }]
    };
  } catch (error) {
    return {
      contents: [{ uri, mimeType: 'text/plain', text: `Error reading resource: ${error}` }]
    };
  }
}

/**
 * Handle prompt get
 */
export async function handleGetPrompt(name: string, args: Record<string, string>): Promise<{
  description: string;
  messages: Array<{ role: string; content: { type: string; text: string } }>;
}> {
  const prompt = prompts.get(name);
  if (!prompt) {
    return {
      description: 'Unknown prompt',
      messages: [{ role: 'user', content: { type: 'text', text: `Unknown prompt: ${name}` } }]
    };
  }

  try {
    const text = await prompt.handler(args);
    return {
      description: prompt.description,
      messages: [{ role: 'user', content: { type: 'text', text } }]
    };
  } catch (error) {
    return {
      description: 'Error',
      messages: [{ role: 'user', content: { type: 'text', text: `Error: ${error}` } }]
    };
  }
}

// ============================================================================
// STATUS
// ============================================================================

/**
 * Get MCP server status
 */
export function getMCPServerStatus(): MCPServerStatus {
  return {
    status: 'running',
    tools: tools.size,
    resources: resources.size,
    prompts: prompts.size,
    sessions: sessions.size,
    uptime: Date.now() - startTime
  };
}

// ============================================================================
// DEFAULT TOOLS
// ============================================================================

// Register default Kasbah Guard tools
registerTool({
  name: 'guard_status',
  description: 'Get current Kasbah Guard security status',
  inputSchema: {
    type: 'object',
    properties: {}
  },
  handler: async () => {
    const guard = await import('./index');
    return guard.getGuardStatus();
  }
});

registerTool({
  name: 'scan_app',
  description: 'Scan an application for security vulnerabilities',
  inputSchema: {
    type: 'object',
    properties: {
      target: { type: 'string', description: 'Application path or URL to scan' },
      scanType: { 
        type: 'string', 
        description: 'Type of scan',
        enum: ['quick', 'standard', 'deep', 'ai-vibe-check']
      }
    },
    required: ['target']
  },
  handler: async (args) => {
    const guard = await import('./index');
    return guard.appScanner.scanApplication(
      String(args.target),
      String(args.scanType || 'standard')
    );
  }
});

registerTool({
  name: 'block_threat',
  description: 'Block a threat (IP, domain, or pattern)',
  inputSchema: {
    type: 'object',
    properties: {
      type: { type: 'string', description: 'Threat type: ip, domain, pattern' },
      value: { type: 'string', description: 'Value to block' },
      reason: { type: 'string', description: 'Reason for blocking' },
      duration: { type: 'number', description: 'Duration in hours (0 = permanent)' }
    },
    required: ['type', 'value']
  },
  handler: async (args) => {
    const guard = await import('./index');
    return guard.threatManager.blockThreat({
      type: String(args.type) as 'ip' | 'domain' | 'pattern',
      value: String(args.value),
      reason: String(args.reason || 'Blocked via MCP'),
      duration: Number(args.duration) || 0
    });
  }
});

registerTool({
  name: 'list_protected_apps',
  description: 'List all protected applications',
  inputSchema: {
    type: 'object',
    properties: {}
  },
  handler: async () => {
    const guard = await import('./index');
    return guard.protectedApps.listProtectedApps();
  }
});

registerTool({
  name: 'get_credits',
  description: 'Get API credit status for an application',
  inputSchema: {
    type: 'object',
    properties: {
      appId: { type: 'string', description: 'Application ID (optional)' }
    }
  },
  handler: async (args) => {
    const guard = await import('./index');
    return guard.credits.getCreditStatus(String(args.appId || ''));
  }
});

registerTool({
  name: 'get_sensor_data',
  description: 'Get security sensor readings',
  inputSchema: {
    type: 'object',
    properties: {
      type: { type: 'string', description: 'Sensor type or "all"' },
      range: { type: 'string', description: 'Time range: 1h, 24h, 7d, 30d' }
    }
  },
  handler: async (args) => {
    const guard = await import('./index');
    return guard.sensors.getSensorData(String(args.type || 'all'), String(args.range || '1h'));
  }
});

registerTool({
  name: 'generate_report',
  description: 'Generate a security report',
  inputSchema: {
    type: 'object',
    properties: {
      type: { 
        type: 'string', 
        description: 'Report type',
        enum: ['summary', 'detailed', 'threats', 'credits', 'compliance']
      },
      format: { type: 'string', description: 'Output format: json, html, pdf' },
      timeRange: { type: 'string', description: 'Time range: 1d, 7d, 30d' }
    }
  },
  handler: async (args) => {
    const guard = await import('./index');
    return guard.reports.generateReport(
      String(args.type || 'summary'),
      String(args.format || 'json'),
      String(args.timeRange || '7d')
    );
  }
});

// ============================================================================
// DEFAULT RESOURCES
// ============================================================================

registerResource({
  uri: 'guard://status',
  name: 'Guard Status',
  description: 'Current security status of Kasbah Guard',
  mimeType: 'application/json',
  handler: async () => {
    const guard = await import('./index');
    return guard.getGuardStatus();
  }
});

registerResource({
  uri: 'guard://sensors',
  name: 'Sensor Data',
  description: 'Current sensor readings',
  mimeType: 'application/json',
  handler: async () => {
    const guard = await import('./index');
    return guard.sensors.getSensorData('all', '1h');
  }
});

registerResource({
  uri: 'guard://threats',
  name: 'Threat List',
  description: 'Recent threat detections',
  mimeType: 'application/json',
  handler: async () => {
    const guard = await import('./index');
    return guard.threatManager.getDetections(50);
  }
});

registerResource({
  uri: 'guard://credits',
  name: 'Credit Status',
  description: 'API credit usage and limits',
  mimeType: 'application/json',
  handler: async () => {
    const guard = await import('./index');
    return guard.credits.getCreditStatus();
  }
});

registerResource({
  uri: 'guard://apps',
  name: 'Protected Apps',
  description: 'List of protected applications',
  mimeType: 'application/json',
  handler: async () => {
    const guard = await import('./index');
    return guard.protectedApps.listProtectedApps();
  }
});

// ============================================================================
// DEFAULT PROMPTS
// ============================================================================

registerPrompt({
  name: 'security_analysis',
  description: 'Analyze security status and provide recommendations',
  arguments: [
    { name: 'focus', description: 'Area to focus on (network, api, behavior)', required: false }
  ],
  handler: async (args) => {
    const guard = await import('./index');
    const status = guard.getGuardStatus();
    const focus = args.focus || 'all';
    
    return `Analyze the following Kasbah Guard security status with focus on ${focus}:

${JSON.stringify(status, null, 2)}

Please provide:
1. Security assessment
2. Key vulnerabilities or concerns
3. Recommended actions
4. Priority ranking for addressing issues`;
  }
});

registerPrompt({
  name: 'threat_investigation',
  description: 'Investigate a specific threat or security event',
  arguments: [
    { name: 'threatId', description: 'Threat ID to investigate', required: true }
  ],
  handler: async (args) => {
    return `Investigate the following security threat:

Threat ID: ${args.threatId}

Please analyze:
1. Threat origin and attack vector
2. Potential impact and affected systems
3. Related threats or patterns
4. Recommended remediation steps
5. Prevention measures for future`;
  }
});

registerPrompt({
  name: 'app_security_review',
  description: 'Review security of a protected application',
  arguments: [
    { name: 'appId', description: 'Application ID to review', required: true }
  ],
  handler: async (args) => {
    const guard = await import('./index');
    const apps = guard.protectedApps.listProtectedApps();
    const app = apps.find(a => a.id === args.appId);
    
    return `Review security for application:

${app ? JSON.stringify(app, null, 2) : `App ${args.appId} not found`}

Please provide:
1. Security posture assessment
2. Policy compliance check
3. API credit usage analysis
4. Recommendations for improvement`;
  }
});

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

const mcpServer = {
  // Tool management
  registerTool,
  getTool,
  listTools,
  
  // Resource management
  registerResource,
  getResource,
  listResources,
  
  // Prompt management
  registerPrompt,
  getPrompt,
  listPrompts,
  
  // Session management
  createSession,
  getSession,
  updateSessionActivity,
  closeSession,
  listSessions,
  
  // Handlers
  handleCallTool,
  handleReadResource,
  handleGetPrompt,
  
  // Status
  getMCPServerStatus
};

export default mcpServer;
