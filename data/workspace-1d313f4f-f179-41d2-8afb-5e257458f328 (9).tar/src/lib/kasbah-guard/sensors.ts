/**
 * Kasbah Guard - Security Sensors
 * 
 * Multi-layered security sensors for monitoring:
 * - Network traffic and connections
 * - File system changes
 * - Process behavior
 * - API calls and patterns
 * - Behavioral anomalies
 * 
 * @module kasbah-guard/sensors
 * @version 1.0.0
 */

// ============================================================================
// TYPES
// ============================================================================

/**
 * Sensor Types
 */
export type SensorType = 'network' | 'file' | 'process' | 'api' | 'behavior' | 'memory' | 'runtime';

/**
 * Sensor Configuration
 */
export interface SensorConfig {
  id: string;
  type: SensorType;
  name: string;
  enabled: boolean;
  interval: number; // ms
  sensitivity: 'low' | 'medium' | 'high' | 'critical';
  thresholds: Record<string, number>;
  actions: Array<{
    condition: string;
    action: 'alert' | 'block' | 'log' | 'quarantine';
  }>;
}

/**
 * Sensor Reading
 */
export interface SensorReading {
  id: string;
  sensorId: string;
  sensorType: SensorType;
  timestamp: number;
  value: number | string | Record<string, unknown>;
  unit: string;
  status: 'normal' | 'warning' | 'critical' | 'unknown';
  metadata?: Record<string, unknown>;
}

/**
 * Sensor Alert
 */
export interface SensorAlert {
  id: string;
  sensorId: string;
  sensorType: SensorType;
  severity: 'info' | 'warning' | 'high' | 'critical';
  message: string;
  value: number | string;
  threshold: number;
  timestamp: number;
  acknowledged: boolean;
  resolvedAt?: number;
}

/**
 * Network Sensor Data
 */
export interface NetworkSensorData {
  connections: number;
  inboundBytes: number;
  outboundBytes: number;
  packetsPerSecond: number;
  uniqueIPs: number;
  blockedConnections: number;
  suspiciousConnections: Array<{
    ip: string;
    port: number;
    reason: string;
  }>;
  topProtocols: Record<string, number>;
}

/**
 * File Sensor Data
 */
export interface FileSensorData {
  filesAccessed: number;
  filesModified: number;
  filesCreated: number;
  filesDeleted: number;
  suspiciousFiles: Array<{
    path: string;
    action: string;
    reason: string;
  }>;
  watchedPaths: string[];
  hashMismatches: number;
}

/**
 * Process Sensor Data
 */
export interface ProcessSensorData {
  activeProcesses: number;
  cpuUsage: number;
  memoryUsage: number;
  suspiciousProcesses: Array<{
    pid: number;
    name: string;
    reason: string;
    cpu: number;
    memory: number;
  }>;
  childProcesses: number;
  zombieProcesses: number;
}

/**
 * API Sensor Data
 */
export interface APISensorData {
  requestsPerMinute: number;
  avgResponseTime: number;
  errorRate: number;
  authFailures: number;
  rateLimitHits: number;
  suspiciousPatterns: Array<{
    pattern: string;
    count: number;
    endpoint: string;
  }>;
  topEndpoints: Record<string, number>;
  slowEndpoints: Array<{
    endpoint: string;
    avgTime: number;
  }>;
}

/**
 * Behavior Sensor Data
 */
export interface BehaviorSensorData {
  anomalyScore: number;
  deviationFromBaseline: number;
  unusualActivityPatterns: string[];
  riskIndicators: Array<{
    type: string;
    score: number;
    description: string;
  }>;
  timeBasedAnomalies: Array<{
    time: number;
    activity: string;
    expected: number;
    actual: number;
  }>;
}

/**
 * Memory Sensor Data
 */
export interface MemorySensorData {
  totalMemory: number;
  usedMemory: number;
  peakMemory: number;
  memoryLeaks: Array<{
    process: string;
    growth: number;
  }>;
  heapUsage: number;
  bufferUsage: number;
}

/**
 * Runtime Sensor Data
 */
export interface RuntimeSensorData {
  uptime: number;
  errors: number;
  warnings: number;
  exceptions: Array<{
    type: string;
    message: string;
    count: number;
  }>;
  slowOperations: Array<{
    operation: string;
    duration: number;
  }>;
  resourceContention: boolean;
}

// ============================================================================
// STORAGE
// ============================================================================

const sensorConfigs = new Map<string, SensorConfig>();
const sensorReadings = new Map<string, SensorReading[]>();
const sensorAlerts = new Map<string, SensorAlert[]>();
const baselines = new Map<string, { mean: number; stdDev: number; samples: number }>();

// Active sensor intervals
const sensorIntervals = new Map<string, ReturnType<typeof setInterval>>();

// ============================================================================
// SENSOR CONFIGURATION
// ============================================================================

/**
 * Register a sensor
 */
export function registerSensor(config: Omit<SensorConfig, 'id'>): SensorConfig {
  const id = `sensor_${config.type}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  
  const sensor: SensorConfig = {
    ...config,
    id
  };
  
  sensorConfigs.set(id, sensor);
  sensorReadings.set(id, []);
  sensorAlerts.set(id, []);
  
  return sensor;
}

/**
 * Get sensor configuration
 */
export function getSensorConfig(id: string): SensorConfig | undefined {
  return sensorConfigs.get(id);
}

/**
 * List sensors
 */
export function listSensors(type?: SensorType): SensorConfig[] {
  const all = Array.from(sensorConfigs.values());
  return type ? all.filter(s => s.type === type) : all;
}

/**
 * Update sensor configuration
 */
export function updateSensorConfig(id: string, updates: Partial<SensorConfig>): SensorConfig | undefined {
  const sensor = sensorConfigs.get(id);
  if (!sensor) return undefined;
  
  Object.assign(sensor, updates);
  sensorConfigs.set(id, sensor);
  
  return sensor;
}

/**
 * Enable/disable sensor
 */
export function setSensorEnabled(id: string, enabled: boolean): boolean {
  const sensor = sensorConfigs.get(id);
  if (!sensor) return false;
  
  sensor.enabled = enabled;
  sensorConfigs.set(id, sensor);
  
  return true;
}

// ============================================================================
// SENSOR READINGS
// ============================================================================

/**
 * Record a sensor reading
 */
export function recordReading(reading: Omit<SensorReading, 'id' | 'timestamp'>): SensorReading {
  const fullReading: SensorReading = {
    ...reading,
    id: `read_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    timestamp: Date.now()
  };
  
  const readings = sensorReadings.get(reading.sensorId) || [];
  readings.push(fullReading);
  
  // Keep only last 1000 readings per sensor
  if (readings.length > 1000) {
    readings.shift();
  }
  
  sensorReadings.set(reading.sensorId, readings);
  
  // Update baseline
  updateBaseline(reading.sensorId, typeof reading.value === 'number' ? reading.value : 0);
  
  // Check thresholds
  checkThresholds(fullReading);
  
  return fullReading;
}

/**
 * Get readings for a sensor
 */
export function getReadings(sensorId: string, limit: number = 100): SensorReading[] {
  const readings = sensorReadings.get(sensorId) || [];
  return readings.slice(-limit);
}

/**
 * Get latest reading for each sensor
 */
export function getLatestReadings(): Record<SensorType, SensorReading | null> {
  const latest: Record<SensorType, SensorReading | null> = {
    network: null,
    file: null,
    process: null,
    api: null,
    behavior: null,
    memory: null,
    runtime: null
  };
  
  for (const [id, readings] of sensorReadings.entries()) {
    const sensor = sensorConfigs.get(id);
    if (sensor && readings.length > 0) {
      latest[sensor.type] = readings[readings.length - 1];
    }
  }
  
  return latest;
}

// ============================================================================
// THRESHOLD CHECKING
// ============================================================================

/**
 * Check if reading exceeds thresholds
 */
function checkThresholds(reading: SensorReading): void {
  const sensor = sensorConfigs.get(reading.sensorId);
  if (!sensor || !sensor.enabled) return;
  
  const value = typeof reading.value === 'number' ? reading.value : 0;
  
  for (const [key, threshold] of Object.entries(sensor.thresholds)) {
    if (value > threshold) {
      emitSensorAlert({
        sensorId: reading.sensorId,
        sensorType: reading.sensorType,
        severity: sensor.sensitivity === 'critical' ? 'critical' : 
                  sensor.sensitivity === 'high' ? 'high' : 'warning',
        message: `${key} exceeded threshold: ${value} > ${threshold}`,
        value,
        threshold
      });
    }
  }
}

/**
 * Emit sensor alert
 */
function emitSensorAlert(alert: Omit<SensorAlert, 'id' | 'timestamp' | 'acknowledged'>): SensorAlert {
  const fullAlert: SensorAlert = {
    ...alert,
    id: `alert_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    timestamp: Date.now(),
    acknowledged: false
  };
  
  const alerts = sensorAlerts.get(alert.sensorId) || [];
  alerts.push(fullAlert);
  
  // Keep only last 100 alerts per sensor
  if (alerts.length > 100) {
    alerts.shift();
  }
  
  sensorAlerts.set(alert.sensorId, alerts);
  
  return fullAlert;
}

/**
 * Get sensor alerts
 */
export function getSensorAlerts(sensorId?: string): SensorAlert[] {
  if (sensorId) {
    return sensorAlerts.get(sensorId) || [];
  }
  
  return Array.from(sensorAlerts.values()).flat();
}

/**
 * Acknowledge alert
 */
export function acknowledgeSensorAlert(alertId: string): boolean {
  for (const [sensorId, alerts] of sensorAlerts.entries()) {
    const alert = alerts.find(a => a.id === alertId);
    if (alert) {
      alert.acknowledged = true;
      sensorAlerts.set(sensorId, alerts);
      return true;
    }
  }
  return false;
}

// ============================================================================
// BASELINE & ANOMALY DETECTION
// ============================================================================

/**
 * Update baseline statistics
 */
function updateBaseline(sensorId: string, value: number): void {
  const baseline = baselines.get(sensorId) || { mean: 0, stdDev: 0, samples: 0 };
  
  // Online mean and standard deviation calculation (Welford's algorithm)
  const n = baseline.samples + 1;
  const delta = value - baseline.mean;
  const newMean = baseline.mean + delta / n;
  const delta2 = value - newMean;
  
  baseline.mean = newMean;
  baseline.stdDev = Math.sqrt((baseline.stdDev * baseline.stdDev * (n - 1) + delta * delta2) / n);
  baseline.samples = n;
  
  baselines.set(sensorId, baseline);
}

/**
 * Get baseline for sensor
 */
export function getBaseline(sensorId: string): { mean: number; stdDev: number; samples: number } | undefined {
  return baselines.get(sensorId);
}

/**
 * Calculate anomaly score (z-score based)
 */
export function calculateAnomalyScore(sensorId: string, value: number): number {
  const baseline = baselines.get(sensorId);
  if (!baseline || baseline.samples < 10 || baseline.stdDev === 0) {
    return 0;
  }
  
  const zScore = Math.abs((value - baseline.mean) / baseline.stdDev);
  return Math.min(1, zScore / 3); // Normalize to 0-1 range
}

// ============================================================================
// SPECIALIZED SENSOR DATA COLLECTION
// ============================================================================

/**
 * Collect network sensor data
 */
export function collectNetworkData(): NetworkSensorData {
  // Simulated data - in production would use actual network monitoring
  const baseConnections = Math.floor(Math.random() * 50) + 20;
  const suspiciousCount = Math.floor(Math.random() * 3);
  
  const suspiciousIPs = [];
  for (let i = 0; i < suspiciousCount; i++) {
    suspiciousIPs.push({
      ip: `${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
      port: [22, 23, 4444, 5555, 6666, 8080][Math.floor(Math.random() * 6)],
      reason: ['Unusual port', 'High frequency', 'Known malicious IP', 'Port scan detected'][Math.floor(Math.random() * 4)]
    });
  }
  
  return {
    connections: baseConnections,
    inboundBytes: Math.floor(Math.random() * 10000000) + 1000000,
    outboundBytes: Math.floor(Math.random() * 5000000) + 500000,
    packetsPerSecond: Math.floor(Math.random() * 1000) + 100,
    uniqueIPs: Math.floor(Math.random() * 30) + 10,
    blockedConnections: suspiciousCount,
    suspiciousConnections: suspiciousIPs,
    topProtocols: {
      'HTTPS': 65,
      'HTTP': 20,
      'SSH': 5,
      'DNS': 8,
      'Other': 2
    }
  };
}

/**
 * Collect file sensor data
 */
export function collectFileData(): FileSensorData {
  const suspiciousFiles = [];
  const suspiciousCount = Math.floor(Math.random() * 2);
  
  const actions = ['modified', 'created', 'deleted', 'renamed'];
  const reasons = ['Rapid changes', 'Suspicious extension', 'Hidden file', 'Unusual location'];
  
  for (let i = 0; i < suspiciousCount; i++) {
    suspiciousFiles.push({
      path: `/app/data/${['config', 'secrets', 'temp', 'cache'][Math.floor(Math.random() * 4)]}/${Math.random().toString(36).substr(2, 8)}.dat`,
      action: actions[Math.floor(Math.random() * actions.length)],
      reason: reasons[Math.floor(Math.random() * reasons.length)]
    });
  }
  
  return {
    filesAccessed: Math.floor(Math.random() * 1000) + 500,
    filesModified: Math.floor(Math.random() * 100) + 20,
    filesCreated: Math.floor(Math.random() * 50) + 10,
    filesDeleted: Math.floor(Math.random() * 20) + 5,
    suspiciousFiles,
    watchedPaths: ['/app', '/config', '/data', '/logs'],
    hashMismatches: Math.floor(Math.random() * 3)
  };
}

/**
 * Collect process sensor data
 */
export function collectProcessData(): ProcessSensorData {
  const suspiciousProcesses = [];
  const suspiciousCount = Math.floor(Math.random() * 2);
  
  for (let i = 0; i < suspiciousCount; i++) {
    suspiciousProcesses.push({
      pid: Math.floor(Math.random() * 65535) + 1000,
      name: ['unknown_proc', 'suspicious_daemon', 'unnamed_task'][Math.floor(Math.random() * 3)],
      reason: ['High CPU usage', 'Memory leak detected', 'Unknown process', 'Privilege escalation attempt'][Math.floor(Math.random() * 4)],
      cpu: Math.random() * 80 + 20,
      memory: Math.random() * 500 + 100
    });
  }
  
  return {
    activeProcesses: Math.floor(Math.random() * 50) + 30,
    cpuUsage: Math.random() * 60 + 10,
    memoryUsage: Math.random() * 40 + 30,
    suspiciousProcesses,
    childProcesses: Math.floor(Math.random() * 20) + 5,
    zombieProcesses: Math.floor(Math.random() * 3)
  };
}

/**
 * Collect API sensor data
 */
export function collectAPIData(): APISensorData {
  const suspiciousPatterns = [];
  const patternCount = Math.floor(Math.random() * 3);
  
  const patterns = ['sql_injection', 'xss_attempt', 'path_traversal', 'rate_abuse', 'auth_bypass'];
  const endpoints = ['/api/users', '/api/data', '/api/admin', '/api/config', '/api/auth'];
  
  for (let i = 0; i < patternCount; i++) {
    suspiciousPatterns.push({
      pattern: patterns[Math.floor(Math.random() * patterns.length)],
      count: Math.floor(Math.random() * 10) + 1,
      endpoint: endpoints[Math.floor(Math.random() * endpoints.length)]
    });
  }
  
  const slowEndpoints = endpoints.slice(0, 3).map(e => ({
    endpoint: e,
    avgTime: Math.random() * 2000 + 500
  }));
  
  return {
    requestsPerMinute: Math.floor(Math.random() * 1000) + 100,
    avgResponseTime: Math.random() * 200 + 20,
    errorRate: Math.random() * 5,
    authFailures: Math.floor(Math.random() * 20),
    rateLimitHits: Math.floor(Math.random() * 30),
    suspiciousPatterns,
    topEndpoints: {
      '/api/detect': 450,
      '/api/detections': 230,
      '/api/health': 180,
      '/api/auth': 120,
      '/api/status': 85
    },
    slowEndpoints
  };
}

/**
 * Collect behavior sensor data
 */
export function collectBehaviorData(): BehaviorSensorData {
  const riskIndicators = [];
  const indicatorCount = Math.floor(Math.random() * 3);
  
  const types = ['unusual_time', 'high_volume', 'new_location', 'rapid_requests', 'suspicious_pattern'];
  
  for (let i = 0; i < indicatorCount; i++) {
    riskIndicators.push({
      type: types[Math.floor(Math.random() * types.length)],
      score: Math.random() * 100,
      description: 'Detected deviation from normal behavior pattern'
    });
  }
  
  return {
    anomalyScore: Math.random() * 100,
    deviationFromBaseline: Math.random() * 50,
    unusualActivityPatterns: riskIndicators.map(r => r.type),
    riskIndicators,
    timeBasedAnomalies: []
  };
}

/**
 * Collect memory sensor data
 */
export function collectMemoryData(): MemorySensorData {
  const memoryLeaks = [];
  const leakCount = Math.floor(Math.random() * 2);
  
  for (let i = 0; i < leakCount; i++) {
    memoryLeaks.push({
      process: ['main', 'worker', 'api_handler'][Math.floor(Math.random() * 3)],
      growth: Math.random() * 50 + 10
    });
  }
  
  return {
    totalMemory: 4096,
    usedMemory: Math.random() * 2000 + 1500,
    peakMemory: Math.random() * 500 + 2000,
    memoryLeaks,
    heapUsage: Math.random() * 100,
    bufferUsage: Math.random() * 50
  };
}

/**
 * Collect runtime sensor data
 */
export function collectRuntimeData(): RuntimeSensorData {
  const exceptions = [];
  const exceptionCount = Math.floor(Math.random() * 3);
  
  const exceptionTypes = ['TypeError', 'ReferenceError', 'NetworkError', 'TimeoutError', 'ValidationError'];
  
  for (let i = 0; i < exceptionCount; i++) {
    exceptions.push({
      type: exceptionTypes[Math.floor(Math.random() * exceptionTypes.length)],
      message: 'An error occurred during processing',
      count: Math.floor(Math.random() * 10) + 1
    });
  }
  
  return {
    uptime: Date.now() - (Math.random() * 86400000 * 7), // Up to 7 days
    errors: Math.floor(Math.random() * 50),
    warnings: Math.floor(Math.random() * 100),
    exceptions,
    slowOperations: [
      { operation: 'deepfake_analysis', duration: 2500 },
      { operation: 'file_upload', duration: 1500 }
    ],
    resourceContention: Math.random() > 0.9
  };
}

// ============================================================================
// DATA AGGREGATION
// ============================================================================

/**
 * Get all sensor data
 */
export function getSensorData(
  type: string = 'all',
  timeRange: string = '1h'
): Record<string, unknown> {
  const now = Date.now();
  const rangeMs: Record<string, number> = {
    '1h': 60 * 60 * 1000,
    '6h': 6 * 60 * 60 * 1000,
    '24h': 24 * 60 * 60 * 1000,
    '7d': 7 * 24 * 60 * 60 * 1000,
    '30d': 30 * 24 * 60 * 60 * 1000
  };
  
  const cutoff = now - (rangeMs[timeRange] || rangeMs['1h']);
  
  const data: Record<string, unknown> = {
    timestamp: now,
    timeRange,
    sensors: listSensors().map(s => ({
      id: s.id,
      type: s.type,
      name: s.name,
      enabled: s.enabled,
      sensitivity: s.sensitivity
    }))
  };
  
  if (type === 'all' || type === 'network') {
    data.network = collectNetworkData();
  }
  
  if (type === 'all' || type === 'file') {
    data.file = collectFileData();
  }
  
  if (type === 'all' || type === 'process') {
    data.process = collectProcessData();
  }
  
  if (type === 'all' || type === 'api') {
    data.api = collectAPIData();
  }
  
  if (type === 'all' || type === 'behavior') {
    data.behavior = collectBehaviorData();
  }
  
  if (type === 'all' || type === 'memory') {
    data.memory = collectMemoryData();
  }
  
  if (type === 'all' || type === 'runtime') {
    data.runtime = collectRuntimeData();
  }
  
  // Filter readings by time range
  data.readings = {};
  for (const [sensorId, readings] of sensorReadings.entries()) {
    data.readings[sensorId] = readings.filter(r => r.timestamp >= cutoff);
  }
  
  // Filter alerts by time range
  data.alerts = getSensorAlerts().filter(a => a.timestamp >= cutoff);
  
  return data;
}

// ============================================================================
// INITIALIZATION
// ============================================================================

// Initialize default sensors
function initializeDefaultSensors(): void {
  registerSensor({
    type: 'network',
    name: 'Network Monitor',
    enabled: true,
    interval: 5000,
    sensitivity: 'medium',
    thresholds: {
      connections: 100,
      blockedConnections: 10,
      packetsPerSecond: 10000
    },
    actions: [
      { condition: 'blockedConnections > 5', action: 'alert' },
      { condition: 'connections > 100', action: 'log' }
    ]
  });
  
  registerSensor({
    type: 'file',
    name: 'File System Monitor',
    enabled: true,
    interval: 10000,
    sensitivity: 'high',
    thresholds: {
      filesModified: 500,
      hashMismatches: 1
    },
    actions: [
      { condition: 'hashMismatches > 0', action: 'alert' },
      { condition: 'suspiciousFiles > 0', action: 'block' }
    ]
  });
  
  registerSensor({
    type: 'process',
    name: 'Process Monitor',
    enabled: true,
    interval: 5000,
    sensitivity: 'medium',
    thresholds: {
      cpuUsage: 80,
      memoryUsage: 90,
      suspiciousProcesses: 1
    },
    actions: [
      { condition: 'suspiciousProcesses > 0', action: 'alert' },
      { condition: 'cpuUsage > 90', action: 'log' }
    ]
  });
  
  registerSensor({
    type: 'api',
    name: 'API Monitor',
    enabled: true,
    interval: 1000,
    sensitivity: 'high',
    thresholds: {
      errorRate: 10,
      authFailures: 50,
      avgResponseTime: 1000
    },
    actions: [
      { condition: 'authFailures > 20', action: 'alert' },
      { condition: 'errorRate > 5', action: 'alert' }
    ]
  });
  
  registerSensor({
    type: 'behavior',
    name: 'Behavior Analyzer',
    enabled: true,
    interval: 30000,
    sensitivity: 'high',
    thresholds: {
      anomalyScore: 70,
      deviationFromBaseline: 50
    },
    actions: [
      { condition: 'anomalyScore > 80', action: 'alert' },
      { condition: 'riskIndicators > 3', action: 'block' }
    ]
  });
  
  registerSensor({
    type: 'memory',
    name: 'Memory Monitor',
    enabled: true,
    interval: 10000,
    sensitivity: 'medium',
    thresholds: {
      usedMemory: 3500,
      memoryLeaks: 1
    },
    actions: [
      { condition: 'memoryLeaks > 0', action: 'alert' },
      { condition: 'usedMemory > 3500', action: 'log' }
    ]
  });
  
  registerSensor({
    type: 'runtime',
    name: 'Runtime Monitor',
    enabled: true,
    interval: 5000,
    sensitivity: 'medium',
    thresholds: {
      errors: 100,
      resourceContention: 1
    },
    actions: [
      { condition: 'errors > 50', action: 'alert' },
      { condition: 'resourceContention > 0', action: 'log' }
    ]
  });
}

// Initialize on load
initializeDefaultSensors();

// ============================================================================
// DEFAULT EXPORT
// ============================================================================

const sensors = {
  // Configuration
  registerSensor,
  getSensorConfig,
  listSensors,
  updateSensorConfig,
  setSensorEnabled,
  
  // Readings
  recordReading,
  getReadings,
  getLatestReadings,
  
  // Alerts
  getSensorAlerts,
  acknowledgeSensorAlert,
  
  // Baseline & Anomaly
  getBaseline,
  calculateAnomalyScore,
  
  // Data Collection
  collectNetworkData,
  collectFileData,
  collectProcessData,
  collectAPIData,
  collectBehaviorData,
  collectMemoryData,
  collectRuntimeData,
  
  // Aggregation
  getSensorData
};

export default sensors;
