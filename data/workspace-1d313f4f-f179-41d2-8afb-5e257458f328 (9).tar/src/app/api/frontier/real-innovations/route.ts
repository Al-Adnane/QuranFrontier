/**
 * API Route: Real Frontier Innovations Status
 * 
 * Returns the status of the 3 REAL frontier innovations
 * with verification results.
 */

import { NextRequest, NextResponse } from 'next/server';
import { calculateHonestNoveltyScore } from '@/lib/frontier/real-novelty-score';
import { getRealAdversarialStatus } from '@/lib/frontier/real-adversarial-certification';
import { getRealZKStatus } from '@/lib/frontier/real-zk-proofs';
import { getIntentClassifierStatus } from '@/lib/frontier/intent-classifier';

export async function GET(request: NextRequest) {
  try {
    // Calculate honest novelty score
    const noveltyScore = calculateHonestNoveltyScore();
    
    // Get status of each real implementation
    const adversarialStatus = getRealAdversarialStatus();
    const zkStatus = getRealZKStatus();
    const intentStatus = getIntentClassifierStatus();
    
    // Build response
    const response = {
      timestamp: new Date().toISOString(),
      
      // Overall novelty score
      noveltyScore: {
        overall: noveltyScore.overall,
        grade: noveltyScore.grade,
        category: noveltyScore.category,
        targetMet: noveltyScore.overall >= 90
      },
      
      // Breakdown
      breakdown: {
        baseScore: noveltyScore.breakdown.baseScore,
        frontierContributions: {
          adversarialCertification: {
            points: noveltyScore.breakdown.frontierContributions.adversarialCertification.points,
            verified: noveltyScore.breakdown.frontierContributions.adversarialCertification.verified,
            evidence: noveltyScore.breakdown.frontierContributions.adversarialCertification.evidence
          },
          zkProofs: {
            points: noveltyScore.breakdown.frontierContributions.zkProofs.points,
            verified: noveltyScore.breakdown.frontierContributions.zkProofs.verified,
            evidence: noveltyScore.breakdown.frontierContributions.zkProofs.evidence
          },
          intentClassifier: {
            points: noveltyScore.breakdown.frontierContributions.intentClassifier.points,
            verified: noveltyScore.breakdown.frontierContributions.intentClassifier.verified,
            evidence: noveltyScore.breakdown.frontierContributions.intentClassifier.evidence
          }
        },
        existingMoats: noveltyScore.breakdown.existingMoats
      },
      
      // Verification details
      verifications: noveltyScore.verifications.map(v => ({
        moduleName: v.moduleName,
        isReal: v.isReal,
        evidence: v.evidence,
        missingComponents: v.missingComponents,
        verificationMethod: v.verificationMethod
      })),
      
      // Implementation details
      implementations: {
        adversarialCertification: adversarialStatus,
        zkProofs: zkStatus,
        intentClassifier: intentStatus
      },
      
      // Recommendations
      recommendations: noveltyScore.recommendations,
      
      // Competitive analysis
      competitiveAnalysis: noveltyScore.comparisonWithCompetitors
    };
    
    return NextResponse.json(response);
    
  } catch (error) {
    console.error('Error calculating novelty score:', error);
    return NextResponse.json(
      { error: 'Failed to calculate novelty score', details: String(error) },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action } = body;
    
    switch (action) {
      case 'verify_all':
        // Re-run all verifications
        const score = calculateHonestNoveltyScore();
        return NextResponse.json({
          success: true,
          score: score.overall,
          verifications: score.verifications
        });
        
      case 'get_details':
        // Get detailed breakdown
        const detailed = calculateHonestNoveltyScore();
        return NextResponse.json({
          success: true,
          details: detailed
        });
        
      default:
        return NextResponse.json(
          { error: 'Unknown action' },
          { status: 400 }
        );
    }
  } catch {
    return NextResponse.json(
      { error: 'Failed to process request' },
      { status: 500 }
    );
  }
}
