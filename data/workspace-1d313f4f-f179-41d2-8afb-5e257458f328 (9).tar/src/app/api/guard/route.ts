/**
 * Kasbah Guard API - Security Layer Endpoint
 * @module api/guard
 */

import { NextRequest, NextResponse } from 'next/server';

// ============================================================================
// GET HANDLER
// ============================================================================

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const action = searchParams.get('action') || 'status';

  try {
    const kasbahGuard = await import('@/lib/kasbah-guard');
    
    switch (action) {
      case 'status':
        return NextResponse.json(kasbahGuard.getGuardStatus());

      case 'dashboard':
        return NextResponse.json(kasbahGuard.getDashboardData());

      case 'credits':
        const creditStatus = kasbahGuard.credits.getCreditStatus(
          searchParams.get('appId') || undefined
        );
        return NextResponse.json(creditStatus);

      case 'sensors':
        const sensorData = kasbahGuard.sensors.getSensorData(
          searchParams.get('type') || 'all',
          searchParams.get('range') || '1h'
        );
        return NextResponse.json(sensorData);

      case 'apps':
        const apps = kasbahGuard.protectedApps.listProtectedApps();
        const stats = kasbahGuard.protectedApps.getProtectionStats();
        return NextResponse.json({ apps, stats });

      case 'threats':
        const threats = kasbahGuard.threatManager.getDetections(100);
        const blocklist = kasbahGuard.threatManager.listBlocks();
        const detStats = kasbahGuard.threatManager.getDetectionStats();
        return NextResponse.json({
          detections: threats,
          blocklist,
          stats: detStats
        });

      case 'mcp-status':
        return NextResponse.json(kasbahGuard.mcp.getMCPServerStatus());

      case 'scan-stats':
        return NextResponse.json(kasbahGuard.appScanner.getScanStatistics());

      default:
        return NextResponse.json(kasbahGuard.getGuardStatus());
    }
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to get guard data', message: String(error) },
      { status: 500 }
    );
  }
}

// ============================================================================
// POST HANDLER
// ============================================================================

export async function POST(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const action = searchParams.get('action') || 'status';
  const body = await request.json().catch(() => ({}));

  try {
    const kasbahGuard = await import('@/lib/kasbah-guard');
    
    switch (action) {
      case 'scan':
        const scanResult = await kasbahGuard.appScanner.scanApplication(
          body.target || '',
          body.scanType || 'standard'
        );
        return NextResponse.json(scanResult);

      case 'quick-check':
        const quickResult = await kasbahGuard.quickSecurityCheck(body.target || '');
        return NextResponse.json(quickResult);

      case 'add-app':
        const newApp = kasbahGuard.protectedApps.addProtectedApp({
          name: body.name,
          path: body.path,
          type: body.type,
          policy: body.policy,
          creditLimit: body.creditLimit
        });
        return NextResponse.json({ success: true, app: newApp });

      case 'remove-app':
        const removed = kasbahGuard.protectedApps.removeProtectedApp(body.appId);
        return NextResponse.json({ success: removed });

      case 'block':
        const block = kasbahGuard.threatManager.blockThreat({
          type: body.type,
          value: body.value,
          reason: body.reason,
          duration: body.duration
        });
        return NextResponse.json({ success: true, block });

      case 'unblock':
        const unblocked = kasbahGuard.threatManager.unblockThreat(body.value);
        return NextResponse.json({ success: unblocked });

      case 'threat-intel':
        const intel = await kasbahGuard.threatIntel.getThreatIntel(body.query || '');
        return NextResponse.json(intel);

      case 'set-credit-limit':
        kasbahGuard.credits.setCreditLimit(body.appId, body.limit);
        return NextResponse.json({ success: true });

      case 'generate-report':
        const report = await kasbahGuard.reports.generateReport(
          body.type || 'summary',
          body.format || 'json',
          body.timeRange || '7d'
        );
        return NextResponse.json({ report });

      case 'mcp-execute':
        const result = await kasbahGuard.mcp.handleCallTool(body.tool || '', body.args || {});
        return NextResponse.json(result);

      default:
        return NextResponse.json({ error: 'Unknown action' }, { status: 400 });
    }
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to process request', message: String(error) },
      { status: 500 }
    );
  }
}
