/**
 * API Gateway Control Layer
 * 
 * Unified control for internal and external APIs.
 * Controls what agents can consume, from which APIs, with what limits.
 * 
 * @module api/gateway
 * @version 1.0.0
 */

import { NextRequest, NextResponse } from 'next/server';
import * as apiGateway from '@/lib/frontier/api-gateway';
import * as agentDelegation from '@/lib/frontier/agent-delegation';

// ============================================================================
// GET HANDLER
// ============================================================================

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const action = searchParams.get('action') || 'status';

  switch (action) {
    case 'status':
    case 'statistics':
      const stats = apiGateway.getGatewayStatistics();
      return NextResponse.json({
        status: 'operational',
        timestamp: Date.now(),
        version: '1.0.0',
        statistics: stats,
        features: [
          'provider-management',
          'api-key-management',
          'spending-allocation',
          'circuit-breaker',
          'rate-limiting',
          'caching',
          'audit-logging',
          'request-execution'
        ]
      });

    case 'providers':
      const providerType = searchParams.get('type');
      const providers = providerType 
        ? apiGateway.getProvidersByType(providerType as apiGateway.APIProvider)
        : apiGateway.getActiveProviders();
      return NextResponse.json({
        success: true,
        providers: providers.map(p => ({
          id: p.id,
          provider: p.provider,
          name: p.name,
          status: p.status,
          baseUrl: p.baseUrl,
          features: p.features,
          lastHealthCheck: p.lastHealthCheck
        }))
      });

    case 'provider':
      const providerId = searchParams.get('id');
      if (!providerId) {
        return NextResponse.json({ error: 'Missing provider id' }, { status: 400 });
      }
      const provider = apiGateway.getProvider(providerId);
      if (!provider) {
        return NextResponse.json({ error: 'Provider not found' }, { status: 404 });
      }
      return NextResponse.json({ success: true, provider });

    case 'health-check':
      const healthProviderId = searchParams.get('providerId');
      if (!healthProviderId) {
        return NextResponse.json({ error: 'Missing providerId' }, { status: 400 });
      }
      const healthResult = await apiGateway.checkProviderHealth(healthProviderId);
      return NextResponse.json({
        success: true,
        providerId: healthProviderId,
        health: healthResult
      });

    case 'circuit-breaker':
      const cbProviderId = searchParams.get('providerId');
      if (!cbProviderId) {
        return NextResponse.json({ error: 'Missing providerId' }, { status: 400 });
      }
      const cbState = apiGateway.checkCircuitBreaker(cbProviderId);
      return NextResponse.json({
        success: true,
        providerId: cbProviderId,
        circuitBreaker: cbState
      });

    case 'rate-limit':
      const rlProviderId = searchParams.get('providerId');
      if (!rlProviderId) {
        return NextResponse.json({ error: 'Missing providerId' }, { status: 400 });
      }
      const rlState = apiGateway.checkRateLimit(rlProviderId);
      return NextResponse.json({
        success: true,
        providerId: rlProviderId,
        rateLimit: rlState
      });

    case 'spending':
      const spendingAgentId = searchParams.get('agentId');
      const spendingProviderId = searchParams.get('providerId');
      if (!spendingAgentId || !spendingProviderId) {
        return NextResponse.json({ error: 'Missing agentId or providerId' }, { status: 400 });
      }
      const allocation = apiGateway.getSpendingAllocation(spendingAgentId, spendingProviderId);
      return NextResponse.json({
        success: true,
        allocation: allocation ? {
          id: allocation.id,
          dailyBudgetCents: allocation.dailyBudgetCents,
          monthlyBudgetCents: allocation.monthlyBudgetCents,
          dailySpentCents: allocation.dailySpentCents,
          monthlySpentCents: allocation.monthlySpentCents,
          status: allocation.status
        } : null
      });

    case 'audit-log':
      const auditFilters = {
        agentId: searchParams.get('agentId') || undefined,
        principalId: searchParams.get('principalId') || undefined,
        providerId: searchParams.get('providerId') || undefined,
        action: searchParams.get('auditAction') as apiGateway.AuditLogEntry['action'] | undefined,
        from: searchParams.get('from') ? parseInt(searchParams.get('from')!) : undefined,
        to: searchParams.get('to') ? parseInt(searchParams.get('to')!) : undefined
      };
      const limit = parseInt(searchParams.get('limit') || '100');
      const auditEntries = apiGateway.getAuditLog(auditFilters, limit);
      return NextResponse.json({
        success: true,
        entries: auditEntries,
        count: auditEntries.length
      });

    case 'config':
      const config = apiGateway.getGatewayConfig();
      return NextResponse.json({
        success: true,
        config
      });

    case 'tests':
      const testResults = apiGateway.runAPIGatewayTests();
      return NextResponse.json(testResults);

    default:
      return NextResponse.json({
        error: 'Unknown action',
        availableActions: [
          'status', 'statistics', 'providers', 'provider', 'health-check',
          'circuit-breaker', 'rate-limit', 'spending', 'audit-log', 'config', 'tests'
        ]
      }, { status: 400 });
  }
}

// ============================================================================
// POST HANDLER
// ============================================================================

export async function POST(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const action = searchParams.get('action') || 'status';
  const body = await request.json().catch(() => ({}));

  switch (action) {
    // ========================================================================
    // PROVIDER MANAGEMENT
    // ========================================================================

    case 'register-provider':
      if (!body.provider || !body.name || !body.authType || !body.baseUrl) {
        return NextResponse.json({
          error: 'Missing required fields: provider, name, authType, baseUrl'
        }, { status: 400 });
      }
      const newProvider = apiGateway.registerProvider({
        provider: body.provider,
        name: body.name,
        description: body.description,
        authType: body.authType,
        authConfig: body.authConfig || {},
        baseUrl: body.baseUrl,
        endpoints: body.endpoints || {},
        features: body.features || {
          streaming: false,
          batching: false,
          async: false,
          webhooks: false
        },
        healthCheck: body.healthCheck || {
          intervalMs: 60000,
          timeoutMs: 5000
        }
      });
      return NextResponse.json({
        success: true,
        provider: {
          id: newProvider.id,
          provider: newProvider.provider,
          name: newProvider.name,
          status: newProvider.status
        }
      });

    case 'update-provider-status':
      if (!body.providerId || !body.status) {
        return NextResponse.json({
          error: 'Missing required fields: providerId, status'
        }, { status: 400 });
      }
      const statusUpdated = apiGateway.updateProviderStatus(
        body.providerId,
        body.status,
        body.error
      );
      return NextResponse.json({
        success: statusUpdated,
        message: statusUpdated ? 'Provider status updated' : 'Provider not found'
      });

    // ========================================================================
    // API KEY MANAGEMENT
    // ========================================================================

    case 'store-api-key':
      if (!body.providerId || !body.name || !body.key) {
        return NextResponse.json({
          error: 'Missing required fields: providerId, name, key'
        }, { status: 400 });
      }
      const newKey = apiGateway.storeAPIKey(
        body.providerId,
        body.name,
        body.key,
        {
          permissions: body.permissions,
          scopes: body.scopes,
          rotationDays: body.rotationDays,
          expiresAt: body.expiresAt,
          ipWhitelist: body.ipWhitelist
        }
      );
      if (!newKey) {
        return NextResponse.json({ error: 'Failed to store API key' }, { status: 500 });
      }
      return NextResponse.json({
        success: true,
        key: {
          id: newKey.id,
          name: newKey.name,
          keyPrefix: newKey.keyPrefix,
          rotationEnabled: newKey.rotationEnabled,
          status: newKey.status
        }
      });

    case 'rotate-api-key':
      if (!body.keyId || !body.newKey) {
        return NextResponse.json({
          error: 'Missing required fields: keyId, newKey'
        }, { status: 400 });
      }
      const rotatedKey = apiGateway.rotateAPIKey(body.keyId, body.newKey);
      if (!rotatedKey) {
        return NextResponse.json({ error: 'Failed to rotate API key' }, { status: 500 });
      }
      return NextResponse.json({
        success: true,
        key: {
          id: rotatedKey.id,
          name: rotatedKey.name,
          keyPrefix: rotatedKey.keyPrefix
        }
      });

    // ========================================================================
    // SPENDING ALLOCATION
    // ========================================================================

    case 'create-spending-allocation':
      if (!body.agentId || !body.principalId || !body.providerId) {
        return NextResponse.json({
          error: 'Missing required fields: agentId, principalId, providerId'
        }, { status: 400 });
      }
      const newAllocation = apiGateway.createSpendingAllocation(
        body.agentId,
        body.principalId,
        body.providerId,
        {
          dailyBudgetCents: body.dailyBudgetCents,
          monthlyBudgetCents: body.monthlyBudgetCents,
          maxRequestsPerDay: body.maxRequestsPerDay,
          maxTokensPerDay: body.maxTokensPerDay
        }
      );
      if (!newAllocation) {
        return NextResponse.json({ error: 'Failed to create spending allocation' }, { status: 500 });
      }
      return NextResponse.json({
        success: true,
        allocation: {
          id: newAllocation.id,
          dailyBudgetCents: newAllocation.dailyBudgetCents,
          monthlyBudgetCents: newAllocation.monthlyBudgetCents,
          status: newAllocation.status
        }
      });

    case 'check-spending':
      if (!body.agentId || !body.providerId) {
        return NextResponse.json({
          error: 'Missing required fields: agentId, providerId'
        }, { status: 400 });
      }
      const spendingCheck = apiGateway.checkSpendingAllowed(
        body.agentId,
        body.providerId,
        body.estimatedCostCents || 1,
        body.estimatedTokens || 0
      );
      return NextResponse.json({
        success: true,
        check: spendingCheck
      });

    // ========================================================================
    // RATE LIMITING
    // ========================================================================

    case 'check-rate-limit':
      if (!body.providerId) {
        return NextResponse.json({
          error: 'Missing required field: providerId'
        }, { status: 400 });
      }
      const rateLimitCheck = apiGateway.checkRateLimit(
        body.providerId,
        body.endpoint,
        body.tokens
      );
      return NextResponse.json({
        success: true,
        check: rateLimitCheck
      });

    // ========================================================================
    // CACHING
    // ========================================================================

    case 'invalidate-cache':
      if (!body.tags || !Array.isArray(body.tags)) {
        return NextResponse.json({
          error: 'Missing required field: tags (array)'
        }, { status: 400 });
      }
      const invalidated = apiGateway.invalidateCacheByTags(body.tags);
      return NextResponse.json({
        success: true,
        invalidated
      });

    // ========================================================================
    // CONFIGURATION
    // ========================================================================

    case 'update-config':
      const updatedConfig = apiGateway.updateGatewayConfig(body);
      return NextResponse.json({
        success: true,
        config: updatedConfig
      });

    // ========================================================================
    // REQUEST EXECUTION
    // ========================================================================

    case 'execute-request':
      if (!body.agentId || !body.principalId || !body.providerId || !body.endpoint) {
        return NextResponse.json({
          error: 'Missing required fields: agentId, principalId, providerId, endpoint'
        }, { status: 400 });
      }
      
      // First, verify agent authorization via delegation system
      const authCheck = agentDelegation.checkAPIAccess(
        body.agentId,
        body.apiCategory || 'detection',
        body.action || 'execute',
        body.resource
      );
      
      if (!authCheck.allowed) {
        return NextResponse.json({
          error: 'Agent not authorized',
          reason: authCheck.reason
        }, { status: 403 });
      }
      
      // Check consumption
      const consumptionCheck = agentDelegation.checkConsumptionAllowed(
        body.agentId,
        body.resourceType || 'api_calls',
        body.estimatedAmount || 1
      );
      
      if (!consumptionCheck.allowed) {
        return NextResponse.json({
          error: 'Consumption not allowed',
          reason: consumptionCheck.reason
        }, { status: 403 });
      }
      
      // Execute the request
      const response = await apiGateway.executeRequest(
        body.agentId,
        body.principalId,
        body.providerId,
        body.endpoint,
        {
          method: body.method,
          body: body.body,
          headers: body.headers,
          queryParams: body.queryParams,
          timeout: body.timeout,
          maxRetries: body.maxRetries,
          skipCache: body.skipCache,
          purpose: body.purpose,
          authorizationId: consumptionCheck.authorizationId || '',
          delegationId: authCheck.delegationId,
          estimatedCostCents: body.estimatedCostCents,
          estimatedTokens: body.estimatedTokens
        }
      );
      
      // Record consumption
      if (consumptionCheck.authorizationId && response.success) {
        agentDelegation.recordConsumption(
          consumptionCheck.authorizationId,
          body.agentId,
          body.principalId,
          body.resourceType || 'api_calls',
          body.estimatedAmount || 1,
          {
            apiEndpoint: body.endpoint,
            apiCategory: body.apiCategory,
            durationMs: response.latencyMs,
            success: response.success
          }
        );
      }
      
      return NextResponse.json({
        success: response.success,
        response: {
          id: response.id,
          statusCode: response.statusCode,
          latencyMs: response.latencyMs,
          cached: response.cached,
          promptTokens: response.promptTokens,
          completionTokens: response.completionTokens,
          totalTokens: response.totalTokens,
          costCents: response.costCents,
          body: response.body,
          error: response.errorMessage
        }
      });

    // ========================================================================
    // CIRCUIT BREAKER
    // ========================================================================

    case 'record-circuit-success':
      if (!body.providerId) {
        return NextResponse.json({
          error: 'Missing required field: providerId'
        }, { status: 400 });
      }
      apiGateway.recordCircuitSuccess(body.providerId);
      return NextResponse.json({ success: true });

    case 'record-circuit-failure':
      if (!body.providerId) {
        return NextResponse.json({
          error: 'Missing required field: providerId'
        }, { status: 400 });
      }
      apiGateway.recordCircuitFailure(body.providerId);
      return NextResponse.json({ success: true });

    // ========================================================================
    // TESTS
    // ========================================================================

    case 'run-tests':
      const testResults = apiGateway.runAPIGatewayTests();
      return NextResponse.json(testResults);

    default:
      return NextResponse.json({
        error: 'Unknown action',
        availableActions: [
          'register-provider', 'update-provider-status',
          'store-api-key', 'rotate-api-key',
          'create-spending-allocation', 'check-spending',
          'check-rate-limit',
          'invalidate-cache',
          'update-config',
          'execute-request',
          'record-circuit-success', 'record-circuit-failure',
          'run-tests'
        ]
      }, { status: 400 });
  }
}
