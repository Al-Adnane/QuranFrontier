'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Shield, ShieldAlert, ShieldCheck, ShieldX,
  Activity, AlertTriangle, BarChart3, 
  Settings, Zap, Lock, Unlock, Eye, 
  Cpu, HardDrive, Wifi, FileSearch,
  Bell, Plus, Trash2, RefreshCw, Scan,
  CreditCard, Server, Globe, LockKeyhole
} from 'lucide-react';

interface GuardStatus {
  status: 'operational' | 'degraded' | 'critical';
  version: string;
  uptime: number;
  startedAt: number;
  modules: {
    mcp: { status: string; tools: number; sessions: number };
    credits: { status: string; totalRemaining: number };
    sensors: { status: string; active: number };
    protection: { status: string; apps: number };
    scanner: { status: string; scans: number };
    threats: { status: string; blocked: number };
  };
  health: {
    cpuUsage: number;
    memoryUsage: number;
    errorRate: number;
    lastError: string | null;
  };
  stats: {
    totalRequests: number;
    totalBlocked: number;
    totalAlerts: number;
    totalScans: number;
  };
}

interface CreditStatus {
  global: { balance: number; limit: number };
  totalUsed: number;
  totalRemaining: number;
  usageStats: {
    totalCredits: number;
    totalRequests: number;
    avgResponseTime: number;
    errorRate: number;
  };
}

interface ProtectedApp {
  id: string;
  name: string;
  type: string;
  status: string;
  riskScore: number;
  creditsUsed: number;
  creditsRemaining: number;
}

export default function KasbahGuardDashboard() {
  const [status, setStatus] = useState<GuardStatus | null>(null);
  const [credits, setCredits] = useState<CreditStatus | null>(null);
  const [apps, setApps] = useState<ProtectedApp[]>([]);
  const [alerts, setAlerts] = useState<Array<{ id: string; message: string; severity: string }>>([]);
  const [loading, setLoading] = useState(true);
  const [scanTarget, setScanTarget] = useState('');
  const [scanning, setScanning] = useState(false);
  const [scanResult, setScanResult] = useState<Record<string, unknown> | null>(null);

  useEffect(() => {
    fetchDashboardData();
    const interval = setInterval(fetchDashboardData, 30000); // Refresh every 30s
    return () => clearInterval(interval);
  }, []);

  const fetchDashboardData = async () => {
    try {
      const [statusRes, creditsRes, appsRes] = await Promise.all([
        fetch('/api/guard?action=status'),
        fetch('/api/guard?action=credits'),
        fetch('/api/guard?action=apps')
      ]);

      if (statusRes.ok) setStatus(await statusRes.json());
      if (creditsRes.ok) setCredits(await creditsRes.json());
      if (appsRes.ok) {
        const appsData = await appsRes.json();
        setApps(appsData.apps || []);
      }
    } catch (error) {
      console.error('Failed to fetch dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleScan = async () => {
    if (!scanTarget) return;
    
    setScanning(true);
    setScanResult(null);
    
    try {
      const res = await fetch('/api/guard?action=quick-check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ target: scanTarget })
      });
      
      if (res.ok) {
        setScanResult(await res.json());
      }
    } catch (error) {
      console.error('Scan failed:', error);
    } finally {
      setScanning(false);
    }
  };

  const getStatusIcon = () => {
    switch (status?.status) {
      case 'operational': return <ShieldCheck className="h-8 w-8 text-green-500" />;
      case 'degraded': return <ShieldAlert className="h-8 w-8 text-yellow-500" />;
      case 'critical': return <ShieldX className="h-8 w-8 text-red-500" />;
      default: return <Shield className="h-8 w-8 text-gray-500" />;
    }
  };

  const getStatusColor = () => {
    switch (status?.status) {
      case 'operational': return 'text-green-500';
      case 'degraded': return 'text-yellow-500';
      case 'critical': return 'text-red-500';
      default: return 'text-gray-500';
    }
  };

  const formatUptime = (ms: number) => {
    const hours = Math.floor(ms / 3600000);
    const minutes = Math.floor((ms % 3600000) / 60000);
    return `${hours}h ${minutes}m`;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <Shield className="h-12 w-12 mx-auto animate-pulse text-primary" />
          <p className="mt-4 text-muted-foreground">Loading Kasbah Guard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-4">
          {getStatusIcon()}
          <div>
            <h1 className="text-3xl font-bold">Kasbah Guard</h1>
            <p className="text-muted-foreground">Security Layer for Applications</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <Badge variant={status?.status === 'operational' ? 'default' : 'destructive'} className="text-sm">
            {status?.status?.toUpperCase() || 'UNKNOWN'}
          </Badge>
          <Badge variant="outline" className="text-sm">
            v{status?.version || '1.0.0'}
          </Badge>
          <Button variant="outline" size="icon" onClick={fetchDashboardData}>
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-100 dark:bg-green-900 rounded-lg">
                <Shield className="h-5 w-5 text-green-600 dark:text-green-400" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Protected Apps</p>
                <p className="text-2xl font-bold">{status?.modules.protection.apps || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-red-100 dark:bg-red-900 rounded-lg">
                <LockKeyhole className="h-5 w-5 text-red-600 dark:text-red-400" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Threats Blocked</p>
                <p className="text-2xl font-bold">{status?.stats.totalBlocked || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-lg">
                <CreditCard className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">API Credits</p>
                <p className="text-2xl font-bold">{credits?.totalRemaining?.toLocaleString() || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-purple-100 dark:bg-purple-900 rounded-lg">
                <Activity className="h-5 w-5 text-purple-600 dark:text-purple-400" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Uptime</p>
                <p className="text-2xl font-bold">{formatUptime(status?.uptime || 0)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="protection">Protection</TabsTrigger>
          <TabsTrigger value="scanner">Scanner</TabsTrigger>
          <TabsTrigger value="credits">Credits</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Module Status */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Server className="h-5 w-5" />
                  Module Status
                </CardTitle>
                <CardDescription>All security modules operational</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {status?.modules && Object.entries(status.modules).map(([key, module]) => (
                  <div key={key} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className={`h-2 w-2 rounded-full ${
                        module.status === 'healthy' || module.status === 'active' || module.status === 'ready' 
                          ? 'bg-green-500' 
                          : module.status === 'low' 
                            ? 'bg-yellow-500' 
                            : 'bg-red-500'
                      }`} />
                      <span className="capitalize">{key}</span>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {key === 'mcp' && `${module.tools} tools`}
                      {key === 'credits' && `${module.totalRemaining.toLocaleString()} remaining`}
                      {key === 'sensors' && `${module.active} active`}
                      {key === 'protection' && `${module.apps} apps`}
                      {key === 'scanner' && `${module.scans} scans`}
                      {key === 'threats' && `${module.blocked} blocked`}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Health Metrics */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5" />
                  Health Metrics
                </CardTitle>
                <CardDescription>System resource utilization</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm">CPU Usage</span>
                    <span className="text-sm text-muted-foreground">{Math.round(status?.health.cpuUsage || 0)}%</span>
                  </div>
                  <Progress value={status?.health.cpuUsage || 0} />
                </div>
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm">Memory Usage</span>
                    <span className="text-sm text-muted-foreground">{Math.round(status?.health.memoryUsage || 0)}%</span>
                  </div>
                  <Progress value={status?.health.memoryUsage || 0} />
                </div>
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm">Error Rate</span>
                    <span className="text-sm text-muted-foreground">{Math.round((status?.health.errorRate || 0) * 100)}%</span>
                  </div>
                  <Progress value={(status?.health.errorRate || 0) * 100} className="[&>div]:bg-green-500" />
                </div>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bell className="h-5 w-5" />
                  Recent Activity
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <div className="flex items-center gap-3">
                      <Shield className="h-4 w-4 text-green-500" />
                      <span>System initialized</span>
                    </div>
                    <span className="text-sm text-muted-foreground">Just now</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <div className="flex items-center gap-3">
                      <Zap className="h-4 w-4 text-blue-500" />
                      <span>All sensors activated</span>
                    </div>
                    <span className="text-sm text-muted-foreground">1m ago</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <div className="flex items-center gap-3">
                      <Globe className="h-4 w-4 text-purple-500" />
                      <span>Threat intelligence synced</span>
                    </div>
                    <span className="text-sm text-muted-foreground">5m ago</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Protection Tab */}
        <TabsContent value="protection" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Protected Applications</CardTitle>
                  <CardDescription>Applications under Kasbah Guard protection</CardDescription>
                </div>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Application
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {apps.map((app) => (
                  <div key={app.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="p-2 bg-muted rounded-lg">
                        <Shield className="h-5 w-5" />
                      </div>
                      <div>
                        <h4 className="font-medium">{app.name}</h4>
                        <p className="text-sm text-muted-foreground">
                          {app.type} • {app.status}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="text-sm font-medium">Risk Score</p>
                        <p className={`text-lg font-bold ${app.riskScore > 70 ? 'text-red-500' : app.riskScore > 40 ? 'text-yellow-500' : 'text-green-500'}`}>
                          {app.riskScore}
                        </p>
                      </div>
                      <Button variant="ghost" size="icon">
                        <Settings className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
                {apps.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    <Shield className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>No protected applications yet</p>
                    <p className="text-sm">Add an application to start protecting it</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Scanner Tab */}
        <TabsContent value="scanner" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileSearch className="h-5 w-5" />
                Security Scanner
              </CardTitle>
              <CardDescription>
                Scan applications, code, or URLs for security vulnerabilities
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-4">
                <div className="flex-1">
                  <Label htmlFor="scan-target">Target to Scan</Label>
                  <Input
                    id="scan-target"
                    placeholder="Enter code, URL, or file path..."
                    value={scanTarget}
                    onChange={(e) => setScanTarget(e.target.value)}
                  />
                </div>
                <div className="flex items-end gap-2">
                  <Button onClick={handleScan} disabled={scanning || !scanTarget}>
                    {scanning ? (
                      <>
                        <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                        Scanning...
                      </>
                    ) : (
                      <>
                        <Scan className="h-4 w-4 mr-2" />
                        Scan
                      </>
                    )}
                  </Button>
                </div>
              </div>

              {scanResult && (
                <div className="mt-4">
                  <Alert variant={(scanResult as { safe?: boolean }).safe ? 'default' : 'destructive'}>
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle>Scan Complete</AlertTitle>
                    <AlertDescription>
                      <div className="mt-2">
                        <p>Safe: {(scanResult as { safe?: boolean }).safe ? 'Yes' : 'No'}</p>
                        <p>Score: {(scanResult as { score?: number }).score}/100</p>
                        {(scanResult as { issues?: string[] }).issues?.length > 0 && (
                          <div className="mt-2">
                            <p className="font-medium">Issues found:</p>
                            <ul className="list-disc list-inside text-sm">
                              {(scanResult as { issues?: string[] }).issues?.map((issue, i) => (
                                <li key={i}>{issue}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    </AlertDescription>
                  </Alert>
                </div>
              )}
            </CardContent>
          </Card>

          {/* AI/Vibe-Coded App Info */}
          <Card className="border-yellow-200 dark:border-yellow-800">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-yellow-600 dark:text-yellow-400">
                <Zap className="h-5 w-5" />
                AI/Vibe-Coded App Protection
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                Kasbah Guard includes specialized checks for AI-generated applications:
              </p>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center gap-2">
                  <Lock className="h-4 w-4 text-red-500" />
                  <span className="text-sm">Hardcoded secrets detection</span>
                </div>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-orange-500" />
                  <span className="text-sm">Insecure default detection</span>
                </div>
                <div className="flex items-center gap-2">
                  <Eye className="h-4 w-4 text-yellow-500" />
                  <span className="text-sm">Missing validation patterns</span>
                </div>
                <div className="flex items-center gap-2">
                  <Shield className="h-4 w-4 text-green-500" />
                  <span className="text-sm">Injection vulnerability check</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Credits Tab */}
        <TabsContent value="credits" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="h-5 w-5" />
                API Credits
              </CardTitle>
              <CardDescription>Track and manage API credit usage</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm font-medium">Global Credit Usage</span>
                    <span className="text-sm text-muted-foreground">
                      {credits?.totalUsed?.toLocaleString() || 0} / {(credits?.totalUsed || 0) + (credits?.totalRemaining || 0)}
                    </span>
                  </div>
                  <Progress 
                    value={credits ? (credits.totalUsed / (credits.totalUsed + credits.totalRemaining)) * 100 : 0} 
                    className="h-3"
                  />
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="p-4 bg-muted rounded-lg text-center">
                    <p className="text-2xl font-bold">{credits?.usageStats?.totalRequests?.toLocaleString() || 0}</p>
                    <p className="text-sm text-muted-foreground">Total Requests</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg text-center">
                    <p className="text-2xl font-bold">{Math.round(credits?.usageStats?.avgResponseTime || 0)}ms</p>
                    <p className="text-sm text-muted-foreground">Avg Response</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg text-center">
                    <p className="text-2xl font-bold">{credits?.usageStats?.errorRate?.toFixed(2) || 0}%</p>
                    <p className="text-sm text-muted-foreground">Error Rate</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg text-center">
                    <p className="text-2xl font-bold">{credits?.totalRemaining?.toLocaleString() || 0}</p>
                    <p className="text-sm text-muted-foreground">Remaining</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Settings Tab */}
        <TabsContent value="settings" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5" />
                Guard Settings
              </CardTitle>
              <CardDescription>Configure Kasbah Guard behavior</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <h4 className="font-medium">Auto-Block Threats</h4>
                    <p className="text-sm text-muted-foreground">Automatically block detected threats</p>
                  </div>
                  <Button variant="outline" size="sm">Configure</Button>
                </div>
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <h4 className="font-medium">Sensor Sensitivity</h4>
                    <p className="text-sm text-muted-foreground">Adjust sensor detection thresholds</p>
                  </div>
                  <Button variant="outline" size="sm">Configure</Button>
                </div>
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <h4 className="font-medium">MCP Integration</h4>
                    <p className="text-sm text-muted-foreground">Manage AI assistant connections</p>
                  </div>
                  <Button variant="outline" size="sm">Configure</Button>
                </div>
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <h4 className="font-medium">Notifications</h4>
                    <p className="text-sm text-muted-foreground">Alert and notification preferences</p>
                  </div>
                  <Button variant="outline" size="sm">Configure</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Footer */}
      <footer className="mt-12 pt-6 border-t text-center text-sm text-muted-foreground">
        <p>Kasbah Guard v{status?.version} • Security Layer for Vibe-Coded Applications</p>
        <p className="mt-1">Protected by {status?.modules?.protection?.apps || 0} apps • {status?.stats?.totalBlocked || 0} threats blocked</p>
      </footer>
    </div>
  );
}
